"""Retain the exact standalone Scheduler qualification, including any refusal."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
PHASE = "scheduler-standalone-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    receipt = json.loads(q.own("evidence/" + PHASE + "/receipt.json").read_bytes())
    data = {}
    def add(path):
        if path in data:
            raise RuntimeError("Duplicate member")
        data[path] = q.own(path).read_bytes()
    for row in receipt["commands"]:
        if not row["settled"] or row["timed_out"]:
            raise RuntimeError("Unsettled qualification")
        for stream in ("stdout", "stderr"):
            raw = q.own("evidence/" + PHASE + "/" + row["label"] + "." + stream + ".log").read_bytes()
            if len(raw) != row[stream]["bytes"] or q.sha(raw) != row[stream]["sha256"]:
                raise RuntimeError("Raw qualification stream changed")
    for path in q.own("evidence/" + PHASE).iterdir():
        if path.is_file():
            add(path.relative_to(ROOT).as_posix())
    for path in ["evidence/materialize-" + PHASE + "/receipt.json", "evidence/materialize-" + PHASE + "/receipt-initial.json",
        "plans/" + PHASE + ".json", "inputs/660-source-tree-20261123-57604a3a.json", "qualify_go.py",
        "prepare_scheduler_standalone_20261123_57604a3a.py", "export_scheduler_standalone_20261123_57604a3a.py"]:
        add(path)
    archive = q.own("exports/" + PHASE + ".zip")
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, raw in sorted(data.items()):
            zipped.writestr(name, raw)
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None or set(zipped.namelist()) != set(data):
            raise RuntimeError("Archive membership changed")
        for name, raw in data.items():
            if zipped.read(name) != raw:
                raise RuntimeError("Archive bytes changed")
    raw = archive.read_bytes()
    manifest = {"archive": archive.relative_to(ROOT).as_posix(), "bytes": len(raw), "sha256": q.sha(raw),
        "qualification_completed": receipt["completed"],
        "members": [{"path": name, "bytes": len(value), "sha256": q.sha(value)} for name, value in sorted(data.items())]}
    q.save(archive.with_suffix(".json"), manifest)
    with archive.with_suffix(".b64").open("x", encoding="ascii", newline="\n") as stream:
        stream.write(base64.b64encode(raw).decode() + "\n")
    print(json.dumps({k: v for k, v in manifest.items() if k != "members"}), flush=True)

if __name__ == "__main__":
    main()
