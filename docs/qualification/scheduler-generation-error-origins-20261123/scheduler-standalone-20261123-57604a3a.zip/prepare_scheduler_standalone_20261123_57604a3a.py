"""Check the Scheduler patch on its own exact PR base, without composing donors."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
BASE = "026928c31977788444f6b3e3504324ae21106446"
TREE = "42069a9870ac9585e425711a84f950d92b353d87"
SOURCE = "candidate-scheduler-standalone-20261123-57604a3a"
INPUTS = "candidate-next-continuation-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
TREE_SHA = "db558e3b968c8fbb1358086d90545cf08bd797e999dc974f7ff7aa4d65cc2845"
CHANGES = [
    "internal/api/" + name for name in (
        "r36_lane_a2_fixes_test.go", "scheduler_mgmt.go", "scheduler_mgmt_validation_test.go",
        "scheduler_replacement.go", "scheduler_replacement_test.go", "scheduler_swap.go", "scheduler_swap_test.go",
        "scheduler_upgrade_recovery_test.go", "scheduler_upgrade_snapshot_test.go", "weekly_refresh.go",
        "weekly_refresh_applied_result_test.go", "weekly_refresh_atomic_test.go", "weekly_refresh_call_graph_origins_test.go",
        "weekly_refresh_recovery_test.go", "weekly_refresh_test.go")
] + ["internal/gui/daemons_test.go", "internal/gui/weekly_schedule_applied_result_test.go"]

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    raw_tree = q.own("inputs/660-source-tree-20261123-57604a3a.json").read_bytes()
    if q.sha(raw_tree) != TREE_SHA:
        raise RuntimeError("Exact PR tree manifest changed")
    tree = json.loads(raw_tree)
    if tree["base_commit"] != BASE or tree["base_tree"] != TREE or len(tree["files"]) != 3266:
        raise RuntimeError("Unexpected PR base identity")
    expected = {row["path"]: row for row in tree["files"]}
    if len(expected) != 3266 or any(row["mode"] != "100644" for row in expected.values()):
        raise RuntimeError("Unsupported PR tree")
    a1_raw = q.own("plans/a1-continuation-20261123-57604a3a.json").read_bytes()
    if q.sha(a1_raw) != "258f368ce98cd71d97e90246d76570fdb2a08c22bb2b448efceba3d9e9e9d6ae":
        raise RuntimeError("Qualified composition plan changed")
    a1 = json.loads(a1_raw)
    admitted = {row["path"]: row for row in a1["source_files"]}
    inputs = [admitted[path] for path in CHANGES]
    inputs_before = q.check_files(INPUTS, inputs)
    phase = "scheduler-standalone-20261123-57604a3a"
    out = q.own("evidence/materialize-" + phase)
    out.mkdir()
    receipt = {"started_utc": q.now(), "completed": False, "base_commit": BASE, "base_tree": TREE,
        "exact_new_git_commit": None, "installs": False, "native_scheduler_operations": False,
        "dependency_downloads": False, "source_archive_download": True, "inputs_before": inputs_before}
    q.save(out / "receipt-initial.json", receipt)
    try:
        url = "https://codeload.github.com/applicate2628/mcp-local-hub/zip/" + BASE
        archive = out / "base-source.zip"
        with urllib.request.urlopen(url, timeout=30) as response, archive.open("xb") as stream:
            total = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > 64 * 1024 * 1024:
                    raise RuntimeError("Source archive exceeds admitted transfer size")
                stream.write(chunk)
        receipt["source_archive"] = {"url": url, "bytes": archive.stat().st_size, "sha256": q.sha(archive.read_bytes())}
        data = {}
        with zipfile.ZipFile(archive) as zipped:
            prefix = "mcp-local-hub-" + BASE + "/"
            for item in zipped.infolist():
                if item.is_dir():
                    continue
                if not item.filename.startswith(prefix):
                    raise RuntimeError("Unexpected archive root")
                path = item.filename[len(prefix):]
                if str(PurePosixPath(path)) != path or ".." in PurePosixPath(path).parts or path not in expected or path in data:
                    raise RuntimeError("Unadmitted archive path")
                raw = zipped.read(item)
                blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
                if blob != expected[path]["blob"] or len(raw) != expected[path]["bytes"]:
                    raise RuntimeError("Source archive differs from exact Git tree: " + path)
                data[path] = raw
        if set(data) != set(expected):
            raise RuntimeError("Incomplete PR source")
        for row in inputs:
            raw = q.own(INPUTS + "/" + row["path"]).read_bytes()
            if q.sha(raw) != row["sha256"] or len(raw) != row["bytes"]:
                raise RuntimeError("Scheduler input changed")
            data[row["path"]] = raw
        q.own(SOURCE).mkdir()
        for path, raw in sorted(data.items()):
            target = q.own(SOURCE + "/" + path)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(raw)
        files = [{"path": path, "bytes": len(raw), "sha256": q.sha(raw)} for path, raw in sorted(data.items())]
        receipt["source"] = q.check_files(SOURCE, files, True)
        a4_raw = q.own("plans/a4-contract-proof-20261123-v1.json").read_bytes()
        a4 = json.loads(a4_raw)
        commands = a1["commands"] + a4["commands"][:4] + [
            {"label": "standalone-build", "tool": "go", "args": ["build", "./..."], "timeout_seconds": 300, "expected_exit_code": 0},
            {"label": "standalone-vet", "tool": "go", "args": ["vet", "./..."], "timeout_seconds": 300, "expected_exit_code": 0}]
        plan = {**a1, "phase": phase, "source_directory": SOURCE, "source_head": BASE, "source_tree": None,
            "source_files": files, "inputs_directory": INPUTS, "input_files": inputs, "commands": commands}
        plan_path = q.own("plans/" + phase + ".json")
        q.save(plan_path, plan)
        receipt["plan"] = {"path": plan_path.relative_to(ROOT).as_posix(), "sha256": q.sha(plan_path.read_bytes())}
        receipt["contract_plan_sha256"] = q.sha(a4_raw)
        receipt["inputs_after"] = q.check_files(INPUTS, inputs)
        if receipt["inputs_before"] != receipt["inputs_after"]:
            raise RuntimeError("Scheduler inputs changed during materialization")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
