import sys
sys.dont_write_bytecode = True
import base64, hashlib, importlib.util, json, subprocess
from pathlib import Path

ROOT=Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
OLD='install-generation-v1-20261123-57604a3a'
PHASE='install-generation-v2-20261123-57604a3a'
RUNNER_SHA='a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e'
PLAN_SHA='9c25061366969e2e2ee5623ce6001f887b3f0ea990d4cd4924660ff389bbbe17'
CORRECTIONS='install-generation-corrections-v2-20261123-57604a3a.json'
CORRECTIONS_SHA='75e66b3ecf3d549b24a69d7c179e8a1cb43c9d27ebf4e7a3555fc32ab4b21a02'

def main():
    if sys.platform!='win32' or sys.flags.optimize or Path(__file__).parent!=ROOT: raise RuntimeError('Fixed Windows root required')
    if hashlib.sha256((ROOT/'qualify_go.py').read_bytes()).hexdigest()!=RUNNER_SHA: raise RuntimeError('Runner changed')
    spec=importlib.util.spec_from_file_location('qualification',ROOT/'qualify_go.py')
    q=importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
    raw=q.own('plans/'+OLD+'.json').read_bytes()
    if q.sha(raw)!=PLAN_SHA: raise RuntimeError('Prior source manifest changed')
    prior=json.loads(raw)
    receipt1=json.loads(q.own('evidence/'+OLD+'/receipt.json').read_bytes())
    if len(receipt1['commands'])!=1 or any(not c['settled'] or c['timed_out'] for c in receipt1['commands']): raise RuntimeError('Prior run not settled')
    raw=q.own(CORRECTIONS).read_bytes()
    if q.sha(raw)!=CORRECTIONS_SHA: raise RuntimeError('Corrections changed')
    corrections=json.loads(raw)
    out=q.own('evidence/materialize-'+PHASE); out.mkdir()
    receipt={'started_utc':q.now(),'completed':False,'prior_phase':OLD,'prior_manifest_sha256':PLAN_SHA,'corrections_sha256':CORRECTIONS_SHA,'native_scheduler_operations':False,'installs':False}
    q.save(out/'receipt-initial.json',receipt)
    try:
        receipt['prior_source_before']=q.check_files(prior['source_directory'],prior['source_files'],True)
        receipt['prior_inputs_before']=q.check_files(prior['inputs_directory'],prior['input_files'],True)
        source='candidate-'+PHASE
        inputs='inputs/'+PHASE
        q.own(source).mkdir(); q.own(inputs).mkdir()
        for row in prior['source_files']:
            p=q.own(source+'/'+row['path']); p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f: f.write(q.own(prior['source_directory']+'/'+row['path']).read_bytes())
        for row in prior['input_files']:
            if row['path']=='old-owner-overlay.json': continue
            p=q.own(inputs+'/'+row['path']); p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f: f.write(q.own(prior['inputs_directory']+'/'+row['path']).read_bytes())
        corrected=[]
        for row in corrections['files']:
            b=base64.b64decode(row['base64'],validate=True)
            if len(b)!=row['bytes'] or q.sha(b)!=row['sha256']: raise RuntimeError('Correction bytes differ')
            if row['path'] not in {'internal/api/install_prune_recovery_test.go','internal/api/install_task_mutation_failure_test.go'}: raise RuntimeError('Unexpected correction')
            q.own(source+'/'+row['path']).write_bytes(b); corrected.append(row['path'])
        runtime=q.own('runtime/format-'+PHASE); runtime.mkdir()
        env=q.environment(runtime,{})
        if q.sha(q.GOFMT.read_bytes())!=q.PINS[str(q.GOFMT)]: raise RuntimeError('Formatter changed')
        argv=[str(q.GOFMT),'-w',*[str(q.own(source+'/'+p)) for p in corrected]]
        with (out/'gofmt.stdout.log').open('xb') as stdout,(out/'gofmt.stderr.log').open('xb') as stderr:
            result=subprocess.run(argv,env=env,cwd=q.own(source),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
        if result.returncode!=0: raise RuntimeError('Formatter failed')
        for p in corrected: q.own(inputs+'/formatted/'+p).write_bytes(q.own(source+'/'+p).read_bytes())
        files=[]
        for row in prior['source_files']:
            b=q.own(source+'/'+row['path']).read_bytes()
            files.append({'path':row['path'],'bytes':len(b),'sha256':q.sha(b)})
        manifest=json.loads(q.own(inputs+'/manifest.json').read_bytes())
        overlay={'Replace':{str(q.own(source+'/'+p)):str(q.own(inputs+'/control/'+p)) for p in manifest['controls']}}
        overlay_path=q.own(inputs+'/old-owner-overlay.json'); q.save(overlay_path,overlay)
        input_files=[]
        for p in sorted(q.own(inputs).rglob('*')):
            if p.is_file():
                b=p.read_bytes(); input_files.append({'path':p.relative_to(q.own(inputs)).as_posix(),'bytes':len(b),'sha256':q.sha(b)})
        commands=prior['commands'][:2]
        commands[1]={**commands[1],'args':[('-overlay='+str(overlay_path)) if a.startswith('-overlay=') else a for a in commands[1]['args']]}
        commands.append({'label':'install-generation-standard-callers','tool':'go','args':['test','-race','-count=1','-timeout=180s','-json','-run','^TestExecuteInstallTo','./internal/api'],'timeout_seconds':300,'expected_exit_code':0,'required_tests':{'pass':['PACKAGE:mcp-local-hub/internal/api','TestExecuteInstallToGenerationOwnershipRefusal','TestExecuteInstallToPruneRetainsObservedDefinition'],'fail':[],'skip':[]}})
        original=json.loads(q.own('plans/scheduler-standalone-20261123-57604a3a.json').read_bytes())
        for c in original['commands']:
            if c['label'] in ('production-lock-order','a4-api-contract'): commands.append(c)
        commands+=prior['commands'][2:]
        plan={**prior,'phase':PHASE,'source_directory':source,'source_files':files,'inputs_directory':inputs,'input_files':input_files,'commands':commands}
        plan_path=q.own('plans/'+PHASE+'.json'); q.save(plan_path,plan)
        receipt['plan']={'path':plan_path.relative_to(ROOT).as_posix(),'sha256':q.sha(plan_path.read_bytes())}
        receipt['source']=q.check_files(source,files,True)
        receipt['inputs']=q.check_files(inputs,input_files,True)
        receipt['prior_source_after']=q.check_files(prior['source_directory'],prior['source_files'],True)
        receipt['prior_inputs_after']=q.check_files(prior['inputs_directory'],prior['input_files'],True)
        if receipt['prior_source_before']!=receipt['prior_source_after'] or receipt['prior_inputs_before']!=receipt['prior_inputs_after']: raise RuntimeError('Prior evidence changed')
        receipt['commands']=[c['label'] for c in commands]
        receipt['completed']=True
    except BaseException as e:
        receipt.update(error_type=type(e).__name__,error=str(e)); raise
    finally:
        receipt['finished_utc']=q.now(); q.save(out/'receipt.json',receipt); print(json.dumps(receipt),flush=True)

if __name__=='__main__': main()
