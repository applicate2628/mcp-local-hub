import sys
sys.dont_write_bytecode=True
import base64, hashlib, importlib.util, json, zipfile
from pathlib import Path

ROOT=Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
PHASES=['install-generation-v1-20261123-57604a3a','install-generation-v2-20261123-57604a3a']
RUNNER_SHA='a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e'

def main():
    if sys.platform!='win32' or sys.flags.optimize or Path(__file__).parent!=ROOT: raise RuntimeError('Fixed root required')
    if hashlib.sha256((ROOT/'qualify_go.py').read_bytes()).hexdigest()!=RUNNER_SHA: raise RuntimeError('Runner changed')
    spec=importlib.util.spec_from_file_location('qualification',ROOT/'qualify_go.py')
    q=importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
    data={}; summary=[]
    def add(path):
        b=q.own(path).read_bytes()
        if path in data and data[path]!=b: raise RuntimeError('Duplicate source changed')
        data[path]=b
    for phase in PHASES:
        receipt=json.loads(q.own('evidence/'+phase+'/receipt.json').read_bytes())
        raw_plan=q.own('plans/'+phase+'.json').read_bytes()
        if q.sha(raw_plan)!=receipt['manifest_sha256']: raise RuntimeError('Plan changed')
        plan=json.loads(raw_plan)
        if not receipt['source_before']==receipt['source_after']==q.check_files(plan['source_directory'],plan['source_files'],True): raise RuntimeError('Qualified source changed')
        if not receipt['inputs_before']==receipt['inputs_after']==q.check_files(plan['inputs_directory'],plan['input_files']): raise RuntimeError('Qualified inputs changed')
        for c in receipt['commands']:
            if not c['settled'] or c['timed_out']: raise RuntimeError('Unsettled command')
            for stream in ('stdout','stderr'):
                raw=q.own('evidence/'+phase+'/'+c['label']+'.'+stream+'.log').read_bytes()
                if len(raw)!=c[stream]['bytes'] or q.sha(raw)!=c[stream]['sha256']: raise RuntimeError('Raw stream differs')
        for p in q.own('evidence/'+phase).iterdir():
            if p.is_file(): add(p.relative_to(ROOT).as_posix())
        for leaf in ('receipt-initial.json','receipt.json','gofmt.stdout.log','gofmt.stderr.log'):
            p='evidence/materialize-'+phase+'/'+leaf
            if q.own(p).exists(): add(p)
        add('plans/'+phase+'.json')
        for row in plan['input_files']: add(plan['inputs_directory']+'/'+row['path'])
        summary.append({'phase':phase,'completed':receipt['completed'],'source':receipt['source_after'],
            'commands':[{'label':c['label'],'exit':c.get('exit_code'),'oracle':c['oracle_pass'],'seconds':c['seconds'],'pass':len(c.get('tests',{}).get('pass',[])),'fail':c.get('tests',{}).get('fail',[]),'skip':c.get('tests',{}).get('skip',[])} for c in receipt['commands']]})
    if not summary[-1]['completed']: raise RuntimeError('Final phase not complete')
    for p in ['qualify_go.py','prepare_install_generation_20261123_57604a3a.py','prepare_install_generation_v2_20261123_57604a3a.py','export_install_generation_20261123_57604a3a.py','install-generation-corrections-v2-20261123-57604a3a.json']:
        add(p)
    archive=q.own('exports/install-generation-20261123-57604a3a.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,b in sorted(data.items()): z.writestr(path,b)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or set(z.namelist())!=set(data): raise RuntimeError('Archive membership differs')
        for path,b in data.items():
            if z.read(path)!=b: raise RuntimeError('Archive bytes differ')
    raw=archive.read_bytes()
    manifest={'archive':archive.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':q.sha(raw),'phases':summary,
        'members':[{'path':p,'bytes':len(b),'sha256':q.sha(b)} for p,b in sorted(data.items())]}
    q.save(archive.with_suffix('.json'),manifest)
    with archive.with_suffix('.b64').open('x',encoding='ascii') as f: f.write(base64.b64encode(raw).decode())
    print(json.dumps({k:v for k,v in manifest.items() if k!='members'}),flush=True)

if __name__=='__main__': main()
