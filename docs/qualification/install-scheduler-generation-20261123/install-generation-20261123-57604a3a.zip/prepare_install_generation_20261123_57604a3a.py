"""Materialize and qualify the reviewed install generation refusal on exact #660."""
import sys
sys.dont_write_bytecode = True
import base64, hashlib, importlib.util, json, re, subprocess, urllib.request, zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
BASE = '58d7c948e410fdb5969abb9a8a4febfea8f14150'
TREE = '6da0563e56d6b11db92e72dbdccea295314cd289'
PHASE = 'install-generation-v1-20261123-57604a3a'
SOURCE = 'candidate-' + PHASE
INPUTS = 'inputs/' + PHASE
PAYLOAD = 'install-generation-inputs-v1-20261123-57604a3a.b64'
PAYLOAD_SHA = 'cde9ebea01108ee0e681bd52b89dd97ac021309f5d77b4ecbb18864ecbaa42ff'
MANIFEST_SHA = '06874b312552d77f46a84411c89e5be3325270d67e5d9277a8d2a8f063a623bf'
RUNNER_SHA = 'a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e'

def main():
    if sys.platform != 'win32' or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError('Use the fixed task root')
    if hashlib.sha256((ROOT/'qualify_go.py').read_bytes()).hexdigest() != RUNNER_SHA:
        raise RuntimeError('Qualification owner changed')
    spec = importlib.util.spec_from_file_location('qualification', ROOT/'qualify_go.py')
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    out = q.own('evidence/materialize-' + PHASE)
    out.mkdir()
    receipt = {'started_utc':q.now(),'completed':False,'base_commit':BASE,'base_tree':TREE,
        'installs':False,'native_scheduler_operations':False,'dependency_downloads':False,
        'exact_new_git_commit':None,'source_archive_download':True}
    q.save(out/'receipt-initial.json',receipt)
    try:
        raw = base64.b64decode(q.own(PAYLOAD).read_bytes(),validate=True)
        if q.sha(raw) != PAYLOAD_SHA: raise RuntimeError('Transport differs')
        archive = out/'reviewed-inputs.zip'
        archive.write_bytes(raw)
        with zipfile.ZipFile(archive) as z:
            manifest_raw=z.read('manifest.json')
            if q.sha(manifest_raw) != MANIFEST_SHA: raise RuntimeError('Manifest differs')
            manifest=json.loads(manifest_raw)
            if manifest['base_commit'] != BASE: raise RuntimeError('Wrong base')
            expected={row['path']:row for row in manifest['files']}
            if set(z.namelist()) != set(expected)|{'manifest.json'}: raise RuntimeError('Unexpected payload members')
            q.own(INPUTS).mkdir()
            for path in sorted(z.namelist()):
                p=q.own(INPUTS+'/'+path)
                b=z.read(path)
                if path in expected and (len(b)!=expected[path]['bytes'] or q.sha(b)!=expected[path]['sha256']): raise RuntimeError('Input differs: '+path)
                p.parent.mkdir(parents=True,exist_ok=True)
                with p.open('xb') as f: f.write(b)
        tree=json.loads(q.own(INPUTS+'/base-tree.json').read_bytes())
        if tree['base_commit']!=BASE or len(tree['files'])!=3272: raise RuntimeError('Tree differs')
        expected={row['path']:row for row in tree['files']}
        if len(expected)!=3272 or any(x['mode']!='100644' for x in expected.values()): raise RuntimeError('Unadmitted tree mode')
        source_archive=out/'exact-source.zip'
        url='https://codeload.github.com/applicate2628/mcp-local-hub/zip/'+BASE
        with urllib.request.urlopen(url,timeout=30) as response, source_archive.open('xb') as f:
            size=0
            while True:
                block=response.read(1024*1024)
                if not block: break
                size+=len(block)
                if size>64*1024*1024: raise RuntimeError('Source archive exceeds bound')
                f.write(block)
        receipt['source_archive']={'url':url,'bytes':source_archive.stat().st_size,'sha256':q.sha(source_archive.read_bytes())}
        data={}
        with zipfile.ZipFile(source_archive) as z:
            prefix='mcp-local-hub-'+BASE+'/'
            for member in z.infolist():
                if member.is_dir(): continue
                if not member.filename.startswith(prefix): raise RuntimeError('Unexpected source root')
                path=member.filename[len(prefix):]
                if path not in expected or path in data or str(PurePosixPath(path))!=path or '..' in PurePosixPath(path).parts: raise RuntimeError('Unexpected source path')
                b=z.read(member)
                blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
                if blob!=expected[path]['blob'] or len(b)!=expected[path]['bytes']: raise RuntimeError('Source Git blob differs: '+path)
                data[path]=b
        if set(data)!=set(expected): raise RuntimeError('Incomplete exact source')
        receipt['git_blobs_verified']=len(data)
        for path in manifest['changed']: data[path]=q.own(INPUTS+'/candidate/'+path).read_bytes()
        q.own(SOURCE).mkdir()
        for path,b in sorted(data.items()):
            target=q.own(SOURCE+'/'+path)
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f: f.write(b)
        for path,digest in q.PINS.items():
            if q.sha(Path(path).read_bytes())!=digest: raise RuntimeError('Installed tool changed')
        runtime=q.own('runtime/format-'+PHASE)
        runtime.mkdir()
        env=q.environment(runtime,{})
        argv=[str(q.GOFMT),'-w',*[str(q.own(SOURCE+'/'+path)) for path in manifest['changed']]]
        with (out/'gofmt.stdout.log').open('xb') as stdout,(out/'gofmt.stderr.log').open('xb') as stderr:
            result=subprocess.run(argv,env=env,cwd=q.own(SOURCE),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
        receipt['format']={'argv':argv,'exit_code':result.returncode}
        if result.returncode!=0: raise RuntimeError('Formatting failed')
        for path in manifest['changed']:
            data[path]=q.own(SOURCE+'/'+path).read_bytes()
            target=q.own(INPUTS+'/formatted/'+path)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data[path])
        files=[{'path':p,'bytes':len(b),'sha256':q.sha(b)} for p,b in sorted(data.items())]
        input_files=[]
        for path in sorted(q.own(INPUTS).rglob('*')):
            if path.is_file():
                b=path.read_bytes()
                input_files.append({'path':path.relative_to(q.own(INPUTS)).as_posix(),'bytes':len(b),'sha256':q.sha(b)})
        receipt['source']=q.check_files(SOURCE,files,True)
        receipt['inputs']=q.check_files(INPUTS,input_files,True)
        tests=[]
        for path in manifest['changed']:
            if path.endswith('_test.go'):
                tests+=re.findall(r'^func (Test\w+)\(t \*testing\.T\)',data[path].decode(),re.MULTILINE)
        pattern='^('+'|'.join(sorted(tests))+')$'
        def command(label, args, code=0, required=None):
            result={'label':label,'tool':'go','args':args,'timeout_seconds':300,'expected_exit_code':code}
            if required is not None: result['required_tests']=required
            return result
        commands=[command('install-generation-focused', ['test','-tags=test_state_path_env','-race','-count=1','-timeout=180s','-json','-run',pattern,'./internal/api'],required={'pass':sorted(tests)+['PACKAGE:mcp-local-hub/internal/api'],'fail':[],'skip':[]})]
        overlay={'Replace':{str(q.own(SOURCE+'/'+p)):str(q.own(INPUTS+'/control/'+p)) for p in manifest['controls']}}
        overlay_path=q.own(INPUTS+'/old-owner-overlay.json')
        q.save(overlay_path,overlay)
        raw=overlay_path.read_bytes()
        input_files.append({'path':'old-owner-overlay.json','bytes':len(raw),'sha256':q.sha(raw)})
        controls=['TestExecuteInstallToGenerationOwnershipRefusal','TestExecuteInstallToEarlierTaskRollback','TestInstallTaskMutationFailureDoesNotAcceptSameXMLAsGeneration']
        commands.append(command('install-generation-old-owner-control', ['test','-tags=test_state_path_env','-race','-count=1','-timeout=180s','-json','-overlay='+str(overlay_path),'-run','^('+'|'.join(controls)+')$','./internal/api'],1,{'fail':[controls[0]+'/replacement_external_same_xml',controls[0]+'/prune_external_same_xml',controls[1]+'/external_same_xml',controls[2]+'/same_xml']}))
        old_plan=json.loads(q.own('plans/scheduler-standalone-20261123-57604a3a.json').read_bytes())
        for c in old_plan['commands']:
            if c['label']=='a1-production-barrier': commands.append(c)
        commands += [command('install-generation-build',['build','./...']),command('install-generation-vet',['vet','./...'])]
        plan={**old_plan,'phase':PHASE,'source_directory':SOURCE,'source_head':BASE,'source_tree':TREE,
            'source_note':'Exact parent Git tree plus the eleven enumerated reviewed files; physical inventory identifies the candidate.',
            'source_files':files,'inputs_directory':INPUTS,'input_files':input_files,'commands':commands}
        plan_path=q.own('plans/'+PHASE+'.json')
        q.save(plan_path,plan)
        receipt['plan']={'path':plan_path.relative_to(ROOT).as_posix(),'sha256':q.sha(plan_path.read_bytes())}
        receipt['test_functions']=len(tests)
        receipt['commands']=[c['label'] for c in commands]
        receipt['completed']=True
    except BaseException as e:
        receipt.update(error_type=type(e).__name__,error=str(e))
        raise
    finally:
        receipt['finished_utc']=q.now()
        q.save(out/'receipt.json',receipt)
        print(json.dumps({k:v for k,v in receipt.items() if k not in ('format',)}),flush=True)

if __name__=='__main__': main()
