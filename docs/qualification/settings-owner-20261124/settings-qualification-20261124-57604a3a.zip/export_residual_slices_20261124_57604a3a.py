"""Export settled receipts and exact changed bytes; retain raw originals separately."""
import sys
sys.dont_write_bytecode=True
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import zipfile

ROOT=Path(r"<qualification-root>")
QSHA="a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
TAIL="-20261124-57604a3a"
def main():
    if sys.platform!="win32" or sys.flags.optimize or Path(__file__).parent!=ROOT or len(sys.argv)!=2:raise RuntimeError("Use fixed root and named slice")
    if hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest()!=QSHA:raise RuntimeError("Runner changed")
    spec=importlib.util.spec_from_file_location("qualification",ROOT/"qualify_go.py")
    q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    kind=sys.argv[1]
    if kind=="census":
        phases=["census-"+role+"-"+selection+"-v1"+TAIL for role in ("owner","composed","control") for selection in ("standard","tagged")]
        extra=["census-v1"+TAIL+"/receipt.json","census-v1"+TAIL+"/owner/internal/api/weekly_refresh_atomic_test.go","census-v1"+TAIL+"/composed/internal/api/weekly_refresh_atomic_test.go","census-v1"+TAIL+"/control/internal/api/state_dir_resolution_observed_windows_test.go","prepare_census_20261124_57604a3a.py"]
        required=phases
    elif kind=="relay":
        phases=["relay-post-candidate-v1"+TAIL,"relay-post-control-v1"+TAIL,"relay-sdk-candidate-v2"+TAIL,"relay-sdk-control-v2"+TAIL,"relay-regression-v2"+TAIL,"relay-regression-v3"+TAIL]
        extra=["relay-resumption-v"+str(v)+TAIL+"/receipt.json" for v in (1,2,3)]
        extra += ["relay-resumption-v3"+TAIL+"/candidate/internal/daemon/"+n for n in ("relay.go","relay_post_resume.go","relay_post_resume_test.go","relay_post_consumer_test.go","relay_response_contract_test.go")]
        extra += ["prepare_relay_resumption_20261124_57604a3a.py","prepare_relay_sdk_20261124_57604a3a.py","prepare_relay_v3_20261124_57604a3a.py"]
        required=[p for p in phases if p!="relay-regression-v2"+TAIL]
    elif kind=="settings":
        phases=["settings-owner-v1"+TAIL,"settings-architecture-v1"+TAIL]
        extra=["settings-owner-v1"+TAIL+"/receipt.json","prepare_settings_owner_20261124_57604a3a.py"]
        extra += ["settings-owner-v1"+TAIL+"/candidate/"+n for n in ("internal/gui/server.go","internal/gui/settings.go","internal/gui/settings_test.go","architecture/baseline.yaml")]
        required=[phases[0]]
    else:raise RuntimeError("Unknown slice")
    data={};summary=[];checked={}
    def add(path):
        raw=q.own(path).read_bytes()
        if path in data and data[path]!=raw:raise RuntimeError("Member changed while exporting")
        data[path]=raw
    for phase in phases:
        folder="evidence/"+phase
        receipt=json.loads(q.own(folder+"/receipt.json").read_bytes())
        if phase in required and not receipt["completed"]:raise RuntimeError("Required phase incomplete: "+phase)
        raw=q.own("plans/"+phase+".json").read_bytes()
        if q.sha(raw)!=receipt["manifest_sha256"]:raise RuntimeError("Plan changed")
        plan=json.loads(raw);key=(plan["source_directory"],receipt["source_before"]["inventory_sha256"])
        if key not in checked:checked[key]=q.check_files(plan["source_directory"],plan["source_files"],True)
        if receipt["source_before"]!=receipt["source_after"] or checked[key]!=receipt["source_after"]:raise RuntimeError("Qualified source changed")
        if receipt["inputs_before"]!=receipt["inputs_after"] or receipt["inputs_after"]!=q.check_files(plan["inputs_directory"],plan["input_files"]):raise RuntimeError("Qualified input changed")
        for command in receipt["commands"]:
            if not command["settled"] or command["timed_out"]:raise RuntimeError("Unsettled command")
            for stream in ("stdout","stderr"):
                raw=q.own(folder+"/"+command["label"]+"."+stream+".log").read_bytes()
                if len(raw)!=command[stream]["bytes"] or q.sha(raw)!=command[stream]["sha256"]:raise RuntimeError("Original event stream changed")
        for path in sorted(q.own(folder).iterdir()):
            if path.is_file():add(path.relative_to(ROOT).as_posix())
        add("plans/"+phase+".json")
        summary.append({"phase":phase,"completed":receipt["completed"],"source":receipt["source_after"],"commands":[{"label":c["label"],"exit_code":c["exit_code"],"oracle_pass":c["oracle_pass"],"seconds":c["seconds"],"pass":len(c.get("tests",{}).get("pass",[])),"fail":c.get("tests",{}).get("fail",[]),"skip":c.get("tests",{}).get("skip",[])} for c in receipt["commands"]]})
    for path in ["qualify_go.py","export_residual_slices_20261124_57604a3a.py",*extra]:add(path)
    name=kind+"-qualification"+TAIL
    raw_archive=q.own("exports/"+name+"-raw.zip")
    public_archive=q.own("exports/"+name+".zip")
    substitutions=[]
    aliases=[(str(ROOT),"<qualification-root>"),(str(ROOT).replace("\\","/"),"<qualification-root>"),(r"<existing-tool-cache>","<existing-tool-cache>"),("<existing-tool-cache>","<existing-tool-cache>")]
    for old,new in aliases:substitutions.extend(((old,new),(json.dumps(old)[1:-1],new)))
    def public(raw):
        s=raw.decode("utf-8")
        for old,new in sorted(substitutions,key=lambda p:len(p[0]),reverse=True):s=s.replace(old,new)
        s=re.sub(r"(?i)C:(?:\\\\|\\|/)Users(?:\\\\|\\|/)[^\\/\s\"]+", "<user-profile>",s)
        return s.encode()
    published={name:public(raw) for name,raw in data.items()}
    manifest={"schema":"qualified-evidence-export-v1","kind":kind,"phases":summary,"raw_archive":{"bytes":0,"sha256":""},"path_redaction_only":True,"original_events_retained":True,"executables_included":False,"members":[{"path":p,"original_bytes":len(b),"original_sha256":q.sha(b),"published_bytes":len(published[p]),"published_sha256":q.sha(published[p])} for p,b in sorted(data.items())]}
    for archive,content in ((raw_archive,data),(public_archive,published)):
        with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p,b in sorted(content.items()):z.writestr(p,b)
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None or set(z.namelist())!=set(content) or any(z.read(p)!=b for p,b in content.items()):raise RuntimeError("Archive readback mismatch")
    manifest["raw_archive"]={"bytes":raw_archive.stat().st_size,"sha256":q.sha(raw_archive.read_bytes())}
    raw=public_archive.read_bytes();manifest.update(archive=public_archive.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=q.sha(raw))
    q.save(public_archive.with_suffix(".json"),manifest)
    encoded=base64.b64encode(raw)
    parts=[]
    for i,start in enumerate(range(0,len(encoded),180000)):
        path=q.own("exports/"+name+"-%02d.b64"%i);block=encoded[start:start+180000]
        with path.open("xb") as f:f.write(block)
        parts.append({"path":path.relative_to(ROOT).as_posix(),"bytes":len(block),"sha256":q.sha(block)})
    transfer={"archive":manifest["archive"],"bytes":len(raw),"sha256":q.sha(raw),"parts":parts,"phases":summary}
    q.save(public_archive.with_name(name+"-transfer.json"),transfer)
    print(json.dumps(transfer),flush=True)

if __name__=="__main__":main()
