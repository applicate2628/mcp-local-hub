"""Qualify the settings adapter against its exact existing architecture owner."""
import sys
sys.dont_write_bytecode=True
import base64
import hashlib
import importlib.util
import io
import json
from pathlib import Path,PurePosixPath
import re
import subprocess
import urllib.request
import zipfile

ROOT=Path(r"<qualification-root>")
WORK="settings-owner-v1-20261124-57604a3a"
BASE="67f89401c31736399c84d866828241db8c12d8cb"
TREE="d4e9bc0ce85f6bbbc46f236b2e6189853753a19b"
QSHA="a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
ZIP_SHA="c59557ca7fd770566b5f6e4aa66bf5a21f6cb8b4ec3892911e0cb2569bae5ac4"
def main():
    if sys.platform!="win32" or sys.flags.optimize or Path(__file__).parent!=ROOT:raise RuntimeError("Use fixed task root")
    if hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest()!=QSHA:raise RuntimeError("Runner changed")
    spec=importlib.util.spec_from_file_location("qualification",ROOT/"qualify_go.py")
    q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    raw=base64.b64decode(b"".join(q.own("settings-owner-inputs-v1-%02d.b64"%i).read_bytes() for i in range(3)),validate=True)
    if q.sha(raw)!=ZIP_SHA:raise RuntimeError("Reviewed input changed")
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if set(z.namelist())!={"payload.json","owner-tree.json"} or len(z.infolist())!=2:raise RuntimeError("Unexpected payload")
        changes=json.loads(z.read("payload.json"));tree=json.loads(z.read("owner-tree.json"))
    expected={p["path"]:p for p in tree["files"]};pins={p["path"]:p for p in changes}
    if tree["commit"]!=BASE or tree["tree"]!=TREE or len(expected)!=3287:raise RuntimeError("Owner source differs")
    if len(pins)!=4 or set(pins)!={"internal/gui/server.go","internal/gui/settings.go","internal/gui/settings_test.go","architecture/baseline.yaml"}:raise RuntimeError("Unexpected ownership delta")
    out=q.own(WORK);out.mkdir()
    receipt={"completed":False,"started_utc":q.now(),"base_commit":BASE,"base_tree":TREE,"payload_sha256":ZIP_SHA,"installs":False,"native_scheduler_operations":False,"plans":[]}
    q.save(out/"receipt-initial.json",receipt)
    try:
        with (out/"reviewed-inputs.zip").open("xb") as f:f.write(raw)
        archive=out/"exact-owner.zip";url="https://codeload.github.com/applicate2628/mcp-local-hub/zip/"+BASE;size=0
        with urllib.request.urlopen(url,timeout=30) as response,archive.open("xb") as f:
            while True:
                b=response.read(262144)
                if not b:break
                size+=len(b)
                if size>64*1024*1024:raise RuntimeError("Owner archive exceeds bound")
                f.write(b)
        receipt["source_archive"]={"bytes":size,"sha256":q.sha(archive.read_bytes()),"url":url}
        contents={};prefix="mcp-local-hub-"+BASE+"/"
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                if not item.filename.startswith(prefix) or item.flag_bits&1:raise RuntimeError("Unexpected source member")
                if item.is_dir():continue
                name=item.filename[len(prefix):];path=PurePosixPath(name)
                if name not in expected or name in contents or path.is_absolute() or path.as_posix()!=name or any(p in ("..",".git") for p in path.parts):raise RuntimeError("Unadmitted source path")
                b=z.read(item);pin=expected[name]
                if pin["mode"]!="100644" or len(b)!=pin["bytes"] or hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()!=pin["blob"]:raise RuntimeError("Source blob differs: "+name)
                contents[name]=b
        if set(contents)!=set(expected):raise RuntimeError("Incomplete owner source")
        for name,pin in pins.items():
            if q.sha(contents[name])!=pin["before_sha256"]:raise RuntimeError("Wrong ownership delta before image")
            b=pin["content"].encode()
            if len(b)!=pin["bytes"] or q.sha(b)!=pin["sha256"]:raise RuntimeError("Delta bytes changed")
            contents[name]=b
        for name,b in sorted(contents.items()):
            target=q.own(WORK+"/candidate/"+name);target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as f:f.write(b)
        runtime=q.own("runtime/"+WORK+"-prepare");runtime.mkdir();env=q.environment(runtime,{})
        if q.sha(q.GOFMT.read_bytes())!=q.PINS[str(q.GOFMT)]:raise RuntimeError("Formatter changed")
        with (out/"format.stdout.log").open("xb") as stdout,(out/"format.stderr.log").open("xb") as stderr:
            p=subprocess.Popen([str(q.GOFMT),"-w",*(str(q.own(WORK+"/candidate/"+name)) for name in sorted(pins) if name.endswith(".go"))],cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            try:code=p.wait(timeout=30)
            except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10);raise
        if code!=0 or (out/"format.stderr.log").stat().st_size:raise RuntimeError("Formatter failed")
        files=[]
        for name in sorted(contents):
            b=q.own(WORK+"/candidate/"+name).read_bytes();files.append({"path":name,"bytes":len(b),"sha256":q.sha(b)})
        q.save(out/"candidate-files.json",files);receipt["candidate"]=q.check_files(WORK+"/candidate",files,True)
        roots=[n.decode() for n in re.findall(rb"^func (TestSettings_\w+)\(t \*testing\.T\)",contents["internal/gui/settings_test.go"],re.MULTILINE)]
        roots += ["TestGUIOwnerPolicyAcquisitionKeepsIndependentOwners","TestGUIOwnerPolicyAcquisitionRefusalPreservesRecord","TestGUIOwnerPolicyHandoffRefusalPreservesRecord","TestClientInstallPrefs_UsesServerAPI","TestClientInstallPrefs_ServersKeepIndependentDependencies","TestLSPRouterControlRoutesKeepServerDependenciesSeparate","TestAcquireSingleInstance_BoundLifecycleAvoidsPostPublishOpenFailure"]
        basis={"schema":1,"runner_sha256":QSHA,"source_head":BASE+"+settings-owner","source_tree":"UNISSUED","source_note":"Exact owner inventory plus settings adapter binding, fixture isolation and deletion of two obsolete baseline entries.","source_directory":WORK+"/candidate","source_files":files,"inputs_directory":WORK,"input_files":[{"path":"reviewed-inputs.zip","bytes":len(raw),"sha256":ZIP_SHA}],"native_scheduler_operations":False}
        commands=[]
        for tagged in (False,True):
            args=["test","-race","-count=1","-timeout=180s","-json"]
            if tagged:args+=["-tags=test_state_path_env"]
            args += ["-run","^("+"|".join(roots)+")$","./internal/gui"]
            commands.append({"label":"settings-"+("tagged" if tagged else "standard"),"tool":"go","args":args,"timeout_seconds":300,"expected_exit_code":0,"required_tests":{"pass":roots+["PACKAGE:mcp-local-hub/internal/gui"]}})
        commands += [{"label":"settings-build","tool":"go","args":["build","./..."],"timeout_seconds":300,"expected_exit_code":0},{"label":"settings-vet","tool":"go","args":["vet","./..."],"timeout_seconds":300,"expected_exit_code":0}]
        phase=WORK
        arch_phase="settings-architecture-v1-20261124-57604a3a"
        arch={"label":"settings-architecture","tool":"go","args":["run","./tools/archcheck","verify","--root",".","--policy","architecture/policy.yaml","--baseline","architecture/baseline.yaml","--workers","architecture/workers.yaml","--report-json",str(q.own("evidence/"+arch_phase+"/architecture.json")),"--report-md",str(q.own("evidence/"+arch_phase+"/architecture.md"))],"timeout_seconds":300,"expected_exit_code":0}
        for name,cmds in ((phase,commands),(arch_phase,[arch])):
            plan={**basis,"phase":name,"commands":cmds};path=q.own("plans/"+name+".json");q.save(path,plan)
            receipt["plans"].append({"phase":name,"path":path.relative_to(ROOT).as_posix(),"sha256":q.sha(path.read_bytes())})
        receipt["completed"]=True
    except BaseException as error:receipt.update(error_type=type(error).__name__,error=str(error));raise
    finally:receipt["finished_utc"]=q.now();q.save(out/"receipt.json",receipt);print(json.dumps(receipt),flush=True)

if __name__=="__main__":main()
