"""Materialize the exact #629 owner and private POST-resumption controls."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import urllib.request
import zipfile

ROOT = Path(r"<qualification-root>")
WORK = "relay-resumption-v1-20261124-57604a3a"
BASE = "4b6ec39930cb5a0498dba068b99dbf29ba7129b7"
QSHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
INPUT_SHA = "21e33f36fa05ff8b22e2305bb9322d2fcb890735c7d296ca92479db213847ed3"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT or len(sys.argv) != 2:
        raise RuntimeError("Use the fixed work root and exact base tree")
    if not re.fullmatch(r"[0-9a-f]{40}", sys.argv[1]): raise RuntimeError("Invalid base tree")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QSHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
    payload = base64.b64decode(b"".join(q.own("relay-resume-transfer-v1-%02d.b64" % i).read_bytes() for i in range(2)), validate=True)
    if q.sha(payload) != INPUT_SHA: raise RuntimeError("Reviewed input differs")
    out = q.own(WORK); out.mkdir()
    receipt = {"completed": False, "started_utc": q.now(), "source_head": BASE, "source_tree": sys.argv[1], "payload_sha256": INPUT_SHA,
        "installs": False, "native_scheduler_operations": False, "tests_executed": False, "files": 3231}
    q.save(out / "receipt-initial.json", receipt)
    try:
        with (out / "reviewed-inputs.zip").open("xb") as stream: stream.write(payload)
        with zipfile.ZipFile(io.BytesIO(payload)) as z:
            manifest = json.loads(z.read("manifest.json"))
            expected = {p["path"]: p for p in manifest["payload_files"]}
            if manifest["base_commit"] != BASE or set(z.namelist()) != set(expected) | {"manifest.json"} or len(z.infolist()) != len(expected)+1:
                raise RuntimeError("Input archive membership differs")
            data = {}
            for name, pin in expected.items():
                raw = z.read(name)
                if len(raw) != pin["bytes"] or q.sha(raw) != pin["sha256"]: raise RuntimeError("Input archive content differs")
                data[name] = raw
        tree = json.loads(data["owner-tree.json"])
        pins = {p["path"]: p for p in tree}
        if len(tree) != 3231 or len(pins) != 3231: raise RuntimeError("Base tree membership differs")
        archive = out / "exact-owner.zip"
        url = "https://codeload.github.com/applicate2628/mcp-local-hub/zip/" + BASE
        size = 0
        with urllib.request.urlopen(url, timeout=30) as response, archive.open("xb") as target:
            while True:
                block = response.read(262144)
                if not block: break
                size += len(block)
                if size > 64*1024*1024: raise RuntimeError("Owner source archive exceeds admitted bound")
                target.write(block)
        receipt["source_archive"] = {"url": url, "bytes": size, "sha256": q.sha(archive.read_bytes())}
        prefix = "mcp-local-hub-" + BASE + "/"
        contents = {}
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                if not item.filename.startswith(prefix) or item.flag_bits & 1: raise RuntimeError("Unadmitted source ZIP entry")
                name = item.filename[len(prefix):]
                if item.is_dir(): continue
                path = PurePosixPath(name)
                if name not in pins or name in contents or path.as_posix() != name or path.is_absolute() or any(p in ("..", ".git") for p in path.parts):
                    raise RuntimeError("Source ZIP path differs")
                raw = z.read(item); pin = pins[name]
                blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
                if pin["mode"] != "100644" or len(raw) != pin["bytes"] or blob != pin["blob"]:
                    raise RuntimeError("Source Git blob differs: " + name)
                contents[name] = raw
        if set(contents) != set(pins): raise RuntimeError("Complete source membership differs")
        receipt["test_main_sources"] = [p for p, raw in contents.items() if p.startswith("internal/daemon/") and p.endswith(".go") and re.search(rb"\bfunc\s+TestMain\s*\(",raw)]
        for name, raw in sorted(contents.items()):
            for role in ("base", "candidate", "control"):
                target = q.own(WORK + "/" + role + "/" + name); target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as stream: stream.write(raw)
        changes = sorted(name.removeprefix("candidate/") for name in data if name.startswith("candidate/"))
        if changes != ["internal/daemon/relay.go", "internal/daemon/relay_post_resume.go", "internal/daemon/relay_post_resume_test.go"]:
            raise RuntimeError("Unexpected POST resumption scope")
        for name in changes:
            target = q.own(WORK + "/candidate/" + name)
            with target.open("wb" if name in contents else "xb") as stream: stream.write(data["candidate/" + name])
        if q.sha(q.GOFMT.read_bytes()) != q.PINS[str(q.GOFMT)]: raise RuntimeError("Formatter changed")
        runtime = q.own("runtime/" + WORK + "-prepare"); runtime.mkdir()
        env = q.environment(runtime,{})
        args = [str(q.GOFMT), "-w", *(str(q.own(WORK + "/candidate/" + name)) for name in changes)]
        with (out / "format.stdout.log").open("xb") as stdout, (out / "format.stderr.log").open("xb") as stderr:
            child = subprocess.Popen(args, cwd=out, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt["formatter_pid"] = child.pid
            try: receipt["formatter_exit"] = child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                child.terminate(); child.wait(timeout=10); raise
        if receipt["formatter_exit"] != 0 or (out / "format.stderr.log").stat().st_size: raise RuntimeError("Formatter failed")
        test_path = "internal/daemon/relay_post_resume_test.go"
        with q.own(WORK + "/control/" + test_path).open("xb") as stream: stream.write(q.own(WORK + "/candidate/" + test_path).read_bytes())
        inventories = {}
        for role in ("base", "candidate", "control"):
            names = sorted(set(contents) | (set(changes) if role == "candidate" else {test_path} if role == "control" else set()))
            rows = []
            for name in names:
                raw = q.own(WORK + "/" + role + "/" + name).read_bytes()
                rows.append({"path": name, "bytes": len(raw), "sha256": q.sha(raw)})
            inventories[role] = rows
            q.save(out / (role + "-files.json"), rows)
            receipt[role] = q.check_files(WORK + "/" + role, rows, True)
        roots = ["TestRelayPOSTResumesOriginalStream", "TestRelayPOSTResumptionCursorAndVersion", "TestRelayPOSTResumptionPreservesReadAndCloseErrors", "TestRelayPOSTResumptionRejectsParserAndOutputFailure", "TestRelayPOSTResumptionKeepsAbsoluteDeadline"]
        receipt["plans"] = []
        for role in ("candidate", "control"):
            phase = "relay-post-" + role + "-v1-20261124-57604a3a"
            required = roots if role == "candidate" else [roots[0], roots[2], roots[4]]
            command = {"label": "post-resumption-" + role, "tool": "go", "args": ["test", "-race", "-count=1", "-timeout=120s", "-json", "-run", "^(" + "|".join(required) + ")$", "./internal/daemon"], "timeout_seconds": 240, "expected_exit_code": 0 if role == "candidate" else 1,
                "required_tests": {"pass" if role == "candidate" else "fail": [*required, "PACKAGE:mcp-local-hub/internal/daemon"]}}
            plan = {"schema": 1, "phase": phase, "runner_sha256": QSHA, "source_head": BASE + ("+post-resumption" if role == "candidate" else "+new-regression-tests"), "source_tree": sys.argv[1], "source_note": "Exact inventory differs from the named base; no issued Source/Product role.", "source_directory": WORK + "/" + role, "source_files": inventories[role], "inputs_directory": WORK,
                "input_files": [{"path": "reviewed-inputs.zip", "bytes": len(payload), "sha256": INPUT_SHA}], "native_scheduler_operations": False, "commands": [command]}
            path = q.own("plans/" + phase + ".json"); q.save(path, plan)
            receipt["plans"].append({"phase": phase, "path": path.relative_to(ROOT).as_posix(), "sha256": q.sha(path.read_bytes())})
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error)); raise
    finally:
        receipt["finished_utc"] = q.now(); q.save(out / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__": main()
