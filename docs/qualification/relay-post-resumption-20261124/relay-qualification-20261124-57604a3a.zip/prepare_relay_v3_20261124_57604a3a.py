"""Correct the framing fixture's request identity and add a mismatched-response control."""
import sys
sys.dont_write_bytecode=True
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT=Path(r"<qualification-root>")
OLD="relay-resumption-v2-20261124-57604a3a"
WORK="relay-resumption-v3-20261124-57604a3a"
QSHA="a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
PSHA="5c574a96d4b2b8ebef29f12478f8694d585120f5153a6042863636f2a436c545"
def main():
    if sys.platform!="win32" or sys.flags.optimize or Path(__file__).parent!=ROOT:raise RuntimeError("Use fixed root")
    if hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest()!=QSHA:raise RuntimeError("Runner changed")
    spec=importlib.util.spec_from_file_location("qualification",ROOT/"qualify_go.py")
    q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    raw=q.own("relay-v3-reviewed-payload.json").read_bytes()
    if q.sha(raw)!=PSHA:raise RuntimeError("Reviewed payload changed")
    rows=json.loads(q.own(OLD+"/candidate-files.json").read_bytes());before=q.check_files(OLD+"/candidate",rows,True)
    changes=json.loads(raw);pins={p["path"]:p for p in changes}
    if len(pins)!=2 or set(pins)!={"internal/daemon/relay_response_contract_test.go","internal/daemon/relay_post_resume_test.go"}:raise RuntimeError("Unexpected fixture scope")
    out=q.own(WORK);out.mkdir()
    receipt={"completed":False,"started_utc":q.now(),"source_before":before,"payload_sha256":PSHA,"production_changes_from_v2":False,"installs":False,"native_scheduler_operations":False}
    q.save(out/"receipt-initial.json",receipt)
    try:
        with (out/"reviewed-payload.json").open("xb") as f:f.write(raw)
        for row in rows:
            b=q.own(OLD+"/candidate/"+row["path"]).read_bytes()
            if q.sha(b)!=row["sha256"] or len(b)!=row["bytes"]:raise RuntimeError("Preserved source changed")
            if row["path"] in pins:
                pin=pins[row["path"]]
                if q.sha(b)!=pin["before_sha256"]:raise RuntimeError("Wrong fixture before image")
                b=pin["content"].encode()
                if len(b)!=pin["bytes"] or q.sha(b)!=pin["sha256"]:raise RuntimeError("Fixture content differs")
            target=q.own(WORK+"/candidate/"+row["path"]);target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as f:f.write(b)
        runtime=q.own("runtime/"+WORK+"-prepare");runtime.mkdir();env=q.environment(runtime,{})
        if q.sha(q.GOFMT.read_bytes())!=q.PINS[str(q.GOFMT)]:raise RuntimeError("Formatter changed")
        with (out/"format.stdout.log").open("xb") as stdout,(out/"format.stderr.log").open("xb") as stderr:
            p=subprocess.Popen([str(q.GOFMT),"-w",*(str(q.own(WORK+"/candidate/"+name)) for name in sorted(pins))],cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            try:code=p.wait(timeout=30)
            except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10);raise
        if code!=0 or (out/"format.stderr.log").stat().st_size:raise RuntimeError("Formatter failed")
        full=[]
        for row in rows:
            b=q.own(WORK+"/candidate/"+row["path"]).read_bytes();full.append({"path":row["path"],"bytes":len(b),"sha256":q.sha(b)})
        q.save(out/"candidate-files.json",full);receipt["candidate"]=q.check_files(WORK+"/candidate",full,True)
        plan_raw=q.own("plans/relay-regression-v2-20261124-57604a3a.json").read_bytes()
        if q.sha(plan_raw)!="abecddadf1030a553fa2e4423f08daa70d27f8411dd66aef2658a8e40b9cc338":raise RuntimeError("Regression selection changed")
        plan=json.loads(plan_raw);phase="relay-regression-v3-20261124-57604a3a"
        plan.update(phase=phase,source_directory=WORK+"/candidate",source_files=full,inputs_directory=WORK,input_files=[{"path":"reviewed-payload.json","bytes":len(raw),"sha256":PSHA}])
        path=q.own("plans/"+phase+".json");q.save(path,plan);receipt["plan"]={"phase":phase,"path":path.relative_to(ROOT).as_posix(),"sha256":q.sha(path.read_bytes())}
        if q.check_files(OLD+"/candidate",rows,True)!=before:raise RuntimeError("Preserved candidate changed")
        receipt["completed"]=True
    except BaseException as error:receipt.update(error_type=type(error).__name__,error=str(error));raise
    finally:receipt["finished_utc"]=q.now();q.save(out/"receipt.json",receipt);print(json.dumps(receipt),flush=True)

if __name__=="__main__":main()
