"""Add the real pinned Go SDK consumer to preserved POST resumption candidates."""
import sys
sys.dont_write_bytecode=True
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(r"<qualification-root>")
OLD="relay-resumption-v1-20261124-57604a3a"
WORK="relay-resumption-v2-20261124-57604a3a"
QSHA="a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
REL="internal/daemon/relay_post_consumer_test.go"
def main():
    if sys.platform!="win32" or sys.flags.optimize or Path(__file__).parent!=ROOT or len(sys.argv)!=2: raise RuntimeError("Use fixed root with reviewed test SHA256")
    if hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest()!=QSHA: raise RuntimeError("Runner changed")
    spec=importlib.util.spec_from_file_location("qualification",ROOT/"qualify_go.py")
    q=importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
    new=q.own("relay-post-consumer-reviewed-v2.go").read_bytes()
    if q.sha(new)!=sys.argv[1]: raise RuntimeError("Consumer test changed")
    out=q.own(WORK); out.mkdir()
    receipt={"completed":False,"started_utc":q.now(),"reviewed_test_sha256":q.sha(new),"production_change":"identical to v1 candidate","installs":False,"native_scheduler_operations":False,"plans":[]}
    q.save(out/"receipt-initial.json",receipt)
    try:
        with (out/"reviewed-consumer.go").open("xb") as f:f.write(new)
        runtime=q.own("runtime/"+WORK+"-prepare");runtime.mkdir();env=q.environment(runtime,{})
        if q.sha(q.GOFMT.read_bytes())!=q.PINS[str(q.GOFMT)]:raise RuntimeError("Formatter changed")
        for role in ("candidate","control"):
            rows=json.loads(q.own(OLD+"/"+role+"-files.json").read_bytes())
            q.check_files(OLD+"/"+role,rows,True)
            contents={}
            for pin in rows:
                b=q.own(OLD+"/"+role+"/"+pin["path"]).read_bytes()
                if q.sha(b)!=pin["sha256"] or len(b)!=pin["bytes"]:raise RuntimeError("Old candidate changed")
                contents[pin["path"]]=b
            if REL in contents:raise RuntimeError("Consumer already exists")
            contents[REL]=new
            for name,b in sorted(contents.items()):
                target=q.own(WORK+"/"+role+"/"+name);target.parent.mkdir(parents=True,exist_ok=True)
                with target.open("xb") as f:f.write(b)
            with (out/(role+"-format.stdout.log")).open("xb") as stdout,(out/(role+"-format.stderr.log")).open("xb") as stderr:
                p=subprocess.Popen([str(q.GOFMT),"-w",str(q.own(WORK+"/"+role+"/"+REL))],cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
                try:code=p.wait(timeout=30)
                except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10);raise
            if code!=0 or (out/(role+"-format.stderr.log")).stat().st_size:raise RuntimeError("Formatter failed")
            contents[REL]=q.own(WORK+"/"+role+"/"+REL).read_bytes()
            files=[{"path":p,"bytes":len(b),"sha256":q.sha(b)} for p,b in sorted(contents.items())]
            q.save(out/(role+"-files.json"),files);receipt[role]=q.check_files(WORK+"/"+role,files,True)
            source_plan=json.loads(q.own("plans/relay-post-"+role+"-v1-20261124-57604a3a.json").read_bytes())
            phase="relay-sdk-"+role+"-v2-20261124-57604a3a"
            root="TestRelayPOSTConsumerSDKResumesStoredResult"
            command={"label":"sdk-post-"+role,"tool":"go","args":["test","-race","-count=1","-timeout=120s","-json","-run","^"+root+"$","./internal/daemon"],"timeout_seconds":240,"expected_exit_code":0 if role=="candidate" else 1,"required_tests":{"pass" if role=="candidate" else "fail":[root,"PACKAGE:mcp-local-hub/internal/daemon"]}}
            if role=="control":command["required_output"]=["SDK POST-origin replay"]
            basis={**source_plan,"phase":phase,"source_directory":WORK+"/"+role,"source_files":files,"source_note":"Same v1 production bytes plus real Go SDK POST consumer; unissued private inventory.","inputs_directory":WORK,"input_files":[{"path":"reviewed-consumer.go","bytes":len(new),"sha256":q.sha(new)}],"commands":[command]}
            plans=[basis]
            if role=="candidate":
                roots=[]
                for path,b in contents.items():
                    if path.startswith("internal/daemon/relay") and path.endswith("_test.go"):
                        roots+=re.findall(rb"^func (TestRelay\w+)\(t \*testing\.T\)",b,re.MULTILINE)
                names=sorted({n.decode() for n in roots})+["TestQualificationExchangeUsesRealReceiver","TestQualificationSessionCloseIsCached","TestQualificationZeroObservationRefuses"]
                regression={"label":"all-relay-and-shared-receiver","tool":"go","args":["test","-race","-count=1","-timeout=180s","-json","-run","^("+"|".join(names)+")$","./internal/daemon"],"timeout_seconds":300,"expected_exit_code":0,"required_tests":{"pass":names+["PACKAGE:mcp-local-hub/internal/daemon"]}}
                build={"label":"relay-build","tool":"go","args":["build","./..."],"timeout_seconds":300,"expected_exit_code":0}
                vet={"label":"relay-vet","tool":"go","args":["vet","./..."],"timeout_seconds":300,"expected_exit_code":0}
                plans.append({**basis,"phase":"relay-regression-v2-20261124-57604a3a","commands":[regression,build,vet]})
                receipt["regression_roots"]=names
            for plan in plans:
                path=q.own("plans/"+plan["phase"]+".json");q.save(path,plan)
                receipt["plans"].append({"phase":plan["phase"],"path":path.relative_to(ROOT).as_posix(),"sha256":q.sha(path.read_bytes())})
            q.check_files(OLD+"/"+role,rows,True)
        receipt["completed"]=True
    except BaseException as error:receipt.update(error_type=type(error).__name__,error=str(error));raise
    finally:receipt["finished_utc"]=q.now();q.save(out/"receipt.json",receipt);print(json.dumps(receipt),flush=True)

if __name__=="__main__":main()
