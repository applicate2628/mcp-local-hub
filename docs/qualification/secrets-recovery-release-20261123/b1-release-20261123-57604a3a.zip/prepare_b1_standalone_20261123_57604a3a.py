"""Materialize the two-file recovery change on the exact retained master archive."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
PHASE = "materialize-b1-standalone-20261123-57604a3a"
SOURCE = "candidate-b1-standalone-20261123-57604a3a"
MASTER = "75dbc6406123e22468f168b861d5e0622c9d5769"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
INPUTS = "inputs/continuation-20261123-57604a3a"
CHANGES = {
    "internal/api/secrets_init_recovery.go": "f40c60a79affd1e9c1cb9b61a93c870eea2edec0899cf4c7766169aa1dfe3caf",
    "internal/api/secrets_init_recovery_lock_test.go": "db8569cfede6f1a265d1bd5935f62d2d6c010885780be5bc27b57b3d3ce1f4b1",
}

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed work root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    archive = q.own("a5-prep/master-download/master.zip")
    if q.sha(archive.read_bytes()) != "2e688e6e1e84cc062b3213a50f59f8cad61fac730a2afe44ecaba7f2937d09ac":
        raise RuntimeError("Exact master archive changed")
    basis = json.loads(q.own("plans/b1-continuation-20261123-57604a3a.json").read_bytes())
    before = json.loads(q.own("a5-prep/inputs/base-files.json").read_bytes())
    expected = {row["path"]: row for row in before}
    if len(expected) != 3270 or len(before) != 3270:
        raise RuntimeError("Master path inventory changed")
    evidence = q.own("evidence/" + PHASE)
    source = q.own(SOURCE)
    if evidence.exists() or source.exists():
        raise RuntimeError("Fresh standalone paths occupied")
    data = {}
    with zipfile.ZipFile(archive) as zipped:
        prefix = "mcp-local-hub-" + MASTER + "/"
        for item in zipped.infolist():
            if item.is_dir():
                continue
            if not item.filename.startswith(prefix):
                raise RuntimeError("Archive root mismatch")
            path = item.filename[len(prefix):]
            if str(PurePosixPath(path)) != path or ".." in PurePosixPath(path).parts or path not in expected or path in data:
                raise RuntimeError("Unexpected or duplicate archive path")
            raw = zipped.read(item)
            row = expected[path]
            blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            if len(raw) != row["bytes"] or q.sha(raw) != row["sha256"] or blob != row["blob"]:
                raise RuntimeError("Master archive content mismatch: " + path)
            data[path] = raw
    if set(data) != set(expected):
        raise RuntimeError("Incomplete master archive")
    inputs, provenance = [], []
    for path, digest in CHANGES.items():
        raw = q.own(INPUTS + "/" + path).read_bytes()
        if q.sha(raw) != digest:
            raise RuntimeError("Changed input mismatch: " + path)
        provenance.append({"path": path, "before": expected.get(path), "after_sha256": digest})
        inputs.append({"path": path, "bytes": len(raw), "sha256": digest})
        data[path] = raw
    evidence.mkdir()
    source.mkdir()
    for path, raw in sorted(data.items()):
        output = q.own(SOURCE + "/" + path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("xb") as stream:
            stream.write(raw)
    files = [{"path": path, "bytes": len(raw), "sha256": q.sha(raw)} for path, raw in sorted(data.items())]
    result = q.check_files(SOURCE, files, True)
    selection = "^(TestSecretsInitRecoveryLock.*|TestSecretsInit_Recovery(Stages|RetentionFaults|Codec|Producer|ProducerPersistenceFailures|StrictWriterFaults|ReadbackAndIndependentInspect|Capacity|ReadOnlyReport|ConcurrentTerminalAndConflict|CaptureRefusal)|TestReleaseAndJoinAppliedSettlementMatrix)$"
    commands = []
    for label, tags in [("standard-recovery-contract", []), ("tagged-recovery-contract", ["-tags=test_state_path_env"])]:
        commands.append({"label": label, "tool": "go", "args": ["test", *tags, "-race", "-count=1", "-timeout=180s", "-json", "-run", selection, "./internal/api"],
            "timeout_seconds": 240, "expected_exit_code": 0, "required_tests": {"pass": ["TestSecretsInitRecoveryLockSettlement", "TestSecretsInitRecoveryLockAcquireFailure", "TestSecretsInitRecoveryLockReleasesOnPanic", "TestSecretsInit_RecoveryProducerPersistenceFailures", "PACKAGE:mcp-local-hub/internal/api"]}})
    commands.extend([
        {"label": "api-vet", "tool": "go", "args": ["vet", "./internal/api"], "timeout_seconds": 300, "expected_exit_code": 0},
        {"label": "api-build", "tool": "go", "args": ["build", "./internal/api"], "timeout_seconds": 300, "expected_exit_code": 0}])
    phase = "b1-standalone-20261123-57604a3a"
    plan = {**basis, "phase": phase, "source_directory": SOURCE, "source_head": MASTER, "source_tree": None,
        "source_files": files, "inputs_directory": INPUTS, "input_files": inputs, "commands": commands}
    path = q.own("plans/" + phase + ".json")
    if path.exists():
        raise RuntimeError("Fresh standalone plan occupied")
    q.save(path, plan)
    receipt = {"completed": True, "base_commit": MASTER, "exact_new_git_commit": None, "source": result,
        "changes": provenance, "plan": {"path": path.relative_to(ROOT).as_posix(), "sha256": q.sha(path.read_bytes())}}
    q.save(evidence / "receipt.json", receipt)
    print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
