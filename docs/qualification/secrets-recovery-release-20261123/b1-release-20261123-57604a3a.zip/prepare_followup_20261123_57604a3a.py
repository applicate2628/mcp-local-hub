"""Prepare exact regression controls and a native namespace launcher build.

Data-only: no child, policy, scheduler, installation, or existing source writes.
"""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
BASE = "plans/b1-continuation-20261123-57604a3a.json"
BASE_SHA = "94850d9b5b25e5d326702990b4bdb8428b8cd4e5eb9875c544139e87335c5508"
INPUTS = "inputs/b1-controls-20261123-57604a3a"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    raw = q.own(BASE).read_bytes()
    if q.sha(raw) != BASE_SHA:
        raise RuntimeError("Exact source manifest changed")
    base = json.loads(raw)
    source = base["source_directory"]
    q.check_files(source, base["source_files"], True)
    inputs = q.own(INPUTS)
    inputs.mkdir()
    old = q.own("candidate-next-a1-scheduler-20261123-v1/internal/api/secrets_init_recovery.go").read_bytes()
    if q.sha(old) != "e585d5fc9c3b6a82f66b557b7fa50937fddfa2b94d7d473870d2cd1ae8971544":
        raise RuntimeError("Original recovery owner changed")
    fixed = q.own(source + "/internal/api/secrets_init_recovery.go").read_bytes()
    if q.sha(fixed) != "f40c60a79affd1e9c1cb9b61a93c870eea2edec0899cf4c7766169aa1dfe3caf":
        raise RuntimeError("Fixed recovery owner changed")
    needle = b"return errors.Join(e.InitError, e.PersistenceCause)"
    if fixed.count(needle) != 1:
        raise RuntimeError("Envelope control is ambiguous")
    variants = {"old-owner.go": old, "old-envelope.go": fixed.replace(needle, b"return e.InitError")}
    for name, data in variants.items():
        with (inputs / name).open("xb") as out:
            out.write(data)
        q.save(inputs / (name + ".overlay.json"), {"Replace": {str(q.own(source + "/internal/api/secrets_init_recovery.go")): str(inputs / name)}})
    pins = [{"path": p.name, "bytes": len(p.read_bytes()), "sha256": q.sha(p.read_bytes())} for p in sorted(inputs.iterdir())]
    prefix = ["test", "-tags=test_state_path_env", "-race", "-count=1", "-timeout=180s", "-json"]
    package = "PACKAGE:mcp-local-hub/internal/api"
    root = "TestSecretsInitRecoveryLockSettlement"
    negatives = []
    for variant, marker in [("old-owner.go", "release outcome="), ("old-envelope.go", "API recovery envelope lost causes:")]:
        negatives.append({"label": variant.removesuffix(".go"), "tool": "go",
            "args": [*prefix, "-overlay=" + str(inputs / (variant + ".overlay.json")), "-run", "^" + root + "$/^(success|primary|primary-and-recovery)$/^release-failure$", "./internal/api"],
            "timeout_seconds": 240, "expected_exit_code": 1,
            "required_output": [marker], "required_tests": {"fail": [root + "/" + name + "/release-failure" for name in ("success", "primary", "primary-and-recovery")] + [root, package]}})
    regression = {"label": "recovery-lock-contract", "tool": "go",
        "args": [*prefix, "-run", "^(TestSecretsInitRecoveryLock.*|TestSecretsInit_Recovery(Stages|RetentionFaults|Codec|Producer|ProducerPersistenceFailures|StrictWriterFaults|ReadbackAndIndependentInspect|Capacity|ReadOnlyReport|ConcurrentTerminalAndConflict|CaptureRefusal)|TestSupervisorIntentLockOwnership.*|TestReleaseAndJoinAppliedSettlementMatrix)$", "./internal/api"],
        "timeout_seconds": 240, "expected_exit_code": 0,
        "required_tests": {"pass": [root, "TestSecretsInitRecoveryLockAcquireFailure", "TestSecretsInitRecoveryLockReleasesOnPanic", "TestSecretsInit_RecoveryProducerPersistenceFailures", "TestSupervisorIntentLockOwnershipProductionInventory", package]}}
    launcher = q.own("exports/recovery-namespace-continuation-20261123-57604a3a.exe")
    if launcher.exists():
        raise RuntimeError("Fresh launcher output is occupied")
    configurations = {
        "b1-controls-20261123-57604a3a": negatives,
        "b1-contract-20261123-57604a3a": [regression],
        "namespace-build-20261123-57604a3a": [{"label": "namespace-launcher-build", "tool": "go", "args": ["build", "-o", str(launcher), "./tools/test-recovery-namespace"], "timeout_seconds": 300, "expected_exit_code": 0}],
    }
    result = []
    for phase, commands in configurations.items():
        plan = {**base, "phase": phase, "commands": commands, "inputs_directory": INPUTS, "input_files": pins}
        path = q.own("plans/" + phase + ".json")
        if path.exists():
            raise RuntimeError("Fresh plan occupied")
        q.save(path, plan)
        result.append({"path": path.relative_to(ROOT).as_posix(), "sha256": q.sha(path.read_bytes())})
    print(json.dumps({"plans": result, "source": q.check_files(source, base["source_files"], True), "input_files": pins}), flush=True)

if __name__ == "__main__":
    main()
