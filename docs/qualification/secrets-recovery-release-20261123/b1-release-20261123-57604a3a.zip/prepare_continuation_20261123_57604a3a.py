"""Compose four reviewed changes into a fresh, fully inventoried source copy.

This data-only preparation imports the existing read/copy/check owner. It starts
no child, changes no installation, and performs no scheduler or network action.
The former candidate and every prior receipt remain unchanged.
"""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
BASIS_PLAN = "plans/a1-error-proof-20261123-v1.json"
BASIS_SHA = "e2f3a3bc91937d2804039d89f95c7225727a496e2b8af12b2849b16423bd8562"
INPUTS = "inputs/continuation-20261123-57604a3a"
SOURCE = "candidate-next-continuation-20261123-57604a3a"
PHASE = "materialize-continuation-20261123-57604a3a"
CHANGES = {
    "internal/api/weekly_refresh_call_graph_origins_test.go": "preserve the exact read-step callback through the reviewed reader chain",
    "internal/api/secrets_init_recovery.go": "join operation and release causes with the existing ledger; retain both API error branches",
    "internal/api/secrets_init_recovery_lock_test.go": "exercise real lock settlement, release faults, reentry, acquisition refusal and panic",
    "internal/api/supervisor_intent_lock_ownership_test.go": "remove only the raw-flock owner that now delegates to the existing ledger",
}

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the task's fixed Windows work root")
    raw = (ROOT / "qualify_go.py").read_bytes()
    if hashlib.sha256(raw).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    basis_raw = q.own(BASIS_PLAN).read_bytes()
    if q.sha(basis_raw) != BASIS_SHA:
        raise RuntimeError("Prior exact qualification plan changed")
    basis = json.loads(basis_raw)
    if basis["source_directory"] != "candidate-next-a1-scheduler-20261123-v1":
        raise RuntimeError("Unexpected prior source")
    format_receipt = json.loads(q.own("evidence/format-continuation-20261123-57604a3a/receipt.json").read_bytes())
    format_check = json.loads(q.own("evidence/format-continuation-20261123-57604a3a/gofmt-check.receipt.json").read_bytes())
    if format_receipt["exit_code"] != 0 or format_receipt["timed_out"] or not format_receipt["settled"] or not format_check["oracle_pass"]:
        raise RuntimeError("Formatting did not settle successfully")
    incoming = []
    for pin in format_receipt["after"]:
        prefix = INPUTS + "/"
        if not pin["path"].startswith(prefix):
            raise RuntimeError("Unexpected formatted input")
        incoming.append({**pin, "path": pin["path"][len(prefix):]})
    if {p["path"] for p in incoming} != set(CHANGES) or len(incoming) != len(CHANGES):
        raise RuntimeError("Changed paths differ from the reviewed scope")
    current = {p["path"]: p for p in basis["source_files"]}
    if "internal/api/secrets_init_recovery_lock_test.go" in current:
        raise RuntimeError("New regression path is occupied")
    # The inventory change follows the producing code: no new or larger allowance.
    old_census = q.own(basis["source_directory"] + "/internal/api/supervisor_intent_lock_ownership_test.go").read_text(encoding="utf-8")
    new_census = q.own(INPUTS + "/internal/api/supervisor_intent_lock_ownership_test.go").read_text(encoding="utf-8")
    owner = '"internal/api/secrets_init_recovery.go:method:*secretsInitRecoveryOwner.locked":'
    before_lines = old_census.splitlines()
    if sum(owner in line for line in before_lines) != 1 or new_census.splitlines() != [line for line in before_lines if owner not in line]:
        raise RuntimeError("Raw-owner inventory changed outside the removed constructor")
    provenance = [{"path": p["path"], "before": current.get(p["path"]), "after": p, "reason": CHANGES[p["path"]]} for p in incoming]
    current.update({p["path"]: p for p in incoming})
    final = sorted(current.values(), key=lambda p: p["path"])
    evidence = q.own("evidence/" + PHASE)
    source = q.own(SOURCE)
    if evidence.exists() or source.exists():
        raise RuntimeError("Fresh materialization paths are occupied")
    before = q.check_files(basis["source_directory"], basis["source_files"], True)
    incoming_before = q.check_files(INPUTS, incoming, True)
    evidence.mkdir()
    receipt = {"phase": PHASE, "started_utc": q.now(), "completed": False,
        "base_manifest_sha256": BASIS_SHA, "source_before": before, "inputs_before": incoming_before,
        "exact_new_git_commit": None, "source_directory": SOURCE, "changed_files": provenance,
        "native_scheduler_operations": False, "child_processes": False}
    q.save(evidence / "receipt-initial.json", receipt)
    try:
        source.mkdir()
        for pin in final:
            path = pin["path"]
            origin = INPUTS if path in CHANGES else basis["source_directory"]
            content = q.own(origin + "/" + path).read_bytes()
            if len(content) != pin["bytes"] or q.sha(content) != pin["sha256"]:
                raise RuntimeError("Copy input changed: " + path)
            out = q.own(SOURCE + "/" + path)
            out.parent.mkdir(parents=True, exist_ok=True)
            with out.open("xb") as stream:
                stream.write(content)
        receipt["source_after"] = q.check_files(basis["source_directory"], basis["source_files"], True)
        receipt["inputs_after"] = q.check_files(INPUTS, incoming, True)
        receipt["result"] = q.check_files(SOURCE, final, True)
        if receipt["source_before"] != receipt["source_after"] or receipt["inputs_before"] != receipt["inputs_after"]:
            raise RuntimeError("Preparation input changed")
        q.save(evidence / "source-inventory.json", {"source_files": final, "summary": receipt["result"], "exact_new_git_commit": None})
        q.save(evidence / "provenance.json", {"basis_manifest_sha256": BASIS_SHA, "changes": provenance})
        prefix = ["test", "-tags=test_state_path_env", "-race", "-count=1", "-timeout=180s", "-json"]
        def test(label, pattern, roots):
            return {"label": label, "tool": "go", "args": [*prefix, "-run", pattern, "./internal/api"],
                    "timeout_seconds": 240, "expected_exit_code": 0, "required_tests": {"pass": roots + ["PACKAGE:mcp-local-hub/internal/api"]}}
        plans = {
            "b1-continuation-20261123-57604a3a": [test("recovery-release-and-regression", "^(TestSecretsInitRecoveryLock.*|TestSecretsInit_Recovery.*|TestSupervisorIntentLockOwnership.*|TestReleaseAndJoinAppliedSettlementMatrix)$", ["TestSecretsInitRecoveryLockSettlement", "TestSecretsInitRecoveryLockAcquireFailure", "TestSecretsInitRecoveryLockReleasesOnPanic", "TestSupervisorIntentLockOwnershipProductionInventory", "TestSecretsInit_RecoveryProducerPersistenceFailures"])],
            "a1-continuation-20261123-57604a3a": [
                test("error-and-context-origins", "^(TestWeeklyTypedLocalLiteralOrigins|TestWeeklyTypedContextOrigins|TestWeeklyTypedCallGraphResolution|TestWeeklyTypedExportXMLBoundary|TestWeeklyTypedErrorOrigins|TestWeeklyTypedImportedErrorOrigins|TestWeeklyTypedNativeErrorContracts|TestWeeklyTypedNativeErrorFormatting)$", ["TestWeeklyTypedContextOrigins", "TestWeeklyTypedErrorOrigins", "TestWeeklyTypedImportedErrorOrigins", "TestWeeklyTypedNativeErrorContracts", "TestWeeklyTypedNativeErrorFormatting"]),
                test("production-lock-order", "^TestWeeklyRefreshLockOrderInventory$", ["TestWeeklyRefreshLockOrderInventory"])],
            "build-continuation-20261123-57604a3a": [
                {"label": "composition-build", "tool": "go", "args": ["build", "./..."], "timeout_seconds": 300, "expected_exit_code": 0},
                {"label": "composition-vet", "tool": "go", "args": ["vet", "./..."], "timeout_seconds": 300, "expected_exit_code": 0}],
        }
        plan_results = []
        for phase, commands in plans.items():
            plan = {**basis, "phase": phase, "source_directory": SOURCE, "source_files": final,
                    "inputs_directory": INPUTS, "input_files": incoming, "commands": commands}
            path = q.own("plans/" + phase + ".json")
            q.save(path, plan)
            plan_results.append({"path": path.relative_to(ROOT).as_posix(), "sha256": q.sha(path.read_bytes())})
        receipt["qualification_plans"] = plan_results
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(evidence / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
