"""Read frozen inputs and emit architecture publication qualification only."""
from __future__ import annotations

import collections
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import zipfile

import yaml


ROOT = Path(__file__).resolve().parent
RECEIVED = ROOT.parent / "mcphub-p0/verification/received"
OUT = ROOT / "publication"
MASTER = "75dbc6406123e22468f168b861d5e0622c9d5769"
COMMIT = "8a13085cbae24e18c2d7c2918b0241ab743dc729"
TREE = "37c5071d505d38f15cbf8d9c227ad10014c08395"
DAY = dt.date(2026, 11, 21)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def blocks(raw: bytes) -> tuple[bytes, dict[str, bytes]]:
    starts = list(re.finditer(rb"(?m)^    - fingerprint: ([0-9a-f]{64})\n", raw))
    assert starts
    parsed = {}
    for i, match in enumerate(starts):
        key = match.group(1).decode()
        assert key not in parsed
        end = starts[i + 1].start() if i + 1 < len(starts) else len(raw)
        parsed[key] = raw[match.start():end]
    return raw[:starts[0].start()], parsed


def fp(entry: dict) -> str:
    evidence = entry.get("evidence", "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if entry["kind"] == "file_budget":
        if evidence.startswith("production_"):
            evidence = "production_line_count"
        elif evidence.startswith("test_"):
            evidence = "test_line_count"
    loc = entry["location"]
    return sha("\0".join([entry["kind"], loc["path"], loc.get("symbol", ""), evidence]).encode())


def comparison(current: dict, baseline: dict) -> dict:
    new = sorted(set(current) - set(baseline))
    stale = sorted(set(baseline) - set(current))
    grown = sorted(key for key in set(current) & set(baseline)
                   if current[key].get("metric", 0) > baseline[key].get("max_metric", 0))
    workers = sorted(key for key in new if current[key]["kind"] == "worker")
    expired = sorted(key for key, e in baseline.items() if dt.date.fromisoformat(e["remove_by"]) < DAY)
    unowned = sorted(key for key, e in baseline.items()
                     if any(not str(e.get(k, "")).strip() for k in ["owner", "work_package", "reason", "remove_by"])
                     or key in current and current[key].get("metric", 0) > 0 and e.get("max_metric", 0) <= 0)
    return {"New": new, "Stale": stale, "Grown": grown, "workers": workers, "expired": expired, "unowned": unowned}


def terminal_command(z: zipfile.ZipFile, path: str) -> dict:
    raw = z.read(path)
    d = json.loads(raw)
    before, after = d["source_before"], d["source_after"]
    assert before == after
    assert before["head"] == COMMIT and before["tree"] == TREE
    assert before["materialized"] and not before["staged"] and not before["status"]
    assert d["settled"] and not d["timed_out"]
    return {"archive_entry": path, "receipt_sha256": sha(raw),
            **{key: d[key] for key in ["label", "executable", "args", "cwd", "started_utc", "finished_utc",
                                      "exit_code", "seconds", "settled", "timed_out", "direct_timeout_seconds",
                                      "whole_process_tree_deadline_enforced", "stdout", "stderr"]},
            "source_head": before["head"], "source_tree": before["tree"],
            "source_clean_before_and_after": True}


candidate_manifest_raw = (ROOT / "candidate/manifest.json").read_bytes()
candidate_manifest = json.loads(candidate_manifest_raw)
remote = json.loads((ROOT / "physical-verification-source.json").read_text(encoding="utf-8"))
assert remote["commit"]["sha"] == COMMIT
assert remote["commit"]["tree"]["sha"] == TREE
assert [p["sha"] for p in remote["commit"]["parents"]] == [MASTER]
assert remote["tree"]["sha"] == TREE and not remote["tree"]["truncated"]
remote_changes = {f["path"]: f for f in remote["changed_files"]}
files = candidate_manifest["files"]
assert len(files) == len(remote_changes) == 4
assert {f["path"] for f in files} == set(remote_changes)
for f in files:
    source = (ROOT / "source" / f["path"]).read_bytes()
    candidate = (ROOT / "candidate" / f["path"]).read_bytes()
    assert sha(source) == f["source_sha256"] and blob(source) == f["source_git_blob"]
    assert sha(candidate) == f["candidate_sha256"] and blob(candidate) == f["candidate_git_blob"]
    assert remote_changes[f["path"]]["sha"] == f["candidate_git_blob"]
    assert remote_changes[f["path"]]["status"] == "modified"

source_raw = (ROOT / "source/architecture/baseline.yaml").read_bytes()
candidate_raw = (ROOT / "candidate/architecture/baseline.yaml").read_bytes()
source_yaml, candidate_yaml = yaml.safe_load(source_raw), yaml.safe_load(candidate_raw)
source_entries = {e["fingerprint"]: e for e in source_yaml["entries"]}
candidate_entries = {e["fingerprint"]: e for e in candidate_yaml["entries"]}
source_header, source_blocks = blocks(source_raw)
candidate_header, candidate_blocks = blocks(candidate_raw)
assert len(source_entries) == len(source_blocks) == 2411
assert len(candidate_entries) == len(candidate_blocks) == 2410
assert source_header == candidate_header
assert source_yaml["generated_from"] == candidate_yaml["generated_from"]
assert source_yaml["schema_version"] == candidate_yaml["schema_version"]
assert all(fp(e) == key for key, e in candidate_entries.items())

delta = candidate_manifest["baseline_delta"]
migrations = delta["changed"]
assert len(migrations) == 102 and len(delta["deleted"]) == 1
old_keys = {e["old"]["fingerprint"] for e in migrations}
new_keys = {e["new"]["fingerprint"] for e in migrations}
removed_key = delta["deleted"][0]["entry"]["fingerprint"]
assert removed_key == "01e4b2a59c6e741b82a920b31824c9121d486c2025516d21d383f6b65e4f6e71"
assert set(source_entries) - set(candidate_entries) == old_keys | {removed_key}
assert set(candidate_entries) - set(source_entries) == new_keys
unchanged = sorted(set(source_entries) & set(candidate_entries))
assert len(unchanged) == 2308
for key in unchanged:
    assert source_entries[key] == candidate_entries[key]
    assert source_blocks[key] == candidate_blocks[key]
aggregate = sha("".join(key + " " + sha(source_blocks[key]) + "\n" for key in unchanged).encode())
assert aggregate == delta["unchanged_others"]["aggregate_sha256_before_and_after"]
for row in migrations:
    old, new = row["old"], row["new"]
    assert source_entries[old["fingerprint"]] == old
    assert candidate_entries[new["fingerprint"]] == new
    assert old.get("max_metric") == new.get("max_metric")
    assert old["remove_by"] == new["remove_by"]
    assert new.get("metric", 0) <= old.get("max_metric", 0)
    assert new["owner"] == "mcp-runtime" and new["work_package"] == "WP-11E"
    assert sha(source_blocks[old["fingerprint"]]) == row["old_block_sha256"]
    assert sha(candidate_blocks[new["fingerprint"]]) == row["new_block_sha256"]

comment = candidate_manifest["comment_delta"]
old_go = (ROOT / "source" / comment["path"]).read_bytes()
new_go = (ROOT / "candidate" / comment["path"]).read_bytes()
assert old_go.count(comment["old"].encode()) == 1
assert old_go.replace(comment["old"].encode(), comment["new"].encode()) == new_go
assert old_go.count(b"\n") == 1800 and new_go.count(b"\n") == 1799
original_owners = yaml.safe_load((ROOT / "source/architecture/owners.yaml").read_bytes())
updated_owners = yaml.safe_load((ROOT / "candidate/architecture/owners.yaml").read_bytes())
restored_owners = copy.deepcopy(updated_owners)
binary_rule = restored_owners["rules"].pop(1)
assert binary_rule["globs"] == ["internal/binaryadmission/**"]
assert binary_rule["owner"] == "lifecycle-runtime" and binary_rule["work_package"] == "WP-11C"
for rule in restored_owners["rules"]:
    if rule["owner"] == "mcp-runtime":
        rule["globs"].remove("internal/mcproute/**")
assert restored_owners == original_owners
original_policy = yaml.safe_load((ROOT / "source/architecture/policy.yaml").read_bytes())
updated_policy = yaml.safe_load((ROOT / "candidate/architecture/policy.yaml").read_bytes())
restored_policy = copy.deepcopy(updated_policy)
for glob in ["internal/binaryadmission/**", "internal/mcproute/**"]:
    restored_policy["import_rules"][0]["from"].remove(glob)
assert restored_policy == original_policy
assert updated_policy["import_rules"][0]["deny"] == ["internal/app/**", "internal/cli/**", "internal/gui/**"]
assert not yaml.safe_load((ROOT / "source/architecture/workers.yaml").read_bytes()).get("entries")

base_scan_raw = (RECEIVED / "arch-base-scan.json").read_bytes()
scan_raw = (RECEIVED / "arch-candidate-scan.json").read_bytes()
assert sha(base_scan_raw) == candidate_manifest["source_scan"]["sha256"]
base_scan, scan = json.loads(base_scan_raw), json.loads(scan_raw)
base_current = {v["fingerprint"]: v for v in base_scan["violations"]}
current = {v["fingerprint"]: v for v in scan["violations"]}
assert len(base_current) == len(current) == len(scan["violations"]) == 2671
assert set(base_current) == set(current)
predicted = copy.deepcopy(base_current)
comment_last_line = comment["changed_original_comment_lines"][1]
for v in predicted.values():
    if v["location"]["path"] != comment["path"]:
        continue
    if v["location"].get("line", 0) > comment_last_line:
        v["location"]["line"] -= 1
    if v["kind"] == "file_budget":
        assert v["metric"] == 1800
        v["metric"] = 1799
        v["message"] = "file has 1799 lines and exceeds production_hard_lines"
assert predicted == current
for row in migrations:
    v = current[row["new"]["fingerprint"]]
    assert all(row["new"][k] == value for k, value in v.items())
assert removed_key not in current
deleted = delta["deleted"][0]
assert source_entries[removed_key] == deleted["entry"]
assert sha(source_blocks[removed_key]) == deleted["source_block_sha256"]
for f in deleted["proof"]["remaining_files"]:
    b = (ROOT / "source" / f["path"]).read_bytes()
    assert blob(b) == f["git_blob"] and b.count(b"\n") == f["lines"]
    assert not any(v["kind"] == "file_budget" and v["location"]["path"] == f["path"] for v in current.values())

actual = comparison(current, candidate_entries)
base_actual = comparison(base_current, source_entries)
counts = {k: len(v) for k, v in actual.items()}
assert counts == candidate_manifest["expected_residual"]["counts"]
for kind in ["New", "Stale", "Grown", "workers"]:
    assert actual[kind] == candidate_manifest["expected_residual"][kind + "_fingerprints"]
assert actual["Grown"] == base_actual["Grown"]
assert all(current[key] == base_current[key] for key in actual["Grown"])

archive_path = RECEIVED / "architecture-evidence.zip"
archive_raw = archive_path.read_bytes()
assert len(archive_raw) == 770237
assert sha(archive_raw) == "ffb6130b84d4e1c5f6ea3a2f91d9442aba3d28cd62fc784ef727d4d2c1db547c"
with zipfile.ZipFile(archive_path) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 662
    manifest_raw = z.read("MANIFEST.json")
    member_manifest = json.loads(manifest_raw)["files"]
    assert len(member_manifest) == 661
    assert {row["path"] for row in member_manifest} == set(names) - {"MANIFEST.json"}
    for row in member_manifest:
        b = z.read(row["path"])
        assert len(b) == row["bytes"] and sha(b) == row["sha256"]
    assert z.read("candidate/full-scan.stdout.log") == scan_raw
    assert z.read("master/arch-base-scan.stdout.log") == base_scan_raw
    for name in ["candidate/overlay.json", "candidate-build-vet/overlay.json", "master/overlay.json"]:
        assert json.loads(z.read(name)) == {"Replace": {}}
    candidate_wrapper = json.loads(z.read("candidate/receipt.json"))
    build_wrapper = json.loads(z.read("candidate-build-vet/receipt.json"))
    assert candidate_wrapper["state"] == "failed" and not candidate_wrapper["completed"]
    assert candidate_wrapper["error"] == "Qualification selected a skipped test"
    assert build_wrapper["state"] == "complete" and build_wrapper["completed"]
    commands = [terminal_command(z, p) for p in [
        "candidate/gofmt-check.receipt.json", "candidate/full-scan.receipt.json",
        "candidate/full-verify.receipt.json", "candidate/arch-package-tests.receipt.json",
        "candidate-build-vet/full-build.receipt.json", "candidate-build-vet/full-vet.receipt.json"]]
    assert [c["exit_code"] for c in commands] == [0, 0, 1, 0, 0, 0]
    verify_stderr = z.read("candidate/full-verify.stderr.log").decode()
    assert "expired=0 grown=42 new=389 stale=128 unowned=0 workers=72" in verify_stderr
    events = [json.loads(line) for line in z.read("candidate/arch-package-tests.stdout.log").splitlines() if line.strip()]
    all_events = collections.Counter(e["Action"] for e in events)
    test_events = collections.Counter(e["Action"] for e in events if e.get("Test"))
    skip_events = [e for e in events if e["Action"] == "skip"]
    assert all_events["pass"] == 280 and all_events["fail"] == 0 and all_events["skip"] == 1
    assert test_events["pass"] == 278 and test_events["fail"] == 0 and test_events["skip"] == 1
    assert [e["Test"] for e in skip_events] == ["TestUnixBackslashPathRemainsDistinct"]
    package_events = [e for e in events if not e.get("Test") and e["Action"] in ["pass", "fail", "skip"]]
    assert len(package_events) == 2 and all(e["Action"] == "pass" for e in package_events)
    wrappers = {}
    for name, d in [("architecture_qualification", candidate_wrapper), ("build_vet", build_wrapper)]:
        wrappers[name] = {key: d.get(key) for key in ["state", "completed", "error_type", "error", "overlay_paths",
            "whole_process_tree_deadline_enforced", "direct_child_wait_bounded", "process_tree_settlement_observed",
            "native_task_operations", "native_task_operations_basis"]}

result = {
    "schema_version": 1,
    "status": "DRAFT_NOT_GREEN_PHYSICAL_MIGRATION_CONFIRMED",
    "qualification_date_utc": str(DAY),
    "repository": "applicate2628/mcp-local-hub",
    "source": {
        "base_commit": MASTER, "candidate_commit": COMMIT, "candidate_tree": TREE,
        "parent_verified_from_git_commit_object": MASTER,
        "commit_url": "https://github.com/applicate2628/mcp-local-hub/commit/" + COMMIT,
        "exactly_four_modified_source_paths": True,
        "physical_candidate_tree": True,
        "compiler_overlay_replace": {},
        "overlay_note": "Commands supplied -overlay with empty Replace; AST scan read the materialized candidate cwd/--root.",
        "shallow_receipt_note": "Local source receipts have parents=[]; parent proof comes from the immutable GitHub commit object.",
        "candidate_manifest_sha256": sha(candidate_manifest_raw),
        "files": files,
    },
    "baseline_invariants": {
        "before_entries": 2411, "after_entries": 2410,
        "migrated_entries": 102, "deleted_entries": 1, "unrelated_added_entries": 0,
        "unchanged_entries": 2308,
        "unchanged_blocks_byte_identical": True,
        "unchanged_blocks_aggregate_sha256": aggregate,
        "unchanged_blocks_aggregate_encoding": delta["unchanged_others"]["aggregate_encoding"],
        "header_byte_identical": True, "header_sha256": sha(source_header),
        "generated_from_before_and_after": source_yaml["generated_from"],
        "all_original_remove_by_preserved": True, "all_original_max_metric_preserved": True,
        "all_migrations_within_original_caps": True, "all_fingerprints_recomputed_valid": True,
        "baseline_regenerated": False,
        "migrated_worker_entries": sum(row["new"]["kind"] == "worker" for row in migrations),
        "worker_registry_modified": False, "new_worker_lifecycle_contracts_claimed": False,
        "migration_pairs": [
            {"old_fingerprint": row["old"]["fingerprint"], "new_fingerprint": row["new"]["fingerprint"],
             "kind": row["new"]["kind"], "old_path": row["old"]["location"]["path"],
             "new_path": row["new"]["location"]["path"],
             "max_metric_preserved": row["new"].get("max_metric"), "remove_by_preserved": row["new"]["remove_by"],
             "old_block_sha256": row["old_block_sha256"], "new_block_sha256": row["new_block_sha256"]}
            for row in migrations],
        "deleted": deleted,
    },
    "other_changes": {
        "mcproute_owner": {"owner": "mcp-runtime", "work_package": "WP-11E"},
        "binaryadmission_owner": {"owner": "lifecycle-runtime", "work_package": "WP-11C"},
        "new_import_from_globs": ["internal/binaryadmission/**", "internal/mcproute/**"],
        "unchanged_import_deny": ["internal/app/**", "internal/cli/**", "internal/gui/**"],
        "other_owner_rules_and_policy_unchanged": True,
        "lifecycle_comment_only": {"path": comment["path"], "before_lines": 1800, "after_lines": 1799,
                                  "runtime_code_unchanged": True, "metric_cap_raised": False},
    },
    "scan_comparison": {
        "base_scan_sha256": sha(base_scan_raw), "candidate_scan_sha256": sha(scan_raw),
        "candidate_scan_bytes": len(scan_raw), "candidate_violation_count": len(current),
        "same_full_violation_fingerprint_set_as_master": True,
        "all_2671_actual_records_equal_prediction": True,
        "only_scan_record_differences": "One lifecycle file-budget metric/message 1800 to 1799 and later line numbers shifted by one; no identity changes.",
        "before": {k: len(v) for k, v in base_actual.items()}, "after": counts,
        "exact_residual_fingerprint_sets_match_prediction": True,
        "all_42_growth_records_unchanged": True,
        "residual_set_sha256": {k: sha(("\n".join(v) + "\n").encode()) for k, v in actual.items()},
        "new_by_kind": dict(sorted(collections.Counter(current[k]["kind"] for k in actual["New"]).items())),
        "new_by_package": dict(collections.Counter("/".join(current[k]["location"]["path"].split("/")[:2]) for k in actual["New"]).most_common()),
        "worker_count_is_subset_of_new_not_additional": True,
        "verify_exit_code": 1,
    },
    "evidence": {
        "archive_filename": archive_path.name, "archive_bytes": len(archive_raw), "archive_sha256": sha(archive_raw),
        "archive_entries": 662, "manifest_entries": 661, "all_manifest_sizes_and_sha256_verified": True,
        "manifest_sha256": sha(manifest_raw), "raw_scans_equal_archive_members": True,
        "commands": commands, "wrappers": wrappers,
        "race_tests": {"go_exit_code": 0, "pass_events_total": 280, "test_pass_events": 278,
                       "package_pass_events": 2, "fail_events": 0, "skip_events": 1,
                       "skipped_test": "TestUnixBackslashPathRemainsDistinct",
                       "qualification_wrapper_status": "FAILED", "package_terminal_events": package_events},
    },
    "claim_limits": [
        "The full architecture verification remains exit 1; 389 New, 128 Stale, 42 Grown, and 72 unclassified workers remain.",
        "The architecture qualification wrapper remains FAILED because its selected test set included one SKIP.",
        "The successful build and vet phase does not replace the failed qualification wrapper or full test gates.",
        "The Unix-only backslash test did not execute on this Windows run; no Unix or cross-platform execution claim follows.",
        "The runner bounded direct-child waits but did not enforce a whole-process-tree deadline or observe process-tree settlement.",
        "Empty worker registry and six legacy baseline migrations do not prove new cancellation/join/timeout ownership contracts.",
        "Counts apply only to master plus these four source files; preservation checkpoint 858812988833a84368c60fba1540ae601155fa71 and runtime helper changes need separate composed-tree qualification.",
        "This reviewer inspected stored evidence only and did not run Go, native commands, remote changes, publication, CI, or dependency installation.",
    ],
}
OUT.mkdir(exist_ok=True)
(OUT / "qualification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"status": result["status"], "counts": counts,
                  "migrations": len(migrations), "unchanged_blocks": len(unchanged),
                  "all_full_scan_records_match": True, "archive_entries_verified": 661,
                  "qualification_sha256": sha((OUT / "qualification.json").read_bytes())}, indent=2))
