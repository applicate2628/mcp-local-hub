# R24: Rust PR source and consolidation audit

## Contents

1. [Result](#result)
2. [Exact branches and dependencies](#exact-branches-and-dependencies)
3. [Confirmed documentation correction](#confirmed-documentation-correction)
4. [Consolidation decision](#consolidation-decision)
5. [Source review and evidence limits](#source-review-and-evidence-limits)
6. [Verification and handoff](#verification-and-handoff)
7. [Terms and abbreviations](#terms-and-abbreviations)

## Result

One bounded documentation correction is prepared for **#631**. It restores the
native read-only query qualification paragraph already present in #644:
30 unit, 43 integration and three compile-fail checks, 76 in debug, with the
explicit statement that the complete native release suite was not repeated for
that increment. The candidate adds two lines and removes none.

Keep **#625, #644, #631 and #627 as separate scopes**. No duplicate PR closure is
supported by this audit. No new confirmed executable-code defect was found in
the focused reviewed paths. No build, test, installation, dependency download,
manual continuous-integration dispatch or published mutation was performed.

## Exact branches and dependencies

The four current heads were read from PR metadata and independently matched
against live Git references on 21 November 2026. All remain open drafts.

**Table 1. Verified heads and current review bases.**

| PR | Head | Base branch | Distinct responsibility |
|---|---|---|---|
| #625 | `287a7772a4be75ed9fb2f9ba1feb68cf035ed907` | `master` | Native process, thread and Job ownership; creation, context, settlement |
| #644 | `1cf5754b81c850a3569be269642b49605895eeb2` | #625 branch | Original-process identity observations and borrowed read-only view |
| #631 | `2eb7c114103ef5c60939cd114110ebe667901166` | #644 branch | C interface and Go consumer; copied observations and explicit lifecycle |
| #627 | `b827398ef127a1556b7b2bdcdcec7fe03fa6651d` | `master` | Independent anchored, verified file reader |

Current `master` is `a7d92d2852c4f6eb8afb0569ef76a545e38aacf7`.
The PR response's recorded base SHA is not substituted for the live base reference.

**Table 2. Commit ancestry and source continuity.**

| Comparison | Git result | Common ancestor | Meaning |
|---|---|---|---|
| Current #625 → #644 | Diverged, eight ahead / one behind | `c5672f49f65713c7555e8841e46de75b045da5f8` | #625's last commit changes README only |
| Current #644 → #631 | Diverged, 29 ahead / one behind | `71891067d0c24387ba873a3e4276b0462ae365ae` | #644's last commit changes README only |
| Current #625 → #631 | Diverged, 36 ahead / one behind | `c5672f49f65713c7555e8841e46de75b045da5f8` | Native observations and foreign boundary are distinct incremental work |

The 14 shared native source, test and manifest files other than README are
byte-identical between #644 and the prepared #631 source. Git metadata confirms
that #631 head has parent `ebfa4ef32b57cfa022acdcfcb4a2745f32b815c6` and modifies
only `experiments/rust-process-owner/README.md`. Thus those code comparisons
also apply to the current #631 head. The current README was separately fetched
and matched to Git blob `57ad9d27dcc1154ec128e16e8faf43689997e778`.

## Confirmed documentation correction

**RUST-DOC-01 — P3, documentation coverage gap.**

Location:
[`experiments/rust-process-owner/README.md:147–155` at #631](https://github.com/applicate2628/mcp-local-hub/blob/2eb7c114103ef5c60939cd114110ebe667901166/experiments/rust-process-owner/README.md#L147-L155).

The README describes the current `process_view()` interface, but its evidence
section moves directly from the historical TokenUser result of 71 checks in
debug and release to the stdio table. It omits the later query qualification and
its explicit release limitation. A reader using this section alone can miss
which native interface the debug/release result covers. The underlying report
and foreign-interface README already retain the correct distinction.

The minimal correction copies the existing
[#644 paragraph at line 153](https://github.com/applicate2628/mcp-local-hub/blob/1cf5754b81c850a3569be269642b49605895eeb2/experiments/rust-process-owner/README.md#L153)
without modifying the older results. The native
[query report at #631](https://github.com/applicate2628/mcp-local-hub/blob/2eb7c114103ef5c60939cd114110ebe667901166/experiments/rust-process-owner/verification/query-2026-11-15/RESULTS.md#L38-L57)
explicitly records both 76 debug checks and no complete native release run for
that increment. The report's Git blob is the same at both heads:
`90262049507f10d1782a508dc72632824fa235d0`.

Candidate files are under `candidates/631/`:

- `README.original.md`: exact current #631 README bytes.
- `README.candidate.md`: one added paragraph and its blank line.
- `README.diff`: reviewable unified diff.
- `../manifest.json` and `../self-review.json`: original/candidate hashes and
  focused static checks.

**Corrected preliminary hypothesis.** An early message inferred that the two
descendants lacked #625's close-failure clarification because they lacked its
last commit. Exact text checks contradicted that inference: both current
READMEs already have the corrected sentence at line 24. The guarded candidate
generation stopped before writing any candidate. That item is retracted, and
no #644 edit is prepared. Commit ancestry alone does not prove missing content.

## Consolidation decision

The native crate owns Windows resources once. Identity observation extends
that owner; it does not create a second supervisor. The foreign boundary then
depends on that same crate through
[`ffi/Cargo.toml:10–11`](https://github.com/applicate2628/mcp-local-hub/blob/2eb7c114103ef5c60939cd114110ebe667901166/experiments/rust-process-owner/ffi/Cargo.toml#L10-L11).
Its Go adapter owns foreign-call serialization, copied values and library
lifetime. The file reader uses a separate filesystem contract and has no
process-owner dependency.

**Table 3. Incremental size supports retaining responsibility boundaries.**

| Increment | Code, tests and manifests | Documentation | Verification assets |
|---|---:|---:|---:|
| #644 beyond its common ancestor with #625 | Six files, +1,175 / −15 lines | One file, +49 / −11 | 21 files, +4,709 |
| #631 beyond its common ancestor with #644 | 32 files, +6,873 / −0 lines | Two files, +492 / −1 | 27 files, +6,320 |

The three-dot comparison of #631 with current master contains **96 files and
20,468 added lines**, all under `experiments/rust-process-owner/`. Its common
ancestor is `17bc78fc602efa204a74596409c939a3bf1ddc42`; #631 is 42 commits ahead
and 12 behind. These are comparison facts, not evidence that the branch has
integrated the 12 later master commits.

Flattening the stack would expose that whole change in a single review while
discarding the useful distinction between native ownership, observation and
foreign consumption. Closing #625 or #644 merely because code appears in a
descendant would also remove the intended incremental review base.
The README clarification can be reconciled directly without either action.

The dated verification files and archives are provenance. Similar names or
repeated test totals do not establish duplicate bytes or dispensability.
This audit provides no deletion or archive-transfer proof for them.

## Source review and evidence limits

The focused trace followed these boundaries:

- Native creation validates inputs before acquisition, retains original handles
  after a successful create, and stores a failed initial creation-time query
  in the returned owner. See `src/windows.rs:326–471`.
- Read-only views borrow the original process and Job; admission consumption,
  stop attempts and terminal cleanup remain distinct. See
  `src/windows.rs:481–559` and `562–675`.
- Token observation keeps query and close failures separately and does not
  return a successful SID after failed token close. See
  `src/token_user.rs:68–107`.
- The foreign interface reuses native creation and settlement. Go preserves a
  transferred owner even when result metadata fails, and preserves completed
  deallocation independently of response validation. See
  `ffi/go/bridge_windows.go:338–348` and `390–410`.
- The query receiver checks schema, callback count, diagnostic process identity,
  known-exit/wait consistency and absence of settlement claims. See
  `ffi/go/bridge_windows.go:479–529`.
- The independent file reader anchors each component, enforces the byte cap
  during reads as well as at initial metadata inspection, and retains cleanup
  failures separately. See `rust-anchored-read/src/windows.rs:45–183`.

All paths are under `experiments/`; exact commits and links for each reviewed
file are retained in `AUDIT.json`. The review also read the native launch
context, ordinary foreign exports, Go admission/identity decoding, standard
stream copies, outcome validation and cancelable observation implementation.
Selected failure/query tests and their reports were inspected; this does not
claim every fixture or archive was reread end-to-end.

The previous R23 runtime evidence remains bounded to its recorded sources:
#625 `287a7772`, #644 `1cf5754b`, and #631 `ebfa4ef3`. #627 source was
prepared but not executed in R23. This audit does not repeat those runs or
upgrade them into installed-product, complete foreign-call, Unix or release
qualification. It imports no parallel wait/close work.

## Verification and handoff

The local preparation verified 84 public source-text blobs, 825,869 bytes,
against their immutable Git blob identifiers. Current head metadata, live
references and last-commit file lists were checked independently. The query
report link and its bytes were checked at both parent and child heads.

Self-review confirmed that the candidate differs only by the selected
paragraph and blank line, retains the current identity-protocol wording,
introduces no new execution claim and changes no source/test/manifest byte.
There is no reason to repeat native runtime tests for this documentation delta.

The canonical Orchestrarium governance was read at Git blob
`88810caa9134c201677bb09818ec2bc63fca49a8`. The four exact branches share root
`CLAUDE.md` blob `2bafe12915c29b935c6e9280c9a23817ba753286`.
Exact-path reads and complete recursive trees found no applicable root or
experiment `AGENTS.md`, or nested `CLAUDE.md`.
Relevant PR-verification, publication and process-ownership instructions were
applied within the current read-only authorization.

Five relevant skills were applied: Architecture Review, Source-Driven
Development, Code Review and Quality, Ponytail Code Simplification, and MCP
Boundary. Their concrete use was separating observation from authority,
checking current source provenance, preserving error/ownership contracts,
rejecting a larger unhelpful consolidation, and limiting evidence claims.

Root owns independent review and any publication. Originals, candidate,
audit and source snapshots remain retained for that verification. No branch,
PR state, product runtime or installed artifact has been changed.

## Terms and abbreviations

PR — pull request, a proposed change for review. ABI — application binary
interface, the memory layouts and calling conventions shared by languages.
FFI — foreign function interface. DLL — dynamic-link library. SID — Windows
security identifier. PID — process identifier. Job — the retained Windows
process-group resource. stdio — standard input, output and error streams.
A compile-fail check expects the compiler to reject an invalid use.
Debug and release are separate Rust build profiles.

