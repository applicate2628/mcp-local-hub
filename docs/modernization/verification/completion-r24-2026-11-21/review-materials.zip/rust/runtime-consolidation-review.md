# R24 independent source review: runner and #650 consolidation

**Result: no blocking defect found in the bounded source review below.** This was a nonauthoring review: no runner, build, test, product, scheduler or installation was executed, and no candidate source was edited. The subsequent review of all five frozen execution manifests is recorded below. This review does not certify any runtime outcome.

## Exact reviewed scope

| Item | Identity |
|---|---|
| `r24-audit/runtime/qualify_scope.py` | SHA-256 `7378f36331d692df4c35f3bee1176840c14d5efa853cdf48662fba756dbc2c27` |
| Reused capture owner | Remote `D:\dev\ChatGPT\mcp-r17-current-task-recovery-20261121\check_recovery.py`, all 552 lines read; wrapper requires SHA-256 `6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61` before import |
| #650 source → candidate tree | `686a54c0efbe9f99cb6ffa8d6480b289c6f465bf` → `712f175be713b1d27843942a31fadf8edd56e61a` |
| Imported #656 source | `5efac36d1e2b4be998fadfa4ccfed1a5da098cff` |

The four #650 candidate files independently matched both SHA-256 and Git blob identities in `candidate-pr-650/candidate-manifest.json`. The candidate tree changes exactly the connection close implementation and its new regression file: 338 added / 6 removed lines. Existing `relay_qualification_test.go` and `relay_qualification_transport_test.go` remain byte-identical to the #650 source head.

## Runner assessment

`qualify_scope.py:18,43–61,64–108` binds the wrapper, source snapshot, per-phase output and runtime directories to the new R24 root. The original module keeps its own read-only admission inputs; subclass paths are installed before `Runner.begin`. Import does not invoke its guarded main routine. The explicit child environment is applied before the first captured command. Temporary files, profiles, application-data directories, Go temporary work and the new build cache resolve beneath the R24 directory on D; the pre-existing module cache also resides under `D:\dev\ChatGPT`. Existing tools and Go installation on C are read inputs. No reviewed command explicitly targets C for output; this is configuration and source evidence, not operating-system write containment.

`qualify_scope.py:32–54,120–163,209–217` checks the capture-owner identity, wrapper and manifest pins, clean source commit/tree, original Git blobs, candidate SHA-256/blob identities and overlay bytes before/after the work. Exact source retrieval is separate from dependency acquisition. The retained environment has `GOPROXY=off`, `GOSUMDB=off`, `GOVCS=*:off`, `GOTOOLCHAIN=local`, `GOWORK=off`, and read-only module mode. Ambient fixture/child switches are excluded by the explicit allowlist.

Frozen owner `check_recovery.py:307–360,405–420,464–481` writes start/launch records and separate streams, retains partial results on failure, and uses the retained direct-child process handle for termination. The wrapper rejects timed-out, unsettled, capture/parser-error and unexpected-exit results. It requires a nonempty test oracle and rejects skipped positive tests (`qualify_scope.py:181–207`). The advertised limitation is accurate: it bounds direct-child waiting and does not establish descendant settlement or a whole-process-tree deadline. A timeout therefore cannot justify cleanup of unresolved runtime files.

## #650 lifecycle and selection assessment

`relay_qualification.go:238–294,315,453–455,468` retains each POST/DELETE request's owner, original deadline and cancellation while an in-flight dial remains counted. The close import does not alter that contract. At `621–676`, the close-completion channel belongs to the single original underlying Close; receiving it replaces the transient pending error with that call's actual result. New I/O is barred after closing begins; original I/O is separately received. Cancellation/expiry is checked after ready channels, so readiness cannot turn an invalid receive into success. Session closure remains cached and failed proof is not upgraded by a later retry (`440–455,537–540`; new regression `296–316`).

The source-inspected selection in `serena-qualification/focused-test-selection.json` includes all 11 #650 roots: 8 preserved and 3 imported. I read the three test files; none contains a skip or subprocess launch. Socket fixtures use owned TCP/IPv4 loopback connections and preserve the distinction between transport tests and successful protocol/native qualification. Build handoff selectors retain the stated 4 roots for #647 and 10 Windows roots for #643; no skip calls were found in their listed source files. Actual execution must still match these selected roots and expected repeat counts in its frozen command manifest.

**Limits:** initial synchronous `net.Conn.Close` and `http.Transport.CloseIdleConnections` are not made preemptible by a cleanup context. The import improves reception of an already-running original close; it does not prove a total cleanup deadline. No installed-product, native-child, full-suite, full published-head or successful protocol qualification is inferred from this review. No speculative defect is promoted to a blocker.

## Follow-up: five frozen execution manifests

**No blocker found in the actual command/selection manifests.** All five original commits resolve to the recorded source trees. For each scope, its complete Git tree difference is exactly the file set admitted by the manifest. All 13 overlay files match their recorded byte lengths, SHA-256 hashes and Git blobs, and independently match the corresponding candidate-tree contents. Original blobs, including genuinely absent new files, also match the original source trees. Every phase uses that same complete overlay set. The payload's wrapper is byte-identical to the reviewed wrapper above.

| Scope | Manifest SHA-256 | Required root passes by command |
|---|---|---|
| #647 | `431826a6009ae94972436c2ee1c7611e6e53900255dbc331791e55d04b15f2e1` | API default 4; state-path tag 4 |
| #643 | `cfdbfa663e4b37f9f687c313839ec745d0704debd9fcae95b5afa223c84af6e2` | API default 10; state-path tag 10 |
| #650 | `7de97512d559ef0d6ffa99e95073c2b1f990b7709ea7972450665e11b3747e8b` | daemon default 11; state-path tag 11 |
| #635 | `34f4e2fd7e7b770c534bf6a02ca55b0eb6c6e10e2f0984a3e184a8cc4496c750` | API default 1; state-path tag 1 |
| #637 | `0a69d4b5e7d5d12d1aeca4174233bd2493509183e97bda0349719de55991b793` | API default 1; state-path tag 1; publisher helpers default 3 |

The 11 test commands are exactly the source-inspected groups: anchored `-run` expressions contain the same names as `required_root_pass_counts`, each required once. Every command has `-race -json -count=1 -timeout=180s -parallel=4`, expected exit zero and a 900-second direct-child deadline. API and daemon groups run in default mode and with `-tags=test_state_path_env`; publisher option/environment helpers run only in default mode. The wrapper checks the root counters, rejects fail/skip events and rejects unsettled, timed-out or malformed results. This is **57 required top-level passes across commands**, not 57 distinct tests or all nested events. The index's #637 summary value 4 combines the default API and publisher groups; its tagged API command requires only 1, giving 5 passes for #637 overall. Actual per-command oracles are unambiguous.

`prepare` has no product/test commands: the previously reviewed wrapper fetches the exact source commit, checks out that snapshot and runs read-only `gofmt -l` on candidate files. Each `build-vet` phase contains exactly `go build -overlay {overlay} ./...` followed by `go vet -overlay {overlay} ./...`, each with a 900-second direct-child deadline and exit-zero requirement. These are compilation/static-analysis commands, not application, publisher-main, scheduler or installer execution.

The scope index pins all five manifest bytes and matches `payload-receipt.json`. The 62,197-byte ZIP has SHA-256 `385b37f3d1c601ccd91cf699e8936a6c0edd9fafc29c7389121cd82864180e8f`; all 20 distinct entries match the payload files byte-for-byte, and the Base64 transfer decodes to that exact ZIP. This establishes the local frozen transfer identity; remote readback and subsequent execution receipts remain separate evidence.
