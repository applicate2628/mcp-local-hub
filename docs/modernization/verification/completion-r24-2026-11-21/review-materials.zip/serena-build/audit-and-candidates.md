# Serena build/discovery: source audit and local consolidation candidates

## Contents

- [Result and limits](#result-and-limits)
- [Exact source inventory](#exact-source-inventory)
- [Candidate 647: build environment](#candidate-647-build-environment)
- [Candidate 643: owned-tree cleanup](#candidate-643-owned-tree-cleanup)
- [Inclusion and self-review](#inclusion-and-self-review)
- [Windows verification handoff](#windows-verification-handoff)
- [Material residual uncertainty](#material-residual-uncertainty)
- [Provenance and terminology](#provenance-and-terminology)

## Result and limits

Two local, single-parent candidates preserve the entire useful content of three donor pull requests (PRs):

1. Carry **#639 into #647**, the existing owner of the preparation build-environment projection.
2. Carry **#645 and #651 into #643**, the existing owner of bounded cleanup for a tree acquired by the original operation.

No new concrete defect was identified in the reviewed donor changes or in these two combinations. This is a source-review result, not native execution acceptance. No product test, package installation, product-spawned UV/Git/Python process, manual continuous-integration run, GitHub mutation, comment, review submission, branch publication or PR merge was performed in this lane. Donor closure is justified only after the receiving candidate is qualified, published and read back with its complete donor content.

**Keep #646 and #648 separate.** Interpreter selection belongs to preparation policy; the build-constraint file belongs to acquisition/install resource custody. Combining either with the selected candidates would widen the responsibility and its validation surface. No redundant live function or equivalent regression test was established in those PRs. Shared files alone are not proof of duplication.

## Exact source inventory

Table 1 records fresh GitHub metadata/full changed-file lists, downloaded source and live branch-ref observations. The source snapshot is non-atomic. All seven PRs were open drafts. All were independently based on `17bc78fc602efa204a74596409c939a3bf1ddc42`.

| PR | Published head | Responsibility | Files; additions/deletions | Disposition |
|---|---|---|---|---|
| [#639](https://github.com/applicate2628/mcp-local-hub/pull/639) | `98c4b54a69f2776fdabc2b8b8d19f09110e02a74` | Classify exact PYTHONUNBUFFERED as runtime-only before build resolution | 2; +69/−0 | Preserve completely in #647 candidate |
| [#643](https://github.com/applicate2628/mcp-local-hub/pull/643) | `527574928335142d95bc073c6ca4459fef9f9f90` | Fresh bounded cleanup-parent observation bound to original retained identity | 7; +459/−36 | Receiving cleanup candidate |
| [#645](https://github.com/applicate2628/mcp-local-hub/pull/645) | `98511ab9ea633b7e47e825396f002dc783c51d9f` | Native no-stream result is empty inventory, preserving cancellation/errors | 2; +124/−0 | Preserve completely in #643 candidate |
| [#646](https://github.com/applicate2628/mcp-local-hub/pull/646) | `1df32782e7ade719e1d7f8c6153b4455a6ea740a` | Prefer system Python while retaining managed fallback | 2; +5/−3 | Keep independent |
| [#647](https://github.com/applicate2628/mcp-local-hub/pull/647) | `6de482cdd09034f71b5e091cc9e385e229cd96a2` | Own fixed Windows executable/Git settings and bind their identity | 2; +186/−0 | Receiving environment candidate |
| [#648](https://github.com/applicate2628/mcp-local-hub/pull/648) | `fc4dc5c7145e4f4d709b91654ab4bc1fd7abe259` | Own fixed constraint bytes, retained native file handle and install-only use | 10; +505/−25 | Keep independent |
| [#651](https://github.com/applicate2628/mcp-local-hub/pull/651) | `01c08819cb0d3fc4fe2b9e11833e40de3c28c3d6` | Unlink nominated readonly entries without changing survivor attributes | 2; +162/−6 | Preserve completely in #643 candidate |

The live master was `a7d92d2852c4f6eb8afb0569ef76a545e38aacf7`. Its diff from the common base changes seven files outside Serena's API code. None of these PRs already contains another complete donor; there is no existing parent/child stack to rebase or close as redundant. The local candidates incorporate no unrelated master change.

## Candidate 647: build environment

- **Local commit:** `ac97c015bd7eb5262b657bae5e89cb5830c88e8d`
- **Only parent:** `6de482cdd09034f71b5e091cc9e385e229cd96a2`
- **Candidate tree:** `5e0192aec3522f3dd2f1f6110910cf3274fb0b38`
- **Original target tree:** `a332fbfe30ea19944e119e64398f39db90ac6faa`
- **Delta from target:** 2 files, +69/−0; aggregate PR against common base: 3 files, +255/−0.
- **Files:** `candidate-647-target-relative.patch`, `candidate-647.bundle`, `candidate-647/`.

The only new production change is the exact three-line #639 case at candidate `internal/api/serena_build_environment.go:309–311`. The original declaration source still filters runtime-only keys before resolving values (`serena_build_environment_source.go:30–40`). The fixed Windows PATHEXT and process-scoped Git fields from #647 remain unchanged. The original projection sorting and identity codec remain their sole owner.

The complete 66-line `serena_build_environment_python_test.go` is byte-identical to #639 (SHA-256 `64e862f0f2455047249429eb62c301c8255269dea57cd847216f19b0ad671e50`). No target test changed. The [Python 3.14 contract](https://docs.python.org/3.14/using/cmdline.html#envvar-PYTHONUNBUFFERED) identifies this variable as the unbuffered-output option; the [Git configuration contract](https://git-scm.com/docs/git-config#Documentation/git-config.txt-GIT_CONFIG_COUNT) supports the existing process-scoped fixed pair.

## Candidate 643: owned-tree cleanup

- **Local commit:** `e4371eb52f3aee5ac869861c20547e7b50cf3e28`
- **Only parent:** `527574928335142d95bc073c6ca4459fef9f9f90`
- **Candidate tree:** `b658184e7c7a421f973acf71f6309abb19f1b775`
- **Original target tree:** `d3b2757f30983120072826916f7a0e3b4d0da251`
- **Delta from target:** 3 files, +286/−6; aggregate PR against common base: 9 files, +745/−42.
- **Files:** `candidate-643-target-relative.patch`, `candidate-643.bundle`, `candidate-643/`.

This is the larger candidate, but all changes participate in the same cleanup operation. Most added lines are the original independent regression fixtures.

The #645 hunk at candidate `serena_owned_tree_windows.go:399–403` treats only `ERROR_HANDLE_EOF` from the stream query as no streams and returns any current context error. [Microsoft documents this no-stream result](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getfileinformationbyhandleex). Regular-file inventory still requires one default stream with matching size; named-stream refusal and other native errors remain.

The #651 changes at candidate `serena_owned_tree_windows.go:353–382` retain a removal-specific access choice and its published-reader refusal. All four production openEntry call sites were carried: inventory and both absence probes use `forRemoval=false`; the unlink traversal uses `true`. Only entry deletion uses `setSerenaOwnedTreeEntryDeleteOnClose`; root deletion and the shared secure-write helper remain distinct owners. The new primitive does not clear the shared inode's readonly attributes.

The #643 cleanup context remains captured at all four acquiring call sites; cleanup obtains a fresh parent observation, verifies strict protection, compares full parent identity and original namespace ownership, and preserves close failures. The source includes its latest comment correction about possible audit-log effects. There is no replacement of that original owner with a new path-based cleanup routine.

Both complete donor tests are byte-identical:

| Table 2. Preserved file | Source | SHA-256 |
|---|---|---|
| `serena_owned_tree_streams_windows_test.go` | #645 | `a2ba550535cc6d56e7972d450f8bba147271af146d2b2407040052ac162b9dc2` |
| `serena_owned_tree_delete_windows_test.go` | #651 | `8792ca17eb87dc4033753f210f4fe1b34a9ff7d5a4d0d3ed5701f76eb80056b3` |

## Inclusion and self-review

`inclusion-evidence.json` contains the source heads, complete filename inventories, per-file source Git blobs and SHA-256 values, full donor patch digests, candidate commit/tree/parent identities and per-file candidate digests.

Verification actually performed:

1. Git merge-base equals the declared common base for every audited source.
2. Git diff's complete file list equals the freshly fetched paginated GitHub list.
3. Every donor patch applies in full to the exact receiving target; no hand-edited hunk or dropped test.
4. Every complete donor reverse patch applies to the final receiving candidate.
5. In a private temporary Git index, reversing **all** donors reconstructs the original target's entire tree exactly. This proves the candidate has no unexplained delta beyond those donors.
6. Donor test bytes match the published source; target tests are unchanged; both candidate worktrees are clean.
7. `git diff --check` passes for both target-relative deltas.
8. Own review traced requirements, caller propagation, error/cancellation behavior, published-reader authority, resource closure, compatibility and complexity. All four openEntry callers use the intended mode. No new dependency or dormant wrapper was introduced.

An independent static review by the Serena qualification lane also found no consolidation-introduced defect in candidate #643 at `e4371eb52f3aee5ac869861c20547e7b50cf3e28`. It independently checked all four openEntry call sites, preserved parent binding and sticky close failures, native stream EOF/error behavior, unchanged target files and byte-identical donor tests. This is additional source review, not execution evidence; the peer likewise identified full tree lifecycle acceptance as untested.

The disposable proof indexes were moved to the lane's deterministic trash and verified absent at their original paths. They are not needed for recovery; the JSON records the resulting tree identities. Candidate sources, patches, bundles and required evidence remain outside trash.

## Windows verification handoff

The machine-readable entry point is **`windows-verification-manifest.json`**. It includes exact original/candidate Git blobs and SHA-256 values for every changed file, root names with file/line, expected Windows root counts, full selectors and TestMain notes.

### Environment candidate

Use the selector stored in the manifest. It has exactly four roots:

- `TestSerenaBuildEnvironment_CatalogUnbufferedIsRuntimeOnly`
- `TestSerenaBuildEnvironment_PythonDeclarationBoundary`
- `TestSerenaBuildEnvironmentWindowsExecutablePolicy`
- `TestSerenaNetworkProjectionOriginalContext` (existing adjacent identity/network contract)

The tests read the embedded manifest and/or exercise the actual projection source. Windows bootstrap tests read SYSTEMROOT, WINDIR and COMSPEC; they replace only their declared bootstrap PATH with COMSPEC's directory and perform native file/directory qualification. These selected functions do not start UV, Git or Python.

### Cleanup candidate

The manifest selects exactly ten roots: the seven `TestSerenaOwnedTreeCleanup...` roots already in #643, `TestSerenaOwnedTreeObserveStreamsNative`, `TestSerenaOwnedTreeReadonlyHardlinkDeletion`, and `TestSerenaOwnedTreeRemovalOpenRejectsPublishedReader`.

No selected root contains an explicit `t.Skip`, `t.Skipf` or `t.SkipNow`. Native files have Windows build constraints: a passing non-Windows run with missing roots is not evidence for this handoff. Record observed root names, failures/skips and the exact executed source; do not infer execution from the selector string.

### TestMain and retained fixture effects

`internal/api/main_test.go:65` runs before any selected root. Line 72 enters a special child path if `MCPHUB_TEST_CALLER_START_TIME_CHILD_STATEDIR` is set; the harness must not inherit that sentinel. Line 88 creates a root through `os.TempDir()`; line 96 redirects client configuration environment paths into it; line 249 executes the selection; line 282 invokes `apitest.RemoveTestMainRoot`, which uses `os.RemoveAll` and verifies absence. Supervisor, process-table, autostart and interprocess-communication side-effect seams are sealed by TestMain.

Bind the process's TEMP/TMP and Go writable caches to the root-owned R24 area under `D:\dev\ChatGPT`. SYSTEMROOT/WINDIR/COMSPEC must still refer to qualified native inputs; no replacement of those files is needed.

The readonly-link test intentionally uses `os.MkdirTemp(os.TempDir(), "serena-readonly-unlink-")`, not `t.TempDir`. Its marker is:

```text
retained native readonly-link fixture: <basename>
```

The retained path is **the harness's child temp root joined with that basename**. It contains the surviving readonly hard link after all owned handles have checked closes. Preserve load-bearing receipt data, then apply the root's trash-first disposition to the complete confirmed disposable fixture. Do not individually delete or change the survivor's readonly attributes. The stream test uses `t.TempDir` and Go's normal test cleanup.

## Material residual uncertainty

The #643 fixtures test binding predicates and refusal paths; they do not issue a successful native tree capability and then run full later-context acquisition/inventory/removal. #645 tests the stream primitive; #651 calls the unlink primitive after closing its initial survivor handle. Their combination does not itself add full production RemoveOwned acceptance. The #648 standalone tests likewise do not positively execute its complete native constraint custody lifecycle.

Historical combined-source installation/qualification reports belong only to the recorded source and publisher image. They must remain linked as history and cannot be credited to these local candidate heads. Full required Go suites, current external review and deployed lifecycle behavior are outside this lane's verified result.

## Provenance and terminology

- Execution role: source/code reviewer and bounded local consolidation author; assigned internal role: Serena build/discovery lane.
- Actual path: ChatGPT native collaboration, GitHub read connector, local public-source Git inspection, local Python standard-library audit scripts. No external model/provider launch.
- Skills read and applied: Ponytail; Source-driven Development; Architecture Review; Code Review and Quality; Review Go Engineering Change plus its finding standard; Git Workflow and Versioning.
- Canonical Orchestrarium shared governance was read from published `main`; source blob `88810caa9134c201677bb09818ec2bc63fca49a8`. No AGENTS.md existed in the audited trees. Applicable root CLAUDE.md workflow and Serena sections were inspected; publication gates were not bypassed.
- **PR:** pull request. **SHA-256:** content digest used for byte comparison. **Git blob/tree:** immutable file/directory content objects. **DACL:** discretionary access-control list. **IPC:** interprocess communication. **UV:** Python package/interpreter tool. **Native primitive:** an individual operating-system operation, without implying the complete product lifecycle.

