# R24 — Serena qualification, transport and cleanup audit

## Contents

1. [Decision](#decision)
2. [Exact sources and responsibilities](#exact-sources-and-responsibilities)
3. [Inclusion and retained history](#inclusion-and-retained-history)
4. [Bounded corrections](#bounded-corrections)
5. [Verification and limits](#verification-and-limits)
6. [Artifacts](#artifacts)

## Decision

Reduce duplicate review items through two bounded transfers and one proven existing inclusion: retain #636 in #637; import #656 into #650; let the build lane import #651 into #643 alongside #645. Close donors only after destination content, tests, source references and actual GitHub state have been read back. No PR (pull request) merge or history rewrite is proposed. Keep #632, #635, #649, #652, #653, #654 and #655 as separate responsibility owners.

All 12 assigned heads were freshly retrieved, then read back unchanged at **2026-11-21 11:03:13 UTC**. API metadata base SHAs sometimes describe old snapshots; actual Git refs and common ancestors are recorded separately. Full changed files at exact heads and bases are stored with Git blob and SHA-256 (Secure Hash Algorithm 256-bit) identities. All changed hunks and the relevant owner/caller/test paths were reviewed. This is not a claim that every unchanged line of the large legacy migration fixture was newly requalified.

## Exact sources and responsibilities

**Table 1. Current source identities and recommended disposition.**

| PR | Exact source head | Files in current PR | Recommendation |
|---|---|---:|---|
| [#632](https://github.com/applicate2628/mcp-local-hub/pull/632) | `ff4ba7f85fef35e19b39dced17d9df47bb9237a0` | 2 | Production qualified PATH discovery; preserve as #635 base and propagate its late guard into existing descendants. |
| [#635](https://github.com/applicate2628/mcp-local-hub/pull/635) | `1c135914c108dda8b63816175347c5da77da26d9` | 14 | Source-issued publisher tooling/admission; import missing #632 guard/test only. |
| [#636](https://github.com/applicate2628/mcp-local-hub/pull/636) | `acac454e539a6b951d4b6ee998cc2142ee153069` | 14 | Already exactly included in #637: whole commit ancestry and all 14 changed file blobs. Retarget #637 to #635 after missing parent fixes are preserved. |
| [#637](https://github.com/applicate2628/mcp-local-hub/pull/637) | `2542d63d2f917dc414a387e0ed2ceb494d118cfe` | 12 | Namespace, migration fixture and lifetime qualification; import missing PATH/telemetry guards and keep exact #636 history. |
| [#649](https://github.com/applicate2628/mcp-local-hub/pull/649) | `73caa97a860f1eaec205ec84c1502c47ce05cdc0` | 1 | Qualification HostInputs USERPROFILE binds the retained qualification root; different lifetime/identity from build projection #647 and install constraints #648. |
| [#650](https://github.com/applicate2628/mcp-local-hub/pull/650) | `686a54c0efbe9f99cb6ffa8d6480b289c6f465bf` | 3 | Private HTTP qualification transport: original request and cleanup receiver ownership; absorb only unique #656 patch/tests with one-parent append. |
| [#651](https://github.com/applicate2628/mcp-local-hub/pull/651) | `01c08819cb0d3fc4fe2b9e11833e40de3c28c3d6` | 2 | Readonly entry removal belongs to retained owned-tree cleanup owner; source evidence handed to build lane, same unique tests retained. |
| [#652](https://github.com/applicate2628/mcp-local-hub/pull/652) | `b079e4c9503f080d8ab09742270c89a3bf88d7d5` | 10 | Original generation capability threaded through install, metadata, invocation and unpublished qualification; native/batch read transaction is independent of cleanup disposition. |
| [#653](https://github.com/applicate2628/mcp-local-hub/pull/653) | `90fd6f69ea4a59856375e29b34cebf4953cb2ff4` | 4 | Native TCP table acquisition plus bounded locale/scoped-address decoding; different authority from HTTP connection ownership. |
| [#654](https://github.com/applicate2628/mcp-local-hub/pull/654) | `d01fb6e73013d6a47628b1a9cbecd2d5f3b8e32c` | 2 | Ready writer/readback publication receiver must validate exact original byte cap; distinct from HTTP cleanup, keep #650 scope bounded. |
| [#655](https://github.com/applicate2628/mcp-local-hub/pull/655) | `2defe618259f7db4144824d19927b032300d160d` | 2 | Work-context lifetime until concrete finalization receives native writers; distinct runtime-owner ordering contract. |
| [#656](https://github.com/applicate2628/mcp-local-hub/pull/656) | `5efac36d1e2b4be998fadfa4ccfed1a5da098cff` | 2 | Not currently absorbed. Import actual original close result receiving and all three regression roots into #650 first. |

## Inclusion and retained history

The full changed-file matrix finds exactly one current complete inclusion among these heads: **#636 → #637, 14 of 14 blobs identical**, and #636's exact commit is an ancestor. #637 still owns six later commits and 12 changed files relative to #636; those fixtures, lifetime tests, documentation and historical evidence must remain. No other current PR in this lane is proven absorbed into another head or master. Byte inequality alone is not used as a semantic non-equivalence proof; the independently retained behavior is identified in Table 1.

The latest #632 commit is not merely missing from ancestry: both #635/#637 production and test files equal the exact pre-fix blobs. Likewise #637's builder and regression file equal the pre-telemetry-fix blobs from #635. `missing-parent-content-proof.json` records all six comparisons.

Corrected #635 appends only the 2-file/+27-line PATH guard and regression; corrected #637 appends only those files plus the builder override/regression, 4 files/+33 lines. Each append must have exactly one parent, its current existing head. Source-issued publisher evidence stays attached to its original source. The parent-only publisher evidence packet is retained on #635 rather than falsely reissued for #637.

For the proposed #637 base change, the current comparison against actual #635 is **26 files, +1748/-89** from common ancestor `6ca53c83aa4f8ccca9bc0eae3d91f3fff9ede109`. After the one-parent propagation it is **30 files, +1781/-89**. The common ancestor does not move: copied identical parent hunks can still appear in GitHub's three-dot view. Candidate tree-to-tree comparison is 30 files, +1747/-326, including historical parent-only evidence; this does not authorize deleting the parent's packet. Four exact patches and file lists are in `retarget-637-comparison.json`.

For #650, the direct append imports only #656's unique production hunks and original close regression file: **2 target-relative files, +338/-6**. Its total retained responsibility has four unique files (+843/-49 relative to the original `17bc78f` base); all three test files keep their source bytes. Donor source commit references preserve provenance; a one-parent append does not make that donor commit an ancestor. No unrelated master updates are imported.

The independent #643 review found no consolidation defect in candidate `e4371eb52f3aee5ac869861c20547e7b50cf3e28`: the inventory and absence-probe opens remain observational; only removal requests write-attribute access. Empty stream EOF preserves cancellation. Parent identity/issuer/lifetime checks, hardlink accounting, sticky close errors and checked close/absence remain intact. Six nonshared original #643 files and both donor tests are byte-identical. Runtime evidence remains the build/root lane's separate responsibility.

## Bounded corrections

**Q1 — missing empty-PATH guard in #635/#637.** At `internal/api/serena_prepared_inputs.go:270`, an empty component reaches `filepath.Join(directory, name)`; when the working directory contains uv/uv.exe, the private helper can select it before the qualified directory. [Exact #635 source](https://github.com/applicate2628/mcp-local-hub/blob/1c135914c108dda8b63816175347c5da77da26d9/internal/api/serena_prepared_inputs.go#L270-L280). The normal bootstrap already rejects empty components, so this is a bounded helper contract omission, not a demonstrated production execution exploit. Copy the existing three-line guard and original 24-line regression. Candidates do this exactly.

**Q2 — missing telemetry override in #637.** At `tools/test-serena-publisher/main_windows.go:324`, the override map lacks `TEST_TELEMETRY_DIR`, `GO_TELEMETRY_CHILD` and `GO_TELEMETRY_CHILD_UPLOAD`; the inherited-environment loop consequently passes them through. [Exact original #637 source](https://github.com/applicate2628/mcp-local-hub/blob/2542d63d2f917dc414a387e0ed2ceb494d118cfe/tools/test-serena-publisher/main_windows.go#L324-L348). If the host defines them, the child retains host-selected telemetry controls instead of clearing them under the builder's private policy. No actual upload is asserted. Copy the original two production lines and four regression lines from #635; the candidate does so.

No additional consolidation-introduced runtime defect was established within the reviewed scope. Old descriptions that prohibit local combination are historical authorization boundaries, superseded by the current instruction; they are archived rather than silently rewritten as if never true. After publication, replace stale scope/base claims and keep earlier source-specific PASS results explicitly historical.

## Verification and limits

**Table 2. Local candidate identities and focused test requirements.**

| Target | Original parent | Candidate tree | Focused top-level roots |
|---|---|---|---:|
| #635 | `1c135914c108dda8b63816175347c5da77da26d9` | `0c4cb2acce09b56198865915d2babbc91b67ddf5` | 1 |
| #637 | `2542d63d2f917dc414a387e0ed2ceb494d118cfe` | `940dfb102e62d599ac453f0afd41a1c0d3b87351` | 4 |
| #650 | `686a54c0efbe9f99cb6ffa8d6480b289c6f465bf` | `712f175be713b1d27843942a31fadf8edd56e61a` | 11 |

Every candidate's target-relative `git diff --check` returned zero. Those are whitespace/static checks, not tests. This agent executed **no product, test or publisher build**, and made **no GitHub mutation**. Required broad gates are **NOT_RUN** in this lane. Exact root names, anchored selections, package paths, hashes, platform exclusions, TestMain effects and child sentinels are in `focused-test-selection.json`.

- #650: 11 untagged portable roots in `./internal/daemon`, with real private ephemeral loopback TCP (Transmission Control Protocol) connections. No selected body skips or starts a subprocess; refusal probes do not issue successful MCP (Model Context Protocol) qualification. The unchanged original head has only eight roots unless the new regression file is overlaid for a counterfactual.
- #635: one discovery root in `./internal/api`. Inert uv/uv.exe fixtures are selected but never executed.
- #637: the same API root plus three Windows-only publisher-tool roots. Option/environment projection does not run the builder. Optional ordinary-build policy checks add two refusal roots. Exclusion by a platform/build tag is missing coverage, not a passing skip.
- API TestMain can bypass the test suite when `MCPHUB_TEST_CALLER_START_TIME_CHILD_STATEDIR` is inherited; clear it and the delay sentinel. Its normal path installs private state/client sandboxes and seals live supervisor/process/autostart/kill seams.

**Retained limitations:** `closeObserved` calls the first underlying `Conn.Close` synchronously before its waiting loop (candidate lines 635/644), and `CloseIdleConnections` is also not newly time-bounded. The import proves bounded receiving of an already-running close plus I/O (input/output), not a total transport/native/tree cleanup budget. Positive #637 migration tests still require an independently admitted Product input and a source-issued Windows qualification executable for the changed source. #652's five native traversal/batch/refusal roots deliberately do not issue full namespace/publisher authority; complete installation acceptance remains separate.

Keep #649's qualification USERPROFILE change separate from build projection and installation constraints; its historical standard-library home-directory probe is not current full preparation acceptance. Keep #653's six parser/native-query roots with TCP-table ownership, #654's two original-readback roots with Ready publication, and #655's two finalization-context roots with runtime ordering. Each has a distinct triggering condition and regression oracle; broadening #650 to absorb them would increase scope without removing duplicated ownership.

## Artifacts

- `recommendations.json`: machine-readable decisions, source SHAs, findings, limits and candidate references.
- `source-manifest.json`, `current-inclusion-matrix.json`, `chain-inclusion-proof.json`, `missing-parent-content-proof.json`: exact source/content proof.
- `retarget-637-comparison.json` and four patches: current and proposed base comparisons.
- `candidate-pr-635`, `candidate-pr-637`, `candidate-pr-650`: complete changed candidate files, target-relative patches and manifests.
- `focused-test-selection.json` and `FOCUSED-TEST-SELECTION.md`: exact focused requirements; execution remains separate.
- `../docs/original-pr-descriptions.zip` and its manifest: all 31 original descriptions, metadata and byte-for-byte archive readback. The 10 concise local body drafts retain source links and explicit publication/runtime placeholders.
