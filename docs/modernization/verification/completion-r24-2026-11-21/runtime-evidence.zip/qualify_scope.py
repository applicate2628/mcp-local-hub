"""Qualify one reviewed R24 consolidation on its own clean PR snapshot.

Reuse the frozen command-capture/lifecycle owner from R21. Product changes are
explicit Go overlays from reviewed source PRs; the checked-out base stays clean.
This does not merge PRs or claim a full published-head qualification.
"""
import sys
sys.dont_write_bytecode = True

from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

ROOT = Path(r"D:\dev\ChatGPT\mcp-r24-pr-quality-20261121")
PRIOR = Path(r"D:\dev\ChatGPT\mcp-r17-current-task-recovery-20261121")
RUNNER_SHA = "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61"
REPOSITORY = "https://github.com/applicate2628/mcp-local-hub.git"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def load_owner():
    path = PRIOR / "check_recovery.py"
    if sha(path.read_bytes()) != RUNNER_SHA:
        raise RuntimeError("Frozen command-capture owner changed")
    spec = importlib.util.spec_from_file_location("r24_reused_capture_owner", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 4 or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Use qualify_scope.py <scope> <phase> <manifest-sha256> from the R24 root")
    scope, phase, manifest_sha = sys.argv[1:]
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,40}", scope) or not re.fullmatch(r"[a-z][a-z0-9-]{0,40}", phase) or not re.fullmatch(r"[0-9a-f]{64}", manifest_sha):
        raise RuntimeError("Invalid scope, phase or manifest pin")
    manifest_path = ROOT / "scopes" / scope / "manifest.json"
    manifest_raw = manifest_path.read_bytes()
    if sha(manifest_raw) != manifest_sha:
        raise RuntimeError("Scope manifest differs from the reviewed pin")
    plan = json.loads(manifest_raw)
    if plan["scope"] != scope or phase not in plan["phases"] or plan["wrapper_sha256"] != sha(Path(__file__).read_bytes()):
        raise RuntimeError("Scope, phase or wrapper is not the frozen qualification")
    owner = load_owner()
    source = ROOT / plan["source_directory"]
    if source.parent != ROOT or not re.fullmatch(r"source-pr[0-9]+", source.name):
        raise RuntimeError("Source must be one direct PR snapshot under the R24 root")
    paths = [row["path"] for row in plan["files"]]
    if len(paths) != len(set(paths)) or any(owner.relative_source_path(path) != path for path in paths):
        raise RuntimeError("Source paths are duplicated or outside the admitted Go scope")

    class ScopeRunner(owner.Runner):
        def __init__(self):
            super().__init__(scope + "-" + phase)
            self.out = ROOT / "evidence" / self.phase
            self.runtime = ROOT / "runtime" / self.phase

        def begin(self):
            super().begin()
            # Reuse capture/lifecycle code, but admit only explicit environment
            # inputs for this new scope. No ambient child or fixture switches.
            essentials = {"SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT",
                          "SYSTEMDRIVE", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE"}
            explicit = {"GOROOT", "GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB",
                        "GOVCS", "GOWORK", "GOFLAGS", "GOMODCACHE", "GOPATH", "CC",
                        "CGO_ENABLED", "GOMAXPROCS", "GOTELEMETRY", "USERPROFILE",
                        "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR", "GOTMPDIR",
                        "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME",
                        "PSMODULEANALYSISCACHEPATH", "PYTHONDONTWRITEBYTECODE",
                        "GIT_OPTIONAL_LOCKS", "GIT_CONFIG_NOSYSTEM", "GIT_CONFIG_GLOBAL",
                        "GIT_TERMINAL_PROMPT", "GCM_INTERACTIVE", "MCPHUB_NO_AUTO_GUI",
                        "MCPHUB_E2E_SCHEDULER"}
            self.env = {k: v for k, v in self.env.items() if k.upper() in essentials | explicit}
            system = Path(next(v for k, v in self.env.items() if k.upper() == "SYSTEMROOT"))
            cache = ROOT / "gocache"
            cache.mkdir(exist_ok=True)
            self.env.update({
                "GOCACHE": str(cache), "HOME": str(self.runtime / "profile"),
                "PATH": os.pathsep.join(map(str, (owner.GO.parent, owner.GIT.parent,
                    system / "System32", system / "System32/WindowsPowerShell/v1.0"))),
                "GOOS": "windows", "GOARCH": "amd64", "GOAMD64": "v1",
                "GO111MODULE": "on", "GOEXPERIMENT": "", "GOFIPS140": "off",
                "GOCACHEPROG": "", "GOPRIVATE": "", "GONOPROXY": "none", "GONOSUMDB": "none",
                "TEST_TELEMETRY_DIR": "", "GO_TELEMETRY_CHILD": "", "GO_TELEMETRY_CHILD_UPLOAD": "",
                "MCPHUB_SUPPRESS_BROWSER_LAUNCH": "1", "MIMOCODE_DISABLE_CLAUDE_CODE_MCP": "1",
                "GIT_LFS_SKIP_SMUDGE": "1",
            })
            self.receipt["environment"] = dict(self.env)
            self.receipt["environment_role"] = "Explicit R24 allowlist; earlier capture-owner initial receipt precedes this override and no command used that initial environment"
            owner.save_new(self.out / "scope-environment.json", {
                "environment": self.env, "scope": scope, "phase": phase,
                "wrapper_sha256": sha(Path(__file__).read_bytes()),
                "whole_process_tree_deadline_enforced": False,
            })

        def snapshot(self, path=None):
            return super().snapshot(source if path is None else path)

    runner = ScopeRunner()
    failure = None

    def captured(label, command, cwd, timeout):
        row = runner.execute(label, command, cwd, timeout)
        runner.receipt["commands"].append(row)
        owner.save_new(runner.out / (label + ".receipt.json"), row)
        runner.require_pass(row)
        return row

    def admit():
        snap = runner.snapshot()
        if snap.get("head") != plan["source_head"] or snap.get("tree") != plan["source_tree"] or snap.get("staged") or snap.get("status"):
            raise RuntimeError("PR source is not the exact clean snapshot")
        for file in plan["files"]:
            path = source / file["path"]
            actual = git_blob(path.read_bytes()) if path.is_file() else None
            if actual != file["original_git_blob"]:
                raise RuntimeError("Original source blob differs: " + file["path"])
        return snap

    def payloads():
        selected = {}
        for file in plan["files"]:
            candidate = manifest_path.parent / "candidate" / file["path"]
            raw = candidate.read_bytes()
            if sha(raw) != file["candidate_sha256"] or git_blob(raw) != file["candidate_git_blob"]:
                raise RuntimeError("Candidate bytes differ: " + file["path"])
            selected[file["path"]] = candidate
        return selected

    try:
        runner.begin()
        runner.paths = paths
        runner.receipt.update(base=plan["source_head"], base_tree=plan["source_tree"],
                              scope_manifest_sha256=manifest_sha, scope_wrapper_sha256=sha(Path(__file__).read_bytes()),
                              reused_capture_owner_sha256=RUNNER_SHA,
                              source_manifest_role="Frozen R21 capture-owner admission only; R24 scope_manifest owns this source and selection",
                              scope=scope, source_directory=str(source))
        if phase == "prepare":
            if source.exists():
                raise RuntimeError("New source destination already exists; no overwrite or reuse")
            captured("init", runner.git_command(ROOT, ["init", "--template=", str(source)]), ROOT, 60)
            captured("fetch-exact", runner.git_command(source, ["fetch", "--no-tags", "--depth=1", REPOSITORY, plan["source_head"]]), source, 300)
            captured("checkout-exact", runner.git_command(source, ["checkout", "--detach", plan["source_head"]]), source, 120)
        runner.receipt["source_before"] = admit()
        candidates = payloads()
        phase_plan = plan["phases"][phase]
        overlay_paths = phase_plan.get("overlay_paths", [])
        if any(path not in candidates for path in overlay_paths) or len(overlay_paths) != len(set(overlay_paths)):
            raise RuntimeError("Overlay contains paths outside this exact scope")
        overlay = runner.out / "overlay.json"
        owner.save_new(overlay, {"Replace": {str(source / path): str(candidates[path]) for path in overlay_paths}})
        runner.receipt["overlay_sha256"] = sha(overlay.read_bytes())
        if phase in {"prepare", "admit"}:
            row = runner.run("gofmt-check", owner.GOFMT, ["-l", *map(str, candidates.values())], 60, source)
            runner.require_pass(row)
            if (runner.out / "gofmt-check.stdout.log").read_bytes():
                raise RuntimeError("Candidate needs formatting before qualification")
        commands = phase_plan.get("commands", [])
        if not commands and phase not in {"prepare", "admit"}:
            raise RuntimeError("An execution phase requires at least one reviewed command")
        labels = [command["label"] for command in commands]
        if len(labels) != len(set(labels)) or any(not re.fullmatch(r"[a-z][a-z0-9-]{0,63}", label) or label.startswith("observation-") or label in {"init", "fetch-exact", "checkout-exact", "gofmt-check"} for label in labels):
            raise RuntimeError("Command labels are invalid, duplicated or reserved")
        for command in commands:
            arguments = [str(overlay) if value == "{overlay}" else value for value in command["args"]]
            if not arguments or arguments[0] not in {"test", "build", "vet"}:
                raise RuntimeError("Only reviewed Go test/build/vet commands are admitted")
            if "-overlay" not in command["args"] or command["args"][command["args"].index("-overlay") + 1] != "{overlay}":
                raise RuntimeError("The command must use the phase's pinned overlay")
            if arguments[0] == "test":
                if "-json" not in arguments or not any(arg.startswith("-count=") for arg in arguments) or not any(arg.startswith("-timeout=") for arg in arguments):
                    raise RuntimeError("Go tests require structured, uncached, bounded results")
                if not command.get("expected_tests") and not command.get("required_root_pass_counts") and not command.get("required_benchmarks"):
                    raise RuntimeError("Go tests require a nonempty selection oracle")
            row = runner.run(command["label"], owner.GO, arguments, command["timeout_seconds"], source)
            if not row.get("settled") or row.get("timed_out") or any(key in row for key in ("error_type", "event_error_type", "source_after_error", "stdout_capture_error", "stderr_capture_error")) or row.get("exit_code") != command["expected_exit_code"]:
                raise RuntimeError("Execution differs from the expected result: " + command["label"])
            output = (runner.out / (command["label"] + ".stdout.log")).read_bytes()
            expected_tests = command.get("expected_tests")
            if expected_tests is not None and (set(row.get("tests", {})) != set(expected_tests) or any(Counter(row["tests"][action]) != Counter(expected_tests[action]) for action in expected_tests)):
                raise RuntimeError("Terminal test events differ from the reviewed oracle: " + command["label"])
            for required in command.get("required_output", []):
                if required.encode("utf-8") not in output:
                    raise RuntimeError("Expected diagnostic is absent: " + command["label"])
            counts = Counter(row.get("tests", {}).get("pass", []))
            if any(counts[root] != count for root, count in command.get("required_root_pass_counts", {}).items()):
                raise RuntimeError("An admitted root test did not pass the required count: " + command["label"])
            for name in command.get("required_benchmarks", []):
                rendered = "".join(event.get("Output", "") for event in owner.test_events(output))
                pattern = r"(?m)^" + re.escape(name) + r"(?:-\d+)?\s+1\s+[0-9]+(?:\.[0-9]+)?\s+ns/op\b"
                if re.search(pattern, rendered) is None:
                    raise RuntimeError("An admitted benchmark did not report a numeric one-iteration result: " + command["label"])
            if command["expected_exit_code"] == 0:
                runner.require_pass(row)
                if row.get("tests", {}).get("skip"):
                    raise RuntimeError("Qualification selected an unexpected skipped test: " + command["label"])
            row["scope_oracle_matched"] = True
        if sha(overlay.read_bytes()) != runner.receipt["overlay_sha256"]:
            raise RuntimeError("Go overlay changed during qualification")
        payloads()
        runner.receipt.update(source_after=admit(), source_head=plan["source_head"], source_tree=plan["source_tree"],
                              completed=True, state="complete")
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
