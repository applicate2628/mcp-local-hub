"""Verify saved receipts, stage only the five reviewed paths, and package redacted copies.

No tests, Scheduler operations, installations or process termination are performed.
"""
from datetime import datetime, timezone
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

if sys.flags.optimize:
    raise SystemExit('Run without Python optimization; validation assertions are required')

ROOT = Path(r'<WORK>')
SOURCE = ROOT / 'source'
GIT = r'<GIT>'
BASE = '1b870e04f58bbf60fde2d2339fcd4ae9b50b24c3'
mode = sys.argv[1]
assert mode in {'prepare', 'final'}
phases = ['bootstrap', 'control', 'candidate', 'focused', 'gates']
if mode == 'final': phases.append('published')
receipts = {p: json.loads((ROOT / 'evidence' / p / 'receipt.json').read_text()) for p in phases}
assert all(r['wrapper_ok'] for r in receipts.values())
assert receipts['control']['semantic_negative_control']
assert len(receipts['gates']['commands']) == 4
final_hashes = receipts['candidate']['source_sha256_after']
assert len(final_hashes) == 5
assert all(receipts[p]['source_stable'] and receipts[p]['source_sha256_after'] == final_hashes for p in phases if p in {'focused','gates','published'})
assert all(hashlib.sha256((SOURCE / p).read_bytes()).hexdigest() == h for p,h in final_hashes.items())
for phase,receipt in receipts.items():
    for c in receipt['commands']:
        assert c['settled']
        for stream in ('stdout','stderr'):
            raw=(ROOT/'evidence'/phase/(c['name']+'.'+stream+'.log')).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == c[stream+'_sha256']
            assert len(raw) == c[stream+'_bytes']
        if 'tests' in c:
            events=[json.loads(l) for l in (ROOT/'evidence'/phase/(c['name']+'.stdout.log')).read_text().splitlines()]
            tests={a:[e.get('Test','PACKAGE:'+e.get('Package','')) for e in events if e.get('Action')==a] for a in ('pass','fail','skip')}
            assert tests == c['tests']
    if phase in {'focused','published'}:
        assert all(c['exit_code']==0 and not c['tests']['fail'] and not c['tests']['skip'] for c in receipt['commands'])

env=dict(os.environ)
env.update({'TEMP':str(ROOT/'runtime/bootstrap/tmp'),'TMP':str(ROOT/'runtime/bootstrap/tmp'),
            'USERPROFILE':str(ROOT/'runtime/bootstrap/profile'),'APPDATA':str(ROOT/'runtime/bootstrap/appdata'),
            'LOCALAPPDATA':str(ROOT/'runtime/bootstrap/localappdata'),'GIT_CONFIG_NOSYSTEM':'1',
            'GIT_CONFIG_GLOBAL':str(ROOT/'runtime/bootstrap/no-global-git-config'),'GIT_TERMINAL_PROMPT':'0'})
def git(*args):
    return subprocess.check_output([GIT,'-C',str(SOURCE),*args],env=env).decode().strip()
if mode == 'prepare':
    assert git('rev-parse','HEAD') == BASE
    assert set(git('diff','--name-only').splitlines()) == set(final_hashes)-{'internal/scheduler/scheduler_last_result_windows_test.go'}
    assert git('ls-files','--others','--exclude-standard') == 'internal/scheduler/scheduler_last_result_windows_test.go'
    git('add','--',*sorted(final_hashes))
    git('diff','--cached','--check')
    assert set(git('diff','--cached','--name-only').splitlines()) == set(final_hashes)
    assert git('diff','--name-only') == ''
    assert git('ls-files','--others','--exclude-standard') == ''
    tree=git('write-tree')
else:
    expected=sys.argv[2]
    assert git('rev-parse','HEAD') == expected
    assert git('status','--porcelain=v1','--untracked-files=all') == ''
    tree=git('rev-parse','HEAD^{tree}')
    prepared=json.loads((ROOT/'prepared-summary.json').read_text())
    assert prepared['base']==BASE and prepared['source_sha256']==final_hashes and tree==prepared['code_tree']
    published=receipts['published']
    assert published['expected_head']==expected and published['head_after']==expected and published['tree_after']==tree
    assert published['status_after']==''
    checkout=json.loads((ROOT/'evidence/published-checkout/receipt.json').read_text())
    assert checkout['previous_head']==BASE and checkout['parents']==BASE
    assert checkout['expected_head']==expected and checkout['head']==expected and checkout['tree']==tree
    assert checkout['status']=='' and checkout['source_sha256']==final_hashes
    assert all(c['exit_code']==0 and c['settled'] for c in checkout['commands'])
    for phase in ('post-gates','post-published'):
        observation=json.loads((ROOT/'evidence'/phase/'receipt.json').read_text())
        assert observation['exit_code']==0 and observation['settled']
        assert observation['scoped_absence_observed']==(not observation['observation']['remaining'])
        for stream in ('stdout','stderr'):
            assert hashlib.sha256((ROOT/'evidence'/phase/(stream+'.log')).read_bytes()).hexdigest()==observation[stream+'_sha256']

replacements=[(str(SOURCE),'<SOURCE>'),(str(ROOT),'<WORK>'),
              (r'<PREVIOUS_SOURCE>','<PREVIOUS_SOURCE>'),
              (r'<GO_CACHE_ROOT>','<GO_CACHE_ROOT>'),
              (r'<GO_ROOT>','<GO_ROOT>'),(r'<GO_BIN>','<GO_BIN>'),
              (GIT,'<GIT>'),(r'<OWNED_ROOT>','<OWNED_ROOT>')]
private_names=[(v,'<'+k+'>') for k in ('USERNAME','USERDOMAIN','COMPUTERNAME') if (v:=os.environ.get(k)) and len(v)>=3]
def redact_string(text):
    for old,new in replacements:
        for pattern in (old.replace('\\','\\\\'),old,old.replace('\\','/')):
            text=re.sub(re.escape(pattern),lambda _:new,text,flags=re.I)
    text=re.sub(r'(?i)C:[\\/]+Users[\\/]+[^\\/\s\"\']+','<USER_PROFILE>',text)
    text=re.sub(r'S-1-5-21-(?:[0-9]+-){3}[0-9]+','<USER_SID>',text)
    for old,new in private_names:
        text=re.sub(r'(?<![A-Za-z0-9_])'+re.escape(old)+r'(?![A-Za-z0-9_])',lambda _:new,text,flags=re.I)
    return text

def redact(value):
    if isinstance(value,str):return redact_string(value)
    if isinstance(value,list):return [redact(v) for v in value]
    if isinstance(value,dict):return {redact_string(k):redact(v) for k,v in value.items()}
    return value

def safe_bytes(path):
    data=path.read_bytes()
    if path.suffix=='.json':
        return (json.dumps(redact(json.loads(data)),ensure_ascii=False,indent=2)+'\n').encode()
    result=[]
    for line in data.decode('utf-8',errors='replace').splitlines(keepends=True):
        try:event=json.loads(line)
        except ValueError:result.append(redact_string(line))
        else:result.append(json.dumps(redact(event),ensure_ascii=False)+'\n')
    return ''.join(result).encode()

summary={'schema':1,'base':BASE,'code_tree':tree,'mode':mode,'head':git('rev-parse','HEAD'),
         'source_sha256':final_hashes,'source_manifest_sha256':hashlib.sha256(''.join(f'{h}  {p}\n' for p,h in sorted(final_hashes.items())).encode()).hexdigest(),
         'diff_numstat':git('diff',BASE,'--numstat') if mode=='prepare' else git('diff',BASE,'HEAD','--numstat'),
         'verified_utc':datetime.now(timezone.utc).isoformat(),'phases':{},
         'qualification':'Object PowerShell fixtures and Go checks; no new native Scheduler fixture or Product qualification.',
         'whole_process_tree_deadline_enforced':False}
for phase,receipt in receipts.items():
    rows=[]
    for c in receipt['commands']:
        row={k:c[k] for k in ('name','arguments','exit_code','seconds','stderr_bytes','settled','started_utc','finished_utc')}
        if 'tests' in c:
            row['counts']={a:len(v) for a,v in c['tests'].items()}
            row['failures']=c['tests']['fail'];row['skips']=c['tests']['skip']
            row['top_level_functions']=sorted({n for n in c['tests']['pass'] if '/' not in n and not n.startswith('PACKAGE:')})
        if c['arguments'] and c['arguments'][0] == 'test' and 'tests' not in c:
            raw=(ROOT/'evidence'/phase/(c['name']+'.stdout.log')).read_text(encoding='utf-8',errors='replace')
            row['failed_packages']=re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)',raw,re.M)
            row['failed_tests']=re.findall(r'^--- FAIL: ([^ (]+)',raw,re.M)
            row['timed_out']=re.findall(r'panic: test timed out after ([^\n]+)',raw)
            row['diagnostics_source']='Reparsed original stdout line by line; original runner failed_packages may join a bare FAIL with the next line.'
        rows.append(row)
    summary['phases'][phase]={'source_stable':receipt.get('source_stable'),'commands':rows}
summary_name='prepared-summary.json' if mode=='prepare' else 'execution-summary.json'
with (ROOT/summary_name).open('x',encoding='utf-8',newline='\n') as f:
    json.dump(redact(summary),f,ensure_ascii=False,indent=2);f.write('\n')
if mode=='prepare':
    print(json.dumps({'code_tree':tree,'source_files':len(final_hashes),'diff_numstat':summary['diff_numstat'],'verified':True}),flush=True)
    raise SystemExit(0)

archive=ROOT/'evidence-redacted.zip'
assert not archive.exists()
files=[]
for phase in phases:
    files.extend((ROOT/'evidence'/phase).glob('*.log'))
    files.append(ROOT/'evidence'/phase/'receipt.json')
files.extend((ROOT/'evidence/control').glob('*observation*.json'))
for name in ('published-checkout','post-gates','post-published'):
    files.extend((ROOT/'evidence'/name).glob('*.json'))
    files.extend((ROOT/'evidence'/name).glob('*.log'))

files.extend((ROOT/'preparation-failures').glob('*'))
files.extend(ROOT/n for n in ('run_checks.py','package_evidence.py','execution-summary.json','observe_control.py','observe_control_children.py','observe_post_test.py','checkout_published.py','observe_owned_processes.py'))
manifest={'redaction':'Private user identities and machine paths replaced. Receipts retain original stream SHA-256; MANIFEST separately binds public redacted bytes. Original evidence retained outside trash.', 'files':[]}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        data=safe_bytes(p)
        assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{16,}|sk-[A-Za-z0-9_-]{20,}|xox[baprs]-[A-Za-z0-9-]{16,}|AKIA[A-Z0-9]{16}',data),'credential-shaped content requires review'
        name=p.relative_to(ROOT).as_posix()
        z.writestr(name,data)
        manifest['files'].append({'path':name,'original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'saved_sha256':hashlib.sha256(data).hexdigest(),'saved_bytes':len(data)})
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
encoded=base64.b64encode(archive.read_bytes()).decode()
(ROOT/'evidence-redacted.base64.txt').write_text('\n'.join(encoded[i:i+4096] for i in range(0,len(encoded),4096))+'\n')
metadata={'code_tree':tree,'head':summary['head'],'files':len(manifest['files']),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'base64_lines':(len(encoded)+4095)//4096}
(ROOT/'archive-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata),flush=True)
