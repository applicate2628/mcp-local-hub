"""Read-only process snapshot restricted to this work-root marker, not a whole-tree proof."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
ROOT=Path(r'<WORK>')
phase=sys.argv[1]
assert phase in {'post-gates','post-published'}
out=ROOT/'evidence'/phase
out.mkdir(exist_ok=False)
runtime=ROOT/'runtime'/phase
env=dict(os.environ)
for key,name in {'USERPROFILE':'profile','APPDATA':'appdata','LOCALAPPDATA':'localappdata','TEMP':'tmp','TMP':'tmp','TMPDIR':'tmp'}.items():
 p=runtime/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env['PSModuleAnalysisCachePath']=str(runtime/'localappdata/module-analysis-cache')
ps=Path(os.environ.get('SYSTEMROOT') or os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
code=r'''$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);
$ignore=@($PID,__PYTHON_PID__,__SHELL_PID__)
$matched=@(Get-CimInstance Win32_Process -Filter "CommandLine LIKE '%mcp-r17-last-result-20261120%' OR ExecutablePath LIKE '%mcp-r17-last-result-20261120%'" | ForEach-Object {
 [pscustomobject]@{pid=[int]$_.ProcessId;parent_pid=[int]$_.ParentProcessId;image=[string]$_.ExecutablePath;command_line=[string]$_.CommandLine;created_utc=$_.CreationDate.ToUniversalTime().ToString('o')}
})
[pscustomobject]@{observed_utc=[DateTime]::UtcNow.ToString('o');observer_pid=$PID;excluded_pids=$ignore;remaining=@($matched|Where-Object {$_.pid -notin $ignore});scope='work-root marker in executable path or command line'}|ConvertTo-Json -Compress -Depth 4
'''.replace('__PYTHON_PID__',str(os.getpid())).replace('__SHELL_PID__',str(os.getppid()))
receipt={'phase':phase,'started_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'whole_process_tree_proven':False}
with subprocess.Popen([str(ps),'-NoProfile','-NonInteractive','-Command',code],env=env,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as child:
 receipt['pid']=child.pid
 try:
  stdout,stderr=child.communicate(timeout=30)
  receipt['exit_code']=child.returncode;receipt['settled']=True
 except subprocess.TimeoutExpired:
  child.kill();stdout,stderr=child.communicate();receipt.update({'timed_out':True,'exit_code':child.returncode,'settled':True})
(out/'stdout.log').write_bytes(stdout);(out/'stderr.log').write_bytes(stderr)
receipt.update({'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'finished_utc':datetime.now(timezone.utc).isoformat()})
if receipt['exit_code']==0 and not stderr:
 data=json.loads(stdout);assert data['observer_pid']==receipt['pid'];receipt['observation']=data;receipt['scoped_absence_observed']=not data['remaining']
else:receipt['scoped_absence_observed']=False
with (out/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'phase':phase,'exit_code':receipt['exit_code'],'scoped_absence_observed':receipt['scoped_absence_observed'],'remaining':receipt.get('observation',{}).get('remaining'),'whole_process_tree_proven':False}))
raise SystemExit(0 if receipt['scoped_absence_observed'] else 1)
