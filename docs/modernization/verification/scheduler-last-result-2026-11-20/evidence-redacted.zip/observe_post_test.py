"""Read-only post-test Go I/O and cache/workdir observations."""
import ctypes
from ctypes import wintypes as w
from datetime import datetime,timezone
import json
from pathlib import Path
class IOCounters(ctypes.Structure):
    _fields_=[(n,ctypes.c_ulonglong) for n in ('read_operations','write_operations','other_operations','read_bytes','write_bytes','other_bytes')]
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD]; k.OpenProcess.restype=w.HANDLE
k.GetProcessIoCounters.argtypes=[w.HANDLE,ctypes.POINTER(IOCounters)]
k.GetExitCodeProcess.argtypes=[w.HANDLE,ctypes.POINTER(w.DWORD)]
k.CloseHandle.argtypes=[w.HANDLE]
h=k.OpenProcess(0x1000,False,48716)
r={'utc':datetime.now(timezone.utc).isoformat(),'pid':48716,'handle':bool(h)}
if h:
    io=IOCounters();r['io_ok']=bool(k.GetProcessIoCounters(h,ctypes.byref(io)));r['io']={n:getattr(io,n) for n,_ in io._fields_}
    code=w.DWORD();k.GetExitCodeProcess(h,ctypes.byref(code));r['exit_code_or_active']=code.value;k.CloseHandle(h)
for label,p in [('trim',Path(r'<GO_CACHE_ROOT>\gocache\trim.txt')),('workdir',Path(r'<WORK>\runtime\control\tmp\go-build2141504451'))]:
    d={'exists':p.exists()};r[label]=d
    if p.exists():
        s=p.stat();d.update({'mtime':s.st_mtime,'bytes':s.st_size})
        if p.is_file():d['text']=p.read_text()
        else:d['immediate_entries']=len(list(p.iterdir()))
print(json.dumps(r))
root=Path(r'<WORK>\evidence\control')
name='observation-'+datetime.now(timezone.utc).strftime('%H%M%S')+'.json'
(root/name).write_text(json.dumps(r,indent=2))
