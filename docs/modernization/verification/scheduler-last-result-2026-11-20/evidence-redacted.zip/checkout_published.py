"""Select the exact published single-parent commit with the already verified source tree."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
if sys.flags.optimize:
    raise SystemExit('Run without Python optimization; validation assertions are required')

ROOT=Path(r'<WORK>')
SOURCE=ROOT/'source'
GIT=r'<GIT>'
BASE='1b870e04f58bbf60fde2d2339fcd4ae9b50b24c3'
expected=sys.argv[1]
assert len(expected)==40 and all(c in '0123456789abcdef' for c in expected)
prepared=json.loads((ROOT/'prepared-summary.json').read_text())
env=dict(os.environ)
env.update({'GIT_TERMINAL_PROMPT':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':str(ROOT/'runtime/bootstrap/no-global-git-config'),
 'TEMP':str(ROOT/'runtime/bootstrap/tmp'),'TMP':str(ROOT/'runtime/bootstrap/tmp'),
 'USERPROFILE':str(ROOT/'runtime/bootstrap/profile'),'APPDATA':str(ROOT/'runtime/bootstrap/appdata'),'LOCALAPPDATA':str(ROOT/'runtime/bootstrap/localappdata')})
def git(*args):return subprocess.check_output([GIT,'-C',str(SOURCE),*args],env=env).decode().strip()
assert git('rev-parse','HEAD')==BASE
assert not git('diff','--name-only') and not git('ls-files','--others','--exclude-standard')
assert git('write-tree')==prepared['code_tree']
assert all(hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==h for p,h in prepared['source_sha256'].items())
out=ROOT/'evidence/published-checkout';out.mkdir(exist_ok=False)
receipt={'previous_head':BASE,'expected_head':expected,'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[]}
def run(name,args):
 with (out/(name+'.stdout.log')).open('xb') as fo,(out/(name+'.stderr.log')).open('xb') as fe:
  with subprocess.Popen([GIT,'-C',str(SOURCE),*args],env=env,cwd=SOURCE,stdin=subprocess.DEVNULL,stdout=fo,stderr=fe) as child:
   record={'name':name,'pid':child.pid,'exit_code':child.wait(),'settled':True};receipt['commands'].append(record)
 assert record['exit_code']==0,name
run('fetch',['fetch','--no-tags','https://github.com/applicate2628/mcp-local-hub.git',expected])
assert git('show','-s','--format=%P',expected)==BASE
assert git('rev-parse',expected+'^{tree}')==prepared['code_tree']
run('checkout',['checkout','--detach',expected])
receipt.update({'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parents':git('show','-s','--format=%P','HEAD'),
 'status':git('status','--porcelain=v1','--untracked-files=all'),'source_sha256':{p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in prepared['source_sha256']},
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'finished_utc':datetime.now(timezone.utc).isoformat()})
assert receipt['head']==expected and receipt['tree']==prepared['code_tree'] and receipt['parents']==BASE and not receipt['status']
assert receipt['source_sha256']==prepared['source_sha256']
with (out/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'head':receipt['head'],'tree':receipt['tree'],'single_parent':receipt['parents'],'clean':True,'source_equal':True}))
