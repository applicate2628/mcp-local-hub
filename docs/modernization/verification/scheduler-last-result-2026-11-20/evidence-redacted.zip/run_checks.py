"""Offline LastResult regression checks in a separate checkout; no native task mutations.

Direct children are waited through retained Popen objects. This runner does not
claim a separately enforced process-tree deadline or absence of escaped children.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = '1b870e04f58bbf60fde2d2339fcd4ae9b50b24c3'
TREE = 'f4b20c7ff7c0e0224f056cd9d8ec6b15013dff2a'
ROOT = Path(r'<WORK>')
OLD = Path(r'<PREVIOUS_SOURCE>')
SOURCE = ROOT / 'source'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<GIT>')
TEST = 'internal/scheduler/scheduler_last_result_windows_test.go'
CONTRACT = '^(TestSchedulerCOMLastResult.*|TestSchedulerCOMHiddenTaskLookup|TestSchedulerCOMGuardedRunDefinition|TestSchedulerCOMTypedOutcomesIgnoreHostileLocalizedText|TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable|TestSchedulerCOMScriptSerializesNegativeHRESULT|TestSchedulerCOMScriptUTF8ConsoleRoundTripsUnicodeTaskJSON|TestSchedulerRunOwnedAdmissionAndPositiveReply|TestTaskStatusFromCOMUsesNumericStateOnly)$'
phase = sys.argv[1]
assert phase in {'bootstrap', 'control', 'candidate', 'focused', 'gates', 'published'}
expected_head = sys.argv[2] if phase == 'published' else BASE
out = ROOT / 'evidence' / phase
out.mkdir(parents=True, exist_ok=False)
runtime = ROOT / 'runtime' / phase
for name in ('tmp', 'profile', 'appdata', 'localappdata', 'gopath', 'empty-hooks'):
    (runtime / name).mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith('MCPHUB_')}
system_root = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
powershell = system_root / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off', 'GOFLAGS': '-mod=readonly',
    'GOCACHE': r'<GO_CACHE_ROOT>\gocache',
    'GOMODCACHE': r'<GO_CACHE_ROOT>\gomodcache',
    'GOPATH': str(runtime / 'gopath'), 'CC': str(GO.with_name('gcc.exe')), 'CGO_ENABLED': '1',
    'GOMAXPROCS': '4', 'GOTELEMETRY': 'off', 'MCPHUB_NO_AUTO_GUI': '1', 'MCPHUB_E2E_SCHEDULER': 'none',
    'USERPROFILE': str(runtime / 'profile'), 'APPDATA': str(runtime / 'appdata'),
    'LOCALAPPDATA': str(runtime / 'localappdata'), 'TEMP': str(runtime / 'tmp'),
    'TMP': str(runtime / 'tmp'), 'TMPDIR': str(runtime / 'tmp'), 'GOTMPDIR': str(runtime / 'tmp'),
    'PSModuleAnalysisCachePath': str(runtime / 'localappdata/module-analysis-cache'),
    'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(runtime / 'no-global-git-config'),
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(powershell.parent), str(system_root / 'System32'), str(GIT.parent), env.get('PATH', '')))
for path in (GO, GO.with_name('gofmt.exe'), Path(env['CC']), Path(env['GOROOT']), Path(env['GOCACHE']), Path(env['GOMODCACHE']), powershell, GIT):
    assert path.exists(), str(path)
assert 'MCPHUB_TARGET_SCHEDULER_QA' not in env
spec = json.loads((ROOT / 'files.json').read_bytes().decode('utf-8'))
paths = [f['path'] for f in spec]
assert len(paths) == len(set(paths)) == 5
assert all(p.startswith('internal/scheduler/') and '..' not in p for p in paths)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def git_at(directory, *args):
    return subprocess.check_output([str(GIT), '-c', 'core.hooksPath=' + str(runtime / 'empty-hooks'), '-C', str(directory), *args], env=env).decode('utf-8').strip()

def git(*args):
    return git_at(SOURCE, *args)

receipt = {'schema': 1, 'phase': phase, 'base': BASE, 'expected_head': expected_head,
           'started_utc': now(), 'runner_sha256': digest(Path(__file__)),
           'windows': list(sys.getwindowsversion()[:3]), 'commands': [],
           'environment': {k: env[k] for k in ('GOENV', 'GOTOOLCHAIN', 'GOPROXY', 'GOSUMDB', 'GOVCS', 'GOWORK', 'GOFLAGS', 'GOTELEMETRY', 'GOMAXPROCS', 'CGO_ENABLED', 'MCPHUB_NO_AUTO_GUI', 'MCPHUB_E2E_SCHEDULER')},
           'native_lifecycle_opt_in_present': False, 'whole_process_tree_deadline_enforced': False}
checkpoint_index = 0

def save():
    global checkpoint_index
    p = out / ('checkpoint-%02d.json' % checkpoint_index)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(receipt, f, indent=2); f.write('\n')
    checkpoint_index += 1

def run(name, args, executable=GO, cwd=SOURCE):
    stdout, stderr = out / (name + '.stdout.log'), out / (name + '.stderr.log')
    record = {'name': name, 'executable': executable.name, 'arguments': args, 'started_utc': now(), 'settled': False}
    receipt['commands'].append(record)
    save()
    print('START ' + name, flush=True)
    started = time.monotonic()
    with stdout.open('xb') as fo, stderr.open('xb') as fe:
        with subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=fo, stderr=fe) as child:
            record['pid'] = child.pid
            save()
            record['exit_code'] = child.wait()
            record['settled'] = True
    record.update({'seconds': round(time.monotonic() - started, 3), 'finished_utc': now(),
                   'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
                   'stdout_bytes': stdout.stat().st_size, 'stderr_bytes': stderr.stat().st_size})
    if args and args[0] == 'test':
        if '-json' in args:
            events = []
            for line in stdout.read_text(encoding='utf-8', errors='replace').splitlines():
                try: events.append(json.loads(line))
                except ValueError: pass
            record['tests'] = {a: [e.get('Test', 'PACKAGE:' + e.get('Package', '')) for e in events if e.get('Action') == a] for a in ('pass', 'fail', 'skip')}
        else:
            text = stdout.read_text(encoding='utf-8', errors='replace')
            record['failed_packages'] = re.findall(r'^FAIL\s+(\S+)', text, re.M)
            record['failed_tests'] = re.findall(r'^--- FAIL: ([^ (]+)', text, re.M)
            record['timed_out'] = re.findall(r'panic: test timed out after ([^\n]+)', text)
    save()
    print(json.dumps({k: record[k] for k in ('name', 'exit_code', 'seconds', 'stdout_bytes', 'stderr_bytes', 'settled')}), flush=True)
    return record

save()
try:
    if phase == 'bootstrap':
        assert not SOURCE.exists(), 'isolated checkout already exists'
        assert git_at(OLD, 'rev-parse', 'HEAD') == BASE
        assert git_at(OLD, 'rev-parse', 'HEAD^{tree}') == TREE
        assert git_at(OLD, 'status', '--porcelain=v1', '--untracked-files=all') == '', 'old checkout is dirty'
        r = run('clone', ['-c', 'core.autocrlf=false', 'clone', '--local', '--no-hardlinks', '--no-checkout', str(OLD), str(SOURCE)], GIT, ROOT)
        assert r['exit_code'] == 0
        git('config', 'core.autocrlf', 'false')
        git('config', 'core.hooksPath', str(runtime / 'empty-hooks'))
        git('checkout', '--detach', BASE)
        assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
        assert git('rev-parse', 'HEAD^{tree}') == TREE
        assert run('go-version', ['version'])['exit_code'] == 0
        receipt['original_source_still_clean'] = git_at(OLD, 'status', '--porcelain=v1', '--untracked-files=all') == ''
    else:
        assert git('rev-parse', 'HEAD') == expected_head
        receipt['source_sha256_before'] = {p: digest(SOURCE / p) for p in paths if (SOURCE / p).exists()}
        if phase == 'control':
            assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
            test = next(f for f in spec if f['path'] == TEST)
            assert hashlib.sha256(test['content'].encode()).hexdigest() == test['sha256']
            with (SOURCE / TEST).open('xb') as f: f.write(test['content'].encode())
            assert run('gofmt-control', ['-w', TEST], GO.with_name('gofmt.exe'))['exit_code'] == 0
            r = run('old-code-last-result', ['test', '-json', '-count=1', '-timeout=180s', '-run', '^TestSchedulerCOMLastResult', './internal/scheduler'])
            expected_top = {'TestSchedulerCOMLastResult' + x for x in ('Mapping', 'RejectsMissingOrUnknown', 'RejectsInvalidJSON', 'PublicQueries', 'Script')}
            failed_top = {x for x in r.get('tests', {}).get('fail', []) if '/' not in x and not x.startswith('PACKAGE:')}
            receipt['semantic_negative_control'] = r['exit_code'] == 1 and failed_top == expected_top and not r['tests']['skip'] and r['stderr_bytes'] == 0
            assert receipt['semantic_negative_control'], 'control did not exhibit the expected semantic failures'
            assert git('diff', '--name-only') == '', 'old product source was modified'
        elif phase == 'candidate':
            control = json.loads((ROOT / 'evidence/control/receipt.json').read_text())
            assert control['semantic_negative_control']
            assert git('diff', '--name-only') == ''
            for f in spec:
                content = f['content'].encode('utf-8')
                assert hashlib.sha256(content).hexdigest() == f['sha256']
                (SOURCE / f['path']).write_bytes(content)
            assert run('gofmt-candidate', ['-w', *paths], GO.with_name('gofmt.exe'))['exit_code'] == 0
            assert run('diff-check', ['diff', '--check'], GIT)['exit_code'] == 0
            formatted = [{'path': p, 'content': (SOURCE / p).read_bytes().decode('utf-8'), 'sha256': digest(SOURCE / p)} for p in paths]
            with (out / 'formatted-files.json').open('x', encoding='utf-8') as f: json.dump(formatted, f, ensure_ascii=False)
        elif phase in {'focused', 'published'}:
            assert run('contract-race', ['test', '-json', '-race', '-count=2', '-timeout=180s', '-run', CONTRACT, './internal/scheduler'])['exit_code'] == 0
            assert run('contract-tagged-race', ['test', '-json', '-race', '-tags=test_state_path_env', '-count=1', '-timeout=180s', '-run', CONTRACT, './internal/scheduler'])['exit_code'] == 0
        elif phase == 'gates':
            for label, args in (
                ('build', ['build', './...']), ('vet', ['vet', './...']),
                ('full-test', ['test', '-count=1', '-timeout', '5m', './...']),
                ('state-tag-full', ['test', '-tags=test_state_path_env', '-count=1', '-timeout', '5m', './internal/api/', './internal/cli/']),
            ):
                run(label, args)
        receipt['source_sha256_after'] = {p: digest(SOURCE / p) for p in paths}
        if phase in {'focused', 'gates', 'published'}:
            receipt['source_stable'] = receipt['source_sha256_before'] == receipt['source_sha256_after']
            assert receipt['source_stable']
    receipt['head_after'] = git('rev-parse', 'HEAD')
    receipt['tree_after'] = git('rev-parse', 'HEAD^{tree}')
    receipt['status_after'] = git('status', '--porcelain=v1', '--untracked-files=all')
    receipt['wrapper_ok'] = True
except Exception as error:
    receipt['error'] = repr(error)
    receipt['wrapper_ok'] = False
finally:
    receipt['finished_utc'] = now()
    with (out / 'receipt.json').open('x', encoding='utf-8', newline='\n') as f:
        json.dump(receipt, f, indent=2); f.write('\n')
print(json.dumps({'phase': phase, 'wrapper_ok': receipt['wrapper_ok'], 'error': receipt.get('error')}), flush=True)
raise SystemExit(0 if receipt['wrapper_ok'] else 1)
