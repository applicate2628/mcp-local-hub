"""Read-only liveness for the exact negative-control child and wrapper session."""
import ctypes
from ctypes import wintypes as w
import json
from datetime import datetime, timezone
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
k.OpenProcess.restype = w.HANDLE
k.GetExitCodeProcess.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
k.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
k.CloseHandle.argtypes = [w.HANDLE]
records = []
for pid in [48716, 34764]:
    h = k.OpenProcess(0x1000, False, pid)
    row = {'pid': pid, 'handle_obtained': bool(h), 'open_error': ctypes.get_last_error()}
    if h:
        code = w.DWORD()
        row['query_ok'] = bool(k.GetExitCodeProcess(h, ctypes.byref(code)))
        row['exit_code_or_still_active'] = code.value
        image = ctypes.create_unicode_buffer(32768)
        size = w.DWORD(len(image))
        if k.QueryFullProcessImageNameW(h, 0, image, ctypes.byref(size)):
            row['image'] = image.value
        k.CloseHandle(h)
    records.append(row)
print(json.dumps({'observed_utc': datetime.now(timezone.utc).isoformat(), 'processes': records}))
