"""Read only the exact Go process and its current direct children."""
from pathlib import Path
import json
import os
import subprocess
r=Path(r'<WORK>')
env=dict(os.environ)
for k,v in {'USERPROFILE':'profile','APPDATA':'appdata','LOCALAPPDATA':'localappdata','TEMP':'tmp','TMP':'tmp','TMPDIR':'tmp'}.items():
    env[k]=str(r/'runtime/control'/v)
env['PSModuleAnalysisCachePath']=str(r/'runtime/control/localappdata/module-analysis-cache')
ps=Path(os.environ.get('SYSTEMROOT') or os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
code="""$ErrorActionPreference='Stop';Get-CimInstance Win32_Process -Filter 'ProcessId = 48716 OR ParentProcessId = 48716' | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine,KernelModeTime,UserModeTime | ConvertTo-Json -Compress"""
done=subprocess.run([str(ps),'-NoProfile','-NonInteractive','-Command',code],env=env,cwd=r,capture_output=True)
record={'code':done.returncode,'stdout':done.stdout.decode('utf-8',errors='replace'),'stderr':done.stderr.decode('utf-8',errors='replace')}
(r/'evidence/control/process-observation.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
