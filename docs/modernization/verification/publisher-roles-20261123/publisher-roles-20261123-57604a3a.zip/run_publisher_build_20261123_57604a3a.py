"""Build each saved-source role separately; never install or execute Product tests."""
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
WORK = "publisher-work-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
FILES_SHA = "d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235"
SNAPSHOT_SHA = "2bcb3c313dea40ddcb93c5e2d7cd06f69fc23ca98f0ee7fcc08186bff5b6c2a2"
COMMIT = "4c3eb47d002ea729fe80370a75506a1d0c9650ac"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
EPOCH = "4e07a48c4d77d0cdd086dcda1f704cae8d2ccab8067a65811f414ea6de55482d"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GIT_SHA = "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48"
PWSH = Path(r"C:\Program Files\WindowsApps\Microsoft.PowerShell_7.7.0.0_x64__8wekyb3d8bbwe\pwsh.exe")
PWSH_SHA = "f2833e07a5a7d59153ffc63db83bd6b62f6c63ffd8b5b5099a2feadf6b605336"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT or len(sys.argv) != 2:
        raise RuntimeError("Use the fixed task root and one declared role")
    role = sys.argv[1]
    if role not in ("ordinary", "fixture657", "serena"):
        raise RuntimeError("Unknown build role")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    table = q.own("a5-prep/inputs/source-files.json").read_bytes()
    snapshot = q.own(WORK + "/source-snapshot.json").read_bytes()
    if q.sha(table) != FILES_SHA or q.sha(snapshot) != SNAPSHOT_SHA:
        raise RuntimeError("Previously issued Source inputs changed")
    rows = json.loads(table)
    phase = "publisher-" + role + "-20261123-57604a3a"
    out, runtime = q.own("evidence/" + phase), q.own("runtime/" + phase)
    out.mkdir(); runtime.mkdir()
    receipt = {"schema": "separate-publisher-build-v1", "role_requested": role,
        "source_commit": COMMIT, "source_tree": TREE, "source_epoch": EPOCH,
        "source_snapshot_sha256": SNAPSHOT_SHA, "started_utc": q.now(), "completed": False,
        "runner_sha256": q.sha(Path(__file__).read_bytes()), "installs": False,
        "product_or_qualification_tests_executed": False, "native_scheduler_operations": False,
        "whole_process_tree_deadline_enforced_by_outer_runner": False}
    q.save(out / "receipt-initial.json", receipt)
    try:
        pins = {**q.PINS, str(GIT): GIT_SHA}
        if role != "serena":
            pins[str(PWSH)] = PWSH_SHA
        for path, digest in pins.items():
            if q.sha(Path(path).read_bytes()) != digest:
                raise RuntimeError("Installed tool changed: " + path)
        receipt["tool_sha256"] = pins
        receipt["saved_source_before"] = q.check_files("a5-work-v3/export", rows, True)
        q.check_files("a5-work-v3/checkout", rows, True)
        source_rel = "a5-work-v3/checkout" if role == "serena" else WORK + ("/ordinary-source" if role == "ordinary" else "/fixture-git")
        source = q.own(source_rel)
        receipt["build_source_before"] = q.check_files(source_rel, rows, True)
        env = q.environment(runtime, {})
        env["PATH"] = str(GIT.parent) + os.pathsep + env["PATH"]
        env.update(GIT_NO_LAZY_FETCH="1", GIT_ASKPASS="", GCM_INTERACTIVE="never")
        env["GOPROXY"] = (Path(env["GOMODCACHE"]) / "cache" / "download").as_uri().replace(",", "%2C")
        env.update(GOPRIVATE="", GONOPROXY="none", GONOSUMDB="none", CGO_ENABLED="0")
        receipt["environment"] = {k: env[k] for k in sorted(env) if k.startswith(("GO", "GIT_", "MCPHUB_", "XDG_")) or k in ("TEMP", "TMP", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PATH")}
        if role == "serena":
            built = json.loads(q.own("evidence/serena-builder-20261123-57604a3a/receipt.json").read_bytes())
            if not built["completed"] or built["source_head"] != COMMIT or built["source_tree"] != TREE:
                raise RuntimeError("Serena builder source qualification missing")
            executable = q.own(WORK + "/serena-publisher-builder.exe")
            output = q.own(WORK + "/serena-issued")
            args = [str(executable), "--checkout", str(q.own("a5-work-v3/checkout")),
                "--expected-commit", COMMIT, "--go", str(q.GO), "--go-root", env["GOROOT"],
                "--module-cache", env["GOMODCACHE"], "--work-root", str(output), "--timeout", "10m"]
            timeout = 660
        else:
            executable = PWSH
            output = q.own(WORK + ("/ordinary-product" if role == "ordinary" else "/fixture-git/.scratch/product657"))
            args = [str(PWSH), "-NoLogo", "-NoProfile", "-NonInteractive", "-File", str(source / "build.ps1")]
            if role == "ordinary":
                build_date = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                args += ["-WindowsTargetArch", "amd64", "-ReleaseVersion", "0.4.65", "-ReleaseCommit", COMMIT,
                    "-ReleaseBuildDate", build_date, "-SourceSnapshotPath", str(q.own(WORK + "/source-snapshot.json"))]
                receipt["release_build_date"] = build_date
            else:
                args += ["-TestStateIsolatedProduct", "-CanonicalEntryCommandTestProduct"]
            args += ["-OutputDirectory", str(output)]
            timeout = 660
        if output.exists():
            raise RuntimeError("Fresh build destination occupied")
        receipt["executable_sha256_before"] = q.sha(executable.read_bytes())
        row = {"argv": args, "cwd": str(source), "started_utc": q.now(), "settled": False,
            "timed_out": False, "direct_timeout_seconds": timeout}
        q.save(out / "build.started.json", row)
        child = None
        started = time.monotonic()
        try:
            with (out / "build.stdout.log").open("xb") as stdout, (out / "build.stderr.log").open("xb") as stderr:
                child = subprocess.Popen(args, cwd=source, env=env, stdin=subprocess.DEVNULL,
                    stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                row["pid"] = child.pid
                q.save(out / "build.launched.json", row)
                row["exit_code"] = child.wait(timeout=timeout)
                row["settled"] = True
        except subprocess.TimeoutExpired:
            row.update(timed_out=True, process_tree_unresolved=True, retain_runtime_and_logs=True)
            child.terminate()
            try:
                row["exit_code"] = child.wait(timeout=10)
                row["settled"] = True
            except subprocess.TimeoutExpired:
                row["termination_unresolved"] = True
        finally:
            row.update(finished_utc=q.now(), seconds=time.monotonic() - started)
            for stream in ("stdout", "stderr"):
                path = out / ("build." + stream + ".log")
                if path.exists():
                    raw = path.read_bytes()
                    row[stream] = {"bytes": len(raw), "sha256": q.sha(raw)}
            q.save(out / "build.receipt.json", row)
            receipt["build"] = row
        if row["timed_out"] or not row["settled"] or row.get("exit_code") != 0:
            raise RuntimeError("Role builder did not complete successfully")
        receipt["build_source_after"] = q.check_files(source_rel, rows, role != "fixture657")
        receipt["outputs"] = []
        paths = output.rglob("*")
        if role == "serena":
            paths = [output / "source-snapshot.json", output / "qualification-versioninfo.json",
                *(output / "bin").rglob("*"), *(output / "proof").rglob("*")]
        for path in sorted(paths):
            q.own(path.relative_to(ROOT).as_posix())
            if path.is_file():
                raw = path.read_bytes()
                receipt["outputs"].append({"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw), "sha256": q.sha(raw)})
        receipt["saved_source_after"] = q.check_files("a5-work-v3/export", rows, True)
        receipt["saved_checkout_after"] = q.check_files("a5-work-v3/checkout", rows, True)
        if receipt["saved_source_before"] != receipt["saved_source_after"] or receipt["saved_source_before"] != receipt["saved_checkout_after"]:
            raise RuntimeError("Saved source changed")
        if q.sha(executable.read_bytes()) != receipt["executable_sha256_before"]:
            raise RuntimeError("Builder executable changed")
        if q.sha(q.own(WORK + "/source-snapshot.json").read_bytes()) != SNAPSHOT_SHA:
            raise RuntimeError("Source snapshot changed")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        if "saved_source_before" in receipt and "saved_source_after" not in receipt:
            try:
                receipt["saved_source_after"] = q.check_files("a5-work-v3/export", rows, True)
                receipt["saved_checkout_after"] = q.check_files("a5-work-v3/checkout", rows, True)
            except BaseException as error:
                receipt["saved_source_after_error"] = str(error)
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps({k: receipt.get(k) for k in ("role_requested", "completed", "error", "source_commit", "source_epoch", "saved_source_before", "saved_source_after")}), flush=True)

if __name__ == "__main__":
    main()
