"""Finish build preparation with a local Git clone and unchanged source guards."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
WORK = "publisher-work-20261123-57604a3a"
PHASE = "publisher-checkout-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
FILES_SHA = "d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235"
SNAPSHOT_SHA = "2bcb3c313dea40ddcb93c5e2d7cd06f69fc23ca98f0ee7fcc08186bff5b6c2a2"
COMMIT = "4c3eb47d002ea729fe80370a75506a1d0c9650ac"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GIT_SHA = "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    if q.sha(GIT.read_bytes()) != GIT_SHA:
        raise RuntimeError("Installed Git changed")
    table = q.own("a5-prep/inputs/source-files.json").read_bytes()
    snapshot = q.own("a5-work-v3/source-snapshot.json").read_bytes()
    if q.sha(table) != FILES_SHA or q.sha(snapshot) != SNAPSHOT_SHA:
        raise RuntimeError("Previously issued source inputs changed")
    rows = json.loads(table)
    out = q.own("evidence/" + PHASE)
    runtime = q.own("runtime/" + PHASE)
    out.mkdir(); runtime.mkdir()
    receipt = {"started_utc": q.now(), "completed": False, "source_commit": COMMIT,
        "source_tree": TREE, "git_sha256": GIT_SHA, "commands": [],
        "installs": False, "tests": False, "native_scheduler_operations": False}
    q.save(out / "receipt-initial.json", receipt)
    try:
        before = q.check_files("a5-work-v3/checkout", rows, True)
        receipt["source_before"] = before
        q.check_files("a5-work-v3/export", rows, True)
        q.check_files(WORK + "/ordinary-source", rows, True)
        env = q.environment(runtime, {})
        env.update(GIT_NO_LAZY_FETCH="1", GIT_ASKPASS="", GCM_INTERACTIVE="never")
        env["PATH"] = str(GIT.parent) + os.pathsep + env["PATH"]
        hooks = runtime / "empty-hooks"
        hooks.mkdir()
        checkout = q.own(WORK + "/fixture-git")
        if checkout.exists():
            raise RuntimeError("Fresh checkout destination occupied")
        prefix = ["-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(hooks),
                  "-c", "protocol.file.allow=always", "-c", "protocol.allow=never"]
        commands = [
            ("local-clone", [*prefix, "clone", "--local", "--no-hardlinks", "--no-checkout",
                "--template=" + str(hooks), str(q.own("a5-work-v3/checkout")), str(checkout)]),
            ("checkout-exact", [*prefix, "-C", str(checkout), "checkout", "--detach", COMMIT]),
            ("verify-head", [*prefix, "-C", str(checkout), "rev-parse", "--verify", "HEAD"]),
            ("verify-tree", [*prefix, "-C", str(checkout), "rev-parse", "--verify", "HEAD^{tree}"]),
            ("verify-clean", [*prefix, "-C", str(checkout), "status", "--porcelain=v1", "--untracked-files=all"]),
        ]
        for label, args in commands:
            row = {"label": label, "argv": [str(GIT), *args], "cwd": str(ROOT),
                "started_utc": q.now(), "settled": False, "timed_out": False,
                "whole_process_tree_deadline_enforced": False, "direct_timeout_seconds": 120}
            q.save(out / (label + ".started.json"), row)
            started = time.monotonic()
            child = None
            try:
                with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
                    child = subprocess.Popen(row["argv"], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                        stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                    row["pid"] = child.pid
                    q.save(out / (label + ".launched.json"), row)
                    row["exit_code"] = child.wait(timeout=120)
                    row["settled"] = True
            except subprocess.TimeoutExpired:
                row.update(timed_out=True, process_tree_unresolved=True, retain_runtime_and_logs=True)
                child.terminate()
                try:
                    row["exit_code"] = child.wait(timeout=10)
                    row["settled"] = True
                except subprocess.TimeoutExpired:
                    row["termination_unresolved"] = True
            finally:
                row.update(finished_utc=q.now(), seconds=time.monotonic() - started)
                for stream in ("stdout", "stderr"):
                    raw = (out / (label + "." + stream + ".log")).read_bytes()
                    row[stream] = {"bytes": len(raw), "sha256": q.sha(raw)}
                q.save(out / (label + ".receipt.json"), row)
                receipt["commands"].append(row)
            if not row["settled"] or row["timed_out"] or row.get("exit_code") != 0:
                raise RuntimeError("Local Git operation failed: " + label)
        def output(label):
            return (out / (label + ".stdout.log")).read_text(encoding="utf-8").strip()
        if output("verify-head") != COMMIT or output("verify-tree") != TREE or output("verify-clean"):
            raise RuntimeError("Clone identity or clean-state mismatch")
        receipt["clone_source"] = q.check_files(WORK + "/fixture-git", rows, True)
        if receipt["clone_source"] != before:
            raise RuntimeError("Cloned source differs")
        with q.own(WORK + "/source-snapshot.json").open("xb") as stream:
            stream.write(snapshot)
        basis = json.loads(q.own("plans/b1-continuation-20261123-57604a3a.json").read_bytes())
        phase = "serena-builder-20261123-57604a3a"
        plan = {**basis, "phase": phase, "source_directory": "a5-work-v3/export", "source_head": COMMIT,
            "source_tree": TREE, "source_files": rows, "inputs_directory": "a5-prep/inputs",
            "input_files": [{"path": "source-files.json", "bytes": len(table), "sha256": FILES_SHA}],
            "commands": [{"label": "serena-builder-build", "tool": "go", "args": ["build", "-o",
                str(q.own(WORK + "/serena-publisher-builder.exe")), "./tools/test-serena-publisher"],
                "timeout_seconds": 300, "expected_exit_code": 0}]}
        plan_path = q.own("plans/" + phase + ".json")
        q.save(plan_path, plan)
        receipt["builder_plan"] = {"path": plan_path.relative_to(ROOT).as_posix(), "sha256": q.sha(plan_path.read_bytes())}
        receipt["source_after"] = q.check_files("a5-work-v3/checkout", rows, True)
        receipt["export_after"] = q.check_files("a5-work-v3/export", rows, True)
        if receipt["source_after"] != before or receipt["export_after"] != before:
            raise RuntimeError("Saved source changed")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps({k: v for k, v in receipt.items() if k != "commands"}), flush=True)

if __name__ == "__main__":
    main()
