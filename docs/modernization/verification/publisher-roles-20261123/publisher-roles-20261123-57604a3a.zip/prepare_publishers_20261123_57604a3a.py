"""Copy the previously issued exact Source for three distinct build contracts."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
WORK = "publisher-work-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
SOURCE_FILES_SHA = "d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235"
SNAPSHOT_SHA = "2bcb3c313dea40ddcb93c5e2d7cd06f69fc23ca98f0ee7fcc08186bff5b6c2a2"
COMMIT = "4c3eb47d002ea729fe80370a75506a1d0c9650ac"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
EPOCH = "4e07a48c4d77d0cdd086dcda1f704cae8d2ccab8067a65811f414ea6de55482d"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    table = q.own("a5-prep/inputs/source-files.json").read_bytes()
    snapshot = q.own("a5-work-v3/source-snapshot.json").read_bytes()
    if q.sha(table) != SOURCE_FILES_SHA or q.sha(snapshot) != SNAPSHOT_SHA:
        raise RuntimeError("Previously issued Source inputs changed")
    rows = json.loads(table)
    if len(rows) != 3323:
        raise RuntimeError("Unexpected Source size")
    original = q.check_files("a5-work-v3/export", rows, True)
    checkout = q.check_files("a5-work-v3/checkout", rows, True)
    if original != checkout:
        raise RuntimeError("Issued export and committed checkout differ")
    work = q.own(WORK)
    work.mkdir()
    receipt = {"started_utc": q.now(), "completed": False, "source_commit": COMMIT, "source_tree": TREE,
        "source_epoch": EPOCH, "snapshot_sha256": SNAPSHOT_SHA, "original_before": original,
        "installs": False, "tests": False, "native_scheduler_operations": False}
    q.save(work / "receipt-initial.json", receipt)
    try:
        for leaf in ("ordinary-source", "fixture-checkout"):
            (work / leaf).mkdir()
            for row in rows:
                raw = q.own("a5-work-v3/export/" + row["path"]).read_bytes()
                if len(raw) != row["bytes"] or q.sha(raw) != row["sha256"]:
                    raise RuntimeError("Source changed during copy")
                output = q.own(WORK + "/" + leaf + "/" + row["path"])
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open("xb") as stream:
                    stream.write(raw)
            receipt[leaf] = q.check_files(WORK + "/" + leaf, rows, True)
        git_root = q.own("a5-work-v3/checkout/.git")
        git_files = []
        for path in sorted(git_root.rglob("*")):
            q.own(path.relative_to(ROOT).as_posix())
            if not path.is_file():
                continue
            relative = path.relative_to(git_root).as_posix()
            raw = path.read_bytes()
            output = q.own(WORK + "/fixture-checkout/.git/" + relative)
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open("xb") as stream:
                stream.write(raw)
            git_files.append({"path": relative, "bytes": len(raw), "sha256": q.sha(raw)})
        receipt["fixture_git_files"] = git_files
        with (work / "source-snapshot.json").open("xb") as stream:
            stream.write(snapshot)
        basis = json.loads(q.own("plans/b1-continuation-20261123-57604a3a.json").read_bytes())
        phase = "serena-builder-20261123-57604a3a"
        launcher = q.own(WORK + "/serena-publisher-builder.exe")
        plan = {**basis, "phase": phase, "source_directory": "a5-work-v3/export", "source_head": COMMIT, "source_tree": TREE,
            "source_files": rows, "inputs_directory": "a5-prep/inputs", "input_files": [{"path": "source-files.json", "bytes": len(table), "sha256": SOURCE_FILES_SHA}],
            "commands": [{"label": "serena-builder-build", "tool": "go", "args": ["build", "-o", str(launcher), "./tools/test-serena-publisher"], "timeout_seconds": 300, "expected_exit_code": 0}]}
        plan_path = q.own("plans/" + phase + ".json")
        if plan_path.exists():
            raise RuntimeError("Fresh builder plan occupied")
        q.save(plan_path, plan)
        receipt["builder_plan"] = {"path": plan_path.relative_to(ROOT).as_posix(), "sha256": q.sha(plan_path.read_bytes())}
        receipt["original_after"] = q.check_files("a5-work-v3/export", rows, True)
        receipt["checkout_after"] = q.check_files("a5-work-v3/checkout", rows, True)
        if receipt["original_after"] != original or receipt["checkout_after"] != checkout:
            raise RuntimeError("Saved Source changed")
        receipt["completed"] = True
    finally:
        receipt["finished_utc"] = q.now()
        q.save(work / "receipt.json", receipt)
        print(json.dumps({k: v for k, v in receipt.items() if k != "fixture_git_files"}), flush=True)

if __name__ == "__main__":
    main()
