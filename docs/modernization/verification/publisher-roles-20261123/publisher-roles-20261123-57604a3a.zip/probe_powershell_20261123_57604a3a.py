"""Read the installed PowerShell identity and effective policy in owned scratch."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
PHASE = "powershell-probe-20261123-57604a3a"
ALIAS = Path(r"C:\Users\dima_\AppData\Local\Microsoft\WindowsApps\Microsoft.PowerShell_8wekyb3d8bbwe\pwsh.exe")
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed work root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Environment owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    evidence = q.own("evidence/" + PHASE)
    runtime = q.own("runtime/" + PHASE)
    evidence.mkdir()
    runtime.mkdir()
    env = q.environment(runtime, {})
    script = "[pscustomobject]@{Path=[Environment]::ProcessPath; Version=$PSVersionTable.PSVersion.ToString(); ExecutionPolicy=(Get-ExecutionPolicy).ToString()} | ConvertTo-Json -Compress"
    argv = [str(ALIAS), "-NoProfile", "-NonInteractive", "-Command", script]
    receipt = {"started_utc": q.now(), "argv": argv, "read_only_probe": True,
        "policy_changes": False, "profile_loaded": False, "settled": False, "timed_out": False}
    q.save(evidence / "receipt-initial.json", receipt)
    child = None
    started = time.monotonic()
    try:
        with (evidence / "stdout.log").open("xb") as stdout, (evidence / "stderr.log").open("xb") as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt["pid"] = child.pid
            q.save(evidence / "launched.json", receipt)
            try:
                receipt["exit_code"] = child.wait(timeout=30)
                receipt["settled"] = True
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
                child.terminate()
                receipt["exit_code"] = child.wait(timeout=10)
                receipt["settled"] = True
                receipt["process_tree_unresolved"] = True
        for stream in ("stdout", "stderr"):
            raw = (evidence / (stream + ".log")).read_bytes()
            receipt[stream] = {"bytes": len(raw), "sha256": q.sha(raw)}
        if receipt["exit_code"] == 0 and not receipt["timed_out"]:
            observed = json.loads((evidence / "stdout.log").read_text(encoding="utf-8-sig"))
            path = Path(observed["Path"])
            if not path.is_absolute() or not path.is_file():
                raise RuntimeError("Observed physical executable is not a file")
            receipt["observed"] = observed
            receipt["executable_sha256"] = q.sha(path.read_bytes())
    finally:
        receipt["finished_utc"] = q.now()
        receipt["seconds"] = time.monotonic() - started
        q.save(evidence / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
