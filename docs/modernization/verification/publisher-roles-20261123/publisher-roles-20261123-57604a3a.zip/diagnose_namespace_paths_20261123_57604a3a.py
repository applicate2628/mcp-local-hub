"""Read-only reproduction of the native fixture's ordinary-path handle checks."""
import sys
sys.dont_write_bytecode = True
import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"

class Information(ctypes.Structure):
    _fields_ = [("attributes", wintypes.DWORD), ("created", wintypes.FILETIME),
        ("accessed", wintypes.FILETIME), ("written", wintypes.FILETIME),
        ("volume", wintypes.DWORD), ("size_high", wintypes.DWORD), ("size_low", wintypes.DWORD),
        ("links", wintypes.DWORD), ("index_high", wintypes.DWORD), ("index_low", wintypes.DWORD)]

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    out = q.own("evidence/namespace-path-diagnostic-20261123-57604a3a")
    out.mkdir()
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    create.restype = wintypes.HANDLE
    info = kernel.GetFileInformationByHandle
    info.argtypes = [wintypes.HANDLE, ctypes.POINTER(Information)]
    info.restype = wintypes.BOOL
    close = kernel.CloseHandle
    close.argtypes = [wintypes.HANDLE]
    close.restype = wintypes.BOOL
    receipt = {"started_utc": q.now(), "completed": False, "read_only": True,
        "permission_or_policy_changes": False, "tests_executed": False, "paths": []}
    targets = [
        (q.own("candidate-next-continuation-20261123-57604a3a"), True),
        (q.own("runtime/namespace-run-20261123-57604a3a"), True),
        (q.GO, False),
        (Path(r"C:\Program Files\WindowsApps\Microsoft.PowerShell_7.7.0.0_x64__8wekyb3d8bbwe\pwsh.exe"), False),
    ]
    try:
        for target, directory in targets:
            row = {"target": str(target), "directory": directory, "opened": [], "close_errors": []}
            held = []
            try:
                parts = [*reversed(target.parents), target]
                for i, part in enumerate(parts):
                    leaf = i == len(parts) - 1
                    access = 0x00020000 | 0x00000080  # READ_CONTROL | FILE_READ_ATTRIBUTES
                    if leaf and not directory:
                        access |= 0x80000000  # GENERIC_READ
                    handle = create(str(part), access, 1, None, 3, 0x00200000 | 0x02000000, None)
                    if handle == ctypes.c_void_p(-1).value:
                        code = ctypes.get_last_error()
                        row["failure"] = {"path": str(part), "operation": "CreateFileW", "winerror": code, "message": ctypes.FormatError(code)}
                        break
                    held.append((part, handle))
                    data = Information()
                    if not info(handle, ctypes.byref(data)):
                        code = ctypes.get_last_error()
                        row["failure"] = {"path": str(part), "operation": "GetFileInformationByHandle", "winerror": code, "message": ctypes.FormatError(code)}
                        break
                    if data.attributes & 0x400 or bool(data.attributes & 0x10) != (not leaf or directory):
                        row["failure"] = {"path": str(part), "operation": "type-or-reparse-check", "attributes": data.attributes}
                        break
                    row["opened"].append(str(part))
            finally:
                for part, handle in reversed(held):
                    if not close(handle):
                        row["close_errors"].append({"path": str(part), "winerror": ctypes.get_last_error()})
                receipt["paths"].append(row)
        receipt["other_existing_powershell_candidates"] = [
            {"path": str(p), "is_file": p.is_file()} for p in (
                Path(r"C:\Program Files\PowerShell\7\pwsh.exe"),
                Path(r"C:\Program Files\PowerShell\7-preview\pwsh.exe"))]
        receipt["completed"] = True
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
