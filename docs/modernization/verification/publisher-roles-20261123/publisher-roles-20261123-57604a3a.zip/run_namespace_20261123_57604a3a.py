"""Run the repository's existing native namespace fixture with exact local inputs."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
PHASE = "namespace-run-20261123-57604a3a"
BASE = "plans/b1-continuation-20261123-57604a3a.json"
BASE_SHA = "94850d9b5b25e5d326702990b4bdb8428b8cd4e5eb9875c544139e87335c5508"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
PWSH = Path(r"C:\Program Files\WindowsApps\Microsoft.PowerShell_7.7.0.0_x64__8wekyb3d8bbwe\pwsh.exe")
PWSH_SHA = "f2833e07a5a7d59153ffc63db83bd6b62f6c63ffd8b5b5099a2feadf6b605336"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed work root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    raw = q.own(BASE).read_bytes()
    if q.sha(raw) != BASE_SHA or q.sha(PWSH.read_bytes()) != PWSH_SHA:
        raise RuntimeError("Source manifest or physical PowerShell changed")
    base = json.loads(raw)
    build = json.loads(q.own("evidence/namespace-build-20261123-57604a3a/receipt.json").read_bytes())
    if not build["completed"] or any(not c["oracle_pass"] for c in build["commands"]):
        raise RuntimeError("Native namespace launcher build is not admitted")
    before = q.check_files(base["source_directory"], base["source_files"], True)
    if build["source_after"] != before:
        raise RuntimeError("Launcher build/source inventory differs")
    binary = q.own("exports/recovery-namespace-continuation-20261123-57604a3a.exe")
    binary_sha = q.sha(binary.read_bytes())
    evidence, runtime = q.own("evidence/" + PHASE), q.own("runtime/" + PHASE)
    evidence.mkdir()
    runtime.mkdir()
    env = q.environment(runtime, {})
    argv = [str(binary), "-repo", str(q.own(base["source_directory"])), "-go", str(q.GO), "-pwsh", str(PWSH), "-parent", str(runtime), "-build-timeout", "5m", "-test-timeout", "3m"]
    receipt = {"started_utc": q.now(), "argv": argv, "source_before": before, "manifest_sha256": BASE_SHA,
        "launcher_sha256": binary_sha, "powershell_sha256": PWSH_SHA, "policy_changes": False,
        "settled": False, "timed_out": False, "outer_tree_deadline_proven": False}
    q.save(evidence / "receipt-initial.json", receipt)
    started = time.monotonic()
    try:
        with (evidence / "stdout.log").open("xb") as stdout, (evidence / "stderr.log").open("xb") as stderr:
            child = subprocess.Popen(argv, cwd=q.own(base["source_directory"]), env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt["pid"] = child.pid
            q.save(evidence / "launched.json", receipt)
            try:
                receipt["exit_code"] = child.wait(timeout=540)
                receipt["settled"] = True
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
                child.terminate()
                receipt["exit_code"] = child.wait(timeout=10)
                receipt["settled"] = True
                receipt["process_tree_unresolved"] = True
        for stream in ("stdout", "stderr"):
            raw = (evidence / (stream + ".log")).read_bytes()
            receipt[stream] = {"bytes": len(raw), "sha256": q.sha(raw)}
        for line in (evidence / "stdout.log").read_text(encoding="utf-8-sig").splitlines():
            if line.startswith("Private evidence root: "):
                native = Path(line.removeprefix("Private evidence root: "))
                if not native.is_relative_to(runtime):
                    raise RuntimeError("Native fixture escaped its fresh runtime")
                receipt["native_evidence"] = str(native)
        receipt["source_after"] = q.check_files(base["source_directory"], base["source_files"], True)
        receipt["inputs_unchanged"] = before == receipt["source_after"] and binary_sha == q.sha(binary.read_bytes()) and PWSH_SHA == q.sha(PWSH.read_bytes())
    finally:
        receipt["finished_utc"] = q.now()
        receipt["seconds"] = time.monotonic() - started
        q.save(evidence / "receipt.json", receipt)
        print(json.dumps(receipt), flush=True)

if __name__ == "__main__":
    main()
