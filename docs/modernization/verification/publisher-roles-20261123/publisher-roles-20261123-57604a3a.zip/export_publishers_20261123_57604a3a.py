"""Export closed build/admission receipts, without copying executable products."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
WORK = "publisher-work-20261123-57604a3a"
QUALIFY_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"

def main():
    if sys.platform != "win32" or sys.flags.optimize or Path(__file__).parent != ROOT:
        raise RuntimeError("Use the fixed task root")
    if hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() != QUALIFY_SHA:
        raise RuntimeError("Qualification owner changed")
    spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    data = {}
    def add(name):
        raw = q.own(name).read_bytes()
        if name in data:
            raise RuntimeError("Duplicate evidence member")
        data[name] = raw
    def directory(name):
        for path in sorted(q.own(name).rglob("*")):
            q.own(path.relative_to(ROOT).as_posix())
            if path.is_file():
                add(path.relative_to(ROOT).as_posix())
    phases = ["publisher-checkout", "serena-builder", "publisher-ordinary", "publisher-fixture657", "publisher-serena", "namespace-run", "namespace-path-diagnostic"]
    for phase in phases:
        name = "evidence/" + phase + "-20261123-57604a3a"
        receipt = json.loads(q.own(name + "/receipt.json").read_bytes())
        if phase.startswith("publisher") or phase == "serena-builder":
            if receipt.get("completed") is not True:
                raise RuntimeError("Build preparation not complete: " + phase)
        for path in q.own(name).glob("*.receipt.json"):
            row = json.loads(path.read_bytes())
            if row.get("settled") is not True or row.get("timed_out") is not False:
                raise RuntimeError("Unsettled evidence: " + str(path))
            stem = path.name.removesuffix(".receipt.json")
            for stream in ("stdout", "stderr"):
                if stream in row:
                    raw = (path.parent / (stem + "." + stream + ".log")).read_bytes()
                    if len(raw) != row[stream]["bytes"] or q.sha(raw) != row[stream]["sha256"]:
                        raise RuntimeError("Raw build stream changed")
        for artifact in receipt.get("outputs", []):
            raw = q.own(artifact["path"]).read_bytes()
            if len(raw) != artifact["bytes"] or q.sha(raw) != artifact["sha256"]:
                raise RuntimeError("Issued artifact changed: " + artifact["path"])
        directory(name)
    for name in [
        "qualify_go.py", "prepare_publishers_20261123_57604a3a.py", "prepare_publishers_git_20261123_57604a3a.py",
        "run_publisher_build_20261123_57604a3a.py", "diagnose_namespace_paths_20261123_57604a3a.py",
        "probe_powershell_20261123_57604a3a.py", "run_namespace_20261123_57604a3a.py",
        "export_publishers_20261123_57604a3a.py", "plans/serena-builder-20261123-57604a3a.json",
        "a5-prep/inputs/source-files.json", WORK + "/receipt-initial.json", WORK + "/receipt.json",
        WORK + "/source-snapshot.json", WORK + "/ordinary-product/windows-product-identity.json",
        WORK + "/fixture-git/.scratch/product657/windows-product-identity.json",
        WORK + "/fixture-git/.scratch/product657/windows-canonical-command-test-fixture.json",
        WORK + "/serena-issued/qualification-versioninfo.json", WORK + "/serena-issued/source-snapshot.json",
        "a5-work-v3/export/build.ps1", "a5-work-v3/export/windows-product-artifacts.json",
        "a5-work-v3/export/tools/test-serena-publisher/main_windows.go",
        "a5-work-v3/export/tools/test-recovery-namespace/main_windows.go",
        "a5-work-v3/export/scripts/test-recovery-namespace/helper.ps1"]:
        add(name)
    directory(WORK + "/serena-issued/proof")
    archive = q.own("exports/publisher-roles-20261123-57604a3a.zip")
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, raw in sorted(data.items()):
            zipped.writestr(name, raw)
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None or set(zipped.namelist()) != set(data):
            raise RuntimeError("Evidence archive member mismatch")
        for name, raw in data.items():
            if zipped.read(name) != raw:
                raise RuntimeError("Evidence archive readback mismatch")
    raw = archive.read_bytes()
    manifest = {"archive": archive.relative_to(ROOT).as_posix(), "bytes": len(raw), "sha256": q.sha(raw),
        "members": [{"path": name, "bytes": len(value), "sha256": q.sha(value)} for name, value in sorted(data.items())],
        "executable_artifacts_included": False, "executables_retained_at_recorded_paths": True}
    q.save(archive.with_suffix(".json"), manifest)
    with archive.with_suffix(".b64").open("x", encoding="ascii", newline="\n") as stream:
        stream.write(base64.b64encode(raw).decode() + "\n")
    print(json.dumps({k: v for k, v in manifest.items() if k != "members"}), flush=True)

if __name__ == "__main__":
    main()
