"""Focused red/green verification of the Serena publisher telemetry boundary."""
import datetime, hashlib, json, os, pathlib, subprocess, time
BASE=pathlib.Path(r"D:\dev\ChatGPT")
TASK=BASE/"serena-review-20261118"
REPO=BASE/"mcp-local-hub-pr635-review-20261117"
HEAD="6ca53c83aa4f8ccca9bc0eae3d91f3fff9ede109"
GO=r"C:\msys64\ucrt64\bin\go.exe"
GOFMT=r"C:\msys64\ucrt64\bin\gofmt.exe"
GIT=r"C:\Program Files\Git\cmd\git.exe"
OUT=TASK/"publisher-checks"
OUT.mkdir(exist_ok=False)
for name in ("temp","home","appdata","localappdata"):
    (OUT/name).mkdir()
env={k:v for k,v in os.environ.items() if k.upper() in {"SYSTEMROOT","WINDIR","COMSPEC","SYSTEMDRIVE","PROCESSOR_ARCHITECTURE","NUMBER_OF_PROCESSORS"}}
env.update({
 "PATH":r"C:\msys64\ucrt64\bin;C:\Program Files\Git\cmd;C:\Windows\System32;C:\Windows",
 "PATHEXT":".COM;.EXE;.BAT;.CMD","GOROOT":r"C:\msys64\ucrt64\lib\go",
 "GOCACHE":str(BASE/"mcp-pr616-qualification-20261114"/"gocache"),
 "GOMODCACHE":str(BASE/"mcp-pr616-qualification-20261114"/"gomodcache"),
 "GOENV":"off","GOTOOLCHAIN":"local","GOWORK":"off","GOFLAGS":"","GOMAXPROCS":"4",
 "GOPROXY":"off","GOSUMDB":"off","GOVCS":"*:off","GOAUTH":"off","GOPRIVATE":"","GONOPROXY":"none","GONOSUMDB":"none",
 "GO111MODULE":"on","CGO_ENABLED":"1","GOOS":"windows","GOARCH":"amd64","GOAMD64":"v1","GOEXPERIMENT":"","GOFIPS140":"off","GOCACHEPROG":"",
 "TEST_TELEMETRY_DIR":"","GO_TELEMETRY_CHILD":"","GO_TELEMETRY_CHILD_UPLOAD":"",
 "HOME":str(OUT/"home"),"USERPROFILE":str(OUT/"home"),"APPDATA":str(OUT/"appdata"),"LOCALAPPDATA":str(OUT/"localappdata"),
 "GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":os.devnull,"PYTHONDONTWRITEBYTECODE":"1",
})
for key in ("TEMP","TMP","TMPDIR","GOTMPDIR"):
    env[key]=str(OUT/"temp")
def git(*args):
    return subprocess.check_output([GIT,"-C",str(REPO),*args],env=env,text=True,timeout=30).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert git("rev-parse","HEAD")==HEAD
assert pathlib.Path(GOFMT).is_file()
changed=git("diff","--name-only").splitlines()
assert changed==["tools/test-serena-publisher/main_windows_test.go"],changed
assert not git("diff","--cached","--name-only")
assert not git("ls-files","--others","--exclude-standard")
receipt={"source_parent_commit":HEAD,"stages":[],"network":{"GOPROXY":"off","GOSUMDB":"off","GOVCS":"*:off"}}
def save():
    (OUT/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
def run(name,argv,expected=0):
    print("START",name,flush=True)
    t=time.perf_counter()
    with (OUT/(name+".stdout.log")).open("xb") as fo,(OUT/(name+".stderr.log")).open("xb") as fe:
        result=subprocess.run(argv,cwd=REPO,env=env,stdout=fo,stderr=fe,timeout=180)
    row={"name":name,"argv":argv,"exit_code":result.returncode,"wall_seconds":round(time.perf_counter()-t,3)}
    for stream in ("stdout","stderr"):
        p=OUT/(name+"."+stream+".log")
        row[stream]={"bytes":p.stat().st_size,"sha256":sha(p)}
    receipt["stages"].append(row)
    save()
    print("END",name,"exit",result.returncode,flush=True)
    assert (result.returncode==0) if expected==0 else (result.returncode!=0),name
    return (OUT/(name+".stdout.log")).read_text(encoding="utf-8")
run("private-telemetry-off",[GO,"telemetry","off"])
red=run("red-environment",[GO,"test","-mod=readonly","-json","-count=1","-p=1","-timeout=60s",
 "-run","^TestQualificationBuildEnvironmentCannotInheritSourceOrTagOverrides$","./tools/test-serena-publisher"],1)
events=[json.loads(x) for x in red.splitlines() if x.strip()]
assert any(e.get("Action")=="fail" and e.get("Test")=="TestQualificationBuildEnvironmentCannotInheritSourceOrTagOverrides" for e in events)
output="".join(e.get("Output","") for e in events)
for key in ("TEST_TELEMETRY_DIR","GO_TELEMETRY_CHILD","GO_TELEMETRY_CHILD_UPLOAD"):
    assert key+"=" in output,output
main=REPO/"tools"/"test-serena-publisher"/"main_windows.go"
original=main.read_text(encoding="utf-8")
anchor='\t\t"APPDATA":  filepath.Join(o.root, "appdata"), "LOCALAPPDATA": filepath.Join(o.root, "localappdata"),\n'
assert original.count(anchor)==1
replacement=anchor+'\t\t// Inherited telemetry test/child controls can bypass private telemetry-off.\n'+'\t\t"TEST_TELEMETRY_DIR": "", "GO_TELEMETRY_CHILD": "", "GO_TELEMETRY_CHILD_UPLOAD": "",\n'
main.write_bytes(original.replace(anchor,replacement).encode("utf-8"))
run("gofmt",[GOFMT,"-w",str(main),str(REPO/"tools"/"test-serena-publisher"/"main_windows_test.go")])
green=run("green-package-race",[GO,"test","-mod=readonly","-json","-race","-count=3","-p=1","-timeout=90s","./tools/test-serena-publisher"])
events=[json.loads(x) for x in green.splitlines() if x.strip()]
terminal=[e for e in events if e.get("Test") and e.get("Action") in ("pass","fail","skip")]
assert terminal and all(e["Action"]=="pass" for e in terminal)
receipt["tests"]={"root_pass_events":sum("/" not in e["Test"] for e in terminal),
 "nested_pass_events":sum("/" in e["Test"] for e in terminal),
 "distinct_roots":len({e["Test"] for e in terminal if "/" not in e["Test"]}),
 "fail_events":0,"skip_events":0}
run("vet",[GO,"vet","-mod=readonly","-p=1","./tools/test-serena-publisher"])
assert git("rev-parse","HEAD")==HEAD
assert set(git("diff","--name-only").splitlines())=={
 "tools/test-serena-publisher/main_windows.go","tools/test-serena-publisher/main_windows_test.go"}
diff=subprocess.check_output([GIT,"-C",str(REPO),"diff","--","tools/test-serena-publisher/main_windows.go",
 "tools/test-serena-publisher/main_windows_test.go"],env=env)
(OUT/"review.patch").write_bytes(diff)
receipt["source_files"]={str(p.relative_to(REPO)).replace("\\","/"):sha(p) for p in
 [main,REPO/"tools"/"test-serena-publisher"/"main_windows_test.go"]}
receipt["finished_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({"tests":receipt["tests"],"files":receipt["source_files"]}),flush=True)
