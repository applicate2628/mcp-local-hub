import sys
sys.dont_write_bytecode=True
import base64,hashlib,json,zipfile
from pathlib import Path
root=Path(r"D:\dev\ChatGPT\mcp-residual-20261122-dcb40fba")
assert Path(__file__).resolve().parent==root
for phase in ("upgrade-recovery","weekly-behavior","weekly-lock-order"):
    r=json.loads((root/"evidence"/phase/"receipt.json").read_bytes())
    assert r["commands"] and all(c["settled"] and not c["timed_out"] for c in r["commands"])
    assert r["source_before"]==r["source_after"] and r["inputs_before"]==r["inputs_after"]
names=["qualify_go.py","prepare.py","source-manifest.json","materialize_weekly.py","materialize-weekly-receipt.json","format-upgrade.py","format-weekly.py","receive.py","receive-lzma.py","bootstrap.py","pack_evidence.py","transfer.b64","weekly-transfer.b64"]
paths=[root/n for n in names]
for directory in ("inputs","plans","evidence"):
    paths.extend(p for p in (root/directory).rglob("*") if p.is_file())
paths=sorted(paths,key=lambda p:p.relative_to(root).as_posix())
manifest={"files":[],"source_copies_included":False,"runtime_and_binaries_included":False}
archive=root/"raw-evidence.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for p in paths:
        assert p.is_file() and not p.is_symlink()
        rel=p.relative_to(root).as_posix();raw=p.read_bytes()
        manifest["files"].append({"path":rel,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()})
        out.writestr(rel,raw)
    out.writestr("manifest.json",(json.dumps(manifest,indent=2)+"\n").encode())
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for r in manifest["files"]:
        raw=check.read(r["path"]);assert len(raw)==r["bytes"] and hashlib.sha256(raw).hexdigest()==r["sha256"]
raw=archive.read_bytes()
(root/"raw-evidence.b64").write_bytes(base64.b64encode(raw))
receipt={"archive_bytes":len(raw),"archive_sha256":hashlib.sha256(raw).hexdigest(),"payload_files":len(manifest["files"]),"payload_bytes":sum(r["bytes"] for r in manifest["files"]),"encoded_bytes":(root/"raw-evidence.b64").stat().st_size,"all_payloads_read_back":True}
with (root/"pack-receipt.json").open("x",encoding="utf-8") as out:json.dump(receipt,out,indent=2);out.write("\n")
print(json.dumps(receipt),flush=True)
