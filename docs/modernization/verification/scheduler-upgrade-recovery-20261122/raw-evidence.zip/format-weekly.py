import sys
sys.dont_write_bytecode=True
import hashlib,importlib.util,json,subprocess,base64
from pathlib import Path
root=Path(r"D:\dev\ChatGPT\mcp-residual-20261122-dcb40fba")
assert Path(__file__).resolve().parent==root
assert hashlib.sha256((root/"qualify_go.py").read_bytes()).hexdigest()=="8171272de4782736594ce9e88de5facf2ffcc96d101cf4fc34ae4ef35b6d123b"
spec=importlib.util.spec_from_file_location("qualification",root/"qualify_go.py");q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
files=["internal/api/register.go","internal/api/scheduler_swap.go","internal/api/testhooks.go","internal/api/weekly_refresh.go","internal/api/scheduler_swap_test.go","internal/api/scheduler_mgmt_validation_test.go","internal/api/weekly_refresh_test.go","internal/api/weekly_refresh_recovery_test.go","internal/api/weekly_refresh_atomic_test.go"]
out=q.own("evidence/format-weekly");out.mkdir(parents=True,exist_ok=False)
runtime=q.own("runtime/format-weekly");runtime.mkdir(parents=True,exist_ok=False)
env=q.environment(runtime,{})
for name,digest in q.PINS.items():assert q.sha(Path(name).read_bytes())==digest
paths=[q.own("inputs/weekly-candidate/"+name) for name in files]
row={"argv":[str(q.GOFMT),"-w",*map(str,paths)],"before":[{"path":f,"sha256":q.sha(p.read_bytes())} for f,p in zip(files,paths)],"settled":False,"timed_out":False,"started_utc":q.now()}
q.save(out/"started.json",row)
child=None
try:
    with (out/"stdout.log").open("xb") as stdout,(out/"stderr.log").open("xb") as stderr:
        child=subprocess.Popen(row["argv"],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row["pid"]=child.pid
        row["exit_code"]=child.wait(timeout=60);row["settled"]=True
except subprocess.TimeoutExpired:
    row["timed_out"]=True;raise
finally:
    if child is not None and not row["settled"]:
        child.terminate();row["exit_code"]=child.wait(timeout=10);row["settled"]=True
    row["after"]=[{"path":f,"bytes":len(p.read_bytes()),"sha256":q.sha(p.read_bytes())} for f,p in zip(files,paths)]
    row["finished_utc"]=q.now();q.save(out/"receipt.json",row)
assert row["exit_code"]==0 and not row["timed_out"]
q.execute(out,env,{"label":"gofmt-check","tool":"gofmt","args":["-l",*map(str,paths)],"timeout_seconds":60,"expected_exit_code":0},root)
q.save(root/"formatted-weekly.json",{"files":[{"path":f,"base64":base64.b64encode(p.read_bytes()).decode()} for f,p in zip(files,paths)]})
print(json.dumps(row),flush=True)
