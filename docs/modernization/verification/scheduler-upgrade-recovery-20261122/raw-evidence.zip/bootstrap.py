import base64, hashlib, json, os, zlib
from pathlib import Path, PurePosixPath
root=Path(r"D:\dev\ChatGPT\mcp-residual-20261122-dcb40fba")
assert os.name=="nt" and Path(__file__).resolve().parent==root
raw=(root/"transfer.b64").read_bytes()
assert hashlib.sha256(raw).hexdigest()=="bb2fd3d4ca8d45d8034c4f38ed6290d393c04bbfbc42bb525c77029b06e21ef2"
rows=json.loads(zlib.decompress(base64.b64decode(raw,validate=True)))
assert len(rows)==5
for row in rows:
    rel=PurePosixPath(row["path"])
    assert not rel.is_absolute() and ".." not in rel.parts and "\\" not in row["path"] and ":" not in row["path"]
    data=row["content"].encode("utf-8")
    assert len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"]
    target=root/str(rel)
    for node in (target,*target.parents):
        if node.exists():
            info=node.lstat()
            assert not node.is_symlink() and not getattr(info,"st_file_attributes",0)&0x400
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("xb") as stream:stream.write(data)
print(json.dumps({"transferred_files":len(rows),"hashes_verified":True}),flush=True)
