import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json
from pathlib import Path

root = Path(r"D:\dev\ChatGPT\mcp-residual-20261122-dcb40fba")
assert Path(__file__).resolve().parent == root and len(sys.argv) == 3
runner = root / "qualify_go.py"
assert hashlib.sha256(runner.read_bytes()).hexdigest() == "8171272de4782736594ce9e88de5facf2ffcc96d101cf4fc34ae4ef35b6d123b"
spec = importlib.util.spec_from_file_location("qualification", runner)
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
raw = q.own(sys.argv[1]).read_bytes()
assert q.sha(raw) == sys.argv[2]
plan = json.loads(raw)
assert plan["source_directory"] == "weekly-source"
receipt = {"started_utc": q.now(), "manifest_sha256": q.sha(raw), "script_sha256": q.sha(Path(__file__).read_bytes()), "completed": False, "project_execution": False}
try:
    receipt["base_before"] = q.check_files("source", plan["base_files"], True)
    receipt["inputs_before"] = q.check_files("inputs", plan["input_files"])
    q.own("weekly-source").mkdir(exist_ok=False)
    replacements = {row["path"]: row["from"] for row in plan["replacements"]}
    assert len(replacements) == len(plan["replacements"])
    for row in plan["source_files"]:
        relative = row["path"]
        source = q.own("inputs/" + replacements[relative]) if relative in replacements else q.own("source/" + relative)
        data = source.read_bytes()
        assert len(data) == row["bytes"] and q.sha(data) == row["sha256"]
        target = q.own("weekly-source/" + relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
    receipt["source"] = q.check_files("weekly-source", plan["source_files"], True)
    receipt["base_after"] = q.check_files("source", plan["base_files"], True)
    receipt["inputs_after"] = q.check_files("inputs", plan["input_files"])
    assert receipt["base_before"] == receipt["base_after"] and receipt["inputs_before"] == receipt["inputs_after"]
    receipt["completed"] = True
finally:
    receipt["finished_utc"] = q.now()
    q.save(root / "materialize-weekly-receipt.json", receipt)
print(json.dumps(receipt), flush=True)
