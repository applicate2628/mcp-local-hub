"""Prepare an isolated source composition; execute no tests or Product."""
import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, os, subprocess, zipfile, urllib.request
from pathlib import Path, PureWindowsPath
ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-20261122-dcb40fba")
PRESERVED = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")
ARCHIVE_SHA = "37fa99c64880d4aef5bfa4ff1cf5c19ce0fef6a6c8022b590d1215c18b0db120"
RUNNER_SHA = "8171272de4782736594ce9e88de5facf2ffcc96d101cf4fc34ae4ef35b6d123b"
assert os.name == "nt" and Path(__file__).resolve().parent == ROOT
assert hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest() == RUNNER_SHA
spec=importlib.util.spec_from_file_location("qualification", ROOT/"qualify_go.py")
q=importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
def reject_reparse(p):
    for node in (p, *p.parents):
        st=node.lstat()
        if node.is_symlink() or getattr(st,"st_file_attributes",0)&0x400: raise RuntimeError("Reparse source/ancestor")
reject_reparse(ROOT); reject_reparse(PRESERVED)
out=q.own("evidence/prepare"); out.mkdir(parents=True, exist_ok=False)
runtime=q.own("runtime/prepare"); runtime.mkdir(parents=True,exist_ok=False)
receipt={"completed":False,"tests_executed":False,"native_scheduler_operations":False,"product_operations":False,"dependency_downloads":False,"commands":[],"started_utc":q.now()}
try:
    env=q.environment(runtime,{})
    for name,digest in q.PINS.items():
        if q.sha(Path(name).read_bytes())!=digest: raise RuntimeError("Tool changed")
    archive=q.own("predecessor.zip")
    with urllib.request.urlopen("https://raw.githubusercontent.com/applicate2628/mcp-local-hub/63ba3e771cb5a165e276bf7c481e10a3d3a19837/docs/modernization/verification/scheduler-upgrade-snapshot-20261122/raw-evidence.zip",timeout=60) as response, archive.open("xb") as target:
        while block:=response.read(1024*1024): target.write(block)
    if q.sha(archive.read_bytes())!=ARCHIVE_SHA: raise RuntimeError("Predecessor archive differs")
    with zipfile.ZipFile(archive) as z:
        plan=json.loads(z.read("plans/scheduler-red-green.json")); overlay=json.loads(z.read("inputs/scheduler-green-overlay.json"))["Replace"]
        if plan["source_head"]!="858812988833a84368c60fba1540ae601155fa71" or plan["source_tree"]!="dba685c090952a93a80a1e82403c4646ad8aaed1": raise RuntimeError("Source identity differs")
        for row in plan["source_files"]:
            source=PRESERVED/row["path"]; reject_reparse(source); raw=source.read_bytes()
            if len(raw)!=row["bytes"] or q.sha(raw)!=row["sha256"]: raise RuntimeError("Preserved source differs: "+row["path"])
            target=q.own("source/"+row["path"]); target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as stream: stream.write(raw)
        replacements={}
        for original,replacement in overlay.items():
            relative=str(PureWindowsPath(original).relative_to(PureWindowsPath(r"D:\dev\ChatGPT\mcp-p0-next-20261122-e51f\source"))).replace("\\","/")
            entry="inputs/"+str(PureWindowsPath(replacement).relative_to(PureWindowsPath(r"D:\dev\ChatGPT\mcp-p0-next-20261122-e51f\inputs"))).replace("\\","/")
            target=q.own("inputs/predecessor/"+relative); target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as stream: stream.write(z.read(entry))
            replacements[str(q.own("source/"+relative))]=str(target)
    receipt["source_inventory"]=q.check_files("source",plan["source_files"],True)
    q.save(q.own("source-manifest.json"),{k:plan[k] for k in ("source_head","source_tree","source_files")})
    q.save(q.own("inputs/predecessor-overlay.json"),{"Replace":replacements})
    receipt["archive_sha256"]=ARCHIVE_SHA; receipt["completed"]=True
except BaseException as error:
    receipt.update(error_type=type(error).__name__,error=str(error)); raise
finally:
    receipt["finished_utc"]=q.now(); q.save(out/"receipt.json",receipt)
    print(json.dumps(receipt),flush=True)
