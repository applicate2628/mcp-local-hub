package api

func (f *fakeSwapScheduler) ImportXML(_ string, raw []byte) error {
	f.xml = append([]byte(nil), raw...)
	f.restored = true
	return nil
}
