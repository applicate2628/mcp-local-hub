// Package api — test hooks exported for cross-package integration tests.
//
// The Register/Unregister paths consult package-scoped overrides for the
// scheduler backend, client adapter set, and registry file location. In
// unit tests inside internal/api those overrides are assigned directly;
// cross-package tests (e.g. internal/e2e) cannot reach unexported names,
// so the install-time factory hooks are surfaced as typed public helpers
// here. Production callers never invoke these.
package api

import (
	"context"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"mcp-local-hub/internal/autostart"
	"mcp-local-hub/internal/clients"
	"mcp-local-hub/internal/process"
	"mcp-local-hub/internal/scheduler"
)

// SetFrozenStdioBridgeAdmissionForTest replaces the process-owning stdio
// admission probe for an entire external-package test binary. It is needed by
// transaction tests whose intentionally non-runnable canonical descriptors
// exercise later install/adopt stages; focused API tests retain the real probe.
func SetFrozenStdioBridgeAdmissionForTest(fn func(context.Context, []FrozenStdioBridgeAdmissionRequest) error) (restore func()) {
	if !testing.Testing() {
		panic("api.SetFrozenStdioBridgeAdmissionForTest called outside a test binary — test-only hook")
	}
	if fn == nil {
		panic("api.SetFrozenStdioBridgeAdmissionForTest called with nil admission function")
	}
	original := frozenStdioBridgeAdmissionFn
	frozenStdioBridgeAdmissionFn = fn
	var once sync.Once
	return func() {
		once.Do(func() { frozenStdioBridgeAdmissionFn = original })
	}
}

// RefuseNextStdioBridgeSettlementForTest degrades exactly one API-owned cleanup
// attempt. Every later attempt calls the real same-child owner; no admission
// result, native handle or successful settlement is fabricated. Tests using
// package hooks must remain serialized and restore them after owned cleanup.
func RefuseNextStdioBridgeSettlementForTest(cause error) (restore func()) {
	if !testing.Testing() {
		panic("api.RefuseNextStdioBridgeSettlementForTest called outside a test binary")
	}
	if cause == nil {
		panic("api.RefuseNextStdioBridgeSettlementForTest called with nil refusal")
	}
	original := settleStdioBridgeProvisionalFn
	var refusalOnce sync.Once
	settleStdioBridgeProvisionalFn = func(child *process.ProvisionalProcess, timeout time.Duration) error {
		var refusal error
		refusalOnce.Do(func() { refusal = cause })
		if refusal != nil {
			return refusal
		}
		return child.TerminateAndWait(timeout)
	}
	var restoreOnce sync.Once
	return func() {
		restoreOnce.Do(func() { settleStdioBridgeProvisionalFn = original })
	}
}

// TestSchedulerIface matches the subset of scheduler.Scheduler that the
// Register/Unregister paths use. Cross-package fakes implement it to
// replace the real scheduler backend.
type TestSchedulerIface interface {
	Create(spec scheduler.TaskSpec) error
	Delete(name string) error
	Run(name string) error
	ExportXML(name string) ([]byte, error)
	ImportXML(name string, xml []byte) error
}

// TestClientIface matches the subset of clients.Client that the register
// path consumes. Cross-package fakes implement it.
type TestClientIface interface {
	Exists() bool
	BackupKeep(keepN int) (string, error)
	AddEntry(clients.MCPEntry) error
	RemoveEntry(name string) error
	GetEntry(name string) (*clients.MCPEntry, error)
	AllStdioEntries() ([]clients.StdioEntry, error)
	FindStdioLanguageServerEntries() ([]clients.LanguageServerStdioEntry, error)
}

// InstallTestHooks replaces the Register/Unregister factories with fakes
// for cross-package tests. Every argument is mandatory except
// registryPathOverride (use "" to keep the default). Returns a restore
// function that resets every hook to the production default.
//
// Intended for internal/e2e-style integration tests; production code must
// never call this.
func InstallTestHooks(newScheduler func() (TestSchedulerIface, error),
	clientSet func() map[string]TestClientIface,
	registryPathOverride string,
) (restore func()) {
	origSch := testSchedulerFactory
	origClients := testClientFactory
	origRegPath := testRegistryPathOverride
	origReadiness := proxyReadinessFn

	// Cross-package tests run against a fake scheduler whose Run is a
	// no-op; the production readiness probe would then time out waiting
	// for a port that never binds. Fake it to succeed immediately so
	// Register's post-Run check does not block E2E tests. The E2E test
	// reaches the proxy via its own httptest server, not via the CLI
	// listening on the register-advertised port.
	proxyReadinessFn = func(port int, timeout time.Duration) error { return nil }

	testSchedulerFactory = func() (testScheduler, error) {
		s, err := newScheduler()
		if err != nil {
			return nil, err
		}
		return s, nil
	}
	testClientFactory = func() map[string]registerClient {
		out := map[string]registerClient{}
		for name, c := range clientSet() {
			out[name] = testClientShim{c}
		}
		return out
	}
	testRegistryPathOverride = registryPathOverride

	return func() {
		testSchedulerFactory = origSch
		testClientFactory = origClients
		testRegistryPathOverride = origRegPath
		proxyReadinessFn = origReadiness
	}
}

// SetTestCanonicalMcphubPath overrides the path that canonicalMcphubPath()
// returns. Production code uses ~/.local/bin/mcphub[.exe]; tests that
// need a deterministic stub (or a deliberately missing binary path) set
// this and reset it via the returned restore function.
//
// Intended for cross-package test helpers (internal/e2e and unit tests
// in other packages that exercise the Register/Install paths). The
// in-package register_test.go harness writes to the unexported variable
// directly. Production code must never call this.
func SetTestCanonicalMcphubPath(path string) (restore func()) {
	orig := testCanonicalMcphubPathOverride
	testCanonicalMcphubPathOverride = path
	return func() {
		testCanonicalMcphubPathOverride = orig
	}
}

// MCPHubBinaryName returns the platform-correct basename for the
// canonical mcphub binary ("mcphub" on POSIX, "mcphub.exe" on Windows).
// Cross-package tests use it to pick a stub-file name that matches what
// canonicalMcphubPath() would return after SetTestCanonicalMcphubPath.
func MCPHubBinaryName() string {
	return mcphubShortName
}

// SetInstallAutostartFixtureForTest replaces the install-time scheduler and
// autostart seams for a cross-package test. The install owner lives in this
// package, so callers must use this composite fixture rather than creating a
// GUI-local scheduler bypass. The returned closure restores all prior bindings
// exactly once.
//
// Production callers never invoke this helper. Nil inputs are test setup errors
// and panic before any install path can observe a partial fixture.
func SetInstallAutostartFixtureForTest(
	schedulerFactory func() (scheduler.Scheduler, error),
	factory func() (autostart.Backend, error),
	startOwner func() error,
) (restore func()) {
	if !testing.Testing() {
		panic("api.SetInstallAutostartFixtureForTest called outside a test binary — test-only hook")
	}
	if schedulerFactory == nil {
		panic("api.SetInstallAutostartFixtureForTest called with nil scheduler factory")
	}
	if factory == nil {
		panic("api.SetInstallAutostartFixtureForTest called with nil factory")
	}
	if startOwner == nil {
		panic("api.SetInstallAutostartFixtureForTest called with nil start owner")
	}
	origSchedulerFactory := schedulerFactoryFn
	origFactory := installAutostartBackendFactoryFn
	origStartOwner := installAutostartOwnerStartFn
	schedulerFactoryFn = schedulerFactory
	installAutostartBackendFactoryFn = factory
	installAutostartOwnerStartFn = startOwner
	var once sync.Once
	return func() {
		once.Do(func() {
			schedulerFactoryFn = origSchedulerFactory
			installAutostartBackendFactoryFn = origFactory
			installAutostartOwnerStartFn = origStartOwner
		})
	}
}

// SetDaemonStateRootForTest overrides the per-user state directory
// resolver so cross-package tests (internal/cli/watchdog_test.go,
// future internal/e2e watchdog tests) can route every state file
// (daemon-intent.json, watchdog-state.json, intent-audit.log,
// watchdog.log, --once.lock) into a temp directory without env vars.
//
// Returns a restore function that resets the override to "" (meaning
// the platform resolver runs normally).
//
// Production safety (issue #159 leaks lane #6 closure): the helper
// PANICS when called outside a test binary. Detection uses
// testing.Testing() (Go 1.21+) which returns true iff the running
// process was built via `go test`. A production `mcphub` binary
// linking the api package CANNOT smuggle a state-dir override at
// runtime via this exported surface — calling it crashes the
// process loudly instead of silently redirecting state writes.
//
// Plan v13 §16: production binary refuses env-fallback resolution; this
// override is the sanctioned cross-package test-only equivalent.
func SetDaemonStateRootForTest(root string) (restore func()) {
	if !testing.Testing() {
		panic("api.SetDaemonStateRootForTest called outside a test binary — this is a programming error or attack vector; the helper exists exclusively for test hygiene")
	}
	orig := daemonStateRootOverride
	daemonStateRootOverride = root
	// FIX-5: the serena stop-read cache is keyed by the supervisor-intent path
	// (which changes with the state root) AND the file (mtime,size). Reset it on
	// every state-root switch so a test that reuses a previously-seen path (or a
	// fast-mtime-tick filesystem) never reads a stale cached classification from
	// a prior test. Cheap and test-only.
	resetSerenaStopReadCache()
	return func() {
		daemonStateRootOverride = orig
		resetSerenaStopReadCache()
	}
}

// ResetStrictModeIntentCacheForTest clears the lazy supervisor-intent.json
// strict_mode cache from a CROSS-PACKAGE test (e.g. internal/cli). The
// in-package equivalent resetStrictModeIntentCacheForTest is unreachable from
// other packages; this exported wrapper bridges that gap with the same
// testing.Testing() production guard as SetDaemonStateRootForTest. Production
// callers never invoke it (the cache value is fixed for the process lifetime).
func ResetStrictModeIntentCacheForTest() {
	if !testing.Testing() {
		panic("api.ResetStrictModeIntentCacheForTest called outside a test binary — test-only hook")
	}
	resetStrictModeIntentCacheForTest()
}

// ResetStrictModeMutationGateBypassForTest force-clears the #301-3 strict-mode
// mutation-gate bypass depth from a cross-package test so a leaked Begin cannot
// bleed across tests. Same production guard as the other test hooks.
func ResetStrictModeMutationGateBypassForTest() {
	if !testing.Testing() {
		panic("api.ResetStrictModeMutationGateBypassForTest called outside a test binary — test-only hook")
	}
	resetStrictModeMutationGateBypassForTest()
}

// resetSerenaStopReadCache clears the FIX-5 hot-path stop-read cache. Used by
// the state-root test hook so tests do not see a stale cached stop sub-block
// across state-dir switches.
func resetSerenaStopReadCache() {
	serenaStopReadCache.mu.Lock()
	defer serenaStopReadCache.mu.Unlock()
	serenaStopReadCache.valid = false
	serenaStopReadCache.stops = nil
	serenaStopReadCache.path = ""
	serenaStopReadCache.mtime = time.Time{}
	serenaStopReadCache.size = 0
}

// SetTestStatusFn overrides the StatusContext source so cross-package
// tests can inject deterministic []DaemonStatus rows without spinning
// up Task Scheduler. The watchdog driver consumes both Status() and
// StatusContext via the same seam (statusContextSrcFn).
//
// Returns a restore function that resets the seam.
func SetTestStatusFn(fn func() ([]DaemonStatus, error)) (restore func()) {
	orig := statusContextSrcFn
	statusContextSrcFn = fn
	return func() { statusContextSrcFn = orig }
}

// SetTestRestartContextFn overrides the general-purpose ctx-aware
// Restart wrapper. Used by cross-package tests that exercise paths
// where the watchdog driver could fall back to a non-snapshot restart
// (defensive — the driver should only ever take the snapshot path).
//
// Returns a restore function that resets the seam.
func SetTestRestartContextFn(fn func(server, daemonFilter string) ([]RestartResult, error)) (restore func()) {
	orig := restartContextSrcFn
	restartContextSrcFn = fn
	return func() { restartContextSrcFn = orig }
}

// SetTestSchedulerFactoryFn overrides the package-level scheduler
// factory used by Uninstall paths. Returns a restore function.
func SetTestSchedulerFactoryFn(fn func() (scheduler.Scheduler, error)) (restore func()) {
	orig := schedulerFactoryFn
	schedulerFactoryFn = fn
	return func() { schedulerFactoryFn = orig }
}

// SetTestIntentReaderFn overrides the readDaemonIntentFn seam so
// cross-package tests can drive IntentStillRunning without writing
// intent files to disk. Returns a restore function.
func SetTestIntentReaderFn(fn func(taskName string) (DaemonIntent, bool, error)) (restore func()) {
	orig := readDaemonIntentFn
	readDaemonIntentFn = fn
	return func() { readDaemonIntentFn = orig }
}

// SetTestAuditAppendFn overrides the disk-append step inside
// AppendIntentAudit. Cross-package tests inject targeted failures
// (disk full, permission denied) without exercising the OS write path.
//
// Returns a restore function. The seam is the lower-level audit-append
// step — appendIntentAuditFn (set by intent_audit.go's init()) still
// routes through the production AppendIntentAudit, which then
// dispatches via auditAppendWriteFn.
func SetTestAuditAppendFn(fn func(path string, line []byte) error) (restore func()) {
	orig := auditAppendWriteFn
	auditAppendWriteFn = fn
	return func() { auditAppendWriteFn = orig }
}

// SetTestCanonicalMcphubPathFn overrides the canonical-mcphub-path
// resolver consumed by the liveness-task install (liveness_task.go).
// Returns a restore function.
func SetTestCanonicalMcphubPathFn(fn func() (string, error)) (restore func()) {
	orig := canonicalMcphubPathFn
	canonicalMcphubPathFn = fn
	return func() { canonicalMcphubPathFn = orig }
}

// SetTestCurrentWindowsUserFn overrides the current-user resolver
// consumed by the liveness-task install (liveness_task.go). Returns a
// restore function.
func SetTestCurrentWindowsUserFn(fn func() (string, error)) (restore func()) {
	orig := currentWindowsUserFn
	currentWindowsUserFn = fn
	return func() { currentWindowsUserFn = orig }
}

// SetClientWriteFallbackForTest reverts the client-adapter writer hook
// (clients.WriteConfigFile) to a plain os.WriteFile-style fallback for
// the duration of a test that exercises adapter writes through
// t.TempDir() / t.Setenv("HOME"/"USERPROFILE", tmp) without
// hardenedTempDir.
//
// Production wires clients.WriteConfigFile to SecureWriteClientConfig
// in init() (see client_write_init.go); the parent-dir DACL gate that
// hook enforces rejects %TEMP%-backed paths on Windows. Tests that
// want to validate the secure-write pipeline use hardenedTempDir
// directly. Tests that pre-date Phase 5 and just want to exercise
// migrate/demigrate/scan flows can call this helper to fall back to
// the looser test-friendly writer.
//
// Returns a restore function that re-installs SecureWriteClientConfig.
// Always invoke via `t.Cleanup(restore)` or `defer restore()` so
// subsequent tests inherit the production hook.
func SetClientWriteFallbackForTest() (restore func()) {
	orig := clients.WriteConfigFile
	clients.WriteConfigFile = func(path string, contents []byte) error {
		if dir := filepath.Dir(path); dir != "" {
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return err
			}
		}
		return os.WriteFile(path, contents, 0o600)
	}
	return func() { clients.WriteConfigFile = orig }
}

// SetPortOwnerIdentityProbesForTest injects the two OS-level identity
// primitives (loopback port -> owner PID, and owner PID -> image basename)
// that AssertMCPFrontPortSupervisorOwned and defaultGUIPidportIdentityCheck
// depend on. A nil argument leaves that probe at its production default.
//
// It exists so a CROSS-PACKAGE test (internal/cli drives the whole
// `--reconcile-mcp-front` command) can exercise the REAL ownership gate
// instead of stubbing the gate itself out. That distinction is the point: a
// test that neutralized the gate would prove only that the gate is callable,
// never that it refuses an unsupervised listener. With these two probes
// injected, every other step of the chain — supervisor lock, canonical intent
// descriptor, supervisor-state row, PID liveness — runs its production code
// against files the test seeded.
//
// Same testing.Testing() production guard as SetDaemonStateRootForTest: a
// shipped binary that reached this surface would be able to forge a port
// ownership proof, so calling it outside a test binary panics loudly.
//
// Returns a restore function; always invoke via t.Cleanup / defer.
func SetPortOwnerIdentityProbesForTest(
	owner func(port int) (int, bool, error),
	image func(pid int) (string, bool),
) (restore func()) {
	if !testing.Testing() {
		panic("api.SetPortOwnerIdentityProbesForTest called outside a test binary — this hook can forge an OS-level port-ownership proof; it exists exclusively for tests")
	}
	origOwner := loopbackPortOwnerFn
	origImage := guiImageForPIDFn
	if owner != nil {
		loopbackPortOwnerFn = owner
	}
	if image != nil {
		guiImageForPIDFn = image
	}
	return func() {
		loopbackPortOwnerFn = origOwner
		guiImageForPIDFn = origImage
	}
}

// testClientShim adapts a caller-supplied TestClientIface to the
// package-private registerClient interface.
type testClientShim struct{ c TestClientIface }

func (a testClientShim) Exists() bool                                    { return a.c.Exists() }
func (a testClientShim) BackupKeep(keepN int) (string, error)            { return a.c.BackupKeep(keepN) }
func (a testClientShim) AddEntry(e clients.MCPEntry) error               { return a.c.AddEntry(e) }
func (a testClientShim) RemoveEntry(name string) error                   { return a.c.RemoveEntry(name) }
func (a testClientShim) GetEntry(name string) (*clients.MCPEntry, error) { return a.c.GetEntry(name) }
func (a testClientShim) AllStdioEntries() ([]clients.StdioEntry, error)  { return a.c.AllStdioEntries() }
func (a testClientShim) FindStdioLanguageServerEntries() ([]clients.LanguageServerStdioEntry, error) {
	return a.c.FindStdioLanguageServerEntries()
}
