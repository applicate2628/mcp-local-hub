"""Stage pinned source and inputs; never run tests or an installed Product."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
import zlib
_helper = Path(__file__).with_name("qualify_go.py")
if hashlib.sha256(_helper.read_bytes()).hexdigest() != "3d7eac69716fe2e863e37dd4cd45bc0847c011a02d40efbd227c89eb47b29180":
    raise RuntimeError("Qualification helper changed before import")
_spec = importlib.util.spec_from_file_location("qualify_go", _helper)
q = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(q)

BUNDLE = "24555661c97dbb42ece4c3185bde5942b9ea898d4e14b04df4a54000bfef4334"
RUNNER = "3d7eac69716fe2e863e37dd4cd45bc0847c011a02d40efbd227c89eb47b29180"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
CACHE = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\arch-input\source-arch")
PRESERVED = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")

def reject_reparse(path):
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.exists():
            st = current.lstat()
            if current.is_symlink() or getattr(st, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Reparse point in preparation path")

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != q.ROOT or len(sys.argv) != 2:
        raise RuntimeError("Unexpected preparation entry")
    phase = sys.argv[1]
    if phase not in ("stage", "architecture", "scheduler", "apply-architecture"):
        raise RuntimeError("Unknown phase")
    reject_reparse(q.ROOT)
    if q.sha(q.own("qualify_go.py").read_bytes()) != RUNNER:
        raise RuntimeError("Runner changed")
    raw = q.own("stage-inputs.json.zlib.b64").read_bytes()
    if q.sha(raw) != BUNDLE:
        raise RuntimeError("Bundle changed")
    payload = json.loads(zlib.decompress(base64.b64decode(raw, validate=True)))
    if payload["schema"] != 1 or len(payload["files"]) != 47:
        raise RuntimeError("Unexpected bundle schema/count")
    out = q.own("evidence/prepare-" + phase)
    out.mkdir(parents=True, exist_ok=False)
    runtime = q.own("runtime/prepare-" + phase)
    runtime.mkdir(parents=True, exist_ok=False)
    env = q.environment(runtime, {})
    receipt = {"phase": phase, "started_utc": q.now(), "completed": False,
               "runner_sha256": RUNNER, "bundle_sha256": BUNDLE,
               "script_sha256": q.sha(Path(__file__).read_bytes()), "commands": [],
               "native_scheduler_operations": False, "product_operations": False,
               "tests_executed": False, "dependency_downloads": False}

    def run(label, args, cwd, timeout=120, allowed=(0,)):
        row = {"label": label, "argv": list(map(str, args)), "cwd": str(cwd),
               "started_utc": q.now(), "settled": False, "timed_out": False,
               "whole_process_tree_deadline_enforced": False}
        receipt["commands"].append(row)
        q.save(out / (label + ".started.json"), row)
        child = None
        started = time.monotonic()
        try:
            with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
                child = subprocess.Popen(row["argv"], cwd=cwd, env=env,
                                         stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                row["pid"] = child.pid
                q.save(out / (label + ".launched.json"), row)
                try:
                    row["exit_code"] = child.wait(timeout=timeout)
                    row["settled"] = True
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    raise
        finally:
            if child is not None and not row["settled"]:
                row.update(process_tree_unresolved=True, retain_runtime_and_logs=True)
                child.terminate()
                row["exit_code"] = child.wait(timeout=10)
                row["settled"] = True
            row["seconds"] = round(time.monotonic() - started, 3)
            for stream in ("stdout", "stderr"):
                p = out / (label + "." + stream + ".log")
                if p.exists():
                    b = p.read_bytes()
                    row[stream] = {"bytes": len(b), "sha256": q.sha(b)}
            q.save(out / (label + ".receipt.json"), row)
        print(json.dumps({k: row.get(k) for k in ("label", "exit_code", "seconds")}), flush=True)
        if row["exit_code"] not in allowed or row["timed_out"]:
            raise RuntimeError("Preparation command failed: " + label)
        return (out / (label + ".stdout.log")).read_bytes(), row["exit_code"]

    try:
        for name, expected in q.PINS.items():
            if q.sha(Path(name).read_bytes()) != expected:
                raise RuntimeError("Existing tool changed: " + name)
        receipt["tools_sha256"] = q.PINS
        version, _ = run("go-version", [q.GO, "version"], q.ROOT)
        if version.decode().strip() != "go version go1.27.4 windows/amd64":
            raise RuntimeError("Unexpected Go version")
        if phase == "stage":
            for row in payload["files"]:
                if not row["path"].startswith("inputs/"):
                    raise RuntimeError("Input path escaped inputs")
                data = row["content_utf8"].encode("utf-8")
                if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                    raise RuntimeError("Input bytes changed")
                target = q.own(row["path"])
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as f:
                    f.write(data)
            candidates = [r for r in payload["files"] if r["path"].startswith(("inputs/new-", "inputs/architecture-control/")) and r["path"].endswith(".go")]
            before = [{k: r[k] for k in ("path", "bytes", "sha256")} for r in candidates]
            for r in candidates:
                p = q.own("inputs/preformat/" + r["path"].removeprefix("inputs/"))
                p.parent.mkdir(parents=True, exist_ok=True)
                with p.open("xb") as f:
                    f.write(q.own(r["path"]).read_bytes())
            run("gofmt-write", [q.GOFMT, "-w", *(q.own(r["path"]) for r in candidates)], q.ROOT)
            formatted, _ = run("gofmt-check", [q.GOFMT, "-l", *(q.own(r["path"]) for r in candidates)], q.ROOT)
            if formatted.strip():
                raise RuntimeError("Formatting remains inconsistent")
            after = [{"path": r["path"], "bytes": q.own(r["path"]).stat().st_size, "sha256": q.sha(q.own(r["path"]).read_bytes())} for r in candidates]
            receipt.update(preformat=before, formatted=after, formatting_changed=before != after)
        elif phase == "architecture":
            source = q.own("architecture")
            if source.exists():
                raise RuntimeError("Architecture source already exists")
            reject_reparse(CACHE)
            run("clone-cache", [GIT, "-c", "core.autocrlf=false", "clone", "--no-hardlinks", "--no-checkout", CACHE, source], q.ROOT)
            run("source-remote", [GIT, "remote", "set-url", "origin", "https://github.com/applicate2628/mcp-local-hub.git"], source)
            run("fetch-source", [GIT, "fetch", "--no-tags", "origin", payload["source_head"]], source, timeout=300)
            run("checkout-source", [GIT, "-c", "core.autocrlf=false", "checkout", "--detach", payload["source_head"]], source)
            tree, _ = run("source-tree", [GIT, "rev-parse", "HEAD^{tree}"], source)
            clean, _ = run("source-clean", [GIT, "status", "--porcelain"], source)
            if tree.decode().strip() != payload["source_tree"] or clean.strip():
                raise RuntimeError("Architecture checkout drift")
            receipt["source_inventory"] = q.check_files("architecture", payload["architecture_source_files"], True)
        elif phase == "scheduler":
            reject_reparse(PRESERVED)
            source = q.own("source")
            if source.exists():
                raise RuntimeError("Preserved destination already exists")
            head, _ = run("source-head", [GIT, "rev-parse", "HEAD"], PRESERVED)
            tree, _ = run("source-tree", [GIT, "rev-parse", "HEAD^{tree}"], PRESERVED)
            if head.decode().strip() != "858812988833a84368c60fba1540ae601155fa71" or tree.decode().strip() != "dba685c090952a93a80a1e82403c4646ad8aaed1":
                raise RuntimeError("Preserved source identity drift")
            for row in payload["scheduler_source_files"]:
                source_path = PRESERVED / row["path"]
                reject_reparse(source_path)
                data = source_path.read_bytes()
                if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                    raise RuntimeError("Preserved source changed: " + row["path"])
                target = q.own("source/" + row["path"])
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as f:
                    f.write(data)
            receipt["source_inventory"] = q.check_files("source", payload["scheduler_source_files"], True)
        else:
            receipt["before"] = q.check_files("architecture", payload["architecture_source_files"], True)
            updates = [r for r in payload["files"] if r["path"].startswith("inputs/new-architecture/")]
            if len(updates) != 4:
                raise RuntimeError("Wrong architecture update set")
            rows = {r["path"]: r for r in payload["architecture_source_files"]}
            for row in updates:
                path = row["path"].removeprefix("inputs/new-architecture/")
                data = q.own(row["path"]).read_bytes()
                if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                    raise RuntimeError("Candidate formatting needs readmission")
                q.own("architecture/" + path).write_bytes(data)
                rows[path] = {"path": path, "bytes": len(data), "sha256": q.sha(data)}
            receipt["after"] = q.check_files("architecture", sorted(rows.values(), key=lambda r: r["path"]), True)
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps({k: receipt.get(k) for k in ("phase", "completed", "error", "formatting_changed", "source_inventory")}), flush=True)

if __name__ == "__main__":
    main()
