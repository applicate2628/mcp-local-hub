"""Stage exact Serena test inputs; format only owned candidates and controls."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-next-20261122-e51f")
helper = Path(__file__).with_name("qualify_go.py")
if hashlib.sha256(helper.read_bytes()).hexdigest() != "3d7eac69716fe2e863e37dd4cd45bc0847c011a02d40efbd227c89eb47b29180":
    raise RuntimeError("Runner changed before import")
spec = importlib.util.spec_from_file_location("qualify_go", helper)
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 4:
        raise RuntimeError("Unexpected stage entry")
    mode, filename, expected = sys.argv[1:]
    if mode not in ("inputs", "plans"):
        raise RuntimeError("Unknown stage mode")
    raw = q.own(filename).read_bytes()
    if q.sha(raw) != expected:
        raise RuntimeError("Bundle differs")
    payload = json.loads(zlib.decompress(base64.b64decode(raw.strip(), validate=True)))
    if payload["schema"] != 1 or payload["source_head"] != "858812988833a84368c60fba1540ae601155fa71":
        raise RuntimeError("Source identity differs")
    rows = payload["files"]
    if len(rows) != (20 if mode == "inputs" else 4) or len({r["path"] for r in rows}) != len(rows):
        raise RuntimeError("Wrong staged count")
    out = q.own("evidence/prepare-serena-" + mode)
    out.mkdir(parents=True, exist_ok=False)
    receipt = {"phase": "prepare-serena-" + mode, "started_utc": q.now(), "completed": False,
               "bundle_sha256": expected, "script_sha256": q.sha(Path(__file__).read_bytes()),
               "commands": [], "native_scheduler_operations": False, "product_operations": False}
    try:
        for row in rows:
            allowed = row["path"].startswith("inputs/serena/") if mode == "inputs" else row["path"] in {"plans/serena-proof-red.json", "plans/serena-exit-red.json", "plans/serena-green.json", "plans/serena-index.json"}
            if not allowed:
                raise RuntimeError("Unadmitted staged path")
            data = row["content_utf8"].encode("utf-8")
            if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                raise RuntimeError("Staged file differs")
            p = q.own(row["path"])
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open("xb") as stream:
                stream.write(data)
        if mode == "inputs":
            runtime = q.own("runtime/prepare-serena-inputs")
            runtime.mkdir(parents=True, exist_ok=False)
            env = q.environment(runtime, {})
            candidates = [r for r in rows if r["path"].endswith(".go") and r["path"].startswith(("inputs/serena/candidate/", "inputs/serena/control-"))]
            if len(candidates) != 5:
                raise RuntimeError("Unexpected formatting scope")
            for p, expected_hash in q.PINS.items():
                if q.sha(Path(p).read_bytes()) != expected_hash:
                    raise RuntimeError("Formatter/tool changed")
            receipt["preformat"] = [{k: r[k] for k in ("path", "bytes", "sha256")} for r in candidates]
            for row in candidates:
                p = q.own("inputs/serena/preformat/" + row["path"].removeprefix("inputs/serena/"))
                p.parent.mkdir(parents=True, exist_ok=True)
                with p.open("xb") as stream:
                    stream.write(q.own(row["path"]).read_bytes())
            args = [str(q.GOFMT), "-w", *(str(q.own(r["path"])) for r in candidates)]
            with (out / "gofmt-write.stdout.log").open("xb") as stdout, (out / "gofmt-write.stderr.log").open("xb") as stderr:
                child = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                command = {"label": "gofmt-write", "argv": args, "pid": child.pid, "settled": False, "timed_out": False}
                receipt["commands"].append(command)
                try:
                    command["exit_code"] = child.wait(timeout=30)
                    command["settled"] = True
                except subprocess.TimeoutExpired:
                    command.update(timed_out=True, process_tree_unresolved=True, retain_runtime_and_logs=True)
                    child.terminate()
                    command["exit_code"] = child.wait(timeout=10)
                    command["settled"] = True
                    raise
            if command["exit_code"] != 0:
                raise RuntimeError("Formatter failed")
            check = {"label": "gofmt-check", "tool": "gofmt", "args": ["-l", *(str(q.own(r["path"])) for r in candidates)], "timeout_seconds": 30, "expected_exit_code": 0}
            result = q.execute(out, env, check, ROOT)
            receipt["commands"].append(result)
            if not result["oracle_pass"]:
                raise RuntimeError("Format check failed")
            receipt["formatted"] = [{"path": r["path"], "bytes": q.own(r["path"]).stat().st_size, "sha256": q.sha(q.own(r["path"]).read_bytes())} for r in candidates]
            receipt["formatting_changed"] = receipt["formatted"] != receipt["preformat"]
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps(receipt))

if __name__ == "__main__":
    main()
