"""Deterministic manifests for exact, reviewed source and test selectors."""
import base64
import hashlib
import json
from pathlib import Path, PureWindowsPath
import zlib

ROOT = PureWindowsPath(r"D:\dev\ChatGPT\mcp-p0-next-20261122-e51f")
HERE = Path(__file__).resolve().parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()

def write(relative, raw):
    p = HERE / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("xb") as f:
        f.write(raw)
    return {"path": relative.removeprefix("inputs/"), "bytes": len(raw), "sha256": sha(raw)}

def main():
    data = json.loads(zlib.decompress(base64.b64decode((HERE / "stage-inputs.json.zlib.b64").read_bytes())))
    runner = sha((HERE / "qualify_go.py").read_bytes())
    input_rows = [{"path": r["path"].removeprefix("inputs/"), "bytes": r["bytes"], "sha256": r["sha256"]} for r in data["files"]]
    def overlay(name, mapping):
        raw = encode({"Replace": {str(ROOT / a): str(ROOT / b) for a, b in sorted(mapping.items())}})
        input_rows.append(write("inputs/" + name + ".json", raw))
        return str(ROOT / "inputs" / (name + ".json"))

    arch_control = overlay("architecture-control-overlay", {"architecture/internal/gui/lsp_router_control_test.go": "inputs/architecture-control/internal/gui/lsp_router_control_test.go"})
    scheduler = {"source/" + r["path"].removeprefix("inputs/scheduler/"): r["path"] for r in data["files"] if r["path"].startswith("inputs/scheduler/")}
    scheduler["source/internal/api/scheduler_upgrade_snapshot_test.go"] = "inputs/new-scheduler/internal/api/scheduler_upgrade_snapshot_test.go"
    scheduler_red = overlay("scheduler-red-overlay", scheduler)
    scheduler["source/internal/api/scheduler_mgmt.go"] = "inputs/new-scheduler/internal/api/scheduler_mgmt.go"
    scheduler_green = overlay("scheduler-green-overlay", scheduler)
    def test(label, package, selector, outcomes, overlay_path=None, exit_code=0):
        args = ["test", "-buildvcs=false", "-p=2", "-json", "-race", "-count=1", "-timeout=120s", "-parallel=1"]
        if overlay_path:
            args += ["-overlay", overlay_path]
        args += ["-run", selector, package]
        return {"label": label, "tool": "go", "args": args, "timeout_seconds": 360,
                "expected_exit_code": exit_code, "required_tests": outcomes}
    def command(label, args, exit_code=0):
        return {"label": label, "tool": "go", "args": args, "timeout_seconds": 360, "expected_exit_code": exit_code}
    def plan(phase, source, rows, head, tree, commands):
        value = {"schema": 1, "runner_sha256": runner, "native_scheduler_operations": False,
                 "source_directory": source, "source_head": head, "source_tree": tree,
                 "source_files": rows, "inputs_directory": "inputs", "input_files": sorted(input_rows, key=lambda r: r["path"]),
                 "environment": {}, "phase": phase, "commands": commands}
        raw = encode(value)
        write("plans/" + phase + ".json", raw)
        return {"phase": phase, "plan": "plans/" + phase + ".json", "sha256": sha(raw)}
    arch_root = "TestLSPRouterControlRoutesKeepServerDependenciesSeparate"
    arch_red = test("lsp-red", "./internal/gui", "^" + arch_root + "$", {
        "pass": [arch_root + "/second"], "fail": [arch_root + "/first", arch_root, "PACKAGE:mcp-local-hub/internal/gui"], "skip": []}, arch_control, 1)
    specs = [plan("architecture-red", "architecture", data["architecture_source_files"], data["source_head"], data["source_tree"], [arch_red])]
    arch_rows = {r["path"]: r for r in data["architecture_source_files"]}
    for r in data["files"]:
        if r["path"].startswith("inputs/new-architecture/"):
            path = r["path"].removeprefix("inputs/new-architecture/")
            arch_rows[path] = {"path": path, "bytes": r["bytes"], "sha256": r["sha256"]}
    # Existing route roots are frozen from the exact test file, plus new owner regression.
    import re
    test_text = next(r["content_utf8"] for r in data["files"] if r["path"] == "inputs/new-architecture/internal/gui/lsp_router_control_test.go")
    arch_tests = re.findall(r"^func (Test\w+)\(t \*testing.T\)", test_text, re.M)
    arch_green = test("lsp-green", "./internal/gui", "^(" + "|".join(arch_tests) + ")$", {
        "pass": [*arch_tests, arch_root + "/first", arch_root + "/second", "PACKAGE:mcp-local-hub/internal/gui"], "fail": [], "skip": []})
    common = ["--root", ".", "--policy", "architecture/policy.yaml"]
    specs.append(plan("architecture-green", "architecture", sorted(arch_rows.values(), key=lambda r: r["path"]), data["source_head"], data["source_tree"], [
        arch_green,
        command("arch-scan", ["run", "./tools/archcheck", "scan", *common]),
        command("arch-verify", ["run", "./tools/archcheck", "verify", *common, "--owners", "architecture/owners.yaml", "--baseline", "architecture/baseline.yaml", "--workers", "architecture/workers.yaml"], 1),
        command("build", ["build", "./..."]), command("vet", ["vet", "./..."]),
    ]))
    root = "TestSchedulerUpgradeSnapshotAdmission"
    cases = ["permission_denied", "unavailable", "canceled", "partial_failure", "unsupported", "nil_success", "empty_success", "conflicting_absence", "existing", "absent", "wrapped_absent", "absent_conflict", "delete_denied"]
    red = {"pass": [], "fail": [root, root + "/server", root + "/lazy_proxy", "PACKAGE:mcp-local-hub/internal/api"], "skip": []}
    for kind in ("server", "lazy_proxy"):
        failures = set(cases) - {"existing", "delete_denied"} if kind == "server" else {"nil_success", "empty_success", "conflicting_absence", "absent", "wrapped_absent", "absent_conflict"}
        for name in cases:
            red["fail" if name in failures else "pass"].append(root + "/" + kind + "/" + name)
    green = {"pass": [root, root + "/server", root + "/lazy_proxy", "PACKAGE:mcp-local-hub/internal/api"] + [root + "/" + k + "/" + n for k in ("server", "lazy_proxy") for n in cases], "fail": [], "skip": []}
    adjacent = ["TestSchedulerUpgrade_TaskRoutingPredicates", "TestSchedulerUpgrade_HyphenatedDaemon_RecreatesWithCorrectArgs", "TestUpgradeWorkspaceWeeklyRefreshTask_AbortOnExportError", "TestUpgradeLazyProxyTask_AbortOnExportError", "TestUpgradeHelpers_AllowNotFoundExport", "TestSchedulerUpgradePreservesWeeklyTrigger", "TestParseWeeklyRefreshSchedule", "TestEnsureWeeklyRefreshTask_PreservesPriorOnCreateFailure"]
    outcomes = {"pass": adjacent + ["TestSchedulerUpgrade_TaskRoutingPredicates/" + n for n in ("global-weekly-refresh", "workspace-weekly-refresh", "lazy-proxy", "global-daemon")] + ["PACKAGE:mcp-local-hub/internal/api"], "fail": [], "skip": []}
    specs.append(plan("scheduler-red-green", "source", data["scheduler_source_files"], "858812988833a84368c60fba1540ae601155fa71", "dba685c090952a93a80a1e82403c4646ad8aaed1", [
        test("snapshot-red", "./internal/api", "^" + root + "$", red, scheduler_red, 1),
        test("snapshot-green", "./internal/api", "^" + root + "$", green, scheduler_green),
        test("snapshot-adjacent", "./internal/api", "^(" + "|".join(adjacent) + ")$", outcomes, scheduler_green),
        command("build", ["build", "-buildvcs=false", "-overlay", scheduler_green, "./..."]),
        command("vet", ["vet", "-buildvcs=false", "-overlay", scheduler_green, "./..."]),
    ]))
    write("plans/index.json", encode(specs))
    print(json.dumps(specs))

if __name__ == "__main__":
    main()
