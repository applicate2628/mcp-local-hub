"""Export completed owned evidence without reading source or runtime state."""
import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-next-20261122-e51f")
GROUPS = {
    "serena": ["prepare-serena-inputs", "prepare-serena-plans", "serena-proof-red", "serena-exit-red", "serena-green"],
    "scheduler": ["prepare-stage", "prepare-scheduler", "scheduler-red-green"],
    "architecture": ["prepare-stage", "prepare-architecture", "prepare-apply-architecture", "architecture-red", "architecture-green"],
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 2 or sys.argv[1] not in GROUPS:
        raise RuntimeError("Unknown export scope")
    group = sys.argv[1]
    paths = []
    for phase in GROUPS[group]:
        receipt_path = ROOT / "evidence" / phase / "receipt.json"
        receipt = json.loads(receipt_path.read_text())
        if not receipt.get("completed"):
            raise RuntimeError("Qualification not complete: " + phase)
        for command in receipt.get("commands", []):
            if command.get("timed_out") or not command.get("settled"):
                raise RuntimeError("Unsettled command requires explicit recovery")
        paths.extend(p for p in receipt_path.parent.rglob("*") if p.is_file())
    phases = [p for p in GROUPS[group] if not p.startswith("prepare-")]
    plans = [ROOT / "plans" / (p + ".json") for p in phases]
    for plan_path in plans:
        plan = json.loads(plan_path.read_text())
        paths.append(plan_path)
        for row in plan["input_files"]:
            p = ROOT / plan["inputs_directory"] / row["path"]
            data = p.read_bytes()
            if len(data) != row["bytes"] or sha(data) != row["sha256"]:
                raise RuntimeError("Input changed before export: " + row["path"])
            paths.append(p)
    paths.extend(ROOT / name for name in ("qualify_go.py", "prepare.py", "make_plans.py", "export_evidence.py"))
    if group == "serena":
        paths.append(ROOT / "stage_serena.py")
        paths.extend(p for p in (ROOT / "inputs/serena/preformat").rglob("*") if p.is_file())
    paths = sorted(set(paths), key=lambda p: p.relative_to(ROOT).as_posix())
    rows = []
    out = ROOT / "exports" / group
    out.mkdir(parents=True, exist_ok=False)
    target = out / "raw-evidence.zip"
    with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in paths:
            rel = p.relative_to(ROOT).as_posix()
            if p.is_symlink() or getattr(p.lstat(), "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Reparse export input")
            raw = p.read_bytes()
            rows.append({"path": rel, "bytes": len(raw), "sha256": sha(raw)})
            entry = zipfile.ZipInfo(rel, (2026, 11, 22, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, raw)
        archive.writestr("manifest.json", json.dumps({"schema": 1, "group": group, "files": rows}, indent=2) + "\n")
    raw = target.read_bytes()
    b64 = base64.b64encode(raw)
    chunks = []
    for i, start in enumerate(range(0, len(b64), 180000)):
        part = b64[start:start + 180000]
        path = out / ("part-%03d.b64" % i)
        path.write_bytes(part)
        chunks.append({"path": path.name, "bytes": len(part), "sha256": sha(part)})
    meta = {"group": group, "files": len(rows), "zip_bytes": len(raw), "zip_sha256": sha(raw), "chunks": chunks}
    (out / "transport.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(meta))

if __name__ == "__main__":
    main()
