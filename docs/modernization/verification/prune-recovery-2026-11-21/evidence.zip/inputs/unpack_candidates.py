"""Materialize the exact reviewed candidate, then format only those Go files."""
import sys
sys.dont_write_bytecode = True
import base64, gzip, hashlib, json, os, subprocess
from pathlib import Path
ROOT = Path(r"D:\dev\ChatGPT\mcp-pr660-prune-20261121-247107d5")
EXPECTED = [
    "internal/api/install.go", "internal/api/install_task_rollback.go",
    "internal/api/prune_tasks_test.go", "internal/api/install_prune_recovery_test.go",
]
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
if Path(__file__).resolve().parent != ROOT or os.name != "nt":
    raise RuntimeError("Unexpected task root or platform")
transport = (ROOT / "candidate-utf8-payload.b64").read_bytes()
if sha(transport) != "cfd2d6d9cc63fa8e5b0c4314524e12ac899a171f5d75d3345b00776081437666":
    raise RuntimeError("Transport differs from reviewed bytes")
raw = gzip.decompress(base64.b64decode(transport, validate=True))
if sha(raw) != "5f0c2bb32cf0a6b67b16d34c49d268fbc124f5d1789a9f760d3543092169f1d3":
    raise RuntimeError("Payload differs from reviewed bytes")
rows = json.loads(raw)
if [row["path"] for row in rows] != EXPECTED:
    raise RuntimeError("Unexpected candidate paths")
candidate = ROOT / "scopes/prune/candidate"
candidate.mkdir(parents=True, exist_ok=False)
out = ROOT / "format"
out.mkdir(exist_ok=False)
tmp = out / "tmp"
tmp.mkdir()
paths = []
for row in rows:
    body = row["content"].encode("utf-8")
    if sha(body) != row["sha256"]:
        raise RuntimeError("Candidate content identity mismatch")
    path = candidate / row["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(body)
    paths.append(path)
gofmt = Path(r"C:\msys64\ucrt64\bin\gofmt.exe")
receipt = {"transport_sha256": sha(transport), "payload_sha256": sha(raw),
           "gofmt_sha256": sha(gofmt.read_bytes()), "paths": EXPECTED,
           "before": {row["path"]: row["sha256"] for row in rows}}
env = os.environ.copy()
env.update(TEMP=str(tmp), TMP=str(tmp), TMPDIR=str(tmp), GOTMPDIR=str(tmp))
with (out/"stdout.log").open("xb") as stdout, (out/"stderr.log").open("xb") as stderr:
    result = subprocess.run([str(gofmt), "-w", *map(str, paths)], cwd=ROOT,
                            env=env, stdin=subprocess.DEVNULL, stdout=stdout,
                            stderr=stderr, timeout=60, check=False)
receipt["exit_code"] = result.returncode
receipt["after"] = {name: sha(path.read_bytes()) for name,path in zip(EXPECTED,paths)}
with (out/"receipt.json").open("x",encoding="utf-8",newline="\n") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt),flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
