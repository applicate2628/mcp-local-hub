"""Export four fixed P0 evidence families without executing any child process.

Run once from ROOT with the existing interpreter:
  python export_p0_evidence.py <exact-script-sha256>

All inputs are admitted before the new p0-export-v1 directory is created.
Existing or partial exports are never overwritten or resumed. Archive payloads
are immutable receipts, captured streams and manifest-pinned source inputs;
runtime/profile data, executables and the two private audits are excluded.
"""
import sys
sys.dont_write_bytecode = True

import base64
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import zipfile
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5")
DESTINATION = ROOT / "evidence/p0-export-v1"
ROOTS = {"base": ROOT, "preserved": ROOT / "preserved-input"}
SOURCE_IDENTITIES = {
    "base": ("75dbc6406123e22468f168b861d5e0622c9d5769", "cb3eec77c23f9400be962d91c9f23834b84f7643"),
    "preserved": ("858812988833a84368c60fba1540ae601155fa71", "dba685c090952a93a80a1e82403c4646ad8aaed1"),
}
SCOPES = {
    "canonical": (
        ("base", "helper-control"), ("base", "helper-candidate"),
        ("base", "helper-candidate-formatted"), ("base", "helper-missing-formatted"),
        ("base", "p0-build-vet"), ("base", "private-proof-probe"),
        ("base", "private-proof-control"), ("base", "private-proof-candidate"),
        ("base", "private-proof-missing-fixture"),
        ("preserved", "preserved-build-vet"), ("preserved", "composed-build-vet"),
    ),
    "api": (
        ("preserved", "api-control"), ("preserved", "api-candidate"),
        ("preserved", "native-proof-api-control"),
        ("preserved", "native-proof-v2-api-control"),
        ("preserved", "native-proof-v2-api-candidate"),
    ),
    "cli": (
        ("preserved", "cli-control"), ("preserved", "cli-candidate"),
        ("preserved", "cli-control-oracle"), ("preserved", "cli-owned-helpers"),
        ("preserved", "cli-path-checks"), ("preserved", "native-proof-v2-cli-control"),
        ("preserved", "native-proof-v2-cli-candidate"),
    ),
    "shell": (("preserved", "shell-candidate"),),
}
SCRIPTS = {
    "base": ("p0_runner.py", "prove_private_helper.py", "prove_private_helper_formatted.py"),
    "preserved": ("p0_preserved_runner.py", "p0_preserved_runner_v2.py", "p0_shell_runner.py",
                  "prove_api_cli_helpers.py", "prove_api_cli_helpers_v2.py"),
}
MANIFEST_DIRECTORIES = {
    "base": {"helper-control", "helper-candidate", "helper-candidate-formatted", "helper-missing-formatted"},
    "preserved": {"controls", "api-staged", "cli-staged", "shell-staged", "composed"},
}
PRIVATE_EXCLUSIONS = {"formatter-environment-audit.json", "bash-path-audit.stderr.txt"}
RUNTIME_NAMES = {"runtime", "tmp", "profile", "appdata", "localappdata", "gopath",
                 "gocache", "gomodcache", "telemetry", "xdg-cache", "xdg-config", "xdg-data"}
CASE_NAMES = {"cooperative", "invalid-mode", "invalid-marker", "extra-argument", "missing-fixture"}
PLAIN_ARTIFACTS = {"receipt.json", "receipt-initial.json", "overlay.json", "case-started.json",
                   "case-receipt.json", "launched.json", "stdout.bin", "stderr.bin"}
ARTIFACT = re.compile(r"[a-z][a-z0-9-]{0,63}\.(?:(?:started|launched|receipt|oracle)\.json|(?:stdout|stderr)\.log)\Z")
MAX_FILE_BYTES = 32 << 20
MAX_ARCHIVE_BYTES = 128 << 20
MAX_ARCHIVE_FILES = 10000
CHUNK_CHARACTERS = 24000
ZIP_DATE = (2026, 11, 21, 0, 0, 0)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def save_new(path, value):
    with path.open("xb") as stream:
        stream.write(json_bytes(value))


def owned(path):
    parts = path.relative_to(ROOT).parts
    require(not any(p in {".", ".."} for p in parts), "Path aliases the export scope")
    current = ROOT
    for part in (None, *parts):
        if part is not None:
            current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        require(not current.is_symlink() and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Reparse point in export scope: " + str(current))
    return path


def read_file(path):
    require(path.name.lower() not in PRIVATE_EXCLUSIONS, "Private audit cannot be read into an archive")
    path = owned(path)
    require(path.is_file() and path.stat().st_size <= MAX_FILE_BYTES, "Missing or oversized input: " + str(path))
    raw = path.read_bytes()
    require(len(raw) <= MAX_FILE_BYTES, "Input grew beyond its bound")
    return raw


def relative_go(value):
    require(isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_./-]+\.go", value), "Invalid candidate path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value
            and not any(p.lower() in {".", "..", ".git", "runtime", "gocache", "gomodcache"} for p in path.parts),
            "Candidate path escapes its manifest")
    return value


def add(entries, pins, name, path, expected=None):
    raw = read_file(path)
    require(expected is None or sha(raw) == expected, "Pinned input changed: " + str(path))
    if name in entries:
        require(entries[name] == raw, "Conflicting archive path: " + name)
    entries[name] = raw
    key = str(path)
    require(key not in pins or pins[key] == sha(raw), "Input changed during admission")
    pins[key] = sha(raw)
    require(len(entries) <= MAX_ARCHIVE_FILES and sum(map(len, entries.values())) <= MAX_ARCHIVE_BYTES,
            "Evidence family exceeds its fixed export bound")
    return raw


def artifacts(directory, cases):
    """Read only direct evidence leaves and declared direct case directories."""
    result, excluded = {}, []
    require(owned(directory).is_dir(), "Missing evidence directory: " + str(directory))
    for parent, prefix in [(directory, "")] + [(directory / name, name + "/") for name in cases]:
        require(owned(parent).is_dir(), "Missing declared case directory: " + str(parent))
        for path in sorted(parent.iterdir(), key=lambda p: p.name):
            owned(path)
            name = path.name
            if name.lower() in PRIVATE_EXCLUSIONS or path.suffix.lower() == ".exe" or name in RUNTIME_NAMES:
                excluded.append(prefix + name)
                continue
            if path.is_dir():
                require(not prefix and name in cases, "Unexpected evidence subdirectory: " + str(path))
                continue
            require(path.is_file() and (name in PLAIN_ARTIFACTS or ARTIFACT.fullmatch(name)),
                    "Unexpected evidence leaf: " + str(path))
            result[prefix + name] = read_file(path)
    return result, sorted(excluded)


def process_rows(value):
    if isinstance(value, dict):
        if "settled" in value:
            yield value
        for item in value.values():
            yield from process_rows(item)
    elif isinstance(value, list):
        for item in value:
            yield from process_rows(item)


def settled(row):
    require(row.get("settled") is True and row.get("timed_out") is False
            and type(row.get("exit_code")) is int and not row.get("process_tree_unresolved")
            and not any(k in row for k in ("error_type", "event_error_type", "termination_error",
                                           "source_after_error", "stdout_capture_error", "stderr_capture_error")),
            "Receipt has an unsettled, timed-out or failed capture")


def verify_streams(row, files):
    for stream in ("stdout", "stderr"):
        if "label" in row:
            suffix = row["label"] + "." + stream + ".log"
            matches = [raw for name, raw in files.items() if PurePosixPath(name).name == suffix]
        else:
            name = row["case"] + "/" + stream + ".bin"
            matches = [files[name]] if name in files else []
        require(len(matches) == 1 and row.get(stream, {}).get("bytes") == len(matches[0])
                and row[stream].get("sha256") == sha(matches[0]), "Captured stream missing or changed")


def verify_launches(files):
    for name, raw in files.items():
        path = PurePosixPath(name)
        if path.name == "case-started.json" or not (path.name == "launched.json"
                or path.name.endswith(".started.json") or path.name.endswith(".launched.json")):
            continue
        final_name = "receipt.json" if path.name == "launched.json" else re.sub(r"\.(?:started|launched)\.json$", ".receipt.json", path.name)
        final = str(path.with_name(final_name))
        require(final in files, "Started command has no terminal receipt: " + name)
        before, after = json.loads(raw), json.loads(files[final])
        settled(after)
        require(before.get("started_utc") == after.get("started_utc")
                and ("pid" not in before or before["pid"] == after.get("pid")), "Launch and terminal identity differ")


def declared_failure(alias, phase, receipt):
    require(receipt.get("completed") is False and receipt.get("state") == "failed"
            and receipt.get("error_type") == "RuntimeError", "Undeclared unsuccessful phase")
    before = receipt.get("source_before")
    require(isinstance(before, dict) and receipt.get("source_final") == before
            and (before.get("head"), before.get("tree")) == SOURCE_IDENTITIES[alias],
            "Declared failure has inconsistent source observations")
    if (alias, phase) == ("base", "helper-candidate"):
        rows = receipt.get("commands")
        require(receipt.get("error") == "Candidate needs formatting; no source mutation performed"
                and isinstance(rows, list) and len(rows) == 1 and rows[0].get("label") == "gofmt-check"
                and rows[0].get("exit_code") == 0 and rows[0].get("stdout", {}).get("bytes", 0) > 0,
                "Failed candidate is not the declared format refusal")
        return "format-refusal-before-tests"
    if (alias, phase) == ("preserved", "native-proof-api-control"):
        cases = receipt.get("cases")
        require(receipt.get("commands") == [] and isinstance(cases, list) and len(cases) == 1
                and cases[0].get("case") == "cooperative" and "execution" not in cases[0]
                and cases[0].get("oracle_matched") is False
                and cases[0].get("error") == "Owned telemetry mode is not off"
                and receipt.get("error") == "cooperative: Owned telemetry mode is not off",
                "Failed proof is not the declared prelaunch telemetry refusal")
        return "telemetry-encoding-refusal-before-helper"
    raise RuntimeError("Unsuccessful phase is not an admitted declared failure: " + phase)


def add_manifest(alias, receipt, entries, pins):
    if "manifest_path" not in receipt:
        return
    root = ROOTS[alias]
    path = Path(receipt["manifest_path"])
    relative = path.relative_to(root)
    parts = relative.parts
    require(len(parts) == 3 and parts[0] == "manifests" and parts[1] in MANIFEST_DIRECTORIES[alias]
            and parts[2] in {"manifest.json", "build-vet.json"}, "Manifest is outside the fixed input selection")
    prefix = "inputs/" + alias + "/"
    raw = add(entries, pins, prefix + relative.as_posix(), path, receipt["manifest_sha256"])
    manifest = json.loads(raw)
    require((manifest.get("source_head"), manifest.get("source_tree")) == SOURCE_IDENTITIES[alias],
            "Manifest has another source identity")
    require(isinstance(manifest.get("files"), list) and 0 < len(manifest["files"]) <= 64,
            "Manifest lacks a bounded explicit candidate selection")
    for item in manifest["files"]:
        candidate_relative = relative_go(item["path"])
        candidate = path.parent / "candidate" / candidate_relative
        payload = add(entries, pins, prefix + candidate.relative_to(root).as_posix(), candidate, item["candidate_sha256"])
        blob = hashlib.sha1(b"blob " + str(len(payload)).encode("ascii") + b"\0" + payload).hexdigest()
        require(blob == item["candidate_git_blob"], "Candidate Git blob differs from its manifest")


def add_scripts(alias, receipt, entries, pins, script_cache):
    required = {receipt[key] for key in ("runner_sha256", "script_sha256", "proof_script_sha256") if key in receipt}
    for digest in required:
        matches = []
        for name in SCRIPTS[alias]:
            path = ROOTS[alias] / name
            key = str(path)
            if key not in script_cache:
                script_cache[key] = sha(read_file(path))
            if script_cache[key] == digest:
                matches.append(path)
        require(len(matches) == 1, "Pinned execution/proof script is absent or ambiguous")
        path = matches[0]
        add(entries, pins, "inputs/" + alias + "/" + path.name, path, digest)


def collect_phase(alias, phase, entries, pins, script_cache):
    directory = ROOTS[alias] / "evidence" / phase
    receipt_raw = read_file(directory / "receipt.json")
    receipt = json.loads(receipt_raw)
    if phase.startswith("private-proof-"):
        require(receipt.get("stage") == phase.removeprefix("private-proof-"), "Private proof stage mismatch")
    else:
        require(receipt.get("phase") == phase, "Phase receipt mismatch")
    require(not receipt.get("process_tree_unresolved") and "source_final_error" not in receipt
            and "final_identity_error" not in receipt, "Unresolved or inconsistent phase cannot be exported")
    failure = None if receipt.get("completed") is True else declared_failure(alias, phase, receipt)
    cases = [case["case"] for case in receipt.get("cases", [])]
    require(len(cases) == len(set(cases)) and set(cases).issubset(CASE_NAMES), "Unexpected case selection")
    files, excluded = artifacts(directory, cases)
    require(files.get("receipt.json") == receipt_raw, "Phase receipt changed during admission")
    for case in receipt.get("cases", []):
        final_name = "receipt.json" if "settled" in case else "case-receipt.json"
        relative = case["case"] + "/" + final_name
        require(relative in files and json.loads(files[relative]) == case, "Case receipt differs from aggregate")
        if failure is None:
            require(case.get("oracle_matched") is True, "Completed proof contains an unmatched case")
    rows = {sha(json_bytes(row)): row for row in process_rows(receipt)}
    for row in rows.values():
        settled(row)
        verify_streams(row, files)
    verify_launches(files)
    for relative, raw in files.items():
        name = "evidence/" + alias + "/" + phase + "/" + relative
        add(entries, pins, name, directory / relative, sha(raw))
    add_manifest(alias, receipt, entries, pins)
    add_scripts(alias, receipt, entries, pins, script_cache)
    return {"root": alias, "phase": phase, "completed": receipt["completed"],
            "declared_failure": failure, "receipt_sha256": sha(receipt_raw),
            "distinct_direct_child_receipts": len(rows), "excluded_relative_paths": excluded}


def collect_family(family, exporter_sha, script_cache):
    entries, pins, phases = {}, {}, []
    for alias, phase in SCOPES[family]:
        phases.append(collect_phase(alias, phase, entries, pins, script_cache))
    add(entries, pins, "inputs/export_p0_evidence.py", Path(__file__), exporter_sha)
    inventory = [{"path": name, "bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(entries.items())]
    manifest = {
        "schema": 1, "family": family, "exporter_sha256": exporter_sha, "phases": phases,
        "files": inventory, "private_audits_excluded_by_basename": sorted(PRIVATE_EXCLUSIONS),
        "manifest_self_identity": "MANIFEST.json length/SHA256 are recorded in sibling transfer metadata and export receipt",
        "qualification_scope": "Copies recorded results; declared failed checks remain failed; no new source or process-tree qualification",
    }
    entries["MANIFEST.json"] = json_bytes(manifest)
    return entries, pins, phases


def zip_bytes(entries):
    destination = io.BytesIO()
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for path, raw in sorted(entries.items()):
            info = zipfile.ZipInfo(path, ZIP_DATE)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.extra = b""
            info.comment = b""
            package.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return destination.getvalue()


def write_archive(family, entries, phases):
    name = family + "-evidence"
    archive = DESTINATION / (name + ".zip")
    receipt = {"schema": 1, "family": family, "completed": False, "phases": phases,
               "native_execution": False, "started_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    error = None
    try:
        raw = zip_bytes(entries)
        with archive.open("xb") as stream:
            stream.write(raw)
        require(sha(archive.read_bytes()) == sha(raw), "Written archive differs from admitted bytes")
        encoded = base64.b64encode(raw).decode("ascii")
        metadata = {"schema": 1, "family": family, "archive": archive.name, "bytes": len(raw),
                    "sha256": sha(raw), "entries": len(entries), "encoding": "zip+base64",
                    "chunk_characters": CHUNK_CHARACTERS,
                    "chunks": (len(encoded) + CHUNK_CHARACTERS - 1) // CHUNK_CHARACTERS,
                    "manifest_bytes": len(entries["MANIFEST.json"]),
                    "manifest_sha256": sha(entries["MANIFEST.json"]),
                    "python_version": sys.version, "zlib_version": zlib.ZLIB_VERSION}
        save_new(DESTINATION / (name + ".transfer.json"), metadata)
        transfer = DESTINATION / (name + ".transfer.txt")
        with transfer.open("x", encoding="ascii", newline="\n") as stream:
            stream.write(json.dumps(metadata, sort_keys=True) + "\n")
            for offset in range(0, len(encoded), CHUNK_CHARACTERS):
                stream.write(encoded[offset:offset + CHUNK_CHARACTERS] + "\n")
        transfer_raw = transfer.read_bytes()
        receipt.update(completed=True, archive=metadata,
                       transfer={"path": transfer.name, "bytes": len(transfer_raw), "sha256": sha(transfer_raw)})
    except BaseException as failure:
        error = failure
        receipt.update(error_type=type(failure).__name__, error=str(failure))
    finally:
        receipt["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        save_new(DESTINATION / (name + ".receipt.json"), receipt)
    if error is not None:
        raise error
    return receipt


def main():
    require(os.name == "nt" and not sys.flags.optimize and Path(__file__).resolve().parent == ROOT,
            "Run the reviewed exporter from its owned Windows task root")
    require(len(sys.argv) == 2 and re.fullmatch(r"[0-9a-f]{64}", sys.argv[1]), "Expected the exact exporter SHA256")
    exporter_sha = sys.argv[1]
    require(sha(read_file(Path(__file__))) == exporter_sha, "Exporter differs from reviewed bytes")
    require(not owned(DESTINATION).exists(), "Export destination exists; partial exports are never recreated")
    script_cache = {}
    families = {name: collect_family(name, exporter_sha, script_cache) for name in SCOPES}
    for _, pins, _ in families.values():
        for path, digest in pins.items():
            require(sha(read_file(Path(path))) == digest, "Input changed before export: " + path)
    DESTINATION.mkdir(exist_ok=False)
    summary = {"schema": 1, "exporter_sha256": exporter_sha, "completed": False,
               "native_execution": False, "archives": []}
    error = None
    try:
        for family, (entries, _, phases) in families.items():
            summary["archives"].append(write_archive(family, entries, phases))
        summary["completed"] = True
    except BaseException as failure:
        error = failure
        summary.update(error_type=type(failure).__name__, error=str(failure))
    finally:
        save_new(DESTINATION / "receipt.json", summary)
        print(json.dumps({"completed": summary["completed"], "archives": len(summary["archives"]),
                          "destination": str(DESTINATION), "error": summary.get("error")}), flush=True)
    if error is not None:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
