"""Native proof of the exact API vault and CLI CodeGraph helper entry points.

Run from the preserved-input task root with the existing Python interpreter:
  python prove_api_cli_helpers_v2.py <stage> <binary-sha256> <script-sha256>
Stages: api-control, api-candidate, cli-control, cli-candidate.

All binaries and build manifests are frozen below. The execution owner is
imported by hash; its offline environment, telemetry directory and retained
Popen-handle capture implementation are reused without changing that file.
Controls run only the cooperative helper. Candidates also reject an invalid
marker and one extra argument with TEMP/TMP pointing to an owned regular file.
Only the stated direct children are selected: no server, scheduler, model,
descendant, native leaf/reparse rejection or whole-tree lifetime qualification.
Version 2 uses a separate native-proof-v2 namespace and admits the two exact
off mode-file encodings written with LF or Windows CRLF line endings.
"""
import sys
sys.dont_write_bytecode = True

import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input")
SOURCE = ROOT / "source-preserved"
BASE = "858812988833a84368c60fba1540ae601155fa71"
BASE_TREE = "dba685c090952a93a80a1e82403c4646ad8aaed1"
OWNER_NAME = "p0_preserved_runner_v2.py"
OWNER_SHA256 = "b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641"
CONTROL_MANIFEST_SHA256 = "011a8f8efa3e9b960efb3845573d31ea3669a5897963c51759fe3a7a47697401"
STAGES = {
    "api-control": (
        "5573fc5f1ec2668e0652217a16fa1b3187c701b8d38b89cf38de994256c02f13",
        CONTROL_MANIFEST_SHA256,
    ),
    "api-candidate": (
        "1326f26f2b3fbe2ef4a91d41a497f8a223b1e15cb18440e682c9923fd41fce0f",
        "6e419ddce2447add5ddaadd7023fcf9052c4237122eb8383bc0cd93bd27cddbc",
    ),
    "cli-control": (
        "4429c449d309ff931c1458db77d187aa70f5227a9f5c26b830b0daf922da6197",
        CONTROL_MANIFEST_SHA256,
    ),
    "cli-candidate": (
        "27d57dda3c151c0ab676d75130bceaa32b015e8735cdfe5543f47f57908127a4",
        "6900e167e575aefa58428fe1091452939ff3d0362bfff128f6389eea263c47b1",
    ),
}
API_SELECTOR = "-test.run=^TestVaultFlockHelperProcess$"
CLI_SELECTOR = "-test.run=^TestDaemonCmdCodeGraphDiskManifestCompatibilityHelper$"
BLOCKER = b"Owned regular file: package-state allocation must not precede admission.\n"
RELEASE = b"release"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load_owner():
    path = ROOT / OWNER_NAME
    require(sha(path.read_bytes()) == OWNER_SHA256, "Execution owner changed")
    spec = importlib.util.spec_from_file_location("api_cli_proof_capture_owner", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(module.ROOT == ROOT and module.SOURCE == SOURCE and module.BASE == BASE
            and module.BASE_TREE == BASE_TREE, "Execution owner has another source context")
    module.own_path(path)
    return module


def read_identity(owner, path, expected=None):
    raw = owner.own_path(path).read_bytes()
    digest = sha(raw)
    require(expected is None or digest == expected, "Input identity differs: " + str(path))
    return raw, digest


def admit_build(owner, stage, expected_binary):
    """Admit the existing completed build; never invoke any manifest command."""
    directory = ROOT / "evidence" / stage
    binary = directory / (stage + ".exe")
    raw, binary_sha = read_identity(owner, binary, expected_binary)
    binary_size = len(raw)
    receipt_path = directory / "receipt.json"
    raw, receipt_sha = read_identity(owner, receipt_path)
    receipt = json.loads(raw)
    require(receipt.get("phase") == stage and receipt.get("completed") is True
            and not receipt.get("process_tree_unresolved") and receipt.get("base") == BASE
            and receipt.get("base_tree") == BASE_TREE and receipt.get("source_head") == BASE
            and receipt.get("source_tree") == BASE_TREE and receipt.get("source_directory") == str(SOURCE),
            "Build receipt is not the completed exact-source qualification")
    source = receipt.get("source_final", {})
    require(source.get("head") == BASE and source.get("tree") == BASE_TREE
            and source.get("staged") == "" and source.get("status") == ""
            and source == receipt.get("source_after"), "Build source was not the clean pinned tree")
    manifest_path = Path(receipt["manifest_path"])
    raw, manifest_sha = read_identity(owner, manifest_path, STAGES[stage][1])
    require(receipt.get("manifest_sha256") == manifest_sha, "Build manifest receipt differs")
    manifest = json.loads(raw)
    require(manifest.get("source_head") == BASE and manifest.get("source_tree") == BASE_TREE
            and manifest.get("native_scheduler_operations") is False
            and manifest.get("runner_sha256") == receipt.get("runner_sha256"),
            "Build manifest has another source or execution-owner identity")
    selection = manifest["phases"][stage]
    commands = [c for c in selection["commands"] if c["label"] == stage]
    require(len(commands) == 1 and commands[0]["kind"] == "compile"
            and commands[0]["expected_exit_code"] == 0, "Missing exact compile command")
    rows = [row for row in receipt["commands"] if row["label"] == stage]
    require(len(rows) == 1, "Missing or duplicate compile result")
    owner.Runner.require_pass(rows[0])
    oracle_path = directory / (stage + ".oracle.json")
    raw, oracle_sha = read_identity(owner, oracle_path)
    oracle = json.loads(raw)
    require(oracle == rows[0].get("oracle") and oracle.get("matched") is True
            and oracle.get("manifest_sha256") == manifest_sha
            and oracle.get("binary") == {"path": str(binary), "bytes": binary_size, "sha256": binary_sha},
            "Compile oracle differs from the exact executable")
    owner.candidate_paths(manifest, manifest_path)
    identity = {
        "source_head": BASE, "source_tree": BASE_TREE, "build_phase": stage,
        "binary": {"path": str(binary), "bytes": binary_size, "sha256": binary_sha},
        "build_receipt_sha256": receipt_sha, "compile_oracle_sha256": oracle_sha,
        "build_manifest_path": str(manifest_path), "build_manifest_sha256": manifest_sha,
        "build_execution_owner_sha256": receipt["runner_sha256"],
        "proof_execution_owner_sha256": OWNER_SHA256,
    }
    pins = {str(receipt_path): receipt_sha, str(oracle_path): oracle_sha,
            str(manifest_path): manifest_sha, str(ROOT / OWNER_NAME): OWNER_SHA256}
    return binary, manifest, manifest_path, identity, pins


def native_temp(requested):
    """Use the available Windows API selected by the reviewed installed Go."""
    previous = {key: os.environ.get(key) for key in ("TEMP", "TMP")}
    try:
        os.environ.update(TEMP=str(requested), TMP=str(requested))
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        name = "GetTempPath2W" if hasattr(kernel, "GetTempPath2W") else "GetTempPathW"
        function = getattr(kernel, name)
        function.argtypes = (wintypes.DWORD, wintypes.LPWSTR)
        function.restype = wintypes.DWORD
        buffer = ctypes.create_unicode_buffer(32768)
        size = function(len(buffer), buffer)
        require(0 < size < len(buffer), "Native temporary-path resolution failed")
        actual = Path(buffer.value)
        require(actual == requested, "Native temporary path escaped the requested owned location")
        return {"api": name, "requested": str(requested), "resolved": str(actual)}
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def case_protocol(stage, name, binary, protocol):
    family = stage.split("-", 1)[0]
    marker = "2" if name == "invalid-marker" else "1"
    if family == "api":
        args = [str(binary), API_SELECTOR]
        env = {"MCPHUB_TEST_HOLD_VAULT_LOCK": marker,
               "MCPHUB_TEST_VAULT_PATH": str(protocol / "vault"),
               "MCPHUB_TEST_READY_PATH": str(protocol / "ready"),
               "MCPHUB_TEST_RELEASE_PATH": str(protocol / "release")}
        if name == "extra-argument":
            args.append("-test.v=true")
    else:
        args = [str(binary), CLI_SELECTOR, "--"]
        env = {"MCPHUB_CODEGRAPH_COMPAT_HELPER": marker}
        if name == "extra-argument":
            args.append("extra")
    return args, env


def exercise(owner, runner, stage, name, binary, expected_hash):
    stage_out, stage_env = runner.out, runner.env
    out = owner.own_path(stage_out / name)
    out.mkdir(exist_ok=False)
    runtime = owner.own_path(runner.runtime / name)
    row = {"case": name, "stage": stage, "started_utc": owner.utc(), "oracle_matched": False}
    try:
        runtime.mkdir(exist_ok=False)
        temporary, protocol = runtime / "tmp", runtime / "protocol"
        protocol.mkdir(exist_ok=False)
        if name == "cooperative":
            temporary.mkdir(exist_ok=False)
        else:
            with temporary.open("xb") as stream:
                stream.write(BLOCKER)
        if stage.startswith("api-"):
            with (protocol / "release").open("xb") as stream:
                stream.write(RELEASE)
        args, helper_env = case_protocol(stage, name, binary, protocol)
        env = {**stage_env, **helper_env, "TEMP": str(temporary), "TMP": str(temporary),
               "TMPDIR": str(temporary), "GOTMPDIR": str(temporary)}
        before = sorted(p.name for p in temporary.iterdir()) if temporary.is_dir() else []
        require(not before, "Case temporary directory was not empty")
        row.update(args=args, helper_environment=helper_env, native_temp=native_temp(temporary),
                   temporary_kind="directory" if name == "cooperative" else "regular-file",
                   temporary_path=str(temporary), state_entries_before=before,
                   binary_sha256_before=sha(owner.own_path(binary).read_bytes()),
                   telemetry_directory=env["TEST_TELEMETRY_DIR"])
        require(row["binary_sha256_before"] == expected_hash, "Binary changed before invocation")
        mode_path = owner.own_path(Path(env["TEST_TELEMETRY_DIR"]) / "mode")
        mode_bytes = mode_path.read_bytes()
        row["telemetry_mode_file"] = {"path": str(mode_path), "bytes": len(mode_bytes),
                                      "raw_hex": mode_bytes.hex(), "raw_repr": repr(mode_bytes),
                                      "sha256": sha(mode_bytes)}
        # Installed telemetry Dir.Mode trims surrounding whitespace. Limit this
        # proof to the two exact encodings produced by the pinned owner's writer.
        require(mode_bytes in (b"off\n", b"off\r\n"),
                "Owned telemetry mode is not off")
        row["telemetry_mode"] = "off"
        source_before = runner.snapshot()
        require(source_before == runner.receipt["source_before"], "Physical source changed before helper invocation")
        owner.save_new(out / "case-started.json", row)
        runner.out, runner.env = out, env
        execution = runner.execute(name, args, runtime, 20, source_before)
        runner.out, runner.env = stage_out, stage_env
        runner.receipt["commands"].append(execution)
        try:
            execution["source_after"] = runner.snapshot()
        except Exception as error:
            execution["source_after_error"] = type(error).__name__ + ": " + str(error)
        owner.save_new(out / (name + ".receipt.json"), execution)
        row["execution"] = execution
        require(execution.get("settled") and not execution.get("timed_out")
                and not any(k in execution for k in ("error_type", "event_error_type", "source_after_error",
                                                     "stdout_capture_error", "stderr_capture_error")),
                "Helper did not settle with complete captured streams")
        require(execution.get("source_before") == runner.receipt["source_before"]
                and execution.get("source_after") == runner.receipt["source_before"],
                "Physical source changed around the helper invocation")
        stdout = (out / (name + ".stdout.log")).read_bytes()
        stderr = (out / (name + ".stderr.log")).read_bytes()
        for label, data in (("stdout", stdout), ("stderr", stderr)):
            require(execution[label]["bytes"] == len(data) and execution[label]["sha256"] == sha(data),
                    "Captured stream changed after direct-child exit")
        row["binary_sha256_after"] = sha(owner.own_path(binary).read_bytes())
        require(row["binary_sha256_after"] == expected_hash, "Binary changed during invocation")
        if name == "cooperative":
            entries = sorted(p.name for p in temporary.iterdir())
            row["state_entries_after"] = entries
            expected_roots = 1 if stage.endswith("-control") else 0
            prefix = "mcphub-" + stage.split("-", 1)[0] + "-test-state-"
            require(execution["exit_code"] == 0 and not stdout and not stderr,
                    "Cooperative helper did not exit 0 with empty stdout/stderr")
            require(len(entries) == expected_roots and all(n.startswith(prefix)
                    and owner.own_path(temporary / n).is_dir() for n in entries),
                    "Unexpected package-state residue")
            row.update(expected_exit_code=0, expected_state_roots=expected_roots)
        else:
            require(temporary.is_file() and owner.own_path(temporary).read_bytes() == BLOCKER,
                    "Regular-file allocation blocker changed")
            marker = (b"internal/api TestMain: invalid helper invocation\n" if stage.startswith("api-")
                      else b"internal/cli: invalid test helper dispatch\n")
            require(execution["exit_code"] == 3 and not stdout and stderr == marker,
                    "Candidate did not reject at the exact admission boundary")
            row.update(expected_exit_code=3, allocation_blocker_sha256=sha(BLOCKER))
        if stage.startswith("api-"):
            ready = owner.own_path(protocol / "ready")
            require(ready.read_bytes() == b"ready" if name == "cooperative" else not ready.exists(),
                    "Vault helper readiness differs from the expected protocol")
            require(owner.own_path(protocol / "release").read_bytes() == RELEASE,
                    "Precreated release marker changed")
            row["ready"] = "ready" if name == "cooperative" else "absent"
        row["oracle_matched"] = True
    except BaseException as error:
        row.update(error_type=type(error).__name__, error=str(error))
    finally:
        runner.out, runner.env = stage_out, stage_env
        row["finished_utc"] = owner.utc()
        owner.save_new(out / "case-receipt.json", row)
    return row


def main():
    require(os.name == "nt" and not sys.flags.optimize and Path(__file__).resolve().parent == ROOT,
            "Use the reviewed proof script from its unoptimized owned Windows root")
    require(len(sys.argv) == 4, "Expected stage, exact executable SHA256 and script SHA256")
    stage, binary_sha, script_sha = sys.argv[1:]
    require(stage in STAGES and re.fullmatch(r"[0-9a-f]{64}", binary_sha)
            and re.fullmatch(r"[0-9a-f]{64}", script_sha), "Invalid proof stage or identity")
    require(binary_sha == STAGES[stage][0], "Executable is outside the frozen stage selection")
    require(sha(Path(__file__).read_bytes()) == script_sha, "Proof script differs from reviewed bytes")
    owner = load_owner()
    binary, manifest, manifest_path, build, pins = admit_build(owner, stage, binary_sha)
    runner = owner.Runner("native-proof-v2-" + stage, manifest, manifest_path, build["build_manifest_sha256"])
    runner.receipt.update(proof_stage=stage, proof_script_sha256=script_sha, source_build_identity=build,
                          manifest_role="Original binary-build source manifest; helper argv is frozen in proof_script_sha256",
                          cases=[], stdin_mode="DEVNULL: immediate EOF", direct_helper_timeout_seconds=20,
                          native_task_operations_basis="Reviewed vault flock/ready/release or CodeGraph stdin-EOF fixture only; not syscall enforcement")
    failure = None
    try:
        runner.begin()
        runner.receipt["source_before"] = runner.admit()
        names = ("cooperative",) if stage.endswith("-control") else (
            "cooperative", "invalid-marker", "extra-argument")
        for name in names:
            row = exercise(owner, runner, stage, name, binary, binary_sha)
            runner.receipt["cases"].append(row)
            require(row["oracle_matched"], name + ": " + row.get("error", "oracle did not match"))
        for path, digest in pins.items():
            read_identity(owner, Path(path), digest)
        owner.candidate_paths(manifest, manifest_path)
        require(sha(Path(__file__).read_bytes()) == script_sha, "Proof script changed during execution")
        runner.receipt["proof_script_sha256_after"] = script_sha
        after = runner.admit()
        runner.receipt.update(source_after=after, source_head=after["head"], source_tree=after["tree"],
                              completed=True, state="complete")
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
