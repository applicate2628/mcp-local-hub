"""Read settled task-owned receipts and streams; export exact bytes and hashes."""
import sys
sys.dont_write_bytecode = True

import base64
import json
import zlib

import qualify_go as q

PHASES = ("prepare", "lifecycle-red-green", "build-vet")


def main():
    if len(sys.argv) != 1 or q.Path(__file__).resolve().parent != q.ROOT:
        raise RuntimeError("Use this exact task-owned evidence exporter")
    rows = []
    for phase in PHASES:
        directory = q.own("evidence/" + phase)
        receipt = json.loads((directory / "receipt.json").read_bytes())
        if not receipt.get("finished_utc"):
            raise RuntimeError("Phase is not settled: " + phase)
        for path in sorted(directory.iterdir(), key=lambda path: path.name):
            # The formatted code was exported separately and verified byte-for-byte.
            if path.name.startswith("formatted-export."):
                continue
            path = q.own(path.relative_to(q.ROOT).as_posix())
            if not path.is_file() or not path.name.endswith((".json", ".stdout.log", ".stderr.log")):
                raise RuntimeError("Unexpected evidence item")
            raw = path.read_bytes()
            if path.read_bytes() != raw:
                raise RuntimeError("Evidence changed while read")
            rows.append({"path": path.relative_to(q.ROOT).as_posix(), "bytes": len(raw),
                         "sha256": q.sha(raw), "content_b64": base64.b64encode(raw).decode()})
    payload = {"schema": 1, "source_root": str(q.ROOT), "exported_utc": q.now(),
               "exporter_sha256": q.sha(q.Path(__file__).read_bytes()), "files": rows}
    raw = json.dumps(payload, separators=(",", ":")).encode()
    encoded = base64.b64encode(zlib.compress(raw, 9)) + b"\n"
    out = q.own("evidence-export.json.zlib.b64")
    with out.open("xb") as stream:
        stream.write(encoded)
    summary = {"schema": 1, "files": len(rows), "bytes": sum(row["bytes"] for row in rows),
               "export_bytes": len(encoded), "export_sha256": q.sha(encoded),
               "exporter_sha256": payload["exporter_sha256"], "phases": list(PHASES)}
    q.save(q.own("evidence-export-manifest.json"), summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
