"""Prepare one exact offline Scheduler composition; execute no product or tests."""
import sys
sys.dont_write_bytecode = True

import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import zlib

import qualify_go as q

SOURCE = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
BUNDLE_SHA256 = "21276a32ac023ed8abbad5bcda5f2e01640befd95de0502359498074099a2e45"
RUNNER_SHA256 = "b55705f864c52ae4e23e144ecfda4470c4e97a07cddd75fc53df780d2166c8d5"
HEAD = "858812988833a84368c60fba1540ae601155fa71"
TREE = "dba685c090952a93a80a1e82403c4646ad8aaed1"
CANDIDATES = ("internal/api/install.go", "internal/api/install_scheduler_stop_failure_test.go")


def checked(path):
    info = path.lstat()
    if path.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("Reparse point in source input: " + str(path))
    return info


def source_inventory(expected):
    current = Path(r"D:\dev")
    for part in (None, "ChatGPT", *SOURCE.relative_to(Path(r"D:\dev\ChatGPT")).parts):
        if part is not None:
            current = current / part
        if not stat.S_ISDIR(checked(current).st_mode):
            raise RuntimeError("Source ancestor is not a directory")
    found = []
    def walk_error(error):
        raise error
    for directory, children, names in os.walk(SOURCE, followlinks=False, onerror=walk_error):
        if ".git" in children:
            children.remove(".git")
        for name in children + names:
            if name != ".git":
                checked(Path(directory) / name)
        for name in names:
            if name != ".git":
                found.append((Path(directory) / name).relative_to(SOURCE).as_posix())
    if sorted(found) != sorted(row["path"] for row in expected):
        raise RuntimeError("Preserved source has missing or unadmitted files")
    rows = []
    for row in expected:
        path = SOURCE / row["path"]
        if not stat.S_ISREG(checked(path).st_mode):
            raise RuntimeError("Non-regular source file")
        raw = path.read_bytes()
        if len(raw) != row["bytes"] or q.sha(raw) != row["sha256"]:
            raise RuntimeError("Preserved source differs: " + row["path"])
        rows.append([row["path"], len(raw), q.sha(raw)])
    return {"files": len(rows), "bytes": sum(row[1] for row in rows),
            "inventory_sha256": q.sha(json.dumps(rows, separators=(",", ":"), ensure_ascii=True).encode())}


def main():
    if os.name != "nt" or sys.flags.optimize or Path(__file__).resolve().parent != q.ROOT or len(sys.argv) != 1:
        raise RuntimeError("Use the owned Windows preparation helper")
    if q.sha(q.own("qualify_go.py").read_bytes()) != RUNNER_SHA256:
        raise RuntimeError("Qualification runner differs")
    raw = q.own("stage-inputs.json.zlib.b64").read_bytes()
    if q.sha(raw) != BUNDLE_SHA256:
        raise RuntimeError("Transport bundle differs")
    payload = json.loads(zlib.decompress(base64.b64decode(raw, validate=False)))
    if payload.get("schema") != 1 or payload.get("source_head") != HEAD or payload.get("source_tree") != TREE:
        raise RuntimeError("Wrong source identity")
    if len(payload["source_files"]) != 3281 or len(payload["files"]) != 41:
        raise RuntimeError("Unexpected composition cardinality")
    paths = [row["path"] for row in payload["files"]]
    if len(set(paths)) != len(paths) or any(not path.startswith(("inputs/scheduler/", "inputs/candidate/")) for path in paths):
        raise RuntimeError("Unexpected staged input path")
    for row in payload["source_files"]:
        q.own("source/" + row["path"])
    for row in payload["files"]:
        q.own(row["path"])
        data = base64.b64decode(row["content_b64"], validate=True)
        if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
            raise RuntimeError("Bad bundled file: " + row["path"])
    for relative in ("source", "inputs", "evidence/prepare", "runtime/prepare"):
        if q.own(relative).exists():
            raise RuntimeError("Preparation destination already exists: " + relative)
    out = q.own("evidence/prepare")
    out.mkdir(parents=True, exist_ok=False)
    runtime = q.own("runtime/prepare")
    runtime.mkdir(parents=True, exist_ok=False)
    receipt = {"schema": 1, "phase": "prepare", "started_utc": q.now(), "completed": False,
               "script_sha256": q.sha(Path(__file__).read_bytes()), "runner_sha256": RUNNER_SHA256,
               "bundle_sha256": BUNDLE_SHA256, "commands": [], "source_head": HEAD, "source_tree": TREE,
               "native_scheduler_operations": False, "tests_executed": False, "dependency_downloads": False}
    q.save(out / "receipt-initial.json", receipt)
    env = q.environment(runtime, {})

    def run(label, args, cwd, timeout=30):
        row = {"label": label, "argv": list(map(str, args)), "cwd": str(cwd), "started_utc": q.now(),
               "timeout_seconds": timeout, "settled": False, "timed_out": False}
        receipt["commands"].append(row)
        child = None
        started = time.monotonic()
        try:
            with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
                child = subprocess.Popen(row["argv"], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
                row["pid"] = child.pid
                try:
                    row["exit_code"] = child.wait(timeout=timeout)
                    row["settled"] = True
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    raise
        finally:
            if child is not None and not row["settled"]:
                row.update(process_tree_unresolved=True, retain_runtime_and_logs=True)
                child.terminate()
                row["exit_code"] = child.wait(timeout=10)
                row["settled"] = True
            row.update(seconds=round(time.monotonic() - started, 3), finished_utc=q.now())
            for name in ("stdout", "stderr"):
                path = out / (label + "." + name + ".log")
                if path.exists():
                    data = path.read_bytes()
                    row[name] = {"bytes": len(data), "sha256": q.sha(data)}
            q.save(out / (label + ".receipt.json"), row)
        if row["exit_code"] != 0 or row["timed_out"]:
            raise RuntimeError("Preparation command failed: " + label)
        return (out / (label + ".stdout.log")).read_bytes()

    try:
        for path, expected in q.PINS.items():
            if q.sha(Path(path).read_bytes()) != expected:
                raise RuntimeError("Installed tool changed: " + path)
        receipt["tools_sha256"] = q.PINS
        receipt["git_sha256"] = q.sha(GIT.read_bytes())
        if run("go-version", [q.GO, "version"], q.ROOT).decode().strip() != "go version go1.27.4 windows/amd64":
            raise RuntimeError("Unexpected Go version")
        if run("source-head", [GIT, "rev-parse", "--verify", "HEAD"], SOURCE).decode().strip() != HEAD:
            raise RuntimeError("Preserved Git HEAD changed")
        if run("source-tree", [GIT, "rev-parse", "--verify", "HEAD^{tree}"], SOURCE).decode().strip() != TREE:
            raise RuntimeError("Preserved Git tree changed")
        receipt["source_before"] = source_inventory(payload["source_files"])
        for row in payload["source_files"]:
            target = q.own("source/" + row["path"])
            target.parent.mkdir(parents=True, exist_ok=True)
            data = (SOURCE / row["path"]).read_bytes()
            if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                raise RuntimeError("Source changed during copy: " + row["path"])
            with target.open("xb") as stream:
                stream.write(data)
        receipt["copied_source"] = q.check_files("source", payload["source_files"], True)
        receipt["source_after"] = source_inventory(payload["source_files"])
        if receipt["source_before"] != receipt["source_after"] or receipt["source_before"] != receipt["copied_source"]:
            raise RuntimeError("Source changed while copied")
        for row in payload["files"]:
            path = q.own(row["path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as stream:
                stream.write(base64.b64decode(row["content_b64"], validate=True))
        q.save(q.own("source-files.json"), payload["source_files"])
        before = []
        for relative in CANDIDATES:
            data = q.own("inputs/candidate/" + relative).read_bytes()
            archive = q.own("inputs/preformat/" + relative)
            archive.parent.mkdir(parents=True, exist_ok=True)
            with archive.open("xb") as stream:
                stream.write(data)
            before.append({"path": relative, "bytes": len(data), "sha256": q.sha(data)})
        receipt["preformat"] = before
        paths = [q.own("inputs/candidate/" + relative) for relative in CANDIDATES]
        run("gofmt-write", [q.GOFMT, "-w", *paths], q.ROOT)
        if run("gofmt-check", [q.GOFMT, "-l", *paths], q.ROOT).strip():
            raise RuntimeError("Formatter left differences")
        export = []
        for relative in CANDIDATES:
            data = q.own("inputs/candidate/" + relative).read_bytes()
            export.append({"path": relative, "bytes": len(data), "sha256": q.sha(data), "content_b64": base64.b64encode(data).decode()})
        q.save(out / "formatted-export.json", export)
        packed = base64.b64encode(zlib.compress(json.dumps(export, separators=(",", ":")).encode(), 9)).decode()
        with (out / "formatted-export.json.zlib.b64").open("x", encoding="ascii", newline="\n") as stream:
            stream.write(packed + "\n")
        receipt["formatted"] = [{k: value for k, value in row.items() if k != "content_b64"} for row in export]
        receipt["formatted_export_sha256"] = q.sha((out / "formatted-export.json.zlib.b64").read_bytes())
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps({k: receipt.get(k) for k in ("phase", "completed", "error", "source_before", "source_after", "formatted")}), flush=True)


if __name__ == "__main__":
    main()
