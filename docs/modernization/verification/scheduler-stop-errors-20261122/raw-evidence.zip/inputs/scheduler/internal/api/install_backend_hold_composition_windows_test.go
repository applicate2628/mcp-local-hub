//go:build windows

package api

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"mcp-local-hub/internal/config"
)

// These tests exercise the install merge and its temporary write probe on the
// composed master/#660 source. No scheduler or installed product is acquired.
func TestInstallMergePreservesBackendRunHold(t *testing.T) {
	root := hardenedTempDir(t)
	t.Cleanup(SetDaemonStateRootForTest(root))
	t.Setenv("MCPHUB_MANIFEST_DIR_OVERRIDE", root)
	hold := fixturePassiveBackendRunHold()
	prior := &SupervisorIntentFile{Version: 1, BackendRunHold: hold}
	before := cloneSupervisorIntentFile(prior)
	manifest := &config.ServerManifest{Name: "hold-composition"}
	wantRow := SupervisorDaemon{TaskName: `\mcp-local-hub-hold-composition-default`, Server: manifest.Name, Daemon: "default"}
	merged, original, existed, err := NewAPI().buildMergedSupervisorIntentFromPriorWithProjection(
		manifest, nil, "", prior, true, func() ([]SupervisorDaemon, error) {
			return []SupervisorDaemon{wantRow}, nil
		})
	if err != nil || merged == nil || original != prior || !existed {
		t.Fatalf("HOLD-MERGE: prior observation was not preserved: merged=%v existed=%v err=%v", merged != nil, existed, err)
	}
	if !reflect.DeepEqual(merged.BackendRunHold, hold) || !errors.Is(merged.BackendStartError(), ErrSupervisorBackendHeld) {
		t.Fatal("HOLD-MERGE: install merge lost the original backend run hold")
	}
	if len(merged.Daemons) != 1 || !reflect.DeepEqual(merged.Daemons[0], wantRow) {
		t.Fatal("HOLD-MERGE: install merge did not retain the requested descriptor")
	}
	if !reflect.DeepEqual(prior, before) {
		t.Fatal("HOLD-MERGE: merge changed its prior observation")
	}
	merged.BackendRunHold.Work[0].PendingPhase = "changed-in-new-result-only"
	if !reflect.DeepEqual(prior, before) {
		t.Fatal("HOLD-MERGE: returned hold shares mutable work with the prior observation")
	}
}

func TestInstallPreflightPreservesBackendRunHold(t *testing.T) {
	hold := fixturePassiveBackendRunHold()
	path, priorBytes := fixturePassiveBackendIntent(t, &SupervisorIntentFile{Version: 1, BackendRunHold: hold})
	desired := &SupervisorIntentFile{
		Version: 1, BackendRunHold: hold.clone(),
		Daemons: []SupervisorDaemon{{TaskName: `\mcp-local-hub-hold-composition-default`, Server: "hold-composition", Daemon: "default"}},
	}
	before := cloneSupervisorIntentFile(desired)
	if err := preflightSupervisorIntentWrite(filepath.Dir(path), desired); err != nil {
		t.Fatalf("HOLD-PREFLIGHT: temporary write probe failed: %v", err)
	}
	if !reflect.DeepEqual(desired, before) || !errors.Is(desired.BackendStartError(), ErrSupervisorBackendHeld) {
		t.Fatal("HOLD-PREFLIGHT: temporary probe changed the install's desired hold or descriptors")
	}
	afterBytes, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(afterBytes, priorBytes) {
		t.Fatalf("HOLD-PREFLIGHT: temporary probe changed the original intent bytes: %v", err)
	}
	for _, suffix := range []string{".preflight", ".preflight.lock"} {
		if _, err := os.Lstat(path + suffix); !errors.Is(err, os.ErrNotExist) {
			t.Fatalf("HOLD-PREFLIGHT: temporary probe left an unconfirmed artifact %s: %v", suffix, err)
		}
	}
}
