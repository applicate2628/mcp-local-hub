"""Verify the received Windows evidence without executing project code."""
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import sys
import zlib

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    require(not sys.flags.optimize, "Do not use optimized verification")
    index = json.loads((ROOT / "qualification-index.json").read_bytes())
    manifest = json.loads((ROOT / "evidence-export-manifest.json").read_bytes())
    encoded = (ROOT / "evidence-export.json.zlib.b64").read_bytes()
    require(len(encoded) == manifest["export_bytes"] and sha(encoded) == manifest["export_sha256"], "Export transport differs")
    payload = json.loads(zlib.decompress(base64.b64decode(encoded)))
    require(payload["source_root"] == index["root"], "Unexpected remote root")
    require(sha((ROOT / "export_evidence.py").read_bytes()) == manifest["exporter_sha256"] == payload["exporter_sha256"], "Exporter differs")
    rows = payload["files"]
    require(len(rows) == manifest["files"] and sum(row["bytes"] for row in rows) == manifest["bytes"], "Export totals differ")
    require(len({row["path"].casefold() for row in rows}) == len(rows), "Duplicate export paths")
    output = ROOT / "results"
    output.mkdir(exist_ok=False)
    received = {}
    for row in rows:
        relative = PurePosixPath(row["path"])
        require(not relative.is_absolute() and len(relative.parts) == 3 and relative.parts[0] == "evidence" and relative.parts[1] in manifest["phases"], "Unadmitted evidence path")
        require(str(relative) == row["path"] and all(part not in (".", "..") and "\\" not in part and ":" not in part for part in relative.parts), "Unsafe evidence path")
        raw = base64.b64decode(row["content_b64"], validate=True)
        require(len(raw) == row["bytes"] and sha(raw) == row["sha256"], "Received evidence differs: " + row["path"])
        path = output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(raw)
        received[row["path"]] = raw
    def load(phase, name):
        return json.loads(received["evidence/" + phase + "/" + name])
    prepared = load("prepare", "receipt.json")
    require(prepared["completed"] and prepared["source_before"] == prepared["copied_source"] == prepared["source_after"], "Preparation not complete and stable")
    require(prepared["preformat"] == prepared["formatted"], "Unexpected formatting change")
    require((ROOT / "prepare.receipt.json").read_bytes() == received["evidence/prepare/receipt.json"], "Preparation receipt readbacks differ")
    command_results = []
    for entry in index["manifest_files"]:
        raw = (ROOT / entry["path"]).read_bytes()
        require(len(raw) == entry["bytes"] and sha(raw) == entry["sha256"], "Local plan differs")
        plan = json.loads(raw)
        phase = plan["phase"]
        receipt = load(phase, "receipt.json")
        require(receipt["completed"] and receipt["manifest_sha256"] == entry["sha256"] and receipt["runner_sha256"] == index["runner_sha256"], "Phase failed or identity differs")
        require(receipt["source_head"] == index["source_head"] and receipt["source_tree"] == index["source_tree"], "Source identity differs")
        require(receipt["source_before"] == receipt["source_after"] == prepared["source_before"], "Source changed")
        require(receipt["inputs_before"] == receipt["inputs_after"] and receipt["inputs_before"]["files"] == 45, "Composition changed")
        require(receipt["tools_sha256"] == prepared["tools_sha256"], "Tool pins differ")
        require(receipt["native_scheduler_operations"] is False, "Native scope changed")
        for name, value in {"GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly", "MCPHUB_E2E_SCHEDULER": "none"}.items():
            require(receipt["environment"][name] == value, "Environment gate differs: " + name)
        for name in ("TEMP", "TMP", "GOTMPDIR", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME", "PSModuleAnalysisCachePath"):
            require(PureWindowsPath(receipt["environment"][name]).is_relative_to(PureWindowsPath(index["root"])), "Runtime path escaped task root: " + name)
        require(len(receipt["commands"]) == len(plan["commands"]), "Command count differs")
        for row, command in zip(receipt["commands"], plan["commands"]):
            label = command["label"]
            require(row == load(phase, label + ".receipt.json"), "Command receipt mismatch")
            require(row["label"] == label and row["argv"] == [r"C:\msys64\ucrt64\bin\go.exe", *command["args"]], "Command arguments differ")
            require(row["cwd"] == str(PureWindowsPath(index["root"]) / "source"), "Unexpected command working directory")
            require(row["settled"] and not row["timed_out"] and row["oracle_pass"] and row["exit_code"] == command["expected_exit_code"], "Command failed its gate")
            require(row["pid"] == load(phase, label + ".launched.json")["pid"], "Direct-child identity differs")
            streams = {}
            for stream in ("stdout", "stderr"):
                data = received["evidence/" + phase + "/" + label + "." + stream + ".log"]
                require(len(data) == row[stream]["bytes"] and sha(data) == row[stream]["sha256"], "Stream digest differs")
                streams[stream] = data
            result = {"phase": phase, "label": label, "exit_code": row["exit_code"], "seconds": row["seconds"], "settled": True, "timed_out": False}
            if label in index["exact_terminal_oracles"]:
                events = [json.loads(line) for line in streams["stdout"].splitlines() if line]
                observed = {action: [] for action in ("pass", "fail", "skip")}
                for event in events:
                    if event.get("Action") in observed:
                        observed[event["Action"]].append(event.get("Test", "PACKAGE:" + event["Package"]))
                expected = index["exact_terminal_oracles"][label]
                require(all(Counter(observed[action]) == Counter(expected[action]) == Counter(row["tests"][action]) for action in observed), "Exact terminal multiset differs: " + label)
                require(all(count == 1 for action in observed for count in Counter(observed[action]).values()), "Duplicate terminal event")
                expected_roots = {name for names in expected.values() for name in names if "/" not in name and not name.startswith("PACKAGE:")}
                actual_roots = [event["Test"] for event in events if event.get("Action") == "run" and "Test" in event and "/" not in event["Test"]]
                require(Counter(actual_roots) == Counter(expected_roots), "Selected root multiset differs")
                require("-race" in row["argv"] and b"DATA RACE" not in streams["stdout"] + streams["stderr"], "Race gate differs")
                result.update(exact_terminal_multisets=True, selected_roots=sorted(expected_roots), race_detector_enabled=True,
                              terminal_counts={action: len(names) for action, names in observed.items()},
                              terminal_names=observed)
                if label == "stop-red":
                    failed_leaves = {name for name in expected["fail"] if name.startswith("Test") and name.count("/") == 2}
                    errors = {name: [] for name in failed_leaves}
                    for event in events:
                        if event.get("Action") == "output" and event.get("OutputType") == "error":
                            require(event.get("Test") in errors, "Unexpected negative-control error test")
                            match = re.fullmatch(r"\s*install_scheduler_stop_failure_test\.go:\d+: (.*)\n", event["Output"])
                            require(match is not None, "Unexpected negative-control error shape")
                            errors[event["Test"]].append(match.group(1))
                    counts = {"false_success": 0, "unsafe_run": 0, "lost_stop_intent": 0}
                    for name, messages in errors.items():
                        want = 1 + int("/Restart/" in name or "/RestartAll/" in name) + int("/Restart/" in name)
                        require(len(messages) == want, "Negative-control failure cause count differs")
                        for message in messages:
                            if message.startswith("results = ") and "want alpha error" in message and "and beta success" in message:
                                counts["false_success"] += 1
                            elif message.startswith("started task names = ") and "a failed stop must not authorize Run" in message:
                                counts["unsafe_run"] += 1
                            elif message.startswith("alpha intent desired = "):
                                counts["lost_stop_intent"] += 1
                            else:
                                raise RuntimeError("Unexpected negative-control failure cause")
                    require(counts == {"false_success": 16, "unsafe_run": 8, "lost_stop_intent": 4}, "Negative control did not reproduce the intended defects")
                    result["observed_defect_assertions"] = counts
            command_results.append(result)
    summary = {"schema": 1, "status": "OBSERVED_SCOPED_WINDOWS_RED_GREEN_PASS", "source_head": index["source_head"],
               "source_tree": index["source_tree"], "source_inventory": prepared["source_before"], "input_files": 45,
               "overlay_count": 40, "export_files": len(rows), "export_sha256": manifest["export_sha256"],
               "formatted_files": prepared["formatted"], "commands": command_results,
               "limits": ["Composition qualification; not an isolated published PR head.", "No native Scheduler or installed Product operation.",
                          "Cancellation scenario checks returned-error propagation, not cancellation of a running COM call.",
                          "Go runner waits original direct-child handles; it does not enforce a whole-tree deadline. No timeout occurred."]}
    (ROOT / "verification-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": summary["status"], "export_files": len(rows), "commands": [{k: v for k, v in row.items() if k not in ("terminal_names", "selected_roots")} for row in command_results]}, indent=2))


if __name__ == "__main__":
    main()
