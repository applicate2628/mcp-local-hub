"""Execute a frozen, hash-bound Go qualification plan in this owned D root.

Source and overlays are admitted by complete file inventories before/after the
phase. Commands are literal argument arrays, never shell fragments. The runner
captures original direct-child process ownership and does not infer descendant
settlement from a wrapper exit. It installs nothing and invokes no native tasks.
"""
import sys
sys.dont_write_bytecode = True
from collections import Counter
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GOFMT = GO.with_name("gofmt.exe")
PINS = {
    str(GO): "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113",
    str(GOFMT): "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5",
    str(GO.with_name("gcc.exe")): "f6ff9378c1edb591131304518eac6456708d28720284105930d0d687136bcdd3",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")

def own(relative):
    p = PurePosixPath(relative)
    if p.is_absolute() or str(p) != relative or any(x in (".", "..", ".git") for x in p.parts) or "\\" in relative or ":" in relative:
        raise ValueError("Invalid owned relative path")
    current = ROOT
    for part in (None, *p.parts):
        if part is not None:
            current = current / part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Reparse point in owned path")
    return current

def check_files(directory, expected, complete=False):
    rows=[]
    for row in expected:
        p=own(directory+"/"+row["path"])
        raw=p.read_bytes()
        if len(raw)!=row["bytes"] or sha(raw)!=row["sha256"]:
            raise RuntimeError("Pinned input differs: "+directory+"/"+row["path"])
        rows.append([row["path"],len(raw),sha(raw)])
    if complete:
        found=[]
        def walk_error(error):
            raise error
        for parent, dirs, names in os.walk(own(directory), followlinks=False, onerror=walk_error):
            if ".git" in dirs:
                dirs.remove(".git")
            for name in dirs+names:
                p=Path(parent)/name
                if name==".git":
                    continue
                own(p.relative_to(ROOT).as_posix())
            for name in names:
                if name!=".git":
                    found.append((Path(parent)/name).relative_to(own(directory)).as_posix())
        if sorted(found)!=sorted(r[0] for r in rows):
            raise RuntimeError("Source contains missing or unadmitted files")
    return {"files":len(rows),"bytes":sum(r[1] for r in rows),"inventory_sha256":sha(json.dumps(rows,separators=(",",":"),ensure_ascii=True).encode())}

def environment(runtime, extra):
    for name in ("tmp","profile","appdata","localappdata","gopath","xdg-config","xdg-cache","xdg-data","telemetry"):
        (runtime/name).mkdir()
    (runtime/"telemetry/mode").write_text("off\n",encoding="ascii")
    env={k:v for k,v in os.environ.items() if not k.upper().startswith(("MCPHUB_","GIT_","GO")) and k.upper()!="SSH_ASKPASS"}
    env.update({
        "GOROOT":r"C:\msys64\ucrt64\lib\go","GOENV":"off","GOTOOLCHAIN":"local",
        "GOPROXY":"off","GOSUMDB":"off","GOVCS":"*:off","GOWORK":"off","GOFLAGS":"-mod=readonly","GOAUTH":"off","GOGC":"100",
        "GOCACHE":r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gocache",
        "GOMODCACHE":r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache",
        "GOPATH":str(runtime/"gopath"),"CC":str(GO.with_name("gcc.exe")),
        "GOOS":"windows","GOARCH":"amd64","CGO_ENABLED":"1","GOMAXPROCS":"4",
        "GOTELEMETRY":"off","TEST_TELEMETRY_DIR":str(runtime/"telemetry"),
        "MCPHUB_NO_AUTO_GUI":"1","MCPHUB_E2E_SCHEDULER":"none",
        "USERPROFILE":str(runtime/"profile"),"APPDATA":str(runtime/"appdata"),"LOCALAPPDATA":str(runtime/"localappdata"),
        "TEMP":str(runtime/"tmp"),"TMP":str(runtime/"tmp"),"TMPDIR":str(runtime/"tmp"),"GOTMPDIR":str(runtime/"tmp"),
        "XDG_CONFIG_HOME":str(runtime/"xdg-config"),"XDG_CACHE_HOME":str(runtime/"xdg-cache"),"XDG_DATA_HOME":str(runtime/"xdg-data"),
        "PSModuleAnalysisCachePath":str(runtime/"localappdata/module-cache"),"PYTHONDONTWRITEBYTECODE":"1",
        "GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":str(runtime/"absent-global-config"),"GIT_TERMINAL_PROMPT":"0",
    })
    allowed={"MCPHUB_RELAY_SDK_PROFILE","MCPHUB_CMAKE_SDK_PROFILE_TRACE","MCPHUB_CMAKE_SDK_PROFILE_SHA256","GOOS","CGO_ENABLED"}
    if not set(extra)<=allowed or any(not isinstance(v,str) for v in extra.values()):
        raise ValueError("Unreviewed environment extension")
    env.update(extra)
    env["PATH"]=os.pathsep.join([str(GO.parent),env.get("PATH","")])
    # Bind the native temporary directory used by the installed Go runtime.
    old={k:os.environ.get(k) for k in ("TEMP","TMP")}
    try:
        os.environ.update(TEMP=env["TEMP"],TMP=env["TMP"])
        kernel=ctypes.WinDLL("kernel32",use_last_error=True)
        name="GetTempPath2W" if hasattr(kernel,"GetTempPath2W") else "GetTempPathW"
        fn=getattr(kernel,name);fn.argtypes=(wintypes.DWORD,wintypes.LPWSTR);fn.restype=wintypes.DWORD
        buffer=ctypes.create_unicode_buffer(32768);n=fn(len(buffer),buffer)
        if not 0<n<len(buffer) or Path(buffer.value)!=runtime/"tmp":
            raise RuntimeError("Native temporary directory escaped owned runtime")
    finally:
        for k,v in old.items():
            if v is None:os.environ.pop(k,None)
            else:os.environ[k]=v
    return env

def execute(out, env, command, cwd):
    label=command["label"]
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,63}",label):raise ValueError("Invalid command label")
    executable={"go":GO,"gofmt":GOFMT}[command["tool"]]
    args=command["args"]
    if not isinstance(args,list) or not args or any(not isinstance(a,str) or "\0" in a for a in args):raise ValueError("Invalid argv")
    if command["tool"]=="go" and args[0] not in ("version","mod","test","build","vet","run"):raise ValueError("Unadmitted Go verb")
    if command["tool"]=="gofmt" and args[0]!="-l":raise ValueError("Qualification formatting is read-only")
    if any(a==f or a.startswith(f+"=") for a in args for f in ("-exec","-toolexec","-C")):raise ValueError("Alternate execution is not admitted")
    if args[0]=="run" and ("./tools/archcheck" not in args or "baseline" in args):raise ValueError("Only nonmutating archcheck commands are admitted")
    timeout=command["timeout_seconds"]
    if type(timeout) is not int or not 1<=timeout<=900:raise ValueError("Invalid direct deadline")
    row={"label":label,"argv":[str(executable),*args],"cwd":str(cwd),"started_utc":now(),
         "direct_timeout_seconds":timeout,"settled":False,"timed_out":False,"whole_process_tree_deadline_enforced":False}
    save(out/(label+".started.json"),row)
    child=None;started=time.monotonic()
    try:
        with (out/(label+".stdout.log")).open("xb") as stdout,(out/(label+".stderr.log")).open("xb") as stderr:
            child=subprocess.Popen(row["argv"],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
            row["pid"]=child.pid;save(out/(label+".launched.json"),row)
            try:
                row["exit_code"]=child.wait(timeout=timeout);row["settled"]=True
            except subprocess.TimeoutExpired:
                row.update(timed_out=True,error="Direct child deadline expired")
    except BaseException as error:
        row.update(error_type=type(error).__name__,error=str(error))
    finally:
        if child is not None and not row["settled"]:
            row.update(process_tree_unresolved=True,retain_runtime_and_logs=True,termination_method="Popen.terminate with retained original direct-child handle")
            try:
                child.terminate();row["exit_code"]=child.wait(timeout=10);row["settled"]=True
            except BaseException as error:row["termination_error"]=type(error).__name__+": "+str(error)
        row.update(seconds=time.monotonic()-started,finished_utc=now())
        for stream in ("stdout","stderr"):
            p=out/(label+"."+stream+".log")
            if p.exists():
                raw=p.read_bytes();row[stream]={"bytes":len(raw),"sha256":sha(raw)}
    output=(out/(label+".stdout.log")).read_bytes()+(out/(label+".stderr.log")).read_bytes()
    valid=row["settled"] and not row["timed_out"] and not row.get("error_type") and row.get("exit_code")==command["expected_exit_code"]
    for needle in command.get("required_output",[]):valid=valid and needle.encode() in output
    if command["tool"]=="gofmt":valid=valid and not output
    if args[0]=="test" and "-json" in args and "-c" not in args:
        terminal={"pass":[],"fail":[],"skip":[]}
        for line in (out/(label+".stdout.log")).read_bytes().splitlines():
            try:event=json.loads(line)
            except ValueError:continue
            action=event.get("Action")
            if action in terminal:terminal[action].append(event.get("Test","PACKAGE:"+event.get("Package","")))
        row["tests"]=terminal
        for action,names in command.get("required_tests",{}).items():
            observed=Counter(terminal[action]);required=Counter(names)
            valid=valid and all(observed[n]>=count for n,count in required.items())
        if command["expected_exit_code"]==0:valid=valid and not terminal["fail"]
        if not command.get("required_tests") and "-bench" not in args:raise RuntimeError("Test plan lacks an event oracle")
    row["oracle_pass"]=bool(valid)
    save(out/(label+".receipt.json"),row)
    print(json.dumps({k:row.get(k) for k in ("label","exit_code","seconds","oracle_pass","timed_out")}),flush=True)
    return row

def main():
    if os.name!="nt" or sys.flags.optimize or Path(__file__).resolve().parent!=ROOT or len(sys.argv)!=3:
        raise RuntimeError("Use the owned Windows runner with an exact manifest SHA256")
    plan_path=own(sys.argv[1]);raw=plan_path.read_bytes()
    if sha(raw)!=sys.argv[2]:raise RuntimeError("Manifest hash differs from reviewed caller pin")
    plan=json.loads(raw)
    if plan.get("schema")!=1 or plan.get("runner_sha256")!=sha(Path(__file__).read_bytes()) or plan.get("native_scheduler_operations") is not False:
        raise RuntimeError("Unadmitted runner or native task scope")
    phase=plan["phase"]
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,63}",phase):raise ValueError("Invalid phase")
    out=own("evidence/"+phase);out.mkdir(parents=True,exist_ok=False)
    runtime=own("runtime/"+phase);runtime.mkdir(parents=True,exist_ok=False)
    receipt={"schema":1,"phase":phase,"manifest_sha256":sha(raw),"runner_sha256":sha(Path(__file__).read_bytes()),
             "started_utc":now(),"source_head":plan["source_head"],"source_tree":plan["source_tree"],
             "commands":[],"completed":False,"native_scheduler_operations":False}
    save(out/"receipt-initial.json",receipt)
    try:
        env=environment(runtime,plan.get("environment",{}))
        receipt["environment"]={k:env[k] for k in sorted(env) if k.startswith(("GO","MCPHUB_","XDG_")) or k in ("USERPROFILE","APPDATA","LOCALAPPDATA","TEMP","TMP","CC","PSModuleAnalysisCachePath")}
        for p,digest in PINS.items():
            if sha(Path(p).read_bytes())!=digest:raise RuntimeError("Installed tool changed: "+p)
        receipt["tools_sha256"]=PINS
        receipt["source_before"]=check_files(plan["source_directory"],plan["source_files"],True)
        receipt["inputs_before"]=check_files(plan["inputs_directory"],plan["input_files"])
        for command in plan["commands"]:
            row=execute(out,env,command,own(plan["source_directory"]))
            receipt["commands"].append(row)
            if not row["oracle_pass"]:raise RuntimeError("Command failed its declared oracle: "+command["label"])
        receipt["source_after"]=check_files(plan["source_directory"],plan["source_files"],True)
        receipt["inputs_after"]=check_files(plan["inputs_directory"],plan["input_files"])
        if sha(plan_path.read_bytes())!=receipt["manifest_sha256"] or sha(Path(__file__).read_bytes())!=receipt["runner_sha256"]:
            raise RuntimeError("Manifest or runner changed")
        for p,digest in PINS.items():
            if sha(Path(p).read_bytes())!=digest:raise RuntimeError("Tool changed during execution")
        receipt["completed"]=True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__,error=str(error))
        raise
    finally:
        if "source_before" in receipt and "source_after" not in receipt:
            try:receipt["source_after"]=check_files(plan["source_directory"],plan["source_files"],True)
            except BaseException as error:receipt["source_after_error"]=type(error).__name__+": "+str(error)
        if "inputs_before" in receipt and "inputs_after" not in receipt:
            try:receipt["inputs_after"]=check_files(plan["inputs_directory"],plan["input_files"])
            except BaseException as error:receipt["inputs_after_error"]=type(error).__name__+": "+str(error)
        receipt["finished_utc"]=now();save(out/"receipt.json",receipt)
        print(json.dumps({k:receipt.get(k) for k in ("phase","completed","error","source_before","source_after")}),flush=True)

if __name__=="__main__":
    main()
