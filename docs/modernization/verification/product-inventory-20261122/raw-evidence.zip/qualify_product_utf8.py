"""Execute only reviewed inventory statements; no Product build or install."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-continuation-product-20261122-e51f")
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
ZIP_SHA = "dfa893526eda85cf65acbeb2d5ac474cbb4cc6f770365ca82b375c5a768c35ff"
FILES = {
    "inputs/pr657/build.ps1": "9dd728889a303534e872913832ba89614cfc79b50a4eb1d864e8fe287b22ab7b",
    "publication/build.ps1": "bc55dd0815e95c6dc5a19513f07e6a8b5eab636382a16e9940e28b209dd1b8f2",
    "composition/build.ps1": "8735f68771d545b814a3c609a8d019ec03adb9f0266fb1fcb3918e9029fb9579",
    "windows-product-artifacts.json": "3442d29fcc99611c299d9c9e6496ed2cfe7f9b5192f8452298fe2dd6e229cd0b",
    "test-product-inventory.ps1": "4089d9dbf4e30a712b03563ab280fd2245f70a6928b5f118699ba1b48389e9e4",
    "test-product-inventory-utf8.ps1": "993c1e62444d14f7b5c9015d307113ce0a8df19ee267ac4a29260f2d88df3e03",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe(path):
    parts = path.relative_to(ROOT).parts
    current = ROOT
    for part in (None, *parts):
        if part is not None:
            current /= part
        if current.exists():
            if current.is_symlink() or getattr(current.lstat(), "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Unexpected task reparse point")
    return path

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Unexpected platform/root")
    safe(ROOT)
    for name, expected in FILES.items():
        if sha(safe(ROOT / name).read_bytes()) != expected:
            raise RuntimeError("Input member mismatch: " + name)
    evidence = safe(ROOT / "evidence-utf8")
    evidence.mkdir(exist_ok=False)
    runtime = safe(ROOT / "runtime-utf8")
    runtime.mkdir(exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata"):
        (runtime / name).mkdir()
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith("MCPHUB_")}
    env.update({"TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"),
                "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
                "LOCALAPPDATA": str(runtime / "localappdata"), "PYTHONDONTWRITEBYTECODE": "1",
                "PSModulePath": str(PS.parent / "Modules")})
    receipt = {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "runner_sha256": sha(Path(__file__).read_bytes()), "input_zip_sha256": ZIP_SHA,
               "inputs_sha256": FILES, "powershell_sha256_before": sha(PS.read_bytes()),
               "commands": [], "completed": False,
               "boundary": "Exact three inventory statements, mocked provider; no build/install/native lifecycle",
               "execution_policy_changed": False}
    def save():
        (evidence / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    def run(label, arguments, expected):
        item = {"label": label, "argv": list(map(str, arguments)), "expected_exit": expected}
        receipt["commands"].append(item)
        save()
        out, err = evidence / (label + ".stdout"), evidence / (label + ".stderr")
        started = time.monotonic()
        try:
            with out.open("xb") as stdout, err.open("xb") as stderr:
                result = subprocess.run(list(map(str, arguments)), cwd=ROOT, env=env,
                                        stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                        timeout=45, check=False)
            item.update(exit_code=result.returncode, direct_child_waited=True)
        except subprocess.TimeoutExpired:
            item.update(timed_out=True, direct_child_waited=True,
                        descendant_settlement="not_established; preserve task root")
            raise
        finally:
            item["seconds"] = round(time.monotonic() - started, 3)
            item["stdout"] = {"bytes": out.stat().st_size, "sha256": sha(out.read_bytes())}
            item["stderr"] = {"bytes": err.stat().st_size, "sha256": sha(err.read_bytes())}
            save()
        if result.returncode != expected or err.stat().st_size:
            raise RuntimeError("Unexpected process result: " + label)
        print(json.dumps({"label": label, "exit_code": result.returncode}), flush=True)
        return out.read_bytes().decode("utf-8-sig")
    try:
        policy = "$ErrorActionPreference='Stop'; [pscustomobject]@{version=$PSVersionTable.PSVersion.ToString(); effective=(Get-ExecutionPolicy).ToString(); scopes=@(Get-ExecutionPolicy -List | ForEach-Object {[pscustomobject]@{scope=$_.Scope.ToString(); policy=$_.ExecutionPolicy.ToString()}})} | ConvertTo-Json -Compress -Depth 4"
        receipt["policy_before"] = json.loads(run("policy-before", [PS, "-NoProfile", "-NonInteractive", "-Command", policy], 0))
        if receipt["policy_before"]["effective"] not in ("Unrestricted", "RemoteSigned"):
            raise RuntimeError("Existing execution policy does not admit this unsigned local harness")
        for label, path, expected in (("control", "inputs/pr657/build.ps1", 1),
                                      ("publication", "publication/build.ps1", 0),
                                      ("composition", "composition/build.ps1", 0)):
            output = run(label, [PS, "-NoProfile", "-NonInteractive", "-File", ROOT / "test-product-inventory-utf8.ps1",
                                "-BuildScript", ROOT / path, "-RegistryPath", ROOT / "windows-product-artifacts.json"], expected)
            rows = [json.loads(line) for line in output.splitlines() if line.strip()]
            if len(rows) != 11 or len({row["case"] for row in rows}) != 11:
                raise RuntimeError("Unexpected case count")
            if any(row["build_sha256"] != FILES[path] for row in rows):
                raise RuntimeError("Executed source identity mismatch")
            failures = [row["case"] for row in rows if row["outcome"] != "PASS"]
            if (label == "control" and "ancestor-case-only" not in failures) or (label != "control" and failures):
                raise RuntimeError("Regression oracle mismatch")
            receipt[label] = {"pass": len(rows) - len(failures), "fail": len(failures), "failed_cases": failures}
        receipt["policy_after"] = json.loads(run("policy-after", [PS, "-NoProfile", "-NonInteractive", "-Command", policy], 0))
        if receipt["policy_before"] != receipt["policy_after"]:
            raise RuntimeError("Execution policy changed")
        receipt["powershell_sha256_after"] = sha(PS.read_bytes())
        if receipt["powershell_sha256_after"] != receipt["powershell_sha256_before"]:
            raise RuntimeError("PowerShell image changed")
        for name, expected in FILES.items():
            if sha((ROOT / name).read_bytes()) != expected:
                raise RuntimeError("Input changed during qualification: " + name)
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()

if __name__ == "__main__":
    main()
