#Requires -Version 5.1
param(
    [Parameter(Mandatory = $true)][string]$BuildScript,
    [Parameter(Mandatory = $true)][string]$RegistryPath
)

$ErrorActionPreference = "Stop"
if ([System.Environment]::OSVersion.Platform -ne [System.PlatformID]::Win32NT) {
    throw "This inventory qualification requires Windows path semantics"
}

# Parse the supplied source, then execute only its three inventory statements.
# All other build statements, including resource generation and Go, stay inert.
$tokens = $null
$parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile(
    [IO.Path]::GetFullPath($BuildScript), [ref]$tokens, [ref]$parseErrors)
if (@($parseErrors).Count -ne 0) { throw "Build script has parser errors" }
$statements = @($ast.EndBlock.Statements)
$inventoryStarts = @(
    for ($i = 0; $i -lt $statements.Count; $i++) {
        if ($statements[$i] -is [System.Management.Automation.Language.AssignmentStatementAst] -and
            $statements[$i].Left -is [System.Management.Automation.Language.VariableExpressionAst] -and
            $statements[$i].Left.VariablePath.UserPath -ceq "mcpHubExecutables") { $i }
    }
)
if ($inventoryStarts.Count -ne 1) { throw "Expected one inventory assignment in the source" }
$start = [int]$inventoryStarts[0]
if ($start + 2 -ge $statements.Count -or
    $statements[$start + 1] -isnot [System.Management.Automation.Language.AssignmentStatementAst] -or
    $statements[$start + 1].Left -isnot [System.Management.Automation.Language.VariableExpressionAst] -or
    $statements[$start + 1].Left.VariablePath.UserPath -cne "expectedExecutables" -or
    $statements[$start + 2] -isnot [System.Management.Automation.Language.IfStatementAst]) {
    throw "Inventory source no longer has the expected three-statement boundary"
}
$refusal = "Windows output must contain exactly the registry's CUI and GUI executable paths"
if (-not $statements[$start + 2].Extent.Text.Contains($refusal)) {
    throw "Inventory refusal boundary changed"
}
$guard = [scriptblock]::Create((@(
    $statements[$start].Extent.Text
    $statements[$start + 1].Extent.Text
    $statements[$start + 2].Extent.Text
) -join [Environment]::NewLine))

$registry = Get-Content -Raw -Encoding UTF8 -LiteralPath $RegistryPath | ConvertFrom-Json
if ($registry.schemaVersion -ne 3 -or @($registry.artifacts).Count -ne 2 -or
    $registry.identityManifest.schema -cne "windows-product-identity-v1" -or
    @($registry.artifacts | Where-Object { $_.role -ceq "launcher" -and $_.filename -ceq "mcphub.exe" }).Count -ne 1 -or
    @($registry.artifacts | Where-Object { $_.role -ceq "product" -and $_.filename -ceq "mcphub-product/mcphub.exe" }).Count -ne 1) {
    throw "Expected the declared V1 canonical launcher and Product registry"
}

$requestedRoot = 'D:\dev\ChatGPT\InventoryProduct'
$exact = @('mcphub.exe', 'mcphub-product\mcphub.exe')
$cases = @(
    [pscustomobject]@{ Name = 'exact'; Paths = $exact; Root = $requestedRoot; Accept = $true }
    [pscustomobject]@{ Name = 'ancestor-case-only'; Paths = $exact; Root = $requestedRoot.ToLowerInvariant(); Accept = $true }
    [pscustomobject]@{ Name = 'reversed-enumeration'; Paths = @($exact[1], $exact[0]); Root = $requestedRoot; Accept = $true }
    [pscustomobject]@{ Name = 'missing-launcher'; Paths = @($exact[1]); Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'missing-product'; Paths = @($exact[0]); Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'extra-root-executable'; Paths = @($exact) + 'mcphub-extra.exe'; Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'extra-nested-executable'; Paths = @($exact) + 'mcphub-product\mcphub-extra.exe'; Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'launcher-case'; Paths = @('MCPHUB.exe', $exact[1]); Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'product-case'; Paths = @($exact[0], 'mcphub-product\MCPHUB.exe'); Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'product-directory-case'; Paths = @($exact[0], 'MCPHUB-PRODUCT\mcphub.exe'); Root = $requestedRoot; Accept = $false }
    [pscustomobject]@{ Name = 'product-ignorable-character'; Paths = @($exact[0], ('mcphub-product\mcphub' + [char]0x00ad + '.exe')); Root = $requestedRoot; Accept = $false }
)

function Invoke-InventoryCase {
    param([psobject]$Case)
    $outDir = $requestedRoot
    $artifacts = @($registry.artifacts)
    $calls = @(0)
    # This is an explicit provider-result seam. It varies only the enumerated
    # paths and ancestor spelling; no Product, PE or native authority is issued.
    function Get-ChildItem {
        param([string]$LiteralPath, [switch]$File, [string]$Filter, [switch]$Recurse, [switch]$Name)
        if ($LiteralPath -cne $outDir -or -not $File -or -not $Recurse -or $Filter -cne 'mcphub*.exe') {
            throw "Unexpected inventory provider query"
        }
        $calls[0]++
        foreach ($relative in $Case.Paths) {
            if ($Name) { $relative } else { [pscustomobject]@{ FullName = Join-Path $Case.Root $relative } }
        }
    }
    $accepted = $false
    try {
        & $guard
        $accepted = $true
    } catch {
        if ($_.Exception.Message -cne $refusal) { throw }
    }
    if ($calls[0] -ne 1) { throw "Expected exactly one inventory provider call" }
    return $accepted
}

$failures = 0
$sourceSHA256 = (Get-FileHash -LiteralPath $BuildScript -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($case in $cases) {
    $accepted = Invoke-InventoryCase $case
    $passed = $accepted -eq $case.Accept
    if (-not $passed) { $failures++ }
    [pscustomobject]@{
        case = $case.Name
        expected_accept = $case.Accept
        actual_accept = $accepted
        outcome = $(if ($passed) { 'PASS' } else { 'FAIL' })
        build_sha256 = $sourceSHA256
    } | ConvertTo-Json -Compress
}
if ($failures -ne 0) { exit 1 }
exit 0
