"""Export the completed, exact four-list inventory; never run project code.
Read only the explicit evidence allowlist. Create a fresh public directory/ZIP.
Runtime/cache/binary/source contents are excluded. Preserve original byte hashes.
"""
import sys
sys.dont_write_bytecode = True
import hashlib
import json
import os
import stat
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(r"D:\dev\ChatGPT\mcp-r23-go-inventory-20261121")
HEAD = "f12932bcca6c288d062f9affd32ea58a7c9eb74f"
TREE = "79a36a7aca62cd2c08cb6a1a79a1f7d58ad6010c"
RUNNER_SHA = "4b6404c2218aef6f08c8dbcbcf77eba1eea84d453540c984fba648594c1225dd"
CASES = ("api-normal", "cli-normal", "api-tagged", "cli-tagged")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def safe_read(relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or ".." in rel.parts:
        raise RuntimeError("Unsafe relative evidence path")
    path = ROOT.joinpath(*rel.parts)
    for item in [path, *path.parents]:
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError("Reparse point in evidence path")
        if item == ROOT:
            break
    if not path.is_file():
        raise RuntimeError("Required evidence is not a regular file")
    return path.read_bytes()


def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Wrong export location or platform")
    public = ROOT / "public-inventory"
    archive = ROOT / "public-inventory.zip"
    receipt_path = ROOT / "export-inventory-receipt.json"
    if any(path.exists() for path in (public, archive, receipt_path)):
        raise RuntimeError("Fresh export paths required; no overwrite")
    receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "completed": False,
               "exporter_sha256": digest(Path(__file__).read_bytes())}
    receipt_path.write_bytes(encoded(receipt))
    try:
        payload, source_manifests = {}, []
        runner = safe_read("run_inventory.py")
        if digest(runner) != RUNNER_SHA:
            raise RuntimeError("Runner differs from executed revision")
        payload["run_inventory.py"] = runner
        payload["export_inventory.py"] = Path(__file__).read_bytes()
        payload["REVIEW.md"] = safe_read("REVIEW.md")
        payload["reviewed-source-manifest.json"] = safe_read("reviewed-source-manifest.json")
        phases = {}
        verified_streams = 0
        for phase in ("prepare", "inventory"):
            raw = safe_read(phase + "/receipt.json")
            data = json.loads(raw)
            if (not data["completed"] or data["expected_head"] != HEAD or data["expected_tree"] != TREE or
                    data["runner_sha256"] != RUNNER_SHA or data["tools_before"] != data["tools_after"] or
                    any(data[key] for key in ("test_bodies_run", "benchmark_bodies_run", "shards_executed", "software_installed", "branches_integrated"))):
                raise RuntimeError("Phase does not meet selected scope: " + phase)
            phases[phase] = data
            payload[phase + "/receipt.json"] = raw
            for command in data["commands"]:
                if command["exit_code"] != 0 or not command["settled"] or command.get("timed_out"):
                    raise RuntimeError("Failed or incomplete command")
                for name, expected in command["streams"].items():
                    relative = phase + "/" + name
                    stream = safe_read(relative)
                    if len(stream) != expected["bytes"] or digest(stream) != expected["sha256"]:
                        raise RuntimeError("Original stream mismatch: " + relative)
                    payload[relative] = stream
                    verified_streams += 1
        prepared = phases["prepare"]["source"]
        inventory = phases["inventory"]
        if prepared != inventory["source_before"] or prepared != inventory["source_after"]:
            raise RuntimeError("Source changed between preparation and inventory")
        for relative in ("prepare/prepared-source-manifest.json", "inventory/source-before-manifest.json", "inventory/source-after-manifest.json"):
            raw = safe_read(relative)
            manifest = json.loads(raw)
            files = manifest.pop("file_hashes")
            aggregate = digest(json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8"))
            if manifest != prepared or len(files) != prepared["files"] or aggregate != prepared["aggregate_sha256"]:
                raise RuntimeError("Retained full source manifest mismatch")
            source_manifests.append({"retained_not_exported": relative, "bytes": len(raw), "sha256": digest(raw), **manifest})
        payload["source-qualification.json"] = encoded({"source": prepared, "full_manifests_retained_outside_trash": source_manifests,
                                                        "tools": inventory["tools_after"], "inventory_tool_sha256": inventory["inventory_tool_sha256"]})
        if [row["label"] for row in inventory["inventories"]] != list(CASES):
            raise RuntimeError("Unexpected inventory selection")
        comparisons = {}
        roots_by_case = {}
        for row in inventory["inventories"]:
            case = row["label"]
            for name, expected in row["files"].items():
                relative = "evidence/" + case + "/" + name
                raw = safe_read(relative)
                if len(raw) != expected["bytes"] or digest(raw) != expected["sha256"]:
                    raise RuntimeError("Inventory file mismatch")
                payload[relative] = raw
            plan = json.loads(payload["evidence/" + case + "/plan.json"])
            roots = [name for group in plan["shards"] for name in group["roots"]]
            if (plan["commit"] != HEAD or len(roots) != row["roots"] or len(set(roots)) != len(roots) or
                    plan["equivalentToSingleProcess"] or not plan["mandatoryUnshardedGateUnchanged"]):
                raise RuntimeError("Plan verification failed")
            roots_by_case[case] = roots
        for package in ("api", "cli"):
            normal, tagged = roots_by_case[package + "-normal"], roots_by_case[package + "-tagged"]
            comparisons[package] = {"same_ordered_roots": normal == tagged,
                                    "only_normal": sorted(set(normal) - set(tagged)), "only_tagged": sorted(set(tagged) - set(normal))}
        payload["inventory-comparison.json"] = encoded(comparisons)
        rows = ["| Selection | ROOT names | Test / Example / Fuzz | Benchmarks listed, not run | Groups planned, not executed |",
                "|---|---:|---|---:|---:|"]
        for row in inventory["inventories"]:
            counts = row["types"]
            rows.append(f"| {row['label']} | {row['roots']} | {counts['Test']} / {counts['Example']} / {counts['Fuzz']} | {row['benchmarks_not_run']} | {row['shards_planned_not_executed']} |")
        text = """# Qualified Go test inventories

## Contents

1. [Results](#results)
2. [Source and scope](#source-and-scope)
3. [Evidence and limits](#evidence-and-limits)

## Results

All four selected compiled inventories completed successfully. ROOT means a top-level test, example, or fuzz-test name. API means application programming interface; CLI means command-line interface.

""" + "\n".join(rows) + "\n\n"
        text += "The build tag is `test_state_path_env`. Normal and tagged ordered ROOT lists are identical for API: `" + str(comparisons["api"]["same_ordered_roots"]).lower() + "`; for CLI: `" + str(comparisons["cli"]["same_ordered_roots"]).lower() + "`. Exact differences, if any, are in `inventory-comparison.json`.\n\n"
        text += """## Source and scope

Source commit: `""" + HEAD + "`, tree `" + TREE + "`. Preparation and inventory used a new detached checkout. The clean source and all " + str(prepared["files"]) + " tracked-file hashes matched before and after; aggregate SHA-256: `" + prepared["aggregate_sha256"] + "`.\n\n"
        text += "The existing Go compiler reported `" + inventory["go_version"] + "`. The standalone tool build selected only `./tools/testshards`; each listing also compiled the selected package's test binary. The four plan invocations used explicit `-execute=false`; the underlying operation was `go test -list . -p=1` for API or CLI, with the tag on the two tagged selections. Package initialization and existing `TestMain` setup/cleanup ran. Test, example, fuzz and benchmark bodies and planned groups were not executed. Module/toolchain downloads were disabled. No branch integration or installation occurred.\n\n"
        text += "Preparation: `" + phases["prepare"]["started_utc"] + "` to `" + phases["prepare"]["finished_utc"] + "`. Inventory: `" + inventory["started_utc"] + "` to `" + inventory["finished_utc"] + "`. These source receipt times use Coordinated Universal Time (UTC); Moscow time is UTC plus three hours.\n\n"
        text += """## Evidence and limits

`REVIEW.md` explains the source review, prerequisites, environment allowlist and exact execution boundary. The package contains the executed controller, this exporter, both original receipts, every receipt-referenced command stream, all four original lists and plans, and derived source/comparison summaries. SHA-256 means the Secure Hash Algorithm with a 256-bit digest. `PUBLIC-HASHES.json` records every payload size and checksum; all copied payload bytes are unchanged. Generated summaries are identified separately. No redaction was needed for selected evidence.

The full source tree, executable binaries, full source manifests, runtime directories and caches remain outside this public package. The three retained full source manifests were checked against the receipts and recomputed aggregate; their original checksums are in `source-qualification.json`. Source file contents are available at the exact public commit.

All top-level commands returned exit code zero and settled through retained direct handles. The controller does not prove deadline enforcement or settlement for an entire descendant process tree. The original inventory tool clears child `GOFLAGS`; source hashes and cleanliness were rechecked after execution.

These inventories establish compiled top-level names, counts and a diagnostic grouping plan. They establish neither nested subtest counts nor successful test-body execution or durations. They do not replace the unchanged five-minute unsharded gate, qualify the historical failing source, or reconstruct the missing historical Go JSON event trace (JSON is JavaScript Object Notation).
"""
        payload["RESULTS.md"] = text.encode("utf-8")
        generated = {"source-qualification.json", "inventory-comparison.json", "RESULTS.md"}
        hashes = {"schema": 1, "redactions": [], "files": [
            {"path": path, "bytes": len(data), "sha256": digest(data),
             "origin": "generated_summary" if path in generated else "unchanged_selected_file"}
            for path, data in sorted(payload.items())]}
        payload["PUBLIC-HASHES.json"] = encoded(hashes)
        public.mkdir()
        for path, data in sorted(payload.items()):
            destination = public.joinpath(*PurePosixPath(path).parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(data)
        with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
            for path, data in sorted(payload.items()):
                bundle.writestr(path, data)
        with zipfile.ZipFile(archive) as bundle:
            if bundle.testzip() is not None or sorted(bundle.namelist()) != sorted(payload):
                raise RuntimeError("Archive membership or CRC verification failed")
            for path, original in payload.items():
                if bundle.read(path) != original:
                    raise RuntimeError("Archive byte mismatch")
        receipt.update(completed=True, archive=str(archive), archive_bytes=archive.stat().st_size,
                       archive_sha256=digest(archive.read_bytes()), entries=len(payload), payload_hashes=len(hashes["files"]),
                       verified_original_command_streams=verified_streams,
                       public_hash_manifest_sha256=digest(payload["PUBLIC-HASHES.json"]))
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        receipt_path.write_bytes(encoded(receipt))
        print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
