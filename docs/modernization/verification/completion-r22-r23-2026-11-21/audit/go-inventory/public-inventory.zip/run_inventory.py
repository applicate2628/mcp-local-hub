"""Prepare one detached source, then plan four Go inventories after Root review.
No shard execution, test/benchmark bodies, installation, or branch integration.
Existing TestMain initialization and cleanup run during Go's -list operation.
The wrapper retains direct process handles; it makes no whole-tree claim.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import json
import os
import re
import stat
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(r"D:\dev\ChatGPT\mcp-r23-go-inventory-20261121")
SOURCE = ROOT / "source"
STORE = ROOT / "repository.git"
HEAD = "f12932bcca6c288d062f9affd32ea58a7c9eb74f"
TREE = "79a36a7aca62cd2c08cb6a1a79a1f7d58ad6010c"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GCC = Path(r"C:\msys64\ucrt64\bin\gcc.exe")
GOROOT = Path(r"C:\msys64\ucrt64\lib\go")
GOCACHE = Path(r"D:\dev\ChatGPT\mcp-go-gate-followup-20261120-081343\runtime\gocache")
GOMODCACHE = Path(r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache")
GO_SHA = "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113"
GCC_SHA = "f6ff9378c1edb591131304518eac6456708d28720284105930d0d687136bcdd3"
CASES = (("api-normal", "./internal/api", ""), ("cli-normal", "./internal/cli", ""),
         ("api-tagged", "./internal/api", "test_state_path_env"),
         ("cli-tagged", "./internal/cli", "test_state_path_env"))

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("prepare", "inventory"))
    args = parser.parse_args()
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Wrong platform or runner location")
    os.chdir(ROOT)
    run = ROOT / args.phase
    run.mkdir(exist_ok=False)
    receipt_path = run / "receipt.json"
    receipt = {"phase": args.phase, "started_utc": now(), "completed": False,
               "expected_head": HEAD, "expected_tree": TREE, "runner_sha256": sha(Path(__file__)),
               "commands": [], "inventories": [], "test_bodies_run": False, "benchmark_bodies_run": False,
               "shards_executed": False, "software_installed": False, "branches_integrated": False,
               "whole_process_tree_deadline_enforced": False, "whole_process_tree_settlement_proven": False}
    save(receipt_path, receipt)
    runtime = run / "runtime"
    for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks", "empty-template"):
        (runtime / name).mkdir(parents=True, exist_ok=False)
    essentials = {"SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "SYSTEMDRIVE", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE"}
    env = {key: value for key, value in os.environ.items() if key.upper() in essentials}
    env.update({"PATH": os.pathsep.join(map(str, [GO.parent, GIT.parent, Path(os.environ["SystemRoot"]) / "System32"])),
                "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
                "GOTMPDIR": str(runtime / "tmp"), "HOME": str(runtime / "profile"), "USERPROFILE": str(runtime / "profile"),
                "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata"),
                "GOROOT": str(GOROOT), "GOCACHE": str(GOCACHE), "GOMODCACHE": str(GOMODCACHE), "GOPATH": str(runtime / "gopath"),
                "GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off",
                "GOWORK": "off", "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "GOMAXPROCS": "4", "CGO_ENABLED": "1", "CC": str(GCC),
                "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_SUPPRESS_BROWSER_LAUNCH": "1", "MCPHUB_E2E_SCHEDULER": "none",
                "MIMOCODE_DISABLE_CLAUDE_CODE_MCP": "1", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "NUL",
                "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0", "GIT_LFS_SKIP_SMUDGE": "1",
                "PYTHONDONTWRITEBYTECODE": "1"})
    receipt["explicit_environment"] = env
    receipt["tool_clears_child_GOFLAGS"] = True
    receipt["existing_TestMain_cleanup"] = "Owned temporary state roots use original apitest.RemoveTestMainRoot/os.RemoveAll; evidence is retained."
    git_options = [GIT, "-c", "core.fsmonitor=false", "-c", "core.hooksPath=" + str(runtime / "empty-hooks"),
                   "-c", "core.autocrlf=false", "-c", "credential.helper="]

    def command(name, argv, cwd=ROOT, timeout=300):
        row = {"name": name, "argv": list(map(str, argv)), "cwd": str(cwd), "started_utc": now(), "settled": False}
        receipt["commands"].append(row)
        save(receipt_path, receipt)
        outpath, errpath = run / (name + ".stdout.log"), run / (name + ".stderr.log")
        proc = None
        started = time.monotonic()
        try:
            with outpath.open("xb") as out, errpath.open("xb") as err:
                proc = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                        stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
                row["pid"] = proc.pid
                save(receipt_path, receipt)
                try:
                    row["exit_code"] = proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    proc.kill()  # Continuously held direct process handle only.
                    row["exit_code"] = proc.wait(timeout=30)
                row["settled"] = True
        finally:
            if proc is not None and proc.poll() is None:
                try:
                    proc.kill()
                    row["exit_code"] = proc.wait(timeout=30)
                    row["settled"] = True
                except BaseException as error:
                    row["settlement_error"] = repr(error)
            row["seconds"] = time.monotonic() - started
            row["finished_utc"] = now()
            row["streams"] = {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)} for path in (outpath, errpath) if path.exists()}
            save(receipt_path, receipt)
        if row.get("timed_out") or row.get("exit_code") != 0:
            raise RuntimeError("Command failed; retained evidence: " + name)
        return outpath.read_bytes()

    def source_snapshot(label, full=False):
        head = command(label + "-head", [*git_options, "-C", SOURCE, "rev-parse", "HEAD"], timeout=30).decode().strip()
        tree = command(label + "-tree", [*git_options, "-C", SOURCE, "rev-parse", "HEAD^{tree}"], timeout=30).decode().strip()
        status = command(label + "-status", [*git_options, "-C", SOURCE, "status", "--porcelain=v1", "--untracked-files=all"], timeout=60).decode()
        if head != HEAD or tree != TREE or status:
            raise RuntimeError("Source HEAD/tree/cleanliness differs")
        names = command(label + "-files", [*git_options, "-C", SOURCE, "ls-files", "-z"], timeout=30).decode("utf-8").split("\0")
        files, checked_dirs = [], set()
        for name in sorted(name for name in names if name):
            rel = PurePosixPath(name)
            if rel.is_absolute() or ".." in rel.parts:
                raise RuntimeError("Unexpected tracked source path")
            path = SOURCE.joinpath(*rel.parts)
            for node in [path, *path.parents]:
                if node == SOURCE.parent:
                    break
                if node not in checked_dirs:
                    attributes = node.lstat()
                    if stat.S_ISLNK(attributes.st_mode) or getattr(attributes, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                        raise RuntimeError("Reparse point in source")
                    if node != path:
                        checked_dirs.add(node)
            files.append({"path": name, "bytes": path.stat().st_size, "sha256": sha(path)})
        packed = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
        result = {"head": head, "tree": tree, "status": status, "files": len(files),
                  "aggregate_sha256": hashlib.sha256(packed).hexdigest()}
        if full:
            save(run / (label + "-manifest.json"), {**result, "file_hashes": files})
        return result

    before = None
    failure = None
    try:
        for path in (GIT, GO, GCC):
            if not path.is_file():
                raise RuntimeError("Required existing tool missing: " + str(path))
        for path in (GOROOT / "src/runtime/runtime2.go", GOROOT / "pkg/tool/windows_amd64/compile.exe"):
            if not path.is_file():
                raise RuntimeError("Existing GOROOT incomplete")
        for path in (GOCACHE, GOMODCACHE):
            if not path.is_dir():
                raise RuntimeError("Existing cache missing: " + str(path))
        receipt["tools_before"] = {path.name: sha(path) for path in (GIT, GO, GCC)}
        if receipt["tools_before"][GO.name] != GO_SHA or receipt["tools_before"][GCC.name] != GCC_SHA:
            raise RuntimeError("Existing Go/GCC differ from qualified tools")
        if args.phase == "prepare":
            if SOURCE.exists() or STORE.exists():
                raise RuntimeError("Fresh Git store and detached source required")
            command("git-init", [*git_options, "init", "--bare", "--template=" + str(runtime / "empty-template"), STORE], timeout=30)
            for key, value in (("core.longpaths", "true"), ("core.autocrlf", "false"), ("core.fsmonitor", "false"),
                               ("core.hooksPath", str(runtime / "empty-hooks"))):
                command("config-" + key.replace(".", "-"), [*git_options, "--git-dir=" + str(STORE), "config", key, value], timeout=30)
            command("fetch-exact", [*git_options, "--git-dir=" + str(STORE), "fetch", "--no-tags", "--depth=1", "--no-write-fetch-head",
                                    "https://github.com/applicate2628/mcp-local-hub.git", HEAD])
            command("detached-checkout", [*git_options, "--git-dir=" + str(STORE), "worktree", "add", "--detach", SOURCE, HEAD])
            receipt["source"] = source_snapshot("prepared-source", full=True)
        else:
            prepared = json.loads((ROOT / "prepare/receipt.json").read_bytes())
            if not prepared["completed"] or prepared["source"]["head"] != HEAD or prepared["source"]["tree"] != TREE:
                raise RuntimeError("Completed exact-source preparation required")
            before = source_snapshot("source-before", full=True)
            if before != prepared["source"]:
                raise RuntimeError("Source differs from its preparation")
            receipt["source_before"] = before
            version = command("go-version", [GO, "version"], timeout=30).decode().strip()
            if version != "go version go1.27.4 windows/amd64":
                raise RuntimeError("Unexpected existing Go version")
            receipt["go_version"] = version
            binary = ROOT / "bin/testshards.exe"
            binary.parent.mkdir(exist_ok=False)
            command("build-inventory-tool", [GO, "build", "-mod=readonly", "-p=1", "-trimpath", "-o", binary, "./tools/testshards"], SOURCE)
            receipt["inventory_tool_sha256"] = sha(binary)
            for label, package, tags in CASES:
                evidence = ROOT / "evidence" / label
                argv = [binary, "-repo", SOURCE, "-evidence", evidence, "-package", package,
                        "-go", GO, "-max-roots", "80", "-execute=false"]
                if tags:
                    argv.append("-tags=" + tags)
                command("list-" + label, argv)
                plan = json.loads((evidence / "plan.json").read_bytes())
                roots = [name for shard in plan["shards"] for name in shard["roots"]]
                if (plan["commit"] != HEAD or plan["package"] != package or plan["tags"] != tags or
                        plan["testMainDeclarations"] != 1 or plan["rootCount"] != len(roots) or not roots or
                        len(set(roots)) != len(roots) or plan["equivalentToSingleProcess"] or
                        not plan["mandatoryUnshardedGateUnchanged"] or any(len(part["roots"]) > 80 for part in plan["shards"])):
                    raise RuntimeError("Inventory plan contract differs: " + label)
                receipt["inventories"].append({"label": label, "package": package, "tags": tags, "roots": len(roots),
                                               "shards_planned_not_executed": len(plan["shards"]), "benchmarks_not_run": plan["benchmarksNotRun"],
                                               "types": {prefix: sum(name.startswith(prefix) for name in roots) for prefix in ("Test", "Example", "Fuzz")},
                                               "files": {name: {"bytes": (evidence / name).stat().st_size, "sha256": sha(evidence / name)} for name in ("inventory.txt", "plan.json")}})
                save(receipt_path, receipt)
        receipt["tools_after"] = {path.name: sha(path) for path in (GIT, GO, GCC)}
        if receipt["tools_before"] != receipt["tools_after"]:
            raise RuntimeError("Tools changed during phase")
        receipt["completed"] = True
    except BaseException as error:
        failure = error
        receipt.update(error_type=type(error).__name__, error=str(error))
    finally:
        if before is not None:
            try:
                receipt["source_after"] = source_snapshot("source-after", full=True)
                if receipt["source_after"] != before:
                    raise RuntimeError("Source changed during inventory")
            except BaseException as error:
                failure = error
                receipt.update(completed=False, source_verification_error=str(error))
        receipt["finished_utc"] = now()
        save(receipt_path, receipt)
        print(json.dumps({"phase": args.phase, "completed": receipt["completed"], "error": receipt.get("error"),
                          "source_verification_error": receipt.get("source_verification_error"),
                          "inventories": receipt["inventories"], "receipt": str(receipt_path)}), flush=True)
    if failure:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
