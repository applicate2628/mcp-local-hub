"""Read retained R22 control evidence; never execute commands or rerun tests."""
import sys
sys.dont_write_bytecode = True

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re

ROOT = Path(r"<R22_ROOT>")
SCOPE = ROOT / "scopes/scheduler-rollback"
EVIDENCE = ROOT / "evidence/scheduler-rollback-control"
MANIFEST_SHA = "987a7b86cb80929543d73892ec250cf39c8c1b406a6f5a9dca221cd0a52d1dba"
SPEC_SHA = "9458f6eabd1c776c284d766633ad342fe3d52174a0713a7d4d625d15d8f14788"
WRAPPER_SHA = "25647d3fa88fd20a9e8629f729bed1da517556f182fc0dc97c43e973a4301dd9"
RUNNER_SHA = "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61"
HEAD = "ba17867125b3728fb734e90b383639a3ff9175ee"
TREE = "1c803a8ef8227fe6c289be69c7897aee1549372b"
GO = r"C:\msys64\ucrt64\bin\go.exe"
ERROR_KEYS = {"error_type", "event_error_type", "source_after_error", "source_final_error", "stdout_capture_error", "stderr_capture_error", "termination_error"}
ASSERTION = re.compile(r"(?m)^[ \t]+[^\r\n]+?\.go:\d+: (.*)$")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def validate(report, receipt_sha):
    inputs = report["inputs"]

    def read(path, pin=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        inputs[str(path)] = {"sha256": digest, "bytes": len(raw)}
        need(pin is None or digest == pin, "Input digest differs: " + str(path))
        return raw

    plan = json.loads(read(SCOPE / "manifest.json", MANIFEST_SHA))
    spec = json.loads(read(SCOPE / "control-validation.json", SPEC_SHA))
    read(ROOT / "qualify_scope.py", WRAPPER_SHA)
    receipt = json.loads(read(EVIDENCE / "receipt.json", receipt_sha))
    need(plan["source_head"] == spec["source_head"] == HEAD and plan["source_tree"] == spec["source_tree"] == TREE, "Source pins differ")
    need(receipt.get("scope") == "scheduler-rollback" and receipt.get("phase") == "scheduler-rollback-control", "Wrong scope/phase receipt")
    need(receipt.get("completed") is True and receipt.get("state") == "complete", "Scope did not complete")
    need(not (ERROR_KEYS & receipt.keys()) and not receipt.get("process_tree_unresolved"), "Scope capture or lifecycle is unresolved")
    for key, expected in {"base": HEAD, "base_tree": TREE, "source_head": HEAD, "source_tree": TREE, "scope_manifest_sha256": MANIFEST_SHA, "scope_wrapper_sha256": WRAPPER_SHA, "runner_sha256": RUNNER_SHA, "reused_capture_owner_sha256": RUNNER_SHA}.items():
        need(receipt.get(key) == expected, "Receipt identity differs: " + key)
    need(receipt.get("environment", {}).get("MCPHUB_E2E_SCHEDULER") == "none", "Scheduler test environment changed")
    source = ROOT / "source-pr660"
    original_hashes = {}
    for file in plan["files"]:
        path = source / file["path"]
        raw = read(path) if path.exists() else None
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest() if raw is not None else None
        need(blob == file["original_git_blob"], "Current original blob differs: " + file["path"])
        original_hashes[file["path"]] = hashlib.sha256(raw).hexdigest() if raw is not None else None
        raw = read(SCOPE / "candidate" / file["path"], file["candidate_sha256"])
        need(len(raw) == file["bytes"] and hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest() == file["candidate_git_blob"], "Candidate blob/size differs: " + file["path"])
    overlay_path = EVIDENCE / "overlay.json"
    overlay = json.loads(read(overlay_path, receipt["overlay_sha256"]))
    expected_overlay = {str(source / path): str(SCOPE / "candidate" / path) for path in plan["phases"]["control"]["overlay_paths"]}
    need(overlay == {"Replace": expected_overlay}, "Control overlay differs")
    command = plan["phases"]["control"]["commands"][0]
    need(command["expected_tests"] == spec["expected_terminal_events"], "Manifest/spec test maps differ")
    need(len(receipt["commands"]) == 1, "Control command missing or duplicated")
    row = receipt["commands"][0]
    saved = json.loads(read(EVIDENCE / "control-core.receipt.json"))
    need(row.get("scope_oracle_matched") is True and saved == {k: v for k, v in row.items() if k != "scope_oracle_matched"}, "Command receipt differs from completed scope")
    need(row.get("label") == "control-core" and row.get("executable") == GO and row.get("cwd") == str(source), "Unexpected command owner or destination")
    need(row.get("args") == [str(overlay_path) if a == "{overlay}" else a for a in command["args"]], "Command arguments differ")
    need(row.get("settled") is True and row.get("timed_out") is False and row.get("exit_code") == 1, "Control did not settle with expected exit")
    need(not (ERROR_KEYS & row.keys()) and not row.get("process_tree_unresolved"), "Command capture or lifecycle is unresolved")
    snapshots = [receipt[k] for k in ("source_before", "source_after", "source_final")] + [row[k] for k in ("source_before", "source_after")]
    for snapshot in snapshots:
        need(snapshot == snapshots[0] and snapshot.get("head") == HEAD and snapshot.get("tree") == TREE and snapshot.get("exists") is True and snapshot.get("materialized") is True and snapshot.get("staged") == "" and snapshot.get("status") == "" and snapshot.get("sha256") == original_hashes, "Source snapshot is changed, dirty, or mismatched")
    streams = {}
    for stream in ("stdout", "stderr"):
        streams[stream] = read(EVIDENCE / ("control-core." + stream + ".log"), row[stream]["sha256"])
        need(len(streams[stream]) == row[stream]["bytes"], "Stream size differs: " + stream)
    need(streams["stderr"] == b"", "Unexpected control stderr")
    events = [json.loads(line) for line in streams["stdout"].decode("utf-8").splitlines()]
    need(events and all(isinstance(e, dict) and e.get("Package") == spec["package"] for e in events), "Invalid or unrelated Go JSON events")
    expected = spec["expected_terminal_events"]
    for action in ("pass", "fail", "skip"):
        actual = Counter(e.get("Test", "PACKAGE:" + e["Package"]) for e in events if e.get("Action") == action)
        need(actual == Counter(expected[action]) == Counter(row["tests"][action]), "Terminal event counts differ: " + action)
    rules = {**spec["passes"], **spec["failures"]}
    need(Counter(e["Test"] for e in events if e.get("Action") == "run") == Counter({name: 1 for name in rules}), "Run-event test selection differs")
    output = defaultdict(str)
    for event in events:
        need(event.get("Test") is None or event["Test"] in rules, "Unexpected test event")
        if event.get("Action") == "output":
            output[event.get("Test", "")] += event.get("Output", "")
    rendered = "".join(event.get("Output", "") for event in events)
    for marker in spec["raw_evidence_requirements"]["forbidden_in_stdout_or_stderr"]:
        need(marker not in rendered, "Forbidden runtime or cleanup diagnostic: " + marker)
    assertions = {}
    for name, rule in rules.items():
        found = Counter()
        for message in ASSERTION.findall(output[name]):
            matches = [prefix for prefix in rule["allowed_assertion_prefixes"] if message.startswith(prefix)]
            need(len(matches) == 1, "Unexpected assertion in " + name + ": " + message)
            found[matches[0]] += 1
        need(found == Counter(rule["required_assertion_prefix_counts"]), "Per-test assertion counts differ: " + name)
        assertions[name] = dict(found)
    need(not ASSERTION.findall(output[""]), "Unattributed package assertion")
    report.update(status="confirmed", terminal_counts={a: sum(expected[a].values()) for a in expected}, assertions=assertions, source_git_observation="Retained exact clean snapshots plus current bytes of all admitted paths; no Git command was executed", tests_rerun=False)


if __name__ == "__main__":
    need(os.name == "nt" and not sys.flags.optimize and Path(__file__).resolve().parent == SCOPE, "Run the reviewed validator unoptimized from its R22 scope directory")
    need(len(sys.argv) == 2 and re.fullmatch(r"[0-9a-f]{64}", sys.argv[1]), "Expected one independently recorded phase-receipt SHA-256")
    destination = EVIDENCE / "control-validation-result.json"
    need(not destination.exists(), "Validation result already exists; no overwrite")
    result = {"schema": 1, "status": "rejected", "inputs": {}, "validator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "expected_receipt_sha256": sys.argv[1], "tests_rerun": False}
    try:
        validate(result, sys.argv[1])
    except Exception as error:
        result.update(error_type=type(error).__name__, error=str(error))
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    with destination.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({"status": result["status"], "result": str(destination)}, ensure_ascii=False))
    raise SystemExit(0 if result["status"] == "confirmed" else 1)
