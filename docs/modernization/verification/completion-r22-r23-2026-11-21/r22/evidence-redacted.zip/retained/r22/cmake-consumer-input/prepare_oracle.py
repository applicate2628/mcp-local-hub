"""Read an existing CMake trace and emit an independent consumer oracle.

No CMake/Go/process invocation, installation, network request or source edit.
The output is created exclusively; a prior oracle is never replaced.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def same_path(left, right):
    return os.path.normcase(os.path.abspath(left)) == os.path.normcase(os.path.abspath(right))


def record(row):
    result = {key: row[key] for key in ("file", "line", "cmd", "args")}
    for key in ("time", "frame", "global_frame"):
        if row.get(key, 0) != 0:
            result[key] = row[key]
    if row.get("defer") is not None:
        result["defer"] = True
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixture", required=True, type=Path)
    parser.add_argument("--trace", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    fixture, trace, output = args.fixture, args.trace, args.output
    if not all(path.is_absolute() for path in (fixture, trace, output)):
        raise SystemExit("absolute owned paths required")
    if output.exists() or not output.parent.is_dir():
        raise SystemExit("new oracle file in an existing owned directory required")
    spec = json.loads((fixture / "fixture-manifest.json").read_text(encoding="utf-8"))
    if spec["schema"] != 1 or spec["iterations"] != 16384 or spec["padding_bytes"] != 512:
        raise SystemExit("unexpected fixture specification")
    sources = []
    for item in spec["files"]:
        if item["path"] not in ("CMakeLists.txt", "payload.cmake", "tail.cmake"):
            raise SystemExit("unexpected fixture source")
        path = fixture / item["path"]
        if path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise SystemExit("fixture source hash mismatch: " + str(path))
        sources.append({"path": str(path), "sha256": item["sha256"]})
    size = trace.stat().st_size
    # These are the source-pinned product input/line ceilings, not an SLA.
    if not trace.is_file() or size <= 0 or size > 256 << 20:
        raise SystemExit("trace is not a positive regular file within MaxTraceBytes")
    before_hash = digest(trace)
    lines_by_file, include_chain = {}, []
    selected, tail = [], []
    payload_count = total = headers = 0
    max_line_bytes = 0
    with trace.open("rb") as stream:
        for line_number, raw in enumerate(stream, 1):
            max_line_bytes = max(max_line_bytes, len(raw))
            if len(raw) > 4 << 20:
                raise SystemExit("trace exceeds MaxLineBytes")
            row = json.loads(raw)
            if "version" in row:
                headers += 1
                if line_number != 1 or row["version"].get("major") != 1:
                    raise SystemExit("unexpected trace version/header position")
                continue
            if not isinstance(row.get("file"), str) or not row["file"] or not isinstance(row.get("cmd"), str) or not row["cmd"]:
                raise SystemExit("invalid command identity")
            if not isinstance(row.get("line"), int) or row["line"] <= 0 or not isinstance(row.get("args"), list) or not all(isinstance(value, str) for value in row["args"]):
                raise SystemExit("invalid command line/arguments")
            total += 1
            if total > 2000000:
                raise SystemExit("trace exceeds MaxParsedRecords")
            lines_by_file.setdefault(row["file"], set()).add(row["line"])
            command = row["cmd"].lower()
            if command in ("include", "add_subdirectory"):
                include_chain.append({"kind": command, "file": row["file"], "line": row["line"], "argument": row["args"][0] if row["args"] else ""})
            if same_path(row["file"], fixture / "payload.cmake") and command == "set":
                payload_count += 1
                want = ["R22_PAYLOAD", "r22:" + str(payload_count) + ":" + spec["padding"]]
                if row["args"] != want or row["line"] != 2:
                    raise SystemExit("CMake expansion/order mismatch at payload " + str(payload_count))
                if len(selected) < 1000:
                    selected.append(record(row))
            if same_path(row["file"], fixture / "tail.cmake") and command == "set":
                if row["args"] != ["R22_DONE", "r22-finished-" + str(spec["iterations"])] or payload_count != spec["iterations"]:
                    raise SystemExit("tail marker precedes or disagrees with complete payload")
                tail.append(record(row))
    if headers != 1 or payload_count != spec["iterations"] or len(selected) != 1000 or len(tail) != 1:
        raise SystemExit("incomplete or duplicate producer output")
    if digest(trace) != before_hash or trace.stat().st_size != size:
        raise SystemExit("trace changed during oracle preparation")
    file_names = sorted(lines_by_file)
    oracle = {
        "schema": 1,
        "trace_path": str(trace),
        "trace_sha256": before_hash,
        "trace_bytes": size,
        "input_records": total,
        "payload_records": payload_count,
        "max_line_bytes": max_line_bytes,
        "public_limit": 256 << 10,
        "fixture_sources": sources,
        "include_chain": include_chain,
        "executed_lines": [{"file": file, "lines": sorted(lines_by_file[file])} for file in file_names],
        "files_in_trace": file_names,
        "cases": [
            {"name": "selected-32", "file": selected[0]["file"], "command": "set", "max_records": 32, "truncated": True, "projected": False, "records": selected[:32]},
            {"name": "selected-1000", "file": selected[0]["file"], "command": "set", "max_records": 1000, "truncated": True, "projected": True, "records": selected},
            {"name": "last-marker", "file": tail[0]["file"], "command": "set", "max_records": 1, "truncated": False, "projected": False, "records": tail},
        ],
    }
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(oracle, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"trace_sha256": before_hash, "trace_bytes": size, "input_records": total, "payload_records": payload_count, "oracle_sha256": digest(output), "oracle": str(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
