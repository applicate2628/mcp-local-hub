"""One reviewed native raw-export roundtrip; no retry or product source edit."""
import sys
sys.dont_write_bytecode = True

from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(r"<R22_ROOT>")
PRIOR = Path(r"<R21_ROOT>")
SOURCE_HEAD = "ba17867125b3728fb734e90b383639a3ff9175ee"
SOURCE_TREE = "1c803a8ef8227fe6c289be69c7897aee1549372b"
RUNNER_SHA = "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61"
HARNESS_SHA = "f85188df1ba9406caabb3e963d19f6f6d28d2139f4fb43d4815cc51e5f75fae5"
RUN_ID = "<NATIVE_RUN_ID>"
NAME = "\\MCPHub-R22-Export-" + RUN_ID
NATIVE = ROOT / ("native-roundtrip-" + RUN_ID)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_lines(raw):
    result = [json.loads(line) for line in raw.decode("utf-8").splitlines()]
    if not result or any(not isinstance(row, dict) for row in result):
        raise RuntimeError("Expected nonempty JSON object observations")
    return result


def verify_native(runner):
    stdout_raw = (runner.out / "native-harness.stdout.log").read_bytes()
    stdout = json_lines(stdout_raw)
    expected = dict(final=True, run_id=RUN_ID, name=NAME, passed=True, directory=str(NATIVE),
                    source_commit=SOURCE_HEAD, acknowledged_registrations=2, acknowledged_delete_calls=2,
                    verified_deletions=2, current_creation_confirmed=False, cleanup_requested=True,
                    cleanup_complete=True, private_final_saved=True)
    if stdout[-1] != expected or any(type(stdout[-1].get(k)) is not type(v) for k, v in expected.items()) or any(row.get("final") for row in stdout[:-1]):
        raise RuntimeError("Final native result does not establish the full admitted sequence")
    if (runner.out / "native-harness.stderr.log").read_bytes():
        raise RuntimeError("Unexpected native stderr; preserve all evidence")
    durable_raw = (NATIVE / "observations.jsonl").read_bytes()
    rows = json_lines(durable_raw)
    if rows != stdout[:-1] or any(row.get("run_id") != RUN_ID for row in rows):
        raise RuntimeError("Native stdout differs from durable observations or run identity")
    counts = Counter(row.get("operation") for row in rows)
    expected_counts = dict(preflight=1, create_attempt=2, create_result=2, identity_observation=4,
                           delete_attempt=2, delete_result=2, absence_observation=2, qualification_checks_complete=1)
    if counts != expected_counts:
        raise RuntimeError("Native operation sequence contains missing or extra observations")
    selected = lambda operation: [row for row in rows if row["operation"] == operation]
    if any(row.get("name", NAME) != NAME for row in rows):
        raise RuntimeError("A native observation refers to another task")
    if not selected("preflight")[0].get("absent") or any(row.get("absent") is not True for row in selected("absence_observation")):
        raise RuntimeError("Native absence observations are incomplete")
    creates, deletes = selected("create_result"), selected("delete_result")
    if [row.get("phase") for row in creates] != ["seed", "restore"] or [row.get("acknowledged_registrations") for row in creates] != [1, 2] or any(row.get("acknowledged") is not True or row.get("outcome_not_established") is not False or row.get("error_kind") != "" for row in creates):
        raise RuntimeError("Native registrations did not both acknowledge success")
    if [row.get("phase") for row in deletes] != ["roundtrip", "cleanup"] or [row.get("acknowledged_delete_calls") for row in deletes] != [1, 2] or any(row.get("acknowledged") is not True or row.get("error_kind") != "" for row in deletes):
        raise RuntimeError("Native delete calls did not both acknowledge success")
    if [row.get("verified_deletions") for row in selected("absence_observation")] != [1, 2]:
        raise RuntimeError("The two removals lack their separate absence observations")
    identities = selected("identity_observation")
    labels = ["initial", "before-roundtrip-delete", "restored", "before-cleanup"]
    if [row.get("phase") for row in identities] != labels or any(row.get("fixture_definition_matches") is not True or row.get("disabled") is not True or row.get("owner_sid_matches") is not True for row in identities) or [row.get("full_bytes_compared") for row in identities] != [False, True, True, True]:
        raise RuntimeError("Definition, owner or disabled-state checks are incomplete")
    exports = [(NATIVE / ("export-" + label + ".bin")).read_bytes() for label in labels]
    if not exports[0] or any(raw != exports[0] for raw in exports):
        raise RuntimeError("Actual raw exports are not completely byte-identical")
    digest = sha(exports[0])
    if any(row.get("export_sha256") != digest or row.get("export_bytes") != len(exports[0]) for row in identities) or any(row.get("verified_export_sha256") != digest for row in selected("delete_attempt")):
        raise RuntimeError("Raw export observations differ from retained files")
    attempts = selected("create_attempt")
    seed = (NATIVE / "seed-input.bin").read_bytes()
    if [row.get("phase") for row in attempts] != ["seed", "restore"] or attempts[0].get("input_sha256") != sha(seed) or attempts[0].get("input_bytes") != len(seed) or attempts[1].get("input_sha256") != digest or attempts[1].get("input_bytes") != len(exports[0]):
        raise RuntimeError("Restoration did not receive the captured raw export identity")
    manifest_raw = (NATIVE / "manifest-private.json").read_bytes()
    manifest = json.loads(manifest_raw)
    for key, value in dict(run_id=RUN_ID, source_commit=SOURCE_HEAD, name=NAME, seed_sha256=sha(seed), seed_bytes=len(seed), disabled=True, hidden=True, triggers="none", allow_start_on_demand=False, logon_type="InteractiveToken", run_level="LeastPrivilege", planned_registrations=2, planned_deletions=2, logical_task_names=1, cleanup_requested=True).items():
        if manifest.get(key) != value or type(manifest.get(key)) is not type(value):
            raise RuntimeError("Private manifest differs from the admitted fixture policy")
    final_raw = (NATIVE / "final-private.json").read_bytes()
    final = json.loads(final_raw)
    if final.get("passed") is not True or final.get("error") != "" or final.get("run_id") != RUN_ID or final.get("source_commit") != SOURCE_HEAD or final.get("name") != NAME or final.get("cleanup_requested") is not True or final.get("state") != dict(step="complete", output_created=True, acknowledged_registrations=2, acknowledged_delete_calls=2, verified_deletions=2, current_creation_confirmed=False):
        raise RuntimeError("Private durable final does not confirm completion")
    runner.receipt.update(native_result=expected, native_operation_counts=dict(counts),
                          native_counter_basis="Reviewed harness call/result observations reconciled with durable files; not syscall tracing",
                          raw_export_sha256=digest, raw_export_bytes=len(exports[0]), raw_export_files_equal=True,
                          native_private_manifest_sha256=sha(manifest_raw), native_private_final_sha256=sha(final_raw),
                          native_observations_sha256=sha(durable_raw), stdout_matches_durable_observations=True)


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 1 or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Use the unmodified native wrapper from the R22 root without arguments")
    helper = PRIOR / "check_recovery.py"
    if sha(helper.read_bytes()) != RUNNER_SHA:
        raise RuntimeError("Frozen capture owner changed")
    spec = importlib.util.spec_from_file_location("r22_native_capture_owner", helper)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    runner = owner.Runner("r22-native-raw-roundtrip")
    runner.out = ROOT / "evidence/native-raw-roundtrip"
    runner.runtime = ROOT / "runtime/native-raw-roundtrip"
    failure = None
    try:
        runner.begin()
        source = runner.admit("published", SOURCE_HEAD)
        if source["tree"] != SOURCE_TREE:
            raise RuntimeError("Published native source tree changed")
        runner.receipt.update(source_before=source, native_wrapper_sha256=sha(Path(__file__).read_bytes()),
                              native_task_operations_authorized=True, qualified_product_commit=SOURCE_HEAD)
        original = ROOT / "native-main.go"
        raw = original.read_bytes()
        if sha(raw) != HARNESS_SHA:
            raise RuntimeError("Native harness differs from the independently reviewed source")
        formatted = ROOT / "native-formatted/main.go"
        formatted.parent.mkdir(exist_ok=False)
        with formatted.open("xb") as stream:
            stream.write(raw)
        runner.require_pass(runner.run("native-gofmt", owner.GOFMT, ["-w", str(formatted)], 60, ROOT))
        virtual = owner.SOURCE / "cmd/r22-native-roundtrip/main.go"
        overlay, executable = ROOT / "native-overlay.json", ROOT / "native-roundtrip.exe"
        if virtual.parent.exists() or executable.exists() or NATIVE.exists():
            raise RuntimeError("Native source/output destination already exists; no reuse")
        owner.save_new(overlay, {"Replace": {str(virtual): str(formatted)}})
        runner.require_pass(runner.run("native-build", owner.GO, ["build", "-overlay", str(overlay), "-o", str(executable), "./cmd/r22-native-roundtrip"], 900))
        if virtual.parent.exists():
            raise RuntimeError("Build materialized the virtual source directory")
        source = runner.admit("published", SOURCE_HEAD)
        pin = dict(source=source, harness_original_sha256=HARNESS_SHA, harness_formatted_sha256=sha(formatted.read_bytes()),
                   overlay_sha256=sha(overlay.read_bytes()), executable_sha256=sha(executable.read_bytes()),
                   wrapper_sha256=sha(Path(__file__).read_bytes()), native_environment_override={"MCPHUB_E2E_SCHEDULER": ""})
        owner.save_new(runner.out / "native-launch-inputs.json", pin)
        runner.receipt["native_launch_inputs"] = pin
        previous, row = runner.env["MCPHUB_E2E_SCHEDULER"], None
        try:
            runner.env["MCPHUB_E2E_SCHEDULER"] = ""
            row = runner.run("native-harness", executable, ["--cleanup-owned"], 600, ROOT)
        finally:
            runner.env["MCPHUB_E2E_SCHEDULER"] = previous
            launched = bool(row and row.get("pid")) or any(command.get("label") == "native-harness" and command.get("pid") for command in runner.receipt["commands"]) or (runner.out / "native-harness.launched.json").is_file()
            runner.receipt.update(native_harness_started=True if launched else None, native_task_operations=True if launched else None,
                                  native_task_operations_basis="Actual native harness launch observed; exact effects require reconciled receipts" if launched else "No supported launch receipt; outcome unresolved if a launch was attempted")
        runner.require_pass(row)
        verify_native(runner)
        if sha(original.read_bytes()) != HARNESS_SHA or sha(formatted.read_bytes()) != pin["harness_formatted_sha256"] or sha(overlay.read_bytes()) != pin["overlay_sha256"] or sha(executable.read_bytes()) != pin["executable_sha256"]:
            raise RuntimeError("Pinned native inputs changed during execution")
        after = runner.admit("published", SOURCE_HEAD)
        runner.receipt.update(source_after=after, source_head=after["head"], source_tree=after["tree"], completed=True, state="complete")
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
