"""Package retained, explicitly selected R22 evidence. No tests or subprocesses.

Old inputs are read-only; the sole output directory is a new public-r22.
Raw native XML, private native manifests, and executable bytes are never archived.
Pinned prior helpers supply JSON/redaction/ZIP and read-only semantic validation.
"""
import sys
sys.dont_write_bytecode = True

from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import math
import os
from pathlib import Path
import re
import stat
from types import SimpleNamespace

ROOT = Path(r"<R22_ROOT>")
PRIOR = Path(r"<R21_ROOT>")
DEST = ROOT / "public-r22"
NATIVE_BASENAME = "native-roundtrip"
PHASES = tuple("""cmake-adjacent cmake-build-vet cmake-candidate
cmake-consumer-baseline cmake-consumer-benchmark cmake-consumer-candidate cmake-consumer-prepare
cmake-control cmake-prepare diagnostics-build-vet diagnostics-candidate diagnostics-control diagnostics-prepare
lsp-benchmark-admit lsp-benchmark-baseline lsp-benchmark-candidate native-raw-roundtrip
pending-ram-adjacent pending-ram-build-vet pending-ram-candidate pending-ram-control pending-ram-prepare
relay-retry-candidate relay-retry-control relay-retry-prepare relay-retry-v2-adjacent relay-retry-v2-admit
relay-retry-v2-build-vet relay-retry-v2-candidate relay-retry-v2-control scheduler-rollback-adjacent-snapshot
scheduler-rollback-build-vet scheduler-rollback-candidate-backend scheduler-rollback-candidate-core
scheduler-rollback-control scheduler-rollback-prepare""".split())
SCOPES = ("diagnostics", "lsp-benchmark", "pending-ram", "cmake", "relay-retry", "relay-retry-v2", "scheduler-rollback")
FAILED = "relay-retry-candidate"
PINS = {
    "pack_public.py": "8daf6ac8f380e12aaff277ca1811365e80586e13bac55dbda0be14ebb7a25d97",
    "check_recovery.py": "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61",
    "qualify_scope.py": "25647d3fa88fd20a9e8629f729bed1da517556f182fc0dc97c43e973a4301dd9",
    "native_roundtrip_run.py": "a73cfed683205c244d0b3b839fb45806bb5d1e75033f73d45633da67bb14d616",
    "cmake_consumer_run.py": "b530d5db8cad9cfcb6a3c68b4f67ef0125610adb0dc95d6faed1a0932029e07b",
    "scopes/scheduler-rollback/validate_control.py": "34aaec07ed38347316b7b6d69eabb435544eab43c3bd00122e7209e2cf75c2ec",
}
GO = r"C:\msys64\ucrt64\bin\go.exe"
GOFMT = r"C:\msys64\ucrt64\bin\gofmt.exe"
GIT = r"C:\Program Files\Git\cmd\git.exe"
ERROR_KEYS = {"error_type", "event_error_type", "source_after_error", "source_final_error", "stdout_capture_error", "stderr_capture_error", "termination_error", "process_tree_unresolved"}
MAX_FILE, MAX_TOTAL = 32 * 1024 * 1024, 256 * 1024 * 1024
inputs, inventory_pins, public_sources, receipts, event_counts = {}, {}, {}, {}, {}
stream_paths, command_summaries = [], {}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def location(path):
    for name, root in (("r22", ROOT), ("r21", PRIOR)):
        if path.is_relative_to(root):
            relative = path.relative_to(root).as_posix()
            if name == "r22" and relative.split("/", 1)[0] == NATIVE_BASENAME:
                relative = "native-roundtrip" + relative[len(NATIVE_BASENAME):]
            return name + "/" + relative, root
    raise ValueError("Input outside the two reviewed task roots")


def checked(path, directory=False):
    key, root = location(path)
    need(all(part not in {".", "..", ".git"} for part in path.relative_to(root).parts), "Unsafe input path")
    for current in (path, *path.parents):
        info = current.lstat()
        need(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "Input is a link/reparse point: " + key)
        if current != path or directory:
            need(stat.S_ISDIR(info.st_mode), "Input parent is not a directory: " + key)
        if current == root:
            break
    return key, path.lstat()


def read(path, pin=None, publish=True):
    key, info = checked(path)
    need(stat.S_ISREG(info.st_mode) and info.st_size <= MAX_FILE, "Unbounded/non-file input: " + key)
    with path.open("rb") as stream:
        raw = stream.read(MAX_FILE + 1)
    need(len(raw) == info.st_size <= MAX_FILE, "Input size changed: " + key)
    need(pin is None or digest(raw) == pin, "Input hash differs: " + key)
    if key in inputs:
        need(inputs[key][1] == raw, "Retained input changed: " + key)
    else:
        need(len(inputs) < 8192 and sum(len(v[1]) for v in inputs.values()) + len(raw) <= MAX_TOTAL, "Evidence input bound exceeded")
        inputs[key] = (path, raw)
    if publish:
        public_sources["retained/" + key] = (key, raw)
    return raw


def inventory(path, expected):
    key, _ = checked(path, directory=True)
    actual = {p.name for p in path.iterdir()}
    need(actual == set(expected), "Inventory differs: " + key)
    inventory_pins[key] = (path, actual)


def module(path, pin, name):
    read(path, pin)
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    read(path, pin)
    return result


def json_at(path, pin=None):
    return helpers.parse(read(path, pin))


def source_snapshot(value, head, tree, hashes=None):
    need(value.get("head") == head and value.get("tree") == tree and value.get("exists") is True and value.get("materialized") is True and value.get("status") == "" and value.get("staged") == "", "Source snapshot is not the admitted clean source")
    if hashes is not None:
        need(value.get("sha256") == hashes, "Observed source bytes differ")


def verify_row(folder, row, observation, failure_allowed):
    label = row["label"]
    need(re.fullmatch(r"[a-z][a-z0-9-]{0,79}", label), "Invalid command label")
    need(row.get("settled") is True and row.get("timed_out") is False and not ERROR_KEYS.intersection(row), "Unsettled/error command capture: " + folder.name + "/" + label)
    need(row.get("whole_process_tree_deadline_enforced") is False and row.get("runner_sha256") == PINS["check_recovery.py"], "Command capture identity/limit differs")
    need(type(row.get("pid")) is int and row["pid"] > 0 and type(row.get("seconds")) in (int, float) and math.isfinite(row["seconds"]) and row["seconds"] >= 0, "Invalid process observation")
    need(helpers.timestamp(row["finished_utc"]) >= helpers.timestamp(row["started_utc"]), "Command timestamp order differs")
    saved = {suffix: read(folder / (label + suffix)) for suffix in (".started.json", ".launched.json", ".receipt.json", ".stdout.log", ".stderr.log")}
    clean_row = {k: v for k, v in row.items() if k != "scope_oracle_matched"}
    need(helpers.parse(saved[".receipt.json"]) == clean_row, "Phase and command receipts differ")
    started, launched = helpers.parse(saved[".started.json"]), helpers.parse(saved[".launched.json"])
    direct_prepare = not observation and folder.name in {s + "-prepare" for s in SCOPES} and label in {"init", "fetch-exact", "checkout-exact"}
    need(not direct_prepare or row.get("executable") == GIT, "Direct preparation capture changed owner")
    keys = {"label", "executable", "args", "cwd", "started_utc", "started_moscow", "settled", "timed_out", "direct_timeout_seconds", "whole_process_tree_deadline_enforced", "runner_sha256", "manifest_sha256"} | (set() if observation or direct_prepare else {"source_before"})
    need(set(started) == keys and started["settled"] is False and started["timed_out"] is False and all(started[k] == row[k] for k in keys - {"settled"}), "Started receipt differs")
    need(set(launched) == keys | {"pid", "launched_utc"} and all(launched[k] == v for k, v in started.items()) and launched["pid"] == row["pid"] and helpers.timestamp(row["started_utc"]) <= helpers.timestamp(launched["launched_utc"]) <= helpers.timestamp(row["finished_utc"]), "Launch receipt differs")
    for stream in ("stdout", "stderr"):
        raw = saved["." + stream + ".log"]
        need(row[stream].get("bytes") == len(raw) and row[stream].get("sha256") == digest(raw) and row[stream].get("hash_scope") == "bytes observed after direct-child exit", "Original stream hash/size/scope differs")
        if not failure_allowed:
            need(b"WARNING: DATA RACE" not in raw, "Unexpected race diagnostic")
        stream_paths.append("retained/" + location(folder / (label + "." + stream + ".log"))[0])
    counts, rendered = {}, ""
    if "tests" in row:
        lines = saved[".stdout.log"].splitlines()
        need(0 < len(lines) <= 100000 and all(len(line) <= 256 * 1024 for line in lines), "Go event stream bound differs")
        events = [helpers.parse(line) for line in lines]
        need(all(isinstance(e, dict) and isinstance(e.get("Package"), str) for e in events), "Invalid Go JSON event")
        terminal = {a: [e.get("Test", "PACKAGE:" + e["Package"]) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
        need(terminal == row["tests"], "Retained terminal events differ from receipt")
        counts = {kind + "_" + a: sum(n.startswith("PACKAGE:") == (kind == "package") for n in terminal[a]) for kind in ("test", "package") for a in terminal}
        rendered = "".join(e.get("Output", "") for e in events)
    elif row.get("args", [None])[0] == "test" and "-json" in row["args"]:
        raise ValueError("A Go JSON test command lacks event evidence")
    if observation:
        need(row.get("exit_code") == 0 and row.get("executable") == GIT, "Source observation failed or changed owner")
    event_counts[(folder.name, label)] = counts
    return saved[".stdout.log"], rendered


def verify_phase(phase, pin):
    folder = ROOT / "evidence" / phase
    receipt = json_at(folder / "receipt.json", pin)
    receipts[phase] = receipt
    initial = json_at(folder / "receipt-initial.json")
    need(receipt.get("phase") == ("r22-" + phase if phase == "native-raw-roundtrip" else phase), "Phase identity differs")
    need(initial.get("phase") == receipt["phase"] and initial.get("state") == "preflight" and initial.get("completed") is False and initial.get("commands") == [] and initial.get("observations") == [] and initial.get("runner_sha256") == PINS["check_recovery.py"], "Initial receipt differs")
    need(receipt.get("state") == ("failed" if phase == FAILED else "complete") and receipt.get("completed") is (phase != FAILED), "Original phase outcome differs")
    need(receipt.get("runner_sha256") == PINS["check_recovery.py"] and receipt.get("whole_process_tree_deadline_enforced") is False and receipt.get("process_tree_settlement_observed") is False, "Unsupported lifecycle/owner claim")
    need(not (ERROR_KEYS - ({"error_type"} if phase == FAILED else set())).intersection(receipt), "Phase capture error")
    expected = {"receipt-initial.json", "receipt.json"}
    if receipt.get("scope") or phase.startswith("cmake-consumer-") and phase != "cmake-consumer-prepare":
        expected.add("overlay.json")
        json_at(folder / "overlay.json")
    if phase == "native-raw-roundtrip":
        expected.add("native-launch-inputs.json")
        json_at(folder / "native-launch-inputs.json")
    if phase == "scheduler-rollback-control":
        expected.add("control-validation-result.json")
        json_at(folder / "control-validation-result.json")
    commands = []
    for observation, rows in ((False, receipt["commands"]), (True, receipt["observations"])):
        for row in rows:
            for suffix in (".started.json", ".launched.json", ".receipt.json", ".stdout.log", ".stderr.log"):
                name = row["label"] + suffix
                need(name not in expected, "Duplicate capture label")
                expected.add(name)
            stdout, rendered = verify_row(folder, row, observation, phase == FAILED and not observation)
            if not observation:
                commands.append({k: row[k] for k in ("label", "executable", "args", "cwd", "exit_code", "seconds", "started_utc", "finished_utc", "stdout", "stderr")})
                commands[-1].update(events=event_counts[(phase, row["label"])], terminal_events=row.get("tests"), benchmark_lines=[line for line in rendered.splitlines() if re.match(r"^Benchmark.+\s+[0-9]+\s+", line)])
    inventory(folder, expected)
    command_summaries[phase] = commands
    return receipt


def verify_scopes(config):
    plans = {}
    for scope in SCOPES:
        folder = ROOT / "scopes" / scope
        plan = json_at(folder / "manifest.json", config["scope_manifests"][scope])
        need(plan["scope"] == scope and plan["wrapper_sha256"] == PINS["qualify_scope.py"], "Scope owner differs")
        source = ROOT / plan["source_directory"]
        need(re.fullmatch(r"source-pr[0-9]+", plan["source_directory"]), "Source destination differs")
        originals = {}
        for item in plan["files"]:
            helpers.relative(item["path"])
            path = source / item["path"]
            if item["original_git_blob"] is None:
                need(not path.exists() and not path.is_symlink(), "Unexpected original source")
                originals[item["path"]] = None
            else:
                raw = read(path)
                need(blob(raw) == item["original_git_blob"], "Original Git blob differs")
                originals[item["path"]] = digest(raw)
            candidate = read(folder / "candidate" / item["path"], item["candidate_sha256"])
            need(blob(candidate) == item["candidate_git_blob"] and ("bytes" not in item or len(candidate) == item["bytes"]), "Candidate Git blob/size differs")
        for phase, receipt in receipts.items():
            if receipt.get("scope") != scope:
                continue
            suffix = phase.removeprefix(scope + "-")
            phase_plan = plan["phases"][suffix]
            overlay = ROOT / "evidence" / phase / "overlay.json"
            need(receipt["scope_manifest_sha256"] == config["scope_manifests"][scope] and receipt["scope_wrapper_sha256"] == PINS["qualify_scope.py"], "Receipt/manifest identity differs")
            need(digest(read(overlay)) == receipt["overlay_sha256"] and json_at(overlay) == {"Replace": {str(source / name): str(folder / "candidate" / name) for name in phase_plan["overlay_paths"]}}, "Scope overlay mapping differs")
            for key in ("source_before", "source_after", "source_final"):
                if key in receipt:
                    source_snapshot(receipt[key], plan["source_head"], plan["source_tree"], originals)
            extra = ["init", "fetch-exact", "checkout-exact", "gofmt-check"] if suffix == "prepare" else ["gofmt-check"] if suffix == "admit" else []
            need([row["label"] for row in receipt["commands"]] == extra + [row["label"] for row in phase_plan["commands"]], "Scope command selection differs")
            for row in receipt["commands"][:len(extra)]:
                need(row["exit_code"] == 0, "Scope admission command failed")
                if row["label"] == "gofmt-check":
                    need(row["executable"] == GOFMT and row["args"] == ["-l", *[str(folder / "candidate" / f["path"]) for f in plan["files"]]] and not read(ROOT / "evidence" / phase / "gofmt-check.stdout.log"), "Formatting admission differs")
            for row, oracle in zip(receipt["commands"][len(extra):], phase_plan["commands"]):
                need(row["executable"] == GO and row["cwd"] == str(source) and row["args"] == [str(overlay) if a == "{overlay}" else a for a in oracle["args"]] and row["direct_timeout_seconds"] == oracle["timeout_seconds"], "Frozen Go invocation differs")
                stdout = read(ROOT / "evidence" / phase / (row["label"] + ".stdout.log"))
                if phase == FAILED:
                    need(row["exit_code"] == 1 and row["tests"]["fail"] and b"WARNING: DATA RACE" in stdout and "scope_oracle_matched" not in row, "Retained failed Relay v1 attempt differs")
                    continue
                need(row.get("scope_oracle_matched") is True and row["exit_code"] == oracle["expected_exit_code"], "Frozen exit oracle differs")
                if "expected_tests" in oracle:
                    need(all(Counter(row["tests"][a]) == Counter(oracle["expected_tests"][a]) for a in ("pass", "fail", "skip")), "Frozen terminal-event oracle differs")
                need(all(text.encode("utf-8") in stdout for text in oracle.get("required_output", [])), "Expected negative diagnostic absent")
                counts = Counter(row.get("tests", {}).get("pass", []))
                need(all(counts[name] == count for name, count in oracle.get("required_root_pass_counts", {}).items()), "Required root pass count differs")
                if oracle["expected_exit_code"] == 0:
                    need(not row.get("tests", {}).get("fail") and not row.get("tests", {}).get("skip"), "Unexpected failing/skipped test")
                if oracle.get("required_benchmarks"):
                    rendered = "".join(helpers.parse(line).get("Output", "") for line in stdout.splitlines())
                    for name in oracle["required_benchmarks"]:
                        need(re.search(r"(?m)^" + re.escape(name) + r"(?:-\d+)?\s+1\s+[0-9]+(?:\.[0-9]+)?\s+ns/op\b", rendered), "Required numeric one-iteration benchmark absent")
        plans[scope] = plan
    for row in config["github_publication"]["files"]:
        item = next(f for f in plans[row["scope"]]["files"] if f["path"] == row["path"])
        need(row["candidate_git_blob"] == row["github_git_blob"] == item["candidate_git_blob"], "Publication blob match differs")
    need(len(config["github_publication"]["files"]) == 18, "Publication file coverage differs")
    return plans


def verify_consumer():
    package, work = ROOT / "cmake-consumer-input", ROOT / "cmake-consumer-work"
    manifest = json_at(package / "manifest.json", "43360214559c202d5e257d2521a5b24cb79dcd092fc2a8004dc6b9fd825a1580")
    names = ["execution-plan.json", "prepare_oracle.py", "overlay/internal/vcpkgmcp/cmaketrace/cmake_generated_consumer_test.go", *["fixture/" + n for n in ("CMakeLists.txt", "payload.cmake", "tail.cmake", "fixture-manifest.json")]]
    listed = {f["path"]: f for f in manifest["local_files"]}
    for name in names:
        raw = read(package / name, listed[name]["sha256"])
        need(len(raw) == listed[name]["bytes"], "Consumer input size differs")
    plan = json_at(package / "execution-plan.json")
    prepare = receipts["cmake-consumer-prepare"]
    prepared_names = {"fixture/" + n for n in ("CMakeLists.txt", "payload.cmake", "tail.cmake", "fixture-manifest.json")} | {"formatted/cmake_generated_consumer_test.go", "producer/trace.jsonl", "producer/oracle.json"}
    need(set(prepare["prepared_inputs"]) == prepared_names, "Prepared consumer selection differs")
    for name, pin in prepare["prepared_inputs"].items():
        helpers.relative(name)
        read(work / name, pin)
    source, hashes = ROOT / "source-pr624", {}
    for item in manifest["source_pins"]:
        raw = read(source / str(helpers.relative(item["path"])))
        need(blob(raw) == item["git_blob"], "Consumer source blob differs")
        hashes[item["path"]] = digest(raw)
    virtual = "internal/vcpkgmcp/cmaketrace/cmake_generated_consumer_test.go"
    hashes[virtual] = None
    need(not (source / virtual).exists(), "Unexpected materialized consumer overlay")
    cases = ("selected-32", "selected-1000", "last-marker")
    result = {}
    for suffix in ("prepare", "baseline", "candidate", "benchmark"):
        phase = "cmake-consumer-" + suffix
        r = receipts[phase]
        need(r["consumer_script_sha256"] == PINS["cmake_consumer_run.py"] and r["consumer_manifest_sha256"] == digest(read(package / "manifest.json")), "Consumer owner differs")
        for key in ("source_before", "source_after", "source_final"):
            source_snapshot(r[key], manifest["source_pins"][0].get("commit", r["source_head"]), r["source_tree"], hashes)
        need(r["source_head"] == "251fb4f03405ba438662976137afec0d9c27105e" and r["source_tree"] == "2bc9f398025a32aa05b01bbcc6664d28ab9432cb", "Consumer source identity differs")
        if suffix == "prepare":
            need([c["label"] for c in r["commands"]] == ["format-consumer", "ninja-version", "cmake-configure", "prepare-oracle"] and all(c["exit_code"] == 0 for c in r["commands"]), "Consumer preparation command outcome differs")
            substitutions = {"fixture": str(work / "fixture"), "build": str(work / "build"), "trace": str(work / "producer/trace.jsonl")}
            producer_args = []
            for argument in plan["producer"]["argv"]:
                for key, value in substitutions.items():
                    argument = argument.replace("{{" + key + "}}", value)
                need("{{" not in argument, "Unresolved producer argument")
                producer_args.append(argument)
            expected_args = [["-w", str(work / "formatted/cmake_generated_consumer_test.go")], ["--version"], producer_args, ["-B", str(package / "prepare_oracle.py"), "--fixture", substitutions["fixture"], "--trace", substitutions["trace"], "--output", str(work / "producer/oracle.json")]]
            need([c["args"] for c in r["commands"]] == expected_args and [c["cwd"] for c in r["commands"]] == [str(source), str(work), str(work), str(work)], "Consumer preparation invocation differs")
            need([c["executable"] for c in r["commands"][:3]] == [GOFMT, plan["producer"]["generator_executable"], plan["producer"]["executable"]], "Consumer producer executable differs")
            continue
        need(r["prepare_receipt_sha256"] == digest(read(ROOT / "evidence/cmake-consumer-prepare/receipt.json")), "Consumer preparation receipt differs")
        overlay = ROOT / "evidence" / phase / "overlay.json"
        mapping = {str(source / virtual): str(work / "formatted/cmake_generated_consumer_test.go")}
        if suffix != "baseline":
            product = ROOT / "scopes/cmake/candidate/internal/vcpkgmcp/cmaketrace/cmaketrace.go"
            read(product, manifest["cmake_candidate_production_sha256"])
            mapping[str(source / "internal/vcpkgmcp/cmaketrace/cmaketrace.go")] = str(product)
            need(r["product_overlay_sha256_after"] == manifest["cmake_candidate_production_sha256"], "Consumer product overlay differs")
        need(json_at(overlay) == {"Replace": mapping}, "Consumer overlay differs")
        args = plan["go"]["benchmark_argv" if suffix == "benchmark" else "contract_argv"]
        need(len(r["commands"]) == 1, "Consumer command count differs")
        row = r["commands"][0]
        expected = ["PACKAGE:mcp-local-hub/internal/vcpkgmcp/cmaketrace"] + ([] if suffix == "benchmark" else ["TestCMakeGeneratedConsumerWorkload", *["TestCMakeGeneratedConsumerWorkload/" + c for c in cases]])
        need(row["label"] == "consumer" and row["executable"] == GO and row["args"] == [args[0], "-overlay", str(overlay), *args[1:]] and row["exit_code"] == 0 and Counter(row["tests"]["pass"]) == Counter(expected) and not row["tests"]["fail"] and not row["tests"]["skip"], "Consumer command/event oracle differs")
        if suffix == "benchmark":
            lines = command_summaries[phase][0]["benchmark_lines"]
            for case, count in zip(cases, (32, 0, 1)):
                selected = [line for line in lines if re.match(r"^BenchmarkCMakeGeneratedConsumer/" + re.escape(case) + r"(?:-\d+)?\s+1\s+", line)]
                need(len(selected) == 1 and (metric := re.search(r"([0-9.]+)\s+wire-records/op", selected[0])) and float(metric.group(1)) == count, "Consumer benchmark selection/metric differs")
            continue
        artifacts = {c + ext for c in cases for ext in (".public.json", ".observation.json")}
        need(set(r["consumer_artifacts"]) == artifacts, "Consumer artifact selection differs")
        inventory(work / suffix, artifacts)
        result[suffix] = {}
        for name, pin in r["consumer_artifacts"].items():
            read(work / suffix / name, pin)
        for case in cases:
            observed = json_at(work / suffix / (case + ".observation.json"))
            wire = read(work / suffix / (case + ".public.json"))
            need(observed["wire_sha256"] == digest(wire) and observed["wire_bytes"] == len(wire) and observed["trace_sha256"] == prepare["prepared_inputs"]["producer/trace.jsonl"], "Consumer observation bytes differ")
            result[suffix][case] = observed
    for case in cases:
        need(read(work / "baseline" / (case + ".public.json")) == read(work / "candidate" / (case + ".public.json")), "Consumer public bytes changed")
        need(all(result["candidate"][case][field] == 0 for field in ("discarded_argument_references", "discarded_nonzero_records", "discarded_string_bytes_sum")), "Candidate retained discarded references")
    return {"observations": result, "all_three_public_byte_pairs_equal": True, "interpretation": "One sequential observation per case plus one-iteration benchmarks; no concurrency, latency, throughput, RSS, peak-memory or percentile acceptance. String-reference sums are not unique retained heap."}


def verify_native_and_control():
    native = module(ROOT / "native_roundtrip_run.py", PINS["native_roundtrip_run.py"], "r22_read_only_native")
    for name in ("export-initial.bin", "export-before-roundtrip-delete.bin", "export-restored.bin", "export-before-cleanup.bin", "seed-input.bin", "manifest-private.json", "final-private.json"):
        read(native.NATIVE / name, publish=False)
    read(native.NATIVE / "observations.jsonl")
    inventory(native.NATIVE, {"export-initial.bin", "export-before-roundtrip-delete.bin", "export-restored.bin", "export-before-cleanup.bin", "seed-input.bin", "manifest-private.json", "final-private.json", "observations.jsonl"})
    dummy = SimpleNamespace(out=ROOT / "evidence/native-raw-roundtrip", receipt={})
    native.verify_native(dummy)
    r = receipts["native-raw-roundtrip"]
    need(all(r.get(k) == v for k, v in dummy.receipt.items()), "Native semantic verification differs from phase receipt")
    launch = json_at(ROOT / "evidence/native-raw-roundtrip/native-launch-inputs.json")
    need(launch == r["native_launch_inputs"] and launch["wrapper_sha256"] == PINS["native_roundtrip_run.py"] and launch["native_environment_override"] == {"MCPHUB_E2E_SCHEDULER": ""}, "Native launch identity differs")
    need([c["label"] for c in r["commands"]] == ["native-gofmt", "native-build", "native-harness"] and all(c["exit_code"] == 0 for c in r["commands"]), "Native command outcomes differ")
    need([c["args"] for c in r["commands"]] == [["-w", str(ROOT / "native-formatted/main.go")], ["build", "-overlay", str(ROOT / "native-overlay.json"), "-o", str(ROOT / "native-roundtrip.exe"), "./cmd/r22-native-roundtrip"], ["--cleanup-owned"]], "Native invocation differs")
    for name, pin in (("native-main.go", launch["harness_original_sha256"]), ("native-formatted/main.go", launch["harness_formatted_sha256"]), ("native-overlay.json", launch["overlay_sha256"])):
        read(ROOT / name, pin)
    read(ROOT / "native-roundtrip.exe", launch["executable_sha256"], publish=False)
    for snapshot in (launch["source"], r["source_before"], r["source_after"], r["source_final"]):
        source_snapshot(snapshot, native.SOURCE_HEAD, native.SOURCE_TREE)
    for name, pin in launch["source"]["sha256"].items():
        if pin is not None:
            read(PRIOR / "source" / str(helpers.relative(name)), pin)
    for name in ("observations.jsonl",):
        helpers.native_json_without_xml([helpers.parse(line) for line in read(native.NATIVE / name).splitlines()])
    helpers.native_json_without_xml(r)
    validator = module(ROOT / "scopes/scheduler-rollback/validate_control.py", PINS["scopes/scheduler-rollback/validate_control.py"], "r22_read_only_control")
    saved = json_at(ROOT / "evidence/scheduler-rollback-control/control-validation-result.json")
    fresh = {"inputs": {}, "tests_rerun": False}
    validator.validate(fresh, saved["expected_receipt_sha256"])
    need(all(saved.get(k) == v for k, v in fresh.items()), "Scheduler negative-control revalidation differs")
    for path, item in fresh["inputs"].items():
        raw = read(Path(path), item["sha256"])
        need(len(raw) == item["bytes"], "Scheduler oracle input size differs")
    return dummy.receipt, helpers.parse(read(native.NATIVE / "manifest-private.json", publish=False)), {"status": "confirmed", "tests_rerun": False, "terminal_counts": fresh["terminal_counts"], "assertions": fresh["assertions"]}


def main():
    global helpers
    need(os.name == "nt" and not sys.flags.optimize and len(sys.argv) == 1 and Path(__file__).resolve().parent == ROOT, "Run unoptimized in the reviewed R22 root without arguments")
    need(not DEST.exists() and not DEST.is_symlink(), "public-r22 already exists; no overwrite")
    helpers = module(PRIOR / "pack_public.py", PINS["pack_public.py"], "r22_pack_helpers")
    read(Path(__file__))
    read(ROOT / "pack_r22.py", "e56f6236f152e8599786380800b4d1cb253720d733551cae091ed6ca2701eff4")
    read(ROOT / "pack-attempt-1.json", "9a20d078bbbe66290947d5bbae3cc3459b4421fe336584c3f5d49b9510b94d2a")
    config = json_at(ROOT / "r22-package-input.json")
    need(config["schema"] == 1 and set(config["phase_receipts"]) == set(PHASES) and set(config["scope_manifests"]) == set(SCOPES), "Frozen R22 allowlist differs")
    for name, pin in PINS.items():
        read((PRIOR if name in {"pack_public.py", "check_recovery.py"} else ROOT) / name, pin)
    for name in ("source-manifest.json", "source-plan.json", "control.patch", "product.patch", "candidate.patch"):
        read(PRIOR / name)
    for phase in PHASES:
        verify_phase(phase, config["phase_receipts"][phase])
    plans = verify_scopes(config)
    consumer = verify_consumer()
    native, private, control = verify_native_and_control()
    # Longest exact substitutions first; no generic path/name guess replaces data.
    mappings = [(str(ROOT / NATIVE_BASENAME), "<NATIVE_PRIVATE_ROOT>"), (NATIVE_BASENAME, "native-roundtrip"), (str(ROOT), "<R22_ROOT>"), (str(PRIOR), "<R21_ROOT>"), (r"<WORK_ROOT>", "<WORK_ROOT>"), (str(Path.home()), "<USER_PROFILE>")]
    mappings.append(("<REMOTE_DEVICE>", "<REMOTE_DEVICE>"))
    for key, token in (("account", "<NATIVE_ACCOUNT>"), ("sid", "<NATIVE_OWNER_SID>"), ("name", "<NATIVE_TASK_NAME>"), ("run_id", "<NATIVE_RUN_ID>")):
        need(isinstance(private.get(key), str) and private[key], "Private identity mapping missing")
        mappings.append((private[key], token))
    for key in ("USERNAME", "USERDOMAIN", "COMPUTERNAME"):
        value = os.environ.get(key, "")
        if len(value) >= 3 and value.casefold() not in {"system", "nt authority", "workgroup"}:
            mappings.append((value, "<" + key + ">"))
    members, manifest_rows = {}, []
    for name, (origin, raw) in sorted(public_sources.items()):
        helpers.relative(name)
        public = helpers.redact(raw, mappings)
        if name.endswith(".json"):
            helpers.parse(public)
        members[name] = public
        manifest_rows.append({"path": name, "origin": origin, "original_bytes": len(raw), "original_sha256": digest(raw), "public_bytes": len(public), "public_sha256": digest(public), "redacted": public != raw})
    rows_by_path = {row["path"]: row for row in manifest_rows}
    stream_records = [rows_by_path[name] for name in stream_paths]
    for phase, commands in command_summaries.items():
        for command in commands:
            for stream in ("stdout", "stderr"):
                path = "retained/r22/evidence/" + phase + "/" + command["label"] + "." + stream + ".log"
                command[stream]["public"] = {"path": path, "sha256": rows_by_path[path]["public_sha256"], "bytes": rows_by_path[path]["public_bytes"]}
    summary = {
        "schema": 1, "verification_utc": datetime.now(timezone.utc).isoformat(), "scope": "Completed R22 evidence only", "tests_rerun_by_packager": False,
        "packaging_history": {"attempt_1": "Rejected before output: packager incorrectly expected source_before for direct Runner.execute preparation captures; original source evidence unchanged. v1 script and full traceback are retained in this archive."},
        "phase_count": len(PHASES), "commands": sum(len(r["commands"]) for r in receipts.values()), "observations": sum(len(r["observations"]) for r in receipts.values()),
        "stream_verification": {"original_hashes_checked": len(stream_records), "unchanged_public_streams": sum(not row["redacted"] for row in stream_records), "redacted_public_streams": sum(row["redacted"] for row in stream_records), "all_public_hashes_checked": True},
        "source_scopes": {scope: {k: plan[k] for k in ("source_directory", "source_head", "source_tree", "files")} for scope, plan in plans.items()},
        "github_publication": config["github_publication"],
        "phases": {phase: {"receipt_sha256": config["phase_receipts"][phase], "state": r["state"], "completed": r["completed"], "base": r["base"], "base_tree": r["base_tree"], "started_utc": r["started_utc"], "finished_utc": r["finished_utc"], "commands": command_summaries[phase], "observations": len(r["observations"]), "original_error": {k: r[k] for k in ("error", "error_type") if k in r}} for phase, r in receipts.items()},
        "consumer": consumer, "native": native, "scheduler_control": control,
        "private_inputs_verified_not_published": [{"origin": key, "bytes": len(raw), "sha256": digest(raw)} for key, (_, raw) in inputs.items() if "retained/" + key not in public_sources],
        "limits": ["No Linux phase included; no tests rerun during packaging.", "Scopes ran on their pinned clean base plus explicit Go overlays. Matching candidate blobs were published, but current commit heads were not wholly requalified by these old runs.", "Native raw roundtrip qualified ba17867125b3728fb734e90b383639a3ff9175ee, not the later a6319962 commit. Native XML remains private; public readers cannot independently reconstruct its private byte hashes.", "The original Relay v1 candidate failed with a race diagnostic; v2 has separate evidence. Negative controls retain their nonzero exits.", "Only direct-child waits were bounded; no whole-process-tree deadline or settlement evidence.", "CMake input plan originally requested process-tree ownership; retained execution explicitly records that this broader criterion was not met.", "No overall program readiness, performance budget acceptance, installed-product qualification, or formal external APPROVED review is asserted."]
    }
    table = ["| Phase | Exit code(s) | Test pass/fail/skip | Package pass/fail/skip | Retained outcome |", "|---|---|---|---|---|"]
    for phase, r in receipts.items():
        counts = Counter()
        for row in r["commands"]:
            counts.update(event_counts[(phase, row["label"])])
        table.append("| " + phase + " | " + ", ".join(str(row["exit_code"]) for row in r["commands"]) + " | " + "/".join(str(counts["test_" + a]) for a in ("pass", "fail", "skip")) + " | " + "/".join(str(counts["package_" + a]) for a in ("pass", "fail", "skip")) + " | " + r["state"] + " |")
    readme = """# R22 retained evidence, 21 November 2026

## Contents

- [1. Result and scope](#1-result-and-scope)
- [2. Reading the evidence](#2-reading-the-evidence)
- [3. Qualification limits](#3-qualification-limits)

## 1. Result and scope

This package preserves the fixed completed R22 selection: diagnostics, LSP (Language Server Protocol) benchmark fixture, pending RAM (random-access memory), CMake producer and consumer, Relay retry v1 and v2, scheduler rollback, and one native raw-export roundtrip. Linux phases are excluded. Packaging ran no tests, builds, scheduler operations, or network commands.

All retained command/observation stdout and stderr bytes were checked against their original SHA-256 (Secure Hash Algorithm, 256-bit) and byte-count receipts; Go terminal events were reconstructed from those bytes. Source candidates, frozen overlays and source snapshots were checked independently of a wrapper's final exit. There are 36 retained phases: 35 recorded complete and one historical Relay v1 candidate recorded failed. Successful negative controls intentionally retain nonzero command exits. See Table 1 in [RESULTS.md](RESULTS.md).

Eighteen final candidate files match GitHub blob identifiers at the published commits in execution-summary.json. The evidence consists of executions on pinned original sources with explicit Go overlays, which temporarily substitute candidate files without editing the source checkout. It does not claim that the complete published branch heads were rerun. Relay v1 is retained as failed history and is not a second published candidate.

## 2. Reading the evidence

- [RESULTS.md](RESULTS.md): bounded results, negative evidence and Table 1.
- [execution-summary.json](execution-summary.json): exact retained commands, exits, test and package events, source pins, observations and separate original/public stream hashes. Private literal values in commands are replaced by angle-bracket placeholders.
- [MANIFEST.json](MANIFEST.json): original and public SHA-256 plus byte counts for each retained member; hashes of generated files. Original hash fields in retained receipts remain original claims and are not rewritten to public hashes.
- [archive-metadata.json](archive-metadata.json): ZIP archive size/hash and manifest identity. The ZIP (compressed archive) contains the same README, RESULTS, summary and manifest plus selected retained evidence, source candidates, base source files, scripts and CMake artifacts.

Paths, account/host names, native task identity and the private Windows SID (security identifier) are replaced using exact known literals. All public member hashes were checked after redaction. Unchanged public streams reproduce their original hashes; changed public streams reproduce only their separately recorded public hashes. Raw native XML (Extensible Markup Language), private native manifest/final records and the harness executable are verified locally and excluded from the archive. Their original hashes are retained in the summary. Redacted scripts/source files are audit records and are not advertised as runnable fixtures.

## 3. Qualification limits

Native evidence records two acknowledged registrations, two acknowledged deletion calls, two absence checks and equality of all four actual raw exports. It concerns a disabled, hidden fixture with no triggers and no start-on-demand; it does not qualify Run, RunOwned, Stop, cancellation, owner changes or production Delete scenarios. Its source is ba17867125b3728fb734e90b383639a3ff9175ee, preceding the later scheduler rollback commit. Private raw-export bytes cannot be independently reconstructed from this public package.

Only direct-child waits were bounded. Whole-process-tree deadlines and settlement were not established. The original CMake preparation plan requests stronger process-tree handling than the retained execution achieved; both the plan and the execution limitation are preserved. One-iteration benchmark outputs establish that the selected workloads executed; they establish no latency, throughput, memory, percentile or concurrency budget acceptance.

This package establishes the stated R22 evidence, not overall program readiness. Earlier broad failures and NOT_RUN gates remain unless separately resolved. No external APPROVED review is claimed.
"""
    results = """# R22 results and retained failures

## Contents

- [1. Command and event evidence](#1-command-and-event-evidence)
- [2. Consumer and native observations](#2-consumer-and-native-observations)
- [3. Review boundaries](#3-review-boundaries)

## 1. Command and event evidence

Table 1. Counts below are terminal event occurrences, including repeated tests; test events and package events are separated. Zero test events for build, vet or formatting commands does not mean tests were run. `complete` is the retained phase state and can mean an expected failing control was correctly observed. Exact test names and command arguments are in execution-summary.json and original retained receipts.

""" + "\n".join(table) + """

Relay v1 candidate exit 1, race diagnostic and mixed repeated test outcomes are retained. Relay v2 has separate control, candidate, adjacent and build/vet evidence. The scheduler negative control was rechecked with the pinned read-only validator: 6 passing test events, 36 failing test events and one failing package event, including exact assertion prefixes. No tests were rerun for this revalidation.

## 2. Consumer and native observations

For the three CMake cases selected-32, selected-1000 and last-marker, baseline discarded argument-reference counts were 33,275, 31,339 and 33,265; candidate counts were all zero. Candidate discarded nonzero-record and string-byte-reference sums were also zero. All three baseline/candidate public JSON byte pairs were equal. These are retained references inspected by the test, not unique heap, resident-set size (RSS), peak-memory or concurrency measurements. Timings are single observations without acceptance thresholds.

The native roundtrip was revalidated from its durable observations, stdout, private manifest/final records, seed bytes and four raw-export files. Recorded calls and results reconcile to two registrations and two deletions with separate absence checks. Raw XML is not published. The count basis is harness call/result observation, not system-call tracing. Exact source identity and digest-only private evidence references are in execution-summary.json.

## 3. Review boundaries

The packager checks immutable input identities, flat evidence inventories, per-command start/launch/final receipts, original stream bytes, Go events, frozen negative/positive oracles, candidate Git blobs, overlay maps, source snapshots, CMake byte pairs, scheduler assertion diagnostics and native durable records. All selected inputs are read again before output creation; outputs use exclusive creation in a previously absent directory. No product repository, prior evidence or existing file is rewritten.

Publication correspondence uses GitHub file blob identifiers at exact supplied commits. It does not establish that those complete commits were executed. The private-to-public boundary is explicit in MANIFEST.json. Process-tree settlement, broad program gates, installed product behavior and formal external approval remain outside these results.
"""
    for name, raw in (("README.md", readme.encode()), ("RESULTS.md", results.encode()), ("execution-summary.json", helpers.encode(summary))):
        public = helpers.redact(raw, mappings)
        members[name] = public
        manifest_rows.append({"path": name, "generated": True, "public_bytes": len(public), "public_sha256": digest(public)})
    manifest = {"schema": 1, "coverage": "All ZIP members except MANIFEST.json itself; archive-metadata.json separately hashes this manifest and the full archive", "members": manifest_rows}
    manifest_raw = helpers.encode(manifest)
    members["MANIFEST.json"] = manifest_raw
    archive = helpers.make_archive(members)
    metadata = helpers.encode({"schema": 1, "archive": "evidence-redacted.zip", "archive_bytes": len(archive), "archive_sha256": digest(archive), "archive_members": len(members), "manifest_bytes": len(manifest_raw), "manifest_sha256": digest(manifest_raw), "manifest_member_hashes": len(manifest_rows), "stream_verification": summary["stream_verification"]})
    # No output is created until all validation/redaction/archive checks succeed.
    for key, (path, raw) in list(inputs.items()):
        need(read(path, publish=False) == raw, "Input changed before publication: " + key)
    for key, (path, expected) in inventory_pins.items():
        need({p.name for p in path.iterdir()} == expected, "Evidence inventory changed: " + key)
    DEST.mkdir(exist_ok=False)
    output = {name: members[name] for name in ("README.md", "RESULTS.md", "execution-summary.json", "MANIFEST.json")}
    output.update({"archive-metadata.json": metadata, "evidence-redacted.zip": archive})
    for name, raw in output.items():
        with (DEST / name).open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        need((DEST / name).read_bytes() == raw, "Saved output readback differs")
    print(helpers.encode({"status": "verified", "output": "public-r22", "metadata": helpers.parse(metadata), "phases": len(PHASES), "commands": summary["commands"], "observations": summary["observations"], "tests_rerun": False}).decode())


if __name__ == "__main__":
    main()
