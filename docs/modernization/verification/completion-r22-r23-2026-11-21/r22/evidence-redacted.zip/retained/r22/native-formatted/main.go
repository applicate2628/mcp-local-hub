//go:build windows

// Copy into cmd/r22-native-roundtrip in a temporary source overlay pinned to
// sourceCommit. This fixture never runs. Its two removals assume no external
// writer to the single random name; the checks and Delete are not atomic.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/user"
	"path/filepath"
	"strings"
	"time"

	"mcp-local-hub/internal/scheduler"
)

const (
	runID        = "<NATIVE_RUN_ID>"
	sourceCommit = "ba17867125b3728fb734e90b383639a3ff9175ee"
	outputDir    = `<NATIVE_PRIVATE_ROOT>`
	taskName     = `<NATIVE_TASK_NAME>`
	command      = outputDir + `\NEVER-EXECUTE-f7d1e84d3a694f34a7f05bcb3a8ee3ec.exe`
	arguments    = `--fixture "§ Привет 漢字 🙂" --quoted "\"literal\"" --path "<WORK_ROOT>\path with spaces\value"`
)

type runState struct {
	Step                      string `json:"step"`
	OutputCreated             bool   `json:"output_created"`
	AcknowledgedRegistrations int    `json:"acknowledged_registrations"`
	AcknowledgedDeleteCalls   int    `json:"acknowledged_delete_calls"`
	VerifiedDeletions         int    `json:"verified_deletions"`
	CurrentCreationConfirmed  bool   `json:"current_creation_confirmed"`
}

func main() {
	cleanup := flag.Bool("cleanup-owned", false, "Complete both verified removals, assuming no external writer to the random fixture name")
	flag.Parse()
	state := &runState{Step: "preflight"}
	err := run(*cleanup, state)
	privateFinalSaved := false
	if state.OutputCreated {
		private := map[string]any{
			"run_id": runID, "name": taskName, "source_commit": sourceCommit,
			"utc": time.Now().UTC().Format(time.RFC3339Nano), "passed": err == nil,
			"state": state, "cleanup_requested": *cleanup, "error": privateError(err),
		}
		raw, marshalErr := json.MarshalIndent(private, "", "  ")
		if marshalErr == nil {
			marshalErr = writeNewSynced(filepath.Join(outputDir, "final-private.json"), append(raw, '\n'))
		}
		if marshalErr != nil {
			if err == nil {
				state.Step = "final_private_write"
			}
			err = errors.Join(err, fmt.Errorf("persist private final result: %w", marshalErr))
		} else {
			privateFinalSaved = true
		}
	}
	// Stdout deliberately contains neither raw XML, account names, SIDs nor raw
	// native errors. The private manifest and final file retain recovery details.
	result := map[string]any{
		"final": true, "run_id": runID, "name": taskName, "passed": err == nil,
		"directory": outputDir, "source_commit": sourceCommit,
		"acknowledged_registrations": state.AcknowledgedRegistrations,
		"acknowledged_delete_calls":  state.AcknowledgedDeleteCalls,
		"verified_deletions":         state.VerifiedDeletions,
		"current_creation_confirmed": state.CurrentCreationConfirmed,
		"cleanup_requested":          *cleanup,
		"cleanup_complete":           *cleanup && state.AcknowledgedRegistrations == 2 && state.VerifiedDeletions == 2 && !state.CurrentCreationConfirmed,
		"private_final_saved":        privateFinalSaved,
	}
	if err != nil {
		result["failed_step"] = state.Step
		result["error_kind"] = errorKind(err)
	}
	if outputErr := json.NewEncoder(os.Stdout).Encode(result); outputErr != nil {
		os.Exit(1)
	}
	if err != nil {
		os.Exit(1)
	}
}

func run(cleanup bool, state *runState) (err error) {
	if !cleanup {
		return errors.New("this complete roundtrip requires --cleanup-owned")
	}
	account, err := user.Current()
	if err != nil {
		return fmt.Errorf("resolve current Windows account: %w", err)
	}
	if !strings.HasPrefix(account.Uid, "S-1-") {
		return errors.New("current Windows SID unavailable")
	}
	if !filepath.IsAbs(outputDir) || !strings.HasPrefix(outputDir, `<WORK_ROOT>\`) {
		return errors.New("qualification output must be beneath <WORK_ROOT>")
	}
	if _, pathErr := os.Stat(command); !errors.Is(pathErr, os.ErrNotExist) {
		return fmt.Errorf("nonexistent action path is not confirmed absent: %v", pathErr)
	}
	if err := os.Mkdir(outputDir, 0700); err != nil {
		return fmt.Errorf("create fresh output directory (never reuse): %w", err)
	}
	state.OutputCreated = true
	seed := []byte(taskXML(account.Uid))
	manifest := map[string]any{
		"run_id": runID, "source_commit": sourceCommit, "created_utc": time.Now().UTC().Format(time.RFC3339Nano),
		"name": taskName, "account": account.Username, "sid": account.Uid,
		"action_path": command, "seed_sha256": hash(seed), "seed_bytes": len(seed),
		"disabled": true, "hidden": true, "triggers": "none", "allow_start_on_demand": false,
		"logon_type": "InteractiveToken", "run_level": "LeastPrivilege",
		"planned_registrations": 2, "planned_deletions": 2, "logical_task_names": 1,
		"cleanup_requested":      cleanup,
		"cleanup_preconditions":  "Acknowledged creation, exact name and run marker, unchanged complete exported bytes, expected action and principal, resolved current-owner SID, and disabled state. Preserve uncertain or mismatched tasks.",
		"concurrency_assumption": "No external writer to this isolated random name. Read/check followed by Delete is not atomic compare-and-delete.",
		"raw_export_format":      "Exact bytes returned by product ExportXML; no added BOM, character conversion, XML normalization, or reconstruction.",
	}
	rawManifest, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return err
	}
	if err := writeNewSynced(filepath.Join(outputDir, "manifest-private.json"), append(rawManifest, '\n')); err != nil {
		return err
	}
	if err := writeNewSynced(filepath.Join(outputDir, "seed-input.bin"), seed); err != nil {
		return err
	}
	log, err := os.OpenFile(filepath.Join(outputDir, "observations.jsonl"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer func() {
		if closeErr := log.Close(); closeErr != nil {
			if err == nil {
				state.Step = "observation_log_close"
			}
			err = errors.Join(err, fmt.Errorf("close observation log: %w", closeErr))
		}
	}()
	emit := func(event map[string]any) error {
		event["utc"] = time.Now().UTC().Format(time.RFC3339Nano)
		event["run_id"] = runID
		if err := json.NewEncoder(log).Encode(event); err != nil {
			return err
		}
		if err := log.Sync(); err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(event)
	}
	s, err := scheduler.New()
	if err != nil {
		return err
	}
	creator, ok := s.(scheduler.XMLCreator)
	if !ok {
		return errors.New("scheduler does not implement XMLCreator")
	}
	// Absence is a preflight observation only. Native TASK_CREATE, not the
	// preflight, decides whether a registration can occupy this name.
	raw, readErr := exportSnapshot(s, "preflight")
	if !errors.Is(readErr, scheduler.ErrTaskNotFound) || len(raw) != 0 {
		return fmt.Errorf("fresh name not confirmed absent: %v", readErr)
	}
	if err := emit(map[string]any{"operation": "preflight", "name": taskName, "absent": true}); err != nil {
		return err
	}
	state.Step = "seed_create"
	if err := register(creator, seed, "seed", state, emit); err != nil {
		return err
	}
	state.Step = "initial_export"
	original, err := inspectOwned(s, "initial", nil, account.Uid, state, emit)
	if err != nil {
		return err
	}
	state.Step = "roundtrip_delete"
	if _, err := inspectOwned(s, "before-roundtrip-delete", original, account.Uid, state, emit); err != nil {
		return err
	}
	if err := removeOwned(s, "roundtrip", original, state, emit); err != nil {
		return err
	}
	state.Step = "restore"
	// Pass the same saved raw slice from the actual ExportXML call. In
	// particular, do not convert its encoding or reconstruct taskXML here.
	beforeRestoreHash := hash(original)
	if err := register(creator, original, "restore", state, emit); err != nil {
		return err
	}
	if hash(original) != beforeRestoreHash {
		return errors.New("registration changed the caller's export bytes")
	}
	state.Step = "restored_export"
	if _, err := inspectOwned(s, "restored", original, account.Uid, state, emit); err != nil {
		return err
	}
	state.Step = "cleanup"
	if _, err := inspectOwned(s, "before-cleanup", original, account.Uid, state, emit); err != nil {
		return err
	}
	if err := removeOwned(s, "cleanup", original, state, emit); err != nil {
		return err
	}
	if state.AcknowledgedRegistrations != 2 || state.AcknowledgedDeleteCalls != 2 || state.VerifiedDeletions != 2 || state.CurrentCreationConfirmed {
		return errors.New("completed sequence has unexpected mutation counts")
	}
	state.Step = "complete"
	return emit(map[string]any{
		"operation": "qualification_checks_complete", "full_export_bytes_equal": true,
		"acknowledged_registrations": state.AcknowledgedRegistrations,
		"acknowledged_delete_calls":  state.AcknowledgedDeleteCalls,
		"verified_deletions":         state.VerifiedDeletions, "absent": true,
	})
}

func register(creator scheduler.XMLCreator, input []byte, phase string, state *runState, emit func(map[string]any) error) error {
	if state.CurrentCreationConfirmed {
		return errors.New("registration requires absence after the previous confirmed generation")
	}
	if err := emit(map[string]any{"operation": "create_attempt", "phase": phase, "name": taskName, "input_sha256": hash(input), "input_bytes": len(input)}); err != nil {
		return err
	}
	createErr := creator.CreateXMLIfAbsent(taskName, input)
	if createErr == nil {
		// Update before any fallible result logging: a failed emit must not
		// hide that the native registration was acknowledged.
		state.AcknowledgedRegistrations++
		state.CurrentCreationConfirmed = true
	}
	logErr := emit(map[string]any{
		"operation": "create_result", "phase": phase, "error_kind": errorKind(createErr),
		"acknowledged": createErr == nil, "acknowledged_registrations": state.AcknowledgedRegistrations,
		"outcome_not_established": createErr != nil,
	})
	return errors.Join(createErr, logErr)
}

// Every returned export is captured before semantic checks. A filename ending
// in .bin avoids implying that its declaration describes its byte encoding.
func exportSnapshot(s scheduler.Scheduler, label string) ([]byte, error) {
	raw, exportErr := s.ExportXML(taskName)
	if len(raw) != 0 || exportErr == nil {
		path := filepath.Join(outputDir, "export-"+label+".bin")
		if err := writeNewSynced(path, raw); err != nil {
			return raw, errors.Join(exportErr, fmt.Errorf("persist raw export %s: %w", label, err))
		}
		readback, err := os.ReadFile(path)
		if err != nil {
			return raw, errors.Join(exportErr, fmt.Errorf("read raw export %s: %w", label, err))
		}
		if !bytes.Equal(raw, readback) {
			return raw, errors.Join(exportErr, errors.New("persisted raw export differs from returned bytes"))
		}
	}
	return raw, exportErr
}

func inspectOwned(s scheduler.Scheduler, label string, expected []byte, sid string, state *runState, emit func(map[string]any) error) ([]byte, error) {
	if !state.CurrentCreationConfirmed {
		return nil, errors.New("identity inspection requires an acknowledged current creation")
	}
	raw, err := exportSnapshot(s, label)
	if err != nil {
		return raw, err
	}
	if expected != nil && !bytes.Equal(raw, expected) {
		return raw, errors.New("complete exported bytes changed; preserve the task for diagnosis")
	}
	if err := verifyDefinition(raw, sid); err != nil {
		return raw, err
	}
	status, err := s.Status(taskName)
	if err != nil {
		return raw, err
	}
	if status.Name != taskName || status.RuntimeState != scheduler.TaskRuntimeDisabled {
		return raw, errors.New("exact fixture name and disabled runtime state are not confirmed")
	}
	ownerMatches := status.Owner == sid
	if !ownerMatches {
		owner, ownerErr := user.Lookup(status.Owner)
		if ownerErr != nil {
			return raw, fmt.Errorf("resolve observed task owner: %w", ownerErr)
		}
		ownerMatches = owner.Uid == sid
	}
	if !ownerMatches {
		return raw, errors.New("observed owner SID differs from the fixture principal")
	}
	return raw, emit(map[string]any{
		"operation": "identity_observation", "phase": label, "name": taskName,
		"export_sha256": hash(raw), "export_bytes": len(raw), "full_bytes_compared": expected != nil,
		"fixture_definition_matches": true, "disabled": true, "owner_sid_matches": true,
	})
}

// Only the immediately preceding successful inspectOwned makes either removal
// eligible. No failed/uncertain registration or identity mismatch reaches here;
// there is no deferred cleanup or retry that could affect a replacement task.
func removeOwned(s scheduler.Scheduler, phase string, expected []byte, state *runState, emit func(map[string]any) error) error {
	if !state.CurrentCreationConfirmed || len(expected) == 0 {
		return errors.New("removal requires an acknowledged, fully identified current creation")
	}
	if err := emit(map[string]any{"operation": "delete_attempt", "phase": phase, "name": taskName, "verified_export_sha256": hash(expected)}); err != nil {
		return err
	}
	deleteErr := s.Delete(taskName)
	if deleteErr == nil {
		state.AcknowledgedDeleteCalls++
	}
	logErr := emit(map[string]any{
		"operation": "delete_result", "phase": phase, "error_kind": errorKind(deleteErr),
		"acknowledged": deleteErr == nil, "acknowledged_delete_calls": state.AcknowledgedDeleteCalls,
		"absence_verified": false,
	})
	if err := errors.Join(deleteErr, logErr); err != nil {
		return err
	}
	raw, readErr := exportSnapshot(s, "after-"+phase+"-delete")
	if !errors.Is(readErr, scheduler.ErrTaskNotFound) || len(raw) != 0 {
		return fmt.Errorf("post-delete absence not confirmed: %v", readErr)
	}
	state.VerifiedDeletions++
	state.CurrentCreationConfirmed = false
	return emit(map[string]any{"operation": "absence_observation", "phase": phase, "name": taskName, "absent": true, "verified_deletions": state.VerifiedDeletions})
}

func taskXML(sid string) string {
	return `<?xml version="1.0" encoding="UTF-16"?><Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"><RegistrationInfo><URI>` + escape(taskName) + `</URI><Source>` + escape(runID) + `</Source><Description>R22 disabled fixture § Привет 漢字 🙂</Description></RegistrationInfo><Triggers/><Principals><Principal id="Fixture"><UserId>` + escape(sid) + `</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals><Settings><AllowStartOnDemand>false</AllowStartOnDemand><StartWhenAvailable>false</StartWhenAvailable><Enabled>false</Enabled><Hidden>true</Hidden><WakeToRun>false</WakeToRun><ExecutionTimeLimit>PT1M</ExecutionTimeLimit></Settings><Actions Context="Fixture"><Exec><Command>` + escape(command) + `</Command><Arguments>` + escape(arguments) + `</Arguments><WorkingDirectory>` + escape(outputDir) + `</WorkingDirectory></Exec></Actions></Task>`
}

func verifyDefinition(raw []byte, sid string) error {
	var task struct {
		XMLName xml.Name
		URI     string `xml:"RegistrationInfo>URI"`
		Source  string `xml:"RegistrationInfo>Source"`
		Trigger struct {
			Inner string `xml:",innerxml"`
		} `xml:"Triggers"`
		Principal []struct {
			ID        string `xml:"id,attr"`
			UserID    string `xml:"UserId"`
			LogonType string
			RunLevel  *string
		} `xml:"Principals>Principal"`
		Settings struct {
			Enabled            *bool
			Hidden             *bool
			AllowStartOnDemand *bool
		}
		Actions struct {
			Context string `xml:"Context,attr"`
			Exec    []struct {
				Command          string
				Arguments        string
				WorkingDirectory string
			}
		}
	}
	decoder := xml.NewDecoder(bytes.NewReader(raw))
	// ExportXML returns UTF-8 bytes of COM-decoded Unicode text even when the
	// XML declaration still says UTF-16. This reader changes no saved/input bytes.
	decoder.CharsetReader = func(label string, input io.Reader) (io.Reader, error) {
		if strings.EqualFold(label, "UTF-16") || strings.EqualFold(label, "UTF-16LE") {
			return input, nil
		}
		return nil, fmt.Errorf("unexpected exported charset %q", label)
	}
	if err := decoder.Decode(&task); err != nil {
		return err
	}
	if task.XMLName.Local != "Task" || task.XMLName.Space != "http://schemas.microsoft.com/windows/2004/02/mit/task" || task.URI != taskName || task.Source != runID || strings.TrimSpace(task.Trigger.Inner) != "" || len(task.Principal) != 1 || len(task.Actions.Exec) != 1 {
		return errors.New("export does not match the fixture identity or structure")
	}
	p, action := task.Principal[0], task.Actions.Exec[0]
	// MS-TSCH SchRpcRegisterTask defines an omitted RunLevel as LeastPrivilege.
	// A present empty or different RunLevel remains a qualification failure.
	if p.UserID != sid || p.ID != "Fixture" || p.LogonType != "InteractiveToken" || (p.RunLevel != nil && *p.RunLevel != "LeastPrivilege") || task.Actions.Context != p.ID || action.Command != command || action.Arguments != arguments || action.WorkingDirectory != outputDir {
		return errors.New("export changed the principal, logon type, action, arguments, or working directory")
	}
	if task.Settings.Enabled == nil || *task.Settings.Enabled || task.Settings.Hidden == nil || !*task.Settings.Hidden || task.Settings.AllowStartOnDemand == nil || *task.Settings.AllowStartOnDemand {
		return errors.New("export did not retain disabled, hidden, demand-disabled settings")
	}
	return nil
}

func writeNewSynced(path string, data []byte) (err error) {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer func() {
		if closeErr := f.Close(); closeErr != nil {
			err = errors.Join(err, closeErr)
		}
	}()
	if _, err := f.Write(data); err != nil {
		return err
	}
	return f.Sync()
}

func escape(text string) string {
	var out bytes.Buffer
	_ = xml.EscapeText(&out, []byte(text))
	return out.String()
}

func hash(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func privateError(err error) string {
	if err != nil {
		return err.Error()
	}
	return ""
}

func errorKind(err error) string {
	switch {
	case err == nil:
		return ""
	case errors.Is(err, scheduler.ErrTaskNotFound):
		return "task_not_found"
	case errors.Is(err, scheduler.ErrTaskAlreadyExists):
		return "task_already_exists"
	case errors.Is(err, scheduler.ErrPermissionDenied):
		return "permission_denied"
	case errors.Is(err, scheduler.ErrTaskCorrupt):
		return "task_corrupt"
	case errors.Is(err, scheduler.ErrUnavailable):
		return "unavailable"
	case errors.Is(err, scheduler.ErrNotImplemented):
		return "not_implemented"
	case errors.Is(err, os.ErrPermission):
		return "file_permission"
	default:
		return "qualification_or_io_failure"
	}
}
