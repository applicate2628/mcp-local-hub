package cmaketrace

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"testing"
	"time"

	"mcp-local-hub/internal/vcpkgmcp/evidence"
	"mcp-local-hub/internal/vcpkgmcp/publicresult"
)

type generatedConsumerCase struct {
	Name       string   `json:"name"`
	File       string   `json:"file"`
	Command    string   `json:"command"`
	MaxRecords int      `json:"max_records"`
	Truncated  bool     `json:"truncated"`
	Projected  bool     `json:"projected"`
	Records    []Record `json:"records"`
}

type generatedConsumerOracle struct {
	Schema       int    `json:"schema"`
	TracePath    string `json:"trace_path"`
	TraceSHA256  string `json:"trace_sha256"`
	TraceBytes   int64  `json:"trace_bytes"`
	InputRecords int    `json:"input_records"`
	PayloadCount int    `json:"payload_records"`
	PublicLimit  int    `json:"public_limit"`
	Sources      []struct {
		Path   string `json:"path"`
		SHA256 string `json:"sha256"`
	} `json:"fixture_sources"`
	IncludeChain  []IncludeChainEntry      `json:"include_chain"`
	ExecutedLines []FileLines              `json:"executed_lines"`
	FilesInTrace  []string                 `json:"files_in_trace"`
	Cases         []generatedConsumerCase `json:"cases"`
}

func generatedConsumerHash(tb testing.TB, path string) string {
	tb.Helper()
	f, err := os.Open(path)
	if err != nil {
		tb.Fatal(err)
	}
	h := sha256.New()
	_, copyErr := io.Copy(h, f)
	closeErr := f.Close()
	if copyErr != nil || closeErr != nil {
		tb.Fatalf("hash %s: copy=%v close=%v", path, copyErr, closeErr)
	}
	return hex.EncodeToString(h.Sum(nil))
}

func loadGeneratedConsumerOracle(tb testing.TB) generatedConsumerOracle {
	tb.Helper()
	path := os.Getenv("MCPHUB_R22_CMAKE_ORACLE")
	if path == "" {
		tb.Skip("opt-in existing CMake trace consumer workload")
	}
	if !filepath.IsAbs(path) {
		tb.Fatal("absolute owned oracle path required")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		tb.Fatal(err)
	}
	var oracle generatedConsumerOracle
	if err := json.Unmarshal(raw, &oracle); err != nil {
		tb.Fatal(err)
	}
	if oracle.Schema != 1 || oracle.PublicLimit != publicresult.MaxEncodedBytes || oracle.PayloadCount != 16384 || len(oracle.Cases) != 3 || !filepath.IsAbs(oracle.TracePath) {
		tb.Fatal("oracle does not describe the pinned product/fixture contract")
	}
	for index, name := range []string{"selected-32", "selected-1000", "last-marker"} {
		if oracle.Cases[index].Name != name {
			tb.Fatal("unexpected case name/order")
		}
	}
	info, err := os.Stat(oracle.TracePath)
	if err != nil || !info.Mode().IsRegular() || info.Size() != oracle.TraceBytes || info.Size() > MaxTraceBytes {
		tb.Fatalf("trace file metadata mismatch: %v", err)
	}
	if got := generatedConsumerHash(tb, oracle.TracePath); got != oracle.TraceSHA256 {
		tb.Fatalf("trace SHA-256=%s, want %s", got, oracle.TraceSHA256)
	}
	for _, source := range oracle.Sources {
		if !filepath.IsAbs(source.Path) || generatedConsumerHash(tb, source.Path) != source.SHA256 {
			tb.Fatalf("fixture source changed: %s", source.Path)
		}
	}
	return oracle
}

func generatedConsumerExpected(oracle generatedConsumerOracle, query generatedConsumerCase) Result {
	return Result{
		Status: evidence.StatusOK, IncludeChain: oracle.IncludeChain, Records: query.Records,
		ExecutedLines: oracle.ExecutedLines, FilesInTrace: oracle.FilesInTrace,
		VersionHeaderPresent: true, Truncated: query.Truncated,
		Evidence: evidence.Evidence{Paths: []string{oracle.TracePath}},
	}
}

func checkGeneratedConsumer(tb testing.TB, oracle generatedConsumerOracle, query generatedConsumerCase, result Result, body []byte) int {
	tb.Helper()
	want := generatedConsumerExpected(oracle, query)
	if !reflect.DeepEqual(result, want) {
		tb.Fatalf("%s Trace result differs from independent CMake oracle: status=%s reason=%s records=%d incomplete=%v truncated=%v", query.Name, result.Status, result.Reason, len(result.Records), result.InputIncomplete, result.Truncated)
	}
	if len(body) == 0 || len(body) > publicresult.MaxEncodedBytes {
		tb.Fatalf("%s public bytes=%d exceed source-owned contract %d", query.Name, len(body), publicresult.MaxEncodedBytes)
	}
	var wire struct {
		Result
		Projection *publicresult.Projection `json:"result_projection"`
	}
	if err := json.Unmarshal(body, &wire); err != nil {
		tb.Fatal(err)
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(body, &fields); err != nil {
		tb.Fatal(err)
	}
	for _, field := range []string{"status", "malformed_line_count", "input_incomplete", "version_header_present", "truncated", "evidence"} {
		if _, present := fields[field]; !present {
			tb.Fatalf("%s omitted required public field %s", query.Name, field)
		}
	}
	if !query.Projected {
		if wire.Projection != nil || !reflect.DeepEqual(wire.Result, want) {
			tb.Fatalf("%s lost useful records, expanded arguments, indexes or completeness on the public boundary", query.Name)
		}
		return len(wire.Records)
	}
	if wire.Projection == nil || wire.Projection.Complete || len(wire.Projection.Omissions) != 4 {
		tb.Fatalf("%s missing explicit four-collection projection", query.Name)
	}
	want.Records, want.IncludeChain, want.ExecutedLines, want.FilesInTrace = nil, nil, nil, nil
	if !reflect.DeepEqual(wire.Result, want) {
		tb.Fatalf("%s projection lost verdict/evidence or retained an undeclared collection", query.Name)
	}
	wantOmitted := map[string]int{"include_chain": len(oracle.IncludeChain), "records": len(query.Records), "executed_lines": len(oracle.ExecutedLines), "files_in_trace": len(oracle.FilesInTrace)}
	for field := range wantOmitted {
		if _, present := fields[field]; present {
			tb.Fatalf("%s projected field %s must be omitted", query.Name, field)
		}
	}
	for _, omission := range wire.Projection.Omissions {
		count, found := wantOmitted[omission.Field]
		if !found || omission.Reason != publicresult.InternalProjectionLimit || omission.Retained != 0 || omission.Omitted == nil || *omission.Omitted != count {
			tb.Fatalf("%s wrong omission: %+v", query.Name, omission)
		}
		delete(wantOmitted, omission.Field)
	}
	return 0
}

func writeGeneratedConsumerArtifact(tb testing.TB, path string, content []byte) {
	tb.Helper()
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		tb.Fatal(err)
	}
	n, writeErr := f.Write(content)
	closeErr := f.Close()
	if writeErr != nil || closeErr != nil || n != len(content) {
		tb.Fatalf("write artifact %s: bytes=%d/%d write=%v close=%v", path, n, len(content), writeErr, closeErr)
	}
}

// This is the exact production Trace -> bounded publisher path, with an
// existing CMake-produced input. It does not invoke CMake, MCP transport,
// installed Product or a user project. It must pass on baseline and candidate;
// discarded-tail references are observations, not a hidden negative control.
func TestCMakeGeneratedConsumerWorkload(t *testing.T) {
	oracle := loadGeneratedConsumerOracle(t)
	out := os.Getenv("MCPHUB_R22_CMAKE_EVIDENCE")
	info, err := os.Stat(out)
	if !filepath.IsAbs(out) || err != nil || !info.IsDir() {
		t.Fatal("existing absolute owned evidence directory required")
	}
	for _, query := range oracle.Cases {
		t.Run(query.Name, func(t *testing.T) {
			start := time.Now()
			result := Trace(context.Background(), Args{TracePath: oracle.TracePath, File: query.File, Command: query.Command, MaxRecords: query.MaxRecords}, DefaultDeps())
			parsed := time.Now()
			body, err := publicresult.MarshalIndent(result)
			published := time.Now()
			if err != nil {
				t.Fatal(err)
			}
			wireRecords := checkGeneratedConsumer(t, oracle, query, result, body)
			tailRecords, tailArgs, tailStringBytes := 0, 0, 0
			for _, discarded := range result.Records[len(result.Records):cap(result.Records)] {
				if !reflect.DeepEqual(discarded, Record{}) {
					tailRecords++
				}
				tailArgs += len(discarded.Args)
				tailStringBytes += len(discarded.File) + len(discarded.Cmd)
				for _, arg := range discarded.Args {
					tailStringBytes += len(arg)
				}
			}
			bodyHash := sha256.Sum256(body)
			observation := map[string]any{
				"case": query.Name, "trace_sha256": oracle.TraceSHA256, "trace_bytes": oracle.TraceBytes,
				"go_version": runtime.Version(), "gomaxprocs": runtime.GOMAXPROCS(0),
				"trace_ns": parsed.Sub(start).Nanoseconds(), "publication_ns": published.Sub(parsed).Nanoseconds(), "trace_to_public_json_ns": published.Sub(start).Nanoseconds(),
				"internal_records": len(result.Records), "wire_records": wireRecords, "wire_bytes": len(body), "wire_sha256": hex.EncodeToString(bodyHash[:]),
				"projected": query.Projected, "input_incomplete": result.InputIncomplete, "truncated": result.Truncated,
				"record_backing_capacity": cap(result.Records), "discarded_nonzero_records": tailRecords, "discarded_argument_references": tailArgs, "discarded_string_bytes_sum": tailStringBytes,
				"public_limit": publicresult.MaxEncodedBytes, "max_trace_bytes": MaxTraceBytes, "max_line_bytes": MaxLineBytes, "max_parsed_records": MaxParsedRecords, "max_retained_record_bytes": MaxRetainedRecordBytes,
				"qualification": "one sequential observation; ordinary file caches; no latency/RSS/peak acceptance threshold; tail string sum counts references, not unique retained heap; MCP envelope and transport excluded",
			}
			receipt, err := json.MarshalIndent(observation, "", "  ")
			if err != nil {
				t.Fatal(err)
			}
			writeGeneratedConsumerArtifact(t, filepath.Join(out, query.Name+".public.json"), body)
			writeGeneratedConsumerArtifact(t, filepath.Join(out, query.Name+".observation.json"), receipt)
			runtime.KeepAlive(result)
		})
	}
	if got := generatedConsumerHash(t, oracle.TracePath); got != oracle.TraceSHA256 {
		t.Fatalf("trace changed during consumer run: %s", got)
	}
}

// Optional single-iteration characterization of the same three new workloads.
// Input generation, oracle loading, hash checking, preflight and output
// verification are outside the timer. This is not the old synthetic matrix.
func BenchmarkCMakeGeneratedConsumer(b *testing.B) {
	oracle := loadGeneratedConsumerOracle(b)
	for _, query := range oracle.Cases {
		b.Run(query.Name, func(b *testing.B) {
			args := Args{TracePath: oracle.TracePath, File: query.File, Command: query.Command, MaxRecords: query.MaxRecords}
			preflight := Trace(context.Background(), args, DefaultDeps())
			encoded, err := publicresult.MarshalIndent(preflight)
			if err != nil {
				b.Fatal(err)
			}
			wireRecords := checkGeneratedConsumer(b, oracle, query, preflight, encoded)
			wireBytes := len(encoded)
			preflight, encoded = Result{}, nil
			runtime.GC()
			var result Result
			var body []byte
			b.SetBytes(oracle.TraceBytes)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				result = Trace(context.Background(), args, DefaultDeps())
				body, err = publicresult.MarshalIndent(result)
				if err != nil {
					b.Fatal(err)
				}
			}
			b.StopTimer()
			checkGeneratedConsumer(b, oracle, query, result, body)
			b.ReportMetric(float64(wireBytes), "wire-B/op")
			b.ReportMetric(float64(wireRecords), "wire-records/op")
			runtime.KeepAlive(result)
			runtime.KeepAlive(body)
		})
	}
	if generatedConsumerHash(b, oracle.TracePath) != oracle.TraceSHA256 {
		b.Fatal("trace changed during consumer benchmark")
	}
}
