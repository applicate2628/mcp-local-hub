"""Qualify the frozen R22 CMake consumer on its own exact #624 source.

Only direct-child waits use the retained R21 command owner. No claim about a
whole-process-tree deadline/settlement is made by this observational harness.
"""
import sys
sys.dont_write_bytecode = True

from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

ROOT = Path(r"<R22_ROOT>")
PRIOR = Path(r"<R21_ROOT>")
PACKAGE = ROOT / "cmake-consumer-input"
WORK = ROOT / "cmake-consumer-work"
SOURCE = ROOT / "source-pr624"
BASE = "251fb4f03405ba438662976137afec0d9c27105e"
TREE = "2bc9f398025a32aa05b01bbcc6664d28ab9432cb"
OWNER_SHA = "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61"
PACKAGE_SHA = "43360214559c202d5e257d2521a5b24cb79dcd092fc2a8004dc6b9fd825a1580"
GO_TEST = "internal/vcpkgmcp/cmaketrace/cmake_generated_consumer_test.go"
GO_PRODUCT = "internal/vcpkgmcp/cmaketrace/cmaketrace.go"
CASES = ("selected-32", "selected-1000", "last-marker")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 3 or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Use cmake_consumer_run.py <phase> <script-sha256> in R22 root")
    phase, script_pin = sys.argv[1:]
    if phase not in ("prepare", "baseline", "candidate", "benchmark") or sha(Path(__file__).read_bytes()) != script_pin:
        raise RuntimeError("Unreviewed phase or script")
    owner_path = PRIOR / "check_recovery.py"
    if file_sha(owner_path) != OWNER_SHA or file_sha(PACKAGE / "manifest.json") != PACKAGE_SHA:
        raise RuntimeError("Frozen owner/package changed")
    spec = importlib.util.spec_from_file_location("r22_cmake_capture_owner", owner_path)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    manifest = json.loads((PACKAGE / "manifest.json").read_bytes())
    files = {item["path"]: item for item in manifest["local_files"]}
    inputs = ["execution-plan.json", "prepare_oracle.py", "overlay/" + GO_TEST,
              "fixture/CMakeLists.txt", "fixture/payload.cmake", "fixture/tail.cmake", "fixture/fixture-manifest.json"]
    for name in inputs:
        raw = (PACKAGE / name).read_bytes()
        if len(raw) != files[name]["bytes"] or sha(raw) != files[name]["sha256"]:
            raise RuntimeError("Input differs: " + name)
    plan = json.loads((PACKAGE / "execution-plan.json").read_bytes())

    class CMakeRunner(owner.Runner):
        def __init__(self):
            super().__init__("cmake-consumer-" + phase)
            self.out = ROOT / "evidence" / self.phase
            self.runtime = ROOT / "runtime" / self.phase

        def snapshot(self, path=None):
            return super().snapshot(SOURCE if path is None else path)

    runner = CMakeRunner()
    failure = None

    def admit():
        snapshot = runner.snapshot()
        if snapshot.get("head") != BASE or snapshot.get("tree") != TREE or snapshot.get("status") or snapshot.get("staged"):
            raise RuntimeError("Source is not the clean exact #624 snapshot")
        for item in manifest["source_pins"]:
            if blob((SOURCE / item["path"]).read_bytes()) != item["git_blob"]:
                raise RuntimeError("Product source blob differs: " + item["path"])
        if (SOURCE / GO_TEST).exists():
            raise RuntimeError("Unexpected existing consumer test in source")
        return snapshot

    def run(label, executable, arguments, timeout=120, cwd=SOURCE):
        row = runner.run(label, executable, arguments, timeout, cwd)
        runner.require_pass(row)
        if "event_error_type" in row or row.get("tests", {}).get("skip"):
            raise RuntimeError("Invalid/skipped event stream: " + label)
        return row

    def prepared():
        path = ROOT / "evidence/cmake-consumer-prepare/receipt.json"
        record = json.loads(path.read_bytes())
        if not record.get("completed") or record.get("source_head") != BASE or record.get("consumer_script_sha256") != script_pin:
            raise RuntimeError("Completed preparation with this reviewed script is required")
        saved = record["prepared_inputs"]
        for relative, digest in saved.items():
            if file_sha(WORK / relative) != digest:
                raise RuntimeError("Prepared input changed: " + relative)
        runner.receipt["prepare_receipt_sha256"] = file_sha(path)
        return saved

    try:
        runner.begin()
        runner.paths = [item["path"] for item in manifest["source_pins"]] + [GO_TEST]
        runner.receipt.update(base=BASE, base_tree=TREE, consumer_script_sha256=script_pin,
                              consumer_manifest_sha256=PACKAGE_SHA,
                              source_manifest_role="R21 support admission only; frozen consumer manifest and source_pins own R22 source",
                              producer_lifetime="Retained direct-child handle wait only; no full process-tree qualification",
                              input_sha256={name: files[name]["sha256"] for name in inputs})
        runner.receipt["source_before"] = admit()
        runner.env = {k: v for k, v in runner.env.items() if not k.upper().startswith("CMAKE_")}
        if phase == "prepare":
            WORK.mkdir(exist_ok=False)
            for name in ("fixture", "build", "producer", "formatted"):
                (WORK / name).mkdir(exist_ok=False)
            for leaf in ("CMakeLists.txt", "payload.cmake", "tail.cmake", "fixture-manifest.json"):
                with (WORK / "fixture" / leaf).open("xb") as stream:
                    stream.write((PACKAGE / "fixture" / leaf).read_bytes())
            formatted = WORK / "formatted/cmake_generated_consumer_test.go"
            with formatted.open("xb") as stream:
                stream.write((PACKAGE / "overlay" / GO_TEST).read_bytes())
            run("format-consumer", owner.GOFMT, ["-w", str(formatted)], 60)
            for name in ("cmake", "ninja"):
                tool = manifest["installed_tools_reported_by_parent"][name]
                if file_sha(Path(tool["path"])) != tool["sha256"]:
                    raise RuntimeError("Installed tool differs: " + name)
            run("ninja-version", Path(plan["producer"]["generator_executable"]), ["--version"], 30, WORK)
            mapping = {"fixture": str(WORK / "fixture"), "build": str(WORK / "build"),
                       "trace": str(WORK / "producer/trace.jsonl")}
            arguments = []
            for argument in plan["producer"]["argv"]:
                for key, value in mapping.items():
                    argument = argument.replace("{{" + key + "}}", value)
                if "{{" in argument:
                    raise RuntimeError("Unresolved producer argument")
                arguments.append(argument)
            run("cmake-configure", Path(plan["producer"]["executable"]), arguments, 90, WORK)
            run("prepare-oracle", Path(sys.executable), ["-B", str(PACKAGE / "prepare_oracle.py"),
                 "--fixture", mapping["fixture"], "--trace", mapping["trace"],
                 "--output", str(WORK / "producer/oracle.json")], 60, WORK)
            for name in ("cmake", "ninja"):
                tool = manifest["installed_tools_reported_by_parent"][name]
                if file_sha(Path(tool["path"])) != tool["sha256"]:
                    raise RuntimeError("Installed tool changed: " + name)
            runner.receipt["prepared_inputs"] = {name: file_sha(WORK / name) for name in (
                "fixture/CMakeLists.txt", "fixture/payload.cmake", "fixture/tail.cmake", "fixture/fixture-manifest.json",
                "formatted/cmake_generated_consumer_test.go", "producer/trace.jsonl", "producer/oracle.json")}
        else:
            saved = prepared()
            output = WORK / phase
            output.mkdir(exist_ok=False)
            runner.env.update(MCPHUB_R22_CMAKE_ORACLE=str(WORK / "producer/oracle.json"), MCPHUB_R22_CMAKE_EVIDENCE=str(output))
            overlay = {str(SOURCE / GO_TEST): str(WORK / "formatted/cmake_generated_consumer_test.go")}
            product = None
            if phase != "baseline":
                product = ROOT / "scopes/cmake/candidate" / GO_PRODUCT
                if file_sha(product) != manifest["cmake_candidate_production_sha256"]:
                    raise RuntimeError("Reviewed clear-tail product changed")
                overlay[str(SOURCE / GO_PRODUCT)] = str(product)
            owner.save_new(runner.out / "overlay.json", {"Replace": overlay})
            overlay_hash = file_sha(runner.out / "overlay.json")
            args = plan["go"]["benchmark_argv" if phase == "benchmark" else "contract_argv"]
            row = run("consumer", owner.GO, [args[0], "-overlay", str(runner.out / "overlay.json"), *args[1:]], 360)
            if file_sha(runner.out / "overlay.json") != overlay_hash:
                raise RuntimeError("Go overlay mapping changed during execution")
            if product is not None:
                actual_product = file_sha(product)
                if actual_product != manifest["cmake_candidate_production_sha256"]:
                    raise RuntimeError("Product overlay changed during execution")
                runner.receipt["product_overlay_sha256_after"] = actual_product
            expected = ["PACKAGE:mcp-local-hub/internal/vcpkgmcp/cmaketrace"]
            if phase != "benchmark":
                expected += ["TestCMakeGeneratedConsumerWorkload", *["TestCMakeGeneratedConsumerWorkload/" + name for name in CASES]]
            if Counter(row["tests"]["pass"]) != Counter(expected) or row["tests"]["fail"] or row["tests"]["skip"]:
                raise RuntimeError("Exact consumer event oracle differs")
            if phase == "benchmark":
                rendered = "".join(event.get("Output", "") for event in owner.test_events((runner.out / "consumer.stdout.log").read_bytes()))
                for name, count in zip(CASES, (32, 0, 1)):
                    pattern = r"(?m)^BenchmarkCMakeGeneratedConsumer/" + re.escape(name) + r"(?:-\d+)?\s+1\s+[^\n]+$"
                    lines = re.findall(pattern, rendered)
                    metric = re.search(r"([0-9.]+)\s+wire-records/op", lines[0]) if len(lines) == 1 else None
                    if metric is None or float(metric.group(1)) != count:
                        raise RuntimeError("Benchmark selection/useful wire-record oracle differs: " + name)
                runner.receipt["benchmark_interpretation"] = "One iteration per new workload; no latency, peak/RSS, or percentile acceptance"
            else:
                artifacts = [name + suffix for name in CASES for suffix in (".public.json", ".observation.json")]
                if sorted(p.name for p in output.iterdir()) != sorted(artifacts):
                    raise RuntimeError("Missing/unexpected consumer artifacts")
                runner.receipt["consumer_artifacts"] = {name: file_sha(output / name) for name in artifacts}
                if phase == "candidate":
                    baseline = json.loads((ROOT / "evidence/cmake-consumer-baseline/receipt.json").read_bytes())
                    if not baseline.get("completed") or baseline.get("prepare_receipt_sha256") != runner.receipt["prepare_receipt_sha256"] or baseline.get("source_head") != BASE or baseline.get("source_tree") != TREE or baseline.get("consumer_script_sha256") != script_pin or baseline.get("consumer_manifest_sha256") != PACKAGE_SHA:
                        raise RuntimeError("Corresponding baseline did not complete")
                    if set(baseline.get("consumer_artifacts", {})) != set(artifacts):
                        raise RuntimeError("Baseline artifact manifest differs")
                    for name, digest in baseline["consumer_artifacts"].items():
                        if file_sha(WORK / "baseline" / name) != digest:
                            raise RuntimeError("Completed baseline artifact drifted: " + name)
                    for name in CASES:
                        file = name + ".public.json"
                        if (output / file).read_bytes() != (WORK / "baseline" / file).read_bytes():
                            raise RuntimeError("Published bytes changed: " + name)
                    runner.receipt["baseline_candidate_public_bytes_equal"] = True
            for name, digest in saved.items():
                if file_sha(WORK / name) != digest:
                    raise RuntimeError("Prepared input drifted: " + name)
        runner.receipt.update(source_after=admit(), source_head=BASE, source_tree=TREE, completed=True, state="complete")
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
