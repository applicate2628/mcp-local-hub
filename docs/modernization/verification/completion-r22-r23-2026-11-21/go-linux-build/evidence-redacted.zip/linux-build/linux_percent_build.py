"""Cross-compile a reviewed Linux-only regression; compilation is not execution."""
import sys
sys.dont_write_bytecode = True

import base64
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(r"<LINUX_BUILD_ROOT>")
SOURCE = ROOT / "source-pr660"
PACKAGE = ROOT / "linux-percent-input"
WORK = ROOT / "linux-percent-work"
PRIOR = Path(r"<WORK_ROOT>\mcp-r17-current-task-recovery-20261121")
BASE = "ba17867125b3728fb734e90b383639a3ff9175ee"
TREE = "1c803a8ef8227fe6c289be69c7897aee1549372b"
OWNER_SHA = "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61"
PRODUCT = "internal/autostart/linux.go"
TEST = "internal/autostart/linux_exec_percent_test.go"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def main():
    if os.name != "nt" or sys.flags.optimize or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 5:
        raise RuntimeError("Expected phase, script SHA, provenance SHA and selection SHA in R22 root")
    phase, script_pin, provenance_pin, selection_pin = sys.argv[1:]
    if phase not in {"prepare", "compile-control", "compile-candidate"} or sha(Path(__file__).read_bytes()) != script_pin:
        raise RuntimeError("Unreviewed script or phase")
    for name, expected in (("PROVENANCE.json", provenance_pin), ("QUALIFICATION.json", selection_pin)):
        if sha((PACKAGE / name).read_bytes()) != expected:
            raise RuntimeError("Input pin differs: " + name)
    manifest = json.loads((PACKAGE / "PROVENANCE.json").read_bytes())
    if manifest["source_head"] != BASE or manifest["source_tree"] != TREE or {f["path"] for f in manifest["files"]} != {PRODUCT, TEST}:
        raise RuntimeError("Wrong source or scope")
    owner_path = PRIOR / "check_recovery.py"
    if sha(owner_path.read_bytes()) != OWNER_SHA:
        raise RuntimeError("Capture owner changed")
    spec = importlib.util.spec_from_file_location("r22_linux_build_capture", owner_path)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)

    class LinuxBuildRunner(owner.Runner):
        def __init__(self):
            super().__init__("linux-percent-" + phase)
            self.out = ROOT / "evidence" / self.phase
            self.runtime = ROOT / "runtime" / self.phase

        def snapshot(self, path=None):
            return super().snapshot(SOURCE if path is None else path)

    runner = LinuxBuildRunner()
    failure = None

    def admit():
        snap = runner.snapshot()
        if snap.get("head") != BASE or snap.get("tree") != TREE or snap.get("status") or snap.get("staged"):
            raise RuntimeError("Source is not exact and clean")
        for file in manifest["files"]:
            path = SOURCE / file["path"]
            if (blob(path.read_bytes()) if path.is_file() else None) != file["original_git_blob"]:
                raise RuntimeError("Original blob differs: " + file["path"])
            raw = (PACKAGE / "candidate" / file["path"]).read_bytes()
            if sha(raw) != file["candidate_sha256"] or blob(raw) != file["candidate_git_blob"]:
                raise RuntimeError("Candidate differs: " + file["path"])
        return snap

    def captured(label, executable, arguments, timeout):
        # go test -c has no libtest event stream. Capture directly, not as test JSON.
        row = runner.execute(label, [str(executable), *arguments], SOURCE, timeout, runner.snapshot())
        try:
            row["source_after"] = runner.snapshot()
        except Exception as error:
            row["source_after_error"] = type(error).__name__ + ": " + str(error)
        runner.receipt["commands"].append(row)
        owner.save_new(runner.out / (label + ".receipt.json"), row)
        runner.require_pass(row)
        return row

    try:
        runner.begin()
        runner.paths = [PRODUCT, TEST, "internal/autostart/linux_test.go", "internal/autostart/autostart.go"]
        runner.receipt.update(base=BASE, base_tree=TREE, script_sha256=script_pin,
                              provenance_sha256=provenance_pin, selection_sha256=selection_pin,
                              source_manifest_role="R21 capture-owner admission only; Linux provenance owns source",
                              tests_executed=False, race_detector=False)
        runner.receipt["source_before"] = admit()
        runner.env.update(GOOS="linux", GOARCH="amd64", CGO_ENABLED="0")
        runner.receipt["environment"].update(GOOS="linux", GOARCH="amd64", CGO_ENABLED="0")
        formatted = WORK / "formatted"
        if phase == "prepare":
            WORK.mkdir(exist_ok=False)
            formatted.mkdir(exist_ok=False)
            for file in manifest["files"]:
                destination = formatted / Path(file["path"]).name
                with destination.open("xb") as stream:
                    stream.write((PACKAGE / "candidate" / file["path"]).read_bytes())
            captured("gofmt", owner.GOFMT, ["-w", *[str(formatted / Path(f["path"]).name) for f in manifest["files"]]], 30)
            runner.receipt["formatted"] = {f["path"]: {"sha256": sha((formatted / Path(f["path"]).name).read_bytes()), "git_blob": blob((formatted / Path(f["path"]).name).read_bytes())} for f in manifest["files"]}
        else:
            prep_path = ROOT / "evidence/linux-percent-prepare/receipt.json"
            prep = json.loads(prep_path.read_bytes())
            if not prep.get("completed") or prep.get("script_sha256") != script_pin or prep.get("provenance_sha256") != provenance_pin or prep.get("selection_sha256") != selection_pin:
                raise RuntimeError("Preparation is not admitted")
            for path, expected in prep["formatted"].items():
                if sha((formatted / Path(path).name).read_bytes()) != expected["sha256"]:
                    raise RuntimeError("Formatted candidate changed")
            out = WORK / phase
            out.mkdir(exist_ok=False)
            selected = [TEST] if phase == "compile-control" else [PRODUCT, TEST]
            overlay_path = out / "overlay.json"
            owner.save_new(overlay_path, {"Replace": {str(SOURCE / p): str(formatted / Path(p).name) for p in selected}})
            overlay_sha = sha(overlay_path.read_bytes())
            binary = out / "autostart.test"
            captured("compile", owner.GO, ["test", "-c", "-p=1", "-overlay", str(overlay_path), "-o", str(binary), "./internal/autostart"], 300)
            if phase == "compile-candidate":
                captured("vet", owner.GO, ["vet", "-overlay", str(overlay_path), "./internal/autostart"], 180)
            raw = binary.read_bytes()
            if len(raw) < 64 or raw[:6] != b"\x7fELF\x02\x01" or int.from_bytes(raw[18:20], "little") != 62:
                raise RuntimeError("Output is not a little-endian Linux AMD64 ELF binary")
            packed = gzip.compress(raw, mtime=0)
            with (out / "autostart.test.gz").open("xb") as stream:
                stream.write(packed)
            encoded = base64.b64encode(packed).decode("ascii")
            with (out / "autostart.test.gz.b64").open("x", encoding="ascii", newline="\n") as stream:
                for start in range(0, len(encoded), 4096):
                    stream.write(encoded[start:start + 4096] + "\n")
            for path, expected in prep["formatted"].items():
                if sha((formatted / Path(path).name).read_bytes()) != expected["sha256"]:
                    raise RuntimeError("Formatted candidate changed during compilation")
            if sha(overlay_path.read_bytes()) != overlay_sha:
                raise RuntimeError("Overlay changed")
            runner.receipt.update(prepare_receipt_sha256=sha(prep_path.read_bytes()), overlay_sha256=overlay_sha,
                                  binary={"path": str(binary), "sha256": sha(raw), "bytes": len(raw)},
                                  packed_binary={"path": str(out / "autostart.test.gz"), "sha256": sha(packed), "bytes": len(packed)},
                                  transfer_lines=(len(encoded) + 4095) // 4096)
        runner.receipt.update(source_after=admit(), source_head=BASE, source_tree=TREE, state="complete", completed=True)
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
