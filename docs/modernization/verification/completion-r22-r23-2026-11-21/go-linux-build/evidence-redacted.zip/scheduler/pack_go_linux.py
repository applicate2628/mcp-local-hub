"""Read-only verification and public projection of fixed Go/Linux evidence.

No tests, builds, subprocesses or native operations are invoked. Raw binaries,
runtime directories and the R22 native fixture are outside the input allowlist.
"""
import sys
sys.dont_write_bytecode = True
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import zipfile

TASK = Path(r"<SCHEDULER_R23_ROOT>")
LINUX = Path(r"<LINUX_BUILD_ROOT>")
DEST = TASK / "public-go-linux"
SCHEDULER_PHASES = ("prepare", "control", "candidate", "adjacent", "build-vet")
LINUX_PHASES = ("prepare", "compile-control", "compile-candidate")
SCHEDULER_MANIFEST_SHA = "9519cb49f5c826077b8cace59c453ae1cb71351c90bd7cd53b61400b1c1651ce"
SKIP = "TestExecuteInstallToRollbackBackendCompatibility/unsupported_platform"
members, origins, streams, summaries = {}, {}, [], []
total = 0

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def need(value, reason):
    if not value:
        raise ValueError(reason)

def encode(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()

def read(root, path, target=None, pin=None):
    global total
    full = root / path
    need(full.is_relative_to(root) and ".." not in full.parts, "Input outside task root")
    for part in (full, *full.parents):
        info = part.lstat()
        need(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "Reparse input")
        if part == root:
            break
    need(full.is_file() and full.stat().st_size <= 32 * 1024 * 1024, "Invalid input size/type")
    raw = full.read_bytes()
    need(pin is None or sha(raw) == pin, "Input pin differs: " + path)
    name = target or ("scheduler/" if root == TASK else "linux-build/") + path.replace("\\", "/")
    if name in members:
        need(members[name] == raw, "Input changed during read")
    else:
        total += len(raw)
        need(total <= 96 * 1024 * 1024, "Input byte bound exceeded")
        members[name], origins[name] = raw, full
    return raw, name

def snapshot(value, head, tree):
    need(value.get("head") == head and value.get("tree") == tree and not value.get("status") and not value.get("staged"), "Source snapshot differs")

def phase(root, relative, expected_complete, head, tree):
    raw, _ = read(root, relative + "/receipt.json")
    receipt = json.loads(raw)
    need(receipt["completed"] is expected_complete and receipt["state"] == ("complete" if expected_complete else "failed"), "Retained phase state differs")
    need(receipt.get("runner_sha256") == "6f69fc636f8ec47b725f07238f7ea2180cee9fb8efbd8e8a7275f4665ea87e61", "Capture owner differs")
    need(receipt.get("whole_process_tree_deadline_enforced") is False and receipt.get("process_tree_settlement_observed") is False, "Unsupported process-tree claim")
    for name in ("source_before", "source_after", "source_final"):
        if name in receipt:
            snapshot(receipt[name], head, tree)
    expected = {"receipt.json", "receipt-initial.json"}
    commands = []
    for group in ("commands", "observations"):
        for row in receipt[group]:
            label = row["label"]
            need(row.get("settled") is True and not row.get("timed_out") and not any(k in row for k in ("error_type", "event_error_type", "source_after_error", "stdout_capture_error", "stderr_capture_error")), "Unsettled/error command")
            need(row.get("whole_process_tree_deadline_enforced") is False, "Changed lifecycle boundary")
            for suffix in (".started.json", ".launched.json", ".receipt.json", ".stdout.log", ".stderr.log"):
                expected.add(label + suffix)
                read(root, relative + "/" + label + suffix)
            saved, _ = read(root, relative + "/" + label + ".receipt.json")
            need(json.loads(saved) == {k: v for k, v in row.items() if k != "scope_oracle_matched"}, "Command and phase receipt differ")
            for stream in ("stdout", "stderr"):
                data, member = read(root, relative + "/" + label + "." + stream + ".log")
                need(len(data) == row[stream]["bytes"] and sha(data) == row[stream]["sha256"], "Original stream hash differs")
                need(b"WARNING: DATA RACE" not in data, "Unexpected data race")
                streams.append(member)
            if "tests" in row:
                data, _ = read(root, relative + "/" + label + ".stdout.log")
                events = [json.loads(line) for line in data.splitlines()]
                terminal = {a: [e.get("Test", "PACKAGE:" + e["Package"]) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
                need(terminal == row["tests"], "Go terminal events differ")
            if group == "commands":
                commands.append({k: row[k] for k in ("label", "args", "exit_code", "seconds", "started_utc", "finished_utc")})
                commands[-1]["tests"] = row.get("tests", {})
                commands[-1]["scope_oracle_matched"] = row.get("scope_oracle_matched")
    folder = root / relative
    extras = {"overlay.json"} if (folder / "overlay.json").exists() else set()
    need({p.name for p in folder.iterdir()} == expected | extras, "Unexpected evidence inventory")
    for name in expected | extras:
        read(root, relative + "/" + name)
    summaries.append({"phase": relative.split("/")[-1], "base": head, "base_tree": tree,
                      "receipt_original_sha256": sha(raw), "state": receipt["state"],
                      "completed": receipt["completed"], "error": receipt.get("error"),
                      "commands": commands, "observations": len(receipt["observations"])})
    return receipt

def main():
    need(os.name == "nt" and Path(__file__).resolve().parent == TASK and not DEST.exists(), "Wrong root or existing output")
    read(TASK, Path(__file__).name)
    for name in ("qualify_scope.py", "prepare_candidate.py", "selection.json"):
        read(TASK, name)
    raw, _ = read(TASK, "scopes/current-outcome/manifest.json", pin=SCHEDULER_MANIFEST_SHA)
    plan = json.loads(raw)
    need(sha((TASK / "qualify_scope.py").read_bytes()) == plan["wrapper_sha256"], "Scheduler wrapper differs")
    for item in plan["files"]:
        candidate, _ = read(TASK, "scopes/current-outcome/candidate/" + item["path"], pin=item["candidate_sha256"])
        need(blob(candidate) == item["candidate_git_blob"], "Candidate Git blob differs")
        original = TASK / "source-pr660" / item["path"]
        if item["original_git_blob"] is None:
            need(not original.exists(), "Unexpected original file")
        else:
            old, _ = read(TASK, "source-pr660/" + item["path"])
            need(blob(old) == item["original_git_blob"], "Original Git blob differs")
    for name in SCHEDULER_PHASES:
        r = phase(TASK, "evidence/current-outcome-" + name, name != "adjacent", plan["source_head"], plan["source_tree"])
        if name in ("control", "candidate"):
            row = r["commands"][0]
            need(row.get("scope_oracle_matched") is True, "New-case oracle not matched")
        if name == "adjacent":
            row = r["commands"][0]
            need(row["exit_code"] == 0 and row["tests"]["skip"] == [SKIP] and not row["tests"]["fail"] and len(row["tests"]["pass"]) == 78, "Adjacent evidence differs")
            need(r["error"] == "Qualification selected an unexpected skipped test: adjacent", "Adjacent wrapper failure changed")
            need(all(row["tests"]["pass"].count(n) == count for n, count in plan["phases"]["adjacent"]["commands"][0]["required_root_pass_counts"].items()), "Adjacent root selection differs")
    read(TASK, "source-pr660/internal/api/install_task_rollback_test.go")
    read(LINUX, "linux_percent_build.py", pin="abcb8cb0c09c11eb3bbfa008c1f1f7c82829bcb8f4dff6785051e1c1dac79439")
    prov_raw, _ = read(LINUX, "linux-percent-input/PROVENANCE.json", pin="02e46d392ca567d05cefdc3d3fda73d38c7250721d730611dc2ba9c41b9fa898")
    read(LINUX, "linux-percent-input/QUALIFICATION.json", pin="02a37b7f9da924efecc96f5d8c0c039c1046ebd384c3d4c9f73c25230cb7a25d")
    provenance = json.loads(prov_raw)
    for item in provenance["files"]:
        read(LINUX, "linux-percent-input/candidate/" + item["path"], pin=item["candidate_sha256"])
        read(LINUX, "linux-percent-work/formatted/" + Path(item["path"]).name, pin=item["candidate_sha256"])
        original = LINUX / "source-pr660" / item["path"]
        if item["original_git_blob"]:
            old, _ = read(LINUX, "source-pr660/" + item["path"])
            need(blob(old) == item["original_git_blob"], "Linux original differs")
        else:
            need(not original.exists(), "Unexpected Linux original")
    for name in ("internal/autostart/linux_test.go", "internal/autostart/autostart.go"):
        read(LINUX, "source-pr660/" + name)
    for name in LINUX_PHASES:
        r = phase(LINUX, "evidence/linux-percent-" + name, True, provenance["source_head"], provenance["source_tree"])
        need(r["tests_executed"] is False and r["race_detector"] is False and all(c["exit_code"] == 0 for c in r["commands"]), "Linux build boundary differs")
        need(r["script_sha256"] == "abcb8cb0c09c11eb3bbfa008c1f1f7c82829bcb8f4dff6785051e1c1dac79439" and r["provenance_sha256"] == sha(prov_raw), "Linux build provenance differs")
        if name != "prepare":
            read(LINUX, "linux-percent-work/" + name + "/overlay.json", pin=r["overlay_sha256"])
            summaries[-1].update(binary=r["binary"], packed_binary=r["packed_binary"], overlay_sha256=r["overlay_sha256"])
    # Exact literal projection, including the JSON-escaped representation.
    pairs = [(str(TASK), "<SCHEDULER_R23_ROOT>"), (str(LINUX), "<LINUX_BUILD_ROOT>"),
             (r"<WORK_ROOT>", "<WORK_ROOT>"), (str(Path.home()), "<USER_PROFILE>")]
    pairs = sorted(pairs, key=lambda x: -len(x[0]))
    def redact(raw):
        text = raw.decode("utf-8")
        for old, new in pairs:
            text = text.replace(json.dumps(old)[1:-1], json.dumps(new)[1:-1]).replace(old, new)
        return text.encode("utf-8")
    summary = {"schema": 1, "phases": summaries, "tests_rerun": False,
               "source_interpretation": "Pinned base plus explicit overlay, not a whole published-head rerun",
               "adjacent_interpretation": "Original wrapper FAILED is retained: all 20 Windows roots passed; one Linux/macOS-only subtest skipped on Windows. No rerun or relabel of original receipt.",
               "process_tree_deadline_enforced": False, "process_tree_settlement_proven": False,
               "linux_execution_included": False, "linux_execution_location": "Separate local Linux execution evidence", "binaries_published": False}
    members["SUMMARY.json"] = encode(summary)
    manifest = []
    public = {}
    for name, raw in sorted(members.items()):
        clean = redact(raw)
        if name.endswith(".json"):
            json.loads(clean)
        public[name] = clean
        manifest.append({"path": name, "original_bytes": len(raw), "original_sha256": sha(raw),
                         "public_bytes": len(clean), "public_sha256": sha(clean), "redacted": clean != raw,
                         "stream": name in streams, "generated": name == "SUMMARY.json"})
    public["MANIFEST.json"] = encode({"schema": 1, "coverage": "All archive members except this manifest", "members": manifest})
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(public.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
    packed = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(packed)) as archive:
        need(archive.testzip() is None and set(archive.namelist()) == set(public), "Archive integrity differs")
        need(all(archive.read(name) == raw for name, raw in public.items()), "Archive member differs")
    for name, path in origins.items():
        need(path.read_bytes() == members[name], "Source evidence changed during packing")
    metadata = {"schema": 1, "archive": "evidence-redacted.zip", "archive_bytes": len(packed), "archive_sha256": sha(packed),
                "archive_members": len(public), "manifest_member_hashes": len(manifest),
                "manifest_sha256": sha(public["MANIFEST.json"]), "original_streams_checked": len(streams),
                "unchanged_public_streams": sum(row["stream"] and not row["redacted"] for row in manifest),
                "redacted_public_streams": sum(row["stream"] and row["redacted"] for row in manifest)}
    DEST.mkdir(exist_ok=False)
    outputs = {"evidence-redacted.zip": packed, "SUMMARY.json": public["SUMMARY.json"], "MANIFEST.json": public["MANIFEST.json"], "archive-metadata.json": encode(metadata)}
    for name, raw in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(raw)
        need((DEST / name).read_bytes() == raw, "Saved output differs")
    print(json.dumps(metadata))

if __name__ == "__main__":
    main()
