"""Unpack the reviewed four-file draft, format it and freeze test selection.

This does not execute product code or tests. It writes only a fresh R23 scope.
"""
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(r"<SCHEDULER_R23_ROOT>")
PAYLOAD_SHA = "c09ad1ceb3ccc155e9298b680bc3c103996c3cb09b2fb60e6f3011206e0675c4"
WRAPPER_SHA = "71b0636c6486122bb9de235fcf4001d9038a3f0a0251f5cc0f4e1ea831fde8e6"
ORIGINALS = {
    "internal/api/install.go": "9f941afd7d786d7c56e4f4460d0c372f7cb89f76",
    "internal/api/install_task_rollback.go": "76dfe3156f1faaa1a29f0cdb08ea81975f77e7a1",
    "internal/api/install_scheduler_snapshot_test.go": "dcd2f677f42f7370b97f19a29c5108525f4a078d",
    "internal/api/install_task_mutation_failure_test.go": None,
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Wrong platform or task root")
    payload = base64.b64decode((ROOT / "candidate-payload.json.gz.b64").read_bytes())
    if sha(payload) != PAYLOAD_SHA or sha((ROOT / "qualify_scope.py").read_bytes()) != WRAPPER_SHA:
        raise RuntimeError("Reviewed payload or runner changed")
    data = json.loads(gzip.decompress(payload))
    if set(data) != set(ORIGINALS) or not all(isinstance(x, str) for x in data.values()):
        raise RuntimeError("Unexpected source payload")
    selection = json.loads((ROOT / "selection.json").read_bytes())
    dest = ROOT / "scopes/current-outcome"
    dest.mkdir(parents=True, exist_ok=False)
    paths = []
    before = {}
    for name, text in data.items():
        p = dest / "candidate" / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(text.encode("utf-8"))
        before[name] = sha(p.read_bytes())
        paths.append(p)
    result = subprocess.run([r"C:\msys64\ucrt64\bin\gofmt.exe", "-w", *map(str, paths)],
                            cwd=ROOT, capture_output=True, timeout=60, check=False)
    (dest / "gofmt.stdout.log").write_bytes(result.stdout)
    (dest / "gofmt.stderr.log").write_bytes(result.stderr)
    if result.returncode != 0 or result.stdout or result.stderr:
        raise RuntimeError("Formatter did not finish cleanly")
    files = []
    for p in paths:
        name = p.relative_to(dest / "candidate").as_posix()
        raw = p.read_bytes()
        files.append({"path": name, "original_git_blob": ORIGINALS[name],
                      "candidate_git_blob": blob(raw), "candidate_sha256": sha(raw),
                      "reviewed_preformat_sha256": before[name], "bytes": len(raw)})
    allpaths = list(data)
    testpaths = ["internal/api/install_task_mutation_failure_test.go"]
    package = "PACKAGE:mcp-local-hub/internal/api"

    def test(label, selector, expected, race=False):
        args = ["test", "-overlay", "{overlay}", "-json", "-tags=test_state_path_env",
                "-count=1", "-p=1", "-timeout=180s", "-run=" + selector, "./internal/api"]
        if race:
            args.insert(4, "-race")
        return {"label": label, "args": args, "expected_exit_code": expected, "timeout_seconds": 240}

    control = test("control", selection["selectors"][0], 1)
    control["expected_tests"] = {"pass": {}, "fail": {name: 1 for name in [*selection["new_tests"], package]}, "skip": {}}
    control["required_output"] = ["CURRENT-MUTATION-EFFECTS", "CURRENT-MUTATION-CLASS", "CURRENT-AND-EARLIER", "ADOPT-CURRENT-MUTATION"]
    candidate = test("candidate", selection["selectors"][0], 0, True)
    candidate["expected_tests"] = {"pass": {name: 1 for name in [*selection["new_tests"], package]}, "fail": {}, "skip": {}}
    adjacent = test("adjacent", selection["selectors"][1], 0, True)
    adjacent["required_root_pass_counts"] = {name: 1 for name in [*selection["adjacent_roots"], package]}
    manifest = {
        "schema": 1, "scope": "current-outcome", "source_directory": "source-pr660",
        "source_head": "a63199628c1689b4b77a50abfc7432396a1893f4",
        "source_tree": "286c1579823bc14fd989ee037119f3826b307ab1",
        "wrapper_sha256": WRAPPER_SHA, "files": files,
        "phases": {
            "prepare": {"overlay_paths": [], "commands": []},
            "control": {"overlay_paths": testpaths, "commands": [control]},
            "candidate": {"overlay_paths": allpaths, "commands": [candidate]},
            "adjacent": {"overlay_paths": allpaths, "commands": [adjacent]},
            "build-vet": {"overlay_paths": allpaths, "commands": [
                {"label": "build", "args": ["build", "-overlay", "{overlay}", "./..."], "expected_exit_code": 0, "timeout_seconds": 300},
                {"label": "vet", "args": ["vet", "-overlay", "{overlay}", "./..."], "expected_exit_code": 0, "timeout_seconds": 300},
            ]},
        },
    }
    raw = (json.dumps(manifest, indent=2) + "\n").encode()
    (dest / "manifest.json").write_bytes(raw)
    print(json.dumps({"manifest_sha256": sha(raw), "formatted_files": len(files), "formatter_exit_code": result.returncode}))

if __name__ == "__main__":
    main()
