"""Offline validation of independent immutable Rust PR snapshots.
Run one selected phase only after Root reviews it. No source edits, installation,
provider calls, scheduler changes or branch integration. Direct-child settlement
is recorded; this runner does not claim a whole-tree timeout or settlement proof.
"""
import sys
sys.dont_write_bytecode = True
import argparse, hashlib, json, os, re, subprocess, time, tomllib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-r23-rust-20261121")
MANIFEST_SHA = "433f1b7767fb592a049ae47ffb175bf8af11a37aebec84c63ca2ec4571c0d4fa"
VENDOR_MANIFESTS = {"windows-sys-0.61.2": "6f86590ab9f4d39d5143a4421cca0640e1d9872854a5776aab81605a8f648c80",
                    "windows-link-0.2.1": "dd164b958275e716e6d14dc3214196139bd524f3f4a9ee808a46164c808c46bf"}
RUST_RESULT = re.compile(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

def verify_source(source):
    base = ROOT / ("source-pr" + str(source["pull_request"]))
    seen = {}
    for row in source["files"]:
        path = base / row["path"]
        raw = path.read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if len(raw) != row["bytes"] or actual != row["git_blob"]:
            raise RuntimeError("Source differs: " + row["path"])
        seen[row["path"]] = hashlib.sha256(raw).hexdigest()
    actual_paths = {p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file()}
    if actual_paths != set(seen):
        raise RuntimeError("Unexpected/missing source files")
    return seen

def verify_dependencies(data, lock):
    missing = []
    for package in tomllib.loads(lock.read_text())["package"]:
        if "source" not in package:
            continue
        root = Path(data["vendor_root"]) / (package["name"] + "-" + package["version"])
        manifest = root / ".cargo-checksum.json"
        if not manifest.is_file():
            missing.append(root.name)
            continue
        if root.name not in VENDOR_MANIFESTS or sha(manifest) != VENDOR_MANIFESTS[root.name]:
            raise RuntimeError("Vendor manifest is not archive-qualified: " + root.name)
        checks = json.loads(manifest.read_bytes())
        if checks["package"] != package["checksum"]:
            raise RuntimeError("Vendor package checksum differs: " + root.name)
        actual = {}
        for p in root.rglob("*"):
            if p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction()):
                raise RuntimeError("Reparse point in dependency")
            if p.is_file() and p.name != ".cargo-checksum.json":
                actual[p.relative_to(root).as_posix()] = sha(p)
        if actual != checks["files"]:
            raise RuntimeError("Vendor file checksums differ: " + root.name)
    if missing:
        raise RuntimeError("Missing qualified offline dependencies: " + ", ".join(missing))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("readiness", "native625", "native644", "ffi631", "reader627"))
    parser.add_argument("--profile", choices=("debug", "release"), default="debug")
    parser.add_argument("--run-id", help="Fresh evidence directory label after a reviewed change")
    args = parser.parse_args()
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or sha(ROOT / "manifest.json") != MANIFEST_SHA:
        raise RuntimeError("Wrong platform, location or manifest")
    os.chdir(ROOT)
    data = json.loads((ROOT / "manifest.json").read_bytes())
    prepared = json.loads((ROOT / "preparation-receipt.json").read_bytes())
    if not prepared["completed"] or prepared["manifest_sha256"] != MANIFEST_SHA:
        raise RuntimeError("Qualified preparation required")
    n = {"readiness": 625, "native625": 625, "native644": 644, "ffi631": 631, "reader627": 627}[args.phase]
    source = next(s for s in data["sources"] if s["pull_request"] == n)
    base = ROOT / ("source-pr" + str(n))
    crate = base / source["subtree"]
    label = args.run_id or (args.phase + "-" + args.profile)
    if not re.fullmatch(r"[a-z0-9-]+", label):
        raise RuntimeError("Invalid evidence label")
    run = ROOT / "runs" / label
    run.mkdir(parents=True, exist_ok=False)
    record = {"schema": 1, "phase": args.phase, "profile": args.profile, "commit": source["commit"],
              "source_role": "exact independent experiment subtree; no integration",
              "started_utc": now(), "runner_sha256": sha(Path(__file__)), "manifest_sha256": MANIFEST_SHA,
              "commands": [], "completed": False, "whole_process_tree_deadline_enforced": False,
              "whole_process_tree_settlement_proven": False, "dependency_downloads": False}
    receipt = run / "receipt.json"
    save(receipt, record)
    failure = None
    rustbin, msvc, sdk = Path(data["rust_bin"]), Path(data["msvc_root"]), Path(data["sdk_root"])
    sdkver = data["sdk_version"]
    tools = {"cargo": rustbin / "cargo.exe", "rustc": rustbin / "rustc.exe", "rustdoc": rustbin / "rustdoc.exe",
             "rustfmt": rustbin / "rustfmt.exe", "link": msvc / "bin/Hostx64/x64/link.exe",
             "go": Path(data["go"]), "gcc": Path(data["gcc"])}
    runtime = run / "runtime"
    for leaf in ("tmp", "profile", "appdata", "localappdata", "cargo-home", "fixtures", "go-cache", "go-mod-cache", "go-path"):
        (runtime / leaf).mkdir(parents=True, exist_ok=False)
    target = ROOT / "targets" / ("pr" + str(n))
    config = '[source.crates-io]\nreplace-with = "qualified-vendor"\n[source.qualified-vendor]\ndirectory = ' + json.dumps(Path(data["vendor_root"]).as_posix()) + '\n[net]\noffline = true\n'
    (runtime / "cargo-home/config.toml").write_text(config, encoding="utf-8")
    allowed = {"SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "SYSTEMDRIVE", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE"}
    env = {k: v for k, v in os.environ.items() if k.upper() in allowed}
    env.update({"PATH": os.pathsep.join(map(str, [rustbin, msvc / "bin/Hostx64/x64", tools["go"].parent, tools["gcc"].parent, Path(os.environ["SystemRoot"]) / "System32"])),
                "CARGO_HOME": str(runtime / "cargo-home"), "CARGO_TARGET_DIR": str(target), "CARGO_NET_OFFLINE": "true",
                "CARGO_INCREMENTAL": "0", "CARGO_BUILD_JOBS": "4", "RUSTC": str(tools["rustc"]), "RUSTDOC": str(tools["rustdoc"]),
                "RUSTUP_AUTO_INSTALL": "0", "RUSTUP_OFFLINE": "1", "RUST_BACKTRACE": "1",
                "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
                "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata"),
                "LIB": os.pathsep.join(map(str, [msvc / "lib/x64", sdk / "Lib" / sdkver / "ucrt/x64", sdk / "Lib" / sdkver / "um/x64"])),
                "INCLUDE": os.pathsep.join(map(str, [msvc / "include", sdk / "Include" / sdkver / "ucrt", sdk / "Include" / sdkver / "shared", sdk / "Include" / sdkver / "um"])),
                "MCPHUB_RX02_PARENT_SENTINEL": "owned-test-parent-only-20261113", "MCPHUB_RX02_FIXTURES": str(runtime / "fixtures"),
                "MCPHUB_RX04_FIXTURES": str(runtime / "fixtures"),
                "MCPHUB_RX02_OWNER_CHILD": str(target / args.profile / "owner_child.exe"),
                "MCPHUB_RX02_FFI_CHILD": str(target / args.profile / "owner_child.exe"),
                "MCPHUB_RX02_FFI_DLL": str(target / args.profile / "mcphub_owner_ffi_spike.dll"),
                "GOROOT": str(tools["go"].parent.parent / "lib/go"), "GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOFLAGS": "-mod=readonly", "GOWORK": "off", "GOTELEMETRY": "off", "GOMAXPROCS": "4",
                "GOCACHE": str(runtime / "go-cache"), "GOMODCACHE": str(runtime / "go-mod-cache"), "GOPATH": str(runtime / "go-path"),
                "GOTMPDIR": str(runtime / "tmp"), "CGO_ENABLED": "1", "CC": str(tools["gcc"]), "PYTHONDONTWRITEBYTECODE": "1"})

    def command(label, argv, cwd=crate, timeout=240, oracle=None):
        row = {"label": label, "command": list(map(str, argv)), "cwd": str(cwd), "started_utc": now(), "settled": False}
        record["commands"].append(row)
        save(receipt, record)
        outpath, errpath = run / (label + ".stdout.log"), run / (label + ".stderr.log")
        started = time.monotonic()
        proc = None
        try:
            with outpath.open("xb") as out, errpath.open("xb") as err:
                proc = subprocess.Popen(argv, cwd=cwd, env=env, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
                row["pid"] = proc.pid
                save(receipt, record)
                try:
                    row["exit_code"] = proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    save(receipt, record)
                    proc.kill()  # Only the continuously retained Popen process handle.
                    row["exit_code"] = proc.wait(timeout=30)
                row["settled"] = True
        except BaseException as error:
            row.update(execution_error_type=type(error).__name__, execution_error=str(error))
            if proc is not None and proc.poll() is None:
                try:
                    proc.kill()  # Retained direct process handle, never a recovered PID.
                    row["exit_code"] = proc.wait(timeout=30)
                    row["settled"] = True
                except BaseException as settlement:
                    row.update(settlement_error_type=type(settlement).__name__, settlement_error=str(settlement))
            raise
        finally:
            row["seconds"] = time.monotonic() - started
            row["finished_utc"] = now()
            row["streams"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha(p)} for p in (outpath, errpath) if p.exists()}
            save(receipt, record)
        if row.get("timed_out") or row.get("exit_code") != 0:
            raise RuntimeError("Command failed; review preserved streams: " + label)
        output = outpath.read_text(encoding="utf-8", errors="strict")
        if oracle == "rust":
            results = [dict(zip(("status", "passed", "failed", "ignored", "measured", "filtered"),
                               [m[0], *map(int, m[1:])])) for m in RUST_RESULT.findall(output)]
            row["rust_suites"] = results
            if not results or sum(r["passed"] for r in results) == 0 or any(r["status"] != "ok" or r["failed"] or r["ignored"] or r["filtered"] for r in results):
                raise RuntimeError("Rust test result incomplete, skipped or failed")
        if oracle == "go":
            events = [json.loads(line) for line in output.splitlines() if line.strip()]
            terminal = [e for e in events if e.get("Action") in ("pass", "fail", "skip")]
            row["go_terminal"] = [{"action": e["Action"], "test": e.get("Test"), "package": e.get("Package")} for e in terminal]
            expected = set()
            for p in cwd.glob("*_test.go"):
                text = p.read_text(encoding="utf-8")
                if text.splitlines()[0].strip() == "//go:build windows && amd64 && cgo":
                    expected.update(re.findall(r"(?m)^func (Test\w+)\(t \*testing\.T\)", text))
            actual = [e["Test"] for e in terminal if e.get("Test") and "/" not in e["Test"] and e["Action"] == "pass"]
            package_pass = [e for e in terminal if not e.get("Test") and e["Action"] == "pass"]
            if not expected or set(actual) != expected or len(actual) != len(expected) or len(package_pass) != 1 or any(e["Action"] != "pass" for e in terminal):
                raise RuntimeError("Go terminal test inventory differs or includes skip/failure")
        row["oracle_matched"] = True
        save(receipt, record)
        return output

    try:
        record["source_before"] = verify_source(source)
        for directory in [ROOT, *ROOT.parents, base, crate, crate / "ffi", crate / "ffi/go"]:
            for leaf in ("config", "config.toml"):
                if (directory / ".cargo" / leaf).exists():
                    raise RuntimeError("Unexpected ancestor/source Cargo config")
        verify_dependencies(data, crate / "Cargo.lock")
        record["tool_hashes_before"] = {name: sha(path) for name, path in tools.items()}
        record["vendor_manifest_hashes_before"] = {a["name"]: sha(Path(data["vendor_root"]) / a["name"] / ".cargo-checksum.json") for a in data["archives"]}
        save(receipt, record)
        if args.phase == "readiness":
            version = command("rustc-version", [tools["rustc"], "--version", "--verbose"], timeout=30)
            if not version.startswith("rustc 1.100.0 "):
                raise RuntimeError("Unexpected Rust version")
            command("cargo-version", [tools["cargo"], "--version"], timeout=30)
            command("rustfmt-version", [tools["rustfmt"], "--version"], timeout=30)
            command("go-version", [tools["go"], "version"], timeout=30)
            command("gcc-target", [tools["gcc"], "-dumpmachine"], timeout=30)
        else:
            release = ["--release"] if args.profile == "release" else []
            if args.phase == "ffi631":
                command("child-build", [tools["cargo"], "build", "--offline", "--locked", *release, "--bin", "owner_child"])
                ffi = crate / "ffi"
                command("ffi-rust-tests", [tools["cargo"], "test", "--offline", "--locked", *release, "--", "--test-threads=1"], ffi, oracle="rust")
                command("ffi-dll-build", [tools["cargo"], "build", "--offline", "--locked", *release], ffi)
                record["ffi_artifacts"] = {p.name: sha(p) for p in (target / args.profile / "owner_child.exe", target / args.profile / "mcphub_owner_ffi_spike.dll")}
                save(receipt, record)
                command("go-consumer-race", [tools["go"], "test", "-json", "-race", "-count=1", "-timeout=120s", "."], ffi / "go", oracle="go")
            else:
                command("native-tests", [tools["cargo"], "test", "--offline", "--locked", *release, "--", "--test-threads=1"], oracle="rust")
        record["source_after"] = verify_source(source)
        verify_dependencies(data, crate / "Cargo.lock")
        record["tool_hashes_after"] = {name: sha(path) for name, path in tools.items()}
        if record["tool_hashes_after"] != record["tool_hashes_before"]:
            raise RuntimeError("Tools changed during validation")
        record["completed"] = True
    except BaseException as error:
        failure = error
        record.update(error_type=type(error).__name__, error=str(error))
    finally:
        record["finished_utc"] = now()
        save(receipt, record)
        print(json.dumps({"phase": args.phase, "completed": record["completed"], "error": record.get("error"), "receipt": str(receipt)}), flush=True)
    if failure:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
