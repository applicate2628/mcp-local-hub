"""Export an explicit, hash-qualified text selection without changing originals.
No tests, compilers, dependency downloads, runtime reads, or subprocesses.
Requires a fresh public directory, archive, and final packaging receipt.
"""
import argparse
import hashlib
import json
import os
import re
import stat
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath, PureWindowsPath

sys.dont_write_bytecode = True
ROOT = Path(r"D:\dev\ChatGPT\mcp-r23-rust-20261121")
SELECTION = ROOT / "public-evidence-selection.json"
RUNS = {"readiness-debug", "readiness-goroot", "native625-debug",
        "native644-debug", "ffi631-debug", "ffi631-go-fixtures"}
ROOT_FILES = {"manifest.json", "preparation-receipt.json", "prepare_sources.py",
              "validate_offline.py", "ffi-go-fixtures-runner.diff",
              "ffi-go-fixtures-review.md", "RESULTS.md", "export_public.py"}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode("utf-8")

def owned_file(relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or ".." in rel.parts or "\\" in relative or str(rel) != relative:
        raise RuntimeError("Noncanonical selection path")
    allowed = (relative in ROOT_FILES or
               relative == "runner-revisions/validate_offline-238e0f3f.py" or
               (len(rel.parts) == 3 and rel.parts[0] == "runs" and rel.parts[1] in RUNS and
                (rel.parts[2] == "receipt.json" or rel.parts[2].endswith((".stdout.log", ".stderr.log")))))
    if not allowed:
        raise RuntimeError("Path outside the explicit public text scope: " + relative)
    path = ROOT
    for part in rel.parts:
        path = path / part
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError("Reparse point in selected path")
    if not path.is_file():
        raise RuntimeError("Selected item is not a regular file")
    return path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection-sha256", required=True)
    args = parser.parse_args()
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Run only the reviewed exporter in its owned Windows directory")
    os.chdir(ROOT)
    selection_bytes = SELECTION.read_bytes()
    if digest(selection_bytes) != args.selection_sha256:
        raise RuntimeError("Selection manifest differs from the reviewed bytes")
    selection = json.loads(selection_bytes)
    originals = {}
    for item in selection["files"]:
        name = item["path"]
        if name in originals:
            raise RuntimeError("Duplicate selected path")
        raw = owned_file(name).read_bytes()
        raw.decode("utf-8", errors="strict")
        if len(raw) != item["bytes"] or digest(raw) != item["sha256"]:
            raise RuntimeError("Selected original differs: " + name)
        originals[name] = raw
    if len(originals) != 47 or selection["selected_file_count"] != 47:
        raise RuntimeError("Reviewed selection must contain exactly 47 original text files")
    required = ROOT_FILES | {"runner-revisions/validate_offline-238e0f3f.py"} | {"runs/" + run + "/receipt.json" for run in RUNS}
    if not required.issubset(originals):
        raise RuntimeError("Required scripts or original receipts are missing")
    stream_names = set()
    for run in sorted(RUNS):
        receipt = json.loads(originals["runs/" + run + "/receipt.json"])
        for command in receipt["commands"]:
            for leaf, expected in command["streams"].items():
                if PurePosixPath(leaf).name != leaf or "\\" in leaf:
                    raise RuntimeError("Invalid command stream path")
                name = "runs/" + run + "/" + leaf
                raw = originals[name]
                if len(raw) != expected["bytes"] or digest(raw) != expected["sha256"]:
                    raise RuntimeError("Original stream disagrees with receipt: " + name)
                stream_names.add(name)
    actual_streams = {name for name in originals if name.endswith((".stdout.log", ".stderr.log"))}
    if stream_names != actual_streams or len(stream_names) != 32:
        raise RuntimeError("Selected stream inventory differs from the 32 original streams")
    original_manifest = json.loads(originals["manifest.json"])
    parts = PureWindowsPath(original_manifest["rust_bin"]).parts
    if len(parts) < 4 or parts[1].lower() != "users":
        raise RuntimeError("Unexpected local tool path; review the public projection")
    prefix = str(PureWindowsPath(*parts[:3]))
    public_prefix = str(PureWindowsPath(parts[0], parts[1], "<local-user>"))
    replacements = [(json.dumps(prefix)[1:-1], json.dumps(public_prefix)[1:-1]),
                    (prefix, public_prefix), (prefix.replace("\\", "/"), public_prefix.replace("\\", "/"))]
    replacements = [(a.encode(), b.encode()) for a, b in replacements]
    originals["public-evidence-selection.json"] = selection_bytes
    outputs = {}
    hashes = []
    for name, raw in sorted(originals.items()):
        public = raw
        replacement_count = 0
        for private_token, public_token in replacements:
            replacement_count += public.count(private_token)
            public = public.replace(private_token, public_token)
        if parts[2].lower().encode("utf-8") in public.lower():
            raise RuntimeError("Local account component remains in selected public text: " + name)
        if re.search(rb"\bS-\d-\d+(?:-\d+){2,}\b", public):
            raise RuntimeError("SID-shaped text requires separate review: " + name)
        outputs[name] = public
        hashes.append({"path": name, "original_bytes": len(raw), "original_sha256": digest(raw),
                       "public_bytes": len(public), "public_sha256": digest(public),
                       "local_account_path_replacements": replacement_count,
                       "original_bytes_equal_public": raw == public})
    boundary = {"schema": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
                "original_selection_sha256": digest(selection_bytes),
                "original_streams_verified": len(stream_names),
                "public_streams_equal_original": sum(outputs[name] == originals[name] for name in stream_names),
                "projection": "Only the local account directory component in selected tool paths is replaced by <local-user>.",
                "excluded": "All runtime, identity marker, binary, target, source-copy, and vendor contents remain unread by this exporter.",
                "whole_process_tree_settlement_proven": False, "files": hashes}
    outputs["PUBLIC-HASHES.json"] = encoded(boundary)
    destination, archive, final_receipt = ROOT / "public-rust", ROOT / "public-rust.zip", ROOT / "public-rust-package-receipt.json"
    if any(p.exists() for p in (destination, archive, final_receipt)):
        raise RuntimeError("Fresh publication destinations are required; no overwrite")
    destination.mkdir()
    for name, raw in outputs.items():
        path = destination.joinpath(*PurePosixPath(name).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(raw)
        if path.read_bytes() != raw:
            raise RuntimeError("Public copy readback differs: " + name)
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, raw in sorted(outputs.items()):
            zipped.writestr(name, raw)
    with zipfile.ZipFile(archive, "r") as zipped:
        if zipped.testzip() is not None or set(zipped.namelist()) != set(outputs) or len(zipped.infolist()) != len(outputs):
            raise RuntimeError("ZIP membership or integrity mismatch")
        for name, raw in outputs.items():
            if zipped.read(name) != raw:
                raise RuntimeError("ZIP entry differs: " + name)
    for name, raw in originals.items():
        path = SELECTION if name == "public-evidence-selection.json" else owned_file(name)
        if path.read_bytes() != raw:
            raise RuntimeError("Original changed during packaging: " + name)
    archive_bytes = archive.read_bytes()
    result = {"schema": 1, "completed": True, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "exporter_sha256": digest(Path(__file__).read_bytes()), "selection_sha256": digest(selection_bytes),
              "payload_files_with_hash_rows": len(hashes), "archive_files": len(outputs),
              "archive_bytes": len(archive_bytes), "archive_sha256": digest(archive_bytes),
              "public_hash_manifest_sha256": digest(outputs["PUBLIC-HASHES.json"]),
              "original_streams_verified": len(stream_names),
              "public_streams_equal_original": boundary["public_streams_equal_original"],
              "changed_public_text_files": sum(not row["original_bytes_equal_public"] for row in hashes),
              "originals_unchanged_after": True, "private_marker_contents_read": False,
              "runtime_contents_read": False, "tests_run": False, "subprocesses_started": False}
    with final_receipt.open("xb") as stream:
        stream.write(encoded(result))
    print(json.dumps(result), flush=True)

if __name__ == "__main__":
    main()
