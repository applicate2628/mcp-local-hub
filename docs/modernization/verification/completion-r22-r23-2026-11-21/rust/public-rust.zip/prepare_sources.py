"""Materialize exact public Rust source blobs and verify existing dependencies.
This preparation executes no repository code, compiler, test or downloaded script.
"""
import sys
sys.dont_write_bytecode = True
import hashlib, json, os, tarfile, urllib.request
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(r"D:\dev\ChatGPT\mcp-r23-rust-20261121")
MANIFEST = ROOT / "manifest.json"

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()

def main():
    if Path(__file__).resolve().parent != ROOT or os.name != "nt":
        raise RuntimeError("Run only the owned R23 preparer on Windows")
    os.chdir(ROOT)
    manifest_bytes = MANIFEST.read_bytes()
    data = json.loads(manifest_bytes)
    receipt = {"schema": 1, "started_utc": datetime.now(timezone.utc).isoformat(),
               "manifest_sha256": digest(manifest_bytes), "script_sha256": digest(Path(__file__).read_bytes()),
               "tests_run": False, "compilers_run": False, "downloads": "public source text only",
               "dependency_downloads": False, "files": [], "archives": [], "completed": False}
    receipt_path = ROOT / "preparation-receipt.json"
    if receipt_path.exists():
        raise RuntimeError("Previous preparation receipt exists; review it before a new scope")
    try:
        for archive in data["archives"]:
            name = archive["name"]
            path = Path(data["archive_root"]) / (name + ".crate")
            raw = path.read_bytes()
            if len(raw) != archive["bytes"] or digest(raw) != archive["sha256"]:
                raise RuntimeError("Existing archive differs: " + name)
            package = Path(data["vendor_root"]) / name
            checks = json.loads((package / ".cargo-checksum.json").read_bytes())
            if checks["package"] != archive["sha256"] or len(checks["files"]) != archive["files"]:
                raise RuntimeError("Vendor checksum manifest differs: " + name)
            with tarfile.open(path, "r:gz") as saved:
                archived = {}
                for member in saved.getmembers():
                    rel = PurePosixPath(member.name)
                    if rel.is_absolute() or ".." in rel.parts or not rel.parts or rel.parts[0] != name:
                        raise RuntimeError("Unexpected archive member")
                    if member.isdir():
                        continue
                    if not member.isfile():
                        raise RuntimeError("Unexpected nonregular archive member")
                    member_data = saved.extractfile(member).read()
                    key = str(PurePosixPath(*rel.parts[1:]))
                    if key in archived:
                        raise RuntimeError("Duplicate archive member")
                    archived[key] = digest(member_data)
            if archived != checks["files"]:
                raise RuntimeError("Archive and checksum manifest differ: " + name)
            actual = {}
            for p in package.rglob("*"):
                if p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction()):
                    raise RuntimeError("Reparse point in vendor")
                if p.is_file() and p.name != ".cargo-checksum.json":
                    actual[p.relative_to(package).as_posix()] = digest(p.read_bytes())
            if actual != archived:
                raise RuntimeError("Vendor bytes differ from pinned archive: " + name)
            receipt["archives"].append({"name": name, "files": len(actual), "sha256": digest(raw)})
        for source in data["sources"]:
            base = ROOT / ("source-pr" + str(source["pull_request"]))
            for f in source["files"]:
                rel = PurePosixPath(f["path"])
                if rel.is_absolute() or ".." in rel.parts:
                    raise RuntimeError("Invalid source path")
                target = base.joinpath(*rel.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    raw = target.read_bytes()
                else:
                    url = "https://raw.githubusercontent.com/" + data["repository"] + "/" + source["commit"] + "/" + f["path"]
                    with urllib.request.urlopen(url, timeout=30) as response:
                        if response.geturl() != url:
                            raise RuntimeError("Unexpected source redirect")
                        raw = response.read(f["bytes"] + 1)
                    if len(raw) != f["bytes"] or git_blob(raw) != f["git_blob"]:
                        raise RuntimeError("Downloaded source does not match Git blob: " + f["path"])
                    with target.open("xb") as output:
                        output.write(raw)
                if len(raw) != f["bytes"] or git_blob(raw) != f["git_blob"]:
                    raise RuntimeError("Existing source differs: " + f["path"])
                receipt["files"].append({"pr": source["pull_request"], "path": f["path"],
                                         "git_blob": f["git_blob"], "sha256": digest(raw), "bytes": len(raw)})
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        with receipt_path.open("x", encoding="utf-8") as output:
            json.dump(receipt, output, indent=2)
            output.write("\n")
        print(json.dumps({k: v for k, v in receipt.items() if k != "files"}), flush=True)

if __name__ == "__main__":
    main()
