# R23: Go consumer fixture correction

## Contents

1. [Observed result](#observed-result)
2. [Cause and minimal correction](#cause-and-minimal-correction)
3. [Environment requirements](#environment-requirements)
4. [Artifact identity and verification](#artifact-identity-and-verification)
5. [Limits](#limits)

## Observed result

The original `ffi631-debug` phase tested exact source commit
`ebfa4ef32b57cfa022acdcfcb4a2745f32b815c6`. It built the owned child, passed
20 Rust foreign function interface (FFI) tests, and built the dynamic-link
library (DLL). The following default Go consumer command exited with code 1:

```text
go test -json -race -count=1 -timeout=120s .
```

Table 1 distinguishes parent test events from leaf cases. The package also
emitted one FAIL event; it is excluded from the test counts.

| Table 1. Original Go result | PASS | FAIL | Total |
| --- | ---: | ---: | ---: |
| Root test functions | 55 | 2 | 57 |
| All test terminal events, including parent groups | 123 | 6 | 129 |
| Leaf cases, excluding any test that is an ancestor of another test | 114 | 4 | 118 |

There were no SKIP terminal events. The four failing leaves were `identity`
and `token-user` under both `TestIdentityQueryPreservesAdmissionAndOwnsCopies`
and `TestIdentityAdmissionObservesOriginalFacts`. Each failed with
`explicit owned identity fixture root required` before creating its child.

## Cause and minimal correction

`ffi/go/identity_windows_test.go` reads `MCPHUB_RX02_IDENTITY_FIXTURES` at
line 22 and rejects its absence at line 24. The runner omitted this variable.
The correction creates `runs/<new-run-id>/runtime/identity-fixtures` on D:
and passes its absolute path through that variable. Private binary security
identifier (SID) observations stay in that owned directory. They are not
printed, copied into the public evidence, or deleted.

A separate `ffi631-go` phase reruns only the existing Go command. It does not
repeat successful Rust tests or builds. It reuses the already built child and
DLL only after matching their exact original hashes, verifies those artifacts
again after Go succeeds, and retains the original source, dependency, and
tool checks. The intended new run identifier is `ffi631-go-fixtures`.

## Environment requirements

All 24 Go files were classified by their actual build constraint. Sixteen
use exactly `windows && amd64 && cgo`: seven implementation files and nine
test files containing 57 root tests. Eight files require extra fault,
legacy, or loader tags and are excluded from this command.

Table 2 lists the external test inputs found in the default selection.

| Table 2. Environment input | Use | Runner value |
| --- | --- | --- |
| `MCPHUB_RX02_FFI_DLL` | `setup`, `bridge_windows_test.go:20` | Exact previously built DLL on D: |
| `MCPHUB_RX02_FFI_CHILD` | `setup`, `bridge_windows_test.go:21` | Exact previously built child on D: |
| `MCPHUB_RX02_IDENTITY_FIXTURES` | `identityFixtureDir`, `identity_windows_test.go:22` | New owned identity-fixtures directory on D: |

`MCPHUB_FFI_FAKE_SENTINEL`, `MCPHUB_ENV_PARENT_SENTINEL`,
`MCPHUB_ENV_EMPTY_SENTINEL`, and `MCPHUB_ENV_CHILD_ID` are set and restored by
the tests themselves through `t.Setenv`; no preexisting value is required.
The runner directs TEMP, TMP, TMPDIR, Go build/cache directories, and profile
directories into its owned D: run directory. `t.TempDir` uses that temporary
location. The excluded tagged tests' scenario environment is not claimed
as covered.

## Artifact identity and verification

The preserved original runner is
`runner-revisions/validate_offline-238e0f3f.py`, SHA-256
`238e0f3f095bdc45719020f8ab8ef3d1990655aa2651576920e1642ca5786896`.
The corrected runner has SHA-256
`07ddb93fdf84514ce69eb48d2046dfc74f059c6b43c89103c02f076ee59636f2`.
Local and Comet copies matched; local Python abstract syntax tree parsing
passed without executing the runner.

The corrected phase pins `runs/ffi631-debug/receipt.json` to SHA-256
`1bef5a11589dc23b104adc47b6d025d83f206e1426dfdaa93739222707cd0c06`.
That receipt retains the original failure, successful preceding commands,
source hashes, tool hashes, and these artifact hashes:

| Table 3. Artifact | SHA-256 |
| --- | --- |
| `owner_child.exe` | `76c833cec0aa40abaf4417929e140c91f91c1a68efcb1428343217eaeba87832` |
| `mcphub_owner_ffi_spike.dll` | `c8d5b1e69e59136ad16d087679110185e558eee79676033ee486d5093af2080c` |

An independent read-only check recomputed all 12 stream hashes and sizes
from native625, native644, and the original ffi631 phase (2 + 2 + 8 streams).
All matched. All 48 source files for #631 after the failed Go command matched
the hashes recorded before execution. Two preliminary read-only hashing
attempts did not qualify this conclusion: `Get-FileHash` was unavailable,
and a helper named `H` resolved to PowerShell's `Get-History` alias. The
successful check used an explicitly named .NET SHA-256 helper with terminating
errors; the source, logs, and receipts were unchanged by all three reads.

## Limits

This review prepares the retry; it does not assert a retry result. The source
is the original `ebfa4ef...` snapshot. Parent's later README-only head
`2eb7c114103ef5c60939cd114110ebe667901166` is not silently substituted.
The wrapper records settlement of continuously owned direct process handles;
it does not prove a deadline or settlement for every descendant process.
No reader627, release profile, extra workloads, installs, policy changes,
branch integration, or external model calls were performed for this correction.
