"""Parse the observer's embedded PowerShell without executing that script."""
import ast
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cim-resolver-20261120")
PROBE_SHA = "c1eb1a4172bf89a308e06c65c0134aed404ae66e54d2b61907676917da4b7cce"
if os.name != "nt" or sys.flags.optimize:
    raise SystemExit("Windows without optimization required")
raw = (ROOT / "probe_cim_resolver_absence.py").read_bytes()
if hashlib.sha256(raw).hexdigest() != PROBE_SHA:
    raise SystemExit("Observer bytes differ from review")
tree = ast.parse(raw.decode("utf-8"))
scripts = [ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "SCRIPT" for target in node.targets)]
if len(scripts) != 1 or not isinstance(scripts[0], str):
    raise SystemExit("Ambiguous embedded script")
encoded = base64.b64encode(scripts[0].encode()).decode("ascii")
parse_script = "$text=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "')); $tokens=$null; $errors=$null; $null=[System.Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors); [Console]::WriteLine(([ordered]@{errors=@($errors).Count;tokens=@($tokens).Count;script_executed=$false}|ConvertTo-Json -Compress))"
env = os.environ.copy()
(ROOT / "parse-runtime").mkdir(exist_ok=False)
for name in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    folder = ROOT / "parse-runtime" / name.lower()
    folder.mkdir(parents=True, exist_ok=False)
    env[name] = str(folder)
env["PSModuleAnalysisCachePath"] = str(ROOT / "parse-runtime/module-cache")
env["PYTHONDONTWRITEBYTECODE"] = "1"
ps = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
env["PSModulePath"] = str(ps.parent / "Modules")
started = time.monotonic()
child = subprocess.run([str(ps), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", parse_script],
                       cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
receipt = {"schema": 1, "observer_sha256": PROBE_SHA, "script_sha256": hashlib.sha256(scripts[0].encode()).hexdigest(),
           "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           "returncode": child.returncode, "seconds": time.monotonic()-started,
           "stdout_bytes": len(child.stdout), "stdout_sha256": hashlib.sha256(child.stdout).hexdigest(),
           "stderr_bytes": len(child.stderr), "stderr_sha256": hashlib.sha256(child.stderr).hexdigest(),
           "script_executed": False, "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "completed": False}
if child.returncode == 0 and not child.stderr:
    result = json.loads(child.stdout.decode("utf-8"))
    if set(result) != {"errors", "tokens", "script_executed"} or type(result["errors"]) is not int or type(result["tokens"]) is not int or result["script_executed"] is not False:
        raise SystemExit("Unexpected parse metadata")
    receipt["result"] = result
    receipt["completed"] = result["errors"] == 0
with (ROOT / "parse-receipt.json").open("x", encoding="utf-8") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if receipt["completed"] else 1)
