"""Observe one new CIM resolver-absence case; never export or alter a task.

The generated literal root leaf exists only in the child process's memory.
COM GetTask before and after must contain HRESULT 0x80070002 in their
exception chains before the observation is admitted. This is not an atomic
absence proof, a hidden/access-denied test, or product execution.

Only a strictly validated metadata receipt is retained. Child streams and
exception messages are never written. A 45-second direct-child deadline and
a bounded post-kill drain do not guarantee settlement of a descendant tree.

Primary sources:
https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/get-scheduledtask?view=windowsserver2016-ps
https://learn.microsoft.com/en-us/windows/win32/api/taskschd/nf-taskschd-itaskfolder-gettask
https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsch/528539ab-2678-4184-9573-cd624916ef9a
https://learn.microsoft.com/en-us/dotnet/api/microsoft.management.infrastructure.cimexception
"""

import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cim-resolver-20261120")
SOURCE_COMMIT = "b7831aabdb7162b3a39c78e73c3ab67558236d1d"
DEADLINE_SECONDS = 45
DRAIN_SECONDS = 5

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'
$InformationPreference = 'SilentlyContinue'
Set-StrictMode -Version Latest
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false, $true)
$receipt = [ordered]@{schema=1; outcome='INCOMPLETE'; phase='module'; completed=$false; classification='UNRESOLVED'; semantic_absence_verdict=$null; atomicity_claim=$false; source_executed=$false; product_changed=$false; task_mutations=@(); selector_kind='generated-literal-root-leaf'}
function Fault-Shape([System.Management.Automation.ErrorRecord]$record) {
  $chain = @()
  $exception = $record.Exception
  for ($depth=0; $null -ne $exception -and $depth -lt 8; $depth++) {
    $row = [ordered]@{type=$exception.GetType().FullName; hresult=[uint32]([int64]$exception.HResult -band 0xffffffffL)}
    if ($exception -is [Microsoft.Management.Infrastructure.CimException]) {
      $row.native_error_code = [int64]$exception.NativeErrorCode
      $row.status_code = [int64]$exception.StatusCode
      $data = $exception.ErrorData
      if ($null -ne $data) {
        $row.cim_error_class = [string]$data.CimClass.CimClassName
        $numbers = [ordered]@{}
        foreach ($key in @('CIMStatusCode', 'error_Category', 'error_Code')) {
          $property = $data.CimInstanceProperties[$key]
          if ($null -ne $property -and $null -ne $property.Value) {
            $value = $property.Value
            if ($value -is [byte] -or $value -is [sbyte] -or $value -is [int16] -or $value -is [uint16] -or $value -is [int32] -or $value -is [uint32]) {
              $numbers[$key] = [uint32]([int64]$value -band 0xffffffffL)
            }
          }
        }
        $row.cim_error_numbers = $numbers
      }
    }
    $chain += $row
    $exception = $exception.InnerException
  }
  return [ordered]@{error_category=[int]$record.CategoryInfo.Category; chain=$chain; chain_truncated=($null -ne $exception)}
}
function Read-Absence($folder, [string]$leaf) {
  try {
    $object = $folder.GetTask($leaf)
    if ($null -eq $object) { return [ordered]@{outcome='NULL_RETURNED'} }
    return [ordered]@{outcome='OBJECT_RETURNED'}
  } catch {
    $fault = Fault-Shape $_
    $missing = @($fault.chain | Where-Object { $_.hresult -eq 2147942402 }).Count -gt 0
    return [ordered]@{outcome=$(if ($missing) { 'MISSING_HRESULT_OBSERVED' } else { 'UNKNOWN_ERROR' }); fault=$fault}
  }
}
try {
  if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'Unexpected PowerShell version' }
  $modulePath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\Modules\ScheduledTasks\ScheduledTasks.psd1'
  $modules = @(Import-Module -Name $modulePath -PassThru -ErrorAction Stop)
  if ($modules.Count -ne 1 -or $modules[0].Name -cne 'ScheduledTasks' -or $modules[0].Version.ToString() -cne '1.0.0.0') { throw 'Unexpected ScheduledTasks module' }
  $get = @(Get-Command -Name Get-ScheduledTask -Module ScheduledTasks -ErrorAction Stop)
  if ($get.Count -ne 1) { throw 'Ambiguous resolver command' }
  $receipt.powershell_version = $PSVersionTable.PSVersion.ToString()
  $receipt.module_version = $modules[0].Version.ToString()
  $receipt.phase = 'connect'
  $service = New-Object -ComObject Schedule.Service
  $service.Connect()
  $folder = $service.GetFolder('\')
  # No wildcard characters, path separators, or caller-provided source text.
  $leaf = 'mcphub-readonly-absence-' + [Guid]::NewGuid().ToString('N')
  $receipt.phase = 'com-before'
  $receipt.before = Read-Absence $folder $leaf
  if ($receipt.before.outcome -ceq 'MISSING_HRESULT_OBSERVED') {
    $receipt.phase = 'resolver'
    try {
      $values = @(& $get[0] -TaskName $leaf -TaskPath '\' -ErrorAction Stop)
      $types = @($values | Select-Object -First 4 | ForEach-Object { $_.GetType().FullName } | Select-Object -Unique)
      $receipt.resolver = [ordered]@{outcome='SUCCESS'; output_count=$values.Count; output_types=$types}
    } catch {
      # A terminating error does not provide a reliable success-stream count.
      $receipt.resolver = [ordered]@{outcome='ERROR'; fault=(Fault-Shape $_)}
    }
    $receipt.phase = 'com-after'
    $receipt.after = Read-Absence $folder $leaf
    if ($receipt.after.outcome -ceq 'MISSING_HRESULT_OBSERVED') {
      $receipt.classification = if ($receipt.resolver.outcome -ceq 'ERROR') { 'ERROR_OBSERVED' } elseif ($receipt.resolver.output_count -eq 0) { 'EMPTY_SUCCESS' } else { 'NONEMPTY_SUCCESS' }
      $receipt.completed = $true
      $receipt.outcome = 'RESOLVER_OBSERVATION_COMPLETE'
    } else {
      $receipt.outcome = 'CONTROL_NOT_ADMITTED'
    }
  } else {
    $receipt.outcome = 'CONTROL_NOT_ADMITTED'
  }
} catch {
  $receipt.error = Fault-Shape $_
} finally {
  # These COM references are owned only by this short-lived child process.
  [Console]::WriteLine(($receipt | ConvertTo-Json -Depth 12 -Compress))
}
"""


def exact_keys(value, required, optional=()):
    if not isinstance(value, dict) or not set(required) <= set(value) or set(value) - set(required) - set(optional):
        raise ValueError("Invalid metadata object")


def integer(value, maximum=0xFFFFFFFF):
    if type(value) is not int or not 0 <= value <= maximum:
        raise ValueError("Invalid metadata integer")


def type_name(value):
    if not isinstance(value, str) or not re.fullmatch(r"(?:System|Microsoft)\.[A-Za-z0-9_.+`]{1,240}", value):
        raise ValueError("Invalid type metadata")


def check_fault(value):
    exact_keys(value, {"error_category", "chain", "chain_truncated"})
    integer(value["error_category"], 255)
    if type(value["chain_truncated"]) is not bool or not isinstance(value["chain"], list) or not 1 <= len(value["chain"]) <= 8:
        raise ValueError("Invalid exception chain")
    for item in value["chain"]:
        exact_keys(item, {"type", "hresult"}, {"native_error_code", "status_code", "cim_error_class", "cim_error_numbers"})
        type_name(item["type"])
        integer(item["hresult"])
        for key in ("native_error_code", "status_code"):
            if key in item:
                integer(item[key])
        if "cim_error_class" in item and (not isinstance(item["cim_error_class"], str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,127}", item["cim_error_class"])):
            raise ValueError("Invalid CIM type metadata")
        if "cim_error_numbers" in item:
            exact_keys(item["cim_error_numbers"], set(), {"CIMStatusCode", "error_Category", "error_Code"})
            for number in item["cim_error_numbers"].values():
                integer(number)


def check_control(value):
    exact_keys(value, {"outcome"}, {"fault"})
    if value["outcome"] in {"MISSING_HRESULT_OBSERVED", "UNKNOWN_ERROR"}:
        check_fault(value.get("fault"))
        missing = any(row["hresult"] == 0x80070002 for row in value["fault"]["chain"])
        if missing != (value["outcome"] == "MISSING_HRESULT_OBSERVED"):
            raise ValueError("Inconsistent absence control")
    elif value["outcome"] not in {"NULL_RETURNED", "OBJECT_RETURNED"} or "fault" in value:
        raise ValueError("Invalid absence control")


def check_result(value):
    fixed = {"schema", "outcome", "phase", "completed", "classification", "semantic_absence_verdict", "atomicity_claim", "source_executed", "product_changed", "task_mutations", "selector_kind"}
    exact_keys(value, fixed, {"powershell_version", "module_version", "before", "resolver", "after", "error"})
    if type(value["schema"]) is not int or value["schema"] != 1 or value["selector_kind"] != "generated-literal-root-leaf":
        raise ValueError("Invalid metadata schema")
    if value["outcome"] not in {"INCOMPLETE", "CONTROL_NOT_ADMITTED", "RESOLVER_OBSERVATION_COMPLETE"} or value["phase"] not in {"module", "connect", "com-before", "resolver", "com-after"}:
        raise ValueError("Invalid outcome metadata")
    if value["classification"] not in {"UNRESOLVED", "ERROR_OBSERVED", "EMPTY_SUCCESS", "NONEMPTY_SUCCESS"}:
        raise ValueError("Invalid classification metadata")
    if value["semantic_absence_verdict"] is not None or value["task_mutations"] != []:
        raise ValueError("Unexpected assertion")
    if type(value["completed"]) is not bool or any(value[key] is not False for key in ("atomicity_claim", "source_executed", "product_changed")):
        raise ValueError("Unexpected assertion")
    for key in ("powershell_version", "module_version"):
        if key in value and (not isinstance(value[key], str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}", value[key])):
            raise ValueError("Invalid version metadata")
    for key in ("before", "after"):
        if key in value:
            check_control(value[key])
    if "error" in value:
        check_fault(value["error"])
    if "resolver" in value:
        resolver = value["resolver"]
        if resolver.get("outcome") == "SUCCESS":
            exact_keys(resolver, {"outcome", "output_count", "output_types"})
            integer(resolver["output_count"], 1000000)
            if not isinstance(resolver["output_types"], list) or len(resolver["output_types"]) > 4:
                raise ValueError("Invalid output types")
            for name in resolver["output_types"]:
                type_name(name)
        elif resolver.get("outcome") == "ERROR":
            exact_keys(resolver, {"outcome", "fault"})
            check_fault(resolver["fault"])
        else:
            raise ValueError("Invalid resolver observation")
    if value["completed"]:
        if value["outcome"] != "RESOLVER_OBSERVATION_COMPLETE" or "error" in value or "resolver" not in value or any(value.get(key, {}).get("outcome") != "MISSING_HRESULT_OBSERVED" for key in ("before", "after")):
            raise ValueError("Incomplete observation claimed complete")
        resolver = value["resolver"]
        classification = "ERROR_OBSERVED" if resolver["outcome"] == "ERROR" else "EMPTY_SUCCESS" if resolver["output_count"] == 0 else "NONEMPTY_SUCCESS"
        if value["classification"] != classification:
            raise ValueError("Inconsistent classification")
    return value


def main():
    if os.name != "nt" or sys.flags.optimize:
        raise SystemExit("Windows without Python optimization is required")
    if ROOT.resolve(strict=True) != ROOT or (ROOT / "receipt.json").exists():
        raise SystemExit("A fresh fixed D-drive work root is required")
    for folder in (ROOT, *ROOT.parents):
        info = folder.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise SystemExit("Reparse or non-directory work ancestor rejected")
    env = os.environ.copy()
    (ROOT / "runtime").mkdir(exist_ok=False)
    for key in ("TEMP", "TMP", "TMPDIR", "USERPROFILE", "APPDATA", "LOCALAPPDATA"):
        folder = ROOT / "runtime" / key.lower()
        folder.mkdir(parents=True, exist_ok=False)
        env[key] = str(folder)
    env["PSModuleAnalysisCachePath"] = str(ROOT / "runtime" / "ps-module-cache")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    ps = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    if not ps.is_absolute() or not ps.is_file():
        raise SystemExit("A qualified installed PowerShell executable is required")
    env["PSModulePath"] = str(ps.parent / "Modules")
    utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
    digest = lambda data: hashlib.sha256(data).hexdigest()
    receipt = {
        "schema": 1, "started_utc": utc(), "runner_sha256": digest(Path(__file__).read_bytes()),
        "powershell_script_sha256": digest(SCRIPT.encode()), "powershell_sha256": digest(ps.read_bytes()),
        "source_commit": SOURCE_COMMIT, "source_executed": False, "product_changed": False,
        "task_mutations": [], "filesystem_acl_writes": 0,
        "raw_task_identifiers_retained": False, "raw_definitions_retained": False,
        "raw_error_streams_retained": False, "actual_product_consumer_exercised": False,
        "direct_child_deadline_seconds": DEADLINE_SECONDS, "post_kill_drain_seconds": DRAIN_SECONDS,
        "whole_process_tree_deadline_enforced": False, "completed": False, "outcome": "INCOMPLETE",
    }
    started = time.monotonic()
    child = None
    stdout = stderr = b""
    try:
        child = subprocess.Popen([str(ps), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", SCRIPT],
                                 cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        receipt["pid"] = child.pid
        try:
            stdout, stderr = child.communicate(timeout=DEADLINE_SECONDS)
            receipt["streams_complete"] = True
        except subprocess.TimeoutExpired:
            receipt["timed_out"] = True
            child.kill()
            try:
                stdout, stderr = child.communicate(timeout=DRAIN_SECONDS)
                receipt["streams_complete"] = True
            except subprocess.TimeoutExpired as timeout:
                stdout, stderr = timeout.output or b"", timeout.stderr or b""
                receipt["streams_complete"] = False
                child.wait(timeout=1)
        receipt["returncode"] = child.returncode
        receipt["direct_child_settled"] = child.returncode is not None
        for name, data in (("stdout", stdout), ("stderr", stderr)):
            receipt[name] = {"bytes": len(data), "sha256": digest(data)}
        if child.returncode == 0 and not stderr and not receipt.get("timed_out") and len(stdout) <= 65536:
            result = check_result(json.loads(stdout.decode("utf-8", errors="strict")))
            receipt["result"] = result
            receipt["completed"] = result["completed"]
            receipt["outcome"] = result["outcome"]
        else:
            receipt["outcome"] = "PROCESS_OR_PROTOCOL_FAILURE"
    except Exception as error:
        receipt["outcome"] = "RUNNER_OR_PROTOCOL_FAILURE"
        receipt["error_type"] = type(error).__name__
    finally:
        if child is not None:
            if child.poll() is None:
                receipt["cleanup_termination_requested"] = True
                try:
                    child.kill()
                    child.wait(timeout=DRAIN_SECONDS)
                except Exception as cleanup_error:
                    receipt["cleanup_error_type"] = type(cleanup_error).__name__
            receipt["direct_child_settled"] = child.poll() is not None
            receipt["returncode"] = child.returncode
            if receipt.get("streams_complete"):
                for pipe in (child.stdout, child.stderr):
                    if pipe is not None:
                        pipe.close()
            else:
                # A Windows communicate reader thread can hold the pipe's
                # buffered-reader lock. Closing it here could wait forever.
                # This standalone runner exits immediately after the receipt.
                receipt["pipe_close_deferred_to_runner_exit"] = True
        receipt.update(seconds=time.monotonic() - started, finished_utc=utc())
        with (ROOT / "receipt.json").open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(json.dumps(receipt), flush=True)
    return 0 if receipt["completed"] else 1


if __name__ == "__main__":
    try:
        result_code = main()
    except Exception as preparation_error:
        print(json.dumps({"schema": 1, "outcome": "PREPARATION_OR_RECEIPT_FAILURE", "error_type": type(preparation_error).__name__, "source_executed": False}), flush=True)
        result_code = 1
    raise SystemExit(result_code)
