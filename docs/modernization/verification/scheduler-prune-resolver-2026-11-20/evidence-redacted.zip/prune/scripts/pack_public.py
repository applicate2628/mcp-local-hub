"""Freeze and verify the bounded prune/resolver evidence before public export."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(r"<WORK_ROOT>\mcp-r17-prune-snapshot-20261120")
NATIVE = Path(r"<WORK_ROOT>\mcp-r17-cim-resolver-20261120")
OUT = ROOT / "public-evidence"
BASE = "b7831aabdb7162b3a39c78e73c3ab67558236d1d"
COMMIT = "f5fb00370a833255eacb992a7cd32f2e68da7399"
TREE = "91ea0a635cbeeae0849b328c2b6064d48f95bdfc"
digest = lambda data: hashlib.sha256(data).hexdigest()
jsonbytes = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
phases = ("control", "candidate", "focused", "build-vet", "published-checkout", "published")
items = [("prune/scripts/" + name, ROOT / name) for name in ("check_prune.py", "checkout_published.py", "pack_public.py")]
items.extend(("prune/inputs/" + name, ROOT / name) for name in ("hashes.json", "candidate.patch", "negative-control.patch", "product.patch"))
for phase in phases:
    for path in sorted((ROOT / "evidence" / phase).iterdir()):
        if path.suffix not in {".json", ".log"} or not path.is_file():
            raise RuntimeError("Unexpected evidence member")
        items.append(("prune/" + phase + "/" + path.name, path))
items.extend(("resolver/" + name, NATIVE / name) for name in ("probe_cim_resolver_absence.py", "parse_resolver_probe.py", "parse-receipt.json", "receipt.json"))
originals = {path: path.read_bytes() for _, path in items}
receipts = {phase: json.loads(originals[ROOT / "evidence" / phase / "receipt.json"]) for phase in phases}
if not all(receipt["completed"] for receipt in receipts.values()) or not receipts["control"]["negative_control_confirmed"]:
    raise RuntimeError("Unexpected phase completion")
published = receipts["published"]
if published["base"] != BASE or published["source_head"] != COMMIT or published["source_tree"] != TREE or published["working_status"]:
    raise RuntimeError("Published source is not exact and clean")
checkout = receipts["published-checkout"]
if (checkout["head"], checkout["tree"], checkout["parents"], checkout["status"]) != (COMMIT, TREE, BASE, ""):
    raise RuntimeError("Published checkout identity mismatch")
source_manifest = json.loads(originals[ROOT / "hashes.json"])
source_hashes = {item["path"]: item["candidate_sha256"] for item in source_manifest["files"]}
if published["source_sha256_before"] != source_hashes or published["source_sha256_after"] != source_hashes:
    raise RuntimeError("Published candidate source differs")

commands = []
raw_streams_verified = 0
for phase, receipt in receipts.items():
    for command in receipt["commands"]:
        if not command.get("settled", command.get("direct_child_settled", False)):
            raise RuntimeError("Unsettled command")
        for stream in ("stdout", "stderr"):
            raw = originals[ROOT / "evidence" / phase / (command["label"] + "." + stream + ".log")]
            if {"bytes": len(raw), "sha256": digest(raw)} != command[stream]:
                raise RuntimeError("Original stream digest mismatch")
            raw_streams_verified += 1
        tests = command.get("tests")
        if tests is not None:
            events = [json.loads(line) for line in originals[ROOT / "evidence" / phase / (command["label"] + ".stdout.log")].decode("utf-8").splitlines()]
            actual = {action: [event.get("Test", "PACKAGE:" + event.get("Package", "")) for event in events if event.get("Action") == action] for action in ("pass", "fail", "skip")}
            if actual != tests:
                raise RuntimeError("Test events differ from receipt")
        control = phase == "control" and command["label"] == "original-prune-control"
        if command["exit_code"] != (1 if control else 0):
            raise RuntimeError("Unexpected command result")
        if control:
            name = "TestPruneObsoleteServerTasks_SkipsUnavailableSnapshot"
            expected = [name + "/" + suffix for suffix in ("export_error", "bytes_with_error", "not_found_after_list", "nil_snapshot", "empty_snapshot")] + [name, "PACKAGE:mcp-local-hub/internal/api"]
            if tests["fail"] != expected or tests["pass"] or tests["skip"]:
                raise RuntimeError("Unexpected negative control events")
            for test in expected[:-2]:
                output = "".join(event.get("Output", "") for event in events if event.get("Test") == test)
                if "Delete calls = [mcp-local-hub-s-unavailable mcp-local-hub-s-zobsolete]" not in output:
                    raise RuntimeError("Negative control cause mismatch")
        elif tests and (tests["fail"] or tests["skip"]):
            raise RuntimeError("Unexpected positive test failure or skip")
        row = {key: command[key] for key in ("label", "args", "exit_code", "seconds", "stdout", "stderr")}
        row["phase"] = phase
        if tests is not None:
            row["events"] = {action: {"test": sum(not name.startswith("PACKAGE:") for name in tests[action]), "package": sum(name.startswith("PACKAGE:") for name in tests[action])} for action in tests}
        commands.append(row)

native = json.loads(originals[NATIVE / "receipt.json"])
parser = json.loads(originals[NATIVE / "parse-receipt.json"])
script_sha = digest(originals[NATIVE / "probe_cim_resolver_absence.py"])
if script_sha != native["runner_sha256"] or script_sha != parser["observer_sha256"] or native["powershell_script_sha256"] != parser["script_sha256"]:
    raise RuntimeError("Native observer identity mismatch")
if not parser["completed"] or parser["result"]["errors"] != 0 or parser["script_executed"]:
    raise RuntimeError("Observer parser result not admitted")
if not native["completed"] or not native["direct_child_settled"] or not native["streams_complete"] or native["returncode"] != 0 or native["stderr"]["bytes"] != 0:
    raise RuntimeError("Native result not complete")
result = native["result"]
if result["classification"] != "ERROR_OBSERVED" or result["semantic_absence_verdict"] is not None or result["atomicity_claim"]:
    raise RuntimeError("Unexpected native classification")
for name in ("before", "after"):
    if result[name]["outcome"] != "MISSING_HRESULT_OBSERVED" or not any(row["hresult"] == 0x80070002 for row in result[name]["fault"]["chain"]):
        raise RuntimeError("Missing COM control")
if native["task_mutations"] or native["filesystem_acl_writes"] or native["source_executed"] or native["actual_product_consumer_exercised"]:
    raise RuntimeError("Unexpected native scope")

summary = {"schema": 1, "code_commit": COMMIT, "code_tree": TREE, "parent": BASE,
           "candidate_identity": "parent tree plus three exact source hashes, verified against the full published tree",
           "source_sha256": source_hashes, "commands": commands, "native": native, "native_parser": parser,
           "negative_control_confirmed": True, "negative_control_rerun": False,
           "raw_command_streams_verified": raw_streams_verified, "raw_native_streams_retained": False,
           "full_gates": {"untagged": {"status": "NOT_RUN", "reason": "D-only state isolation is unqualified on this branch; four TestMain fences remain in separate PR658"},
                          "tagged_api_cli": {"status": "NOT_RUN", "reason": "Has state isolation; known unqualified Product/entrypoint inputs and historical blockers remain. The changed prune/ownership contracts were selected directly."}},
           "historical_full_97216816": {"untagged_status": "FAIL", "untagged_seconds": 400.641, "tagged_api_cli_status": "FAIL", "tagged_api_cli_seconds": 322.436},
           "whole_process_tree_deadline_enforced": False, "native_task_mutations": [],
           "native_product_prune_exercised": False, "product_export_changed": False, "general_absence_classifier_qualified": False,
           "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat()}

private_tokens = [os.environ.get(name, "") for name in ("USERNAME", "USERDOMAIN", "COMPUTERNAME")]
private_tokens = sorted({token for token in private_tokens if len(token) >= 3 and token.lower() not in {"system", "user", "windows", "builtin"}}, key=len, reverse=True)


def redact(raw):
    value = raw.decode("utf-8")
    value = re.sub(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT", "<WORK_ROOT>", value)
    value = re.sub(r"(?i)C:[\\/]{1,4}Users[\\/]{1,4}[^\\/\s\"]+", "<USER_PROFILE>", value)
    value = re.sub(r"(?i)S-1-5-21-(?:\d+-){2,}\d+", "<USER_SID>", value)
    for token in private_tokens:
        value = re.sub(re.escape(token), "<LOCAL_IDENTITY>", value, flags=re.I)
    if re.search(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT|C:[\\/]{1,4}Users[\\/]{1,4}|S-1-5-21-(?:\d+-){2,}\d+", value):
        raise RuntimeError("Unredacted private marker")
    return value.encode("utf-8")


members = {}
manifest = {"schema": 1, "redaction": "Work roots, user profiles, local identities and personal SIDs are replaced. Original and saved hashes are distinct. Redacted scripts are audit records, not directly runnable inputs.", "files": []}
for name, path in items:
    raw = originals[path]
    saved = redact(raw)
    if path.read_bytes() != raw or name in members:
        raise RuntimeError("Source changed during packaging or duplicate member")
    if name.endswith(".json"):
        json.loads(saved)
    members[name] = saved
    manifest["files"].append({"path": name, "source_bytes": len(raw), "source_sha256": digest(raw), "saved_bytes": len(saved), "saved_sha256": digest(saved), "redacted": saved != raw})
for name, raw in (("execution-summary.json", redact(jsonbytes(summary))), ("source-identities.json", jsonbytes({"commit": COMMIT, "tree": TREE, "files_sha256": source_hashes}))):
    json.loads(raw)
    members[name] = raw
    manifest["files"].append({"path": name, "source_bytes": len(raw), "source_sha256": digest(raw), "saved_bytes": len(raw), "saved_sha256": digest(raw), "redacted": False, "generated_public_record": True})
members["MANIFEST.json"] = jsonbytes(manifest)
OUT.mkdir(exist_ok=False)
archive = OUT / "evidence-redacted.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for name, data in sorted(members.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026, 11, 20, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o600 << 16
        handle.writestr(entry, data)
with zipfile.ZipFile(archive) as handle:
    if handle.testzip() is not None or set(handle.namelist()) != set(members):
        raise RuntimeError("Archive integrity mismatch")
    for row in manifest["files"]:
        raw = handle.read(row["path"])
        if digest(raw) != row["saved_sha256"] or len(raw) != row["saved_bytes"]:
            raise RuntimeError("Manifest member mismatch")
raw = archive.read_bytes()
metadata = {"schema": 1, "archive": archive.name, "bytes": len(raw), "sha256": digest(raw),
            "entries": len(members), "manifest_files": len(manifest["files"]), "raw_command_streams_verified": raw_streams_verified,
            "original_hashes_distinct_from_saved_hashes": True, "crc_and_manifest_verified": True}
for name, raw in (("execution-summary.json", members["execution-summary.json"]), ("MANIFEST.json", members["MANIFEST.json"]), ("archive-metadata.json", jsonbytes(metadata))):
    with (OUT / name).open("xb") as stream:
        stream.write(raw)
print(json.dumps(metadata), flush=True)
