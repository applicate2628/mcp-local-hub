"""Select the published single-parent snapshot; never merge or reset a branch."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"<WORK_ROOT>\mcp-r17-prune-snapshot-20261120")
SOURCE = ROOT / "source"
BASE = "b7831aabdb7162b3a39c78e73c3ab67558236d1d"
TREE = "91ea0a635cbeeae0849b328c2b6064d48f95bdfc"
GIT = r"C:\Program Files\Git\cmd\git.exe"
expected = sys.argv[1]
if os.name != "nt" or sys.flags.optimize or len(expected) != 40 or any(c not in "0123456789abcdef" for c in expected):
    raise SystemExit("Invalid invocation")
files = json.loads((ROOT / "hashes.json").read_text(encoding="utf-8"))["files"]
paths = [f["path"] for f in files]
if set(paths) != {"internal/api/install.go", "internal/api/prune_tasks_test.go", "internal/api/install_hyphen_family_ownership_test.go"} or len(paths) != 3:
    raise SystemExit("Unexpected source manifest")
runtime = ROOT / "runtime/published-checkout"
out = ROOT / "evidence/published-checkout"
out.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_") and k.upper() != "SSH_ASKPASS"}
for key in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP"):
    folder = runtime / key.lower()
    folder.mkdir(parents=True, exist_ok=False)
    env[key] = str(folder)
hooks = runtime / "empty-hooks"
hooks.mkdir()
env.update(GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never", GIT_CONFIG_NOSYSTEM="1",
           GIT_CONFIG_GLOBAL=str(runtime / "no-global-config"), PYTHONDONTWRITEBYTECODE="1")
prefix = [GIT, "-c", "core.hooksPath=" + str(hooks), "-c", "credential.helper=", "-c", "core.askPass=", "-C", str(SOURCE)]
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
digest = lambda b: hashlib.sha256(b).hexdigest()
receipt = {"schema": 1, "base": BASE, "expected_commit": expected, "expected_tree": TREE,
           "started_utc": utc(), "runner_sha256": digest(Path(__file__).read_bytes()),
           "completed": False, "commands": [], "whole_process_tree_deadline_enforced": False}

def git(*args):
    return subprocess.check_output(prefix + list(args), env=env, cwd=SOURCE, stdin=subprocess.DEVNULL, timeout=60).decode("utf-8").strip()

def hashes():
    value = {p: digest((SOURCE / p).read_bytes()) for p in paths}
    if value != {f["path"]: f["candidate_sha256"] for f in files}:
        raise RuntimeError("Source bytes changed")
    return value

def run(label, args):
    row = {"label": label, "args": args, "started_utc": utc()}
    receipt["commands"].append(row)
    started = time.monotonic()
    with (out / (label + ".stdout.log")).open("xb") as fo, (out / (label + ".stderr.log")).open("xb") as fe:
        with subprocess.Popen(prefix + args, cwd=SOURCE, env=env, stdin=subprocess.DEVNULL, stdout=fo, stderr=fe) as child:
            row["pid"] = child.pid
            row["exit_code"] = child.wait()
            row["direct_child_settled"] = True
    row.update(seconds=time.monotonic()-started, finished_utc=utc())
    for name in ("stdout", "stderr"):
        raw = (out / (label + "." + name + ".log")).read_bytes()
        row[name] = {"bytes": len(raw), "sha256": digest(raw)}
    if row["exit_code"]:
        raise RuntimeError(label + " failed")

try:
    if git("rev-parse", "HEAD") != BASE or git("diff", "--cached", "--name-only"):
        raise RuntimeError("Unexpected head or staged changes")
    expected_status = {"M " + path for path in paths}
    status = git("status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching")
    if {line.strip() for line in status.splitlines()} != expected_status:
        raise RuntimeError("Unexpected source status")
    receipt["source_sha256_before"] = hashes()
    run("stage-exact-files", ["add", "--"] + paths)
    if git("write-tree") != TREE:
        raise RuntimeError("Staged tree differs from GitHub candidate")
    run("fetch-exact-commit", ["fetch", "--no-tags", "https://github.com/applicate2628/mcp-local-hub.git", expected])
    if git("show", "-s", "--format=%P", expected) != BASE or git("rev-parse", expected + "^{tree}") != TREE:
        raise RuntimeError("Unexpected published ancestry or tree")
    run("checkout-detached", ["checkout", "--detach", expected])
    receipt.update(head=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"),
                   parents=git("show", "-s", "--format=%P", "HEAD"),
                   status=git("status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"),
                   source_sha256_after=hashes())
    if receipt["head"] != expected or receipt["tree"] != TREE or receipt["parents"] != BASE or receipt["status"]:
        raise RuntimeError("Published checkout is not exact and clean")
    receipt["completed"] = True
finally:
    receipt["finished_utc"] = utc()
    with (out / "receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt), flush=True)
