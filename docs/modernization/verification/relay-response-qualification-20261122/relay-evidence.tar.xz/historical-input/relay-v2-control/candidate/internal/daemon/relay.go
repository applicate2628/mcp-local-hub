package daemon

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"
)

// HTTPToStdioRelay forwards JSON-RPC messages between a stdio MCP client
// (reads stdin, writes stdout) and an HTTP MCP endpoint using Streamable
// HTTP transport.
//
// Motivation: Antigravity's Cascade agent (and similar stdio-only MCP
// clients) cannot connect to loopback HTTP daemons directly. Relay runs
// as a lightweight subprocess spawned by the client and translates
// between the two transports so the client transparently benefits from
// a shared HTTP daemon.
//
// Protocol reference: docs/superpowers/plans/2026-04-17-post-phase-1-antigravity-relay.md
// § "Protocol notes".
type HTTPToStdioRelay struct {
	URL    string    // e.g. "http://localhost:9121/mcp"
	Stdin  io.Reader // usually os.Stdin
	Stdout io.Writer // usually os.Stdout
	Stderr io.Writer // usually os.Stderr (logging only; never echoed to client)

	// InterruptStdin is an explicit capability granted by the input owner.
	// Nil keeps the existing borrowed-input contract. When set, cancellation
	// may call it once while the input pump is active, concurrently with Read.
	// It must make current/future reads terminate and must itself finish; Run
	// joins both operations. Return an error if interruption/cleanup failed.
	// Run never infers permission from io.Closer and never closes Stdout.
	// Expected interrupted reads should return EOF or context.Canceled;
	// unrelated read errors and this callback's error remain observable.
	InterruptStdin func() error

	// HTTPClient is optional; a sensible default is used if nil.
	HTTPClient *http.Client

	// sessionID is minted by the server on the first POST response
	// (InitializeResult) and echoed on every subsequent request.
	sessionMu       sync.Mutex
	sessionID       string // "" until minted
	qualificationMu sync.Mutex
	qualification   *mcpHTTPQualificationOwner

	// stdoutMu owns complete frame writes and the first output failure.
	// Once a frame fails, every producer must stop using this stream.
	stdoutMu     sync.Mutex
	stdoutErr    error
	stdoutCancel context.CancelFunc // this Run's network/dispatch context only
}

// jsonrpcMeta captures the three fields relay needs to route/synthesize
// without decoding the full MCP payload. Everything else flows through
// as raw bytes.
type jsonrpcMeta struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`     // may be number, string, or null
	Method  string          `json:"method,omitempty"` // empty for responses
}

const (
	mcpSessionIDHeader = "MCP-Session-Id"
	lastEventIDHeader  = "Last-Event-ID"

	// Default HTTP timeout matches what Claude Code uses against our
	// Serena daemon (60 s total). Individual SSE streams are read
	// without a body-read deadline — only the overall connection
	// inherits the HTTPClient's timeout when set to 0 here.
	defaultHTTPTimeoutSec = 60

	// Max line the relay accepts from stdin. MCP messages are typically
	// KB-sized; 1 MiB is a generous ceiling that catches runaway inputs
	// without rejecting any real MCP payload.
	maxStdinLineBytes = 1 << 20 // 1 MiB

	// Upper bound on concurrent POST workers spawned from stdinPump after
	// session establishment. Provides backpressure against untrusted or
	// buggy stdio clients that can otherwise enqueue unbounded work.
	maxConcurrentPOSTs = 64
)

var errStdinLineTooLong = errors.New("stdin line exceeds maxStdinLineBytes")

// Run starts one relay lifetime and joins its POST/SSE workers before returning.
// Normal stdin EOF drains accepted responses before best-effort DELETE /mcp.
// Run must not overlap another Run on the same instance. Its exported
// configuration must remain unchanged until the lifetime has settled.
//
// Stdin and Stdout are borrowed by default; Run never implicitly closes them.
// Cancellation stops context-aware HTTP work, but cannot interrupt an arbitrary blocking
// Reader/Writer. For input, its owner may grant InterruptStdin; Run joins that
// callback as well as the read. Without it, the owner must terminate input.
// Output still requires its owner's termination mechanism if Write can block.
// No detached reader goroutine or implicit ownership transfer is introduced.
//
// The first output failure is retained even when it causes context cancellation.
// A separately observed stdin failure is returned alongside it. Failure to
// deliver an answer does not prove the remote operation did not execute and
// never triggers a replay. Clean EOF/cancellation alone retains the nil result.
//
// Lifecycle rules:
//   - stdin pump reads lines and dispatches POSTs in parallel goroutines
//     tracked by postWG.
//   - When stdin returns (EOF or read error), Run first waits for all
//     in-flight POSTs to drain so the last response reaches stdout before
//     the SSE listener is canceled and DELETE /mcp is sent.
//   - Cancellation stops context-aware HTTP work; responses already in flight
//     may race with it. Run still joins its workers. Borrowed blocking I/O has
//     the separate termination requirement described above.
func (r *HTTPToStdioRelay) Run(ctx context.Context) error {
	if r.URL == "" {
		return errors.New("relay: URL is required")
	}
	if r.Stdin == nil || r.Stdout == nil {
		return errors.New("relay: Stdin and Stdout are required")
	}
	if r.Stderr == nil {
		r.Stderr = io.Discard
	}
	if r.HTTPClient == nil {
		r.HTTPClient = &http.Client{
			Timeout: time.Duration(defaultHTTPTimeoutSec) * time.Second,
		}
	}
	runCtx, cancel := context.WithCancel(ctx)
	defer cancel()
	r.stdoutMu.Lock()
	r.stdoutErr = nil
	r.stdoutCancel = cancel
	r.stdoutMu.Unlock()
	defer func() {
		r.stdoutMu.Lock()
		r.stdoutCancel = nil
		r.stdoutMu.Unlock()
	}()

	var postWG sync.WaitGroup
	sseErrCh := make(chan error, 1)

	go func() {
		sseErrCh <- r.sseListener(runCtx)
	}()

	stdinErr, interruptErr := r.pumpInput(runCtx, &postWG)

	// Drain in-flight POSTs before canceling SSE — we don't want to
	// drop the last responses the client is waiting for.
	postWG.Wait()

	// Shut down SSE listener by canceling runCtx, then wait for it.
	cancel()
	<-sseErrCh

	// Best-effort session termination — don't block caller on failure.
	r.terminateSession()

	outputErr := r.stdoutFailure()
	if interruptErr != nil {
		outputErr = errors.Join(outputErr, interruptErr)
	}
	if !relayInputCleanDetach(stdinErr) {
		if outputErr != nil {
			return errors.Join(stdinErr, outputErr)
		}
		return stdinErr
	}
	return outputErr
}

// relayInputCleanDetach accepts only error trees composed entirely of the
// two expected input-end sentinels. errors.Is would match just one branch and
// incorrectly discard independent read/cleanup failures in errors.Join.
func relayInputCleanDetach(err error) bool {
	if err == nil || err == io.EOF || err == context.Canceled {
		return true
	}
	switch e := err.(type) {
	case interface{ Unwrap() []error }:
		causes := e.Unwrap()
		if len(causes) == 0 {
			return false
		}
		for _, cause := range causes {
			if cause == nil || !relayInputCleanDetach(cause) {
				return false
			}
		}
		return true
	case interface{ Unwrap() error }:
		cause := e.Unwrap()
		return cause != nil && relayInputCleanDetach(cause)
	default:
		return false
	}
}

// pumpInput attaches only the interruption capability explicitly granted by
// the input owner. Reading stays on the Run goroutine; no reader is abandoned.
// Disarm before draining accepted POSTs so normal EOF does not later interrupt
// settled input when Run cancels its HTTP context. If interruption already
// started, join it and retain its outcome independently of the read outcome.
func (r *HTTPToStdioRelay) pumpInput(ctx context.Context, wg *sync.WaitGroup) (error, error) {
	if err := ctx.Err(); err != nil {
		return err, nil
	}
	interrupt := r.InterruptStdin
	if interrupt == nil {
		return r.stdinPump(ctx, wg), nil
	}
	done := make(chan struct{})
	var interruptErr error
	stop := context.AfterFunc(ctx, func() {
		defer close(done)
		interruptErr = interrupt()
	})
	stdinErr := r.stdinPump(ctx, wg)
	if !stop() {
		<-done
		if interruptErr != nil {
			interruptErr = fmt.Errorf("relay stdin interruption: %w", interruptErr)
		}
	}
	// Interruption may end the read with EOF, Canceled or an independent
	// native error. None of those replaces an expired operation deadline.
	if errors.Is(ctx.Err(), context.DeadlineExceeded) {
		stdinErr = errors.Join(ctx.Err(), stdinErr)
	}
	return stdinErr, interruptErr
}

// stdinPump reads JSON-RPC lines from stdin and POSTs each to /mcp.
//
// Messages sent before the session is established (before the server
// responds to `initialize` with a `MCP-Session-Id` header) are
// processed SYNCHRONOUSLY — one at a time, in stdin order. This
// prevents the race where a goroutine carrying `notifications/initialized`
// wins the CAS slot and arrives at the server before `initialize`.
//
// After the session is established, messages are dispatched in parallel
// goroutines tracked by wg so Run can wait for them to drain.
func (r *HTTPToStdioRelay) stdinPump(ctx context.Context, wg *sync.WaitGroup) error {
	reader := bufio.NewReaderSize(r.Stdin, maxStdinLineBytes)
	postSem := make(chan struct{}, maxConcurrentPOSTs)

	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		line, err := readJSONRPCLine(reader)
		if err != nil {
			return fmt.Errorf("stdin read: %w", err)
		}
		// A blocked read may complete with data concurrently with interruption.
		// Such data is not new admission after cancellation, even if a custom
		// HTTP transport would accept an already-canceled request.
		if err := ctx.Err(); err != nil {
			return err
		}
		if len(bytes.TrimSpace(line)) == 0 {
			continue
		}

		// Synchronous path until session established — guarantees
		// message ordering (initialize first) and session-id capture
		// before any parallel dispatch.
		if r.getSessionID() == "" {
			r.handlePOST(ctx, line)
			continue
		}

		// Session known — safe to parallelize.
		select {
		case postSem <- struct{}{}:
		case <-ctx.Done():
			return ctx.Err()
		}

		wg.Add(1)
		go func(body []byte) {
			defer wg.Done()
			defer func() { <-postSem }()
			r.handlePOST(ctx, body)
		}(line)
	}
}

// handlePOST sends one JSON-RPC message over HTTP POST and forwards the
// server's response(s) back to stdout. On HTTP failure with a request
// (has id), synthesizes a JSON-RPC error response so the client does
// not hang awaiting a reply.
func (r *HTTPToStdioRelay) handlePOST(ctx context.Context, body []byte) {
	meta, metaErr := decodeJSONRPCMeta(body)

	req, err := http.NewRequestWithContext(ctx, "POST", r.URL, bytes.NewReader(body))
	if err != nil {
		r.logErr("build POST request: %v", err)
		r.sendSyntheticError(meta, metaErr, err)
		return
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	if sid := r.getSessionID(); sid != "" {
		req.Header.Set(mcpSessionIDHeader, sid)
	}

	resp, err := r.HTTPClient.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return // shutting down; do not synthesize a response
		}
		r.logErr("POST %s: %v", r.URL, err)
		r.sendSyntheticError(meta, metaErr, err)
		return
	}
	defer resp.Body.Close()

	// Capture session ID minted by the server on first initialize.
	if sid := resp.Header.Get(mcpSessionIDHeader); sid != "" {
		r.setSessionID(sid)
	}

	switch resp.StatusCode {
	case http.StatusAccepted: // 202 — no body for notifications/responses
		return
	case http.StatusOK:
		contentType := resp.Header.Get("Content-Type")
		if strings.HasPrefix(contentType, "text/event-stream") {
			if err := r.pipeSSE(ctx, resp.Body); err != nil {
				r.logErr("POST SSE pipe: %v", err)
			}
			return
		}
		// application/json (or anything else) — single message body.
		msg, err := io.ReadAll(resp.Body)
		if err != nil {
			r.logErr("read POST response body: %v", err)
			r.sendSyntheticError(meta, metaErr, err)
			return
		}
		r.writeLine(msg)
	case http.StatusNotFound:
		// Session dropped by server; relay could re-initialize automatically,
		// but for v1 we surface the error to the client. Antigravity will
		// spawn a fresh relay if it retries.
		r.logErr("session lost (server returned 404)")
		r.sendSyntheticError(meta, metaErr, fmt.Errorf("session lost"))
	default:
		msg, _ := io.ReadAll(resp.Body)
		r.logErr("POST non-2xx: status=%d body=%q", resp.StatusCode, msg)
		r.sendSyntheticError(meta, metaErr, fmt.Errorf("HTTP %d", resp.StatusCode))
	}
}

// sseListener opens a long-lived GET /mcp SSE stream and forwards each
// event's JSON payload to stdout. Reconnects once after a 1 s pause on
// stream drop.
func (r *HTTPToStdioRelay) sseListener(ctx context.Context) error {
	var lastEventID string
	attempts := 0

	for {
		if ctx.Err() != nil {
			return nil
		}
		// Wait for session before first SSE request; server requires
		// MCP-Session-Id on GET.
		if r.getSessionID() == "" {
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(100 * time.Millisecond):
				continue
			}
		}

		attempts++
		req, err := http.NewRequestWithContext(ctx, "GET", r.URL, nil)
		if err != nil {
			return fmt.Errorf("build GET request: %w", err)
		}
		req.Header.Set("Accept", "text/event-stream")
		req.Header.Set(mcpSessionIDHeader, r.getSessionID())
		if lastEventID != "" {
			req.Header.Set(lastEventIDHeader, lastEventID)
		}

		resp, err := r.HTTPClient.Do(req)
		if err != nil {
			if ctx.Err() != nil {
				return nil
			}
			r.logErr("GET SSE: %v", err)
			if attempts >= 3 {
				return err
			}
			if !sleepOrDone(ctx, time.Second) {
				return nil
			}
			continue
		}

		if resp.StatusCode == http.StatusMethodNotAllowed {
			// Server doesn't support server-initiated SSE (spec §allows).
			resp.Body.Close()
			return nil
		}
		if resp.StatusCode != http.StatusOK {
			resp.Body.Close()
			r.logErr("GET SSE non-2xx: status=%d", resp.StatusCode)
			if !sleepOrDone(ctx, time.Second) {
				return nil
			}
			continue
		}

		lastEventID = r.readSSEStream(ctx, resp.Body, lastEventID)
		resp.Body.Close()
		if err := r.stdoutFailure(); err != nil {
			return err // a damaged output stream must not reconnect and write again
		}

		// Stream ended cleanly (server closed). Reconnect after brief pause.
		if !sleepOrDone(ctx, time.Second) {
			return nil
		}
		attempts = 0 // reset on clean close
	}
}

// readSSEStream reads an SSE response body until EOF or ctx cancel,
// forwarding each `data:` event's JSON payload to stdout. Returns the
// last observed event ID so the caller may resume.
func (r *HTTPToStdioRelay) readSSEStream(ctx context.Context, body io.Reader, startID string) string {
	lastID, _ := readRelaySSE(ctx, body, startID, 0, func(payload []byte) (bool, error) {
		return false, r.writeLine(payload)
	})
	return lastID
}

// The legacy relay and finite observed exchange share the same SSE framing.
// A matched response can stop an observed POST without claiming body EOF.
func readRelaySSE(ctx context.Context, body io.Reader, startID string, maxEventBytes int, receive func([]byte) (bool, error)) (string, error) {
	scanner := bufio.NewScanner(body)
	scanner.Buffer(make([]byte, 0, 64*1024), maxStdinLineBytes)

	var dataBuf strings.Builder
	lastID := startID

	flush := func() (bool, error) {
		if dataBuf.Len() == 0 {
			return false, nil
		}
		payload := dataBuf.String()
		dataBuf.Reset()
		// SSE `data:` payloads may span multiple lines (joined with \n per spec).
		// For our use case MCP messages are single JSON objects and never contain
		// raw newlines, so the joined form equals the JSON bytes.
		return receive([]byte(payload))
	}

	for scanner.Scan() {
		if ctx.Err() != nil {
			return lastID, ctx.Err()
		}
		line := scanner.Text()
		switch {
		case line == "":
			if stop, err := flush(); stop || err != nil {
				return lastID, err
			}
		case strings.HasPrefix(line, "data:"):
			// Per SSE spec the value is everything after the first colon,
			// optionally with one leading space stripped.
			val := strings.TrimPrefix(line, "data:")
			val = strings.TrimPrefix(val, " ")
			if dataBuf.Len() > 0 {
				dataBuf.WriteByte('\n')
			}
			dataBuf.WriteString(val)
			if maxEventBytes > 0 && dataBuf.Len() > maxEventBytes {
				return lastID, errStdinLineTooLong
			}
		case strings.HasPrefix(line, "id:"):
			lastID = strings.TrimSpace(strings.TrimPrefix(line, "id:"))
		default:
			// Other SSE field lines (event:, retry:, comment lines starting
			// with ':', or unrecognized fields) are ignored — the relay is
			// transport-level and forwards only the data: payload.
		}
	}
	if err := scanner.Err(); err != nil {
		return lastID, err
	}
	_, err := flush()
	return lastID, err
}

// pipeSSE handles the rare case where POST /mcp returns an SSE stream
// (long-running request). The payload framing is identical to the GET
// case, but a separate code path keeps the POST handler focused on
// request-scoped responses.
func (r *HTTPToStdioRelay) pipeSSE(ctx context.Context, body io.Reader) error {
	r.readSSEStream(ctx, body, "")
	return r.stdoutFailure()
}

// terminateSession issues a best-effort DELETE /mcp with the session
// header. Failures are logged and ignored — relay is shutting down
// regardless.
func (r *HTTPToStdioRelay) terminateSession() {
	sid := r.takeSessionID()
	if sid == "" {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "DELETE", r.URL, nil)
	if err != nil {
		return
	}
	req.Header.Set(mcpSessionIDHeader, sid)
	resp, err := r.HTTPClient.Do(req)
	if err != nil {
		r.logErr("DELETE /mcp: %v", err)
		return
	}
	resp.Body.Close()
}

// sendSyntheticError emits a JSON-RPC error response to stdout so a
// client awaiting a response does not hang indefinitely. Called when
// the underlying HTTP POST fails. If the original request had no id
// (notification), no synthetic response is emitted (none is expected).
func (r *HTTPToStdioRelay) sendSyntheticError(meta *jsonrpcMeta, metaErr error, cause error) {
	if metaErr != nil || meta == nil || len(meta.ID) == 0 || string(meta.ID) == "null" {
		return
	}
	// Error code -32603 = JSON-RPC "Internal error" per spec.
	payload := map[string]any{
		"jsonrpc": "2.0",
		"id":      json.RawMessage(meta.ID),
		"error": map[string]any{
			"code":    -32603,
			"message": fmt.Sprintf("mcp-local-hub relay: %v", cause),
		},
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		r.logErr("marshal synthetic error: %v", err)
		return
	}
	r.writeLine(raw)
}

// writeLine writes a single JSON-RPC message plus trailing newline under
// the stdout mutex. The message must be a single-line JSON payload —
// line-delimited framing per MCP stdio transport spec.
func (r *HTTPToStdioRelay) writeLine(msg []byte) error {
	msg = bytes.TrimRight(msg, "\r\n")
	r.stdoutMu.Lock()
	defer r.stdoutMu.Unlock()
	if r.stdoutErr != nil {
		return r.stdoutErr
	}
	for _, part := range [][]byte{msg, []byte("\n")} {
		n, err := r.Stdout.Write(part)
		if err == nil && n != len(part) {
			err = io.ErrShortWrite
		}
		if err != nil {
			r.stdoutErr = fmt.Errorf("relay stdout: %w", err)
			if r.stdoutCancel != nil {
				r.stdoutCancel()
			}
			return r.stdoutErr
		}
	}
	return nil
}

func (r *HTTPToStdioRelay) stdoutFailure() error {
	r.stdoutMu.Lock()
	defer r.stdoutMu.Unlock()
	return r.stdoutErr
}

func (r *HTTPToStdioRelay) logErr(format string, args ...any) {
	fmt.Fprintf(r.Stderr, "[relay] "+format+"\n", args...)
}

func (r *HTTPToStdioRelay) getSessionID() string {
	r.sessionMu.Lock()
	defer r.sessionMu.Unlock()
	return r.sessionID
}

func (r *HTTPToStdioRelay) setSessionID(sid string) {
	// Only store the first session id; rotation would happen via
	// explicit re-initialize which is out of v1 scope.
	r.sessionMu.Lock()
	defer r.sessionMu.Unlock()
	if r.sessionID == "" {
		r.sessionID = sid
	}
}

func (r *HTTPToStdioRelay) takeSessionID() string {
	r.sessionMu.Lock()
	defer r.sessionMu.Unlock()
	sid := r.sessionID
	r.sessionID = ""
	return sid
}

// readJSONRPCLine reads up to the next newline from r and returns the
// raw bytes (without the terminator). Errors include io.EOF (clean
// detach) and any bufio.Reader error.
func readJSONRPCLine(br *bufio.Reader) ([]byte, error) {
	var line []byte
	for {
		chunk, err := br.ReadSlice('\n')
		if len(line)+len(chunk) > maxStdinLineBytes {
			return nil, errStdinLineTooLong
		}
		line = append(line, chunk...)
		if errors.Is(err, bufio.ErrBufferFull) {
			continue
		}
		if len(line) == 0 && err != nil {
			return nil, err
		}
		return bytes.TrimRight(line, "\r\n"), err
	}
}

// decodeJSONRPCMeta extracts the jsonrpc/id/method triple without
// copying the full message. Returns (nil, err) on malformed input,
// in which case callers should skip synthesizing an error reply
// (we have no id to address it to).
func decodeJSONRPCMeta(body []byte) (*jsonrpcMeta, error) {
	var m jsonrpcMeta
	if err := json.Unmarshal(body, &m); err != nil {
		return nil, err
	}
	if m.JSONRPC != "2.0" {
		return nil, fmt.Errorf("unexpected jsonrpc version %q", m.JSONRPC)
	}
	return &m, nil
}

// sleepOrDone waits for either the timeout or ctx cancellation. Returns
// true if the timeout fired (caller should continue), false if canceled.
func sleepOrDone(ctx context.Context, d time.Duration) bool {
	select {
	case <-time.After(d):
		return true
	case <-ctx.Done():
		return false
	}
}
