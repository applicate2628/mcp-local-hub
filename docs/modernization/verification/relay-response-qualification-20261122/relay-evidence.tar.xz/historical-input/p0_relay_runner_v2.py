"""Qualify only the reviewed Relay composition on exact preserved source 858812.

Source-derived entry from the pinned p0_serena_runner.py. Runner, execute,
environment, source admission and retained original Popen ownership are byte
identical to that parent; constants and fixed manifest admission select Relay.

Each phase checks its own 16 pinned Go overlays with gofmt -l before other Go
work. Formatting never mutates source. The control phases select finite readers
and fake transports only; old lifetime/GET timeout controls are not admitted.
Candidate tests select exactly 25 response roots or 17 in-memory neighbors.
The historical d49 priming regression has a separate finite-only control.
Native/HTTP-server/installed-product/model/full-suite selections are absent.

Manifest SHA and runner/source/candidate pins are checked before actions.
Evidence/runtime directories are new per phase. A direct-child timeout remains
an unresolved descendant-tree outcome, never a valid negative test oracle.
No prepare/fetch/checkout, process rediscovery or scheduler operation exists.
"""
import sys
sys.dont_write_bytecode = True

from collections import Counter
import ctypes
from ctypes import wintypes
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5")
SOURCE = ROOT / "preserved-input/source-preserved"
BASE = "858812988833a84368c60fba1540ae601155fa71"
BASE_TREE = "dba685c090952a93a80a1e82403c4646ad8aaed1"
UPSTREAM_OWNER_SHA256 = "c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1"
GO_SHA256 = "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113"
GO_VERSION = "go version go1.27.4 windows/amd64"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GOFMT = GO.with_name("gofmt.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
TIMEOUT_KEYS = {"git", "termination"}
RESERVED_LABELS = {"init", "fetch-exact", "checkout-exact"}
KINDS = {"version", "format", "compile", "test", "build", "vet"}
PHASES = {'control': {'relay-compile-v2-control',
             'relay-format-v2-control',
             'relay-v2-control-body',
             'relay-v2-control-errors',
             'relay-v2-control-framing',
             'relay-v2-control-redirect'},
 'candidate': {'relay-compile-v2-candidate',
               'relay-format-v2-candidate',
               'relay-v2-build',
               'relay-v2-contract',
               'relay-v2-neighbors',
               'relay-v2-vet'},
 'prime-control': {'relay-v2-prime-control', 'relay-format-v2-prime', 'relay-compile-v2-prime'}}
EXPECTED_PATHS = ['cmd/mcphub/main.go',
 'cmd/mcphub/relay_input_windows_test.go',
 'internal/cli/relay.go',
 'internal/cli/relay_process_input.go',
 'internal/cli/relay_process_input_native_windows_test.go',
 'internal/cli/relay_process_input_other.go',
 'internal/cli/relay_process_input_test.go',
 'internal/cli/relay_process_input_windows.go',
 'internal/cli/relay_process_input_windows_test.go',
 'internal/daemon/main_dispatch_test.go',
 'internal/daemon/main_test.go',
 'internal/daemon/relay.go',
 'internal/daemon/relay_input_contract_test.go',
 'internal/daemon/relay_output_contract_test.go',
 'internal/daemon/relay_response_contract_test.go',
 'internal/daemon/relay_sse_session_retry_test.go']
TEST_ROOTS = {'relay-v2-control-body': ['TestRelayResponseHTTPBodyLimit', 'TestRelayResponseSSEAggregateLimit'],
 'relay-v2-control-errors': ['TestRelayResponseSSELineFailureIsReturned',
                             'TestRelayResponsePOSTReadFailureIsReturned',
                             'TestRelayResponseReadAndOutputFailuresRemainVisible'],
 'relay-v2-control-framing': ['TestRelayResponseFramingFeedsOneStdioMessage'],
 'relay-v2-control-redirect': ['TestRelayResponsePOSTRedirectNeverResends'],
 'relay-v2-contract': ['TestRelayResponseHTTPBodyLimit',
                       'TestRelayResponseSSEAggregateLimit',
                       'TestRelayResponseSSELineFailureIsReturned',
                       'TestRelayResponsePOSTReadFailureIsReturned',
                       'TestRelayResponseReadAndOutputFailuresRemainVisible',
                       'TestRelayResponsePOSTTransportFailureSurvivesCancellation',
                       'TestRelayResponsePOSTRedirectNeverResends',
                       'TestRelayResponseGETTransportFailureSurvivesCancellation',
                       'TestRelayResponseGETFailureStopsAndJoins',
                       'TestRelayResponseGETCleanEOFStillResumes',
                       'TestRelayResponseParserPreservesObservedCauses',
                       'TestRelayResponseParserFiniteReceiverContract',
                       'TestRelayResponseFramingFeedsOneStdioMessage',
                       'TestRelayResponseFramingRejectsMalformedJSON',
                       'TestRelayResponseFramingPreservesCompoundCauses',
                       'TestRelayResponseFramingEnforcesCommonByteCap',
                       'TestRelayResponseSSEUnterminatedEventDoesNotDispatch',
                       'TestRelayResponseSSESelectsMCPMessages',
                       'TestRelayResponseSSEControlCursorBoundaries',
                       'TestRelayResponseSSEControlSelectionPreservesFailures',
                       'TestRelayResponseSSEControlEventsRemainBounded',
                       'TestRelayResponsePOSTSSEPrimingReachesStdio',
                       'TestRelayResponseDefaultGETFollowsRunContextAcrossRuns',
                       'TestRelayResponseDefaultPOSTTimeoutRemainsBounded',
                       'TestRelayResponseExplicitClientTimeoutIsPreserved'],
 'relay-v2-neighbors': ['TestRelayInputInterruptUnblocksAndJoins',
                        'TestRelayInputInterruptWaitsForCallback',
                        'TestRelayInputInterruptFailureDoesNotAbandonRead',
                        'TestRelayInputInterruptDisarmedAtNormalEOF',
                        'TestRelayInputInterruptPreCanceledDoesNotTouchInput',
                        'TestRelayInputInterruptOnOutputFailure',
                        'TestRelayInputInterruptDoesNotDispatchLateRead',
                        'TestRelayInputInterruptPreservesDeadline',
                        'TestRelayInputInterruptDisarmedWhileDrainingHTTP',
                        'TestRelayInputBorrowedCloserIsNotImplicitCapability',
                        'TestRelayInputCombinedErrorsRemainVisible',
                        'TestRelayInputDeadlineSurvivesEOFAdapter',
                        'TestRelaySSEWaitingForSessionDoesNotSpendRetries',
                        'TestQualificationExchangeUsesRealReceiver',
                        'TestQualificationSessionCloseIsCached',
                        'TestQualificationZeroObservationRefuses',
                        'TestRelayOutputFailureWaitsForBorrowedInputOwner'],
 'relay-v2-prime-control': ['TestRelayResponsePOSTSSEPrimingReachesStdio']}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def moscow():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=3))).isoformat()


def save_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def relative_source_path(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_./-]+", value):
        raise ValueError("Invalid source-relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or str(path) != value or any(p in {".", "..", ".git"} for p in path.parts):
        raise ValueError("Source path escapes or aliases the reviewed tree")
    if not value.endswith(".go"):
        raise ValueError("This qualification accepts reviewed Go source paths only")
    return value


def own_path(path):
    """Reject lexical escapes and existing reparse points within the task root."""
    parts = path.relative_to(ROOT).parts
    current = ROOT
    for part in (None, *parts):
        if part is not None:
            current = current / part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Task path contains a reparse point: " + str(current))
    return path


def native_temp(requested):
    """Use the available Windows API selected by the reviewed installed Go."""
    previous = {key: os.environ.get(key) for key in ("TEMP", "TMP")}
    try:
        os.environ.update(TEMP=str(requested), TMP=str(requested))
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        name = "GetTempPath2W" if hasattr(kernel, "GetTempPath2W") else "GetTempPathW"
        function = getattr(kernel, name)
        function.argtypes = (wintypes.DWORD, wintypes.LPWSTR)
        function.restype = wintypes.DWORD
        buffer = ctypes.create_unicode_buffer(32768)
        size = function(len(buffer), buffer)
        if not 0 < size < len(buffer):
            raise RuntimeError("Native temporary-path resolution failed")
        actual = Path(buffer.value)
        if actual != requested:
            raise RuntimeError("Native temporary path escaped the requested owned location")
        return {"api": name, "requested": str(requested), "resolved": str(actual)}
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def validate_command(command):
    if not isinstance(command, dict):
        raise ValueError("Command must be an object")
    label, kind, args = command.get("label", ""), command.get("kind"), command.get("args")
    if not isinstance(label, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,63}", label) or label in RESERVED_LABELS or label.startswith("observation-"):
        raise ValueError("Invalid or reserved command label")
    if kind not in KINDS or not isinstance(args, list) or not args or any(not isinstance(a, str) or not a or "\0" in a for a in args):
        raise ValueError("Invalid command kind or argv")
    if type(command.get("timeout_seconds")) is not int or not 1 <= command["timeout_seconds"] <= 3600:
        raise ValueError("Invalid direct-child timeout")
    if type(command.get("expected_exit_code")) is not int or command["expected_exit_code"] not in (0, 1):
        raise ValueError("Invalid exit oracle")
    required = command.get("required_output", [])
    if not isinstance(required, list) or any(not isinstance(m, str) or not m or len(m) > 1000 for m in required):
        raise ValueError("Invalid required-output oracle")
    if command["expected_exit_code"] and not required:
        raise ValueError("Negative controls require an expected diagnostic")
    if any(("{" in a or "}" in a) and a not in {"{overlay}", "{binary}", "{candidate_files}"} for a in args):
        raise ValueError("Unknown or embedded argv placeholder")
    if kind in {"version", "format"}:
        if args != (["version"] if kind == "version" else ["-l", "{candidate_files}"]) or command["expected_exit_code"]:
            raise ValueError("Version and format have fixed read-only arguments")
        return
    verb = {"compile": "test", "test": "test", "build": "build", "vet": "vet", "archcheck": "run"}[kind]
    if args[0] != verb or "{candidate_files}" in args:
        raise ValueError("Command kind and Go verb differ")
    if args.count("-overlay") != 1 or args.index("-overlay") + 1 >= len(args) or args[args.index("-overlay") + 1] != "{overlay}" or any(a.startswith("-overlay=") for a in args):
        raise ValueError("Each Go command must use its exact phase overlay")
    if any(a == flag or a.startswith(flag + "=") for a in args for flag in ("-exec", "-toolexec", "-C")):
        raise ValueError("Alternate command executors and working directories are not admitted")
    if kind == "compile":
        if args.count("-c") != 1 or args.count("-o") != 1 or args.index("-o") + 1 >= len(args) or args[args.index("-o") + 1] != "{binary}":
            raise ValueError("Compile must produce its phase-specific test binary")
    elif "-c" in args:
        raise ValueError("Only compile commands may use -c")
    if kind == "archcheck" and args[:4] != ["run", "-overlay", "{overlay}", "./tools/archcheck"]:
        raise ValueError("Only the repository archcheck CLI may be run")
    if any(a.startswith("-o=") for a in args) or args.count("-o") > 1:
        raise ValueError("Output overrides must use one explicit -o {binary} pair")
    if "-o" in args and (args.index("-o") + 1 >= len(args) or args[args.index("-o") + 1] != "{binary}"):
        raise ValueError("Command outputs must remain in the phase evidence directory")
    if kind != "test":
        return
    counts = [a for a in args if a.startswith("-count=")]
    limits = [a for a in args if a.startswith("-timeout=")]
    if "-json" not in args or len(counts) != 1 or not re.fullmatch(r"-count=(?:[1-9]|1[0-9]|20)", counts[0]) or len(limits) != 1 or not re.fullmatch(r"-timeout=[1-9][0-9]*[sm]", limits[0]):
        raise ValueError("Tests require JSON, an uncached count and a positive Go deadline")
    test_seconds = int(limits[0][9:-1]) * (60 if limits[0][-1] == "m" else 1)
    if not 1 <= test_seconds < command["timeout_seconds"]:
        raise ValueError("Direct-child timeout must leave time for the Go timeout")
    expected = command.get("expected_tests")
    if expected is not None and (not isinstance(expected, dict) or set(expected) != {"pass", "fail", "skip"} or any(not isinstance(names, list) or any(not isinstance(n, str) or not n for n in names) for names in expected.values())):
        raise ValueError("Expected terminal events must contain pass/fail/skip lists")
    roots = command.get("required_root_pass_counts", {})
    if not isinstance(roots, dict) or any(not isinstance(n, str) or not re.fullmatch(r"Test[A-Za-z0-9_]+", n) or type(c) is not int or not 1 <= c <= 20 for n, c in roots.items()):
        raise ValueError("Invalid required root pass counts")
    if not roots and not (expected and any(expected.values())):
        raise ValueError("Tests require a nonempty terminal-event oracle")


def validate_manifest(manifest, phase):
    if not isinstance(manifest, dict) or type(manifest.get("schema")) is not int or manifest["schema"] != 1 or manifest.get("source_head") != BASE or manifest.get("source_tree") != BASE_TREE:
        raise ValueError("Unexpected current-source manifest identity")
    if manifest.get("runner_sha256") != sha(Path(__file__).read_bytes()):
        raise ValueError("Runner differs from its reviewed manifest pin")
    if manifest.get("native_scheduler_operations") is not False:
        raise ValueError("Native scheduler execution is outside this runner")
    timeouts = manifest.get("command_timeouts")
    if not isinstance(timeouts, dict) or set(timeouts) != TIMEOUT_KEYS or any(type(n) is not int or not 1 <= n <= 3600 for n in timeouts.values()):
        raise ValueError("All command deadlines must be explicitly frozen")
    files, phases = manifest.get("files"), manifest.get("phases")
    composition = manifest.get("composition")
    if composition not in PHASES or not isinstance(files, list) or len(files) != 16 or not isinstance(phases, dict) or set(phases) != PHASES[composition] or phase not in phases:
        raise ValueError("Invalid Relay composition, source files or phase selection")
    if manifest.get("candidate_stage") != "source-reviewed-format-required":
        raise ValueError("Formatting must be observed in each phase, not asserted by a manifest label")
    paths = []
    for item in files:
        if not isinstance(item, dict):
            raise ValueError("Source file entry must be an object")
        paths.append(relative_source_path(item.get("path")))
        for prefix in ("source", "candidate"):
            keys = (prefix + "_sha256", prefix + "_git_blob")
            if any(k not in item for k in keys):
                raise ValueError("Every source and candidate identity must be explicit")
            digest, blob = (item[k] for k in keys)
            if prefix == "source" and digest is None and blob is None:
                continue
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest) or not isinstance(blob, str) or not re.fullmatch(r"[0-9a-f]{40}", blob):
                raise ValueError("Invalid file SHA256 or Git blob identity")
    if paths != EXPECTED_PATHS:
        raise ValueError("Each composition requires the exact 13 donor paths, response test and two canonical daemon entry paths")
    for name, selection in phases.items():
        if not isinstance(name, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,40}", name) or not isinstance(selection, dict):
            raise ValueError("Invalid phase name or selection")
        overlays, commands = selection.get("overlay_paths"), selection.get("commands")
        if not isinstance(overlays, list) or any(not isinstance(p, str) or p not in paths for p in overlays) or len(overlays) != len(set(overlays)):
            raise ValueError("Overlay must be a unique subset of the pinned source paths")
        if not isinstance(commands, list) or not commands:
            raise ValueError("Execution phases require explicit commands")
        if set(overlays) != set(paths):
            raise ValueError("Each Relay phase must retain all 16 reviewed overlays")
        for command in commands:
            validate_command(command)
        if len({c["label"] for c in commands}) != len(commands):
            raise ValueError("Duplicate command label within phase")
        kinds = [command["kind"] for command in commands]
        if name.startswith("relay-format-"):
            if kinds != ["version", "format"]:
                raise ValueError("Format phases contain only version and the mandatory format gate")
        else:
            if not kinds or kinds[0] != "format" or kinds.count("format") != 1:
                raise ValueError("Every execution phase must pass gofmt before other Go work")
            if name in TEST_ROOTS:
                if kinds != ["format", "test"]:
                    raise ValueError("A test phase contains exactly one fixed test command")
                command = commands[1]
                selector = "^(" + "|".join(TEST_ROOTS[name]) + ")$"
                args = command["args"]
                if args.count("-run") != 1 or args[args.index("-run") + 1:args.index("-run") + 2] != [selector] or any(a.startswith("-run=") for a in args) or args[-1] != "./internal/daemon":
                    raise ValueError("Test selectors differ from the reviewed finite/fake-transport scope")
                if composition in {"control", "prime-control"}:
                    if command["expected_exit_code"] != 1 or not command.get("expected_tests") or command["expected_tests"]["skip"]:
                        raise ValueError("Negative controls require exact terminal events and a real test failure")
                elif command["expected_exit_code"] != 0 or command.get("required_root_pass_counts") != {root: (2 if name == "relay-v2-contract" else 1) for root in TEST_ROOTS[name]}:
                    raise ValueError("Candidate tests require every reviewed root at the exact repeat count")
            elif name.startswith("relay-compile-"):
                packages = ["./internal/daemon"] if composition == "prime-control" else ["./internal/daemon", "./internal/cli", "./cmd/mcphub"]
                if kinds != ["format"] + ["compile"] * len(packages) or [c["args"][-1] for c in commands[1:]] != packages:
                    raise ValueError("Compile must cover the exact reviewed packages without execution")
            elif kinds != ["format", "build" if name == "relay-v2-build" else "vet"] or commands[1]["args"][-1] != "./...":
                raise ValueError("Build/vet must retain the complete composition")
    return manifest


def test_events(raw):
    events = []
    for line in raw.decode("utf-8").splitlines():
        event = json.loads(line)
        if not isinstance(event, dict):
            raise ValueError("Invalid Go JSON event")
        events.append(event)
    return events


def terminal_events(events):
    return {action: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == action] for action in ("pass", "fail", "skip")}


class Runner:
    def __init__(self, phase, manifest, manifest_path, manifest_sha):
        self.phase = phase
        self.out = ROOT / "evidence" / phase
        self.runtime = ROOT / "runtime" / phase
        self.plan = manifest
        self.manifest_path = manifest_path
        self.receipt = {
            "schema": 1, "phase": phase, "base": BASE, "base_tree": BASE_TREE,
            "source_directory": str(SOURCE), "manifest_sha256": manifest_sha,
            "manifest_path": str(manifest_path), "upstream_capture_owner_sha256": UPSTREAM_OWNER_SHA256,
            "started_utc": utc(), "started_moscow": moscow(), "state": "preflight",
            "completed": False, "runner_sha256": sha(Path(__file__).read_bytes()),
            "commands": [], "observations": [], "native_task_operations": False,
            "native_task_operations_basis": "Reviewed frozen argv and MCPHUB_E2E_SCHEDULER=none; not syscall enforcement",
            "whole_process_tree_deadline_enforced": False,
            "direct_child_wait_bounded": True, "process_tree_settlement_observed": False,
        }
        self.observation_id = 0
        self.out_created = False
        self.env = None
        self.manifest = None

    def begin(self):
        if os.name != "nt" or sys.flags.optimize or Path(__file__).resolve().parent != ROOT:
            raise RuntimeError("Runner must be used unoptimized from the approved Windows task root")
        for path in (self.out, self.runtime, SOURCE, self.manifest_path):
            own_path(path)
        self.out.mkdir(parents=True, exist_ok=False)
        self.out_created = True
        self.runtime.mkdir(parents=True, exist_ok=False)
        for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks", "xdg-config", "xdg-cache", "xdg-data", "telemetry"):
            (self.runtime / name).mkdir(exist_ok=False)
        (self.runtime / "telemetry" / "mode").write_text("off\n", encoding="ascii")
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_")) and k.upper() != "SSH_ASKPASS"}
        system = Path(next(v for k, v in env.items() if k.upper() == "SYSTEMROOT"))
        ps = system / "System32/WindowsPowerShell/v1.0/powershell.exe"
        env.update({
            "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
            "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off",
            "GOFLAGS": "-mod=readonly", "GOCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gocache",
            "GOMODCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache",
            "GOPATH": str(self.runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")),
            "CGO_ENABLED": "1", "GOMAXPROCS": "4", "GOTELEMETRY": "off",
            "TEST_TELEMETRY_DIR": str(self.runtime / "telemetry"),
            "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
            "USERPROFILE": str(self.runtime / "profile"), "APPDATA": str(self.runtime / "appdata"),
            "LOCALAPPDATA": str(self.runtime / "localappdata"), "TEMP": str(self.runtime / "tmp"),
            "TMP": str(self.runtime / "tmp"), "TMPDIR": str(self.runtime / "tmp"),
            "GOTMPDIR": str(self.runtime / "tmp"), "XDG_CONFIG_HOME": str(self.runtime / "xdg-config"),
            "XDG_CACHE_HOME": str(self.runtime / "xdg-cache"), "XDG_DATA_HOME": str(self.runtime / "xdg-data"),
            "PSModuleAnalysisCachePath": str(self.runtime / "localappdata/module-cache"),
            "PYTHONDONTWRITEBYTECODE": "1", "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": str(self.runtime / "no-global-config"), "GIT_TERMINAL_PROMPT": "0",
            "GCM_INTERACTIVE": "never",
        })
        env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))
        self.env = env
        self.receipt["native_temporary_path"] = native_temp(own_path(Path(env["TMP"])))
        for path in (GO, GOFMT, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
            if not path.exists():
                raise RuntimeError("Missing pre-existing tool/cache: " + str(path))
        if sha(GO.read_bytes()) != GO_SHA256:
            raise RuntimeError("Pre-installed Go executable differs from the reviewed pin")
        self.manifest = self.plan
        self.files = self.manifest["files"]
        self.paths = [item["path"] for item in self.files]
        self.receipt.update(
            command_timeouts=self.manifest["command_timeouts"],
            environment={k: env[k] for k in (
                "GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB", "GOVCS", "GOWORK", "GOFLAGS",
                "GOTELEMETRY", "TEST_TELEMETRY_DIR", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI",
                "MCPHUB_E2E_SCHEDULER", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP",
                "GOCACHE", "GOMODCACHE", "GOTMPDIR", "XDG_CACHE_HOME",
            )},
            tools_sha256={str(p): sha(p.read_bytes()) for p in (GO, GOFMT, GIT, Path(env["CC"]))},
        )
        save_new(self.out / "receipt-initial.json", self.receipt)
        self.receipt["state"] = "running"

    def git_command(self, path, args):
        return [
            str(GIT), "-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(self.runtime / "empty-hooks"),
            "-c", "credential.helper=", "-c", "core.askPass=", "-c", "core.fsmonitor=false",
            "-c", "maintenance.auto=false", "-c", "gc.auto=0", "-C", str(path), *args,
        ]

    def execute(self, label, command, cwd, timeout, source_before=None, quiet=False):
        row = {
            "label": label, "executable": command[0], "args": command[1:], "cwd": str(cwd),
            "started_utc": utc(), "started_moscow": moscow(), "settled": False, "timed_out": False,
            "direct_timeout_seconds": timeout, "whole_process_tree_deadline_enforced": False,
            "runner_sha256": self.receipt["runner_sha256"], "manifest_sha256": self.receipt.get("manifest_sha256"),
        }
        if source_before is not None:
            row["source_before"] = source_before
        save_new(self.out / (label + ".started.json"), row)
        if not quiet:
            print("START " + label, flush=True)
        child = None
        started = time.monotonic()
        try:
            with (self.out / (label + ".stdout.log")).open("xb") as stdout, (self.out / (label + ".stderr.log")).open("xb") as stderr:
                child = subprocess.Popen(command, cwd=cwd, env=self.env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
                row["pid"] = child.pid
                save_new(self.out / (label + ".launched.json"), {**row, "launched_utc": utc()})
                try:
                    row["exit_code"] = child.wait(timeout=timeout)
                    row["settled"] = True
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    row["error_type"] = "TimeoutExpired"
                    row["error"] = "Direct-child deadline expired; descendant state is unresolved"
        except BaseException as error:
            row.update(error_type=type(error).__name__, error=str(error))
        finally:
            if child is not None and not row["settled"]:
                # Popen owns the original Windows process handle. Never resolve
                # a PID again, call taskkill, or infer that children were killed.
                row["termination_method"] = "Popen.terminate on retained direct-child handle"
                row["process_tree_unresolved"] = True
                self.receipt["process_tree_unresolved"] = True
                try:
                    child.terminate()
                    row["exit_code"] = child.wait(timeout=self.manifest["command_timeouts"]["termination"])
                    row["settled"] = True
                except BaseException as error:
                    row["termination_error"] = type(error).__name__ + ": " + str(error)
                row["retain_runtime_and_logs"] = True
            row.update(seconds=time.monotonic() - started, finished_utc=utc(), finished_moscow=moscow())
            for stream in ("stdout", "stderr"):
                path = self.out / (label + "." + stream + ".log")
                if path.exists():
                    try:
                        raw = path.read_bytes()
                        row[stream] = {
                            "bytes": len(raw), "sha256": sha(raw), "captured_utc": utc(),
                            "hash_scope": "observed bytes; later writers unresolved" if row.get("process_tree_unresolved") else "bytes observed after direct-child exit",
                        }
                    except Exception as error:
                        row[stream + "_capture_error"] = type(error).__name__ + ": " + str(error)
        return row

    def git_at(self, path, *args):
        self.observation_id += 1
        label = "observation-%04d" % self.observation_id
        row = self.execute(label, self.git_command(path, args), path, self.manifest["command_timeouts"]["git"], quiet=True)
        self.receipt["observations"].append(row)
        save_new(self.out / (label + ".receipt.json"), row)
        self.require_pass(row)
        return (self.out / (label + ".stdout.log")).read_text(encoding="utf-8").rstrip("\r\n")

    def snapshot(self, path=SOURCE):
        own_path(path / ".git")
        for relative in self.paths:
            own_path(path / relative)
        result = {"exists": path.exists(), "sha256": {p: sha((path / p).read_bytes()) if (path / p).is_file() else None for p in self.paths}}
        if (path / ".git").exists():
            result.update(head=self.git_at(path, "rev-parse", "HEAD"), tree=self.git_at(path, "rev-parse", "HEAD^{tree}"))
            result["materialized"] = (path / "go.mod").is_file()
            if result["materialized"]:
                result.update(
                    parents=self.git_at(path, "show", "-s", "--format=%P", "HEAD").split(),
                    staged=self.git_at(path, "diff", "--cached", "--name-only"),
                    status=self.git_at(path, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"),
                )
        return result

    def admit(self):
        own_path(SOURCE)
        value = self.snapshot()
        if value.get("head") != BASE or value.get("tree") != BASE_TREE or not value.get("materialized") or value.get("staged") != "" or value.get("status") != "":
            raise RuntimeError("Source is not the exact clean preserved-input snapshot")
        for item in self.files:
            path = own_path(SOURCE / item["path"])
            raw = path.read_bytes() if path.is_file() else None
            if value["sha256"][item["path"]] != item["source_sha256"] or (git_blob(raw) if raw is not None else None) != item["source_git_blob"]:
                raise RuntimeError("Original source identity differs: " + item["path"])
        return value

    @staticmethod
    def require_pass(row):
        if not row.get("settled") or row.get("timed_out") or row.get("error_type") or row.get("exit_code") != 0 or row.get("tests", {}).get("fail") or any(k in row for k in ("event_error_type", "source_after_error", "stdout_capture_error", "stderr_capture_error")):
            raise RuntimeError(row["label"] + " failed")

    def run(self, label, executable, args, timeout, cwd=SOURCE):
        before = self.snapshot()
        command = self.git_command(cwd, args) if executable == GIT else [str(executable), *args]
        row = self.execute(label, command, cwd, timeout, before)
        self.receipt["commands"].append(row)
        try:
            if executable == GO and args and args[0] == "test" and "-json" in args and "-c" not in args and row.get("settled") and not row.get("timed_out"):
                row["tests"] = terminal_events(test_events((self.out / (label + ".stdout.log")).read_bytes()))
        except Exception as error:
            row.update(event_error_type=type(error).__name__, event_error=str(error))
        try:
            row["source_after"] = self.snapshot()
        except Exception as error:
            row["source_after_error"] = type(error).__name__ + ": " + str(error)
        save_new(self.out / (label + ".receipt.json"), row)
        print(json.dumps({k: row.get(k) for k in ("label", "exit_code", "seconds", "settled", "timed_out", "process_tree_unresolved")}), flush=True)
        return row

    def finish(self, error=None):
        if error is not None:
            self.receipt.update(state="failed", error_type=type(error).__name__, error=str(error), completed=False)
        if self.manifest is not None and self.env is not None and hasattr(self, "paths"):
            try:
                self.receipt["source_final"] = self.snapshot()
                if self.receipt["completed"] and self.receipt["source_final"] != self.receipt.get("source_after"):
                    raise RuntimeError("Source drifted after phase admission")
            except Exception as failure:
                self.receipt.update(completed=False, state="failed", source_final_error=type(failure).__name__ + ": " + str(failure))
        try:
            self.receipt["runner_sha256_after"] = sha(Path(__file__).read_bytes())
            self.receipt["manifest_sha256_after"] = sha(own_path(self.manifest_path).read_bytes())
            if "tools_sha256" in self.receipt:
                self.receipt["tools_sha256_after"] = {p: sha(Path(p).read_bytes()) for p in self.receipt["tools_sha256"]}
            if self.receipt["runner_sha256_after"] != self.receipt["runner_sha256"] or self.receipt["manifest_sha256_after"] != self.receipt["manifest_sha256"] or self.receipt.get("tools_sha256_after") != self.receipt.get("tools_sha256"):
                raise RuntimeError("Runner, manifest or observed tool bytes changed during qualification")
        except Exception as failure:
            self.receipt.update(completed=False, state="failed", final_identity_error=type(failure).__name__ + ": " + str(failure))
        self.receipt.update(finished_utc=utc(), finished_moscow=moscow())
        self.receipt.update(
            source_sha256_before=self.receipt.get("source_before", {}).get("sha256"),
            source_sha256_after=self.receipt.get("source_final", {}).get("sha256"),
        )
        if self.out_created:
            save_new(self.out / "receipt.json", self.receipt)
        print(json.dumps({k: self.receipt.get(k) for k in ("phase", "state", "completed", "error", "source_head", "process_tree_unresolved")}), flush=True)


def candidate_paths(manifest, manifest_path):
    result = {}
    for item in manifest["files"]:
        path = own_path(manifest_path.parent / "candidate" / item["path"])
        raw = path.read_bytes()
        if sha(raw) != item["candidate_sha256"] or git_blob(raw) != item["candidate_git_blob"]:
            raise RuntimeError("Candidate identity differs: " + item["path"])
        result[item["path"]] = path
    return result


def check_command(runner, command, row, binary):
    if not row.get("settled") or row.get("timed_out") or row.get("exit_code") != command["expected_exit_code"] or any(k in row for k in ("error_type", "event_error_type", "source_after_error", "stdout_capture_error", "stderr_capture_error")):
        raise RuntimeError("Execution differs from the expected result: " + command["label"])
    if row.get("source_before") != runner.receipt["source_before"] or row.get("source_after") != runner.receipt["source_before"]:
        raise RuntimeError("Physical source changed around the reviewed command")
    output = (runner.out / (command["label"] + ".stdout.log")).read_bytes()
    stderr = (runner.out / (command["label"] + ".stderr.log")).read_bytes()
    for name, raw in (("stdout", output), ("stderr", stderr)):
        if sha(raw) != row[name]["sha256"] or len(raw) != row[name]["bytes"]:
            raise RuntimeError("Captured stream changed after direct-child exit")
    rendered = output.decode("utf-8")
    if command["kind"] == "test":
        events = test_events(output)
        observed = terminal_events(events)
        if observed != row.get("tests"):
            raise RuntimeError("Terminal event receipt differs from retained bytes")
        expected = command.get("expected_tests")
        if expected is not None and any(Counter(observed[a]) != Counter(expected[a]) for a in observed):
            raise RuntimeError("Terminal test events differ from the reviewed oracle")
        counts = Counter(observed["pass"])
        if any(counts[n] != count for n, count in command.get("required_root_pass_counts", {}).items()):
            raise RuntimeError("A required root did not pass its reviewed repeat count")
        if observed["skip"]:
            raise RuntimeError("Qualification selected a skipped test")
        rendered = "".join(event.get("Output", "") for event in events)
    if any(marker not in rendered + stderr.decode("utf-8") for marker in command.get("required_output", [])):
        raise RuntimeError("An expected diagnostic is absent")
    if command["kind"] == "version" and rendered.strip() != GO_VERSION:
        raise RuntimeError("Go version differs from the reviewed version")
    if command["kind"] == "format" and output:
        raise RuntimeError("Candidate needs formatting; no source mutation performed")
    if command["expected_exit_code"] == 0:
        runner.require_pass(row)
    oracle = {"label": command["label"], "manifest_sha256": runner.receipt["manifest_sha256"], "matched": True}
    if command["kind"] == "compile" and command["expected_exit_code"] == 0:
        raw = own_path(binary).read_bytes()
        if not raw:
            raise RuntimeError("Compilation did not produce a nonempty test binary")
        oracle["binary"] = {"path": str(binary), "bytes": len(raw), "sha256": sha(raw)}
    if command["kind"] == "archcheck":
        oracle["source_read_scope"] = "Physical --root path or source-preserved cwd; Go overlay only affects compilation"
    save_new(runner.out / (command["label"] + ".oracle.json"), oracle)
    row["oracle"] = oracle


def qualify(runner):
    runner.receipt["source_before"] = runner.admit()
    candidates = candidate_paths(runner.manifest, runner.manifest_path)
    selection = runner.manifest["phases"][runner.phase]
    overlay = runner.out / "overlay.json"
    save_new(overlay, {"Replace": {str(SOURCE / p): str(candidates[p]) for p in selection["overlay_paths"]}})
    runner.receipt["overlay_sha256"] = sha(overlay.read_bytes())
    runner.receipt["overlay_paths"] = selection["overlay_paths"]
    for command in selection["commands"]:
        candidate_paths(runner.manifest, runner.manifest_path)
        if sha(overlay.read_bytes()) != runner.receipt["overlay_sha256"]:
            raise RuntimeError("Phase overlay changed before execution")
        binary = runner.out / (command["label"] + ".exe")
        arguments = []
        for arg in command["args"]:
            if arg == "{candidate_files}":
                arguments.extend(map(str, candidates.values()))
            else:
                arguments.append({"{overlay}": str(overlay), "{binary}": str(binary)}.get(arg, arg))
        executable = GOFMT if command["kind"] == "format" else GO
        if executable == GO and sha(GO.read_bytes()) != GO_SHA256:
            raise RuntimeError("Go executable changed before execution")
        row = runner.run(command["label"], executable, arguments, command["timeout_seconds"], SOURCE)
        check_command(runner, command, row, binary)
    if sha(overlay.read_bytes()) != runner.receipt["overlay_sha256"]:
        raise RuntimeError("Phase overlay changed during qualification")
    candidate_paths(runner.manifest, runner.manifest_path)
    after = runner.admit()
    runner.receipt.update(source_after=after, source_head=after["head"], source_tree=after["tree"], working_status=after["status"], completed=True, state="complete")


def main():
    if len(sys.argv) != 4 or os.name != "nt" or sys.flags.optimize or Path(__file__).resolve().parent != ROOT:
        raise SystemExit("Use p0_relay_runner_v2.py <phase> <manifest-relative-path> <manifest-sha256> from the approved Windows task root")
    phase, relative, digest = sys.argv[1:]
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,40}", phase) or not re.fullmatch(r"[0-9a-f]{64}", digest) or not re.fullmatch(r"[A-Za-z0-9_./-]+\.json", relative):
        raise SystemExit("Invalid phase, manifest path or SHA256 pin")
    path = PurePosixPath(relative)
    if path.is_absolute() or str(path) != relative or any(p in {".", "..", ".git"} for p in path.parts):
        raise SystemExit("Manifest path escapes or aliases the task root")
    manifest_path = own_path(ROOT / relative)
    raw = manifest_path.read_bytes()
    if sha(raw) != digest:
        raise SystemExit("Manifest bytes differ from the reviewed command-line pin; no actions performed")
    manifest = validate_manifest(json.loads(raw), phase)
    candidate_paths(manifest, manifest_path)
    runner = Runner(phase, manifest, manifest_path, digest)
    failure = None
    try:
        runner.begin()
        qualify(runner)
    except BaseException as error:
        failure = error
    finally:
        runner.finish(failure)
    if failure is not None or not runner.receipt["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
