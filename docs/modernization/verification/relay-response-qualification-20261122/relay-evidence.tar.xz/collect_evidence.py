"""Export only settled Relay evidence and pinned input files; run no test code."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-relay-20261122-e21a1792")
OLD = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5")
RUNNER = "b6a16eb3a0e281031b2db81f8d05c766bd685e0d2729b56323b4b4a7ae80192d"
INPUT = "c5ebbe5c118f8fd79ea1fa776ef53756ae8def31ed3c9e59506397753b940b4e"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Refusing reparse point: " + str(item))
    return path.read_bytes()


if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
    raise SystemExit("Use the authorized Relay workspace")
assert sha(read(ROOT / "qualify_relay.py")) == RUNNER
composition_raw = read(ROOT / "composition.json")
composition_sha = sha(composition_raw)
composition = json.loads(composition_raw)
assert composition["input_sha256"] == INPUT
for phase in ("neighbors", "build", "vet"):
    summary = json.loads(read(ROOT / "evidence" / phase / "summary.json"))
    assert summary["source_unchanged"] is True
    assert summary["composition_sha256"] == composition_sha
    receipt = json.loads(read(ROOT / "evidence" / phase / (phase + ".receipt.json")))
    assert receipt["settled"] is True and receipt["timed_out"] is False
    assert receipt["exit_code"] == 0

files = {}
for name in ("qualify_relay.py", "collect_evidence.py", "composition.json", "input-manifest.json", "history-summary.json"):
    files[name] = ROOT / name
for directory in ("history", "evidence"):
    for path in (ROOT / directory).rglob("*"):
        if path.is_file():
            files[path.relative_to(ROOT).as_posix()] = path
old_runner = OLD / "p0_relay_runner_v2.py"
assert sha(read(old_runner)) == "d8cb7090ddda09cb14a50759f56397a55ff03f3a6ce9bfc29f226788217ed17e"
files["historical-input/p0_relay_runner_v2.py"] = old_runner
for variant, digest in {
    "relay-v2-candidate": INPUT,
    "relay-v2-control": "5cbf7df8c3ae3ba72c59556fe72af682f8d6649d50a3f6c02e959605b5dbbaea",
    "relay-v2-prime-control": "2db10f175e29b5fdb29fae0e02ad36f784c6d333e6deb90ef51b734f3fcd1fc7",
}.items():
    path = OLD / "manifests" / variant / "manifest.json"
    manifest_raw = read(path)
    assert sha(manifest_raw) == digest
    files["historical-input/" + variant + "/manifest.json"] = path
    manifest = json.loads(manifest_raw)
    for item in manifest["files"]:
        candidate = path.parent / "candidate" / item["path"]
        raw = read(candidate)
        assert sha(raw) == item["candidate_sha256"]
        files["historical-input/" + variant + "/candidate/" + item["path"]] = candidate

destination = ROOT / "export"
destination.mkdir(exist_ok=False)
archive = destination / "relay-evidence.tar.xz"
inventory = {}
with tarfile.open(archive, mode="x:xz", preset=6) as out:
    for name, path in sorted(files.items()):
        raw = read(path)
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        out.addfile(info, io.BytesIO(raw))
        inventory[name] = {"bytes": len(raw), "sha256": sha(raw)}
    raw = (json.dumps(inventory, indent=2) + "\n").encode()
    info = tarfile.TarInfo("archive-inventory.json")
    info.size = len(raw)
    info.mode = 0o644
    out.addfile(info, io.BytesIO(raw))
raw = read(archive)
encoded = base64.b64encode(raw).decode("ascii")
parts = []
for index, offset in enumerate(range(0, len(encoded), 32760)):
    name = "part-%03d.b64" % index
    text = encoded[offset:offset + 32760]
    (destination / name).write_text("\n".join(text[i:i + 120] for i in range(0, len(text), 120)) + "\n", encoding="ascii")
    parts.append(name)
result = {"archive": archive.name, "bytes": len(raw), "sha256": sha(raw),
          "files": len(inventory), "uncompressed_bytes": sum(x["bytes"] for x in inventory.values()),
          "composition_sha256": composition_sha, "parts": parts}
(destination / "archive-summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result), flush=True)
