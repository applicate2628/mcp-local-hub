"""Validate saved follow-up evidence, redact it, and create one exclusive archive.

No subprocess, network, Git, Go, process inspection, waits, or directory scans.
Usage: python package_followup.py EXPECTED_CODE_COMMIT EXPECTED_CODE_TREE
Static inputs: ROOT/review/static-inputs.json, a list (or {"files": list}) of
{path, sha256, archive_path}; path is relative to ROOT/review.
"""
from collections import Counter
from datetime import datetime
from pathlib import Path, PurePosixPath
import base64
import csv
import hashlib
import io
import json
import math
import re
import stat
import sys
import zipfile

ROOT = Path(r'<WORK_ROOT>')
BASE = 'f755d374fab317e1037deecd5dac8ffabbcdde36'
BASE_TREE = '19056c7b39ed2f625cb7f0b5282343c92b3b3a48'
TEST_PATH = 'internal/cli/gui_force_test.go'
CANDIDATE = 'db019916c49da6c5be02298559690b368e431e0c01feb95a786add30b875eba8'
BLOB = '06ec8f6d6a624dce040390532bda824b2553b46a'
PHASES = ('prepare', 'intent-trace', 'intent-trace-01', 'api-receiving', 'job-entry',
          'forcekill-controls', 'forcekill-candidate', 'gates', 'published')
RUNNERS = {
    'prepare': ('prepare_followup.py', 'fa9956df34fc26abbe5a7e0c97a6f4a30716d15a24ea704f7bc48a4daf053660'),
    'intent-trace': ('review/runners/run_followup-acl-encoding.py', 'fefb6d31b8bfac0fbc12eabe3d167ecdce3c9de66ae56ad1b68cd2760afd8f18'),
    'intent-trace-01': ('run_followup.py', 'eedc3167fa4cc1af80548b42f9dddc4d35cb73f8aa3339018c20f1de459915ed'),
    'api-receiving': ('run_qualified.py', 'a6ddab83b8b1ca1552ae1df0f4dffdefb3e096bda1e29884b4975bc9807cdd0c'),
    'job-entry': ('run_qualified.py', 'a6ddab83b8b1ca1552ae1df0f4dffdefb3e096bda1e29884b4975bc9807cdd0c'),
    'forcekill-controls': ('run_forcekill.py', 'cc00f5173d27874f33c579d6685a99d7d204f5f24120950b84c83939ca41b2be'),
    'forcekill-candidate': ('run_candidate.py', 'bf2fada5ae70bed5975db2117bee561c2a8d1ff7fed3324322d01a89a1821b2c'),
    'gates': ('run_candidate.py', 'bf2fada5ae70bed5975db2117bee561c2a8d1ff7fed3324322d01a89a1821b2c'),
    'published': ('run_published.py', '73995ea7ce766f1bf619e91066c326f072d01b06241c81faf694c6fb0a9f2fa3'),
}
FOCUSED = [('mcp-local-hub/internal/cli', 'TestForce_KillHappyPath_SeamMocked'),
           ('mcp-local-hub/internal/cli', 'TestForce_KillRefusesNonMcphubImage'),
           ('mcp-local-hub/internal/gui', 'TestKillRecordedHolder_CancelledContextRefusesKill')]
SELECTOR = '^(TestForce_KillHappyPath_SeamMocked|TestForce_KillRefusesNonMcphubImage|TestKillRecordedHolder_CancelledContextRefusesKill)$'
JOB_TESTS = {'TestJob_BreakawayEnabledDescendantEscapesClose',
             'TestJobInformationTransportPreparationBoundary',
             'TestJobInformationTransportPreparationBoundary/real-native-typed-gc-and-creator'}
POLICY_COMMANDS = {'output-owner', 'output-protect', 'output-acl-save'}
raw, raw_map, inputs, json_lines, phases, commands, analyses = {}, {}, {}, set(), {}, {}, {}
identities, protocol_values = set(), set()


class EvidenceError(Exception):
    pass


def need(ok, label):
    if not ok:
        raise EvidenceError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def relative(name):
    need(isinstance(name, str) and name, 'empty relative path')
    p = PurePosixPath(name)
    need(p.parts and not p.is_absolute() and p.as_posix() == name and '..' not in p.parts
         and not any(c in name for c in ('\\', ':')) and not any(ord(c) < 32 for c in name),
         'invalid relative path')
    return p


def ordinary(path, directory):
    info = path.lstat()
    need((stat.S_ISDIR if directory else stat.S_ISREG)(info.st_mode)
         and not getattr(info, 'st_file_attributes', 0) & 0x400, 'nonordinary saved path')
    return info


def saved_path(name):
    parts = relative(name).parts
    p = ROOT
    try:
        ordinary(p, True)
        for i, part in enumerate(parts):
            p /= part
            ordinary(p, i != len(parts) - 1)
    except FileNotFoundError:
        raise EvidenceError('missing saved file: ' + name) from None
    return p


def capture(name, archive=None, expected=None, size=None, binary=False):
    p = saved_path(name)
    if binary:
        h, length = hashlib.sha256(), 0
        with p.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
                length += len(chunk)
        digest, data = h.hexdigest(), None
    else:
        need(p.stat().st_size <= 32 * 1024 * 1024, 'text input exceeds bound: ' + name)
        if name not in raw:
            raw[name] = p.read_bytes()
        data = raw[name]
        digest, length = sha(data), len(data)
    need(expected is None or digest == expected, 'raw hash mismatch: ' + name)
    need(size is None or type(size) is int and length == size, 'raw length mismatch: ' + name)
    record = {'source_sha256': digest, 'source_bytes': length, 'archive_paths': []}
    if name in raw_map:
        need(raw_map[name]['source_sha256'] == digest, 'saved input changed: ' + name)
        record = raw_map[name]
    raw_map[name] = record
    if archive is not None:
        relative(archive)
        need(data is not None, 'binary publication refused')
        need(archive not in inputs or inputs[archive] == name, 'archive name collision')
        inputs[archive] = name
        if archive not in record['archive_paths']:
            record['archive_paths'].append(archive)
    return data


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def parse(data):
    def nonfinite(_):
        raise EvidenceError('nonfinite JSON number')
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique, parse_constant=nonfinite)


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def load(name, archive=None):
    obj = parse(capture(name, archive))
    need(type(obj) is dict, 'JSON object required: ' + name)
    return obj


def folder(phase):
    return 'prepare' if phase == 'prepare' else 'evidence/' + phase


def stream(phase, name, kind='stdout'):
    return raw[folder(phase) + '/' + name + '.' + kind + '.log']


def line(phase, name):
    return stream(phase, name).decode('utf-8').rstrip('\r\n')


def source(phase, label, head, tree, dirty=False):
    value = {'head': head, 'tree': tree, 'status': ' M ' + TEST_PATH if dirty else ''}
    need(phases[phase].get('source_' + label) == value, 'source receipt mismatch: ' + phase + '/' + label)
    for key, expected in value.items():
        need(line(phase, label + '-' + key) == expected, 'source stdout mismatch: ' + phase + '/' + label)
    if dirty:
        need(line(phase, label + '-index') == '', 'unexpected staged input: ' + phase + '/' + label)


def phase_names(phase):
    before, after = ['before-head', 'before-tree', 'before-status'], ['after-head', 'after-tree', 'after-status']
    if phase in ('gates', 'published'):
        before += ['before-index']
    if phase in ('gates', 'forcekill-candidate'):
        after += ['after-index']
    setup = ['output-owner', 'output-protect', 'output-acl-save']
    middle = {
        'intent-trace': [],
        'intent-trace-01': ['go-version', 'intent-concurrent-trace', 'syscall-profile', 'syscall-top', 'sync-profile', 'sync-top'],
        'api-receiving': ['go-version', 'build-receiving-cli', 'build-receiving-test', 'public-cli-receiving'],
        'job-entry': ['go-version', 'build-job-controller', 'build-job-test', 'qualified-job-entry'],
        'forcekill-controls': ['go-version', 'delayed-baseline-gofmt', 'delayed-baseline', 'delayed-candidate-gofmt', 'delayed-candidate'],
        'forcekill-candidate': ['go-version', 'candidate-applied-head', 'candidate-applied-tree', 'candidate-applied-status',
                              'candidate-applied-index', 'candidate-gofmt', 'candidate-diff-check', 'candidate-race'],
        'gates': ['go-version', 'build', 'vet', 'full-test', 'tagged-api-cli'],
        'published': ['go-version', 'fetch-published', 'published-parents', 'published-paths', 'published-target-tree',
                      'published-blob', 'stage-candidate', 'prepared-tree', 'checkout-published', 'published-head',
                      'published-tree', 'published-status', 'published-race'],
    }
    if phase == 'prepare':
        return ['old-root', 'old-head', 'old-status', 'clone', 'fetch', 'fetched-tree', 'checkout',
                'head', 'tree', 'status', 'go-version', 'powershell-policy']
    return before + setup + middle[phase] + after


def validate_phase(phase, code, tree):
    base = folder(phase)
    receipt = load(base + '/receipt.json', base + '/receipt.json')
    phases[phase] = receipt
    need(receipt.get('phase') == phase, 'wrong phase: ' + phase)
    need(receipt.get('expected_head') == (code if phase == 'published' else BASE)
         and receipt.get('expected_tree') == (tree if phase == 'published' else BASE_TREE), 'phase source pin: ' + phase)
    for key in ('system_policy_changed', 'software_installed', 'branches_integrated', 'whole_process_tree_deadline_enforced'):
        need(receipt.get(key) is False, 'unexpected policy/scope assertion: ' + phase + '/' + key)
    need(not receipt.get('final_source_error'), 'final source verification failed: ' + phase)
    start = datetime.fromisoformat(receipt['started_utc'])
    finish = datetime.fromisoformat(receipt['finished_utc'])
    need(start.utcoffset() is not None and finish.utcoffset() is not None and finish >= start, 'phase time: ' + phase)
    runner, pin = RUNNERS[phase]
    need(receipt.get('script_sha256' if phase == 'prepare' else 'runner_sha256') == pin, 'runner receipt pin: ' + phase)
    capture(runner, 'runners/' + PurePosixPath(runner).name, expected=pin)
    records = receipt['commands']
    need(type(records) is list and [r['name'] for r in records] == phase_names(phase)
         and len({r['name'] for r in records}) == len(records), 'command order/uniqueness: ' + phase)
    commands[phase] = {r['name']: r for r in records}
    for r in records:
        name = r['name']
        allowed = {0, 1} if phase == 'gates' and name in ('build', 'vet', 'full-test', 'tagged-api-cli') else {0}
        if (phase, name) in {('prepare', 'powershell-policy'), ('forcekill-controls', 'delayed-baseline')}:
            allowed = {1}
        need(r.get('settled') is True and type(r.get('exit_code')) is int and r['exit_code'] in allowed
             and not r.get('deadline_hit') and not r.get('direct_child_deadline_hit'), 'command exit/settlement: ' + phase + '/' + name)
        need(type(r.get('pid')) is int and r['pid'] > 0 and type(r.get('direct_child_deadline_seconds')) is int
             and r['direct_child_deadline_seconds'] > 0, 'command identity/deadline: ' + phase + '/' + name)
        need(type(r.get('seconds')) in (int, float) and math.isfinite(r['seconds']) and r['seconds'] >= 0, 'command duration')
        need(type(r.get('arguments')) is list and all(type(x) is str for x in r['arguments']), 'command arguments')
        for kind in ('stdout', 'stderr'):
            path = base + '/' + name + '.' + kind + '.log'
            private = name in POLICY_COMMANDS or name in ('syscall-profile', 'sync-profile') and kind == 'stdout'
            capture(path, None if private else path, expected=r[kind + '_sha256'], size=r[kind + '_bytes'])
        if name.endswith('-gofmt') or name == 'candidate-diff-check':
            need(not stream(phase, name), 'format/diff diagnostic is not empty')
    if phase == 'prepare':
        need(not receipt.get('completed') and receipt.get('error_class') == 'RuntimeError'
             and receipt.get('error') == 'command failed: powershell-policy', 'unrecognized prepare failure')
        need(stream(phase, 'powershell-policy', 'stderr') and not stream(phase, 'powershell-policy'), 'missing policy failure evidence')
        need((receipt.get('head'), receipt.get('tree'), receipt.get('status')) == (BASE, BASE_TREE, ''), 'prepared source receipt')
        for name, expected in [('head', BASE), ('tree', BASE_TREE), ('fetched-tree', BASE_TREE), ('status', ''),
                               ('old-head', '2cb467aac31259ed4fb665ed0a4f277a8f9c31a2'), ('old-status', '')]:
            need(line(phase, name) == expected, 'prepare source stdout: ' + name)
    else:
        failed_early = phase == 'intent-trace'
        need(receipt.get('completed') is (not failed_early), 'phase completion: ' + phase)
        if failed_early:
            need(receipt.get('error_class') == 'UnicodeDecodeError' and 'utf-16' in receipt.get('error', '').lower(),
                 'unrecognized pre-test ACL decoding failure')
        else:
            need(not receipt.get('error'), 'unexpected phase error: ' + phase)
        source(phase, 'before', BASE, BASE_TREE, phase in ('gates', 'published'))
        source(phase, 'after', code if phase == 'published' else BASE,
               tree if phase == 'published' else BASE_TREE, phase in ('gates', 'forcekill-candidate'))
        who = list(csv.reader(stream(phase, 'output-owner').decode('utf-8-sig').splitlines()))
        need(len(who) == 1 and len(who[0]) == 2, 'unexpected saved token-owner representation')
        identities.update(x for x in who[0][0].split('\\') if x)
        sid = who[0][1]
        need(re.fullmatch(r'S-1-5-(?:[0-9]+-)*[0-9]+', sid), 'invalid saved SID')
        acl_path = base + '/output.acl'
        acl = capture(acl_path, expected=receipt.get('output_dacl', {}).get('verified_acl_sha256'))
        rows = [s for s in acl.decode('utf-16-le').lstrip('\ufeff').splitlines() if s]
        need(len(rows) == 2 and rows[1].startswith('D:P')
             and set(re.findall(r'\(([^()]+)\)', rows[1])) == {'A;OICI;FA;;;' + sid, 'A;OICI;FA;;;SY'}
             and len(re.findall(r'\(', rows[1])) == 2, 'saved output ACL properties: ' + phase)
        if not failed_early:
            need(receipt.get('output_dacl', {}).get('protected') is True
                 and receipt['output_dacl'].get('allowed') == ['current-token-user', 'LocalSystem'], 'DACL receipt properties')
    analyses[phase] = {'completed': receipt.get('completed', False), 'error': receipt.get('error'),
                       'seconds': (finish - start).total_seconds(),
                       'classification': 'prior pre-test failure' if phase in ('prepare', 'intent-trace') else 'completed',
                       'commands': [{k: r[k] for k in ('name', 'exit_code', 'seconds', 'settled')} for r in records]}


def go_events(phase, name, expected):
    path = folder(phase) + '/' + name + '.stdout.log'
    json_lines.add(path)
    events = [parse(row) for row in stream(phase, name).splitlines()]
    need(all(type(e) is dict for e in events), 'Go event object')
    terminal = [e for e in events if e.get('Action') in ('pass', 'fail', 'skip')]
    actual = Counter((e['Action'], e.get('Package'), e.get('Test')) for e in terminal)
    need(actual == expected, 'required Go test/package outcomes: ' + phase + '/' + name)
    recorded = phases[phase].get('test_events') if phase == 'intent-trace-01' else phases[phase].get('test_runs', {}).get(name)
    need(recorded == terminal, 'Go terminal events differ from receipt')
    analyses[phase].setdefault('test_runs', {})[name] = terminal
    return ''.join(e.get('Output', '') for e in events)


def focused(phase, name):
    expected = Counter({('pass', p, t): 2 for p, t in FOCUSED})
    expected.update({('pass', p, None): 1 for p in {p for p, _ in FOCUSED}})
    need(commands[phase][name]['arguments'] == ['test', '-mod=readonly', '-race', '-count=2', '-timeout=120s',
         '-json', '-run=' + SELECTOR, './internal/cli', './internal/gui'], 'focused command differs')
    go_events(phase, name, expected)


def validate_results(code, tree):
    expected_artifacts = {
        'intent-trace-01': {'api-intent.test.exe', 'intent.trace'},
        'api-receiving': {'mcphub-attach-test.exe', 'api.test.exe'},
        'job-entry': {'test-job-entry.exe', 'process.test.exe'},
    }
    for phase, names in expected_artifacts.items():
        artifacts = phases[phase]['artifacts']
        need(set(artifacts) == names, 'artifact allowlist: ' + phase)
        for name, value in artifacts.items():
            capture(folder(phase) + '/' + name, expected=value['sha256'], size=value['bytes'], binary=True)
    intent = Counter({('pass', 'mcp-local-hub/internal/api', 'TestDaemonIntent_ConcurrentWrite'): 1,
                      ('pass', 'mcp-local-hub/internal/api', None): 1})
    go_events('intent-trace-01', 'intent-concurrent-trace', intent)
    api = stream('api-receiving', 'public-cli-receiving').decode('utf-8')
    need(len(re.findall(r'^--- PASS: TestAttachExisting_PublicCLIReceiving ', api, re.M)) == 1
         and not re.search(r'--- (FAIL|SKIP):|panic:', api), 'API receiving required PASS')
    receiving = phases['api-receiving']['artifacts']['mcphub-attach-test.exe']['sha256']
    need(phases['api-receiving']['receiving_inputs']['MCPHUB_ATTACH_TEST_BIN_SHA256'] == receiving
         and phases['gates']['receiving_fixture']['sha256'] == receiving, 'receiving fixture hash binding')
    native_path = 'evidence/job-entry/native-run/result.json'
    native = parse(capture(native_path, native_path, expected=phases['job-entry']['native_result_sha256']))
    need(native.get('schema') == 'job-fixture-controller-result-v1'
         and all(native.get(k) is True for k in ('success', 'originalWaitKnown', 'settlementComplete', 'stdoutEOF', 'stderrEOF'))
         and type(native.get('originalExitCode')) is int and native['originalExitCode'] == 0 and not native.get('error')
         and len(native.get('passed', [])) == 3 and set(native['passed']) == JOB_TESTS, 'native original result incomplete')
    settled = native['nativeSettlement']
    need(all(settled.get(k) is True for k in ('RootWaitKnown', 'MembersExited', 'AccountingKnown', 'HandlesClosed'))
         and type(settled.get('RootExitCode')) is int and settled['RootExitCode'] == 0
         and type(settled.get('FinalActive')) is int and settled['FinalActive'] == 0
         and settled.get('TerminalAction') == 'not-requested' and not settled.get('Error'), 'native original settlement incomplete')
    need(native['bind']['binary'] == phases['job-entry']['artifacts']['process.test.exe']['sha256'], 'native binary binding')
    protocol_values.update([native['bind']['nonce'], native['ready']['challenge'], native['grant']['ownerGeneration']])
    for name in ('stdout.log', 'stderr.log'):
        capture('evidence/job-entry/native-run/' + name)  # Protocol-bearing originals remain private.
    analyses['job-entry']['native_result'] = {k: native[k] for k in ('success', 'originalWaitKnown', 'originalExitCode',
                                              'settlementComplete', 'stdoutEOF', 'stderrEOF', 'passed')}
    analyses['job-entry']['native_settlement'] = settled
    for name, action in [('delayed-baseline', 'fail'), ('delayed-candidate', 'pass')]:
        log = go_events('forcekill-controls', name, Counter({(action, 'mcp-local-hub/internal/cli', 'TestForce_KillHappyPath_SeamMocked'): 1,
                                                           (action, 'mcp-local-hub/internal/cli', None): 1}))
        markers = [s.strip() for s in log.splitlines() if 'FORCE_KILL_CONTROL ' in s]
        need(markers == phases['forcekill-controls']['control_markers'][name], 'control markers differ from receipt')
        entered = [s for s in markers if 'gate_enter delay=4s ' in s]
        exited = [s for s in markers if 'gate_exit elapsed=' in s]
        need(len(entered) == len(exited) == 1 and entered[0].endswith('ctx=<nil>')
             and exited[0].endswith('ctx=context canceled' if action == 'fail' else 'ctx=<nil>')
             and markers.index(entered[0]) < markers.index(exited[0]), 'control cancellation ordering')
        duration = re.search(r'gate_exit elapsed=([0-9]+(?:\.[0-9]+)?)s ', exited[0])
        need(duration is not None and float(duration[1]) >= 4, 'four-second injection was not observed')
        need('helper_settled pid=' in log and 'wait_unlock_error=<nil>' in log and 'gate_entered=true' in log, 'control helper not settled')
        required = ('command_return ctx=context canceled exit_code=4', 'kill cancelled before SIGKILL', 'happy path exit code = 4') if action == 'fail' else (
            'recovery_return ctx=<nil> exit_code=0 acquired_lock=true', 'recovered_lock_settled', 'port=1')
        need(all(s in log for s in required), 'control failed to demonstrate its claimed outcome')
        analyses['forcekill-controls'].setdefault('markers', {})[name] = markers
    source('forcekill-candidate', 'candidate-applied', BASE, BASE_TREE, True)
    focused('forcekill-candidate', 'candidate-race')
    gates = {}
    for name in ('build', 'vet', 'full-test', 'tagged-api-cli'):
        text = stream('gates', name).decode('utf-8', errors='replace')
        diagnostic = {'failed_packages': re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)', text, re.M),
                      'failed_tests': re.findall(r'^--- FAIL: ([^ (]+)', text, re.M),
                      'timeouts': re.findall(r'panic: test timed out after ([^\r\n]+)', text)}
        need(phases['gates']['gate_findings'][name] == diagnostic, 'gate diagnostic mismatch: ' + name)
        gates[name] = {**diagnostic, 'exit_code': commands['gates'][name]['exit_code'], 'seconds': commands['gates'][name]['seconds']}
    analyses['gates'].update({'gates': gates, 'all_gates_pass': all(g['exit_code'] == 0 for g in gates.values())})
    published = phases['published']
    need(published.get('base_head') == BASE and published.get('base_tree') == BASE_TREE
         and published.get('published_parents') == [BASE] and published.get('published_changed_paths') == [TEST_PATH]
         and published.get('prepared_tree') == tree, 'published single-change contract')
    need(published.get('gates_receipt_sha256') == raw_map['evidence/gates/receipt.json']['source_sha256'], 'published gate receipt binding')
    for name, expected in [('published-parents', BASE), ('published-paths', TEST_PATH), ('published-target-tree', tree),
                           ('published-blob', BLOB), ('prepared-tree', tree)]:
        need(line('published', name) == expected, 'published stdout binding: ' + name)
    source('published', 'published', code, tree)
    focused('published', 'published-race')
    need(datetime.fromisoformat(phases['gates']['finished_utc']) <= datetime.fromisoformat(published['started_utc']), 'publication preceded gate completion')


def post_observation(code):
    pin = 'ee4447e8aad1848439a66d7af46edc0679a1287d25f25d5dfc10fd43c153e8e9'
    receipt = load('post-verify/receipt.json', 'post-verify/receipt.json')
    need(receipt.get('phase') == 'post-verify' and receipt.get('expected_head') == code
         and receipt.get('script_sha256') == pin, 'post-observation binding')
    capture('observe_followup.py', 'runners/observe_followup.py', expected=pin)
    for kind in ('stdout', 'stderr'):
        name = 'post-verify/' + kind + '.log'
        capture(name, name, expected=receipt[kind + '_sha256'], size=receipt[kind + '_bytes'])
    need(receipt.get('whole_process_tree_proven') is False and receipt.get('observed_processes_modified') is False
         and type(receipt.get('settled')) is bool and type(receipt.get('exit_code')) is int,
         'post-observation scope/settlement fields')
    need(datetime.fromisoformat(phases['published']['finished_utc']) <= datetime.fromisoformat(receipt['started_utc'])
         <= datetime.fromisoformat(receipt['finished_utc']), 'post-observation time')
    if receipt.get('completed') is True:
        value = parse(raw['post-verify/stdout.log'])
        json_lines.add('post-verify/stdout.log')
        need(value == receipt.get('observation') and receipt['settled'] is True and receipt['exit_code'] == 0
             and not receipt.get('direct_child_deadline_hit') and receipt['stderr_bytes'] == 0, 'completed observation mismatch')
        need(value.get('observer_pid') == receipt.get('pid') and value.get('root_labels') == ['go-gate-followup']
             and value.get('scope') == 'exact owned-root marker in executable path or command line; no ancestry closure'
             and value.get('command_lines_or_images_emitted') is False and value.get('whole_process_tree_proven') is False
             and type(value.get('remaining')) is list, 'observation scope')
        excluded = value.get('excluded_pids')
        need(type(excluded) is list and len(excluded) == 3 and excluded[0] == receipt['pid']
             and all(type(p) is int and p > 0 for p in excluded), 'observation exclusions')
        absent = not value['remaining']
        need(receipt.get('scoped_absence_observed') is absent
             and receipt.get('overall') == ('ABSENCE_OBSERVED' if absent else 'MATCHES_OBSERVED'), 'observation outcome')
    else:
        need(receipt.get('completed') is False and receipt.get('scoped_absence_observed') is False
             and receipt.get('overall') == 'INCOMPLETE', 'incomplete observation falsely qualified')
    analyses['post-verify'] = {k: receipt[k] for k in ('completed', 'overall', 'settled', 'exit_code',
                               'seconds', 'scoped_absence_observed', 'whole_process_tree_proven', 'observed_processes_modified')}


def static_inputs():
    index_path = 'review/static-inputs.json'
    index = parse(capture(index_path, index_path))
    entries = index.get('files') if type(index) is dict else index
    need(type(entries) is list and entries, 'static input list is missing or empty')
    seen = set()
    for e in entries:
        need(type(e) is dict and set(e) == {'path', 'sha256', 'archive_path'}, 'static input contract')
        name, target = e['path'], e['archive_path']
        relative(name)
        relative(target)
        need(name not in seen and PurePosixPath(name).suffix in {'.md', '.json', '.go', '.py', '.diff', '.txt'}
             and 'projection' not in name.lower() and re.fullmatch(r'[0-9a-f]{64}', e['sha256']), 'static input allowlist')
        seen.add(name)
        data = capture('review/' + name, target, expected=e['sha256'])
        if name.endswith('.json'):
            value = parse(data)
            need(not (type(value) is dict and 'projection' in str(value.get('kind', '')).lower()), 'normalized projection is not raw evidence')


def redactor():
    replacements = [(str(ROOT), '<WORK_ROOT>'), (r'<OWNED_WORK_ROOT>', '<OWNED_WORK_ROOT>'),
                    (r'<GO_ROOT>', '<GO_ROOT>'), (r'<GO_BIN>', '<GO_BIN>'),
                    (r'<LOCAL_PIPE>', '<LOCAL_PIPE>'), ('<LOCAL_REVIEW_ROOT>', '<LOCAL_REVIEW_ROOT>')]
    replacements += [(s, '<PROTOCOL_VALUE>') for s in protocol_values if s]
    id_patterns = [r'(?<!\w)' + re.escape(s) + r'(?!\w)' for s in sorted(identities, key=len, reverse=True)]
    placeholder = '<REDACTED_IDENTITY>'
    while any(re.search(p, placeholder, re.I) for p in id_patterns):
        placeholder = '<_' + placeholder[1:]
    absolute = r'\b[A-Za-z]:[\\/]+[^\s"\'<>]*'
    unc = r'(?<!\\)\\\\+[A-Za-z0-9_.-]+[\\/][^\s"\'<>]*'
    posix = r'(?<![\w/])/(?:workspace|home|Users|tmp|private|var|mnt)(?:/[^\s"\'<>]*)?'
    sid = r'\bS-[0-9]+-[0-9]+(?:-[0-9]+)+\b'
    credentials = [rb'\bgh[pousr]_[A-Za-z0-9]{16,}', rb'\bgithub_pat_[A-Za-z0-9_]{16,}',
                   rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}', rb'\bxox[baprs]-[A-Za-z0-9-]{16,}',
                   rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}', rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
                   rb'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}']

    def text(value):
        for old, new in sorted(replacements, key=lambda p: len(p[0]), reverse=True):
            for spelling in sorted({old, old.replace('\\', '/'), old.replace('\\', '\\\\')}, key=len, reverse=True):
                value = re.sub(re.escape(spelling), lambda _: new, value, flags=re.I)
        for pattern in (absolute, unc, posix):
            value = re.sub(pattern, lambda m: '<PATH>' + ''.join(c for c in m.group() if 0xDC80 <= ord(c) <= 0xDCFF), value)
        for pattern in id_patterns:
            value = re.sub(pattern, lambda _: placeholder, value, flags=re.I)
        return re.sub(sid, '<SID>', value)

    def obj(value):
        if isinstance(value, str):
            return text(value)
        if isinstance(value, list):
            return [obj(x) for x in value]
        if isinstance(value, dict):
            changed = {text(k): obj(v) for k, v in value.items()}
            need(len(changed) == len(value), 'redacted JSON key collision')
            return changed
        return value

    def check(value):
        if isinstance(value, dict):
            for k, v in value.items():
                check(k)
                check(v)
        elif isinstance(value, list):
            for x in value:
                check(x)
        elif isinstance(value, str):
            need(not any(re.search(p, value, re.I) for p in id_patterns)
                 and not any(re.search(p, value) for p in (absolute, unc, posix, sid)), 'private identity/path remains')
            encoded = value.encode('utf-8', errors='surrogateescape')
            need(not any(re.search(p, encoded) for p in credentials), 'credential-shaped content remains')

    def saved(name, data, original=None):
        if name.endswith('.json'):
            result = obj(parse(data))
            check(result)
            return json_bytes(result)
        if original in json_lines:
            rows = [obj(parse(row)) for row in data.splitlines()]
            check(rows)
            return b''.join((json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8') for row in rows)
        decoded = data.decode('utf-8-sig', errors='surrogateescape' if name.endswith('.log') else 'strict')
        changed = text(decoded)
        check(changed)
        need([c for c in decoded if 0xDC80 <= ord(c) <= 0xDCFF] == [c for c in changed if 0xDC80 <= ord(c) <= 0xDCFF],
             'undecodable bytes changed')
        return changed.encode('utf-8', errors='surrogateescape')
    return saved, text, check


def main():
    need(not sys.flags.optimize and len(sys.argv) == 3 and all(re.fullmatch(r'[0-9a-f]{40}', s) for s in sys.argv[1:]),
         'usage: package_followup.py EXPECTED_CODE_COMMIT EXPECTED_CODE_TREE')
    code, tree = sys.argv[1:]
    for phase in PHASES:
        validate_phase(phase, code, tree)
    validate_results(code, tree)
    post_observation(code)
    static_inputs()
    saved, redact_text, scan = redactor()
    summary = {
        'base_commit': BASE, 'base_tree': BASE_TREE, 'published_code_commit': code, 'published_code_tree': tree,
        'candidate_file_sha256': CANDIDATE, 'candidate_blob_sha1': BLOB,
        'validated_saved_files_only': True, 'no_commands_executed_by_packager': True,
        'gates_completed': True, 'all_gates_pass': analyses['gates']['all_gates_pass'],
        'focused_candidate_and_published_passed': True, 'phase_results': analyses,
        'limitations': ['The two earlier preparation failures and expected old-control FAIL remain failures.',
            'Completed gate execution does not imply all gates passed.',
            'General Go subprocess deadlines do not establish a whole-process-tree deadline.',
            'Native Job settlement qualifies the selected original fixture; terminal action was not requested.',
            'The final process observation covers the saved owned-root marker only, not complete ancestry or the whole process tree.',
            'Raw traces, binaries, protobuf profiles, token-owner/ACL data and native protocol logs remain private.',
            'Identity/path redaction and credential-shape scans are bounded checks, not a proof against every possible secret.',
            'Unstructured logs retain undecodable UTF-8 bytes via surrogateescape; their origin is not established.'],
    }
    members, manifest = {}, {}
    for target, name in sorted(inputs.items()):
        need(redact_text(target) == target, 'private archive member name')
        scan(target)
        data = saved(target, raw[name], name)
        members[target] = data
        manifest[target] = {'source_file': name, 'source_sha256': raw_map[name]['source_sha256'],
                            'source_bytes': raw_map[name]['source_bytes'], 'saved_sha256': sha(data), 'saved_bytes': len(data)}
        if target.endswith('.log') and name not in json_lines:
            manifest[target]['undecodable_utf8_bytes'] = sum(0xDC80 <= ord(c) <= 0xDCFF for c in raw[name].decode('utf-8', errors='surrogateescape'))
    for name, value in [('execution-summary.json', summary), ('raw-hashmap.json', raw_map), ('manifest.json', manifest)]:
        need(name not in members, 'reserved archive name collision')
        members[name] = saved(name, json_bytes(value))
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o444) << 16
            archive.writestr(info, data)
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as archive:
        need(archive.namelist() == sorted(members) and all(archive.read(n) == members[n] for n in members), 'archive verification failed')
    metadata = {'archive_file': 'evidence-redacted.zip', 'archive_sha256': sha(zipped), 'archive_bytes': len(zipped),
                'members': [{'path': n, 'sha256': sha(d), 'bytes': len(d)} for n, d in sorted(members.items())],
                'raw_and_saved_manifest': 'manifest.json', 'raw_hashmap': 'raw-hashmap.json',
                'credential_shape_scan': 'PASS', 'packager_sha256': sha(Path(__file__).read_bytes()),
                'expected_code_commit': code, 'expected_code_tree': tree}
    encoded = base64.b64encode(zipped).decode('ascii')
    b64 = ('\n'.join(encoded[i:i + 4096] for i in range(0, len(encoded), 4096)) + '\n').encode('ascii')
    metadata.update({'base64_file': 'evidence-redacted.base64.txt', 'base64_sha256': sha(b64), 'base64_bytes': len(b64)})
    outputs = {'execution-summary.json': members['execution-summary.json'], 'evidence-redacted.zip': zipped,
               'evidence-redacted.base64.txt': b64, 'archive-metadata.json': json_bytes(metadata)}
    ordinary(ROOT, True)
    destination = ROOT / 'public-evidence'
    destination.mkdir(exist_ok=False)
    for name, data in outputs.items():
        with (destination / name).open('xb') as f:
            f.write(data)
    print(json.dumps({'packaged': True, 'archive_sha256': sha(zipped), 'archive_bytes': len(zipped),
                      'members': len(members), 'all_gates_pass': summary['all_gates_pass']}))


if __name__ == '__main__':
    try:
        main()
    except (EvidenceError, OSError, ValueError, KeyError, TypeError) as exc:
        label = str(exc) if isinstance(exc, EvidenceError) else type(exc).__name__ + ': invalid or missing saved evidence'
        print(json.dumps({'packaged': False, 'error': label}), file=sys.stderr)
        raise SystemExit(1)
