# Job controller: независимое ревью запуска и завершения

## Оглавление

1. [Решение для ближайшего запуска](#1-решение-для-ближайшего-запуска)
2. [Authority и дочерние процессы](#2-authority-и-дочерние-процессы)
3. [Файлы, сроки и cleanup](#3-файлы-сроки-и-cleanup)
4. [Private Windows directory](#4-private-windows-directory)
5. [Приоритетное ревью run_followup.py](#5-приоритетное-ревью-run_followuppy)
6. [Аудит и остаток](#6-аудит-и-остаток)

## 1. Решение для ближайшего запуска

**В прочитанной композиции не найден дефект, который сам по себе запрещает один own-fixture Job run.** Перед запуском нужны конкретные caller inputs: два свежих executable из одного frozen source без trimpath; GUI subsystem тестового executable; private output parent **и private TEMP/TMP**; original controller process, удерживаемый вызывающим runner до его выхода. Это не runtime PASS.

Source pinned: #658 head `f755d374fab317e1037deecd5dac8ffabbcdde36`, tree `19056c7b39ed2f625cb7f0b5282343c92b3b3a48`. Проверены Git blobs 10 использованных controller/lifecycle/fixture файлов. Repository sources не изменялись; одна локальная source-копия сохранена с исходными CRLF для точного blob hash.

Конкретный layout для уже существующего root:

```text
<WORK_ROOT>\source
<WORK_ROOT>\evidence\job-entry-01
    test-job-entry.exe
    process.test.exe
    tmp\
    run-001\                  # отсутствует до controller launch
```

`job-entry-01` — новый private parent; `tmp` создаётся после проверки наследуемой DACL. Эти пути предлагаются, наличие не проверялось удалённо.

В source cwd, с существующим toolchain/cache и `GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off`:

```text
go build -mod=readonly -trimpath=false -o <private-parent>\test-job-entry.exe ./tools/test-job-entry
go test -mod=readonly -c -trimpath=false -ldflags="-H windowsgui" -o <private-parent>\process.test.exe ./internal/process
<private-parent>\test-job-entry.exe -test-binary <private-parent>\process.test.exe -source-dir <source>\internal\process -run-root <private-parent>\run-001 -timeout 90s
```

Последнему процессу передать `TEMP`, `TMP`, `TMPDIR` в `<private-parent>\tmp`. Controller не меняет эти env сам. Собственный внешний runner должен дать controller завершить 90 s work + до 10 s cleanup; больший внешний deadline, например 120 s после успешной подготовки файлов, не расширяет внутренний work budget. Прерывание самого controller означает отказ qualification, даже если Windows закроет его Job handle.

## 2. Authority и дочерние процессы

**Таблица 1. Границы действий по исходникам.**

| Место | Реальное действие | Ограничение |
| --- | --- | --- |
| `main_windows.go:152–169,232–268` | Проверка clean absolute paths, compiled checkout, actual binary/source hashes, GUI PE header | Source-dir должен совпадать с `runtime.Caller`; source freeze и build receipt нужны отдельно от хешей |
| `main_windows.go:203–229`; `owner_windows.go:30–48` | Новый собственный Job, ровно `KILL_ON_JOB_CLOSE`; повторное чтение native limits | Нет BREAKAWAY/SILENT_BREAKAWAY; чужой Job не принимается аргументом |
| `main_windows.go:393–407` | Один `process.test.exe`, фиксированные test args, cwd source/internal/process | Нет shell, process-name kill или передачи произвольного PID |
| `start_with_job_windows.go:156–165,191–239,274–294` | Job assignment внутри `CreateProcess`; разрешено наследование только 3 stdio handles; исходные process/thread handles передаются owner | Нет post-start Assign; Job handle не включён в child handle list |
| `owner_windows.go:61–114` | READY сопоставляется с original creation time, PID и единственным живым original Job member | GRANT не выдаётся по одному JSON assertion; observation закрывается с проверенной квитанцией |
| `main_windows.go:653–662` | Удаляются все наследуемые `MCPHUB_*`, добавляется только новый entry config | Старые helper modes не переключают тест на другой сценарий |

Primary source: [controller](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/main_windows.go#L152), [owner](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/owner_windows.go#L30), [at-create native start](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/process/start_with_job_windows.go#L156).

### Намеренно живущие потомки

Это не только один process:

- **Breakaway test:** запускает helper-parent внутри своего inner Job с BREAKAWAY_OK; helper запускает descendant из того же test executable с CREATE_BREAKAWAY_FROM_JOB. Тест проверяет, что descendant вышел из inner Job, сохранил принадлежность enclosing Job и остался жив после закрытия inner Job. После положительно подтверждённой передачи custody recipient выполняет `TerminateProcess` по удерживаемому проверенному handle, ждёт до 5 s и закрывает handle. Original helper-parent reap тоже проверяется. См. [job_options_windows_test.go:55–233](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/process/job_options_windows_test.go#L55).
- **Native typed/GC/creator test:** создаёт provisional helper-root и его обычного descendant, проверяет exit 17 root, удерживает descendant, затем выпускает его и проверяет естественный exit 0, закрытие файлов и creator settlement. См. [jobobject_windows_test.go:2251–2465](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/process/jobobject_windows_test.go#L2251).

Все эти executable — собственные копии одного freshly built process.test.exe. Observational PID opens сверяются по image и native birth; cleanup не ищет процессы по имени. Companion case имеет общий срок 30 s (`job_options_windows_test.go:370–378`); неопределённая передача custody не присваивает право очистки случайному участнику и оставляет отказ enclosing original Job owner.

При корректном own outer Job descendants не приобретают право уйти из него. Native runtime результат всё равно нужен: статическое чтение не доказывает успешность каждого Windows syscall.

## 3. Файлы, сроки и cleanup

Controller создаёт свежий `run-root` через `Mkdir`, открывает `os.Root`, эксклюзивно пишет:

```text
packet.json
entry-config.json
stdout.log
stderr.log
result.json
```

Он ничего не удаляет. Сами selected tests используют `t.TempDir()`: там появляются `case.json`, offer/decision/ack/control JSON, root/descendant output и локальные codec-фикстуры. Go testing очищает собственные temp directories после завершения; при аварии они могут остаться. Поэтому **защита одного run-root не защищает companion protocol files**, если TEMP/TMP продолжают указывать на другой каталог. Для run нужен private task temp внутри разрешённой области D. На C требуются только уже установленные toolchain/system executable reads.

[main_windows.go:296–370](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/main_windows.go#L296):

1. Work deadline начинается в `runFixture`, до pipe creation; допустимый timeout 1 s…5 min.
2. Local GRANT/ACK window — 8 s; receiver имеет свой 10 s handshake deadline.
3. Cleanup получает один срок `min(now + 10 s, workDeadline + 10 s)`.
4. Owner выполняет один original settlement. При failure возможна termination только его Job. При natural path любая потребовавшаяся terminal action превращает результат в FAIL.
5. Единственный original waiter должен вернуться до release. `ReleaseOriginal` отказывает освобождению live handles, если waiter не получен; это проверено в [start_with_job_original.go:83–114](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/process/start_with_job_original.go#L83).
6. После owner settlement закрывается stdin; незавершённый GRANT writer и stream workers присоединяются в тот же cleanup budget. Принудительно закрытый stream не считается EOF.

Native worker waiter использует `WaitForSingleObject(INFINITE)`, но находится в отдельной goroutine; конечность controller обеспечивают deadline-select и terminal settlement/backstop. При невозможности подтвердить cleanup controller возвращает failure; нельзя объявлять дерево завершённым только по controller exit.

У stderr нет обязательного условия «нулевая длина» внутри этого controller: требуются корректное чтение и EOF. Оба log streams ограничены 2 MiB, строка — 64 KiB, control frame — 8192 bytes. Success также требует ровно READY+ACK, original exit 0 и три обязательных PASS names: оба top-level tests и native subtest.

**Ограничения результата, не новые блокеры:**

- Hashing/preflight и синхронные Windows/filesystem calls не являются жёстко прерываемыми Go context. Сроки выше — программные budgets, не доказанная верхняя граница задержки ОС.
- `result.json.success` вычисляется **до** финальной записи/Sync/Close (`main_windows.go:178–188`). Поэтому принимать успех можно только вместе с controller exit 0 и полной settlement receipt. Нельзя читать один boolean и игнорировать внешний exit.
- Abrupt controller termination закрывает его handles как backstop, но уничтожает возможность получить обычную полную settlement receipt. Такой запуск остаётся FAIL/unqualified.
- Ни отдельная компиляция, ни unit tests controller не подменяют native run.

## 4. Private Windows directory

DACL — discretionary access-control list, список дискреционного управления доступом.

### Уже выполненный ранее способ без policy/module dependency

Локальные сохранённые источники:

- `r17/go-gate-triage-20261120/native-next/run_observation.py:111–172`, SHA-256 `8adb3fc9896e59afb9baf6835dbeb76143e3ccc97ec317d542b343ddce313ae1`;
- `.../run_negative_read.py:170–214`, SHA-256 `33d393d4becbf40fcb7657418df3298a5ff8dde179ba93ff7e5161160d67870d`.

Они запускают существующий WindowsPowerShell:

```text
powershell.exe -NoProfile -NonInteractive -Command <captured .NET directory ACL code>
```

Внутри — прямые .NET `WindowsIdentity.GetCurrent`, `DirectorySecurity`, `SetAccessRuleProtection(true,false)`, `Directory.SetAccessControl` / `GetAccessControl`; PowerShell модули и policy switch не используются. Разрешены current-token user, SYSTEM и Administrators с FullControl и наследованием ObjectInherit/ContainerInherit. До и после проверяется обычный directory, а readback требует точное число explicit ACE, отсутствие inherited/лишних ACE, ровные rights/inheritance/propagation. Имена/SID не печатаются.

Оба сохранённых evidence receipts дают `output_acl_verified=true`; шаг `prepare-output`: exit 0, stderr 0 bytes, stdout 21 bytes, SHA-256 **d463974d50fae033114eeab05f25132045d5c46697ccdb22613924931167c930**. Это подтверждает прежний ACL step, а не результат последующей Scheduler observation.

### Текущий более прямой native icacls путь root

В текущем `run_followup.py:115–139`:

```text
whoami.exe /user /fo csv /nh
icacls.exe <fresh-owned-parent> /inheritance:r /grant:r *<current-SID>:(OI)(CI)F *<SID>:(OI)(CI)F
icacls.exe <fresh-owned-parent> /save <fresh-owned-parent>\output.acl
```

Аргументы передаются как argv, без shell. Нет `/T`, owner change или системной policy mutation. Readback UTF-16LE требует protected DACL и ровно два ACE — current-token user и SYSTEM, FullAccess, ObjectInherit/ContainerInherit. Этот исходный вариант подходит для нового private parent; перед native test нельзя продолжать, если exact-DACL readback не прошёл. Новые `tmp` и `run-root` должны наследовать ACL этого parent.

Сам факт существования обычного каталога или Go mode 0700 DACL не заменяет.

## 5. Приоритетное ревью run_followup.py

Первый рассмотренный SHA-256: `9b6e2517813b832b4c3ff12b31ec8e937e875abf7a009c7817af3f2303bdb5ff`.

Найден один конкретный дефект evidence: `completed=True` устанавливался до final source check; ошибка внутри finally оставляла completed=true и не проходила через основной except. Сообщён root. В повторно прочитанном SHA-256 **eedc3167fa4cc1af80548b42f9dddc4d35cb73f8aa3339018c20f1de459915ed** исправлено: completed назначается после успешного final check; его ошибка сбрасывает completed и записывается отдельно (`171–177`). Python AST parse без выполнения — PASS.

Для одного intent trace новых конкретных блокеров после исправления не найдено. Source/head/tree проверяются до и после; env offline; private OUT DACL readback exact; stdout профилей сохраняется бинарно. Профили не являются текстом до команды `go tool pprof`.

Сохраняется **явно записанное ограничение**, не скрытое свойство: `run():72–87` удерживает/reap только direct child. При 300 s timeout команды `go test` убивается go.exe, но её ещё живые compiler/test children этим кодом не reaped. Runner честно записывает `whole_process_tree_deadline_enforced=false`. Сам `TestDaemonIntent_ConcurrentWrite` создаёт 8 goroutines × 12 writes и не порождает OS child. При внешнем timeout нужен отдельный observation собственных потомков либо разделённые compilation/direct-test stages; нельзя выдавать direct-child settlement за whole-tree proof.

### Дополнение: phases API receiving и Job entry

Повторно прочитан SHA-256 **a6ddab83b8b1ca1552ae1df0f4dffdefb3e096bda1e29884b4975bc9807cdd0c**, в частности новые строки 161–210. Конкретных новых blockers не найдено. API CLI получает tag и GUI subsystem, consumer получает точный binary digest. Job controller и test собираются без trimpath из одного source, run-root новый, внешний срок 120 s допускает внутренние 90 s + 10 s. Root проверяет controller exit 0, success, original wait, settlement, EOF и все три required PASS.

Свежий `OUT/tmp` теперь создаётся после exact-protected parent DACL; TEMP/TMP/TMPDIR/GOTMPDIR переключаются туда до сборок и test runs. **Отдельная protected DACL на каждом t.TempDir контрактом Job не требуется:** `loadJobFixtureCase`, строки 392–409, проверяет ordinary directory и связанный JSON, без проверки SE_DACL_PROTECTED. Наследование только current-user/SYSTEM OI/CI от проверенного private OUT к его свежим потомкам соответствует требованию private parent. Дополнительный policy/module механизм для каждого TempDir не нужен.

## 6. Аудит и остаток

**Аудит:** перечитаны controller main/owner полностью, at-create transfer и settlement implementation, обе выбранные native fixture ветви, текущий runner и два исторических DACL helpers. 10 использованных repository source файлов совпадают с pinned Git blobs. Секреты и private identity значения не выводились. Выполнялись только source reads, AST parse, hash checks и запись отчёта; remote/native/build/install/Git/publication не выполнялись.

**Остаток:**

1. Root проверяет actual private parent, fresh run-root и private task TEMP/TMP.
2. Подготавливает два exact-source executable без trimpath; проверяет GUI subsystem и сохраняет compilation receipt.
3. Выполняет один controller run с достаточным внешним cleanup window.
4. Принимает результат по exit code + original wait + EOF + required PASS + native settlement, без terminal action на success.
5. При отказе сохраняет evidence и точный незавершённый ownership статус; без image-name/process-tree sweeping. PR не вливать.

