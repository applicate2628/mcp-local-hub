# Квалифицированные входы API, CLI и Job: следующий конкретный шаг

## Оглавление

1. [Вывод и границы](#1-вывод-и-границы)
2. [API: принимающий CLI](#2-api-принимающий-cli)
3. [Job: существующий контроллер входа](#3-job-существующий-контроллер-входа)
4. [RunV5: собственный тестовый Product](#4-runv5-собственный-тестовый-product)
5. [Serena: два последовательных барьера](#5-serena-два-последовательных-барьера)
6. [Аудит и остаток](#6-аудит-и-остаток)

## 1. Вывод и границы

**Два отсутствовавших входа имеют конкретный путь подготовки уже в #658: принимающий CLI для API и исходный контроллер Windows Job.** Тест RunV5 требует другого исполняемого файла — собственного тестового Product; его producer остаётся в отдельном #657. Четырнадцать падений Serena требуют больше, чем замены подсистемы PE: старые manifest-фикстуры не соответствуют новому контракту подготовки.

Исследованы исходники `applicate2628/mcp-local-hub` на head **f755d374fab317e1037deecd5dac8ffabbcdde36**, tree **19056c7b39ed2f625cb7f0b5282343c92b3b3a48**, последний код **2cb467aac31259ed4fb665ed0a4f277a8f9c31a2**. Между code SHA и head изменялся только план. Снимки 35 файлов проверены по Git blob SHA-1; подробности в `source-manifest.json`. Это исходники, полученные через GitHub, без локального выполнения.

Фактические ошибки взяты из сохранённого `evidence/gates/tagged-api-cli.stdout.log`, архив SHA-256 **8d2b1958302cefe559953df2aacd7cef105a93f74428e2884224f87a9b994908**. Разбор 14 верхнеуровневых отказов Serena сохранён в `serena-failures.json`. Повторного запуска здесь не было.

**Таблица 1. Различные входы и ближайшее действие.**

| Потребитель | Точный вход | Что уже реализовано | Следующий шаг / недостающее условие |
| --- | --- | --- | --- |
| `TestAttachExisting_PublicCLIReceiving` | `MCPHUB_ATTACH_TEST_BIN`, `MCPHUB_ATTACH_TEST_BIN_SHA256` | Tagged CLI, тестовая изоляция состояния и IPC, принимающий тест | Проверить имеющийся бинарный файл и его происхождение; при отсутствии — подготовить tagged CLI из текущего source и отдельный API test executable |
| Job tests | `MCPHUB_JOB_FIXTURE_ENTRY_CONFIG` **выдаёт контроллер** | `tools/test-job-entry`, native READY/GRANT/ACK | Собрать контроллер и GUI test executable из одного frozen checkout, затем запустить существующий контроллер с fresh run-root |
| RunV5 unreadable intent | `MCPHUB_CANONICAL_ENTRY_FIXTURE`, собственный запущенный Product | Consumer в #658; producer отдельного command-test Product в #657 | Для нынешнего #658 отсутствует source-issued producer этого вида Product; не подставлять исполняемый файл #657 и не переносить его PASS |
| Serena migration, 14 тестов | Runtime Product + source-pinned preparation + publisher metadata + qualified tools | Реальный preparation pipeline; старые migration manifests | Сначала согласовать уровень теста: unit проверка оркестрации или реальная preparation квалификация. Последняя требует отсутствующих источников/инструментов и выполняет установку пакета |

Здесь API — программный интерфейс, CLI — интерфейс командной строки, IPC — межпроцессное взаимодействие, PE — Windows Portable Executable. GUI subsystem 2 — графическая подсистема, CUI subsystem 3 — консольная. SHA-256 — хеш содержимого; он связывает файл с ожидаемыми байтами, но сам по себе не удостоверяет происхождение компиляции.

## 2. API: принимающий CLI

### 2.1. Реальный контракт consumer

[Тест](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/api/attach_client_public_cli_receiving_windows_test.go#L30) существует только под `windows && test_state_path_env`. Он требует два непустых значения:

- `MCPHUB_ATTACH_TEST_BIN`: абсолютный путь; `Lstat` должен определить обычный файл.
- `MCPHUB_ATTACH_TEST_BIN_SHA256`: ожидаемый хеш; фактический SHA-256 обязан совпасть, без учёта регистра hex.

Этот consumer **не запрашивает** `MCPHUB_CANONICAL_ENTRY_FIXTURE` и не проверяет, что сам API test executable является Product. В [root.go](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/root.go#L60) ошибочная/отсутствующая canonical binding сохраняется только для публикующих Product команд. `attach-client` зарегистрирована отдельно и [использует обычный API](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/attach_client.go#L14). Поэтому у этого принимающего теста нет зависимости от #657.

TestMain API устанавливает default state fence, sandbox всех client adapters и отключает реальные destructive process/autostart seams. Сам receiving test создаёт private state с защищённым Windows DACL (списком управления доступом), новый HTTP listener и status IPC endpoint, связанные с собственным PID и временем создания процесса. [Tagged child init](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/cmd/mcphub/ipc_test_isolation_envfallback.go#L53) включает test pipe при непустом `MCPHUB_STATE_DIR_OVERRIDE`; [tagged state resolver](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/api/state_paths_envfallback.go#L57) использует override до системного каталога.

Перед каждым дочерним CLI запуском consumer повторно проверяет выбранный state root и точное тестовое pipe name. Шесть вызовов покрывают attach preview/apply/repeat и rollback preview/apply/repeat. Каждый ребёнок ограничен 15 s, ожидается через собственный `cmd.Wait()`; stderr должен быть пуст, exit code — 0. Тест сравнивает выбранный config, receipt, snapshot и хеши исключённых данных, проверяет фактического владельца своего listener до/после запусков. Это receiving CLI сценарий с имитированным status endpoint, **не доказательство полного жизненного цикла реального supervisor**.

### 2.2. Минимальная подготовка

Сначала root может проверить точный уже известный путь к существующему tagged binary и его receipt: source SHA, build arguments, SHA-256, наличие tag `test_state_path_env`. Один хеш неизвестного файла не доказывает tag/source.

Если такого файла нет, узкий контракт допускает компиляцию из frozen checkout:

```text
go build -mod=readonly -tags=test_state_path_env -ldflags="-H windowsgui" -o <private-output>\mcphub-attach-test.exe ./cmd/mcphub
go test -mod=readonly -c -tags=test_state_path_env -o <private-output>\api.test.exe ./internal/api
```

Это предлагаемые аргументы, **не выполненные команды**. `-H windowsgui` предотвращает появление CUI executable для receiving child; это не заменяет canonical Product qualification. Оба пути вывода, временные файлы и Go caches должны оставаться внутри уже разрешённой области `<OWNED_WORK_ROOT>`. Применимы только существующий toolchain и module cache: `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`. При отсутствии dependency в cache остановиться, не устанавливать её.

Более полный существующий producer — [build.ps1](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/build.ps1#L24):

```text
pwsh -NoProfile -File build.ps1 -TestStateIsolatedProduct -OutputDirectory <absolute-frozen-source>\.scratch\<fresh-output>
```

Он выдаёт обычный tagged GUI Product из `./cmd/mcphub`, launcher и identity. Его `mcphub-product\mcphub.exe` подходит для того же receiving consumer. Этот путь требует доступного cached goversioninfo и разрешённого текущей политикой выполнения скрипта. Параметр обхода политики или изменение политики не нужны и не предлагаются. Source-issued builder не следует смешивать с command-test mode из #657.

После подготовки минимальный scoped run:

```text
api.test.exe -test.run ^TestAttachExisting_PublicCLIReceiving$ -test.v -test.count=1 -test.timeout=90s
```

Точные абсолютные `MCPHUB_ATTACH_TEST_BIN` и digest передаются только собственному запуску. Нужен уже используемый root runner с сохранением stdout/stderr, exit code и завершения своих процессов. Нельзя выдавать успех этого теста за успех всего tagged API/CLI набора.

## 3. Job: существующий контроллер входа

### 3.1. Конфигурация является результатом протокола

[README исходного контроллера](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/README.md) даёт работающий producer; создавать JSON вручную не требуется. Входной JSON consumer проверяет exact binary hash, четыре companion source hashes, абсолютный sourceDir, run/nonce, packet digest и outer Job flags. Затем [receiveJobFixtureEntry](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/process/jobobject_windows_test.go#L809) выполняет READY/GRANT/ACK с новым challenge, фактическим временем создания процесса и 10 s deadline. JSON без исходного живого owner этого протокола не создаёт.

[Controller](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/main_windows.go#L152) связывает executable, sourceDir, собственные main/owner исходники и packet. Test source companions:

- `jobobject_windows.go`;
- `current_job_windows.go`;
- `jobobject_windows_test.go`;
- `job_options_windows_test.go`.

[Owner](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/tools/test-job-entry/owner_windows.go#L30) создаёт собственный Job с `KILL_ON_JOB_CLOSE`, без `BREAKAWAY_OK` и `SILENT_BREAKAWAY_OK`, назначает процесс в Job **при создании**, удерживает original process/thread handles и проверяет native limits/member observations. Контроллер очищает наследуемые `MCPHUB_*`, затем выдаёт собственный `MCPHUB_JOB_FIXTURE_ENTRY_CONFIG`.

### 3.2. Минимальные точные аргументы

Из **одного абсолютного frozen checkout**, без `-trimpath`:

```text
go build -mod=readonly -trimpath=false -o <private-artifacts>\test-job-entry.exe ./tools/test-job-entry
go test -mod=readonly -c -trimpath=false -ldflags="-H windowsgui" -o <private-artifacts>\process.test.exe ./internal/process
<private-artifacts>\test-job-entry.exe -test-binary <private-artifacts>\process.test.exe -source-dir <frozen-source>\internal\process -run-root <private-parent>\<fresh-run> -timeout 90s
```

Пути — placeholders для root, все внутри `<OWNED_WORK_ROOT>`; команды здесь не выполнялись. Parent каталога должен уже иметь private Windows ACL; Go `0700` этого не доказывает. Run-root должен **не существовать**, поскольку контроллер создаёт его через `Mkdir`. Необходимо убрать внешний `-trimpath` из compiler flags: consumer сопоставляет `runtime.Caller` с sourceDir. Контроллер явно отказывает CUI subsystem 3: вспомогательный conhost может нарушить число членов Job даже при CREATE_NO_WINDOW.

Контроллер сам выбирает только:

```text
^Test(Job_BreakawayEnabledDescendantEscapesClose|JobInformationTransportPreparationBoundary)$
```

Для PASS нужны оба top-level tests и native subtest, исходный процесс с exit 0, EOF на обоих streams, все собственные члены Job завершены, handles закрыты и **не было terminal action**. Успешная аварийная очистка после failure не превращает run в PASS. Work deadline допускается до 5 min, cleanup — до 10 s. Один файл `result.json` без сверки этих полей недостаточен.

**Непосредственное недостающее условие:** два compiled artifacts из одного текущего checkout + private fresh output + запуск самого существующего controller. Никакой новой политики Windows, установки или доступа к чужому process tree контракт не требует.

## 4. RunV5: собственный тестовый Product

[TestRunV5UpgradeWindows_UnreadableIntentAbortsUpgrade](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/install_migration_wiring_windows_test.go#L386) требует абсолютный путь `MCPHUB_CANONICAL_ENTRY_FIXTURE`. [Строгий consumer](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/upgrade_gui_qualified_fixture_windows_test.go#L27) читает только один JSON object без неизвестных полей:

```text
product_root, source_epoch, product_version, build_id, reverse_projection,
canonical_entry_sha256, product_sha256, identity_sha256
```

Далее проверяются полный canonical entry set, build binding, metadata и hashes; native acquisition удерживает исходные файлы. Отдельно `os.Executable()`, путь Product и `os.SameFile` должны совпасть; хеш реально исполняемого файла тоже проверяется. Значение `MCPHUB_CANONICAL_FIXTURE_TEST_PRODUCT=1` разрешает только отсутствие publisher source epoch, не ослабляя native/file binding.

Текущий #658 `build.ps1` не имеет `CanonicalEntryCommandTestProduct`: `TestStateIsolatedProduct` строит `./cmd/mcphub`, тогда как consumer должен исполняться внутри `go test -c ./internal/cli` Product.

**Владелец уже есть:** [Draft #657](https://github.com/applicate2628/mcp-local-hub/pull/657), head **4fa52b60b719664ede441be339e196a8b9766c50**. Он добавляет test-only mode:

```text
-TestStateIsolatedProduct -CanonicalEntryCommandTestProduct -OutputDirectory <isolated-.scratch-output>
```

Producer выпускает `windows-canonical-command-test-fixture.json` только после наблюдения полного набора и actual hashes. [Runbook текущего #658](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/docs/agent-runbook.md#L413) прямо относит это к отдельной ветке. Уже зафиксирован scoped native PASS ровно на #657 head; повторять неизменённый run только ради нового отчёта не требуется.

**Конкретно отсутствует:** producer данного command-test Product на current #658 source. Файл #657 не переносит доказательство: его test executable содержит тесты и код #657, а ссылка на него из обычного #658 cli.test.exe провалит self-identity. Переносить/интегрировать #657 здесь запрещено; новый дублирующий PR не нужен.

## 5. Serena: два последовательных барьера

### 5.1. Что доказал свежий лог

**Таблица 2. Первые диагностические причины 14 top-level migration failures.**

| Число | Первый барьер | Причина по текущим исходникам |
| --- | --- | --- |
| 13 | `E_RUNTIME_PRODUCT_IMAGE → E_WINDOWS_PE_SUBSYSTEM`, expected 2, actual 3 | Реальный preflight видит консольный `cli.test.exe` |
| 1 | `TestMigrateSerena_CallsInstallParsedManifest_NotDiskWrite → SERENA_BUILD_SOURCE_INVALID` | Этот тест уже применяет `canonicalRuntimeFixture: true`; выполнение проходит прежний барьер и упирается в неподходящий build source |

Вторичные сообщения про rollback, registry или supervisor start появляются после преждевременного отказа подготовки. Они сами по себе не доказывают дефект соответствующего post-commit алгоритма. Диагностическая подсказка `mcphub setup` из лога не является разрешением установки и здесь не исполнялась.

### 5.2. Точная цепочка

[Default migrate operation](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/migrate_serena.go#L462) теперь создаёт API с реальной Serena preparation assembly. Перед supervisor cutover вызывается `PrepareSerenaParsedInstall`; [API](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/api/serena_parsed_preparation.go#L31) сначала делает runtime Preflight, затем plan/frozen manifest/tasks, затем build preparation.

[Общая migration fixture](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/migrate_serena_test.go#L231) кладёт инертный пустой `mcphub.exe` и только при `canonicalRuntimeFixture: true` включает существующий test hook для canonical path. Она не создаёт настоящий GUI Product. Большинство 13 отказов не задаёт этот option; CallsInstall задаёт его уже сейчас.

Общие manifest literals [legacy2DaemonManifestYAML / alreadyMigratedManifestYAML](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/migrate_serena_test.go#L394) используют `command: go` как дешёвую binary-presence фикстуру и `git+https://example/serena` без `@<commit>`. [Parser build source](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/api/serena_build_environment_source.go#L71) требует HTTPS source с host/path, без credentials/query/fragment, и suffix из ровно 40 lowercase hex после последнего `@`. Отсутствие `@` непосредственно объясняет `SERENA_BUILD_SOURCE_INVALID`.

Замена строки на выдуманный commit не делает preparation квалифицированной. [Дальнейшие входы](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/api/serena_prepared_inputs.go#L125) требуют:

- действительный source epoch от `buildinfo.CurrentPublisherSource()`, связанный с compiled version/commit/date;
- bootstrap environment SYSTEMROOT/WINDIR/COMSPEC/PATH и согласованные source/consumer credentials;
- собственные metadata/state namespace owners;
- найденный и проверенный существующий uv;
- существующий qualified Python, ABI и launcher;
- actual owned-process qualification и реальную команду `uv tool install --python ... --no-python-downloads --no-config --from <pinned-source> ... serena-agent`.

[buildinfo](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/buildinfo/buildinfo.go#L43) отвергает пустой source epoch, version dev/unknown и неподходящий commit/date. Отдельный publisher-source путь builder принимает проверенный `SourceSnapshotPath`; `TestStateIsolatedProduct` с ним **несовместим**. Следовательно, ни GUI linker flag, ни #657 test-only fixture не выполняют всю эту цепочку.

### 5.3. Минимальный следующий шаг

Для текущей задачи без установки ближайший полезный шаг — **исправить контракт migration tests на уровне тестируемой ответственности**, отдельно от runtime preparation. Существующие typed `newInstallAPI` / `newInstallOperation` dependencies дают точку разделения. Уже есть [preparation-refusal tests](https://github.com/applicate2628/mcp-local-hub/blob/f755d374fab317e1037deecd5dac8ffabbcdde36/internal/cli/migrate_serena_preparation_test.go), проверяющие запрет cutover после ошибки подготовки.

Нужен отдельный минимальный patch: unit tests оркестрации явно используют контролируемую preparation/install dependency и проверяют реальный контракт своих cutover/registry действий. Такие тесты должны описываться как unit проверки. Они не доказывают successful real prepared install. Два нынешних теста, явно заявляющих REAL install (`CatalogDynamicPool_RuntimeLegacyMissing_Proceeds` и `CallsInstallParsedManifest_NotDiskWrite`), нельзя сделать «зелёными» общей noop preparation и сохранить прежнюю декларацию.

Если целью остаётся именно real prepared install, недостаёт **source-issued publisher build, действительного закреплённого Serena source и квалифицированных uv/Python/package inputs**, а сам положительный путь включает установку. Это иной запуск, для которого текущего поручения «без установки» недостаточно. Здесь не менялись проверки production и не изготавливался фальшивый positive ticket.

## 6. Аудит и остаток

### Аудит

- Прочитаны repository AGENTS на текущем head, релевантные части runbook, навыки Go project/API design, testing/verification и debugging/error recovery.
- 35 локальных source-копий проверена по Git blob; 0 несовпадений. SHA-256 каждой записан в manifest.
- Отдельно пересчитана SHA-256 исходного архива логов; 14 Serena failures разобраны программно: 13 PE и 1 source.
- Parent получил конкретные API/Job preparation routes и отсутствие зависимости API от #657.
- Native процессы, Go build/test, установка, Windows/Remote Desktop, Git mutation и публикация не выполнялись.
- #657 и #660 не копировались и не интегрировались. Текущие источники взяты только по pinned #658 head; #657 использован как существующий отдельный owner по PR metadata и runbook.
- Результаты анализа сохранены только в выданной папке `qualified-inputs`. Секреты и private configuration не читались/не печатались.
- Исходный consumer код проверен собственным чтением; runtime свойства остаются непроверенными в этом анализе.

### Остаток плана для root

1. По точным разрешённым Windows-путям проверить существующие source checkout, private output, Go toolchain/cache и ранее подготовленные receiving/Job artifacts; сверить их источник и hash.
2. При готовых prerequisites провести один scoped receiving run и/или исходный Job-controller run, с original-process ownership и сохранением результата. Успех этих tests не заменяет два полных Go gates.
3. RunV5 оставить за существующим owner #657 до появления разрешённого source-compatible producer для текущего source; не переносить чужую qualification.
4. В отдельной небольшой зоне ответственности подготовить correction migration test contract; для real prepared install явно сохранить список отсутствующих source/tool/package условий.
5. Проверить затронутые случаи после фактической правки, выполнить собственное ревью; PR не вливать.

