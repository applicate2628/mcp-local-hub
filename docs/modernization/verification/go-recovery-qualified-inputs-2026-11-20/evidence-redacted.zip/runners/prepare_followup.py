"""Prepare an isolated checkout and observe toolchain/policy without changing policy."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(r'<WORK_ROOT>')
OLD = Path(r'<OWNED_WORK_ROOT>\mcp-go-state-isolation-20261120\source')
SOURCE = ROOT / 'source'
HEAD = 'f755d374fab317e1037deecd5dac8ffabbcdde36'
TREE = '19056c7b39ed2f625cb7f0b5282343c92b3b3a48'
OLD_HEAD = '2cb467aac31259ed4fb665ed0a4f277a8f9c31a2'
GIT = Path(r'<PATH> Files\Git\cmd\git.exe')
GO = Path(r'<GO_BIN>\go.exe')
OUT = ROOT / 'prepare'
RUNTIME = ROOT / 'runtime'

if sys.flags.optimize:
    raise SystemExit('optimized execution is unsupported')
OUT.mkdir(exist_ok=False)
for part in ('tmp', 'profile', 'appdata', 'localappdata', 'gopath', 'gocache', 'empty-hooks'):
    (RUNTIME / part).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off',
    'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off', 'GOMAXPROCS': '4',
    'CGO_ENABLED': '1', 'CC': str(GO.with_name('gcc.exe')),
    'GOCACHE': str(RUNTIME / 'gocache'),
    'GOMODCACHE': r'<OWNED_WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache',
    'GOPATH': str(RUNTIME / 'gopath'), 'MCPHUB_NO_AUTO_GUI': '1',
    'MCPHUB_E2E_SCHEDULER': 'none', 'USERPROFILE': str(RUNTIME / 'profile'),
    'APPDATA': str(RUNTIME / 'appdata'), 'LOCALAPPDATA': str(RUNTIME / 'localappdata'),
    'TEMP': str(RUNTIME / 'tmp'), 'TMP': str(RUNTIME / 'tmp'),
    'TMPDIR': str(RUNTIME / 'tmp'), 'GOTMPDIR': str(RUNTIME / 'tmp'),
    'PSModuleAnalysisCachePath': str(RUNTIME / 'localappdata/module-analysis-cache'),
    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(RUNTIME / 'no-global-git-config'),
    'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / 'System32'), str(GIT.parent)))
receipt = {'phase': 'prepare', 'expected_head': HEAD, 'expected_tree': TREE,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'system_policy_changed': False, 'software_installed': False,
           'branches_integrated': False, 'whole_process_tree_deadline_enforced': False}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def run(name, executable, arguments, cwd=ROOT, timeout=90):
    record = {'name': name, 'executable': executable.name, 'arguments': arguments,
              'direct_child_deadline_seconds': timeout, 'settled': False}
    receipt['commands'].append(record)
    save()
    started = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen([str(executable), *arguments], cwd=cwd, env=env,
                                 stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                 creationflags=0x08000000)
        try:
            record['pid'] = child.pid
            save()
            child.wait(timeout=max(0, timeout - (time.monotonic() - started)))
        finally:
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, timeout - (time.monotonic() - started)))
                except subprocess.TimeoutExpired:
                    record['deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            record['exit_code'] = child.returncode
            record['settled'] = child.returncode is not None
            record['seconds'] = round(time.monotonic() - started, 6)
            save()
    for stream in ('stdout', 'stderr'):
        data = (OUT / (name + '.' + stream + '.log')).read_bytes()
        record[stream + '_bytes'] = len(data)
        record[stream + '_sha256'] = digest(data)
    save()
    if record['exit_code'] != 0 or record.get('deadline_hit'):
        raise RuntimeError('command failed: ' + name)
    return (OUT / (name + '.stdout.log')).read_text(encoding='utf-8').strip()

def git(name, directory, *arguments):
    return run(name, GIT, ['-c', 'core.hooksPath=' + str(RUNTIME / 'empty-hooks'),
                         '-c', 'core.fsmonitor=false', '-C', str(directory), *arguments])

try:
    receipt['script_sha256'] = digest(Path(__file__).read_bytes())
    if SOURCE.exists():
        raise RuntimeError('source destination already exists')
    if Path(git('old-root', OLD, 'rev-parse', '--show-toplevel')).resolve() != OLD.resolve():
        raise RuntimeError('old repository root mismatch')
    if git('old-head', OLD, 'rev-parse', 'HEAD') != OLD_HEAD:
        raise RuntimeError('old head changed')
    if git('old-status', OLD, 'status', '--porcelain=v1', '--untracked-files=all'):
        raise RuntimeError('old source is dirty')
    run('clone', GIT, ['-c', 'core.hooksPath=' + str(RUNTIME / 'empty-hooks'),
                      'clone', '--no-hardlinks', '--no-checkout', str(OLD), str(SOURCE)])
    git('fetch', SOURCE, 'fetch', '--no-tags', 'https://github.com/applicate2628/mcp-local-hub.git', HEAD)
    if git('fetched-tree', SOURCE, 'rev-parse', HEAD + '^{tree}') != TREE:
        raise RuntimeError('fetched tree mismatch')
    git('checkout', SOURCE, 'checkout', '--detach', HEAD)
    receipt['head'] = git('head', SOURCE, 'rev-parse', 'HEAD')
    receipt['tree'] = git('tree', SOURCE, 'rev-parse', 'HEAD^{tree}')
    receipt['status'] = git('status', SOURCE, 'status', '--porcelain=v1', '--untracked-files=all')
    if receipt['head'] != HEAD or receipt['tree'] != TREE or receipt['status']:
        raise RuntimeError('checkout binding failed')
    receipt['go_version'] = run('go-version', GO, ['version'], cwd=SOURCE)
    receipt['gomodcache_present'] = Path(env['GOMODCACHE']).is_dir()
    selected_ps = Path(shutil.which('pwsh.exe', path=env['PATH']) or shutil.which('powershell.exe', path=env['PATH']) or '')
    if not selected_ps.is_file():
        raise RuntimeError('selected PowerShell not found')
    receipt['powershell_host'] = selected_ps.name
    policy_command = "[pscustomobject]@{Version=$PSVersionTable.PSVersion.ToString(); Effective=(Get-ExecutionPolicy).ToString(); Scopes=@(Get-ExecutionPolicy -List | ForEach-Object {[pscustomobject]@{Scope=$_.Scope.ToString(); Policy=$_.ExecutionPolicy.ToString()}})} | ConvertTo-Json -Depth 4 -Compress"
    receipt['powershell_policy'] = json.loads(run('powershell-policy', selected_ps, ['-NoProfile', '-NonInteractive', '-Command', policy_command], timeout=20))
    receipt['disk_free_bytes'] = shutil.disk_usage(ROOT).free
    receipt['completed'] = True
except Exception as exc:
    receipt['error_class'] = type(exc).__name__
    receipt['error'] = str(exc)
    raise
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps({k: receipt[k] for k in ('head', 'tree', 'go_version', 'powershell_host', 'powershell_policy', 'disk_free_bytes', 'completed')}))
