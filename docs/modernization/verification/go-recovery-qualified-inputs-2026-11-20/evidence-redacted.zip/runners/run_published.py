"""Bounded, offline Windows probes on the already prepared, pinned checkout."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path(r'<WORK_ROOT>')
SOURCE = ROOT / 'source'
RUNTIME = ROOT / 'runtime'
HEAD = 'f755d374fab317e1037deecd5dac8ffabbcdde36'
TREE = '19056c7b39ed2f625cb7f0b5282343c92b3b3a48'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<PATH> Files\Git\cmd\git.exe')
PHASE = sys.argv[1]
if PHASE != 'published' or len(sys.argv) != 4 or sys.flags.optimize:
    raise SystemExit('Unsupported phase or optimized execution')
OUT = ROOT / 'evidence' / PHASE
OUT.mkdir(parents=True, exist_ok=False)

env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off',
    'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off', 'GOMAXPROCS': '4',
    'CGO_ENABLED': '1', 'CC': str(GO.with_name('gcc.exe')),
    'GOCACHE': str(RUNTIME / 'gocache'),
    'GOMODCACHE': r'<OWNED_WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache',
    'GOPATH': str(RUNTIME / 'gopath'), 'MCPHUB_NO_AUTO_GUI': '1',
    'MCPHUB_E2E_SCHEDULER': 'none', 'USERPROFILE': str(RUNTIME / 'profile'),
    'APPDATA': str(RUNTIME / 'appdata'), 'LOCALAPPDATA': str(RUNTIME / 'localappdata'),
    'TEMP': str(RUNTIME / 'tmp'), 'TMP': str(RUNTIME / 'tmp'),
    'TMPDIR': str(RUNTIME / 'tmp'), 'GOTMPDIR': str(RUNTIME / 'tmp'),
    'PSModuleAnalysisCachePath': str(RUNTIME / 'localappdata/module-analysis-cache'),
    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(RUNTIME / 'no-global-git-config'),
    'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / 'System32'), str(GIT.parent)))
receipt = {'phase': PHASE, 'expected_head': HEAD, 'expected_tree': TREE,
           'completed': False,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'system_policy_changed': False, 'software_installed': False,
           'branches_integrated': False, 'whole_process_tree_deadline_enforced': False,
           'environment': {k: env[k] for k in ('GOENV', 'GOTOOLCHAIN', 'GOPROXY',
               'GOSUMDB', 'GOVCS', 'GOWORK', 'GOFLAGS', 'GOTELEMETRY', 'GOMAXPROCS',
               'CGO_ENABLED', 'MCPHUB_NO_AUTO_GUI', 'MCPHUB_E2E_SCHEDULER')}}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def run(name, executable, arguments, timeout=30, cwd=SOURCE, extra_env=None, allowed_exit_codes=(0,)):
    child_env = dict(env)
    child_env.update(extra_env or {})
    rec = {'name': name, 'executable': str(executable), 'arguments': arguments,
           'environment_delta': extra_env or {},
           'direct_child_deadline_seconds': timeout, 'settled': False,
           'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(rec)
    save()
    print('START ' + name, flush=True)
    started = time.monotonic()
    try:
        with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen([str(executable), *arguments], cwd=cwd, env=child_env,
                                     stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                     creationflags=0x08000000)
            try:
                rec['pid'] = child.pid
                save()
                child.wait(timeout=max(0, timeout - (time.monotonic() - started)))
            except subprocess.TimeoutExpired:
                rec['direct_child_deadline_hit'] = True
                raise
            finally:
                if child.poll() is None:
                    child.kill()
                    child.wait(timeout=15)
                rec['exit_code'] = child.returncode
                rec['settled'] = child.returncode is not None
    finally:
        rec['seconds'] = round(time.monotonic() - started, 6)
        for stream in ('stdout', 'stderr'):
            path = OUT / (name + '.' + stream + '.log')
            if path.exists():
                rec[stream + '_bytes'] = path.stat().st_size
                rec[stream + '_sha256'] = digest(path)
        save()
        print(json.dumps({k: rec[k] for k in ('name', 'exit_code', 'seconds', 'settled') if k in rec}), flush=True)
    if rec['exit_code'] not in allowed_exit_codes:
        raise RuntimeError('Command failed: ' + name)
    return (OUT / (name + '.stdout.log')).read_bytes()

def git(name, *args):
    return run(name, GIT, ['-c', 'core.hooksPath=' + str(RUNTIME / 'empty-hooks'),
                          '-c', 'core.fsmonitor=false', '-C', str(SOURCE), *args], timeout=90 if args[0] == 'fetch' else 30).decode('utf-8').rstrip('\r\n')

TEST_PATH = 'internal/cli/gui_force_test.go'
BASELINE_SHA256 = '8b4e569a3b57691e338235c5690a967982bb61206d57dc91683ad5c869e106cb'
CANDIDATE_SHA256 = 'db019916c49da6c5be02298559690b368e431e0c01feb95a786add30b875eba8'

def verify_source(label, candidate=False, expected_head=HEAD, expected_tree=TREE):
    actual = {'head': git(label + '-head', 'rev-parse', 'HEAD'),
              'tree': git(label + '-tree', 'rev-parse', 'HEAD^{tree}'),
              'status': git(label + '-status', 'status', '--porcelain=v1', '--untracked-files=all')}
    receipt['source_' + label] = actual
    save()
    expected = {'head': expected_head, 'tree': expected_tree, 'status': ' M ' + TEST_PATH if candidate else ''}
    if actual != expected:
        raise RuntimeError('Source binding changed: ' + label)
    if candidate:
        if digest(SOURCE / TEST_PATH) != CANDIDATE_SHA256 or git(label + '-index', 'diff', '--cached', '--name-only'):
            raise RuntimeError('Candidate file or untouched index binding changed')

def protect_output():
    # Only this freshly created directory: no recursion and no system policy change.
    who = run('output-owner', system / 'System32/whoami.exe', ['/user', '/fo', 'csv', '/nh'])
    sids = re.findall(rb'S-1-5-(?:[0-9]+-)*[0-9]+', who)
    if len(sids) != 1:
        raise RuntimeError('Cannot identify exactly one current token user SID')
    sid = sids[0].decode('ascii')
    icacls = system / 'System32/icacls.exe'
    run('output-protect', icacls, [str(OUT), '/inheritance:r', '/grant:r',
        '*' + sid + ':(OI)(CI)F', '*<SID>:(OI)(CI)F'])
    run('output-acl-save', icacls, [str(OUT), '/save', str(OUT / 'output.acl')])
    # icacls /save on this Windows host emits UTF-16LE without a BOM.
    acl = (OUT / 'output.acl').read_text(encoding='utf-16-le').lstrip('\ufeff')
    lines = [line for line in acl.splitlines() if line]
    if len(lines) != 2:
        raise RuntimeError('Unexpected ACL save representation')
    descriptor = lines[1]
    prefix, _, _ = descriptor.partition('(')
    entries = re.findall(r'\(([^()]+)\)', descriptor)
    expected = {'A;OICI;FA;;;' + sid, 'A;OICI;FA;;;SY'}
    if not prefix.startswith('D:P') or len(entries) != 2 or set(entries) != expected:
        raise RuntimeError('Fresh output DACL is not private/protected/full-access as expected')
    receipt['output_dacl'] = {'protected': True, 'allowed': ['current-token-user', 'LocalSystem'],
                              'verified_acl_sha256': digest(OUT / 'output.acl')}
    save()

published_head, published_tree = sys.argv[2:]
if not all(re.fullmatch('[0-9a-f]{40}', value) for value in (published_head, published_tree)):
    raise SystemExit('Exact published commit/tree are required')
receipt.update({'base_head': HEAD, 'base_tree': TREE,
                'expected_head': published_head, 'expected_tree': published_tree})

try:
    receipt['runner_sha256'] = digest(Path(__file__))
    receipt['go_executable_sha256'] = digest(GO)
    gates = json.loads((ROOT / 'evidence/gates/receipt.json').read_text(encoding='utf-8'))
    expected_source = {'head': HEAD, 'tree': TREE, 'status': ' M ' + TEST_PATH}
    commands = {c['name']: c for c in gates['commands']}
    if (gates.get('completed') is not True or gates.get('source_after') != expected_source
            or not all(commands.get(name, {}).get('settled') is True for name in ('build', 'vet', 'full-test', 'tagged-api-cli'))
            or any(c.get('direct_child_deadline_hit') for c in gates['commands'])):
        raise RuntimeError('Required gate execution has not completed')
    # Gate failures remain recorded. This follow-up proves only the selected
    # tests on the separately authorized, published single-parent change.
    receipt['gates_receipt_sha256'] = digest(ROOT / 'evidence/gates/receipt.json')
    verify_source('before', candidate=True)
    protect_output()
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=False)
    env.update({key: str(tmp) for key in ('TEMP', 'TMP', 'TMPDIR', 'GOTMPDIR')})
    receipt['private_temp_parent'] = str(tmp)
    receipt['go_version'] = run('go-version', GO, ['version']).decode('utf-8').strip()
    git('fetch-published', 'fetch', '--no-tags', 'https://github.com/applicate2628/mcp-local-hub.git', published_head)
    receipt['published_parents'] = git('published-parents', 'show', '-s', '--format=%P', published_head).split()
    receipt['published_changed_paths'] = git('published-paths', 'diff', '--name-only', HEAD, published_head).splitlines()
    target_tree = git('published-target-tree', 'rev-parse', published_head + '^{tree}')
    target_blob = git('published-blob', 'rev-parse', published_head + ':' + TEST_PATH)
    if (receipt['published_parents'] != [HEAD] or receipt['published_changed_paths'] != [TEST_PATH]
            or target_tree != published_tree or target_blob != '06ec8f6d6a624dce040390532bda824b2553b46a'):
        raise RuntimeError('Published parent/tree/single-file binding differs')
    git('stage-candidate', 'add', '--', TEST_PATH)
    receipt['prepared_tree'] = git('prepared-tree', 'write-tree')
    if receipt['prepared_tree'] != published_tree:
        raise RuntimeError('Prepared index differs from published tree')
    git('checkout-published', 'checkout', '--detach', published_head)
    verify_source('published', expected_head=published_head, expected_tree=published_tree)
    if digest(SOURCE / TEST_PATH) != CANDIDATE_SHA256:
        raise RuntimeError('Published candidate working bytes changed')
    selector = '^(TestForce_KillHappyPath_SeamMocked|TestForce_KillRefusesNonMcphubImage|TestKillRecordedHolder_CancelledContextRefusesKill)$'
    output = run('published-race', GO, ['test', '-mod=readonly', '-race', '-count=2', '-timeout=120s',
        '-json', '-run=' + selector, './internal/cli', './internal/gui'], timeout=600)
    events = [json.loads(line) for line in output.decode('utf-8').splitlines()]
    receipt['test_runs'] = {'published-race': [e for e in events if e.get('Action') in ('pass', 'fail', 'skip')]}
    required = [('mcp-local-hub/internal/cli', 'TestForce_KillHappyPath_SeamMocked'),
                ('mcp-local-hub/internal/cli', 'TestForce_KillRefusesNonMcphubImage'),
                ('mcp-local-hub/internal/gui', 'TestKillRecordedHolder_CancelledContextRefusesKill')]
    passes = [(e.get('Package'), e.get('Test')) for e in events if e.get('Action') == 'pass']
    if any(passes.count(pair) != 2 for pair in required) or any(e.get('Action') in ('fail', 'skip') for e in events):
        raise RuntimeError('Published focused race verification incomplete or unsuccessful')
except Exception as exc:
    receipt['error_class'], receipt['error'] = type(exc).__name__, str(exc)
    raise
finally:
    try:
        verify_source('after', expected_head=published_head, expected_tree=published_tree)
        if digest(SOURCE / TEST_PATH) != CANDIDATE_SHA256:
            raise RuntimeError('Published test file changed after verification')
        receipt['completed'] = 'error' not in receipt
    except Exception as exc:
        receipt['completed'] = False
        receipt['final_source_error_class'], receipt['final_source_error'] = type(exc).__name__, str(exc)
        raise
    finally:
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save()

