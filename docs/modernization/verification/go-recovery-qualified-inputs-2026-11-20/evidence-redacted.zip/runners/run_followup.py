"""Bounded, offline Windows probes on the already prepared, pinned checkout."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path(r'<WORK_ROOT>')
SOURCE = ROOT / 'source'
RUNTIME = ROOT / 'runtime'
HEAD = 'f755d374fab317e1037deecd5dac8ffabbcdde36'
TREE = '19056c7b39ed2f625cb7f0b5282343c92b3b3a48'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<PATH> Files\Git\cmd\git.exe')
PHASE = sys.argv[1]
if PHASE != 'intent-trace-01' or sys.flags.optimize:
    raise SystemExit('Unsupported phase or optimized execution')
OUT = ROOT / 'evidence' / PHASE
OUT.mkdir(parents=True, exist_ok=False)

env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off',
    'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off', 'GOMAXPROCS': '4',
    'CGO_ENABLED': '1', 'CC': str(GO.with_name('gcc.exe')),
    'GOCACHE': str(RUNTIME / 'gocache'),
    'GOMODCACHE': r'<OWNED_WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache',
    'GOPATH': str(RUNTIME / 'gopath'), 'MCPHUB_NO_AUTO_GUI': '1',
    'MCPHUB_E2E_SCHEDULER': 'none', 'USERPROFILE': str(RUNTIME / 'profile'),
    'APPDATA': str(RUNTIME / 'appdata'), 'LOCALAPPDATA': str(RUNTIME / 'localappdata'),
    'TEMP': str(RUNTIME / 'tmp'), 'TMP': str(RUNTIME / 'tmp'),
    'TMPDIR': str(RUNTIME / 'tmp'), 'GOTMPDIR': str(RUNTIME / 'tmp'),
    'PSModuleAnalysisCachePath': str(RUNTIME / 'localappdata/module-analysis-cache'),
    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(RUNTIME / 'no-global-git-config'),
    'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / 'System32'), str(GIT.parent)))
receipt = {'phase': PHASE, 'expected_head': HEAD, 'expected_tree': TREE,
           'completed': False,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'system_policy_changed': False, 'software_installed': False,
           'branches_integrated': False, 'whole_process_tree_deadline_enforced': False,
           'environment': {k: env[k] for k in ('GOENV', 'GOTOOLCHAIN', 'GOPROXY',
               'GOSUMDB', 'GOVCS', 'GOWORK', 'GOFLAGS', 'GOTELEMETRY', 'GOMAXPROCS',
               'CGO_ENABLED', 'MCPHUB_NO_AUTO_GUI', 'MCPHUB_E2E_SCHEDULER')}}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def run(name, executable, arguments, timeout=30, cwd=SOURCE, extra_env=None):
    child_env = dict(env)
    child_env.update(extra_env or {})
    rec = {'name': name, 'executable': str(executable), 'arguments': arguments,
           'direct_child_deadline_seconds': timeout, 'settled': False,
           'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(rec)
    save()
    print('START ' + name, flush=True)
    started = time.monotonic()
    try:
        with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen([str(executable), *arguments], cwd=cwd, env=child_env,
                                     stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                     creationflags=0x08000000)
            try:
                rec['pid'] = child.pid
                save()
                child.wait(timeout=max(0, timeout - (time.monotonic() - started)))
            except subprocess.TimeoutExpired:
                rec['direct_child_deadline_hit'] = True
                raise
            finally:
                if child.poll() is None:
                    child.kill()
                    child.wait(timeout=15)
                rec['exit_code'] = child.returncode
                rec['settled'] = child.returncode is not None
    finally:
        rec['seconds'] = round(time.monotonic() - started, 6)
        for stream in ('stdout', 'stderr'):
            path = OUT / (name + '.' + stream + '.log')
            if path.exists():
                rec[stream + '_bytes'] = path.stat().st_size
                rec[stream + '_sha256'] = digest(path)
        save()
        print(json.dumps({k: rec[k] for k in ('name', 'exit_code', 'seconds', 'settled') if k in rec}), flush=True)
    if rec['exit_code'] != 0:
        raise RuntimeError('Command failed: ' + name)
    return (OUT / (name + '.stdout.log')).read_bytes()

def git(name, *args):
    return run(name, GIT, ['-c', 'core.hooksPath=' + str(RUNTIME / 'empty-hooks'),
                          '-c', 'core.fsmonitor=false', '-C', str(SOURCE), *args]).decode('utf-8').strip()

def verify_source(label):
    actual = {'head': git(label + '-head', 'rev-parse', 'HEAD'),
              'tree': git(label + '-tree', 'rev-parse', 'HEAD^{tree}'),
              'status': git(label + '-status', 'status', '--porcelain=v1', '--untracked-files=all')}
    receipt['source_' + label] = actual
    save()
    if actual != {'head': HEAD, 'tree': TREE, 'status': ''}:
        raise RuntimeError('Source binding changed: ' + label)

def protect_output():
    # Only this freshly created directory: no recursion and no system policy change.
    who = run('output-owner', system / 'System32/whoami.exe', ['/user', '/fo', 'csv', '/nh'])
    sids = re.findall(rb'S-1-5-(?:[0-9]+-)*[0-9]+', who)
    if len(sids) != 1:
        raise RuntimeError('Cannot identify exactly one current token user SID')
    sid = sids[0].decode('ascii')
    icacls = system / 'System32/icacls.exe'
    run('output-protect', icacls, [str(OUT), '/inheritance:r', '/grant:r',
        '*' + sid + ':(OI)(CI)F', '*<SID>:(OI)(CI)F'])
    run('output-acl-save', icacls, [str(OUT), '/save', str(OUT / 'output.acl')])
    # icacls /save on this Windows host emits UTF-16LE without a BOM.
    acl = (OUT / 'output.acl').read_text(encoding='utf-16-le').lstrip('\ufeff')
    lines = [line for line in acl.splitlines() if line]
    if len(lines) != 2:
        raise RuntimeError('Unexpected ACL save representation')
    descriptor = lines[1]
    prefix, _, _ = descriptor.partition('(')
    entries = re.findall(r'\(([^()]+)\)', descriptor)
    expected = {'A;OICI;FA;;;' + sid, 'A;OICI;FA;;;SY'}
    if not prefix.startswith('D:P') or len(entries) != 2 or set(entries) != expected:
        raise RuntimeError('Fresh output DACL is not private/protected/full-access as expected')
    receipt['output_dacl'] = {'protected': True, 'allowed': ['current-token-user', 'LocalSystem'],
                              'verified_acl_sha256': digest(OUT / 'output.acl')}
    save()

try:
    receipt['runner_sha256'] = digest(Path(__file__))
    receipt['go_executable_sha256'] = digest(GO)
    verify_source('before')
    protect_output()
    receipt['go_version'] = run('go-version', GO, ['version']).decode('utf-8').strip()
    binary = OUT / 'api-intent.test.exe'
    trace = OUT / 'intent.trace'
    output = run('intent-concurrent-trace', GO, ['test', '-mod=readonly', '-tags=test_state_path_env',
        '-count=1', '-timeout=60s', '-json', '-run=^TestDaemonIntent_ConcurrentWrite$',
        '-trace=' + str(trace), '-o=' + str(binary), './internal/api'], timeout=300)
    events = [json.loads(line) for line in output.decode('utf-8').splitlines()]
    receipt['test_events'] = [e for e in events if e.get('Action') in ('pass', 'fail', 'skip')]
    required = [('mcp-local-hub/internal/api', 'TestDaemonIntent_ConcurrentWrite'),
                ('mcp-local-hub/internal/api', None)]
    passed = [(e.get('Package'), e.get('Test')) for e in events if e.get('Action') == 'pass']
    if passed != required or any(e.get('Action') in ('fail', 'skip') for e in events):
        raise RuntimeError('Expected isolated test/package pass was not observed')
    receipt['artifacts'] = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size}
                            for p in (binary, trace)}
    for kind in ('syscall', 'sync'):
        run(kind + '-profile', GO, ['tool', 'trace', '-pprof=' + kind, str(trace)], timeout=60)
        profile = OUT / (kind + '-profile.stdout.log')
        run(kind + '-top', GO, ['tool', 'pprof', '-top', '-cum', str(binary), str(profile)], timeout=60)
except Exception as exc:
    receipt['error_class'] = type(exc).__name__
    receipt['error'] = str(exc)
    raise
finally:
    try:
        verify_source('after')
        receipt['completed'] = 'error' not in receipt
    except Exception as exc:
        receipt['completed'] = False
        receipt['final_source_error_class'] = type(exc).__name__
        receipt['final_source_error'] = str(exc)
        raise
    finally:
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save()
