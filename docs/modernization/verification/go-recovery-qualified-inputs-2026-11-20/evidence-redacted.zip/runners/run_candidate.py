"""Bounded, offline Windows probes on the already prepared, pinned checkout."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path(r'<WORK_ROOT>')
SOURCE = ROOT / 'source'
RUNTIME = ROOT / 'runtime'
HEAD = 'f755d374fab317e1037deecd5dac8ffabbcdde36'
TREE = '19056c7b39ed2f625cb7f0b5282343c92b3b3a48'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<PATH> Files\Git\cmd\git.exe')
PHASE = sys.argv[1]
if PHASE not in {'intent-trace-01', 'api-receiving', 'job-entry', 'forcekill-controls', 'forcekill-candidate', 'gates'} or sys.flags.optimize:
    raise SystemExit('Unsupported phase or optimized execution')
OUT = ROOT / 'evidence' / PHASE
OUT.mkdir(parents=True, exist_ok=False)

env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off', 'GOTOOLCHAIN': 'local',
    'GOPROXY': 'off', 'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off',
    'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off', 'GOMAXPROCS': '4',
    'CGO_ENABLED': '1', 'CC': str(GO.with_name('gcc.exe')),
    'GOCACHE': str(RUNTIME / 'gocache'),
    'GOMODCACHE': r'<OWNED_WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache',
    'GOPATH': str(RUNTIME / 'gopath'), 'MCPHUB_NO_AUTO_GUI': '1',
    'MCPHUB_E2E_SCHEDULER': 'none', 'USERPROFILE': str(RUNTIME / 'profile'),
    'APPDATA': str(RUNTIME / 'appdata'), 'LOCALAPPDATA': str(RUNTIME / 'localappdata'),
    'TEMP': str(RUNTIME / 'tmp'), 'TMP': str(RUNTIME / 'tmp'),
    'TMPDIR': str(RUNTIME / 'tmp'), 'GOTMPDIR': str(RUNTIME / 'tmp'),
    'PSModuleAnalysisCachePath': str(RUNTIME / 'localappdata/module-analysis-cache'),
    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(RUNTIME / 'no-global-git-config'),
    'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / 'System32'), str(GIT.parent)))
receipt = {'phase': PHASE, 'expected_head': HEAD, 'expected_tree': TREE,
           'completed': False,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'system_policy_changed': False, 'software_installed': False,
           'branches_integrated': False, 'whole_process_tree_deadline_enforced': False,
           'environment': {k: env[k] for k in ('GOENV', 'GOTOOLCHAIN', 'GOPROXY',
               'GOSUMDB', 'GOVCS', 'GOWORK', 'GOFLAGS', 'GOTELEMETRY', 'GOMAXPROCS',
               'CGO_ENABLED', 'MCPHUB_NO_AUTO_GUI', 'MCPHUB_E2E_SCHEDULER')}}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def run(name, executable, arguments, timeout=30, cwd=SOURCE, extra_env=None, allowed_exit_codes=(0,)):
    child_env = dict(env)
    child_env.update(extra_env or {})
    rec = {'name': name, 'executable': str(executable), 'arguments': arguments,
           'environment_delta': extra_env or {},
           'direct_child_deadline_seconds': timeout, 'settled': False,
           'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(rec)
    save()
    print('START ' + name, flush=True)
    started = time.monotonic()
    try:
        with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen([str(executable), *arguments], cwd=cwd, env=child_env,
                                     stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                     creationflags=0x08000000)
            try:
                rec['pid'] = child.pid
                save()
                child.wait(timeout=max(0, timeout - (time.monotonic() - started)))
            except subprocess.TimeoutExpired:
                rec['direct_child_deadline_hit'] = True
                raise
            finally:
                if child.poll() is None:
                    child.kill()
                    child.wait(timeout=15)
                rec['exit_code'] = child.returncode
                rec['settled'] = child.returncode is not None
    finally:
        rec['seconds'] = round(time.monotonic() - started, 6)
        for stream in ('stdout', 'stderr'):
            path = OUT / (name + '.' + stream + '.log')
            if path.exists():
                rec[stream + '_bytes'] = path.stat().st_size
                rec[stream + '_sha256'] = digest(path)
        save()
        print(json.dumps({k: rec[k] for k in ('name', 'exit_code', 'seconds', 'settled') if k in rec}), flush=True)
    if rec['exit_code'] not in allowed_exit_codes:
        raise RuntimeError('Command failed: ' + name)
    return (OUT / (name + '.stdout.log')).read_bytes()

def git(name, *args):
    return run(name, GIT, ['-c', 'core.hooksPath=' + str(RUNTIME / 'empty-hooks'),
                          '-c', 'core.fsmonitor=false', '-C', str(SOURCE), *args]).decode('utf-8').rstrip('\r\n')

TEST_PATH = 'internal/cli/gui_force_test.go'
BASELINE_SHA256 = '8b4e569a3b57691e338235c5690a967982bb61206d57dc91683ad5c869e106cb'
CANDIDATE_SHA256 = 'db019916c49da6c5be02298559690b368e431e0c01feb95a786add30b875eba8'

def verify_source(label, candidate=False):
    actual = {'head': git(label + '-head', 'rev-parse', 'HEAD'),
              'tree': git(label + '-tree', 'rev-parse', 'HEAD^{tree}'),
              'status': git(label + '-status', 'status', '--porcelain=v1', '--untracked-files=all')}
    receipt['source_' + label] = actual
    save()
    expected = {'head': HEAD, 'tree': TREE, 'status': ' M ' + TEST_PATH if candidate else ''}
    if actual != expected:
        raise RuntimeError('Source binding changed: ' + label)
    if candidate:
        if digest(SOURCE / TEST_PATH) != CANDIDATE_SHA256 or git(label + '-index', 'diff', '--cached', '--name-only'):
            raise RuntimeError('Candidate file or untouched index binding changed')

def protect_output():
    # Only this freshly created directory: no recursion and no system policy change.
    who = run('output-owner', system / 'System32/whoami.exe', ['/user', '/fo', 'csv', '/nh'])
    sids = re.findall(rb'S-1-5-(?:[0-9]+-)*[0-9]+', who)
    if len(sids) != 1:
        raise RuntimeError('Cannot identify exactly one current token user SID')
    sid = sids[0].decode('ascii')
    icacls = system / 'System32/icacls.exe'
    run('output-protect', icacls, [str(OUT), '/inheritance:r', '/grant:r',
        '*' + sid + ':(OI)(CI)F', '*<SID>:(OI)(CI)F'])
    run('output-acl-save', icacls, [str(OUT), '/save', str(OUT / 'output.acl')])
    # icacls /save on this Windows host emits UTF-16LE without a BOM.
    acl = (OUT / 'output.acl').read_text(encoding='utf-16-le').lstrip('\ufeff')
    lines = [line for line in acl.splitlines() if line]
    if len(lines) != 2:
        raise RuntimeError('Unexpected ACL save representation')
    descriptor = lines[1]
    prefix, _, _ = descriptor.partition('(')
    entries = re.findall(r'\(([^()]+)\)', descriptor)
    expected = {'A;OICI;FA;;;' + sid, 'A;OICI;FA;;;SY'}
    if not prefix.startswith('D:P') or len(entries) != 2 or set(entries) != expected:
        raise RuntimeError('Fresh output DACL is not private/protected/full-access as expected')
    receipt['output_dacl'] = {'protected': True, 'allowed': ['current-token-user', 'LocalSystem'],
                              'verified_acl_sha256': digest(OUT / 'output.acl')}
    save()

def intent_trace():
    binary = OUT / 'api-intent.test.exe'
    trace = OUT / 'intent.trace'
    output = run('intent-concurrent-trace', GO, ['test', '-mod=readonly', '-tags=test_state_path_env',
        '-count=1', '-timeout=60s', '-json', '-run=^TestDaemonIntent_ConcurrentWrite$',
        '-trace=' + str(trace), '-o=' + str(binary), './internal/api'], timeout=300)
    events = [json.loads(line) for line in output.decode('utf-8').splitlines()]
    receipt['test_events'] = [e for e in events if e.get('Action') in ('pass', 'fail', 'skip')]
    required = [('mcp-local-hub/internal/api', 'TestDaemonIntent_ConcurrentWrite'),
                ('mcp-local-hub/internal/api', None)]
    passed = [(e.get('Package'), e.get('Test')) for e in events if e.get('Action') == 'pass']
    if passed != required or any(e.get('Action') in ('fail', 'skip') for e in events):
        raise RuntimeError('Expected isolated test/package pass was not observed')
    receipt['artifacts'] = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size}
                            for p in (binary, trace)}
    for kind in ('syscall', 'sync'):
        run(kind + '-profile', GO, ['tool', 'trace', '-pprof=' + kind, str(trace)], timeout=60)
        profile = OUT / (kind + '-profile.stdout.log')
        run(kind + '-top', GO, ['tool', 'pprof', '-top', '-cum', str(binary), str(profile)], timeout=60)

def api_receiving():
    binary, test = OUT / 'mcphub-attach-test.exe', OUT / 'api.test.exe'
    run('build-receiving-cli', GO, ['build', '-mod=readonly', '-tags=test_state_path_env',
        '-ldflags=-H=windowsgui', '-o', str(binary), './cmd/mcphub'], timeout=300)
    run('build-receiving-test', GO, ['test', '-mod=readonly', '-c', '-tags=test_state_path_env',
        '-o', str(test), './internal/api'], timeout=300)
    receipt['artifacts'] = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size} for p in (binary, test)}
    delta = {'MCPHUB_ATTACH_TEST_BIN': str(binary), 'MCPHUB_ATTACH_TEST_BIN_SHA256': digest(binary)}
    receipt['receiving_inputs'] = delta
    save()
    output = run('public-cli-receiving', test, ['-test.run=^TestAttachExisting_PublicCLIReceiving$',
        '-test.v', '-test.count=1', '-test.timeout=90s'], timeout=120, extra_env=delta).decode('utf-8')
    if len(re.findall(r'^--- PASS: TestAttachExisting_PublicCLIReceiving ', output, re.M)) != 1 or re.search(r'--- (FAIL|SKIP):|panic:', output):
        raise RuntimeError('Receiving test did not produce the required unskipped pass')
    receipt['receiving_scope'] = 'six public CLI children; isolated configs and simulated supervisor status; no canonical Product qualification'

def job_entry():
    controller, test = OUT / 'test-job-entry.exe', OUT / 'process.test.exe'
    run('build-job-controller', GO, ['build', '-mod=readonly', '-trimpath=false',
        '-o', str(controller), './tools/test-job-entry'], timeout=300)
    run('build-job-test', GO, ['test', '-mod=readonly', '-c', '-trimpath=false',
        '-ldflags=-H=windowsgui', '-o', str(test), './internal/process'], timeout=300)
    receipt['artifacts'] = {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size} for p in (controller, test)}
    save()
    run_root = OUT / 'native-run'
    run('qualified-job-entry', controller, ['-test-binary', str(test), '-source-dir', str(SOURCE / 'internal/process'),
        '-run-root', str(run_root), '-timeout', '90s'], timeout=120)
    native = json.loads((run_root / 'result.json').read_text(encoding='utf-8'))
    required = {'TestJob_BreakawayEnabledDescendantEscapesClose', 'TestJobInformationTransportPreparationBoundary',
                'TestJobInformationTransportPreparationBoundary/real-native-typed-gc-and-creator'}
    if (not all(native.get(k) for k in ('success', 'originalWaitKnown', 'settlementComplete', 'stdoutEOF', 'stderrEOF'))
            or native.get('originalExitCode') != 0 or native.get('error')
            or set(native.get('passed', [])) != required):
        raise RuntimeError('Native controller did not establish the complete selected fixture result')
    receipt['native_result_sha256'] = digest(run_root / 'result.json')
    receipt['native_scope'] = 'source-issued controller and its original at-create Job owner, two selected tests only'

def read_input(name, expected):
    data = (ROOT / 'inputs' / name).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise RuntimeError('Input hash mismatch: ' + name)
    return data

def test_events(output, name):
    events = [json.loads(line) for line in output.decode('utf-8').splitlines()]
    receipt.setdefault('test_runs', {})[name] = [e for e in events if e.get('Action') in ('pass', 'fail', 'skip')]
    save()
    return events

def forcekill_controls():
    target = SOURCE / TEST_PATH
    original = target.read_bytes()
    if hashlib.sha256(original).hexdigest() != BASELINE_SHA256:
        raise RuntimeError('Baseline working bytes differ from reviewed source')
    variants = [('delayed-baseline.go', '6314d40e1142d7d40645d9a27952052471c8ef9003cea6e7a646e3d271050681', 'fail'),
                ('delayed-candidate.go', '573bd6f2ce19d1fc2fa3e76b8e644e1c1f365cdc8f005145d064559bdff2b4fc', 'pass')]
    for filename, expected, action in variants:
        data = read_input(filename, expected)
        name = filename.removesuffix('.go')
        target.write_bytes(data)
        try:
            if run(name + '-gofmt', GO.with_name('gofmt.exe'), ['-d', str(target)]):
                raise RuntimeError('Control is not gofmt-clean')
            output = run(name, GO, ['test', '-mod=readonly', '-count=1', '-timeout=75s', '-json',
                '-run=^TestForce_KillHappyPath_SeamMocked$', './internal/cli'], timeout=300,
                allowed_exit_codes=(1,) if action == 'fail' else (0,))
            events = test_events(output, name)
            selected = [e for e in events if e.get('Test') == 'TestForce_KillHappyPath_SeamMocked' and e.get('Action') == action]
            if len(selected) != 1 or any(e.get('Action') == 'skip' for e in events):
                raise RuntimeError('Control did not reach the expected test outcome')
            log = ''.join(e.get('Output', '') for e in events)
            markers = [line.strip() for line in log.splitlines() if 'FORCE_KILL_CONTROL ' in line]
            receipt.setdefault('control_markers', {})[name] = markers
            entered = [line for line in markers if 'gate_enter delay=4s ' in line]
            exited = [line for line in markers if 'gate_exit elapsed=' in line]
            if len(entered) != 1 or not entered[0].endswith('ctx=<nil>') or len(exited) != 1:
                raise RuntimeError('Delay control did not start with an active context')
            expected_context = 'ctx=context canceled' if action == 'fail' else 'ctx=<nil>'
            if not exited[0].endswith(expected_context):
                raise RuntimeError('Delay control ended with an unexpected context')
            if ('gate_enter delay=4s' not in log or 'gate_exit elapsed=' not in log
                    or 'helper_settled pid=' not in log or 'wait_unlock_error=<nil>' not in log
                    or 'gate_entered=true' not in log):
                raise RuntimeError('Control lacked delay reachability or child settlement')
            if action == 'fail' and 'command_return ctx=context canceled exit_code=4' not in log:
                raise RuntimeError('Old control failed for a different reason')
            if action == 'pass' and ('recovery_return ctx=<nil> exit_code=0 acquired_lock=true' not in log or 'recovered_lock_settled' not in log):
                raise RuntimeError('New control did not prove acquired ownership and cleanup')
            save()
        finally:
            if target.read_bytes() != data:
                raise RuntimeError('Control source changed unexpectedly; refusing to overwrite')
            target.write_bytes(original)

def forcekill_candidate():
    target = SOURCE / TEST_PATH
    if digest(target) != BASELINE_SHA256:
        raise RuntimeError('Baseline changed before candidate application')
    target.write_bytes(read_input('candidate.go', CANDIDATE_SHA256))
    receipt['candidate_applied'] = True
    verify_source('candidate-applied', candidate=True)
    if run('candidate-gofmt', GO.with_name('gofmt.exe'), ['-d', str(target)]):
        raise RuntimeError('Candidate is not gofmt-clean')
    git('candidate-diff-check', 'diff', '--check')
    selector = '^(TestForce_KillHappyPath_SeamMocked|TestForce_KillRefusesNonMcphubImage|TestKillRecordedHolder_CancelledContextRefusesKill)$'
    output = run('candidate-race', GO, ['test', '-mod=readonly', '-race', '-count=2', '-timeout=120s',
        '-json', '-run=' + selector, './internal/cli', './internal/gui'], timeout=600)
    events = test_events(output, 'candidate-race')
    required = [('mcp-local-hub/internal/cli', 'TestForce_KillHappyPath_SeamMocked'),
                ('mcp-local-hub/internal/cli', 'TestForce_KillRefusesNonMcphubImage'),
                ('mcp-local-hub/internal/gui', 'TestKillRecordedHolder_CancelledContextRefusesKill')]
    passes = [(e.get('Package'), e.get('Test')) for e in events if e.get('Action') == 'pass']
    if any(passes.count(pair) != 2 for pair in required) or any(e.get('Action') in ('fail', 'skip') for e in events):
        raise RuntimeError('Focused race verification incomplete or unsuccessful')

def full_gates():
    receiving = ROOT / 'evidence/api-receiving/mcphub-attach-test.exe'
    receiving_hash = 'b0e6f756735d1b612d4792a29f90485a71e7b16891ac7d3657187d4c72f903ab'
    if digest(receiving) != receiving_hash:
        raise RuntimeError('Previously qualified receiving fixture binary changed')
    # The only candidate change is a _test.go function, excluded from this CLI
    # build. This is an input fixture for the receiving test, not a Product grant.
    receipt['receiving_fixture'] = {'source_commit': HEAD, 'sha256': receiving_hash,
                                    'role': 'tagged API public-CLI receiving fixture'}
    for name, args, deadline in [
        ('build', ['build', './...'], 300), ('vet', ['vet', './...'], 300),
        ('full-test', ['test', '-count=1', '-timeout', '5m', './...'], 900),
        ('tagged-api-cli', ['test', '-tags=test_state_path_env', '-count=1', '-timeout', '5m', './internal/api/', './internal/cli/'], 900),
    ]:
        delta = {'MCPHUB_ATTACH_TEST_BIN': str(receiving), 'MCPHUB_ATTACH_TEST_BIN_SHA256': receiving_hash} if name == 'tagged-api-cli' else None
        raw = run(name, GO, args, timeout=deadline, allowed_exit_codes=(0, 1), extra_env=delta)
        log = raw.decode('utf-8', errors='replace')
        receipt.setdefault('gate_findings', {})[name] = {
            'failed_packages': re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)', log, re.M),
            'failed_tests': re.findall(r'^--- FAIL: ([^ (]+)', log, re.M),
            'timeouts': re.findall(r'panic: test timed out after ([^\r\n]+)', log)}
        save()

try:
    receipt['runner_sha256'] = digest(Path(__file__))
    receipt['go_executable_sha256'] = digest(GO)
    verify_source('before', candidate=PHASE == 'gates')
    protect_output()
    # The Job fixtures use t.TempDir outside run-root: give every phase a
    # fresh temporary directory inheriting the already verified private DACL.
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=False)
    env.update({k: str(tmp) for k in ('TEMP', 'TMP', 'TMPDIR', 'GOTMPDIR')})
    receipt['private_temp_parent'] = str(tmp)
    receipt['go_version'] = run('go-version', GO, ['version']).decode('utf-8').strip()
    {'intent-trace-01': intent_trace, 'api-receiving': api_receiving, 'job-entry': job_entry,
     'forcekill-controls': forcekill_controls, 'forcekill-candidate': forcekill_candidate, 'gates': full_gates}[PHASE]()
except Exception as exc:
    receipt['error_class'] = type(exc).__name__
    receipt['error'] = str(exc)
    raise
finally:
    try:
        verify_source('after', candidate=PHASE == 'gates' or receipt.get('candidate_applied', False))
        receipt['completed'] = 'error' not in receipt
    except Exception as exc:
        receipt['completed'] = False
        receipt['final_source_error_class'] = type(exc).__name__
        receipt['final_source_error'] = str(exc)
        raise
    finally:
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save()
