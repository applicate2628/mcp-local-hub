"""Derive private v2 controls without executing Go or changing source inputs."""

from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
REL = "internal/cli/gui_force_test.go"
BASE_SHA = "8b4e569a3b57691e338235c5690a967982bb61206d57dc91683ad5c869e106cb"
CANDIDATE_SHA = "db019916c49da6c5be02298559690b368e431e0c01feb95a786add30b875eba8"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="")


def replace_once(content, old, new):
    assert content.count(old) == 1, old[:120]
    return content.replace(old, new, 1)


def split_subject(content):
    start = content.index("func TestForce_KillHappyPath_SeamMocked(t *testing.T) {")
    end = content.index("// ---------------------------------------------------------------\n// Scenario 4b:", start)
    return content[:start], content[start:end], content[end:]


base = (ROOT / "baseline" / REL).read_bytes()
candidate = (ROOT / "v2/candidate" / REL).read_bytes()
assert sha(base) == BASE_SHA and sha(candidate) == CANDIDATE_SHA
baseline_control = (ROOT / "controls/v1/delayed-baseline" / REL).read_bytes()
assert sha(baseline_control) == "6314d40e1142d7d40645d9a27952052471c8ef9003cea6e7a646e3d271050681"
delay = (ROOT / "controls/v1/shared-delay-seam.txt").read_text()
write(OUT / "shared-delay-seam.txt", delay)

prefix, body, suffix = split_subject(candidate.decode())
body = replace_once(body, '\tgui.SetIdentityGate(func(v gui.Verdict) (refused bool, reason string) { return false, "" })\n', "")
body = replace_once(body, "\tc := newGuiCmdRealForTest()\n", delay + "\tc := newGuiCmdRealForTest()\n")
body = replace_once(body, '''\t\tif err := <-holderDone; err != nil {
\t\t\tt.Errorf("reap sleep helper or release fixture lock: %v", err)
\t\t}
''', '''\t\twaitErr := <-holderDone
\t\tt.Logf("FORCE_KILL_CONTROL helper_settled pid=%d wait_unlock_error=%v", sleepCmd.Process.Pid, waitErr)
\t\tif waitErr != nil {
\t\t\tt.Errorf("reap sleep helper or release fixture lock: %v", waitErr)
\t\t}
''')
body = replace_once(body, "\tcontextErr := ctx.Err()\n", '\tcontextErr := ctx.Err()\n\tt.Logf("FORCE_KILL_CONTROL recovery_return ctx=%v exit_code=%d acquired_lock=%t gate_entered=%t", contextErr, exitCode, recovered != nil, delayedGate.Load())\n')
body = replace_once(body, "\tif contextErr != nil {\n", '\tif !delayedGate.Load() {\n\t\tt.Error("FORCE_KILL_CONTROL invalid: delayed identity gate was not reached")\n\t}\n\tif contextErr != nil {\n')
body = replace_once(body, "\tif currentPID != os.Getpid() || port != stalePort {\n", '\tt.Logf("FORCE_KILL_CONTROL recovered_record pid=%d port=%d", currentPID, port)\n\tif currentPID != os.Getpid() || port != stalePort {\n')
body = replace_once(body, '''\t\t\tif err := recovered.ReleaseErr(); err != nil {
\t\t\t\tt.Errorf("release recovered lock: %v", err)
\t\t\t}
''', '''\t\t\tif err := recovered.ReleaseErr(); err != nil {
\t\t\t\tt.Errorf("release recovered lock: %v", err)
\t\t\t} else {
\t\t\t\tt.Log("FORCE_KILL_CONTROL recovered_lock_settled")
\t\t\t}
''')
candidate_control = (prefix + body + suffix).encode()
assert split_subject(base.decode())[0] == prefix and split_subject(base.decode())[2] == suffix
assert body.count(delay) == 1 and baseline_control.decode().count(delay) == 1

common = {
    "base_commit": "f755d374fab317e1037deecd5dac8ffabbcdde36",
    "version": 2,
    "private_control_only": True,
    "production_changes": False,
    "go_executed": False,
    "gofmt_executed": False,
    "native_or_remote_executed": False,
    "github_writes": False,
    "execution_status": "NOT_RUN",
    "delay_seconds": 4,
    "shared_delay_seam_sha256": sha(delay.encode()),
    "selector": "^TestForce_KillHappyPath_SeamMocked$",
    "skip_is_valid_result": False,
    "outside_changed_function_byte_equal": True,
    "strict_delay_causality_requires_active_context_at_gate_entry": True,
}
index = []
for name, source, output, expected_exit in [
    ("delayed-baseline", base, baseline_control, 1),
    ("delayed-candidate", candidate, candidate_control, 0),
]:
    folder = OUT / name
    source_parts = split_subject(source.decode())
    output_parts = split_subject(output.decode())
    assert source_parts[0] == output_parts[0] and source_parts[2] == output_parts[2]
    write(folder / REL, output.decode())
    diff = "".join(difflib.unified_diff(source.decode().splitlines(True), output.decode().splitlines(True), fromfile="a/" + REL, tofile="b/" + REL))
    write(folder / "control.diff", diff)
    manifest = {**common, "name": name, "source_path": REL, "source_sha256": sha(source), "control_sha256": sha(output), "control_bytes": len(output), "diff_sha256": sha(diff.encode()), "expected_process_exit_code": expected_exit}
    if name == "delayed-baseline":
        old_manifest = json.loads((ROOT / "controls/v1/delayed-baseline/manifest.json").read_text())
        for field in ["old_3_second_timer_byte_equal", "old_timer_sha256", "old_result_oracle_byte_equal", "old_result_oracle_sha256", "cleanup_instrumentation", "required_log_fragments"]:
            manifest[field] = old_manifest[field]
        cleanup = (ROOT / "controls/v1/delayed-baseline/cleanup-only.diff").read_text()
        write(folder / "cleanup-only.diff", cleanup)
        manifest.update({"pristine_baseline": False, "cleanup_only_diff_sha256": sha(cleanup.encode()), "expected_result": "FAIL with original exit-4 assertion and kill-cancelled-before-SIGKILL diagnostic; original helper settled", "reference_control_identical_to_archived_v1_baseline": True})
    else:
        manifest.update({"expected_result": "PASS with active context, exit 0, acquired ownership lock, current PID and preserved port 1, settled lease and helper", "gui_server_started": False, "required_log_fragments": ["FORCE_KILL_CONTROL gate_enter delay=4s", "FORCE_KILL_CONTROL gate_exit", "FORCE_KILL_CONTROL recovery_return ctx=<nil> exit_code=0 acquired_lock=true gate_entered=true", "FORCE_KILL_CONTROL recovered_record", "FORCE_KILL_CONTROL recovered_lock_settled", "FORCE_KILL_CONTROL helper_settled"]})
    write(folder / "manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    index.append({"name": name, "control_path": name + "/" + REL, "sha256": sha(output), "manifest_sha256": sha((folder / "manifest.json").read_bytes()), "expected_process_exit_code": expected_exit})

assert sha((ROOT / "baseline" / REL).read_bytes()) == BASE_SHA
assert sha((ROOT / "v2/candidate" / REL).read_bytes()) == CANDIDATE_SHA
write(OUT / "manifest.json", json.dumps({**common, "candidate_sha256": CANDIDATE_SHA, "controls": index, "generator_sha256": sha(Path(__file__).read_bytes()), "readme_sha256": sha((OUT / "README.md").read_bytes())}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"candidate_unchanged": True, "controls": index}, ensure_ascii=False, indent=2))
