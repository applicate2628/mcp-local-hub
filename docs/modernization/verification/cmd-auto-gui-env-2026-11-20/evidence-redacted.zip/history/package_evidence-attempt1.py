"""Validate completed entry-env evidence and package redacted copies.

Usage: python package_evidence.py <exact-published-commit>
Reads saved files only; does not execute Git, tests, or operating-system probes.
Outputs are created exclusively in ROOT. RESULTS.md is intentionally excluded.
"""
import base64
from collections import Counter
from datetime import datetime, timezone
import difflib
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(r'<WORK_ROOT>')
OLD = r'<PREVIOUS_SOURCE>'
BASE = '32b3c4679a6f323c82529a07df9a3a87fc17d6f7'
BASE_TREE = '4399ff7e41fada989a87e8a6db4eba701f57e4cb'
TREE = '8329a7ee95419c8290c13640b3acb50886fdc41c'
BASE_HASH = '3a0f226691721cc109417042937285d4223db94f6688bb4cd6293e8b9e197d09'
HASH = '2c10343ad035722c3e03af41546d2a2f95118daae5bbf25eddb68f0ac6b3ae42'
BOOT_RUNNER = '96dc882e8d9ff2aee0f972e9f22c8db0df4a1d6634708796f8c541b041c4a0a2'
RUNNER = '7240961c5f6e107710faedee65450fd747e32a04d11dd4118787797f07a3b653'
FILE = 'cmd/mcphub/main_test.go'
PKG = 'mcp-local-hub/cmd/mcphub'
REPOSITORY = 'https://github.com/applicate2628/mcp-local-hub.git'
FIVE = {
    'TestPrepareInvocationWindowsBareLaunchReturnsWithoutInlineCobra',
    'TestPrepareInvocationBareLaunchFailureRemainsVisible',
    'TestPrepareInvocationNormalizedDebugBareStaysInline',
    'TestPrepareInvocationNormalizedPlainBareCallsDetachedCoordinator',
    'TestClassifyWindowsEntrypointModeExhaustiveRootCommands',
}
OPT = 'TestClassifyWindowsEntrypointModeBareOptOutKeepsCobraHelp'
REQUIRED = FIVE | {OPT}
OPT_LEAVES = {OPT + '/' + value for value in ('1', 'true', '_TRUE_')}
FOCUSED = '^(' + '|'.join(sorted(REQUIRED)) + ')$'
PACKAGE_ROOTS = REQUIRED | {
    'TestClassifyWindowsEntrypointMode_CBuildIsStdioProtocol',
    'TestPrepareInvocationPreservesNonBareAndOptOutRoutes',
    'TestRouteBareInvocationProducesTrayEnabledGUIArgs',
    'TestShouldAutoLaunchGUIForArgs',
    'TestShouldAutoLaunchGUIIsConsoleIndependent',
    'TestShouldAutoLaunchGUI_EnvOptOut',
    'TestShouldAutoLaunchGUI_OptOutDoesNotLeakIntoThePureSeam',
    'TestWindowsConsolePolicyApplication',
    'TestWindowsEntrypointConsolePolicyRepairsOnlyInvalidCLIOutputs',
    'TestWindowsEntrypointConsolePolicyRepairsInvalidCLIInput',
    'TestWindowsOptedOutBareUsesCLIOutputAcquisition',
}
ENVIRONMENT = {
    'GOENV': 'off', 'GOTOOLCHAIN': 'local', 'GOPROXY': 'off',
    'GOSUMDB': 'off', 'GOVCS': '*:off', 'GOWORK': 'off',
    'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off',
    'GOMAXPROCS': '4', 'CGO_ENABLED': '1',
    'MCPHUB_NO_AUTO_GUI': '1', 'MCPHUB_E2E_SCHEDULER': 'none',
}
PROCESS_SCOPE = 'work-root marker in executable path or command line'
SOURCES = (
    'run_checks.py', 'history/run_checks-bootstrap.py', 'checkout_published.py',
    'observe_owned_processes.py', 'package_evidence.py',
    'baseline/main_test.go', 'candidate/cmd/mcphub/main_test.go',
    'main_test.go.diff', 'AUDIT.md',
)
OUTPUTS = (
    'execution-summary.json', 'evidence-redacted.zip',
    'archive-metadata.json', 'evidence-redacted.base64.txt',
)
raw_files = {}
stream_checks = {}
missing_recorded_sizes = []


class EvidenceError(Exception):
    pass


def need(condition, label):
    if not condition:
        raise EvidenceError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    if name not in raw_files:
        path = ROOT / name
        need(path.is_file() and ROOT.resolve() in path.resolve().parents,
             'missing_or_outside_root: ' + name)
        raw_files[name] = path.read_bytes()
    return raw_files[name]


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    raise EvidenceError('nonfinite_json_number')


def parse(data):
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def load(name):
    value = parse(read(name))
    need(type(value) is dict, 'json_object_required: ' + name)
    return value


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def integer(value, expected=None):
    return type(value) is int and (expected is None or value == expected)


def instant(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.utcoffset() is not None, 'timestamp_without_timezone')
    return result


def check_stream(name, receipt, stream, require_size=True):
    data = read(name)
    need(sha(data) == receipt[stream + '_sha256'], 'stream_hash: ' + name)
    key = stream + '_bytes'
    if key in receipt:
        need(integer(receipt[key], len(data)), 'stream_size: ' + name)
    else:
        need(not require_size, 'missing_stream_size: ' + name)
        missing_recorded_sizes.append(name)
    stream_checks[name] = {
        'source_sha256': sha(data), 'source_bytes': len(data),
        'recorded_size_present': key in receipt,
    }
    return data


def check_commands(phase, receipt, specs):
    commands = receipt['commands']
    need([c['name'] for c in commands] == [s[0] for s in specs], 'command_order: ' + phase)
    previous = instant(receipt['started_utc'])
    finish = instant(receipt['finished_utc'])
    need(previous <= finish, 'phase_time: ' + phase)
    expected_logs = set()
    for command, (name, executable, arguments, exit_code) in zip(commands, specs):
        need(command['executable'] == executable and command['arguments'] == arguments,
             'command_arguments: ' + phase + '/' + name)
        need(command['settled'] is True and integer(command['exit_code']) and
             (exit_code is None or command['exit_code'] == exit_code),
             'command_exit: ' + phase + '/' + name)
        need(integer(command['pid']) and command['pid'] > 0, 'command_pid')
        duration = command['seconds']
        need(type(duration) in (int, float) and math.isfinite(duration) and duration >= 0,
             'command_duration')
        started = instant(command['started_utc'])
        need(previous <= started <= finish, 'command_time')
        previous = started
        for stream in ('stdout', 'stderr'):
            filename = name + '.' + stream + '.log'
            expected_logs.add(filename)
            check_stream('evidence/' + phase + '/' + filename, command, stream)
    actual_logs = {p.name for p in (ROOT / 'evidence' / phase).glob('*.log')}
    need(actual_logs == expected_logs, 'unexpected_log: ' + phase)


def check_go(phase, command, kind):
    name = 'evidence/' + phase + '/' + command['name'] + '.stdout.log'
    data = read(name)
    events = [parse(line.encode('utf-8')) for line in data.decode('utf-8-sig').splitlines()]
    need(all(type(event) is dict for event in events), 'go_event_object')
    tests = {action: [] for action in ('pass', 'fail', 'skip')}
    active = set()
    runs = Counter()
    terminal = Counter()
    package_terminal = []
    for event in events:
        action, test = event.get('Action'), event.get('Test')
        if test:
            need(event.get('Package') == PKG and type(test) is str, 'go_test_package')
            need(not package_terminal, 'go_event_after_package_terminal')
            if action == 'run':
                need(test not in active, 'duplicate_running_test')
                active.add(test)
                runs[test] += 1
            elif action in tests:
                need(test in active, 'terminal_without_run')
                active.remove(test)
                terminal[test] += 1
        if action in tests:
            label = event.get('Test', 'PACKAGE:' + event.get('Package', ''))
            tests[action].append(label)
            if not test:
                need(not active and event.get('Package') == PKG, 'go_package_terminal')
                package_terminal.append(action)
    need(not active and runs == terminal, 'incomplete_test_events')
    need(tests == command['tests'] and command['json_parse_errors'] == 0,
         'receipt_test_lists_differ')
    panic = any(value in data.decode('utf-8-sig') for value in ('panic:', 'test timed out', 'fatal error:'))
    need(command['panic_or_timeout_output'] is panic and not panic, 'panic_or_timeout')
    need(read('evidence/' + phase + '/' + command['name'] + '.stderr.log') == b'',
         'unexpected_test_stderr')
    need(not tests['skip'], 'unexpected_test_skip')
    if kind == 'negative':
        need(package_terminal == ['fail'] and
             Counter(tests['fail']) == Counter(FIVE | {'PACKAGE:' + PKG}) and
             Counter(tests['pass']) == Counter({OPT} | OPT_LEAVES),
             'negative_control_events')
    else:
        passed = [test for test in tests['pass'] if not test.startswith('PACKAGE:')]
        need(package_terminal == ['pass'] and not tests['fail'], 'positive_package_result')
        counts = Counter(passed)
        if kind == 'focused':
            need(counts == Counter({test: 2 for test in REQUIRED | OPT_LEAVES}),
                 'focused_positive_events')
        else:
            roots = {test for test in passed if '/' not in test}
            need(roots == PACKAGE_ROOTS and len(passed) == 114 and
                 all(count == 2 for count in counts.values()), 'whole_package_events')
    return {
        'test_pass': sum(not name.startswith('PACKAGE:') for name in tests['pass']),
        'test_fail': sum(not name.startswith('PACKAGE:') for name in tests['fail']),
        'test_skip': len(tests['skip']),
        'package_pass': tests['pass'].count('PACKAGE:' + PKG),
        'package_fail': tests['fail'].count('PACKAGE:' + PKG),
        'all_test_runs_have_terminal_events': True,
    }


def check_phase(phase, head, specs):
    receipt = load('evidence/' + phase + '/receipt.json')
    need(receipt['phase'] == phase and receipt['completed'] is True, 'phase_completion: ' + phase)
    need(receipt['base'] == BASE and receipt['expected_head'] == head and
         receipt['head_after'] == head, 'phase_head: ' + phase)
    expected_tree = TREE if phase == 'published' else BASE_TREE
    expected_hash = BASE_HASH if phase in ('bootstrap', 'control') else HASH
    expected_status = 'M  ' + FILE if phase in ('candidate', 'gates') else ''
    need(receipt['tree_after'] == expected_tree and receipt['status_after'] == expected_status and
         receipt['file_sha256_after'] == expected_hash, 'phase_source: ' + phase)
    if phase != 'bootstrap':
        before = BASE_HASH if phase in ('control', 'candidate') else HASH
        need(receipt['file_sha256_before'] == before, 'phase_before_hash: ' + phase)
    if phase in ('candidate', 'gates'):
        need(receipt['candidate_tree'] == TREE, 'candidate_tree')
    need(receipt['environment'] == ENVIRONMENT and
         receipt['native_lifecycle_opt_in_present'] is False and
         receipt['whole_process_tree_deadline_enforced'] is False, 'phase_environment: ' + phase)
    runner = BOOT_RUNNER if phase == 'bootstrap' else RUNNER
    need(receipt['runner_sha256'] == runner, 'phase_runner: ' + phase)
    check_commands(phase, receipt, specs)
    return receipt


def validate(head):
    need(sha(read('run_checks.py')) == RUNNER and
         sha(read('history/run_checks-bootstrap.py')) == BOOT_RUNNER, 'runner_source_binding')
    baseline = read('baseline/main_test.go')
    candidate = read('candidate/cmd/mcphub/main_test.go')
    need(sha(baseline) == BASE_HASH and sha(candidate) == HASH, 'test_source_hashes')
    expected = baseline
    for test in sorted(FIVE):
        anchor = ('func ' + test + '(t *testing.T) {\n').encode()
        need(expected.count(anchor) == 1, 'test_anchor')
        expected = expected.replace(anchor, anchor + b'\tt.Setenv(NoAutoGUIEnv, "")\n', 1)
    need(candidate == expected, 'only_five_insertions')
    diff = 'diff --git a/' + FILE + ' b/' + FILE + '\n'
    diff += ''.join(difflib.unified_diff(
        baseline.decode().splitlines(keepends=True), candidate.decode().splitlines(keepends=True),
        fromfile='a/' + FILE, tofile='b/' + FILE))
    need(read('main_test.go.diff') == diff.encode(), 'saved_diff_matches_sources')
    source_path = str(ROOT / 'source')
    bootstrap = check_phase('bootstrap', BASE, [
        ('clone', 'git.exe', ['-c', 'core.autocrlf=false', 'clone', '--local',
                             '--no-hardlinks', '--no-checkout', OLD, source_path], 0),
        ('fetch', 'git.exe', ['-C', source_path, 'fetch', '--no-tags', REPOSITORY, BASE], 0),
        ('go-version', 'go.exe', ['version'], 0),
    ])
    need(re.fullmatch(rb'go version go[0-9][^\r\n]* windows/amd64\r?\n',
                      read('evidence/bootstrap/go-version.stdout.log')) is not None,
         'go_version_platform')
    focused = ['test', '-json', '-race', '-count=2', '-timeout=180s', '-run', FOCUSED, './cmd/mcphub']
    package = ['test', '-json', '-race', '-count=2', '-timeout=180s', './cmd/mcphub']
    control = check_phase('control', BASE, [
        ('old-env-control', 'go.exe', ['test', '-json', '-count=1', '-timeout=180s',
                                     '-run', FOCUSED, './cmd/mcphub'], 1),
    ])
    need(control['semantic_negative_control'] is True, 'negative_control_receipt')
    counts = {'control': check_go('control', control['commands'][0], 'negative')}
    candidate_receipt = check_phase('candidate', BASE, [
        ('gofmt-check', 'gofmt.exe', ['-l', FILE], 0),
        ('focused-race', 'go.exe', focused, 0),
        ('package-race', 'go.exe', package, 0),
    ])
    need(read('evidence/candidate/gofmt-check.stdout.log') ==
         read('evidence/candidate/gofmt-check.stderr.log') == b'', 'gofmt_output')
    counts['focused-race'] = check_go('candidate', candidate_receipt['commands'][1], 'focused')
    counts['package-race'] = check_go('candidate', candidate_receipt['commands'][2], 'package')
    gates = check_phase('gates', BASE, [
        ('build', 'go.exe', ['build', './...'], None),
        ('vet', 'go.exe', ['vet', './...'], None),
        ('full-test', 'go.exe', ['test', '-count=1', '-timeout', '5m', './...'], None),
        ('tagged-api-cli', 'go.exe', ['test', '-tags=test_state_path_env', '-count=1',
                                    '-timeout', '5m', './internal/api/', './internal/cli/'], None),
    ])
    for command in gates['commands']:
        if command['arguments'][0] != 'test':
            continue
        text = read('evidence/gates/' + command['name'] + '.stdout.log').decode('utf-8-sig')
        diagnostics = {
            'failed_packages': re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)', text, re.M),
            'failed_tests': re.findall(r'^--- FAIL: ([^ (]+)', text, re.M),
            'timeouts': re.findall(r'panic: test timed out after ([^\r\n]+)', text),
        }
        need(all(command[key] == value for key, value in diagnostics.items()),
             'gate_diagnostics_differ: ' + command['name'])
    checkout = load('evidence/published-checkout/receipt.json')
    need(checkout['phase'] == 'published-checkout' and checkout['completed'] is True and
         checkout['previous_head'] == BASE and checkout['expected_head'] == head and
         checkout['expected_tree'] == checkout['prepared_tree'] == checkout['tree'] == TREE and
         checkout['head'] == head and checkout['parents'] == [BASE] and checkout['status'] == '' and
         checkout['prepared_file_sha256'] == checkout['file_sha256'] == HASH and
         checkout['whole_process_tree_deadline_enforced'] is False and
         checkout['script_sha256'] == sha(read('checkout_published.py')), 'checkout_binding')
    check_commands('published-checkout', checkout, [
        ('fetch', 'git.exe', ['fetch', '--no-tags', REPOSITORY, head], 0),
        ('checkout', 'git.exe', ['checkout', '--detach', head], 0),
    ])
    published = check_phase('published', head, [
        ('published-package-race', 'go.exe', package, 0),
    ])
    counts['published-package-race'] = check_go('published', published['commands'][0], 'package')
    post = load('post-verify/receipt.json')
    need(post['phase'] == 'post-verify' and integer(post['exit_code'], 0) and
         post['settled'] is True and post.get('timed_out', False) is False and
         post['scoped_absence_observed'] is True and post['whole_process_tree_proven'] is False and
         post['script_sha256'] == sha(read('observe_owned_processes.py')), 'post_verify_receipt')
    processes = parse(check_stream('post-verify/stdout.log', post, 'stdout', False))
    need(check_stream('post-verify/stderr.log', post, 'stderr', False) == b'', 'post_verify_stderr')
    need(processes == post['observation'] and processes['remaining'] == [] and
         type(processes['remaining']) is list and integer(post['pid']) and post['pid'] > 0 and
         integer(processes['observer_pid'], post['pid']) and
         processes['scope'] == PROCESS_SCOPE, 'post_verify_observation')
    excluded = processes['excluded_pids']
    need(type(excluded) is list and len(excluded) == 3 and excluded[0] == post['pid'] and
         all(integer(pid) and pid > 0 for pid in excluded), 'post_verify_exclusions')
    phases = [bootstrap, control, candidate_receipt, gates, checkout, published, post]
    for previous, following in zip(phases, phases[1:]):
        need(instant(previous['finished_utc']) <= instant(following['started_utc']),
             'phase_chronology')
    need(instant(post['started_utc']) <= instant(processes['observed_utc']) <=
         instant(post['finished_utc']), 'post_verify_time')
    return phases, counts, processes


def redactor():
    replacements = [
        (str(ROOT), '<WORK_ROOT>'), (OLD, '<PREVIOUS_SOURCE>'),
        (r'<GO_CACHE_ROOT>', '<GO_CACHE_ROOT>'),
        (r'<GO_ROOT>', '<GO_ROOT>'),
        (r'<GO_BIN>', '<GO_BIN>'),
        (r'<GIT_EXECUTABLE>', '<GIT_EXECUTABLE>'),
        (r'<OWNED_WORK_ROOT>', '<OWNED_WORK_ROOT>'),
        (r'<LOCAL_PIPE>', '<LOCAL_PIPE>'),
    ]
    replacements.extend((value, '<MACHINE_DIRECTORY>')
                        for key in ('USERPROFILE', 'SYSTEMROOT', 'WINDIR')
                        if (value := os.environ.get(key)))
    identities = {value for key in ('USERNAME', 'USERDOMAIN', 'COMPUTERNAME')
                  if (value := os.environ.get(key))}

    def variants(value):
        return {value, value.replace('\\', '/'), value.replace('\\', '\\\\'),
                json.dumps(value, ensure_ascii=True)[1:-1]}

    identity_patterns = [r'(?<!\w)' + re.escape(value) + r'(?!\w)'
                         for old in sorted(identities, key=len, reverse=True)
                         for value in sorted(variants(old), key=len, reverse=True)]
    placeholder = '<REDACTED_0>'
    number = 0
    while any(re.search(pattern, placeholder, re.I) for pattern in identity_patterns):
        number += 1
        placeholder = '<REDACTED_' + str(number) + '>'

    def text(value):
        for old, replacement in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
            for spelling in sorted(variants(old), key=len, reverse=True):
                value = re.sub(re.escape(spelling), lambda _: replacement, value, flags=re.I)
        value = re.sub(r'\b[A-Za-z]:[\\/]+Users[\\/]+[^\\/\s"\'<>]+',
                       '<USER_HOME>', value, flags=re.I)
        for pattern in identity_patterns:
            value = re.sub(pattern, lambda _: placeholder, value, flags=re.I)
        return re.sub(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', '<USER_SID>', value)

    def obj(value):
        if isinstance(value, str):
            return text(value)
        if isinstance(value, list):
            return [obj(item) for item in value]
        if isinstance(value, dict):
            return {text(key): obj(item) for key, item in value.items()}
        return value

    def saved(name, data):
        if name.endswith('.json'):
            return json_bytes(obj(parse(data)))
        return text(data.decode('utf-8-sig')).encode('utf-8')

    def scan(data):
        value = data.decode('utf-8')
        need(not any(re.search(pattern, value, re.I) for pattern in identity_patterns),
             'private_identity_remains')
        need(not re.search(r'\b[A-Za-z]:[\\/]+', value), 'machine_path_remains')
        unc = re.escape(chr(92) * 2) + r'[^\\/\s"\']+[\\/]'
        need(not re.search(unc, value), 'unc_path_remains')
        for pattern in (
            rb'\bgh[pousr]_[A-Za-z0-9]{16,}', rb'\bgithub_pat_[A-Za-z0-9_]{16,}',
            rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}',
            rb'\bxox[baprs]-[A-Za-z0-9-]{16,}', rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}',
            rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
            rb'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
        ):
            need(re.search(pattern, data) is None, 'credential_shaped_content')
    return saved, scan


def main():
    need(not sys.flags.optimize, 'optimized_execution_unsupported')
    need(len(sys.argv) == 2 and re.fullmatch('[0-9a-f]{40}', sys.argv[1]) is not None,
         'exact_published_commit_required')
    head = sys.argv[1]
    need(not any((ROOT / name).exists() for name in OUTPUTS), 'output_already_exists')
    phases, counts, processes = validate(head)
    gates = phases[3]
    included = set(SOURCES) | set(stream_checks) | {
        'evidence/' + phase + '/receipt.json'
        for phase in ('bootstrap', 'control', 'candidate', 'gates', 'published-checkout', 'published')
    } | {'post-verify/receipt.json'}
    need('RESULTS.md' not in included, 'cyclic_results_member')
    summary = {
        'schema': 1, 'evidence_validation': 'PASS', 'mode': 'saved_files_only',
        'base': BASE, 'base_tree': BASE_TREE, 'candidate_tree': TREE, 'head': head,
        'verified_utc': datetime.now(timezone.utc).isoformat(),
        'changed_files': [FILE], 'additions': 5, 'deletions': 0,
        'product_code_changed': False,
        'all_mandatory_commands_passed': all(c['exit_code'] == 0 for c in gates['commands']),
        'test_counts': counts, 'phases': {phase['phase']: phase for phase in phases},
        'source_sha256': {name: sha(read(name)) for name in SOURCES},
        'stream_checks': stream_checks,
        'stream_sizes_absent_from_original_receipts': sorted(missing_recorded_sizes),
        'all_recorded_direct_children_settled': True,
        'whole_process_tree_proven': False, 'whole_process_tree_deadline_enforced': False,
        'post_verify': {'scoped_absence_observed': True, 'remaining': 0,
                        'scope': PROCESS_SCOPE, 'observed_utc': processes['observed_utc']},
        'packager_process_or_git_calls': False,
        'limitations': [
            'Mandatory gate failures are retained; evidence integrity is not a full-suite PASS.',
            'Go event counts are reparsed from original raw logs, not inferred from wrapper success.',
            'Source head, tree, index and clean/staged status are verified from saved receipts.',
            'Scoped process absence does not prove settlement of an ancestry-complete process tree.',
            'Missing original post-verify stream sizes are computed now and identified separately.',
            'Scripts in the archive are redacted review copies; source hashes identify original bytes.',
        ],
    }
    saved, scan = redactor()
    originals = {name: read(name) for name in included}
    originals['execution-summary.json'] = json_bytes(summary)
    members = {}
    manifest = {
        'schema': 1, 'base': BASE, 'head': head, 'candidate_tree': TREE, 'files': [],
        'redaction': 'Receipt stream hashes identify source bytes. Saved hashes identify redacted archive bytes. RESULTS and base64 are excluded.',
    }
    for name in sorted(originals):
        original = originals[name]
        data = saved(name, original)
        scan(data)
        members[name] = data
        manifest['files'].append({
            'path': name, 'origin': 'generated' if name == 'execution-summary.json' else 'saved_evidence',
            'source_sha256': sha(original), 'source_bytes': len(original),
            'saved_sha256': sha(data), 'saved_bytes': len(data),
        })
    members['MANIFEST.json'] = json_bytes(manifest)
    scan(members['MANIFEST.json'])
    for name, original in raw_files.items():
        need((ROOT / name).read_bytes() == original, 'source_changed_during_packaging: ' + name)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    archive_data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
        need(archive.namelist() == list(members), 'archive_member_mismatch')
        for name, data in members.items():
            need(archive.read(name) == data, 'archive_byte_mismatch')
    encoded = base64.b64encode(archive_data).decode('ascii')
    base64_data = ('\n'.join(encoded[i:i + 4096] for i in range(0, len(encoded), 4096)) + '\n').encode('ascii')
    metadata = {
        'base': BASE, 'head': head, 'candidate_tree': TREE,
        'archive_file': 'evidence-redacted.zip', 'archive_sha256': sha(archive_data),
        'archive_bytes': len(archive_data), 'archive_members': len(members),
        'manifest_files': len(manifest['files']), 'manifest_sha256': sha(members['MANIFEST.json']),
        'summary_sha256': sha(members['execution-summary.json']),
        'base64_file': 'evidence-redacted.base64.txt', 'base64_sha256': sha(base64_data),
        'base64_bytes': len(base64_data), 'base64_lines': len(base64_data.splitlines()),
        'base64_chunk_characters': 4096, 'credential_shape_scan': 'PASS',
    }
    metadata_data = json_bytes(metadata)
    scan(metadata_data)
    outputs = {
        'execution-summary.json': members['execution-summary.json'],
        'evidence-redacted.zip': archive_data,
        'archive-metadata.json': metadata_data,
        'evidence-redacted.base64.txt': base64_data,
    }
    for name, data in outputs.items():
        with (ROOT / name).open('xb') as output:
            output.write(data)
    print(json.dumps(metadata), flush=True)


if __name__ == '__main__':
    try:
        main()
    except EvidenceError as error:
        print(json.dumps({'packaged': False, 'error_category': 'evidence_validation',
                          'detail': str(error)}), flush=True)
        raise SystemExit(1)
    except Exception as error:
        print(json.dumps({'packaged': False, 'error_category': type(error).__name__}), flush=True)
        raise SystemExit(1)
