"""Offline validation of five explicit test-environment premises on PR #658."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
BASE='32b3c4679a6f323c82529a07df9a3a87fc17d6f7'
TREE='4399ff7e41fada989a87e8a6db4eba701f57e4cb'
ROOT=Path(r'<WORK_ROOT>')
OLD=Path(r'<PREVIOUS_SOURCE>')
SOURCE=ROOT/'source'
GO=Path(r'<GO_BIN>\go.exe')
GIT=Path(r'<GIT_EXECUTABLE>')
FILE='cmd/mcphub/main_test.go'
HASH='2c10343ad035722c3e03af41546d2a2f95118daae5bbf25eddb68f0ac6b3ae42'
FIVE={'TestPrepareInvocationWindowsBareLaunchReturnsWithoutInlineCobra','TestPrepareInvocationBareLaunchFailureRemainsVisible','TestPrepareInvocationNormalizedDebugBareStaysInline','TestPrepareInvocationNormalizedPlainBareCallsDetachedCoordinator','TestClassifyWindowsEntrypointModeExhaustiveRootCommands'}
FOCUSED='^('+'|'.join(sorted(FIVE|{'TestClassifyWindowsEntrypointModeBareOptOutKeepsCobraHelp'}))+')$'
phase=sys.argv[1]
if phase not in {'bootstrap','control','candidate','gates','published'}:
    raise SystemExit('Unknown phase')
expected=sys.argv[2] if phase=='published' else BASE
out=ROOT/'evidence'/phase
out.mkdir(parents=True,exist_ok=False)
runtime=ROOT/'runtime'/phase
for name in ('tmp','profile','appdata','localappdata','gopath','empty-hooks'):
    (runtime/name).mkdir(parents=True,exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('MCPHUB_', 'GIT_'))}
system=Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps=system/'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({'GOROOT':r'<GO_ROOT>','GOENV':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOVCS':'*:off','GOWORK':'off','GOFLAGS':'-mod=readonly','GOTELEMETRY':'off','GOMAXPROCS':'4','CGO_ENABLED':'1','CC':str(GO.with_name('gcc.exe')),'GOCACHE':r'<GO_CACHE_ROOT>\gocache','GOMODCACHE':r'<GO_CACHE_ROOT>\gomodcache','GOPATH':str(runtime/'gopath'),'MCPHUB_NO_AUTO_GUI':'1','MCPHUB_E2E_SCHEDULER':'none','USERPROFILE':str(runtime/'profile'),'APPDATA':str(runtime/'appdata'),'LOCALAPPDATA':str(runtime/'localappdata'),'TEMP':str(runtime/'tmp'),'TMP':str(runtime/'tmp'),'TMPDIR':str(runtime/'tmp'),'GOTMPDIR':str(runtime/'tmp'),'PSModuleAnalysisCachePath':str(runtime/'localappdata/module-analysis-cache'),'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':str(runtime/'no-global-git-config')})
env['PATH']=os.pathsep.join((str(GO.parent),str(ps.parent),str(system/'System32'),str(GIT.parent)))
receipt={'phase':phase,'base':BASE,'expected_head':expected,'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[],'environment':{k:env[k] for k in ('GOENV','GOTOOLCHAIN','GOPROXY','GOSUMDB','GOVCS','GOWORK','GOFLAGS','GOTELEMETRY','GOMAXPROCS','CGO_ENABLED','MCPHUB_NO_AUTO_GUI','MCPHUB_E2E_SCHEDULER')},'native_lifecycle_opt_in_present':False,'whole_process_tree_deadline_enforced':False}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save():
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def git_at(directory,*args):
    return subprocess.check_output([str(GIT),'-c','core.hooksPath='+str(runtime/'empty-hooks'),'-C',str(directory),*args],env=env).decode().strip()
def git(*args):
    return git_at(SOURCE,*args)
def ensure_root(directory):
    if Path(git_at(directory,'rev-parse','--show-toplevel')).resolve()!=directory.resolve(): raise RuntimeError('Repository root mismatch')
def require_positive(record, focused=False):
    needed=FIVE|{'TestClassifyWindowsEntrypointModeBareOptOutKeepsCobraHelp'}
    passes=record['tests']['pass']
    tops={x for x in passes if '/' not in x and not x.startswith('PACKAGE:')}
    valid=record['exit_code']==0 and not record['tests']['fail'] and not record['tests']['skip'] and record['json_parse_errors']==0 and passes.count('PACKAGE:mcp-local-hub/cmd/mcphub')==1 and all(passes.count(x)==2 for x in needed)
    if focused: valid=valid and tops==needed
    if not valid: raise RuntimeError('Incomplete or unsuccessful positive test set')
def run(name,args,exe=GO,cwd=SOURCE):
    record={'name':name,'executable':exe.name,'arguments':args,'started_utc':datetime.now(timezone.utc).isoformat(),'settled':False}
    receipt['commands'].append(record);save();print('START '+name,flush=True)
    clock=time.monotonic()
    with (out/(name+'.stdout.log')).open('xb') as fo,(out/(name+'.stderr.log')).open('xb') as fe:
        with subprocess.Popen([str(exe),*args],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=fo,stderr=fe,creationflags=0x08000000) as child:
            record['pid']=child.pid;save();record['exit_code']=child.wait();record['settled']=True
    record['seconds']=round(time.monotonic()-clock,3)
    for stream in ('stdout','stderr'):
        path=out/(name+'.'+stream+'.log');record[stream+'_bytes']=path.stat().st_size;record[stream+'_sha256']=digest(path)
    if args and args[0]=='test':
        text=(out/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')
        if '-json' in args:
            events=[]
            record['json_parse_errors']=0
            for line in text.splitlines():
                try: events.append(json.loads(line))
                except ValueError: record['json_parse_errors']+=1
            record['panic_or_timeout_output']=any(x in text for x in ('panic:', 'test timed out', 'fatal error:'))
            record['tests']={a:[x.get('Test','PACKAGE:'+x.get('Package','')) for x in events if x.get('Action')==a] for a in ('pass','fail','skip')}
        else:
            record['failed_packages']=re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)',text,re.M)
            record['failed_tests']=re.findall(r'^--- FAIL: ([^ (]+)',text,re.M)
            record['timeouts']=re.findall(r'panic: test timed out after ([^\r\n]+)',text)
    save();print(json.dumps({k:record[k] for k in ('name','exit_code','seconds','settled','stdout_bytes','stderr_bytes')}),flush=True)
    return record
try:
    receipt['runner_sha256']=digest(Path(__file__))
    if phase=='bootstrap':
        ensure_root(OLD)
        if SOURCE.exists() or git_at(OLD,'rev-parse','HEAD')!='9721681633440d3593d37ffb8f580e5d98440da2' or git_at(OLD,'status','--porcelain=v1','--untracked-files=all')!='': raise RuntimeError('Unexpected original checkout')
        if run('clone',['-c','core.autocrlf=false','clone','--local','--no-hardlinks','--no-checkout',str(OLD),str(SOURCE)],GIT,ROOT)['exit_code']!=0: raise RuntimeError('Clone failed')
        git('config','core.autocrlf','false');git('config','core.hooksPath',str(runtime/'empty-hooks'))
        if run('fetch',['-C',str(SOURCE),'fetch','--no-tags','https://github.com/applicate2628/mcp-local-hub.git',BASE],GIT,ROOT)['exit_code']!=0: raise RuntimeError('Fetch failed')
        if git('rev-parse',BASE+'^{tree}')!=TREE: raise RuntimeError('Base tree mismatch')
        git('checkout','--detach',BASE)
        if run('go-version',['version'])['exit_code']!=0: raise RuntimeError('Go version failed')
    else:
        ensure_root(SOURCE)
        if git('rev-parse','HEAD')!=expected: raise RuntimeError('Unexpected source head')
        receipt['file_sha256_before']=digest(SOURCE/FILE)
        if phase=='control':
            if git('status','--porcelain=v1','--untracked-files=all')!='': raise RuntimeError('Dirty base')
            r=run('old-env-control',['test','-json','-count=1','-timeout=180s','-run',FOCUSED,'./cmd/mcphub'])
            failed={x for x in r['tests']['fail'] if '/' not in x and not x.startswith('PACKAGE:')}
            receipt['semantic_negative_control']=r['exit_code']==1 and failed==FIVE and len(r['tests']['fail'])==6 and all(r['tests']['fail'].count(x)==1 for x in FIVE) and r['tests']['fail'].count('PACKAGE:mcp-local-hub/cmd/mcphub')==1 and r['tests']['pass'].count('TestClassifyWindowsEntrypointModeBareOptOutKeepsCobraHelp')==1 and len([x for x in r['tests']['pass'] if x.startswith('TestClassifyWindowsEntrypointModeBareOptOutKeepsCobraHelp/')])==3 and not r['tests']['skip'] and r['stderr_bytes']==0 and r['json_parse_errors']==0 and not r['panic_or_timeout_output']
            if not receipt['semantic_negative_control']: raise RuntimeError('Unexpected negative control')
        elif phase=='candidate':
            control=json.loads((ROOT/'evidence/control/receipt.json').read_text())
            if not control.get('completed') or control['base']!=BASE or control['head_after']!=BASE or control['tree_after']!=TREE or control['status_after']!='' or control['file_sha256_before']!=control['file_sha256_after'] or control['file_sha256_after']!=digest(SOURCE/FILE) or not control['semantic_negative_control'] or git('status','--porcelain=v1','--untracked-files=all')!='': raise RuntimeError('Control binding failed')
            data=(ROOT/'main_test.go').read_bytes()
            if hashlib.sha256(data).hexdigest()!=HASH: raise RuntimeError('Candidate mismatch')
            (SOURCE/FILE).write_bytes(data)
            fmt=run('gofmt-check',['-l',FILE],GO.with_name('gofmt.exe'))
            if fmt['exit_code']!=0 or fmt['stdout_bytes']!=0: raise RuntimeError('Formatting differs')
            if git('diff','--name-only')!=FILE or git('diff','--numstat')!='5\t0\t'+FILE: raise RuntimeError('Unexpected diff')
            r=run('focused-race',['test','-json','-race','-count=2','-timeout=180s','-run',FOCUSED,'./cmd/mcphub'])
            require_positive(r, focused=True)
            r=run('package-race',['test','-json','-race','-count=2','-timeout=180s','./cmd/mcphub'])
            require_positive(r)
            git('add','--',FILE)
            receipt['candidate_tree']=git('write-tree')
        elif phase=='gates':
            if digest(SOURCE/FILE)!=HASH or git('diff','HEAD','--name-only')!=FILE: raise RuntimeError('Candidate state mismatch')
            receipt['candidate_tree']=git('write-tree')
            previous=json.loads((ROOT/'evidence/candidate/receipt.json').read_text())
            if receipt['candidate_tree']!=previous['candidate_tree'] or git('diff','--name-only')!='' or git('status','--porcelain=v1','--untracked-files=all')!='M  '+FILE: raise RuntimeError('Gate tree binding mismatch')
            run('build',['build','./...'])
            run('vet',['vet','./...'])
            run('full-test',['test','-count=1','-timeout','5m','./...'])
            run('tagged-api-cli',['test','-tags=test_state_path_env','-count=1','-timeout','5m','./internal/api/','./internal/cli/'])
        else:
            gates=json.loads((ROOT/'evidence/gates/receipt.json').read_text())
            if not gates.get('completed') or git('rev-parse','HEAD^{tree}')!=gates['candidate_tree'] or git('rev-list','--parents','-n','1','HEAD').split()!=[expected,BASE]: raise RuntimeError('Published ancestry/tree mismatch')
            if digest(SOURCE/FILE)!=HASH or git('status','--porcelain=v1','--untracked-files=all')!='': raise RuntimeError('Published source mismatch')
            r=run('published-package-race',['test','-json','-race','-count=2','-timeout=180s','./cmd/mcphub'])
            require_positive(r)
    receipt['head_after']=git('rev-parse','HEAD')
    receipt['tree_after']=git('rev-parse','HEAD^{tree}')
    receipt['status_after']=git('status','--porcelain=v1','--untracked-files=all')
    receipt['file_sha256_after']=digest(SOURCE/FILE)
    ensure_root(SOURCE)
    if receipt['head_after']!=expected: raise RuntimeError('Source head changed')
    if phase in {'bootstrap','control'}:
        if receipt['tree_after']!=TREE or receipt['status_after']!='' or git('hash-object','--no-filters',FILE)!='2c6a59c6df43eb47c76f48de8a5515b9c32ebbd8': raise RuntimeError('Base source changed')
    elif phase in {'candidate','gates'}:
        if receipt['tree_after']!=TREE or receipt['status_after']!='M  '+FILE or receipt['file_sha256_after']!=HASH or git('diff','--name-only')!='' or git('diff','--cached','--numstat')!='5\t0\t'+FILE or git('write-tree')!=receipt['candidate_tree']: raise RuntimeError('Candidate source changed')
    else:
        previous=json.loads((ROOT/'evidence/candidate/receipt.json').read_text())
        if receipt['tree_after']!=previous['candidate_tree'] or receipt['status_after']!='' or receipt['file_sha256_after']!=HASH: raise RuntimeError('Published source changed')
    receipt['completed']=True
finally:
    receipt['finished_utc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'phase':phase,'completed':receipt.get('completed',False),'commands':len(receipt['commands']),'candidate_tree':receipt.get('candidate_tree')}),flush=True)
