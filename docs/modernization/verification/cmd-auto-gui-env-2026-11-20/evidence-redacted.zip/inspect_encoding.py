"""Inspect saved UTF-8 failures without disclosing log contents or rerunning tests."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(r'<WORK_ROOT>')
PACKAGER_HASH = 'e2d4531575ce51b3e6224ab304595af37fd5977c8645084071e43abca550b48f'
history = ROOT / 'history'
old = (ROOT / 'package_evidence.py').read_bytes()
if hashlib.sha256(old).hexdigest() != PACKAGER_HASH:
    raise SystemExit('Original packager differs')
with (history / 'package_evidence-attempt1.py').open('xb') as f:
    f.write(old)
files = []
for phase in ('bootstrap', 'control', 'candidate', 'gates', 'published-checkout', 'published'):
    files.extend(sorted((ROOT / 'evidence' / phase).glob('*.log')))
invalid = []
for path in files:
    data = path.read_bytes()
    try:
        data.decode('utf-8-sig')
    except UnicodeDecodeError as error:
        invalid.append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest(),
                        'first_invalid_start': error.start, 'first_invalid_end': error.end,
                        'reason': error.reason})
outputs = ('execution-summary.json', 'evidence-redacted.zip',
           'archive-metadata.json', 'evidence-redacted.base64.txt')
receipt = {'phase': 'packaging-attempt1', 'observed_utc': datetime.now(timezone.utc).isoformat(),
           'packager_sha256': PACKAGER_HASH, 'reported_error_category': 'UnicodeDecodeError',
           'outer_exit_code_observed': 1, 'inspected_logs': len(files),
           'invalid_utf8_files': invalid,
           'outputs_present': [name for name in outputs if (ROOT / name).exists()],
           'native_or_test_calls': False}
with (history / 'packaging-attempt1.json').open('x', encoding='utf-8') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps(receipt), flush=True)
