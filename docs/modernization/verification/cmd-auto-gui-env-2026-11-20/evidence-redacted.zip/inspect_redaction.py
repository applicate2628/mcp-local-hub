"""Diagnose the saved-evidence redactor without running tests or native calls."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import runpy

ROOT = Path(r'<WORK_ROOT>')
EXPECTED = '876437dcfb4a2ec4ada77e72e42185289c7f01d51020f9dadd526a044a142518'
data = (ROOT / 'package_evidence.py').read_bytes()
if hashlib.sha256(data).hexdigest() != EXPECTED:
    raise SystemExit('Packager changed')
with (ROOT / 'history/package_evidence-attempt2.py').open('xb') as f:
    f.write(data)
package = runpy.run_path(str(ROOT / 'package_evidence.py'), run_name='saved_redactor_diagnostic')
package['validate']('95f2c6df8d8883f009025d2196480cc54c8101af')
for name in package['SOURCES']:
    package['read'](name)
save, scan = package['redactor']()
issues = []
for name, original in sorted(package['raw_files'].items()):
    saved = save(name, original)
    try:
        scan(saved, name)
    except package['EvidenceError'] as error:
        decoded = saved.decode('utf-8', errors='surrogateescape')
        matches = list(re.finditer(r'\b[A-Za-z]:[\\/]+[^\r\n\t\"\'<>]*', decoded))
        issues.append({'path': name, 'category': str(error),
                       'source_sha256': hashlib.sha256(original).hexdigest(),
                       'remaining_path_count': len(matches),
                       'remaining_paths': sorted({match.group(0) for match in matches})})
outputs = ('execution-summary.json', 'evidence-redacted.zip',
           'archive-metadata.json', 'evidence-redacted.base64.txt')
receipt = {'phase': 'packaging-attempt2', 'observed_utc': datetime.now(timezone.utc).isoformat(),
           'packager_sha256': EXPECTED, 'reported_error_category': 'evidence_validation',
           'reported_detail': 'machine_path_remains', 'outer_exit_code_observed': 1,
           'issues': issues, 'outputs_present': [n for n in outputs if (ROOT / n).exists()],
           'native_or_test_calls': False}
with (ROOT / 'history/packaging-attempt2-private.json').open('x', encoding='utf-8') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
public = dict(receipt)
public['issues'] = [{k: v for k, v in issue.items() if k != 'remaining_paths'} for issue in issues]
with (ROOT / 'history/packaging-attempt2.json').open('x', encoding='utf-8') as f:
    json.dump(public, f, indent=2)
    f.write('\n')
print(json.dumps(public), flush=True)
