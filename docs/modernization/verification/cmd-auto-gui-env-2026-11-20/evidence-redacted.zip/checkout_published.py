"""Select the published single-parent commit whose tree has completed checks.

Completed checks may have failed; their original outcomes remain in gate evidence.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
ROOT = Path(r'<WORK_ROOT>')
SOURCE = ROOT / 'source'
BASE = '32b3c4679a6f323c82529a07df9a3a87fc17d6f7'
BASE_TREE = '4399ff7e41fada989a87e8a6db4eba701f57e4cb'
TREE = '8329a7ee95419c8290c13640b3acb50886fdc41c'
FILE = 'cmd/mcphub/main_test.go'
HASH = '2c10343ad035722c3e03af41546d2a2f95118daae5bbf25eddb68f0ac6b3ae42'
GIT = r'<GIT_EXECUTABLE>'
if len(sys.argv) != 2 or not re.fullmatch('[0-9a-f]{40}', sys.argv[1]):
    raise SystemExit('An exact commit is required')
expected = sys.argv[1]
out = ROOT / 'evidence/published-checkout'
out.mkdir(exist_ok=False)
runtime = ROOT / 'runtime/published-checkout'
for part in ('tmp', 'profile', 'appdata', 'localappdata', 'empty-hooks'):
    (runtime / part).mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items()
       if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
env.update({'GIT_TERMINAL_PROMPT': '0', 'GIT_CONFIG_NOSYSTEM': '1',
            'GIT_CONFIG_GLOBAL': str(runtime / 'no-global-git-config'),
            'TEMP': str(runtime / 'tmp'), 'TMP': str(runtime / 'tmp'),
            'TMPDIR': str(runtime / 'tmp'), 'USERPROFILE': str(runtime / 'profile'),
            'APPDATA': str(runtime / 'appdata'), 'LOCALAPPDATA': str(runtime / 'localappdata')})
receipt = {'phase': 'published-checkout', 'previous_head': BASE, 'expected_head': expected,
           'expected_tree': TREE, 'commands': [],
           'started_utc': datetime.now(timezone.utc).isoformat(),
           'whole_process_tree_deadline_enforced': False}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


def command(args):
    return [GIT, '-c', 'core.hooksPath=' + str(runtime / 'empty-hooks'),
            '-C', str(SOURCE), *args]


def git(*args):
    return subprocess.check_output(command(args), env=env, cwd=SOURCE).decode().strip()


def ensure_root():
    if Path(git('rev-parse', '--show-toplevel')).resolve() != SOURCE.resolve():
        raise RuntimeError('Repository root mismatch')


def run(name, args):
    record = {'name': name, 'executable': 'git.exe', 'arguments': args,
              'started_utc': datetime.now(timezone.utc).isoformat(), 'settled': False}
    receipt['commands'].append(record)
    save()
    started = time.monotonic()
    with (out / (name + '.stdout.log')).open('xb') as fo, (out / (name + '.stderr.log')).open('xb') as fe:
        with subprocess.Popen(command(args), env=env, cwd=SOURCE, stdin=subprocess.DEVNULL,
                              stdout=fo, stderr=fe, creationflags=0x08000000) as child:
            record['pid'] = child.pid
            save()
            record['exit_code'] = child.wait()
            record['settled'] = True
    record['seconds'] = round(time.monotonic() - started, 3)
    for stream in ('stdout', 'stderr'):
        path = out / (name + '.' + stream + '.log')
        record[stream + '_bytes'] = path.stat().st_size
        record[stream + '_sha256'] = digest(path)
    save()
    if record['exit_code'] != 0:
        raise RuntimeError(name + ' failed')


try:
    receipt['script_sha256'] = digest(Path(__file__))
    gates = json.loads((ROOT / 'evidence/gates/receipt.json').read_text(encoding='utf-8'))
    if (not gates.get('completed') or gates['candidate_tree'] != TREE or
            gates['file_sha256_after'] != HASH or
            [c['name'] for c in gates['commands']] != ['build', 'vet', 'full-test', 'tagged-api-cli'] or
            not all(c.get('settled') is True for c in gates['commands'])):
        raise RuntimeError('Gate evidence incomplete')
    ensure_root()
    if (git('rev-parse', 'HEAD') != BASE or git('rev-parse', 'HEAD^{tree}') != BASE_TREE or
            git('status', '--porcelain=v1', '--untracked-files=all') != 'M  ' + FILE or
            git('diff', '--name-only') != '' or git('diff', '--cached', '--numstat') != '5\t0\t' + FILE or
            git('write-tree') != TREE or digest(SOURCE / FILE) != HASH):
        raise RuntimeError('Prepared source mismatch')
    receipt['prepared_file_sha256'] = HASH
    receipt['prepared_tree'] = TREE
    run('fetch', ['fetch', '--no-tags', 'https://github.com/applicate2628/mcp-local-hub.git', expected])
    if (git('show', '-s', '--format=%P', expected) != BASE or
            git('rev-parse', expected + '^{tree}') != TREE):
        raise RuntimeError('Published parent or tree mismatch')
    run('checkout', ['checkout', '--detach', expected])
    ensure_root()
    receipt.update({'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                    'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
                    'status': git('status', '--porcelain=v1', '--untracked-files=all'),
                    'file_sha256': digest(SOURCE / FILE)})
    if (receipt['head'] != expected or receipt['tree'] != TREE or receipt['parents'] != [BASE] or
            receipt['status'] != '' or receipt['file_sha256'] != HASH):
        raise RuntimeError('Published checkout changed')
    receipt['completed'] = True
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps({'head': receipt['head'], 'tree': receipt['tree'], 'parents': receipt['parents'],
                  'clean': True, 'completed': True}), flush=True)
