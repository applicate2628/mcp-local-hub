# CMake: пакет Windows-квалификации на точном master

**Статус: подготовлен локально; entry, formatter, Go и удалённые действия не выполнялись.** Root рассматривает байты, выполняет upload и решает о каждом запуске. Новый вход импортирует существующий закреплённый `p0_serena_runner.py`; собственная реализация владения процессом, `Popen`, ожидания, окружения и Windows-наблюдателя не добавлена.

## Оглавление

1. [Входы и происхождение](#1-входы-и-происхождение)
2. [Точные файлы передачи](#2-точные-файлы-передачи)
3. [Форматирование новых копий](#3-форматирование-новых-копий)
4. [Семь фаз квалификации](#4-семь-фаз-квалификации)
5. [Контроль и ожидаемые события](#5-контроль-и-ожидаемые-события)
6. [Владение, эффекты и квитанции](#6-владение-эффекты-и-квитанции)
7. [Что не подтверждается](#7-что-не-подтверждается)

## 1. Входы и происхождение

ROOT: `D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5`. Physical source — уже существующий чистый `ROOT\source-master`, HEAD `75dbc6406123e22468f168b861d5e0622c9d5769`, tree `cb3eec77c23f9400be962d91c9f23834b84f7643`. Ни prepare, ни fetch, ни checkout в этом пакете нет.

Полезный Go-остаток #624 берётся из точного HEAD `81dcf67db013ba2879878c2ee6fe07aa0bb4aec3`, tree `50585004a112d5ca4c8c35b105d129fac5d88c4c`. Пять logical overlays перечислены в таблице 1. SHA-256 — хеш точных байтов; Git blob — идентичность файлового объекта Git. Они не доказывают успешное исполнение.

**Таблица 1 — полная исходная композиция.** Общий префикс путей: `internal/vcpkgmcp/cmaketrace/`.

| Файл | Относительно master | Происхождение и назначение |
|---|---|---|
| `cmaketrace.go` | Замена существующего файла | Master + прежний clear-tail из #624 + пять новых строк terminal context check. Исходный master blob `1818f4b69224b8c4839709a79244aa2d6f3dfae5`; кандидат `d85745df93fbbb285960adf7cb248a8ec3846eb4`. |
| `parse_benchmark_test.go` | Новый | Точный donor blob `622e4769f63e6577062a9edb9e7614dffc571358`; сохраняется для полноты полезного Go delta, benchmark не запускается. |
| `trace_benchmark_contract_test.go` | Новый | Точный donor blob `fd0291bfa558ef7562f315d9a2412296e86aaef4`; компилируется, но не выбран для исполнения. |
| `trace_retained_records_test.go` | Новый | Точный donor blob `07cd515ba4edb7d88d48db871742bf65e784c757`; его шесть случаев входят в положительный соседний контроль. |
| `trace_terminal_cancellation_test.go` | Новый | Кандидатный blob `8da0a111d3453b033423931ce78f859b9ee0179a`; восемь новых EOF-сценариев. |

Отдельный шестой Go payload находится под `control/` и не является шестым logical overlay. Это исходный `cmaketrace.go` из #624: 24441 байт, SHA-256 `53a704edffffdd7ee7c8de95584f20f46ac7e6cad405446c05b56ed7c5c396b0`, Git blob `d4a988c65d2dc4738d6a6a87973db310baf8b6ac`. Только две control-фазы подставляют его вместо кандидатного production-файла. Все остальные overlay paths и байты test files одинаковы.

В [source-composition-proof.json](cmake-manifests/cmake-staged/source-composition-proof.json) проверено:

- кандидат минус точный новый блок из пяти строк равен #624 побайтно;
- #624 минус точный прежний clear-tail равен master побайтно;
- три donor test files сохранены побайтно;
- четыре additions отсутствуют в exact master; новый EOF test отсутствует и в #624;
- master-package имеет 17 Go-файлов, #624 — 20, без дополнительных init/TestMain.

Это точечная композиция. Она не переносит master целиком в старую ветку и не содержит чужие PR. Независимое source review: [REVIEW.md](../cmake-consumer-audit/peer-review/REVIEW.md).

## 2. Точные файлы передачи

Использовать только новые назначения. Не заменять существующий capture owner и не перезаписывать ранее созданный `cmake-staged` или evidence/runtime какой-либо фазы.

Передаются ровно десять текстовых файлов напрямую. ZIP извлекать не требуется. Полные локальные и целевые пути, размеры и SHA-256 каждой копии закреплены в [cmake-qualification-transfer.json](cmake-qualification-transfer.json), SHA-256 `0a5a272d2fabe2ed19772e229af8ef7cae542b60a4941d9ec38a72770bac2cef`.

**Таблица 2 — десять новых входов.** В строках 3–10 целевые пути отсчитываются от `ROOT/manifests/cmake-staged/`; общий Go-префикс — `internal/vcpkgmcp/cmaketrace/`.

| Локальный файл | Назначение относительно ROOT | SHA-256 |
|---|---|---|
| [p0_cmake_runner.py](p0_cmake_runner.py) | `p0_cmake_runner.py` | `c950f9cbfbae4bad2fc96b48af2fd9230d3c71be40614b548c87bb034ee4bd99` |
| [format_cmake_staged.py](format_cmake_staged.py) | `format_cmake_staged.py` | `f355b52fe0ee7845ceb3164129b676a8627a7cce164252f13a7d38dff2c255e7` |
| [manifest.json](cmake-manifests/cmake-staged/manifest.json) | `manifest.json` | `1941c6ae371622143313e0cbf090c76de72c88aecf3ce3244f33ee1d0b55fb8d` |
| [source-composition-proof.json](cmake-manifests/cmake-staged/source-composition-proof.json) | `source-composition-proof.json` | `7415a692b7bfbc5a68681ba11525403411dcd4b73c5d1e0114eb69b545d3c3f5` |
| Candidate `cmaketrace.go` | `candidate/` + Go-префикс + имя | `d51adc76972be45cb36cf1a436c8a94a61ba1ed6e571e070697d9882601daa2a` |
| Candidate `parse_benchmark_test.go` | `candidate/` + Go-префикс + имя | `2537a50dd350a416746d6499ea8590be409d2a7dc49d65b063c3cb8c775750d9` |
| Candidate `trace_benchmark_contract_test.go` | `candidate/` + Go-префикс + имя | `e350d2b99622db990f029c941407f8f4e243d925ee89b57b3be2651311812659` |
| Candidate `trace_retained_records_test.go` | `candidate/` + Go-префикс + имя | `c58aea2aa4fd6953dd5db007bf63ecfc858020f4b32238a22cb58e15e000719a` |
| Candidate `trace_terminal_cancellation_test.go` | `candidate/` + Go-префикс + имя | `0e9336b2a583646935766d7c1dd0082ae33cef69d566f3e0267a7397b6e4b383` |
| Control `cmaketrace.go` | `control/` + Go-префикс + имя | `53a704edffffdd7ee7c8de95584f20f46ac7e6cad405446c05b56ed7c5c396b0` |

Необязательная локальная копия того же восьмифайлового набора входов — [cmake-qualification-inputs.zip](cmake-qualification-inputs.zip), 29863 байта, SHA-256 `2e4a3391940cdc0dc208681a44f521aa86825aa077c78cb8bd9a2f8367be40f3`. Она содержит пять `candidate/**/*.go`, один `control/**/*.go`, `manifest.json` и `source-composition-proof.json`; оба Python-файла передаются отдельно. Исполняемых `.exe`, runtime/temp деревьев, модулей или посторонних файлов в ZIP нет. Все восемь entry lengths/SHA и совпадение с локальными байтами проверены.

Исходный manifest: SHA-256 `1941c6ae371622143313e0cbf090c76de72c88aecf3ce3244f33ee1d0b55fb8d`. Source proof: SHA-256 `7415a692b7bfbc5a68681ba11525403411dcd4b73c5d1e0114eb69b545d3c3f5`.

Обязательный уже существующий вход: `ROOT\p0_serena_runner.py`, SHA-256 `c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1`. Он импортируется только после сверки pin. Его неизменённый capture-код является производной исходного `p0_preserved_runner_v2.py` с SHA-256 `b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641`.

В квитанции `runner_sha256` означает именно этот capture owner `c3d…`. Новый `qualification_entry_sha256` отдельно обозначает CMake entry `c950…`; manifest SHA связывает оба. Эти поля нельзя объединять или приписывать новому entry старую native-квалификацию целиком.

Собственная статическая сверка сохранена в [cmake-runner-source-proof.json](cmake-runner-source-proof.json), SHA-256 `b364d9b706893627c35a9e7affac350eaa722017d80b798509e04c12288efd76`: AST (абстрактное синтаксическое дерево) обоих файлов разобрано без их импорта и исполнения; прямых новых process primitives, классов Runner или копий lifecycle methods нет. Проверены точные pins, все argv/oracles, subtraction и архивные байты. Подтверждённых дефектов после собственного чтения не осталось; это source review, а не runtime qualification.

## 3. Форматирование новых копий

Ниже `python` означает уже допущенный root существующий интерпретатор, без поиска или установки. Рабочий каталог — ROOT. После проверки upload root может отдельно рассмотреть эту команду:

```text
python format_cmake_staged.py 1941c6ae371622143313e0cbf090c76de72c88aecf3ce3244f33ee1d0b55fb8d f355b52fe0ee7845ceb3164129b676a8627a7cce164252f13a7d38dff2c255e7
```

Это отдельный scope `cmake-stage-format`. Вызывается один `gofmt -w` только для пяти новых staged candidate-копий. Immutable control, исходный master и локальные исходные кандидаты не передаются formatter. GOFMT pin: `95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5`, уже существующий `C:\msys64\ucrt64\bin\gofmt.exe`.

Formatter создаёт новый `manifests/cmake-staged/manifest.formatted.json`, записывая фактические новые candidate hashes и original-manifest hash. Final receipt содержит все пять resulting contents и исходные source/tool identities. Начальный source proof относится к исходному freeze; возможный formatting delta должен получить собственный readback.

**До следующей фазы root читает обратно** окончательный `evidence/cmake-stage-format/receipt.json`, stdout/stderr, source/tool/entry hashes, все изменённые staged bytes и новый manifest. Требуются `completed: true`, `state: complete`, неизменный physical source/control/tool, правильный native temporary path и согласованные captured stream hashes. Одно присутствие файла `manifest.formatted.json` этого не доказывает: более поздняя финальная проверка могла завершиться отказом.

SHA formatted manifest заранее неизвестен и здесь не подставлен. Только после readback он заменяет плейсхолдер в интерфейсе:

```text
python p0_cmake_runner.py cmake-format manifests/cmake-staged/manifest.formatted.json REVIEWED_FORMATTED_MANIFEST_SHA256
```

Каждая следующая фаза вызывается отдельно с тем же точным manifest/hash. Автоматического перехода, цикла фаз или retry нет. Неудачная квитанция и её каталоги сохраняются.

## 4. Семь фаз квалификации

**Таблица 3 — порядок и границы.**

| Фаза | Production overlay | Действие |
|---|---|---|
| `cmake-format` | candidate | `go version`, затем `gofmt -l` пяти candidate files; вывод списка файлов означает отказ. |
| `cmake-compile-control` | exact #624 | `go test -race -c` одного пакета, executable только в собственном evidence. Test bodies не исполняются. |
| `cmake-compile-candidate` | candidate | Та же компиляция в другом scope. |
| `cmake-negative-control` | exact #624 | Только новый EOF root; ожидаются четыре live PASS и четыре canceled FAIL. |
| `cmake-candidate-targeted` | candidate | Только новый EOF root и четыре явных соседних root из согласованного плана. |
| `cmake-build` | candidate | `go build ./internal/vcpkgmcp/cmaketrace`: affected-package gate, только затронутый пакет. |
| `cmake-vet` | candidate | `go vet ./internal/vcpkgmcp/cmaketrace`: affected-package gate, только затронутый пакет. |

Все Go-команды получают `-overlay` с новым собственным `overlay.json` и `-mod=readonly`. Compile/test используют уже существующий race toolchain; `-race` включает детектор гонок данных. Test-команды также имеют `-json -count=1 -timeout=30s -parallel=1`. Внешний original-child deadline — 300 секунд для test, 600 секунд для compile/build/vet, 30 секунд для version/format. Исходные owner deadlines read-only Git и termination wait сохранены: 180 и 15 секунд.

Точные selectors:

```text
^(TestTraceCancellationAtTerminalRead)$
```

```text
^(TestTraceCancellationAtTerminalRead|TestF26_CancellationDuringTheParseStopsReadingMidStream|TestF26_CanceledRequestFailsClosedAndStopsReading|TestR32OversizedLineDrainStopsOnCancellation|TestTraceReturnedRecordsClearDiscardedReferences)$
```

Entry проверяет phase labels, variant, полный argv и exact terminal oracle. Аргументы для `./...`, чужого пакета, benchmark, отсутствующий `-run`, расширенный selector или иной исполнитель не принимаются. Три donor files компилируются в обеих композициях; benchmark и benchmark-contract test не выбираются для исполнения.

## 5. Контроль и ожидаемые события

**Таблица 4 — предсказанные различающие результаты, ещё NOT_RUN.**

| Запуск | Leaf-события | Root/package | Go exit |
|---|---|---|---:|
| Negative control | Четыре `/live` PASS; четыре `/canceled` FAIL | Новый root FAIL, package FAIL; всего шесть FAIL events | 1 |
| Candidate targeted | Восемь EOF leaf PASS; шесть retained-tail leaf PASS | Пять root PASS, один package PASS; всего 20 PASS events | 0 |

Все имена закреплены в manifest. Отсутствующий соседний root, skip, неожиданный дополнительный fail, compile failure либо истёкший test/outer deadline не засчитываются как корректный отрицательный контроль. Его stdout должен содержать исходный `Trace result=` и ожидаемый `unknown(canceled)` assertion.

На правильно различившем negative control сам qualification entry может завершиться с кодом 0 и `completed: true`, потому что **сопоставил ожидаемый отказ**. При этом raw Go exit 1, четыре failed leaf, failed root/package и полный JSON/stdout/stderr остаются в квитанциях. Это не test PASS. Compile и build/vet события также не выдаются за исполненные test bodies.

## 6. Владение, эффекты и квитанции

`Runner` не скопирован и не переопределён. CMake entry вызывает оригинальные `begin/admit/run/check_command/finish`. Сохранены original `Popen`, владение исходным process handle, capture stdout/stderr, bounded waits, source/tool before/after snapshots и правила unresolved descendants после timeout. PID-only cleanup или новый observer не введены.

Каждая фаза, включая stage-format, использует неизменённый `Runner.begin`. После создания нового `runtime/<phase>/tmp` он проверяет реальный `GetTempPath2W` либо `GetTempPathW` под заданными TMP/TEMP, требует точного совпадения с собственным D-path, записывает `native_temporary_path` и восстанавливает окружение Python в `finally`. Проверка происходит до первого дочернего процесса. Это наблюдение native temp selection; оно не является доказательством ACL-владения, отсутствия ancestor race или sandbox. ROOT и staged files должны быть созданы root как собственные обычные независимые копии без reparse points.

Перенаправления окружения и offline policy унаследованы без изменений: `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOVCS=*:off`, `GOENV=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, telemetry off, существующие Go caches на D. Отсутствие cache/tool — отказ; installation и download не добавлены. Go pin: `0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113`, `go1.27.4 windows/amd64`, `C:\msys64\ucrt64\bin\go.exe`.

У выбранных test bodies нет CMake/Scheduler/installed Product/process launch или listener. Новый EOF root использует восемь TempDir allocations и mock FS; реальный trace file не открывается. Два F26-контроля используют свои TempDir; mid-stream case создаёт 200000-record строку в памяти. R32 использует reader в памяти. Retained-tail root создаёт шесть небольших реальных файлов через `writeTrace`, читает их через production `DefaultDeps` и очищает с TempDir. Это требует фактического принадлежащего test process temporary root на D. Данные `/p/…` и `/fixture/…` внутри trace не открываются как файлы.

Все 20 исходных #624 package Go files не имеют `init`/`TestMain`; новый файл тоже их не добавляет. Независимый master inventory и полный анализ этих вызовов сохранены в peer review. Для CMake selector не требуются API/CLI helper-role dispatch overlays; они вообще не вызываются этой цепочкой.

Source master до/после каждого child должен быть тем же HEAD/tree и полностью чистым. Проверяются SHA/Git blob одного существующего и четырёх отсутствующих source paths, всех пяти candidates и immutable control. Отдельно закреплены entry и imported owner до/после. Runtime/evidence остаются для review. Подтверждённо ненужные остатки после завершения работы перемещает root в разрешённый trash; runner их автоматически не удаляет.

## 7. Что не подтверждается

Пакет готовит проверяемый план; он не утверждает компиляцию, формат или успешное выполнение. Не выполняются полный пакет без selector, весь Go suite, benchmark, реальный MCP consumer profile, CMake configure, установка инструмента, native process-tree qualification или PR/refs действия.

Результаты будущего запуска относятся к physical master75 + пяти overlays. Они не являются standalone qualification старого #624 или его будущей опубликованной головы. Прежние результаты R25 и clear-tail сохраняются у существующего владельца #624; эта работа не открывает дублирующий PR. Отмена внутри последующего построения индексов и потеря MCP-сессии остаются вне рассматриваемых пяти строк.
