# CMake: экспорт восьми фаз проверки

Экспортёр подготовлен локально. Его главный вход, сбор файлов с Windows, runners, Go и удалённые действия этим агентом не выполнялись. Root читает скрипт, завершает восемь фаз и выполняет передачу/экспорт самостоятельно.

## Оглавление

1. [Закреплённые входы](#1-закреплённые-входы)
2. [Фазы и владельцы](#2-фазы-и-владельцы)
3. [Допуск и сохранение отказов](#3-допуск-и-сохранение-отказов)
4. [Передача и точная команда](#4-передача-и-точная-команда)
5. [Локальное ревью и пределы](#5-локальное-ревью-и-пределы)

## 1. Закреплённые входы

ROOT фиксирован: `D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5`. Физический исходный каталог — `ROOT/source-master`, commit `75dbc6406123e22468f168b861d5e0622c9d5769`, tree `cb3eec77c23f9400be962d91c9f23834b84f7643`.

**Таблица 1 — основные SHA-256 (хеши точных байтов).**

| Вход | SHA-256 |
|---|---|
| `export_cmake_evidence.py`, 37431 байт | `16b052d6e7f739c61c3d85b393d50376ba898fb8adbfab621ae178d93dfe480e` |
| Original manifest | `1941c6ae371622143313e0cbf090c76de72c88aecf3ce3244f33ee1d0b55fb8d` |
| Formatted manifest, 12404 байта | `a249d8c6673a59d0c166f2bfb64fc15106eeaf6a6e08823ab084bb8e1944b30e` |
| Новый `cmake-export-inputs/manifest.json`, 2941 байт | `cabf92355b19d9e4ce471fb724cd02003e22c984456fbd41e3b013e4600697af` |
| Существующий capture owner `p0_serena_runner.py` | `c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1` |
| Отдельный вход `p0_cmake_runner.py` | `c950f9cbfbae4bad2fc96b48af2fd9230d3c71be40614b548c87bb034ee4bd99` |
| `format_cmake_staged.py` | `f355b52fe0ee7845ceb3164129b676a8627a7cce164252f13a7d38dff2c255e7` |
| Source-composition proof | `7415a692b7bfbc5a68681ba11525403411dcd4b73c5d1e0114eb69b545d3c3f5` |
| Immutable production из #624 | `53a704edffffdd7ee7c8de95584f20f46ac7e6cad405446c05b56ed7c5c396b0` |

Пять logical Go paths перечислены в обоих manifests. В новом packet находятся только их пять original-копий и manifest; source proof, formatted-копии и control уже находятся под `ROOT/manifests/cmake-staged/`. Original и formatted bytes совпали при root readback, но сохраняются в разных archive namespaces. Только две control-фазы заменяют production overlay на `control/internal/vcpkgmcp/cmaketrace/cmaketrace.go`; остальные четыре файла в этой композиции те же.

Экспорт также сохраняет точный master production preimage с проверкой SHA-256 и Git blob, а для четырёх добавленных test files подтверждает отсутствие в physical master. Другие исходные файлы и весь репозиторий не копируются. Существующий upstream owner `ROOT/preserved-input/p0_preserved_runner_v2.py` включается с pin `b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641`.

## 2. Фазы и владельцы

**Таблица 2 — восемь обязательных scope.**

| № | Фаза | Manifest / production |
|---:|---|---|
| 1 | `cmake-stage-format` | Original; форматирование пяти новых candidate-копий |
| 2 | `cmake-format` | Formatted / candidate |
| 3 | `cmake-compile-control` | Formatted / exact #624 control |
| 4 | `cmake-compile-candidate` | Formatted / candidate |
| 5 | `cmake-negative-control` | Formatted / exact #624 control |
| 6 | `cmake-candidate-targeted` | Formatted / candidate |
| 7 | `cmake-build` | Formatted / candidate; только затронутый пакет |
| 8 | `cmake-vet` | Formatted / candidate; только затронутый пакет |

Во всех command/observation rows поле `runner_sha256` принадлежит capture owner `c3d…`. В aggregate `qualification_entry_sha256` отдельно указывает на CMake entry `c950…`, а `qualification_entry_path` — на `ROOT/p0_cmake_runner.py`. Поля before/after обоих владельцев должны совпадать с pins. У staged formatter дополнительно сверяются его собственные before/after hashes и содержимое всех пяти resulting files.

Перед созданием каталога экспорта требуются окончательные `receipt.json` всех восьми scope. Состояние `running`, отсутствие terminal receipt, незавершённый исходный child или unresolved process tree приводят к отказу. Для provenance formatted-копий `cmake-stage-format` должен быть `complete`; у последующих фаз допускается согласованное terminal `failed` с полными сохранёнными свидетельствами. Неполный набор не экспортируется как завершённый.

## 3. Допуск и сохранение отказов

Скрипт сверяет manifest/script/source identities, полный выбранный argv, bounded deadlines, source snapshots, native temporary-path observation и четыре tool hashes. Git observations допускаются только в пяти исходных read-only формах snapshot owner. Никакие команды, Git, Go или Windows API самим экспортёром не вызываются.

Начальный `settled: false` в `*.started.json` и `*.launched.json` является исходным состоянием; окончательное завершение проверяется по соответствующему `*.receipt.json` и aggregate. Их имена, argv, временная отметка старта, PID и идентичности должны согласоваться. Для каждого сохранённого stdout/stderr проверяются фактическая длина и SHA-256. Go JSON разбирается повторно, а исходные terminal events сравниваются с receipt.

**Отрицательный результат остаётся отрицательным:** ожидаются Go exit `1`, четыре live `PASS` и шесть `FAIL` — четыре canceled leaf, root и package. `oracle_matched: true` означает совпадение с этим ожидаемым исходом. Он не меняет exit и не превращает события в PASS. При совпавшем oracle обязательны точные terminal-event multiplicities и обе diagnostics; при неожиданном terminal отказе raw streams и `failed` сохраняются без выдуманного совпадения. События SKIP не вырезаются; успешный matched oracle с SKIP отвергается.

Контрольный overlay обязан указывать на immutable `control/` production ровно в двух фазах таблицы 2. Во всех остальных фазах используется `candidate/`. Executable, созданный compile, не открывается и не включается в ZIP; его уже записанная длина/SHA остаётся в oracle. Включаются scripts, manifests, original/formatted/control Go bytes, master preimage, source proof, argv, начальные/launch/final receipts, stdout/stderr, Go JSON и наблюдения before/after.

Файлы отбираются по фиксированным именам непосредственно в восьми evidence directories. Обхода runtime, temporary/profile/cache trees или чужих подпапок нет. `.exe`, private audits и traceback files исключаются до чтения. Неизвестный process artifact не пропускается молча. Ни один инструмент с C: не перечитывается: сохраняются его ранее записанные hashes. Все читаемые файловые пути ограничены ROOT.

## 4. Передача и точная команда

Полный список новых прямых uploads — [cmake-export-upload-list.json](cmake-export-upload-list.json): один exporter, один packet manifest и пять original Go-копий, всего **семь текстовых файлов**. ZIP extraction для передачи не требуется. Runners, formatter и staged manifests уже существуют; повторно заменять их не нужно.

После полного root review, завершения всех восьми scope и проверки перенесённых bytes существующим Python из ROOT используется ровно:

```text
python -B export_cmake_evidence.py 16b052d6e7f739c61c3d85b393d50376ba898fb8adbfab621ae178d93dfe480e
```

Новая область записи — `ROOT/evidence/cmake-export-v1`. Она должна отсутствовать; overwrite, resume, retry или удаление в exporter не предусмотрены. Все входы, включая ожидаемое отсутствие новых test paths в physical source, повторно проверяются перед `mkdir`.

В новом каталоге появляются `cmake-evidence.zip`, transfer JSON/text, отдельный archive receipt и общий receipt. ZIP содержит `MANIFEST.json` с длиной и SHA-256 каждого исходного archive member. Собственные длина/SHA `MANIFEST.json` записываются во внешних transfer metadata. Имена сортируются, timestamps и режимы ZIP закреплены; исходные журналы не переписываются. Пределы — 32 МиБ на входной файл, 128 МиБ на суммарное несжатое содержимое с manifest и 10000 archive members.

## 5. Локальное ревью и пределы

[cmake-export-review.json](cmake-export-review.json) фиксирует собственный просмотр и 18 проверок изолированных чистых validators: сохранение negative exit/FAIL; отказ при missing final/start/launch/stdout, неправильном capture owner/manifest, изменённом потоке, скрытом raw FAIL, неверном exit/diagnostic, unsettled final или ложном matched SKIP; допустимость terminal unmatched failure; точный source map; полную строку версии Go; детерминированность ZIP и чтение его членов. AST — абстрактное синтаксическое дерево — разбиралось без импорта exporter module; исполнялись только выбранные чистые функции над локальными данными. Главный вход и файловый collector не запускались.

Пятнадцать общих функций побайтно сохранены из проверенного `export_serena_evidence.py`. Разность доступна в [cmake-export.patch](cmake-export.patch). С локальным semantic stage receipt совпали master source fields; authoritative raw D receipts и streams здесь не подменяются этой копией.

[cmake-export-local-outer.json](cmake-export-local-outer.json) перечисляет peer/entry reviews и локальные дополнительные свидетельства для итогового внешнего архива. В том числе сохранены оба файла `cmake-local-readback/`: первоначальная копия formatted manifest с лишним завершающим LF и квитанция её обнаружения/исправления. Это **локальный serialization/hash failure**; remote original не менялся, а remote format phase использовал верный `a249…`. Событие не объявляется Go failure или ошибкой удалённой квалификации и не скрывается за успешным readback.

Экспорт не подтверждает весь Go suite, полный пакет без selector, benchmark, реальную CMake configure/install операцию, installed Product, сетевой MCP consumer либо самостоятельную опубликованную голову #624. Отдельные temp-path observations не доказывают ACL-владение или отсутствие гонок ancestor paths. Исходный owner сохраняет original process handle и bounded wait; завершение всего дерева процессов не заявляется. Успешный экспорт означает согласованное сохранение выбранных свидетельств, а не общий PASS.
