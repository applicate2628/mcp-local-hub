# CMake: независимое ревью терминальной отмены

**Результат: подтверждённых дефектов в двух файлах freeze не найдено.** Проведено чтение исходников, вычисление хешей и проверка состава файлов. Go, gofmt, CMake, тесты, удалённые процессы, Git refs и публикации не выполнялись. Этот результат не является runtime PASS.

## Оглавление

1. [Входы и минимальная правка](#1-входы-и-минимальная-правка)
2. [Восемь оракулов](#2-восемь-оракулов)
3. [Публичный результат](#3-публичный-результат)
4. [Эффекты и состав master](#4-эффекты-и-состав-master)
5. [Пределы ревью](#5-пределы-ревью)

## 1. Входы и минимальная правка

PR #624: `81dcf67db013ba2879878c2ee6fe07aa0bb4aec3`. Master: `75dbc6406123e22468f168b861d5e0622c9d5769`.

**Таблица 1 — проверенные кандидаты.**

| Путь | SHA-256 | Байты |
|---|---|---:|
| `internal/vcpkgmcp/cmaketrace/cmaketrace.go` | `d51adc76972be45cb36cf1a436c8a94a61ba1ed6e571e070697d9882601daa2a` | 24631 |
| `internal/vcpkgmcp/cmaketrace/trace_terminal_cancellation_test.go` | `0e9336b2a583646935766d7c1dd0082ae33cef69d566f3e0267a7397b6e4b383` | 3683 |

Повторно проверены длины и SHA-256 всех 12 файлов из manifest. Для 20 исходных Go-файлов пакета #624 дополнительно восстановлены Git blob. Новое production-изменение — ровно пять строк после `parseTraceStream` в `Trace:407–412`. Если parser уже вернул ошибку, она сохраняется. Только успешная передача управления получает дополнительную проверку `ctx.Err()`, прежде чем строятся индексы или публикуются частичные сведения.

Статическим удалением только этого блока получен побайтно исходный #624; удалением только прежнего clear-tail из #624 получен побайтно master. Это проверка разности файлов, без git merge. Машиночитаемый результат: [static-checks.json](static-checks.json).

## 2. Восемь оракулов

EOF — end of file, конец файла. `terminalCancelTraceReader.Read` сначала вызывает `strings.Reader.Read`, затем отменяет контекст только при фактическом EOF. Входы меньше 64 КиБ внутреннего буфера, не имеют завершающего LF; возврат EOF внутри `ReadSlice` происходит после проверки context в `readLine`. Fixture тем самым достигает именно пропущенной границы, без таймеров и гонки планировщика.

**Таблица 2 — четыре входа, по два режима.**

| Вход | Фактический путь parser | Обычный EOF | EOF с отменой |
|---|---|---|---|
| `valid_record` | Заголовок уже обработан; последняя запись принимается вместе с EOF; parser возвращает nil error. | `ok`, одна запись, одна строка исполнения, один файл, header=true. | Кандидат возвращает пустой `unknown(canceled)` с path evidence; старый исходник возвращал полезный результат. |
| `header_only` | Финальный header разбирается после EOF; записей нет. | `unknown(no_records_matched)`, header=true, коллекции nil. | Тот же пустой `unknown(canceled)`, без сохранённого header flag. |
| `malformed_tail` | Header и запись уже приняты; `{` с EOF увеличивает malformed count и заканчивает parse с nil error. | `ok`, прежняя запись/индексы, incomplete=true, одна причина `input_malformed`, count=1. | Пустой `unknown(canceled)`, без частичных коллекций и признаков прочитанного хвоста. |
| `oversized_tail` | 256 байт хвоста превышают `MaxLineBytes=128`, но помещаются в buffer; `readLine` возвращает tooLong=true вместе с EOF. `parseTraceStream:147–154` отмечает line limit и malformed и возвращает nil error. | `ok`, прежняя запись/индексы, incomplete=true, причины `input_malformed`, затем `line_limit`, count=1. | Пустой `unknown(canceled)` через новую проверку успешного handoff. |

Все восемь случаев требуют ровно одного наблюдённого EOF и одного `Close` mock reader. Cancel-режим отдельно проверяет, что контекст действительно отменён, live-режим — что он остаётся действующим. Предсказание по коду: одинаковый новый test file со старым production должен принять четыре live leaf и отвергнуть четыре canceled leaf. Это предсказание, не результат запуска.

## 3. Публичный результат

`want` задаётся независимо от реализации Trace; второй вызов Trace для построения эталона не используется. `reflect.DeepEqual(got, want)` проверяет все поля `Result`, включая отсутствие частичных records/indexes/header/incomplete flags на canceled-пути.

Прослежены `Evidence.AddPath`, `Result.PublicResultRequiresProjection`, `publicresult.MarshalIndent` и JSON decode. Для этих малых fixtures предел 256 КиБ не достигается; projection не вызывается. Evidence содержит ровно исходный абсолютный path без нормализации. Пустые nil-коллекции с `omitempty` отсутствуют в JSON и после decode снова nil; непустые records, args, indexes и ordered reasons сохраняются. `VersionHeaderPresent`, `InputIncomplete`, `MalformedLineCount` и `Truncated` также сравниваются. В header-only control `buildDerivedIndexes` возвращает nil-коллекции, поэтому нет ложного расхождения nil против empty slice.

Проверка wire-ветви утверждает равенство полей после существующей сериализации и decode. Она не является отдельным byte-for-byte golden JSON и не проверяет неизвестные дополнительные JSON-поля. Для рассматриваемой пятистрочной правки это не подтверждённый дефект: сериализатор, schema и projection не изменяются.

## 4. Эффекты и состав master

`fsReturning` возвращает `singleReaderFS`; `OpenRegular` отдаёт исходный reader и mock regular `FileInfo`. Native opener не вызывается. `unusedTracePath` вызывает `t.TempDir()` и добавляет имя `unused-trace.json`, не создавая и не открывая этот файл. Восемь новых leaf дают восемь вызовов TempDir и автоматическую очистку принадлежащих тесту каталогов. `/p/CMakeLists.txt` является только содержимым trace/результата и не используется для файлового доступа. Нет shell, external executable, listener, установленного CMake/Product или новых goroutine.

Весь выбранный positive selector шире нового теста: два F26-контроля тоже используют свои TempDir, R32 работает только с reader в памяти, а `TestTraceReturnedRecordsClearDiscardedReferences` создаёт шесть реальных небольших файлов через `writeTrace`, читает их через `DefaultDeps` и удаляет вместе с собственными TempDir. Эти операции требуют фактически принадлежащего запуску temp root на D; перенаправление environment само по себе не объявляется sandbox.

Независимый GitHub directory read точного master подтвердил **17 Go-файлов** cmaketrace, без дополнительных неизвестных путей. Они совпадают с #624, кроме production clear-tail. Все 20 Go-файлов #624 проверены на отсутствие `init` и `TestMain`; единственные package-level vars — error sentinel R32 и compile-time interface assertion. На Windows выбранные package imports остаются стандартной библиотекой плюс production `evidence`/`publicresult`. Полнота этих двух leaf packages проверена по directory API; дополнительно прочитан `evidence/presence.go`, в котором нет initializer или вызова файловой операции при входе в пакет. [master-entry-inventory.json](master-entry-inventory.json).

**Существенное условие композиции:** для исполнения positive selector на preserved master нужно дополнительно наложить `trace_retained_records_test.go`, Git blob `07cd515ba4edb7d88d48db871742bf65e784c757`. Его корень уже перечислен в selector, но отсутствует в master. Два candidate overlay сами по себе этот корень не создают, и Go может молча не выбрать отсутствующее имя. Root уведомлён до запуска. На exact #624 этот файл уже есть. Остальные donor additions — `parse_benchmark_test.go` и `trace_benchmark_contract_test.go`; новый EOF oracle от них не зависит, прежний PR сохраняет их сам.

Для нового отрицательного контроля достаточно одинакового нового test file и различия только production guard; полезный clear-tail следует сохранять одинаково в обеих сравниваемых композициях. Это позволяет приписать четыре ожидаемых отказа именно терминальной отмене.

## 5. Пределы ревью

Прочитаны полный двухфайловый patch, parser, методы Trace/result normalization, helpers и тела выбранных смежных тестов; проверены README, manifest, test-plan и их pins. Нет подтверждённых дефектов правки или восьми оракулов. Реальный preserved checkout и native temporary-path admission остаются проверкой root; локальное сравнение закрепляет источники, а не remote tree.

Компиляция, форматирование, выполнение selector, race, настоящий consumer profile, native Windows/Unix file-reader qualification, полный пакет и полный Go gate — NOT_RUN этим ревью. Отмена, возникшая позже во время построения/сортировки индексов, и lifetime MCP-сессии не входят в данную правку и в документах не объявлены исправленными.
