"""Bind formatted reader bytes to the already-reviewed fixed runner scope."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
READER = ROOT.parent / "reader"
SOURCE = ROOT.parent / "source"
BASE = "858812988833a84368c60fba1540ae601155fa71"
TREE = "dba685c090952a93a80a1e82403c4646ad8aaed1"
scope = json.loads((ROOT / "reader-runner-scope.json").read_text())
runner = (ROOT / "reader_runner.py").read_bytes()
assert hashlib.sha256(runner).hexdigest() == scope["runner_sha256"]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

originals = {}
for relative in scope["paths"]:
    result = subprocess.run(["git", "cat-file", "blob", BASE + ":" + relative], cwd=SOURCE, capture_output=True)
    if result.returncode == 0:
        originals[relative] = result.stdout
    else:
        assert b"does not exist" in result.stderr, result.stderr
        originals[relative] = None

transfers, summaries = [], []
for variant in ("control", "candidate"):
    out = ROOT / "reader-qualification" / variant
    entries = []
    for relative in scope["paths"]:
        fixture = ROOT / "fixtures" / relative
        candidate = READER / "overlays" / relative
        control = READER / "control" / relative
        chosen = fixture if fixture.is_file() else control if variant == "control" and control.is_file() else candidate
        raw = chosen.read_bytes()
        before = originals[relative]
        entry = {"path": relative, "source_sha256": sha(before) if before is not None else None,
                 "source_git_blob": blob(before) if before is not None else None,
                 "candidate_sha256": sha(raw), "candidate_git_blob": blob(raw), "candidate_bytes": len(raw)}
        entries.append(entry)
        target = out / "candidate" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(raw)
        transfers.append({"relative": "reader-qualification/" + variant + "/candidate/" + relative,
                          "content": raw.decode(), "sha256": sha(raw), "bytes": len(raw)})
    manifest = {
        "schema": 1, "composition": variant, "source_head": BASE, "source_tree": TREE,
        "runner_sha256": scope["runner_sha256"], "native_scheduler_operations": False,
        "candidate_stage": "source-reviewed-format-required", "command_timeouts": {"git": 30, "termination": 10},
        "files": entries,
        "phases": {phase: {"overlay_paths": scope["paths"], "commands": scope["commands"][phase]}
                   for phase in scope["phases"][variant]},
    }
    raw = (json.dumps(manifest, indent=2) + "\n").encode()
    with (out / "manifest.json").open("xb") as stream:
        stream.write(raw)
    transfers.append({"relative": "reader-qualification/" + variant + "/manifest.json", "content": raw.decode(), "sha256": sha(raw), "bytes": len(raw)})
    summaries.append({"composition": variant, "manifest_sha256": sha(raw), "files": len(entries), "phases": sorted(manifest["phases"])})
with (ROOT / "reader-transfer.json").open("x") as stream:
    json.dump(transfers, stream)
with (ROOT / "reader-manifest-summary.json").open("x") as stream:
    json.dump(summaries, stream, indent=2)
    stream.write("\n")
print(json.dumps(summaries))
