"""Derive the fixed reader qualification entry; never executes remote code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import pprint

ROOT = Path(__file__).resolve().parent
parent = (ROOT / "parent_relay_runner.py").read_text()
parent_sha = hashlib.sha256(parent.encode()).hexdigest()
assert parent_sha == "d8cb7090ddda09cb14a50759f56397a55ff03f3a6ce9bfc29f226788217ed17e"
plan = json.loads((ROOT.parent / "reader/qualification-plan.json").read_text())
fixtures = sorted(str(p.relative_to(ROOT / "fixtures")) for p in (ROOT / "fixtures/internal/api").glob("*.go"))
overlays = json.loads((ROOT.parent / "reader/overlays-manifest.json").read_text())
paths = sorted(fixtures + [r["path"] for r in overlays])
assert len(paths) == len(set(paths)) == 13
roots = plan["new_roots"] + [plan["existing_affected_regression_root"]]
children = {
    roots[0]: ["final-close", "parent-close", "both-closes", "stat-and-both-closes", "step-and-both-closes", "cancel-and-both-closes"],
    roots[2]: ["original-missing", "wrapped-missing-is-not-direct", "joined-missing-and-close", "joined-single-missing-is-not-direct", "open-with-compound-cause", "close-caused-not-exist", "untyped-not-exist"],
    roots[4]: ["successful-read", "prior-failure"],
    roots[5]: ["pure-missing-creates-owned-record", "missing-and-close-failure-preserves-empty-root"],
    roots[7]: ["exact-cap-capture-and-verified-rollback", "cap-plus-one", "cancellation", "checksum-mismatch", "non-regular-final-object"],
}
passes = roots + [root + "/" + child for root, names in children.items() for child in names]
assert len(passes) == 30
package = "PACKAGE:mcp-local-hub/internal/api"
def fmt(label):
    return {"label": label, "kind": "format", "args": ["-l", "{candidate_files}"], "timeout_seconds": 30, "expected_exit_code": 0}
def phase_format(name, command):
    return [fmt(name + "-format"), command]
commands = {
    "reader-format": [
        {"label": "reader-version", "kind": "version", "args": ["version"], "timeout_seconds": 30, "expected_exit_code": 0},
        fmt("reader-format"),
    ],
    "reader-control": phase_format("reader-control", {
        "label": "reader-control", "kind": "test",
        "args": ["test", "-overlay", "{overlay}", "-p=2", "-race", "-count=1", "-timeout=90s", "-json", "-run", plan["control_selector"], "./internal/api"],
        "timeout_seconds": 300, "expected_exit_code": 1,
        "required_output": ["returned error lost cause", "numeric ownership", "incomplete absence published an inverse record", "consumer replaced the combined read/close failure"],
        "expected_tests": {"pass": [], "fail": plan["control_expected_failures"] + [package], "skip": []},
    }),
    "reader-candidate": phase_format("reader-candidate", {
        "label": "reader-candidate", "kind": "test",
        "args": ["test", "-overlay", "{overlay}", "-p=2", "-race", "-count=1", "-timeout=90s", "-json", "-run", plan["candidate_selector"], "./internal/api"],
        "timeout_seconds": 300, "expected_exit_code": 0,
        "expected_tests": {"pass": passes + [package], "fail": [], "skip": []},
        "required_root_pass_counts": {root: 1 for root in roots},
    }),
    "reader-build": phase_format("reader-build", {
        "label": "reader-build", "kind": "build", "args": ["build", "-overlay", "{overlay}", "-p=2", "./..."],
        "timeout_seconds": 300, "expected_exit_code": 0,
    }),
    "reader-vet": phase_format("reader-vet", {
        "label": "reader-vet", "kind": "vet", "args": ["vet", "-overlay", "{overlay}", "-p=2", "./..."],
        "timeout_seconds": 300, "expected_exit_code": 0,
    }),
    "reader-linux-compile": phase_format("reader-linux-compile", {
        "label": "reader-linux-compile", "kind": "compile", "args": ["test", "-overlay", "{overlay}", "-p=2", "-c", "-o", "{binary}", "./internal/api"],
        "timeout_seconds": 300, "expected_exit_code": 0,
    }),
}
phases = {"control": {"reader-control"}, "candidate": set(commands) - {"reader-control"}}
doc = '''"""Qualify the fixed Go reader failure/absence composition on preserved source 858.

Derived from the pinned parent Relay runner; retained-original-Popen execution,
capture, event oracle and source/candidate checks are retained. Changes are the
owned root, fixed reader paths/argv/oracles, explicit GOOS/GOARCH (Linux only for
compile-only), all four tool pins, and full tracked source-byte admission.

Tests touch their own fenced files. Native stat/close errors are injected after
the successful operation; repeat close is refused before reaching the OS. No
scheduler/product/network/helper execution, install, fetch or checkout exists.
Full default/tagged tests and external exact-head review remain outside scope.
"""'''
source = doc + parent[parent.index('\nimport sys'):]
source = source.replace('ROOT = Path(r"D:\\dev\\ChatGPT\\mcp-p0-gates-20261121-247107d5")', 'ROOT = Path(r"D:\\dev\\ChatGPT\\mcp-next-20261122-e21a1792")')
source = source.replace('SOURCE = ROOT / "preserved-input/source-preserved"', 'SOURCE = ROOT / "source"')
source = source.replace('UPSTREAM_OWNER_SHA256 = "c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1"', 'UPSTREAM_OWNER_SHA256 = "' + parent_sha + '"')
start, end = source.index('PHASES = '), source.index('\n\ndef sha(')
fixed = '\n'.join([
    'PHASES = ' + pprint.pformat(phases, width=100, sort_dicts=True),
    'EXPECTED_PATHS = ' + pprint.pformat(paths, width=100),
    'COMMANDS = ' + pprint.pformat(commands, width=115, sort_dicts=False),
    'TOOL_PINS = {GO: GO_SHA256, GOFMT: "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5", GIT: "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48", GO.with_name("gcc.exe"): "f6ff9378c1edb591131304518eac6456708d28720284105930d0d687136bcdd3"}',
])
source = source[:start] + fixed + source[end:]
source = source.replace('len(files) != 16', 'len(files) != len(EXPECTED_PATHS)')
source = source.replace('Invalid Relay composition, source files or phase selection', 'Invalid reader composition, source files or phase selection')
source = source.replace('Each composition requires the exact 13 donor paths, response test and two canonical daemon entry paths', 'Each reader composition requires its eight change paths and five canonical API entry paths')
source = source.replace('Each Relay phase must retain all 16 reviewed overlays', 'Each reader phase must retain all thirteen reviewed overlays')
start = source.index('        kinds = [command["kind"] for command in commands]')
end = source.index('    return manifest', start)
source = source[:start] + '''        if commands != COMMANDS[name]:
            raise ValueError("Reader command arguments, deadlines or terminal-event oracles changed")
''' + source[end:]
source = source.replace('"CGO_ENABLED": "1", "GOMAXPROCS": "4", "GOTELEMETRY": "off",', '"GOOS": "linux" if self.phase == "reader-linux-compile" else "windows",\n            "GOARCH": "amd64", "CGO_ENABLED": "0" if self.phase == "reader-linux-compile" else "1",\n            "GOMAXPROCS": "4", "GOTELEMETRY": "off",')
source = source.replace('''        if sha(GO.read_bytes()) != GO_SHA256:
            raise RuntimeError("Pre-installed Go executable differs from the reviewed pin")''', '''        for tool, expected in TOOL_PINS.items():
            if sha(tool.read_bytes()) != expected:
                raise RuntimeError("Pre-installed tool differs from its reviewed pin: " + str(tool))''')
source = source.replace('"GOTELEMETRY", "TEST_TELEMETRY_DIR", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI",', '"GOTELEMETRY", "TEST_TELEMETRY_DIR", "GOMAXPROCS", "GOOS", "GOARCH", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI",')
source = source.replace('    @staticmethod\n    def require_pass(row):', '''    def verify_tracked_source(self):
        listing = self.git_at(SOURCE, "ls-tree", "-r", "-z", "--full-tree", BASE)
        rows, total = [], 0
        for record in listing.split("\\0"):
            if not record:
                continue
            metadata, relative = record.split("\\t", 1)
            mode, kind, expected_blob = metadata.split(" ")
            parsed = PurePosixPath(relative)
            if mode != "100644" or kind != "blob" or not re.fullmatch(r"[0-9a-f]{40}", expected_blob):
                raise RuntimeError("Unexpected source tree entry")
            if parsed.is_absolute() or str(parsed) != relative or any(p in {".", "..", ".git"} for p in parsed.parts) or "\\\\" in relative or ":" in relative:
                raise RuntimeError("Unsafe source tree path")
            raw = own_path(SOURCE / relative).read_bytes()
            if git_blob(raw) != expected_blob:
                raise RuntimeError("Materialized source bytes differ from pinned tree: " + relative)
            total += len(raw)
            rows.append([relative, expected_blob, len(raw)])
        if len(rows) != 3281:
            raise RuntimeError("Tracked source count differs from the reviewed tree")
        return {"tree": BASE_TREE, "matched_files": len(rows), "bytes": total,
                "inventory_sha256": sha(json.dumps(rows, ensure_ascii=True, separators=(",", ":")).encode("utf-8")),
                "inventory_schema": "ls-tree order; JSON compact ASCII rows [relative_path, git_blob, byte_length]"}

    @staticmethod
    def require_pass(row):''')
source = source.replace('''    runner.receipt["source_before"] = runner.admit()
    candidates''', '''    runner.receipt["source_before"] = runner.admit()
    runner.receipt["tracked_source_before"] = runner.verify_tracked_source()
    candidates''')
source = source.replace('''    after = runner.admit()
    runner.receipt.update(source_after''', '''    after = runner.admit()
    runner.receipt["tracked_source_after"] = runner.verify_tracked_source()
    if runner.receipt["tracked_source_after"] != runner.receipt["tracked_source_before"]:
        raise RuntimeError("Complete materialized source changed during qualification")
    runner.receipt.update(source_after''')
source = source.replace('Use p0_relay_runner_v2.py', 'Use reader_runner.py')
ast.parse(source)
(ROOT / "reader_runner.py").write_text(source)
(ROOT / "reader_runner.delta.patch").write_text(''.join(difflib.unified_diff(parent.splitlines(True), source.splitlines(True), fromfile="parent_relay_runner.py", tofile="reader_runner.py")))
(ROOT / "reader-runner-scope.json").write_text(json.dumps({"parent_sha256": parent_sha, "runner_sha256": hashlib.sha256(source.encode()).hexdigest(), "paths": paths, "phases": {k: sorted(v) for k, v in phases.items()}, "commands": commands}, indent=2) + "\n")
print(json.dumps({"runner_bytes": len(source.encode()), "runner_sha256": hashlib.sha256(source.encode()).hexdigest(), "paths": len(paths), "candidate_test_pass_events": len(passes)}))
