# Go reader: сохранение ошибок и однократное закрытие

**Состояние: подготовлены изменения и различающие тесты; Go, Rust и Comet этим агентом не запускались.** Публикация и запуск остаются у root. `gofmt` локально отсутствует; перед исполнением нужны форматирование установленным инструментом, возврат изменившихся байтов и обновление manifest.

## Оглавление

1. [Владелец и точные источники](#1-владелец-и-точные-источники)
2. [Подтверждённые дефекты](#2-подтверждённые-дефекты)
3. [Решение и совместимость](#3-решение-и-совместимость)
4. [Тестовые корни и эффекты](#4-тестовые-корни-и-эффекты)
5. [Отрицательный контроль](#5-отрицательный-контроль)
6. [Собственное ревью и ограничения](#6-собственное-ревью-и-ограничения)

## 1. Владелец и точные источники

Производственный владелец — существующий Go reader `ReadStateFileBeneathRootNoFollow` и его вариант для резервных копий `ReadClientConfigBackupBeneathRootNoFollow`. Второй сохраняет возможность первоначального чтения без заранее известной SHA-256 и предел **16 MiB (16 × 1 048 576 байт)**. Предел обычного state reader остаётся 1 MiB. Новый Rust API (программный интерфейс) не вводится.

**Таблица 1. Пинованные версии.**

| Назначение | Точный commit |
| --- | --- |
| Целевая производственная база | `75dbc6406123e22468f168b861d5e0622c9d5769` |
| Rust experiment #627 | `6615d239fe066eaa5fa78c22a5272d6602528274` |
| Serena composition #643 | `daaa04c14bc3944babd4efbc3a125eaf495e6534` |
| Предложенная физическая Windows-копия | `858812988833a84368c60fba1540ae601155fa71`, tree `dba685c090952a93a80a1e82403c4646ad8aaed1` |

Три файла `state_read_beneath_root_common.go`, `state_read_beneath_root_windows.go`, `state_read_beneath_root_posix.go` одинаковы в первых трёх версиях таблицы 1. Их точные Git blobs и перечни PR сохранены в [ownership.json](ownership.json). Это дефект уже действующего Go-кода, а не потерянная дельта #652 или #643. Текущий #627 меняет только experiment и его доказательства; текущий #643 — Serena owner composition. Согласован отдельный небольшой Draft PR (черновой запрос на включение изменений) этого Go-дефекта после проверки.

С физическим источником `858…` сравнены 24 непосредственно значимых входа: 23 совпадают с `master`. Единственное отличие в достижимом графе — две диагностические строки strict policy и соответствующие аргументы форматирования в `hub_mcp_state_read_inode_windows.go`. Ветвления, native операции и политика допуска там не меняются. Это отдельный, явно объявленный вход квалификации, а не часть предлагаемой правки: [qualification-source-binding.json](qualification-source-binding.json), [точный diff](qualification-source-diagnostic.patch). Root отдельно привязывает пять входов изоляции API TestMain из #665.

## 2. Подтверждённые дефекты

**Таблица 2. Замечания к `master75`; это выводы по коду, не наблюдения реального отказа операционной системы.**

| Место | Условие | Конкретное последствие |
| --- | --- | --- |
| Windows reader, строки 95–99; POSIX reader, 86–90 | Закрытие прежнего родителя возвращает ошибку | `current` всё ещё содержит уже использованный числовой handle/descriptor. Ветка закрывает `next`, затем `defer` повторно пытается закрыть прежний `current`. |
| Windows reader, 71 и 115; POSIX reader, 66 и 106 | Уже есть ошибка stat/read/cancel/open; последующее закрытие также ошибочно | Условие `closeErr != nil && retErr == nil` отбрасывает ошибку закрытия. При двух ошибках закрытия вторая также теряется. |
| Windows reader, первоначальная проверка root и проверка `next` | Проверка открытого каталога не проходит, закрытие тоже не проходит | Явно игнорируемый результат `CloseHandle` исчезает. |
| `managed_backend_install.go`, 82 и 978 | Reader после исправления возвращает одновременно native missing и close error | Обычный `errors.Is(err, os.ErrNotExist)` на `errors.Join` остаётся истинным. Первый потребитель мог бы создать inverse record; второй заменил бы исходный отказ общей диагностикой pending consumer. |

Первые три строки — текущие дефекты. Последняя — обязательное условие корректной композиции исправления, предотвращающее новый дефект после сохранения двух причин. Гипотеза о фактическом повторном использовании числового handle/descriptor системой не объявляется измеренным событием.

## 3. Решение и совместимость

В Windows и POSIX после успешного открытия `next` сохраняется `previous := current`, затем **`current = next` выполняется до `close(previous)`**. Единственный отложенный финализатор теперь владеет следующим ресурсом. Ошибка закрытия прежнего ресурса не возвращает его числовую идентичность в область владения.

Общий `completeStateReadClose` сохраняет первую `StateFileReadError`, добавляет типизированную ошибку закрытия через `errors.Join`, обнуляет предоставленный буфер и возвращает `nil` вместо байтов при любой ошибке закрытия. На успешном закрытии исходный результат не меняется. Ошибка root/next inspection на Windows получает те же гарантии.

`errors.Is` продолжает находить все исходные причины; `errors.As` продолжает находить первоначальную категорию первой. `errors.Is(joined, os.ErrNotExist)` по-прежнему может быть истинным: это диагностическая принадлежность причины, а не разрешение создавать отсутствующий объект. Два немедленных потребителя используют один private predicate `stateReadBeneathRootAbsent`, принимающий только прямую `StateFileReadError` категории unsafe I/O на операции native open с **непосредственной native missing причиной**. Wrapped, joined, вложенная compound cause и `NotExist`, возникший при close, отвергаются.

В собственном и root review выявлен и исправлен нюанс первоначального helper: вызов `errors.Is` внутри него пропускал бы direct open error с joined `Cause`. Теперь используется существующий strict native predicate. На POSIX он сопоставляет непосредственно `syscall.Errno` с `unix.ENOENT`; вложенные причины не обходятся. Обычные `errors.Is`/`errors.As` не меняются. Небольшой наблюдаемый нюанс: прямой ручной вызов метода `StateFileReadError.Is(os.ErrNotExist)` для POSIX native open-missing теперь возвращает `true`, как на Windows; ранее отсутствие обнаруживалось только общим `errors.Is` через `Unwrap`. В текущем production нет вызывающих прямой метод `Is` мест.

Два native callback (`statFinal`, `close`) передаются на один private вызов; публичные функции всегда подставляют прежние native операции. Создание root, относительные открытия, чтение, ограничения размера и SHA-256 остаются прежними. Два существующих private потребителя получают аргумент `readBackup`; три production call sites передают прежнюю публичную функцию. Это даёт различающий тест всего потребителя без глобального hook и без дополнительных `WithReader`-обёрток.

## 4. Тестовые корни и эффекты

Точные имена, регулярные выражения отбора и ожидаемые события находятся в [qualification-plan.json](qualification-plan.json). Полный предлагаемый diff — [overlays.patch](overlays.patch); точные размеры и SHA-256 — [overlays-manifest.json](overlays-manifest.json).

**Таблица 3. Семь новых корней и один необходимый существующий regression root.**

| Корень | Различающий результат | Эффекты |
| --- | --- | --- |
| `TestReadStateBeneathRootRetainsPrimaryAndCloseFailures` | Final close, parent close, оба close, stat/step/cancel вместе с обоими close: все причины сохраняются, первая категория не подменяется, байты не выдаются | Собственный файл 4097 байт, реальные open/stat/read/close; synthetic failure после успешного stat/close; локальная отмена context |
| `TestReadStateBeneathRootParentCloseConsumedOnce` | Прежний и следующий родители имеют ровно по одной попытке close; оба отказа доступны | Два собственных каталога; конечный файл не открывается |
| `TestStateReadBeneathRootAbsenceRequiresOnlyMissing` | Только исходная native missing разрешает отсутствие; семь вариантов, включая compound `Cause` | Один native missing read собственного root, затем операции над ошибками в памяти |
| `TestReadStateBeneathRootMissingRetainsParentCloseFailure` | Native missing и close cause доступны одновременно, qualified absence запрещена | Свой root и отсутствующий leaf |
| `TestCompleteStateReadCloseZeroesBytes` | Сохраняемая тестом ссылка на backing buffer видит нули после отказа close | Только память |
| `TestPrepareOwnedBackendCompensationRejectsIncompleteAbsence` | Чистое отсутствие создаёт точный inverse record; отсутствие с failed close оставляет root пустым и возвращает обе причины | Собственные temp files; positive и старый control могут вызвать owner-only create только нового fixture-файла |
| `TestAcquireNoManagedBackendConsumersRetainsReadCloseFailure` | Настоящий scan читает capsule и inverse; combined failure возвращается без замены общей pending-диагностикой | Один инертный capsule в собственном root; два missing inode-reader входа; никакого запуска по данным capsule |
| Существующий `TestReadClientConfigBackupBeneathRootNoFollowPolicy` | Сохранены empty digest capture, pinned digest, точные 16 MiB, cap+1, cancel, checksum и nonregular rejection | Только собственные файлы; повтор обоснован изменённым общим reader-finalization path |

В fixture close callback сначала учитывается попытка. Только первая попытка для собственного номера вызывает реальный native close; после успешного закрытия возвращается заданная synthetic error. Повтор учитывается и получает отдельную ошибку **без второго native close**. Поэтому отрицательный контроль не рискует закрыть переиспользованный номер. Реальный native close failure не маскируется: он записывается отдельно и делает fixture проверку неуспешной.

Consumer scan дополнительно проходит через существующий inode reader для missing `managed-entries.json` и journal в том же temp root. Его возможный audit идёт только в изолированный TestMain state root. Это причина обязательных входов #665 и собственного окружения `D:`. Positive compensation создаёт новый owner-only fixture; существующие продуктовые файлы, системные разрешения и политика не меняются. Root подтвердил допустимость этой тестовой операции.

## 5. Отрицательный контроль

[control.patch](control.patch) и [control-manifest.json](control-manifest.json) сохраняют старые ветки close, старый порядок передачи `current`, игнорирование secondary errors и прежние два `errors.Is` consumer guards. Добавлены только те же per-call native/reader seams, общие helpers для компиляции новых тестов и strict POSIX missing predicate. Последний не меняет обычный `errors.Is` старых результатов; nuance прямого метода описан в разделе 3. Контроль не называется побайтно неизменённым `master`.

Минимальный запуск — четыре корня: parent handoff; один subtest stat+оба close; один subtest compensation missing+close; consumer scan. Ожидаются **шесть событий FAIL для тестов (четыре корня и два subtest) и FAIL пакета**. Это предсказание, не результат запуска. Дополнительно проверяется ненулевой код процесса. Положительные тесты отсутствия/лимитов не нужны в контрольном запуске; они входят в candidate.

Candidate использует те же исходники, native toolchain, #665 isolation и тесты, заменяя четыре контрольных production файла на исправленные. Ожидаются 8 корней и 22 subtest, то есть 30 успешных test events и отдельный PASS пакета. Любой отсутствующий тест, unexpected skip, дополнительный FAIL, ошибка fixture setup или незавершённое дерево процессов требует отдельного отчёта; их нельзя засчитать в ожидаемое проявление дефекта.

## 6. Собственное ревью и ограничения

Полный production diff и новые тесты прочитаны. Проверены передача владения до close, один defer на текущий родитель, раздельное владение final, LIFO-порядок final/parent, сохранение первичной категории и всех причин, обнуление возвращаемого буфера, оба caller guards и три production binding. Общая рабочая копия `source` осталась чистой по `git status --porcelain --untracked-files=no`.

Исправление не добавляет новые зависимости, системные операции, опубликованный Rust adapter, процессы или сетевые действия. Обнаруженная root review проблема nested cause исправлена до какого-либо запуска. Независимый агент `/root/pr658_audit` завершил read-only review: обязательных замечаний к `overlays.patch` SHA-256 `32b8a25764d77e630ae2c0aa00b48fde920a50c373f2407dcd9bef00f9fa3ba9` и manifest `7a62a58dcb1e03a82f599e65f10b1a7116477ca45588609d849bb708edf4a959` нет. Он независимо сверил 8 candidate / 4 control записи, 24 source-binding Git blobs, scope candidate-minus-control и ожидаемые количества тестов. Его проверка не запускала Go/Comet и не заменяет runtime. Форматирование и проверка Go пока не выполнены.

Windows execution, если оно пройдёт, подтвердит контракт на реальных собственных файловых ресурсах с внедрёнными stat/close outcome errors. Оно **не подтвердит фактическое получение ошибок native stat/close от операционной системы**, не квалифицирует Rust #627 и не закрывает native Scheduler, installed product, полные Go gates или POSIX runtime. Для POSIX сейчас доступны source review и потенциальная offline cross-compilation; корректной локальной Go toolchain для исполнения не обнаружено. Windows root/next inspection failure + close failure исправлены в коде, но узкий seam не внедряет ошибки этих inspection-операций; это ограничение покрытия сохраняется.
