"""Build local exact inputs for format_stage_remote.py; no remote or Go action."""
from pathlib import Path
import base64
import hashlib
import json
import zlib


ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT.parent / "qualification/fixtures"
GOFMT_SHA256 = "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("ascii")


rows, packed = [], []
for variant, folder, manifest_name in (("candidate", "overlays", "overlays-manifest.json"), ("control", "control", "control-manifest.json")):
    for original in json.loads((ROOT / manifest_name).read_text()):
        raw = (ROOT / folder / original["path"]).read_bytes()
        assert len(raw) == original["bytes"] and sha(raw) == original["sha256"] and git_blob(raw) == original["git_blob"]
        path = variant + "/" + original["path"]
        rows.append({"path": path, "bytes": len(raw), "sha256": sha(raw), "git_blob": git_blob(raw)})
        packed.append({"path": path, "data_base64": base64.b64encode(raw).decode("ascii")})
for name in ("intent_audit_caller_oracle_test.go", "main_helper_dispatch_test.go", "main_helper_dispatch_validation_test.go", "main_test.go", "secrets_test.go"):
    relative = "internal/api/" + name
    raw = (FIXTURES / relative).read_bytes()
    path = "fixtures/" + relative
    rows.append({"path": path, "bytes": len(raw), "sha256": sha(raw), "git_blob": git_blob(raw)})
    packed.append({"path": path, "data_base64": base64.b64encode(raw).decode("ascii")})
rows.sort(key=lambda row: row["path"])
packed.sort(key=lambda row: row["path"])
assert len(rows) == 17 and len({row["path"].casefold() for row in rows}) == 17
content = encoded({"schema": 1, "files": packed})
bundle = base64.b64encode(zlib.compress(content, level=9))
assert zlib.decompress(base64.b64decode(bundle, validate=True)) == content
bundle_path = ROOT / "reader-stage-input.b64"
bundle_path.write_bytes(bundle)
helper = (ROOT / "format_stage_remote.py").read_bytes()
compile(helper, str(ROOT / "format_stage_remote.py"), "exec")
plan = {
    "schema": "reader-format-stage-v1", "root": r"D:\dev\ChatGPT\mcp-next-20261122-e21a1792\reader-stage",
    "helper_sha256": sha(helper),
    "gofmt": {"path": r"C:\msys64\ucrt64\bin\gofmt.exe", "sha256": GOFMT_SHA256},
    "timeouts": {"direct_seconds": 30, "termination_seconds": 10},
    "bundle": {"file": bundle_path.name, "encoding": "base64-zlib-json", "bytes": len(bundle), "sha256": sha(bundle),
               "json_bytes": len(content), "json_sha256": sha(content)},
    "files": rows,
}
manifest = encoded(plan)
manifest_path = ROOT / "reader-stage-input.json"
manifest_path.write_bytes(manifest)
output = {"status": "LOCAL_PREPARED_NOT_RUN", "source_files": len(rows), "source_bytes": sum(row["bytes"] for row in rows),
          "manifest": {"file": manifest_path.name, "bytes": len(manifest), "sha256": sha(manifest)},
          "bundle": {"file": bundle_path.name, "bytes": len(bundle), "sha256": sha(bundle)},
          "helper": {"file": "format_stage_remote.py", "bytes": len(helper), "sha256": sha(helper)},
          "fixture_paths": [row["path"] for row in rows if row["path"].startswith("fixtures/")]}
(ROOT / "format-stage-input-receipt.json").write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps(output))
