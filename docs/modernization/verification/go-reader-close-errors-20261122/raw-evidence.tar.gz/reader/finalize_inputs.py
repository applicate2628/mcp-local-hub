"""Record stable overlay/control inputs and exact proposed roots; no Go execution."""

from pathlib import Path
import difflib
import hashlib
import json


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "source"


def describe(relative, raw):
    return {"path": str(relative), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
            "new": not (SOURCE / relative).exists()}


for variant in ("overlays", "control"):
    chunks, rows = [], []
    for path in sorted((ROOT / variant).rglob("*.go")):
        relative = path.relative_to(ROOT / variant)
        raw = path.read_bytes()
        before = (SOURCE / relative).read_text() if (SOURCE / relative).exists() else ""
        chunks.extend(difflib.unified_diff(before.splitlines(keepends=True), raw.decode().splitlines(keepends=True),
                                         fromfile="a/" + str(relative), tofile="b/" + str(relative)))
        rows.append(describe(relative, raw))
    (ROOT / (variant + ".patch")).write_text("".join(chunks))
    (ROOT / (variant + "-manifest.json")).write_text(json.dumps(rows, indent=2) + "\n")

roots = [
    "TestReadStateBeneathRootRetainsPrimaryAndCloseFailures",
    "TestReadStateBeneathRootParentCloseConsumedOnce",
    "TestStateReadBeneathRootAbsenceRequiresOnlyMissing",
    "TestReadStateBeneathRootMissingRetainsParentCloseFailure",
    "TestCompleteStateReadCloseZeroesBytes",
    "TestPrepareOwnedBackendCompensationRejectsIncompleteAbsence",
    "TestAcquireNoManagedBackendConsumersRetainsReadCloseFailure",
]
control_roots = [roots[0], roots[1], roots[5], roots[6]]
control_children = ["stat-and-both-closes", "missing-and-close-failure-preserves-empty-root"]
regression_root = "TestReadClientConfigBackupBeneathRootNoFollowPolicy"
expected_control_failures = [
    roots[0] + "/stat-and-both-closes", roots[0], roots[1],
    roots[5] + "/missing-and-close-failure-preserves-empty-root", roots[5], roots[6],
]
plan = {
    "status": "PREPARED_NOT_RUN",
    "target_master": "75dbc6406123e22468f168b861d5e0622c9d5769",
    "physical_source": "858812988833a84368c60fba1540ae601155fa71",
    "package": "./internal/api",
    "new_roots": roots,
    "existing_affected_regression_root": regression_root,
    "candidate_selector": "^(" + "|".join(roots + [regression_root]) + ")$",
    "candidate_expected_test_events": 30,
    "candidate_expected_root_events": 8,
    "candidate_expected_subtest_events": 22,
    "control_selector": "^(" + "|".join(control_roots) + ")$/^(" + "|".join(control_children) + ")$",
    "control_expected_failures": expected_control_failures,
    "control_expected_package_outcome": "FAIL",
    "control_expected_process_outcome": "nonzero",
    "control_composition": [
        "physical source 858 with explicitly bound #665 API TestMain isolation inputs",
        "4 files under control: original reader close/error/consumer absence branches plus private native/reader seams",
        "same new 4 test files as candidate overlays",
        "same new common helpers and strict POSIX native-missing classifier as candidate; public errors.Is/As unchanged",
    ],
    "candidate_composition": [
        "same physical source and #665 API TestMain inputs as control",
        "all 8 Go files under overlays",
    ],
    "allowed_runtime_effects": [
        "reader opens/stats/reads/closes its own t.TempDir files and directories",
        "stat and close failure outcomes are injected after successful native operation on owned resource",
        "repeat close attempt is recorded and refused by test callback before native close",
        "prepare compensation positive/control branch may create owner-only inverse JSON in its own t.TempDir",
        "consumer scan reads two missing inode-anchored fixture entries; any policy fallback audit stays inside fenced API TestMain state root",
    ],
    "excluded_runtime_effects": [
        "Scheduler, backend launch, child helper process, installed Hub/Product/Serena",
        "external network, downloads, dependency installation, system ACL/policy/credential changes",
        "real OS stat/close failure qualification or unchanged Rust/R24/R25 test replay",
    ],
    "before_execution": [
        "parent reviews complete diff and applies only declared #665 isolation inputs",
        "parent runs installed gofmt on exact overlays/control and returns any changed bytes before manifest finalization",
        "offline environment: GOTOOLCHAIN=local, GOPROXY=off, GOSUMDB=off; own D: profiles/TMP/build cache",
        "parent binds exact Go tool hashes, complete native process receipt and source inventory",
    ],
    "platform_limits": {
        "windows": "proposed native execution on own file fixtures; not yet executed",
        "posix": "source review and possible offline cross-compilation; runtime unavailable in current local environment",
        "format": "local gofmt absent; formatting pending parent installed Go toolchain",
    },
}
(ROOT / "qualification-plan.json").write_text(json.dumps(plan, indent=2) + "\n")

master_rows = {row["path"]: row for row in json.loads((ROOT / "source-manifest.json").read_text())["sources"]}
ownership = json.loads((ROOT / "ownership.json").read_text())
for row in ownership["reader_blobs"]:
    assert row["master_blob"] == master_rows[row["path"]]["git_blob"]
    assert row["master_blob"] == row["pr643_blob"] == row["pr627_blob"]
print(json.dumps({"candidate_roots": len(roots) + 1, "control_roots": len(control_roots),
                  "control_expected_failed_test_events": len(expected_control_failures),
                  "status": plan["status"]}))
