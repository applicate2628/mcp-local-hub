"""Prepare reader overlays from the immutable master75 source; does not execute Go."""

from pathlib import Path
import hashlib
import json
import subprocess


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "source"
MASTER = "75dbc6406123e22468f168b861d5e0622c9d5769"


def replace_once(text, before, after):
    assert text.count(before) == 1, (before, text.count(before))
    return text.replace(before, after, 1)


def write(folder, relative, content):
    path = ROOT / folder / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content.encode())


def blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


assert subprocess.check_output(
    ["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True
).strip() == MASTER

paths = [
    "internal/api/state_read_beneath_root_common.go",
    "internal/api/state_read_beneath_root_windows.go",
    "internal/api/state_read_beneath_root_posix.go",
    "internal/api/managed_backend_install.go",
]
sources = {path: (SOURCE / path).read_text() for path in paths}
rows = []
for path in paths:
    raw = (SOURCE / path).read_bytes()
    write("sources/master", path, sources[path])
    assert (ROOT / "sources/master" / path).read_bytes() == raw
    rows.append({"path": path, "commit": MASTER, "bytes": len(raw),
                 "git_blob": blob_sha(raw), "sha256": hashlib.sha256(raw).hexdigest()})

common_path = paths[0]
common = replace_once(sources[common_path], '\t"encoding/hex"\n', '\t"encoding/hex"\n\t"errors"\n')
common = replace_once(common, "type stateReadBeneathRootPolicy struct {", """// stateReadBeneathRootAbsent accepts only the original, lone open-missing
// outcome returned directly by this reader. errors.Is remains useful for
// diagnostics across joined causes; it cannot qualify absence after a failed
// close. Call this before any caller wrapping, without traversing error graphs.
func stateReadBeneathRootAbsent(err error) bool {
	readErr, direct := err.(*StateFileReadError)
	if !direct || readErr == nil || readErr.Category != StateFileReadErrorUnsafeObjectOrIO {
		return false
	}
	switch readErr.Operation {
	case "open-root", "open-component", "open-final":
		return stateReadOpenCauseIsNotExist(readErr.Cause)
	default:
		return false
	}
}

// completeStateReadClose retains the primary category and all native causes,
// but never releases bytes when an owned close is unconfirmed.
func completeStateReadClose(result []byte, primary error, operation, component string, closeErr error) ([]byte, error) {
	if closeErr == nil {
		return result, primary
	}
	zeroStateSecretBytes(result)
	failure := newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, operation, component, closeErr)
	if primary == nil {
		return nil, failure
	}
	return nil, errors.Join(primary, failure)
}

type stateReadBeneathRootPolicy struct {""")

# The control adds the same private seams and common helpers, while retaining
# every original reader close/error branch and both original absence guards.
for platform in ("windows", "posix"):
    path = f"internal/api/state_read_beneath_root_{platform}.go"
    native_type = "windows.Handle" if platform == "windows" else "int"
    stat_type = "windows.ByHandleFileInformation" if platform == "windows" else "unix.Stat_t"
    native_close = "windows.CloseHandle" if platform == "windows" else "unix.Close"
    native_stat = "windows.GetFileInformationByHandle" if platform == "windows" else "unix.Fstat"
    text = sources[path]
    if platform == "posix":
        text = replace_once(text, '\t"context"\n', '\t"context"\n\t"syscall"\n')
        text = replace_once(text, "func stateReadOpenCauseIsNotExist(error) bool {\n\treturn false\n}",
            "func stateReadOpenCauseIsNotExist(cause error) bool {\n\terrno, direct := cause.(syscall.Errno)\n\treturn direct && errno == unix.ENOENT\n}")
    signature = """func readStateFileBeneathRootNoFollowWithPolicy(
	ctx context.Context,
	root string,
	relativeComponents []string,
	policy stateReadBeneathRootPolicy,
	step stateReadBeneathRootStepFunc,
) (result []byte, retErr error) {"""
    seam = f"""// Only final stat and close are injected per invocation. The public readers
// always supply the native operations; no process-global hook is retained.
type stateReadBeneathRootNative struct {{
	statFinal func({native_type}, *{stat_type}) error
	close     func({native_type}) error
}}

{signature}
	return readStateFileBeneathRootNoFollowWithNative(ctx, root, relativeComponents, policy, step, stateReadBeneathRootNative{{
		statFinal: {native_stat}, close: {native_close},
	}})
}}

func readStateFileBeneathRootNoFollowWithNative(
	ctx context.Context,
	root string,
	relativeComponents []string,
	policy stateReadBeneathRootPolicy,
	step stateReadBeneathRootStepFunc,
	native stateReadBeneathRootNative,
) (result []byte, retErr error) {{"""
    text = replace_once(text, signature, seam)
    # Change only call sites, not the direct native function values above.
    text = text.replace(native_close + "(", "native.close(")
    text = replace_once(text, native_stat + "(final", "native.statFinal(final")
    write("control", path, text)

    suffix = "Handle" if platform == "windows" else "FD"
    # Consume the previous parent before its one close attempt. On failure,
    # the existing defer owns next, never the already consumed previous value.
    transfer_before = f"""		if closeErr := native.close(current{suffix}); closeErr != nil {{
			_ = native.close(next{suffix})
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "close-parent", component, closeErr)
		}}
		current{suffix} = next{suffix}"""
    transfer_after = f"""		previous{suffix} := current{suffix}
		current{suffix} = next{suffix}
		if closeErr := native.close(previous{suffix}); closeErr != nil {{
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "close-parent", component, closeErr)
		}}"""
    text = replace_once(text, transfer_before, transfer_after)
    for resource, operation, component in ((f"current{suffix}", "close-parent", '""'),
                                            (f"final{suffix}", "close-final", "finalComponent")):
        before = f"""	defer func() {{
		if closeErr := native.close({resource}); closeErr != nil && retErr == nil {{
			zeroStateSecretBytes(result)
			result = nil
			retErr = newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "{operation}", {component}, closeErr)
		}}
	}}()"""
        after = f"""	defer func() {{
		result, retErr = completeStateReadClose(result, retErr, "{operation}", {component}, native.close({resource}))
	}}()"""
        text = replace_once(text, before, after)
    if platform == "windows":
        before = """	if err := refuseReparsePointHandle(rootHandle); err != nil {
		_ = native.close(rootHandle)
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-root", "", err)
	}
"""
        text = replace_once(text, before, "")
        after_defer = """		result, retErr = completeStateReadClose(result, retErr, "close-parent", "", native.close(currentHandle))
	}()
"""
        text = replace_once(text, after_defer, after_defer + """	if err := refuseReparsePointHandle(rootHandle); err != nil {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-root", "", err)
	}
""")
        text = replace_once(text, """		if infoErr := refuseReparsePointHandle(nextHandle); infoErr != nil {
			_ = native.close(nextHandle)
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-component", component, infoErr)
		}""", """		if infoErr := refuseReparsePointHandle(nextHandle); infoErr != nil {
			primary := newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-component", component, infoErr)
			return completeStateReadClose(nil, primary, "close-parent", component, native.close(nextHandle))
		}""")
    write("overlays", path, text)

consumer_path = paths[3]
consumers = sources[consumer_path]
reader_parameter = "readBackup func(context.Context, string, []string, string) ([]byte, error)"
consumers = replace_once(consumers,
    "func prepareOwnedBackendCompensation(ctx context.Context, root string, ref *ManagedBackendInstallReceiptV1, target string)",
    f"func prepareOwnedBackendCompensation(ctx context.Context, root string, ref *ManagedBackendInstallReceiptV1, target string, {reader_parameter})")
consumers = replace_once(consumers,
    "func acquireNoManagedBackendConsumers(ctx context.Context, root, server, targetGroup, ownOperation string)",
    f"func acquireNoManagedBackendConsumers(ctx context.Context, root, server, targetGroup, ownOperation string, {reader_parameter})")
consumers = replace_once(consumers,
    'b, err := ReadClientConfigBackupBeneathRootNoFollow(ctx, root, []string{leaf}, "")',
    'b, err := readBackup(ctx, root, []string{leaf}, "")')
consumers = replace_once(consumers,
    'b, err := ReadClientConfigBackupBeneathRootNoFollow(ctx, root, []string{entry.Name()}, "")',
    'b, err := readBackup(ctx, root, []string{entry.Name()}, "")')
consumers = replace_once(consumers,
    'inverseBytes, inverseErr := ReadClientConfigBackupBeneathRootNoFollow(ctx, root, []string{entry.Name() + ".inverse.json"}, "")',
    'inverseBytes, inverseErr := readBackup(ctx, root, []string{entry.Name() + ".inverse.json"}, "")')
assert consumers.count("prepareOwnedBackendCompensation(ctx, root, receipt, c.TargetGroupSHA256)") == 2
consumers = consumers.replace("prepareOwnedBackendCompensation(ctx, root, receipt, c.TargetGroupSHA256)",
    "prepareOwnedBackendCompensation(ctx, root, receipt, c.TargetGroupSHA256, ReadClientConfigBackupBeneathRootNoFollow)")
consumers = replace_once(consumers,
    "acquireNoManagedBackendConsumers(ctx, root, backup.Server, c.TargetGroupSHA256, c.OperationID)",
    "acquireNoManagedBackendConsumers(ctx, root, backup.Server, c.TargetGroupSHA256, c.OperationID, ReadClientConfigBackupBeneathRootNoFollow)")
write("control", consumer_path, consumers)
consumers = replace_once(consumers, "\tif !errors.Is(err, os.ErrNotExist) {\n\t\treturn record, false, err\n\t}",
    "\tif !stateReadBeneathRootAbsent(err) {\n\t\treturn record, false, err\n\t}")
consumers = replace_once(consumers, "} else if !errors.Is(inverseErr, os.ErrNotExist) {", "} else if !stateReadBeneathRootAbsent(inverseErr) {")
write("overlays", consumer_path, consumers)
for folder in ("control", "overlays"):
    write(folder, common_path, common)

(ROOT / "source-manifest.json").write_text(json.dumps({
    "master": MASTER,
    "reader_pr627": "6615d239fe066eaa5fa78c22a5272d6602528274",
    "serena_pr643": "daaa04c14bc3944babd4efbc3a125eaf495e6534",
    "sources": rows,
    "status": "PREPARED_NOT_RUN",
}, indent=2) + "\n")
print(json.dumps({"source_files": len(rows), "production_overlays": len(paths),
                  "control": "master behavior with private native/reader call seams and unused new helpers"}))
