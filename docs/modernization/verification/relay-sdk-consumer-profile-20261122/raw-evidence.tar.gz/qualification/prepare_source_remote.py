"""Copy the previously qualified Git input into this increment's own D root.

This helper only inspects and copies files. It does not invoke Git, Go, a
product, a package manager, or a scheduler. The later qualification runner
independently checks the copied Git commit, tree, tracked source and overlays.
"""
import sys
sys.dont_write_bytecode = True

import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

ROOT = Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
SOURCE = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")
DESTINATION = ROOT / "source"


def checked(path):
    info = path.lstat()
    if path.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("Reparse path is not an admitted copy input: " + str(path))
    return info


def checked_directory_chain(path):
    allowed = Path(r"D:\dev\ChatGPT")
    relative = path.relative_to(allowed)
    current = allowed.parent
    for part in (None, allowed.name, *relative.parts):
        if part is not None:
            current = current / part
        if not stat.S_ISDIR(checked(current).st_mode):
            raise RuntimeError("Expected a directory in the approved path: " + str(current))


def inventory(root):
    checked_directory_chain(root)
    files = []
    directories = []

    def walk_error(error):
        raise error

    for directory, children, names in os.walk(root, topdown=True, onerror=walk_error, followlinks=False):
        current = Path(directory)
        if not stat.S_ISDIR(checked(current).st_mode):
            raise RuntimeError("Expected an inventory directory")
        directories.append(current.relative_to(root).as_posix())
        children.sort()
        for name in children:
            if not stat.S_ISDIR(checked(current / name).st_mode):
                raise RuntimeError("Non-directory in the directory inventory")
        for name in sorted(names):
            path = current / name
            info = checked(path)
            if not stat.S_ISREG(info.st_mode):
                raise RuntimeError("Non-regular copy input: " + str(path))
            digest = hashlib.sha256()
            count = 0
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
                    count += len(block)
            if count != info.st_size:
                raise RuntimeError("Copy input changed during its read: " + str(path))
            files.append({"path": path.relative_to(root).as_posix(), "bytes": count, "sha256": digest.hexdigest()})
    files.sort(key=lambda row: row["path"])
    rows = {"directories": sorted(directories), "files": files}
    raw = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {"files": len(files), "directories_including_root": len(directories),
            "bytes": sum(row["bytes"] for row in files), "inventory_sha256": hashlib.sha256(raw).hexdigest()}, rows


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or sys.flags.optimize:
        raise RuntimeError("Use this helper only from the increment's owned Windows root")
    for path in (ROOT, SOURCE):
        checked_directory_chain(path)
    if DESTINATION.exists() or DESTINATION.is_symlink():
        raise RuntimeError("The destination must be new; an uncertain attempt must be inspected")
    receipt = {"schema": 1, "source": str(SOURCE), "destination": str(DESTINATION),
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "state": "preflight", "programs_executed": False}
    write_new(ROOT / "source-copy-started.json", receipt)
    try:
        before, rows = inventory(SOURCE)
        write_new(ROOT / "source-copy-inventory.json", rows)
        receipt["before"] = before
        shutil.copytree(SOURCE, DESTINATION, copy_function=shutil.copy2, symlinks=True)
        after, copied = inventory(DESTINATION)
        original_after, original_rows = inventory(SOURCE)
        if rows != copied or rows != original_rows or before != after or before != original_after:
            raise RuntimeError("Source or destination changed during the copy")
        receipt.update(state="complete", copied=after, original_after=original_after,
                       source_unchanged=True, exact_bytes_copied=True)
    except BaseException as error:
        receipt.update(state="failed", error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_new(ROOT / "source-copy-receipt.json", receipt)
        print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()

