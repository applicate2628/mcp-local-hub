"""Freeze scoped candidate/control commands on the preserved 858 input."""
from pathlib import Path, PureWindowsPath
import base64
import hashlib
import json
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1]
Q=ROOT/"qualification"
D=PureWindowsPath(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
SOURCE="858812988833a84368c60fba1540ae601155fa71"
TREE="dba685c090952a93a80a1e82403c4646ad8aaed1"
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(o):return (json.dumps(o,indent=2)+"\n").encode()
def row(path,b):return {"path":path,"bytes":len(b),"sha256":sha(b)}
def put(path,b):
    p=Q/"inputs"/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def command(label,args,code=0,**extra):return {"label":label,"tool":"go","args":args,"timeout_seconds":300,"expected_exit_code":code,**extra}
def tests(label,overlay,roots,packages,code=0,race=True):
    args=["test","-buildvcs=false","-overlay",str(D/"inputs"/overlay),"-p=2","-count=1","-timeout=180s","-json"]
    if race:args.append("-race")
    args += ["-run","^("+"|".join(roots)+")$",*packages]
    return command(label,args,code,required_tests={"pass" if code==0 else "fail":roots})

source=json.loads((Q/"reference/qualification/preparation/source-copy-inventory.json").read_text())
source=[r for r in source["files"] if not r["path"].startswith(".git/")]
assert len(source)==3281
plans=[];new_files={}
def add_plan(name,scope,commands,env=None,extra_files=None):
    paths=[p for p in sorted((Q/"inputs"/scope).rglob('*')) if p.is_file()]
    paths += extra_files or []
    input_rows=[row(p.relative_to(Q/"inputs").as_posix(),p.read_bytes()) for p in paths]
    plan={"schema":1,"phase":name,"runner_sha256":sha((Q/"qualify_go.py").read_bytes()),"native_scheduler_operations":False,
          "source_directory":"source","source_head":SOURCE,"source_tree":TREE,"source_files":source,
          "inputs_directory":"inputs","input_files":input_rows,"commands":commands,"environment":env or {}}
    b=dump(plan);(Q/"plans"/(name+".json")).write_bytes(b);new_files["inputs/plans/"+name+".json"]=b
    plans.append({"phase":name,"manifest_sha256":sha(b)})

for scope in ("scheduler","relay"):
    mapping={str(D/"source"/p.relative_to(Q/"inputs"/scope).as_posix()):str(D/"inputs"/scope/p.relative_to(Q/"inputs"/scope).as_posix())
             for p in sorted((Q/"inputs"/scope).rglob('*.go'))}
    p=scope+"/overlay.json";b=dump({"Replace":mapping});put(p,b);new_files["inputs/"+p]=b

# The control preserves all prior compatible overlays and the new tests, but
# restores only the four changed production files to their pre-SID behavior.
old={}
with zipfile.ZipFile(ROOT/"scheduler/docs/modernization/verification/scheduler-hold-composition-20261122/qualification-evidence.zip") as z:
    for p in ("internal/api/install.go","internal/scheduler/scheduler_com_windows.go","internal/scheduler/scheduler_windows.go"):
        old[p]=z.read("overlays/"+p)
p="internal/scheduler/entrypoint_migration_windows.go"
old[p]=subprocess.check_output(["git","-C",str(ROOT/"repo"),"show","75dbc6406123e22468f168b861d5e0622c9d5769:"+p])
control_map=json.loads((Q/"inputs/scheduler/overlay.json").read_text())["Replace"]
control_files=[]
for p,b in old.items():
    rel="scheduler-control/"+p;put(rel,b);new_files["inputs/"+rel]=b
    control_map[str(D/"source"/p)]=str(D/"inputs"/rel);control_files.append(Q/"inputs"/rel)
rel="scheduler-control/overlay.json";b=dump({"Replace":control_map});put(rel,b);new_files["inputs/"+rel]=b;control_files.append(Q/"inputs"/rel)
roots=["TestWindowsSchedulerCurrentOwnerUsesSID","TestSchedulerCOMOwnerSIDProjection"]
c=tests("owner-control","scheduler-control/overlay.json",roots,["./internal/scheduler"],1)
c["required_output"]=["migration owner must retain the current SID","owner row 0 was not resolved"]
add_plan("scheduler-sid-control","scheduler",[c],extra_files=control_files)

roots=["TestWindowsSchedulerCurrentOwnerUsesSID","TestSchedulerCOMOwnerSIDProjection","TestSchedulerCOMOwnedRunUsesSameSIDResolver",
       "TestSameWindowsUser","TestEntrypointTaskTxnRejectsForeignOrAmbiguousTaskBeforeMutation","TestSchedulerCOMLastResultPublicQueries","TestSchedulerCOMLastResultScript"]
api=["TestSchedulerPortOwnerRequiresCurrentSID","TestPortHeldByOurDaemon","TestInstallMergePreservesBackendRunHold","TestInstallPreflightPreservesBackendRunHold"]
add_plan("scheduler-sid-candidate","scheduler",[
    tests("scheduler-owners","scheduler/overlay.json",roots,["./internal/scheduler"]),
    tests("api-owners-hold","scheduler/overlay.json",api,["./internal/api"]),
    command("build",["build","-buildvcs=false","-overlay",str(D/"inputs/scheduler/overlay.json"),"-p=2","./..."]),
    command("vet",["vet","-buildvcs=false","-overlay",str(D/"inputs/scheduler/overlay.json"),"-p=2","./..."])])

load=["TestRelayLoadContract","TestRelayLoadHTTPErrorPreservesID","TestRelayLoadOracleRejectsCorruption","TestRelayLoadEOFDrainsFinalResponse"]
add_plan("relay-load-compatibility","relay",[tests("load-oracles","relay/overlay.json",load,["./internal/daemon"])])
add_plan("relay-sdk-race","relay",[tests("sdk-race","relay/overlay.json",["TestRelaySDKConsumerProfile"],["./internal/daemon"])],env={"MCPHUB_RELAY_SDK_PROFILE":"1"})
for i,case in enumerate(["clients_1/workers_1/bytes_1024","clients_8/workers_1/bytes_1024","clients_4/workers_4/bytes_65536"]):
    c=tests("sdk-profile","relay/overlay.json",["TestRelaySDKConsumerProfile"],["./internal/daemon"],race=False)
    c["args"][c["args"].index("-run")+1]="^TestRelaySDKConsumerProfile$/^"+case.replace("/","$/^")+"$"
    c["required_output"]=["RELAY_SDK_PROFILE"]
    add_plan("relay-sdk-profile-"+str(i+1),"relay",[c],env={"MCPHUB_RELAY_SDK_PROFILE":"1"})
add_plan("relay-sdk-build-vet","relay",[
    command("build",["build","-buildvcs=false","-overlay",str(D/"inputs/relay/overlay.json"),"-p=2","./..."]),
    command("vet",["vet","-buildvcs=false","-overlay",str(D/"inputs/relay/overlay.json"),"-p=2","./..."])])
archive=Q/"scoped-go-plans.zip"
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,b in new_files.items():z.writestr(path,b)
b=archive.read_bytes();(Q/"scoped-go-plans.b64").write_bytes(base64.b64encode(b))
(Q/"scoped-go-plan-index.json").write_bytes(dump({"plans":plans,"bundle_bytes":len(b),"bundle_sha256":sha(b),"base64_bytes":len(base64.b64encode(b))}))
print((Q/"scoped-go-plan-index.json").read_text())
