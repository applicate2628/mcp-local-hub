"""Stage one hash-pinned, source-only input archive and format owned Go copies.

The original archive is retained. Destinations must be absent; no repository,
installed state, system policy, native task or dependency is modified here.
"""
import sys
sys.dont_write_bytecode=True
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
RUNNER_SHA256="893c3281026e988c200f61fb2b4459b3385d427b7b39e0eec38d27b9c03949e5"

def main():
    if os.name!="nt" or sys.flags.optimize or Path(__file__).resolve().parent!=ROOT or len(sys.argv)!=3:
        raise RuntimeError("Exact owned bundle path and SHA256 required")
    if hashlib.sha256((ROOT/"qualify_go.py").read_bytes()).hexdigest()!=RUNNER_SHA256:
        raise RuntimeError("Qualification helper differs before import")
    spec=importlib.util.spec_from_file_location("owned_qualification",ROOT/"qualify_go.py")
    q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    archive=q.own(sys.argv[1]);raw=base64.b64decode(archive.read_bytes(),validate=True)
    if q.sha(raw)!=sys.argv[2]:raise RuntimeError("Bundle differs from the reviewed caller pin")
    out=q.own("staging/"+archive.stem);out.mkdir(parents=True,exist_ok=False)
    receipt={"schema":1,"started_utc":q.now(),"script_sha256":q.sha(Path(__file__).read_bytes()),
             "runner_sha256":q.sha((ROOT/"qualify_go.py").read_bytes()),"archive_sha256":q.sha(raw),
             "before":[],"after":[],"completed":False}
    q.save(out/"started.json",receipt)
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names=z.namelist()
            if len(names)!=len(set(n.casefold() for n in names)):raise RuntimeError("Aliased bundle paths")
            for name in names:
                if not name.startswith("inputs/") or name.endswith("/"):raise RuntimeError("Bundle is not source input only")
                p=q.own(name)
                if p.exists():raise RuntimeError("Input destination exists: "+name)
            for name in names:
                b=z.read(name);p=q.own(name);p.parent.mkdir(parents=True,exist_ok=True)
                with p.open("xb") as f:f.write(b)
                receipt["before"].append({"path":name,"bytes":len(b),"sha256":q.sha(b)})
        q.save(out/"staged.json",receipt)
        gofiles=[str(q.own(r["path"])) for r in receipt["before"] if r["path"].endswith(".go")]
        if gofiles:
            if q.sha(q.GOFMT.read_bytes())!=q.PINS[str(q.GOFMT)]:raise RuntimeError("Installed formatter changed")
            runtime=out/"runtime";runtime.mkdir()
            env=q.environment(runtime,{})
            row={"argv":[str(q.GOFMT),"-w",*gofiles],"cwd":str(ROOT),"started_utc":q.now(),"settled":False,"timed_out":False}
            q.save(out/"gofmt.started.json",row);child=None
            try:
                with (out/"gofmt.stdout.log").open("xb") as stdout,(out/"gofmt.stderr.log").open("xb") as stderr:
                    child=subprocess.Popen(row["argv"],cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
                    row["pid"]=child.pid;q.save(out/"gofmt.launched.json",row)
                    try:
                        row["exit_code"]=child.wait(timeout=30);row["settled"]=True
                    except subprocess.TimeoutExpired:row["timed_out"]=True
            finally:
                if child is not None and not row["settled"]:
                    row["process_tree_unresolved"]=True
                    try:
                        child.terminate();row["exit_code"]=child.wait(timeout=10);row["settled"]=True
                    except BaseException as error:row["termination_error"]=str(error)
                row["finished_utc"]=q.now();q.save(out/"gofmt.receipt.json",row);receipt["format"]=row
            if not row["settled"] or row["timed_out"] or row.get("exit_code")!=0:
                raise RuntimeError("Owned input formatting failed")
        for row in receipt["before"]:
            b=q.own(row["path"]).read_bytes()
            receipt["after"].append({"path":row["path"],"bytes":len(b),"sha256":q.sha(b)})
        receipt["completed"]=True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__,error=str(error));raise
    finally:
        receipt["finished_utc"]=q.now();q.save(out/"receipt.json",receipt)
        print(json.dumps({"completed":receipt["completed"],"files":len(receipt["after"]),"error":receipt.get("error"),
                          "changed":[a["path"] for a,b in zip(receipt["after"],receipt["before"]) if a!=b]}),flush=True)

if __name__=="__main__":main()
