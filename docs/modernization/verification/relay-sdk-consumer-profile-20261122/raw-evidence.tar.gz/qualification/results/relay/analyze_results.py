"""Verify imported Relay evidence locally; no Go, remote or source mutations."""
from collections import Counter, defaultdict
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
RESULTS = ROOT / "qualification/results/relay"
PHASES = ("relay-load-compatibility", "relay-sdk-race", "relay-sdk-profile-1",
          "relay-sdk-profile-2", "relay-sdk-profile-3", "relay-sdk-build-vet")
RUNNER_SHA = "893c3281026e988c200f61fb2b4459b3385d427b7b39e0eec38d27b9c03949e5"
NATIVE = r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792"
GO = r"C:\msys64\ucrt64\bin\go.exe"
SOURCE = "858812988833a84368c60fba1540ae601155fa71"
TREE = "dba685c090952a93a80a1e82403c4646ad8aaed1"
RELAY = "4b6ec39930cb5a0498dba068b99dbf29ba7129b7"
CANON = "58670482426cd60aee35bf09b8d945a9809eb854"
FIELDS = ("baseline_after_gc", "held_after_gc", "before_calls_after_gc",
          "after_calls", "retained_open_after_gc", "retained_closed_after_gc")
MEMORY_KEYS = {"HeapAlloc", "HeapInuse", "HeapObjects", "TotalAlloc", "Mallocs",
               "WorkingSet", "PrivateWorkingSet", "PrivateCommit"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": sha(data)}


def inventory(rows):
    content = [[r["path"], r["bytes"], r["sha256"]] for r in rows]
    return {"files": len(rows), "bytes": sum(r["bytes"] for r in rows),
            "inventory_sha256": sha(json.dumps(content, separators=(",", ":"), ensure_ascii=True).encode())}


def git_bytes(commit, path):
    run = subprocess.run(["git", "-C", str(ROOT / "repo"), "show", commit + ":" + path],
                         check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return run.stdout


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


assert sha((ROOT / "qualification/qualify_go.py").read_bytes()) == RUNNER_SHA
readback = json.loads((RESULTS / "readback-manifest.json").read_bytes())
for row in readback["files"]:
    content = (RESULTS / row["path"]).read_bytes()
    assert len(content) == row["bytes"] and sha(content) == row["sha256"]

plans, receipts, qualifications, profiles = {}, {}, [], []
terminal_totals = Counter()
for phase in PHASES:
    plan_path = ROOT / "qualification/plans" / (phase + ".json")
    plan = json.loads(plan_path.read_bytes())
    receipt_path = RESULTS / phase / "receipt.json"
    receipt = json.loads(receipt_path.read_bytes())
    plans[phase], receipts[phase] = plan, receipt
    assert receipt["phase"] == plan["phase"] == phase
    assert receipt["completed"] is True
    assert receipt["manifest_sha256"] == sha(plan_path.read_bytes())
    assert receipt["runner_sha256"] == plan["runner_sha256"] == RUNNER_SHA
    assert receipt["source_head"] == plan["source_head"] == SOURCE
    assert receipt["source_tree"] == plan["source_tree"] == TREE
    assert receipt["native_scheduler_operations"] is False
    for stem, rows in (("source", plan["source_files"]), ("inputs", plan["input_files"])):
        assert receipt[stem + "_before"] == receipt[stem + "_after"] == inventory(rows)
    for row in plan["input_files"]:
        raw = (ROOT / "qualification/inputs" / row["path"]).read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    for key, value in plan["environment"].items():
        assert receipt["environment"][key] == value
    assert receipt["environment"]["GOPROXY"] == "off"
    assert receipt["environment"]["GOTOOLCHAIN"] == "local"
    assert receipt["environment"]["GOMAXPROCS"] == "4"
    assert receipt["environment"]["GOGC"] == "100"
    assert len(plan["commands"]) == len(receipt["commands"])
    commands = []
    for expected, command in zip(plan["commands"], receipt["commands"]):
        assert command["label"] == expected["label"]
        assert command["argv"] == [GO, *expected["args"]]
        assert command["cwd"] == NATIVE + "\\source"
        assert command["direct_timeout_seconds"] == expected["timeout_seconds"]
        assert command["exit_code"] == expected["expected_exit_code"] == 0
        assert command["settled"] is True and command["timed_out"] is False
        assert command["oracle_pass"] is True
        assert not any(command.get(k) for k in ("error", "error_type", "process_tree_unresolved", "termination_error"))
        assert 0 <= command["seconds"] < command["direct_timeout_seconds"]
        streams = {}
        for channel in ("stdout", "stderr"):
            path = RESULTS / phase / (command["label"] + "." + channel + ".log")
            raw = path.read_bytes()
            assert len(raw) == command[channel]["bytes"] and sha(raw) == command[channel]["sha256"]
            streams[channel] = raw
        assert streams["stderr"] == b""
        row = {key: command[key] for key in ("label", "argv", "pid", "started_utc", "finished_utc",
                                             "seconds", "direct_timeout_seconds", "exit_code", "settled",
                                             "timed_out", "whole_process_tree_deadline_enforced", "stdout", "stderr")}
        if expected["args"][0] == "test":
            events = [json.loads(line) for line in streams["stdout"].splitlines()]
            terminal = {action: [] for action in ("pass", "fail", "skip")}
            outputs = defaultdict(list)
            for event in events:
                action = event["Action"]
                if action in terminal:
                    terminal[action].append(event.get("Test", "PACKAGE:" + event.get("Package", "")))
                if action == "output":
                    outputs[(event.get("Package", ""), event.get("Test", ""))].append(event["Output"])
            assert terminal == command["tests"] and not terminal["fail"] and not terminal["skip"]
            assert len(terminal["pass"]) == len(set(terminal["pass"]))
            row["terminal"] = terminal
            row["test_pass"] = sum(not n.startswith("PACKAGE:") for n in terminal["pass"])
            row["package_pass"] = sum(n.startswith("PACKAGE:") for n in terminal["pass"])
            terminal_totals.update(test_pass=row["test_pass"], package_pass=row["package_pass"])
            for (package, test), pieces in outputs.items():
                joined = "".join(pieces)
                marker = "RELAY_SDK_PROFILE "
                if marker not in joined:
                    continue
                assert joined.count(marker) == 1 and test in terminal["pass"]
                suffix = joined.split(marker, 1)[1]
                profile, end = json.JSONDecoder().raw_decode(suffix)
                raw_profile = suffix[:end].encode("utf-8")
                parsed_name = re.fullmatch(r"TestRelaySDKConsumerProfile/clients_(\d+)/workers_(\d+)/bytes_(\d+)", test)
                assert parsed_name
                clients, workers_per_client, payload_bytes = map(int, parsed_name.groups())
                assert [profile["clients"], profile["workers_per_client"], profile["payload_bytes"]] == [clients, workers_per_client, payload_bytes]
                workers = clients * workers_per_client
                n = profile["measured_calls"]
                assert profile["completed_calls"] == n > 0
                assert profile["warmup_calls"] == profile["cancelled_calls"] == profile["cancelled_handler_cleanups_observed"] == clients
                assert profile["held_calls"] == profile["max_active_tools"] == workers
                assert profile["server_calls"] == n + profile["warmup_calls"] + profile["held_calls"] + profile["cancelled_calls"]
                assert profile["deleted_sessions"] == clients
                assert profile["lost_or_corrupted"] == profile["http_active_after_close"] == profile["tool_active_after_close"] == profile["server_sessions_after_close"] == 0
                assert isinstance(profile["get_requests"], int) and profile["get_requests"] >= 0
                assert 0 <= profile["latency_ns"]["p50"] <= profile["latency_ns"]["p95"] <= profile["latency_ns"]["max"]
                assert profile["cancel_handler_cleanup_ns"] >= 0 and profile["elapsed_ns"] > 0
                assert profile["sample_interval_ns"] == 5_000_000
                assert profile["sampled_peak_available"] == (profile["samples"] > 0)
                for field in FIELDS:
                    memory = profile[field]
                    assert set(memory) == MEMORY_KEYS
                    assert all(type(v) is int and v >= 0 for v in memory.values())
                    assert memory["HeapAlloc"] <= memory["HeapInuse"]
                    assert 0 < memory["PrivateWorkingSet"] <= memory["WorkingSet"]
                    assert memory["PrivateCommit"] > 0
                assert profile["allocation_bytes"] == profile["after_calls"]["TotalAlloc"] - profile["before_calls_after_gc"]["TotalAlloc"] >= 0
                assert profile["allocations"] == profile["after_calls"]["Mallocs"] - profile["before_calls_after_gc"]["Mallocs"] >= 0
                for field, name in (("heap_alloc", "HeapAlloc"), ("heap_inuse", "HeapInuse"),
                                    ("working_set", "WorkingSet"), ("private_working_set", "PrivateWorkingSet"),
                                    ("private_commit", "PrivateCommit")):
                    assert profile["sampled_peak_fields"][field] >= profile["before_calls_after_gc"][name]
                name = phase + "--" + test.split("/", 1)[1].replace("/", "-") + ".json"
                directory = RESULTS / "reconstructed"
                directory.mkdir(exist_ok=True)
                path = directory / name
                path.open("xb").write(raw_profile)
                profiles.append({"phase": phase, "package": package, "test": test,
                                 "race_detector": "-race" in command["argv"], "go_command_pid": command["pid"],
                                 "output_fragments_for_test": len(pieces), "reconstructed_json": pin(path),
                                 "profile": profile,
                                 "derived": {"total_workers": workers,
                                             "allocation_bytes_per_completed_measured_call": profile["allocation_bytes"] / n,
                                             "allocations_per_completed_measured_call": profile["allocations"] / n,
                                             "latency_p50_sorted_zero_based_index": (n - 1) // 2,
                                             "latency_p95_sorted_zero_based_index": (95 * n + 99) // 100 - 1}})
        else:
            assert streams["stdout"] == b""
        commands.append(row)
    qualifications.append({"phase": phase, "plan": pin(plan_path), "receipt": pin(receipt_path),
                           "completed": True, "source_before_after": receipt["source_before"],
                           "inputs_before_after": receipt["inputs_before"], "commands": commands})

assert len(profiles) == 6
nonrace = [row for row in profiles if not row["race_detector"]]
race = [row for row in profiles if row["race_detector"]]
assert len(nonrace) == len(race) == 3 and len({row["go_command_pid"] for row in nonrace}) == 3
assert len({row["go_command_pid"] for row in race}) == 1
assert all(plans[phase]["source_files"] == plans[PHASES[0]]["source_files"] for phase in PHASES)
assert all(plans[phase]["input_files"] == plans[PHASES[0]]["input_files"] for phase in PHASES)
assert all(receipts[phase]["tools_sha256"] == receipts[PHASES[0]]["tools_sha256"] for phase in PHASES)
origins = next(row for row in json.loads((ROOT / "qualification/composition-origins.json").read_bytes()) if row["scope"] == "relay-published")
origin_paths = {row["path"] for row in origins["files"]}
composition = []
for row in origins["files"]:
    path = ROOT / "qualification/inputs/relay" / row["path"]
    data = path.read_bytes()
    assert sha(data) == row["candidate_sha256"] and len(data) == row["candidate_bytes"]
    commit = CANON if row["path"] in ("internal/daemon/main_test.go", "internal/daemon/main_dispatch_test.go") else RELAY
    assert git_bytes(commit, row["path"]) == data
    composition.append({**pin(path), "repository_path": row["path"], "exact_git_origin": commit})
for path in sorted((ROOT / "qualification/inputs/relay").rglob("*.go")):
    rel = path.relative_to(ROOT / "qualification/inputs/relay").as_posix()
    if rel not in origin_paths:
        assert path.read_bytes() == (ROOT / "profiles" / rel).read_bytes()
        composition.append({**pin(path), "repository_path": rel, "origin": "current profiles worktree, checked byte-equal; runtime plan pins are authoritative"})
assert len(composition) == 26
overlay = json.loads((ROOT / "qualification/inputs/relay/overlay.json").read_bytes())["Replace"]
assert len(overlay) == 26
for row in composition:
    rel = row["repository_path"].replace("/", "\\")
    assert overlay[NATIVE + "\\source\\" + rel] == NATIVE + "\\inputs\\relay\\" + rel

totals = {key: sum(row["profile"][key] for row in nonrace) for key in
          ("warmup_calls", "held_calls", "measured_calls", "completed_calls", "cancelled_calls",
           "cancelled_handler_cleanups_observed", "server_calls", "lost_or_corrupted", "deleted_sessions", "get_requests")}
report = {
    "schema": 1, "status": "LIMITED_RELAY_SDK_RUNTIME_RESULTS_VERIFIED", "reviewer": "/root/pr658_audit",
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "Independent local readback/data/source review of six completed phases; no repeat runtime, source mutation or publication.",
    "mandatory_findings": [], "readback": pin(RESULTS / "readback-manifest.json"),
    "analyzer": pin(Path(__file__).resolve()), "runner": pin(ROOT / "qualification/qualify_go.py"),
    "source_composition": {"physical_source_commit": SOURCE, "physical_source_tree": TREE,
                           "master_reference": "75dbc6406123e22468f168b861d5e0622c9d5769",
                           "production_relay_origin": RELAY, "canonical_two_test_fixtures_origin": CANON,
                           "profile_worktree_base": "04e1e19650318725850225ebadc521cbf97dadd9",
                           "origins": pin(ROOT / "qualification/composition-origins.json"),
                           "archived_20_source_files_sha256": origins["archive_sha256"],
                           "input_inventory": inventory(plans[PHASES[0]]["input_files"]),
                           "go_overlay_files": 26, "files": composition},
    "tools_sha256": receipts[PHASES[0]]["tools_sha256"],
    "environment": {key: receipts[PHASES[0]]["environment"][key] for key in
                    ("GOOS", "GOARCH", "GOGC", "GOMAXPROCS", "GOPROXY", "GOTOOLCHAIN", "GOFLAGS", "GOMODCACHE", "GOCACHE")},
    "qualifications": qualifications,
    "terminal_totals": dict(terminal_totals, test_fail=0, package_fail=0, skip=0, build_exit=0, vet_exit=0),
    "non_race_fresh_process_profiles": nonrace, "race_functional_profiles": race,
    "non_race_call_totals": totals,
    "checks": {"all_20_imported_raw_file_hashes": True, "all_six_exact_plan_hashes_and_runner_pins": True,
               "all_six_complete_source_and_declared_input_before_after_receipts_match_plan_inventories": True,
               "all_27_local_overlay_inputs_match_every_plan": True, "all_seven_commands_settled_without_timeout": True,
               "all_terminal_events_recomputed_exactly": True, "all_profile_jsons_reconstructed_per_test_across_output_events": True,
               "all_36_named_memory_snapshots_have_valid_units_shape_and_basic_relations": True,
               "all_six_allocation_differences_match_cumulative_snapshots": True,
               "all_six_profile_call_counts_close_state_and_session_deletions_match": True},
    "limits": [
        "These are three distinct closed-loop synthetic configurations in three fresh non-race go test invocations, not repeated samples of one configuration or a before/after comparison. No causal improvement or production SLO follows.",
        "Whole-process memory and allocations include SDK client/server, Relay, measurement driver, payloads, response checks and reachable cleanup closures/closed objects. No Relay-only or standalone-executable attribution is made.",
        "Five-millisecond sampling produced per-field maxima and counts, not an exported time series. Maxima may occur at different instants and are lower bounds on transient peaks; the after_calls snapshot may exceed a sampled maximum.",
        "Only aggregate p50/p95/max latency values are exported. Their order and source-defined ranks were checked; individual durations are unavailable for independent percentile recomputation. The p50 uses the lower middle element for even sample counts.",
        "GET requests are 0, 0 and 4 in the non-race profiles. Only the third observed GET traffic. There is no GET readiness barrier, server-initiated GET message workload or forced reconnect in this profile; earlier #629 reconnect evidence remains separate.",
        "Cancellation covers one entered synthetic tool call per client and its deferred active decrement/signal. cancel_handler_cleanup_ns includes client cancellation returns and tool cleanup; it does not independently time final HTTP response drain. Full owner cleanup is checked later after close.",
        "The cancellation oracle accepts errors.Is(context.Canceled); it does not export each returned error or exclude additional joined cancellation-notification errors. No claim of exclusive cancellation error identity is made.",
        "Call integrity is checked at SDK call/result level against sequence and payload, not every wire frame that SDK may discard. lost_or_corrupted=0 is conditional on those executed assertions.",
        "The harness enforces a direct-child deadline only; whole_process_tree_deadline_enforced=false. Successful owner checks are bounded to these fixture lifetimes, not a native or installed-product process-tree guarantee.",
        "The runtime receipts record complete 3281-file source admission and 27 declared input identities before/after. This reviewer did not re-read the whole remote source/cache or re-run any Go command; local metadata/input bindings and exact exported raw results were independently checked.",
        "SDK semantic version comes from pinned module/source composition, not a version field in these profile JSONs; complete module-cache verification is outside these six receipts.",
        "Full regression, installed Hub acceptance, public-network behavior and external review of an exact newly published head remain outside this result."
    ],
    "export_note": {"remote_writes": False, "new_load_processes": False,
                    "attempt_1": "Read-only exporter stopped because Windows lstat/fstat ctime fields differed for one unchanged file. Raw failure and exact metadata diagnosis retained.",
                    "attempt_2": "Compared ctime within the same API and stable identity across APIs; exact completed-receipt log hashes remained mandatory. Successful export imported 20 files.",
                    "source": pin(RESULTS / "export_readonly.py")},
}
output = ROOT / "evidence/relay-sdk-profile-results.json"
write_new(output, report)
print(json.dumps({"report": pin(output), "terminal_totals": report["terminal_totals"],
                  "non_race_call_totals": totals,
                  "profiles": [{"phase": r["phase"], "clients": r["profile"]["clients"],
                                "workers": r["derived"]["total_workers"], "samples": r["profile"]["samples"],
                                "GET": r["profile"]["get_requests"], "race": r["race_detector"]} for r in profiles]}, indent=2))
