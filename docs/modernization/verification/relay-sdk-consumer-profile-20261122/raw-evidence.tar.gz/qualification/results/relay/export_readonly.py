"""Read only the six completed Relay evidence phases; emit their exact bytes."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792\evidence")
PHASES = (
    "relay-load-compatibility",
    "relay-sdk-race",
    "relay-sdk-profile-1",
    "relay-sdk-profile-2",
    "relay-sdk-profile-3",
    "relay-sdk-build-vet",
)


def identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_mode, info.st_nlink,
            getattr(info, "st_file_attributes", 0))


def regular(path, limit):
    before = path.lstat()
    if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
            or getattr(before, "st_file_attributes", 0) & 0x400):
        raise RuntimeError("not a single-link regular evidence file: " + str(path))
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        content = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    final = path.lstat()
    # Windows Python exposes ctime differently through lstat and fstat.
    # Compare ctime within each API and stable identity across both APIs.
    if (len(content) > limit or identity(before) != identity(opened)
            or identity(before) != identity(after) or identity(before) != identity(final)
            or before.st_ctime_ns != final.st_ctime_ns
            or opened.st_ctime_ns != after.st_ctime_ns):
        raise RuntimeError("oversized or changed evidence file: " + str(path))
    return content


def checked_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("not a non-reparse directory: " + str(path))


def record(path, content):
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": len(content),
        "sha256": hashlib.sha256(content).hexdigest(),
        "base64": base64.b64encode(content).decode("ascii"),
    }


if os.name != "nt" or not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
    raise RuntimeError("requires isolated Windows Python without site or bytecode")
for ancestor in reversed((ROOT,) + ROOT.parents[:-1]):
    checked_directory(ancestor)

rows = []
for phase in PHASES:
    directory = ROOT / phase
    checked_directory(directory)
    receipt_path = directory / "receipt.json"
    receipt_bytes = regular(receipt_path, 2 * 1024 * 1024)
    receipt = json.loads(receipt_bytes)
    if receipt.get("phase") != phase or receipt.get("completed") is not True:
        raise RuntimeError("phase not completed: " + phase)
    rows.append(record(receipt_path, receipt_bytes))
    labels = set()
    for command in receipt["commands"]:
        label = command["label"]
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", label) or label in labels:
            raise RuntimeError("invalid or duplicate command label")
        labels.add(label)
        for channel in ("stdout", "stderr"):
            path = directory / (label + "." + channel + ".log")
            content = regular(path, 16 * 1024 * 1024)
            row = record(path, content)
            if row["bytes"] != command[channel]["bytes"] or row["sha256"] != command[channel]["sha256"]:
                raise RuntimeError("log differs from completed receipt: " + str(path))
            rows.append(row)
    if regular(receipt_path, 2 * 1024 * 1024) != receipt_bytes:
        raise RuntimeError("receipt changed during export: " + phase)

payload = json.dumps({"schema": 1, "root": str(ROOT), "phases": PHASES,
                      "read_only": True, "files": rows},
                     ensure_ascii=True, separators=(",", ":")).encode("ascii")
envelope = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(),
            "base64_zlib": base64.b64encode(zlib.compress(payload, 9)).decode("ascii")}
print("RELAY_EXPORT_V1 " + json.dumps(envelope, separators=(",", ":")), flush=True)
