"""Offline qualification of scheduler cancellation error identity in one isolated clone."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from collections import Counter

ROOT = Path(r"<WORK_ROOT>\mcp-go-reconcile-fixture-20261120")
SOURCE = ROOT / "source"
BASE = "4f3513d886e301d7a358884a34896402f99e8002"
BASE_TREE = "d6f893de2a0957a59038f3a1c582ff21d3a76282"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
TARGET = "internal/cli/supervise_reconcile_ipc_test.go"
BEFORE = "^(TestReconcileIPC_HandlerTimeoutCancelsSchedulerList|TestReconcileIPC_HandlerTimeout)$"
AFTER = "^(TestReconcileIPC_ParentCancellationReachesSchedulerList|TestReconcileIPC_HandlerTimeout)$"
phase = sys.argv[1]
if os.name != "nt" or sys.flags.optimize or phase not in {"baseline", "candidate", "build-vet", "published"}:
    raise SystemExit("Unsupported invocation")
out = ROOT / "evidence" / phase
out.mkdir(parents=True, exist_ok=False)
runtime = ROOT / "runtime" / phase
runtime.mkdir(parents=True, exist_ok=False)
for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks"):
    (runtime / name).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_")) and k.upper() != "SSH_ASKPASS"}
system = Path(env.get("SYSTEMROOT") or env["SystemRoot"])
ps = system / "System32/WindowsPowerShell/v1.0/powershell.exe"
env.update({
    "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly",
    "GOCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gocache",
    "GOMODCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache",
    "GOPATH": str(runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
    "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
    "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"),
    "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
    "PSModuleAnalysisCachePath": str(runtime / "localappdata/module-cache"), "PYTHONDONTWRITEBYTECODE": "1",
    "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"),
    "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never",
})
env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))
for path in (GO, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    if not path.exists():
        raise SystemExit("Missing pre-existing tool/cache")
manifest_raw = (ROOT / "MANIFEST.json").read_bytes()
manifest = json.loads(manifest_raw)
files = manifest["changed_files"]
paths = [item["path"] for item in files]
if manifest["base_commit"] != BASE or paths != [TARGET]:
    raise RuntimeError("Unexpected test manifest")
sha = lambda data: hashlib.sha256(data).hexdigest()
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
receipt = {"schema": 1, "phase": phase, "base": BASE, "started_utc": utc(),
           "runner_sha256": sha(Path(__file__).read_bytes()), "commands": [], "completed": False,
           "native_task_operations": False, "actual_deadline_expiry_exercised": False,
           "whole_process_tree_deadline_enforced": False, "manifest_sha256": sha(manifest_raw),
           "environment": {k: env[k] for k in ("GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB", "GOVCS", "GOWORK", "GOFLAGS", "GOTELEMETRY", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")}}


def git_at(path, *args):
    return subprocess.check_output([str(GIT), "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), "-C", str(path), *args],
                                   env=env, stdin=subprocess.DEVNULL, timeout=60).decode("utf-8").strip()


def run(label, executable, args, cwd=SOURCE):
    row = {"label": label, "executable": executable.name, "args": args, "started_utc": utc(), "settled": False}
    receipt["commands"].append(row)
    print("START " + label, flush=True)
    started = time.monotonic()
    with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
        with subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr) as child:
            row["pid"] = child.pid
            row["exit_code"] = child.wait()
            row["settled"] = True
    row.update(seconds=time.monotonic()-started, finished_utc=utc())
    for stream in ("stdout", "stderr"):
        raw = (out / (label + "." + stream + ".log")).read_bytes()
        row[stream] = {"bytes": len(raw), "sha256": sha(raw)}
    if args and args[0] == "test" and "-json" in args:
        events = [json.loads(line) for line in (out / (label + ".stdout.log")).read_text(encoding="utf-8").splitlines()]
        row["tests"] = {action: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == action] for action in ("pass", "fail", "skip")}
    with (out / (label + ".receipt.json")).open("x", encoding="utf-8") as stream:
        json.dump(row, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: row[k] for k in ("label", "exit_code", "seconds", "settled")}), flush=True)
    return row


def require_pass(row):
    if row["exit_code"] != 0 or row.get("tests", {}).get("fail"):
        raise RuntimeError(row["label"] + " failed")


def admit(expected_head, changed_paths, candidate_paths):
    if git_at(SOURCE, "rev-parse", "HEAD") != expected_head or git_at(SOURCE, "diff", "--cached", "--name-only"):
        raise RuntimeError("Unexpected head or staged changes")
    actual = {line.strip() for line in git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching").splitlines()}
    if actual != {"M " + path for path in changed_paths}:
        raise RuntimeError("Unexpected tracked, untracked, ignored or staged source state")
    hashes = {path: sha((SOURCE / path).read_bytes()) for path in paths}
    if any(hashes[item["path"]] != item["candidate_sha256" if item["path"] in candidate_paths else "base_sha256"] for item in files):
        raise RuntimeError("Source byte mismatch")
    return hashes


def require_expected_tests(row, names):
    require_pass(row)
    expected = Counter({name: 2 for name in names})
    expected["PACKAGE:mcp-local-hub/internal/cli"] = 1
    if row["tests"]["skip"] or Counter(row["tests"]["pass"]) != expected:
        raise RuntimeError("Unexpected CLI positive test inventory")

try:
    if phase == "baseline":
        if SOURCE.exists():
            raise RuntimeError("Source already exists")
        require_pass(run("init-exact-source", GIT, ["-c", "core.autocrlf=false", "init", str(SOURCE)], ROOT))
        git_at(SOURCE, "config", "core.autocrlf", "false")
        git_at(SOURCE, "config", "core.hooksPath", str(runtime / "empty-hooks"))
        require_pass(run("fetch-exact-base", GIT, ["-c", "credential.helper=", "-c", "core.askPass=", "fetch", "--no-tags", "--depth=1", "https://github.com/applicate2628/mcp-local-hub.git", BASE]))
        git_at(SOURCE, "checkout", "--detach", BASE)
        if git_at(SOURCE, "rev-parse", "HEAD^{tree}") != BASE_TREE:
            raise RuntimeError("Wrong base tree")
        receipt["source_sha256_before"] = admit(BASE, [], [])
        require_pass(run("go-version", GO, ["version"]))
        row = run("baseline-timeout-race", GO, ["test", "-json", "-tags=test_state_path_env", "-race", "-count=2", "-timeout=180s", "-run", BEFORE, "./internal/cli"])
        failed = "TestReconcileIPC_HandlerTimeoutCancelsSchedulerList"
        if row["exit_code"] != 1 or row["tests"]["fail"] != [failed, failed, "PACKAGE:mcp-local-hub/internal/cli"] or row["tests"]["pass"] != ["TestReconcileIPC_HandlerTimeout"] * 2 or row["tests"]["skip"]:
            raise RuntimeError("Expected fixture failure not reproduced on exact PR658")
        events = [json.loads(line) for line in (out / "baseline-timeout-race.stdout.log").read_text(encoding="utf-8").splitlines()]
        if sum("scheduler ListContext did not observe reconcile context cancellation" in e.get("Output", "") for e in events if e.get("Test") == failed) != 2:
            raise RuntimeError("Wrong baseline failure")
        receipt["baseline_failure_confirmed"] = True
        receipt["source_sha256_after"] = admit(BASE, [], [])
    elif phase == "candidate":
        prior_raw = (ROOT / "evidence/baseline/receipt.json").read_bytes()
        prior = json.loads(prior_raw)
        if not prior["completed"] or not prior.get("baseline_failure_confirmed") or prior["source_head"] != BASE:
            raise RuntimeError("Baseline not admitted")
        receipt["retained_baseline_receipt_sha256"] = sha(prior_raw)
        receipt["source_sha256_before"] = admit(BASE, [], [])
        require_pass(run("check-test-patch", GIT, ["apply", "--check", str(ROOT / "candidate.patch")]))
        require_pass(run("apply-test-patch", GIT, ["apply", str(ROOT / "candidate.patch")]))
        require_pass(run("format-test", GO.with_name("gofmt.exe"), ["-w", TARGET]))
        receipt["candidate_sha256_before_tests"] = admit(BASE, paths, paths)
        row = run("parent-cancellation-race", GO, ["test", "-json", "-tags=test_state_path_env", "-race", "-count=2", "-timeout=180s", "-run", AFTER, "./internal/cli"])
        require_expected_tests(row, ["TestReconcileIPC_ParentCancellationReachesSchedulerList", "TestReconcileIPC_HandlerTimeout"])
        receipt["source_sha256_after"] = admit(BASE, paths, paths)
    else:
        expected = sys.argv[2] if phase == "published" else BASE
        receipt["source_sha256_before"] = admit(expected, [] if phase == "published" else paths, paths)
        if phase == "published":
            row = run("parent-cancellation-race", GO, ["test", "-json", "-tags=test_state_path_env", "-race", "-count=2", "-timeout=180s", "-run", AFTER, "./internal/cli"])
            require_expected_tests(row, ["TestReconcileIPC_ParentCancellationReachesSchedulerList", "TestReconcileIPC_HandlerTimeout"])
        else:
            require_pass(run("build", GO, ["build", "./..."]))
            require_pass(run("vet", GO, ["vet", "./..."]))
        receipt["source_sha256_after"] = admit(expected, [] if phase == "published" else paths, paths)
    require_pass(run("diff-check", GIT, ["diff", "--check"]))
    receipt.update(source_head=git_at(SOURCE, "rev-parse", "HEAD"), source_tree=git_at(SOURCE, "rev-parse", "HEAD^{tree}"), working_status=git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"), completed=True)
except Exception as error:
    receipt.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    receipt["finished_utc"] = utc()
    with (out / "receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: receipt.get(key) for key in ("phase", "completed", "error", "baseline_failure_confirmed", "source_head")}), flush=True)
