"""Read-only literal/method scan of the exact published scheduler snapshot."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cancellation-20261120")
SOURCE = ROOT / "source"
COMMIT = "11c286fb634cc63d2c6019a790ff376a1d834af9"
TREE = "ba769a5cbed3e05d3071a0cfb846127019500b49"
runtime = ROOT / "runtime/published"
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_") and k.upper() != "SSH_ASKPASS"}
for key, name in (("USERPROFILE", "profile"), ("APPDATA", "appdata"), ("LOCALAPPDATA", "localappdata"), ("TEMP", "tmp"), ("TMP", "tmp")):
    env[key] = str(runtime / name)
env.update(GIT_OPTIONAL_LOCKS="0", GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=str(runtime / "no-global-config"), GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never")
prefix = [r"C:\Program Files\Git\cmd\git.exe", "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), "-C", str(SOURCE)]
digest = lambda b: hashlib.sha256(b).hexdigest()

def git(*args):
    return subprocess.check_output(prefix + list(args), env=env, stdin=subprocess.DEVNULL, timeout=60).decode("utf-8").strip()

def identity():
    row = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "status": git("status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching")}
    if row != {"head": COMMIT, "tree": TREE, "status": ""}:
        raise RuntimeError("Unexpected source identity")
    return row

before = identity()
patterns = {"direct_errors_unwrap": r"\berrors\.Unwrap\s*\(", "unwrap_method": r"\bUnwrap\s*\(\s*\)\s*(?:\[\s*\]\s*)?error\b", "scheduler_parallel": r"\bt\.Parallel\s*\("}
matches = {key: [] for key in patterns}
files = git("ls-files", "--", "*.go").splitlines()
file_hashes = {}
for name in files:
    raw = (SOURCE / name).read_bytes()
    for key, pattern in patterns.items():
        if key == "scheduler_parallel" and not name.startswith("internal/scheduler/"):
            continue
        for lineno, line in enumerate(raw.decode("utf-8").splitlines(), 1):
            if re.search(pattern, line):
                matches[key].append({"path": name, "line": lineno, "text": line.strip()})
                file_hashes[name] = digest(raw)
after = identity()
if any(digest((SOURCE / name).read_bytes()) != value for name, value in file_hashes.items()):
    raise RuntimeError("Matched source changed")
result = {"schema": 1, "runner_sha256": digest(Path(__file__).read_bytes()), "source_before": before, "source_after": after,
          "scanned_tracked_go_files": len(files), "patterns": patterns, "matches": matches, "matched_file_sha256": file_hashes,
          "scope": "literal errors.Unwrap calls, zero-argument Unwrap error methods/type expressions, and t.Parallel in scheduler only; this is not semantic analysis of aliases, reflection, or external consumers",
          "product_commands_executed": False, "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
with (ROOT / "source-review.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result), flush=True)
