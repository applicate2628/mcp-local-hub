"""Offline qualification of scheduler cancellation error identity in one isolated clone."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from collections import Counter

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cancellation-20261120")
SOURCE = ROOT / "source"
OLD = Path(r"<WORK_ROOT>\mcp-r17-prune-snapshot-20261120\source")
BASE = "f5fb00370a833255eacb992a7cd32f2e68da7399"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
PRODUCT = "internal/scheduler/scheduler_com_windows.go"
TESTS = ["internal/scheduler/scheduler_com_windows_test.go"]
CONTROL = "^(TestSchedulerCOMPreservesRunnerErrors|TestWindowsListContextPreservesStoppedContext)$"
FOCUSED = "^(TestSchedulerCOMTypedOutcomesIgnoreHostileLocalizedText|TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable|TestSchedulerCOMPreservesRunnerErrors|TestWindowsListContextPreservesStoppedContext|TestTaskStatusFromCOMUsesNumericStateOnly|TestSchedulerCOMScriptSerializesNegativeHRESULT|TestSchedulerCOMScriptUTF8ConsoleRoundTripsUnicodeTaskJSON)$"
ADJACENT = "^(TestReconcileIPC_HandlerTimeoutCancelsSchedulerList|TestReconcileIPC_HandlerTimeout)$"
phase = sys.argv[1]
if os.name != "nt" or sys.flags.optimize or phase not in {"control", "candidate", "focused", "adjacent", "build-vet", "published"}:
    raise SystemExit("Unsupported invocation")
out = ROOT / "evidence" / phase
out.mkdir(parents=True, exist_ok=False)
runtime = ROOT / "runtime" / phase
runtime.mkdir(parents=True, exist_ok=False)
for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks"):
    (runtime / name).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_")) and k.upper() != "SSH_ASKPASS"}
system = Path(env.get("SYSTEMROOT") or env["SystemRoot"])
ps = system / "System32/WindowsPowerShell/v1.0/powershell.exe"
env.update({
    "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly",
    "GOCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gocache",
    "GOMODCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache",
    "GOPATH": str(runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
    "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
    "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"),
    "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
    "PSModuleAnalysisCachePath": str(runtime / "localappdata/module-cache"), "PYTHONDONTWRITEBYTECODE": "1",
    "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"),
    "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never",
})
env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))
for path in (GO, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    if not path.exists():
        raise SystemExit("Missing pre-existing tool/cache")
manifest = json.loads((ROOT / "hashes.json").read_text(encoding="utf-8"))
files = manifest["files"]
paths = [item["path"] for item in files]
if manifest["base_commit"] != BASE or set(paths) != {PRODUCT, *TESTS} or len(paths) != 2:
    raise SystemExit("Unexpected source manifest")
sha = lambda data: hashlib.sha256(data).hexdigest()
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
receipt = {"schema": 1, "phase": phase, "base": BASE, "started_utc": utc(),
           "runner_sha256": sha(Path(__file__).read_bytes()), "commands": [], "completed": False,
           "native_task_operations": False, "after_start_cancellation_exercised": False, "whole_process_tree_deadline_enforced": False,
           "manifest_sha256": sha((ROOT / "hashes.json").read_bytes()),
           "environment": {k: env[k] for k in ("GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB", "GOVCS", "GOWORK", "GOFLAGS", "GOTELEMETRY", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")}}


def git_at(path, *args):
    return subprocess.check_output([str(GIT), "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), "-C", str(path), *args],
                                   env=env, stdin=subprocess.DEVNULL, timeout=60).decode("utf-8").strip()


def run(label, executable, args, cwd=SOURCE):
    row = {"label": label, "executable": executable.name, "args": args, "started_utc": utc(), "settled": False}
    receipt["commands"].append(row)
    print("START " + label, flush=True)
    started = time.monotonic()
    with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
        with subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr) as child:
            row["pid"] = child.pid
            row["exit_code"] = child.wait()
            row["settled"] = True
    row.update(seconds=time.monotonic()-started, finished_utc=utc())
    for stream in ("stdout", "stderr"):
        raw = (out / (label + "." + stream + ".log")).read_bytes()
        row[stream] = {"bytes": len(raw), "sha256": sha(raw)}
    if args and args[0] == "test" and "-json" in args:
        events = [json.loads(line) for line in (out / (label + ".stdout.log")).read_text(encoding="utf-8").splitlines()]
        row["tests"] = {action: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == action] for action in ("pass", "fail", "skip")}
    with (out / (label + ".receipt.json")).open("x", encoding="utf-8") as stream:
        json.dump(row, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: row[k] for k in ("label", "exit_code", "seconds", "settled")}), flush=True)
    return row


def require_pass(row):
    if row["exit_code"] != 0 or row.get("tests", {}).get("fail"):
        raise RuntimeError(row["label"] + " failed")


def confirm_positive(row, selection, package):
    require_pass(row)
    names = selection[2:-2].split("|")
    if package == "scheduler":
        names += ["TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable/" + case for case in ("permission_denied", "task_corrupt", "scheduler_unavailable")]
        names += ["TestSchedulerCOMPreservesRunnerErrors/" + case for case in ("canceled", "deadline", "bridge")]
        names += ["TestWindowsListContextPreservesStoppedContext/" + case for case in ("canceled", "deadline")]
    expected = Counter({name: 2 for name in names})
    expected["PACKAGE:mcp-local-hub/internal/" + package] = 1
    if row["tests"]["skip"] or Counter(row["tests"]["pass"]) != expected:
        raise RuntimeError("Unexpected positive test selection or event counts")


def admit(expected_head, changed_paths, candidate_paths):
    if git_at(SOURCE, "rev-parse", "HEAD") != expected_head or git_at(SOURCE, "diff", "--cached", "--name-only"):
        raise RuntimeError("Unexpected head or staged changes")
    actual = {line.strip() for line in git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching").splitlines()}
    if actual != {"M " + path for path in changed_paths}:
        raise RuntimeError("Unexpected tracked, untracked, ignored or staged source state")
    hashes = {path: sha((SOURCE / path).read_bytes()) for path in paths}
    if any(hashes[item["path"]] != item["candidate_sha256" if item["path"] in candidate_paths else "base_sha256"] for item in files):
        raise RuntimeError("Source byte mismatch")
    return hashes


def confirm_control(row, raw):
    events = [json.loads(line) for line in raw.decode("utf-8").splitlines()]
    groups = {"TestSchedulerCOMPreservesRunnerErrors": ("canceled", "deadline", "bridge"),
              "TestWindowsListContextPreservesStoppedContext": ("canceled", "deadline")}
    expected_fail = [value for name, cases in groups.items() for value in ([name + "/" + case for case in cases] + [name])] + ["PACKAGE:mcp-local-hub/internal/scheduler"]
    if row["exit_code"] != 1 or row["tests"]["fail"] != expected_fail or row["tests"]["skip"] or row["tests"]["pass"]:
        raise RuntimeError("Unexpected negative-control outcome")
    for name, cases in groups.items():
        for case in cases:
            output = "".join(e.get("Output", "") for e in events if e.get("Test") == name + "/" + case)
            if "error identity lost:" not in output:
                raise RuntimeError("Negative control failed for a different cause")
    receipt["negative_control_confirmed"] = True


try:
    if phase == "control":
        if SOURCE.exists() or git_at(OLD, "rev-parse", "HEAD") != BASE or git_at(OLD, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"):
            raise RuntimeError("Source not admitted or destination exists")
        require_pass(run("clone", GIT, ["-c", "core.autocrlf=false", "clone", "--local", "--no-hardlinks", "--no-checkout", str(OLD), str(SOURCE)], ROOT))
        git_at(SOURCE, "config", "core.autocrlf", "false")
        git_at(SOURCE, "config", "core.hooksPath", str(runtime / "empty-hooks"))
        git_at(SOURCE, "checkout", "--detach", BASE)
        receipt["base_sha256"] = admit(BASE, [], [])
        require_pass(run("apply-control", GIT, ["apply", "--check", str(ROOT / "negative-control.patch")]))
        require_pass(run("write-control", GIT, ["apply", str(ROOT / "negative-control.patch")]))
        require_pass(run("format-tests", GO.with_name("gofmt.exe"), ["-w", *TESTS]))
        receipt["source_sha256_before"] = admit(BASE, TESTS, TESTS)
        require_pass(run("go-version", GO, ["version"]))
        row = run("original-cancellation-control", GO, ["test", "-json", "-tags=test_state_path_env", "-count=1", "-timeout=120s", "-run", CONTROL, "./internal/scheduler"])
        confirm_control(row, (out / "original-cancellation-control.stdout.log").read_bytes())
        receipt["source_sha256_after"] = admit(BASE, TESTS, TESTS)
    elif phase == "candidate":
        prior_path = ROOT / "evidence/control/receipt.json"
        prior_raw = prior_path.read_bytes()
        prior = json.loads(prior_raw)
        control = next(row for row in prior["commands"] if row["label"] == "original-cancellation-control")
        if prior["base"] != BASE or not prior["completed"] or not prior.get("negative_control_confirmed") or not control["settled"]:
            raise RuntimeError("Prior control was not admitted")
        for name in ("stdout", "stderr"):
            raw = (prior_path.parent / ("original-cancellation-control." + name + ".log")).read_bytes()
            if sha(raw) != control[name]["sha256"] or len(raw) != control[name]["bytes"]:
                raise RuntimeError("Retained control stream changed")
        confirm_control(control, (prior_path.parent / "original-cancellation-control.stdout.log").read_bytes())
        receipt["retained_control_receipt_sha256"] = sha(prior_raw)
        receipt["control_rerun"] = False
        receipt["source_sha256_before"] = admit(BASE, TESTS, TESTS)
        require_pass(run("apply-product", GIT, ["apply", "--check", str(ROOT / "product.patch")]))
        require_pass(run("write-product", GIT, ["apply", str(ROOT / "product.patch")]))
        require_pass(run("format-candidate", GO.with_name("gofmt.exe"), ["-w", *paths]))
        receipt["source_sha256_after"] = admit(BASE, paths, paths)
    else:
        expected = sys.argv[2] if phase == "published" else BASE
        changed_paths = [] if phase == "published" else paths
        receipt["source_sha256_before"] = admit(expected, changed_paths, paths)
        if phase in {"focused", "published"}:
            confirm_positive(run("scheduler-contract-race", GO, ["test", "-json", "-tags=test_state_path_env", "-race", "-count=2", "-timeout=180s", "-run", FOCUSED, "./internal/scheduler"]), FOCUSED, "scheduler")
        if phase in {"adjacent", "published"}:
            confirm_positive(run("reconcile-timeout-race", GO, ["test", "-json", "-tags=test_state_path_env", "-race", "-count=2", "-timeout=180s", "-run", ADJACENT, "./internal/cli"]), ADJACENT, "cli")
        elif phase == "build-vet":
            require_pass(run("build", GO, ["build", "./..."]))
            require_pass(run("vet", GO, ["vet", "./..."]))
        receipt["source_sha256_after"] = admit(expected, changed_paths, paths)
    require_pass(run("diff-check", GIT, ["diff", "--check"]))
    receipt["source_head"] = git_at(SOURCE, "rev-parse", "HEAD")
    receipt["source_tree"] = git_at(SOURCE, "rev-parse", "HEAD^{tree}")
    receipt["working_status"] = git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching")
    receipt["completed"] = True
except Exception as error:
    receipt["error_type"] = type(error).__name__
    receipt["error"] = str(error)
    raise
finally:
    receipt["finished_utc"] = utc()
    with (out / "receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: receipt.get(key) for key in ("phase", "completed", "error", "negative_control_confirmed", "source_head")}), flush=True)
