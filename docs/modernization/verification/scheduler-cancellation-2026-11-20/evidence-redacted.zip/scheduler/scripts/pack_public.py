"""Admit and freeze the two independent cancellation evidence lanes.

Run only after both published phases have settled. Input at ROOT/publication-input.json:
{"schema": 1, "cli": {"commit": "<40 lowercase hex>", "tree": "<40 lowercase hex>",
                     "parent": "4f3513d886e301d7a358884a34896402f99e8002"},
 "publication_records": {"scheduler": <GitHub readback>, "cli": <GitHub readback>}}
Each readback has commit/tree/parents/files/source_byte_readback_equal; every files
row has filename/status/additions/deletions/changes/previous_filename. The exact
two-file scheduler and one-file CLI deltas are checked below.

All inputs are read-only. No subprocess, Git command, network, or test is invoked.
No output directory or archive is created before complete admission and an in-memory
ZIP CRC/hash check. Existing outputs are never overwritten or removed. Redacted
scripts are audit records, not runnable copies. Original hashes identify retained
remote bytes; saved hashes identify redacted archive bytes.

Standard-library references: https://docs.python.org/3/library/zipfile.html#zipfile.ZipFile.testzip
https://docs.python.org/3/library/pathlib.html#pathlib.Path.is_symlink
"""
from collections import Counter
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cancellation-20261120")
CLI = Path(r"<WORK_ROOT>\mcp-go-reconcile-fixture-20261120")
OUT = ROOT / "public-evidence"
BASE = "f5fb00370a833255eacb992a7cd32f2e68da7399"
COMMIT = "11c286fb634cc63d2c6019a790ff376a1d834af9"
TREE = "ba769a5cbed3e05d3071a0cfb846127019500b49"
CLI_BASE = "4f3513d886e301d7a358884a34896402f99e8002"
BASE_TREES = {"scheduler": "91ea0a635cbeeae0849b328c2b6064d48f95bdfc",
              "cli": "d6f893de2a0957a59038f3a1c582ff21d3a76282"}
PRODUCT = "internal/scheduler/scheduler_com_windows.go"
SCHEDULER_TEST = "internal/scheduler/scheduler_com_windows_test.go"
CLI_TEST = "internal/cli/supervise_reconcile_ipc_test.go"
FROZEN_MANIFEST = "2dc2c2b5d4078031b904af053b0ad4f8247b367ae966663f8ffb3f8ac21e5c39"
REVIEW_MANIFEST = "693b3123ef67e900e996668032c2352805956eff737a9fecc439812010fbf709"
SCHEDULER_MANIFEST = "4e07c72cb30ffcf0bcc0f199248a28a4ab00ca81e4dc2c82caac61ba03a3e146"
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 96 * 1024 * 1024
MAX_FILES = 600
MAX_EVENTS = 100000
MAX_LINE = 256 * 1024

RUNNERS = {
    "scheduler": {
        "check_cancellation.control.py": "818b4e940a2510fcd5516cd2fbe8992e9ed4b3f7a83883edd3ded1c176753f6e",
        "check_cancellation.positive.py": "bb41ce97ba8626ba77fede81eeb86b4108321fcd8959e3117969cd4948a99584",
        "check_cancellation.baseline.py": "fb9cc704e9f0f4a01c338a70e00b03d236de56a7a2fbc7ab62ab6b0b61472fcf",
        "check_cancellation.py": "3754e6139e84fcf8b7b3a05af8bb80096cd325da5ba4ef058ad3a3105aadc982",
        "checkout_published.py": "56b74be6ebb4a18df92b4bda89022f8f318019b062398013f7dd3d5f213ea247",
        "scan_source.py": "bc0459904c58b13541866f390473a2fac2515b26a5a323d2067201fbc78d2831",
    },
    "cli": {
        "check_cli.py": "06cb0f648dd8137919247fe5dd4c23e91c884a2ac73d799f073a9ad01f24fe55",
        "checkout_published.py": "cc213c911110e7589493924ed3a7daa70aa1466f5cf3c3fd8db69f45b5f93eea",
    },
}
PATCHES = {"scheduler": {
    "candidate.patch": "7d050c1cf2787b59b890b7e9f4865a798fd78ff1545461b9b6d71bd3c270d2dc",
    "negative-control.patch": "695119ada26e2577602eea327f9dad8393784987cb9155cf02419b2b37e2cae6",
    "product.patch": "0bc62272cc9bf969e4d0ced5f5c14924a62720c41c3dc2cf2ea2f08b20fa0706",
}, "cli": {"candidate.patch": "bb58699e2a0b8c2b463cc61b612e22a5735426fc4373689ec0dfe0c58ec86761"}}
PHASE_COMMANDS = {
    "scheduler": {
        "control": ["clone", "apply-control", "write-control", "format-tests", "go-version", "original-cancellation-control", "diff-check"],
        "candidate": ["apply-product", "write-product", "format-candidate", "diff-check"],
        "focused": ["scheduler-contract-race", "diff-check"],
        "adjacent": ["reconcile-timeout-race"],
        "adjacent-baseline": ["clone-baseline", "reconcile-timeout-race", "diff-check"],
        "build-vet": ["build", "vet", "diff-check"],
        "published-checkout": ["stage-exact-files", "fetch-exact-commit", "checkout-detached"],
        "published": ["scheduler-contract-race", "diff-check"],
    },
    "cli": {
        "baseline": ["init-exact-source", "fetch-exact-base", "go-version", "baseline-timeout-race", "diff-check"],
        "candidate": ["check-test-patch", "apply-test-patch", "format-test", "parent-cancellation-race", "diff-check"],
        "build-vet": ["build", "vet", "diff-check"],
        "published-checkout": ["stage-exact-files", "fetch-exact-commit", "checkout-detached"],
        "published": ["parent-cancellation-race", "diff-check"],
    },
}
GROUPS = {"TestSchedulerCOMPreservesRunnerErrors": ("canceled", "deadline", "bridge"),
          "TestWindowsListContextPreservesStoppedContext": ("canceled", "deadline")}
FOCUSED_ROOTS = ["TestSchedulerCOMTypedOutcomesIgnoreHostileLocalizedText", "TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable",
                 *GROUPS, "TestTaskStatusFromCOMUsesNumericStateOnly", "TestSchedulerCOMScriptSerializesNegativeHRESULT",
                 "TestSchedulerCOMScriptUTF8ConsoleRoundTripsUnicodeTaskJSON"]
OLD_CLI = ["TestReconcileIPC_HandlerTimeoutCancelsSchedulerList", "TestReconcileIPC_HandlerTimeout"]
NEW_CLI = ["TestReconcileIPC_ParentCancellationReachesSchedulerList", "TestReconcileIPC_HandlerTimeout"]
FAILURE_TEXT = "scheduler ListContext did not observe reconcile context cancellation"
ENVIRONMENT = {"GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off",
               "GOWORK": "off", "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "GOMAXPROCS": "4", "CGO_ENABLED": "1",
               "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def jsonbytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def object_unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def parse_json(raw):
    return json.loads(raw, object_pairs_hook=object_unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON value")))


def safe_relative(name):
    parts = PurePosixPath(name).parts
    require(isinstance(name, str) and parts and not PurePosixPath(name).is_absolute()
            and ".." not in parts and "\\" not in name and ":" not in name,
            "Unsafe evidence member path")
    return name


def bounded_read(path, root, limit=MAX_FILE):
    require(root.is_dir(), "Missing evidence root")
    path.relative_to(root)
    for entry in (path, *path.parents):
        info = entry.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Evidence path is a link or reparse point")
        if entry == root:
            break
    require(path.is_file() and path.stat().st_size <= limit, "Evidence file missing or too large")
    with path.open("rb") as handle:
        raw = handle.read(limit + 1)
    require(len(raw) <= limit, "Evidence grew beyond size bound")
    return raw


def bounded_names(folder):
    result = set()
    for entry in folder.iterdir():
        result.add(entry.name)
        require(len(result) <= MAX_FILES, "Directory inventory exceeds bound")
    return result


class Inputs:
    def __init__(self):
        self.files = {}
        self.directories = {}
        self.total = 0

    def names(self, folder):
        names = bounded_names(folder)
        if folder in self.directories:
            require(names == self.directories[folder], "Evidence directory changed")
        self.directories[folder] = names
        return names

    def add(self, name, path, root, role="retained original", include=True):
        safe_relative(name)
        if name in self.files:
            require(self.files[name]["path"] == path, "Duplicate evidence member")
            return self.files[name]["raw"]
        raw = bounded_read(path, root)
        self.total += len(raw)
        require(len(self.files) < MAX_FILES and self.total <= MAX_TOTAL, "Evidence inventory exceeds bound")
        self.files[name] = {"path": path, "root": root, "raw": raw, "role": role, "include": include}
        return raw

    def unchanged(self):
        for item in self.files.values():
            require(bounded_read(item["path"], item["root"]) == item["raw"], "Evidence changed during packaging")
        for folder, names in self.directories.items():
            require(bounded_names(folder) == names, "Evidence directory changed during packaging")


def test_policy(label):
    if label == "original-cancellation-control":
        return "negative", "scheduler", list(GROUPS), 1
    if label == "scheduler-contract-race":
        return "scheduler-positive", "scheduler", FOCUSED_ROOTS, 2
    if label in {"reconcile-timeout-race", "baseline-timeout-race"}:
        return "old-cli-failure", "cli", OLD_CLI, 2
    if label == "parent-cancellation-race":
        return "cli-positive", "cli", NEW_CLI, 2
    return None


def recount_tests(raw, command, policy):
    mode, package, roots, count = policy
    args = ["test", "-json", "-tags=test_state_path_env"] + (["-race"] if count == 2 else [])
    args += ["-count=" + str(count), "-timeout=" + ("180s" if count == 2 else "120s"),
             "-run", "^(" + "|".join(roots) + ")$", "./internal/" + package]
    require(command["args"] == args and command.get("executable") == "go.exe", "Test command scope differs")
    lines = raw.decode("utf-8").splitlines()
    require(0 < len(lines) <= MAX_EVENTS and all(len(line) <= MAX_LINE for line in lines), "Test event bounds exceeded")
    require(all("WARNING: DATA RACE" not in line for line in lines), "Unexpected race detector finding")
    events = [parse_json(line) for line in lines]
    require(all(isinstance(event, dict) and isinstance(event.get("Action"), str) for event in events), "Malformed test events")
    expected_package = "mcp-local-hub/internal/" + package
    require(all(event.get("Package") == expected_package for event in events), "Unexpected test package")
    tests = {action: [event.get("Test", "PACKAGE:" + event["Package"]) for event in events if event["Action"] == action]
             for action in ("pass", "fail", "skip")}
    require(tests == command.get("tests") and not tests["skip"], "Test receipt inventory mismatch or skip")
    package_event = "PACKAGE:" + expected_package
    if mode == "negative":
        failures = [item for parent, cases in GROUPS.items() for item in ([parent + "/" + case for case in cases] + [parent])]
        require(tests["fail"] == failures + [package_event] and not tests["pass"], "Negative event inventory differs")
        for parent, cases in GROUPS.items():
            for case in cases:
                output = "".join(event.get("Output", "") for event in events if event.get("Test") == parent + "/" + case)
                require("error identity lost:" in output, "Negative control has another failure cause")
    elif mode == "old-cli-failure":
        require(tests["fail"] == [OLD_CLI[0]] * 2 + [package_event] and tests["pass"] == [OLD_CLI[1]] * 2,
                "Historical CLI failure inventory differs")
        require(sum(FAILURE_TEXT in event.get("Output", "") for event in events if event.get("Test") == OLD_CLI[0]) == 2,
                "Historical CLI failure cause differs")
    else:
        names = list(roots)
        if mode == "scheduler-positive":
            names += ["TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable/" + case
                      for case in ("permission_denied", "task_corrupt", "scheduler_unavailable")]
            names += [parent + "/" + case for parent, cases in GROUPS.items() for case in cases]
        expected = Counter({name: 2 for name in names})
        expected[package_event] = 1
        require(Counter(tests["pass"]) == expected and not tests["fail"], "Positive event inventory differs")
    return tests, mode


def admit_commands(inputs, lane, root, phase, receipt):
    folder = root / "evidence" / phase
    commands = receipt.get("commands")
    require(isinstance(commands, list) and [row.get("label") for row in commands] == PHASE_COMMANDS[lane][phase],
            "Command inventory differs: " + lane + "/" + phase)
    expected_files = {"receipt.json"}
    summary = []
    for command in commands:
        label = command["label"]
        require(command.get("settled", command.get("direct_child_settled")) is True, "Unsettled command")
        require(type(command.get("exit_code")) is int, "Missing command exit code")
        require(isinstance(command.get("seconds"), (int, float)) and math.isfinite(command["seconds"])
                and command["seconds"] >= 0, "Invalid command duration")
        streams = {}
        for stream in ("stdout", "stderr"):
            filename = label + "." + stream + ".log"
            expected_files.add(filename)
            streams[stream] = inputs.add(lane + "/" + phase + "/" + filename, folder / filename, root, "original command stream")
            require(command.get(stream) == {"bytes": len(streams[stream]), "sha256": digest(streams[stream])},
                    "Original command stream hash or size mismatch: " + lane + "/" + phase + "/" + filename)
        if phase != "published-checkout":
            filename = label + ".receipt.json"
            expected_files.add(filename)
            raw = inputs.add(lane + "/" + phase + "/" + filename, folder / filename, root, "original per-command receipt")
            require(parse_json(raw) == command, "Per-command receipt differs from phase receipt")
        policy = test_policy(label)
        expected_exit = 1 if policy and policy[0] in {"negative", "old-cli-failure"} else 0
        require(command["exit_code"] == expected_exit, "Unexpected command outcome")
        row = {key: command[key] for key in ("label", "args", "exit_code", "seconds", "stdout", "stderr")}
        row.update(lane=lane, phase=phase, outcome="observed failure" if expected_exit else "pass")
        if policy:
            require(b"WARNING: DATA RACE" not in streams["stderr"], "Unexpected race detector finding on stderr")
            tests, mode = recount_tests(streams["stdout"], command, policy)
            row["classification"] = mode
            row["events"] = {action: {"test": sum(not name.startswith("PACKAGE:") for name in names),
                                      "package": sum(name.startswith("PACKAGE:") for name in names)} for action, names in tests.items()}
        else:
            require("tests" not in command, "Unexpected test inventory on non-test command")
            if label in {"build", "vet"}:
                require(command["args"] == [label, "./..."] and command.get("executable") == "go.exe", "Build/vet scope differs")
        summary.append(row)
    require(inputs.names(folder) == expected_files, "Missing or extra phase evidence members")
    return summary


def admit_phase(lane, phase, receipt, base, identity, base_hashes, candidate_hashes):
    require(receipt.get("schema") == 1 and receipt.get("base") == base, "Phase schema/base differs")
    require(receipt.get("whole_process_tree_deadline_enforced") is False, "Unsupported process-tree claim")
    checkout = phase == "published-checkout"
    require(receipt.get("completed") is (not (lane == "scheduler" and phase == "adjacent")), "Unexpected phase completion")
    if checkout:
        require((receipt.get("expected_commit"), receipt.get("expected_tree"), receipt.get("head"), receipt.get("tree"),
                 receipt.get("parents"), receipt.get("status")) ==
                (identity["commit"], identity["tree"], identity["commit"], identity["tree"], base, ""),
                "Published checkout ancestry/tree/clean state differs")
        require(receipt.get("source_sha256_before") == candidate_hashes and receipt.get("source_sha256_after") == candidate_hashes,
                "Published checkout source hashes differ")
        return
    require(receipt.get("phase") == phase and receipt.get("environment") == ENVIRONMENT, "Phase name/environment differs")
    require(receipt.get("native_task_operations") is False, "Unexpected native task operation claim")
    limit = "after_start_cancellation_exercised" if lane == "scheduler" else "actual_deadline_expiry_exercised"
    require(receipt.get(limit) is False, "Unsupported cancellation coverage claim")
    expected_manifest = SCHEDULER_MANIFEST if lane == "scheduler" else FROZEN_MANIFEST
    require(receipt.get("manifest_sha256") == expected_manifest, "Execution manifest identity differs")
    control_hashes = dict(base_hashes)
    if lane == "scheduler":
        control_hashes[SCHEDULER_TEST] = candidate_hashes[SCHEDULER_TEST]
    if lane == "scheduler" and phase in {"control", "candidate"}:
        before = control_hashes
        after = control_hashes if phase == "control" else candidate_hashes
        if phase == "control":
            require(receipt.get("base_sha256") == base_hashes and receipt.get("negative_control_confirmed") is True,
                    "Control base or negative confirmation differs")
    elif phase in {"baseline", "adjacent-baseline"}:
        before = after = base_hashes
        key = "baseline_failure_confirmed" if lane == "cli" else "adjacent_failure_reproduced"
        require(receipt.get(key) is True, "Historical baseline failure not confirmed")
    elif lane == "cli" and phase == "candidate":
        before, after = base_hashes, candidate_hashes
        require(receipt.get("candidate_sha256_before_tests") == candidate_hashes, "CLI candidate pre-test source differs")
    else:
        before = after = candidate_hashes
    require(receipt.get("source_sha256_before") == before, "Pre-phase source hashes differ")
    if lane == "scheduler" and phase == "adjacent":
        require(receipt.get("error_type") == "RuntimeError" and receipt.get("error") == "reconcile-timeout-race failed",
                "Unexpected adjacent phase error")
        require(not any(key in receipt for key in ("source_sha256_after", "source_head", "source_tree", "working_status")),
                "Unexpected post-failure source assertion")
        return
    require(receipt.get("source_sha256_after") == after and "error" not in receipt, "Post-phase hashes/error differ")
    published = phase == "published"
    require(receipt.get("source_head") == (identity["commit"] if published else base)
            and receipt.get("source_tree") == (identity["tree"] if published else BASE_TREES[lane]), "Phase head/tree differs")
    changed = [] if published or phase in {"baseline", "adjacent-baseline"} else list(candidate_hashes)
    if lane == "scheduler" and phase == "control":
        changed = [SCHEDULER_TEST]
    require(isinstance(receipt.get("working_status"), str)
            and {line.strip() for line in receipt["working_status"].splitlines()} == {"M " + path for path in changed},
            "Unexpected phase working-tree state")


def redact(raw, identities):
    value = raw.decode("utf-8")
    value = re.sub(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT", "<WORK_ROOT>", value)
    value = re.sub(r'(?i)C:[\\/]{1,4}Users[\\/]{1,4}[^\\/\s"]+', "<USER_PROFILE>", value)
    value = re.sub(r"(?i)S-1-5-21-(?:\d+-){2,}\d+", "<USER_SID>", value)
    for token in identities:
        value = re.sub(r"(?<![\w])" + re.escape(token) + r"(?![\w])", "<LOCAL_IDENTITY>", value, flags=re.I)
    require(not re.search(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT|C:[\\/]{1,4}Users[\\/]{1,4}|S-1-5-21-(?:\d+-){2,}\d+", value),
            "Unredacted private marker")
    require(not re.search(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b|-----BEGIN [A-Z ]*PRIVATE KEY-----", value),
            "Potential credential marker in public evidence")
    return value.encode("utf-8")


def main():
    require(os.name == "nt" and not sys.flags.optimize and len(sys.argv) == 1, "Unsupported packer invocation")
    require(not OUT.exists(), "Output already exists; no files overwritten")
    inputs = Inputs()
    publication = parse_json(inputs.add("publication-input.json", ROOT / "publication-input.json", ROOT, "published identity input"))
    require(set(publication) == {"schema", "cli", "publication_records"} and publication["schema"] == 1
            and set(publication["cli"]) == {"commit", "tree", "parent"}, "Unexpected publication input schema")
    cli_identity = publication["cli"]
    require(all(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{40}", value) for value in cli_identity.values())
            and cli_identity["parent"] == CLI_BASE and cli_identity["commit"] != CLI_BASE, "Invalid CLI publication identity")
    identities = {"scheduler": {"commit": COMMIT, "tree": TREE, "parent": BASE}, "cli": cli_identity}
    require(set(publication["publication_records"]) == set(identities), "Publication readback lanes differ")
    deltas = {"scheduler": {PRODUCT: (3, 3), SCHEDULER_TEST: (58, 5)}, "cli": {CLI_TEST: (25, 16)}}
    for lane, identity in identities.items():
        record = publication["publication_records"][lane]
        require(set(record) == {"commit", "tree", "parents", "files", "source_byte_readback_equal"}
                and record["commit"] == identity["commit"] and record["tree"] == identity["tree"]
                and record["parents"] == [identity["parent"]] and record["source_byte_readback_equal"] is True,
                "Publication readback identity/ancestry/source differs")
        require(isinstance(record["files"], list) and len(record["files"]) == len(deltas[lane]), "Publication file count differs")
        expected_files = [{"filename": path, "status": "modified", "additions": counts[0], "deletions": counts[1],
                           "changes": sum(counts), "previous_filename": None} for path, counts in deltas[lane].items()]
        require(sorted(record["files"], key=lambda item: item["filename"]) == sorted(expected_files, key=lambda item: item["filename"]),
                "Publication file delta differs")
    inputs.add("scheduler/scripts/pack_public.py", Path(__file__).resolve(), ROOT, "packer original")
    commands, phases, manifest_roles = [], {}, []
    for lane, root, base in (("scheduler", ROOT, BASE), ("cli", CLI, CLI_BASE)):
        names = inputs.names(root)
        script_pattern = r"(?:check_cancellation|checkout_published|prepare_candidate|scan_source)(?:[.-][A-Za-z0-9_-]+)*\.py" if lane == "scheduler" else r"(?:check_cli|checkout_published)(?:[.-][A-Za-z0-9_-]+)*\.py"
        script_hashes = {}
        for name in sorted(name for name in names if re.fullmatch(script_pattern, name)):
            raw = inputs.add(lane + "/scripts/" + name, root / name, root, "retained runner/preparation version")
            script_hashes[name] = digest(raw)
        for name, expected in RUNNERS[lane].items():
            require(script_hashes.get(name) == expected, "Missing or changed reviewed runner version: " + lane + "/" + name)
        manifest_names = sorted(name for name in names if (re.fullmatch(r"hashes(?:[.-][A-Za-z0-9_-]+)*\.json", name) if lane == "scheduler" else re.fullmatch(r"(?:[A-Za-z0-9_.-]*MANIFEST[A-Za-z0-9_.-]*)\.json", name)))
        manifest_raws = {}
        for name in manifest_names:
            raw = inputs.add(lane + "/inputs/" + name, root / name, root)
            manifest_raws[name] = raw
            sha = digest(raw)
            role = "execution manifest" if sha in {FROZEN_MANIFEST, SCHEDULER_MANIFEST} else "final review manifest, not execution input" if sha == REVIEW_MANIFEST else "retained manifest version"
            inputs.files[lane + "/inputs/" + name]["role"] = role
            manifest_roles.append({"lane": lane, "path": lane + "/inputs/" + name, "source_sha256": sha, "role": role})
        if lane == "scheduler":
            require(digest(manifest_raws.get("hashes.json", b"")) == SCHEDULER_MANIFEST, "Scheduler manifest differs")
            manifest = parse_json(manifest_raws["hashes.json"])
            files = manifest["files"]
            expected_paths = {PRODUCT, SCHEDULER_TEST}
            required_patches = {"candidate.patch", "negative-control.patch", "product.patch"}
        else:
            require(all(digest(manifest_raws.get(name, b"")) == FROZEN_MANIFEST for name in ("MANIFEST.json", "execution-MANIFEST.json"))
                    and digest(manifest_raws.get("review-MANIFEST.json", b"")) == REVIEW_MANIFEST, "Frozen/final CLI manifest labels differ")
            manifest = parse_json(manifest_raws["execution-MANIFEST.json"])
            review = parse_json(manifest_raws["review-MANIFEST.json"])
            require(review["changed_files"] == manifest["changed_files"] and review["patch"] == manifest["patch"], "Review changed execution inputs")
            files = manifest["changed_files"]
            expected_paths = {CLI_TEST}
            required_patches = {"candidate.patch"}
        require(manifest["base_commit"] == base and len(files) == len(expected_paths)
                and {item["path"] for item in files} == expected_paths, "Source manifest scope differs")
        base_hashes = {item["path"]: item["base_sha256"] for item in files}
        candidate_hashes = {item["path"]: item["candidate_sha256"] for item in files}
        for item in files:
            path = safe_relative(item["path"])
            raw = inputs.add(lane + "/source/" + path, root / "source" / path, root, "published source bytes", include=False)
            blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            require(digest(raw) == item["candidate_sha256"] and blob == item["candidate_git_blob"], "Current published source differs")
        patch_names = {name for name in names if re.fullmatch(r"(?:candidate|negative-control|product)(?:[.-][A-Za-z0-9_-]+)*\.patch", name)}
        require(required_patches <= patch_names, "Missing retained patch")
        for name in sorted(patch_names):
            raw = inputs.add(lane + "/inputs/" + name, root / name, root, "retained patch version")
            if name in PATCHES[lane]:
                require(digest(raw) == PATCHES[lane][name], "Reviewed patch bytes differ")
            if lane == "cli" and name == "candidate.patch":
                require({"path": name, "bytes": len(raw), "sha256": digest(raw)} == manifest["patch"], "CLI execution patch differs")
        require(inputs.names(root / "evidence") == set(PHASE_COMMANDS[lane]), "Unexpected or missing evidence phase")
        receipts, receipt_bytes = {}, {}
        for phase in PHASE_COMMANDS[lane]:
            raw = inputs.add(lane + "/" + phase + "/receipt.json", root / "evidence" / phase / "receipt.json", root, "original phase receipt")
            receipt = parse_json(raw)
            receipts[phase], receipt_bytes[phase] = receipt, raw
            allowed_runners = {name: sha for name, sha in RUNNERS[lane].items() if name.startswith("checkout_published" if phase == "published-checkout" else "check_cancellation" if lane == "scheduler" else "check_cli")}
            matched = [lane + "/scripts/" + name for name, sha in allowed_runners.items() if sha == receipt.get("runner_sha256")]
            require(matched, "Receipt runner has no included original version")
            admit_phase(lane, phase, receipt, base, identities[lane], base_hashes, candidate_hashes)
            commands.extend(admit_commands(inputs, lane, root, phase, receipt))
            phases[lane + "/" + phase] = {"completed": receipt["completed"], "runner_sha256": receipt["runner_sha256"],
                                               "runner_members": matched, "receipt_source_sha256": digest(raw)}
            if "error" in receipt:
                phases[lane + "/" + phase]["error"] = receipt["error"]
        prior_phase = "control" if lane == "scheduler" else "baseline"
        link = "retained_control_receipt_sha256" if lane == "scheduler" else "retained_baseline_receipt_sha256"
        require(receipts["candidate"].get(link) == digest(receipt_bytes[prior_phase]), "Retained control/baseline receipt link differs")
        if lane == "scheduler":
            require(receipts["candidate"].get("control_rerun") is False, "Unexpected control rerun")
        identities[lane]["source_sha256"] = candidate_hashes

    review_raw = inputs.add("scheduler/source-review.json", ROOT / "source-review.json", ROOT, "bounded literal source scan")
    review = parse_json(review_raw)
    scan_identity = {"head": COMMIT, "tree": TREE, "status": ""}
    require(review.get("schema") == 1 and review.get("runner_sha256") == RUNNERS["scheduler"]["scan_source.py"]
            and review.get("source_before") == scan_identity and review.get("source_after") == scan_identity
            and review.get("product_commands_executed") is False, "Source scan identity/scope differs")
    require(type(review.get("scanned_tracked_go_files")) is int and 0 < review["scanned_tracked_go_files"] <= 50000,
            "Source scan inventory outside bound")
    require(set(review.get("patterns", {})) == {"direct_errors_unwrap", "unwrap_method", "scheduler_parallel"}
            and set(review.get("matches", {})) == set(review["patterns"]), "Source scan patterns differ")
    matched_paths = {row["path"] for rows in review["matches"].values() for row in rows}
    require(matched_paths == set(review.get("matched_file_sha256", {})) and len(matched_paths) <= 128, "Source scan match inventory differs")
    for name in sorted(matched_paths):
        safe_relative(name)
        require(name.endswith(".go"), "Unexpected scan source extension")
        raw = inputs.add("scheduler/source/" + name, ROOT / "source" / name, ROOT, "published source matched by literal scan", include=False)
        require(digest(raw) == review["matched_file_sha256"][name], "Matched source hash differs")
        lines = raw.decode("utf-8").splitlines()
        for key, rows in review["matches"].items():
            for row in rows:
                if row["path"] == name:
                    require(type(row["line"]) is int and 0 < row["line"] <= len(lines)
                            and lines[row["line"] - 1].strip() == row["text"], "Source scan excerpt differs")

    summary = {"schema": 1, "identities": identities, "phases": phases, "manifests": manifest_roles, "commands": commands,
               "raw_command_streams_verified": 2 * len(commands), "all_per_command_receipts_verified_where_runner_emits_them": True,
               "expected_failures_retained": True, "negative_control_rerun": False,
               "qualification_scope": {"scheduler": "injected runner causes plus pre-stopped public ListContext with production runner",
                                       "cli": "live fake ListContext entry followed by parent cancellation; separate configured 25-second budget check"},
               "historical_cli_timeout": "The old fixture returned RECONCILE_TIMEOUT and then failed to observe scheduler ListContext cancellation. The observed timeout and real failures are retained; they do not qualify timer expiry after scheduler entry.",
               "limits": {"actual_in_flight_COM_cancellation": False, "actual_handler_deadline_expiry_after_scheduler_entry_qualified": False,
                          "whole_process_tree_deadline_enforced": False, "native_task_operations": False, "full_test_suites_run": False,
                          "semantic_source_analysis": False, "source_scan_of_CLI_branch": False},
               "source_identity_evidence": "Published checkout receipts bind parent, exact full Git tree and clean state; published test receipts independently bind the same head/tree and source hashes. Packaging verifies changed/matched source files read-only; the archive retains patches, hashes and scan excerpts rather than duplicate whole source files.",
               "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    tokens = {os.environ.get(name, "") for name in ("USERNAME", "USERDOMAIN", "COMPUTERNAME")}
    tokens = sorted((token for token in tokens if len(token) >= 3 and token.lower() not in {"system", "user", "windows", "builtin"}), key=len, reverse=True)
    members, manifest_rows = {}, []

    def member(name, raw, role, generated=False):
        safe_relative(name)
        require(name not in members, "Duplicate public member")
        saved = redact(raw, tokens)
        if name.endswith(".json"):
            parse_json(saved)
        members[name] = saved
        manifest_rows.append({"path": name, "role": role, "source_bytes": len(raw), "source_sha256": digest(raw),
                              "saved_bytes": len(saved), "saved_sha256": digest(saved), "redacted": saved != raw,
                              "generated_in_memory": generated})

    for name, item in inputs.files.items():
        if item["include"]:
            member(name, item["raw"], item["role"])
    member("execution-summary.json", jsonbytes(summary), "generated admission summary", True)
    member("source-identities.json", jsonbytes(identities), "generated published identities", True)
    manifest = {"schema": 1, "redaction": "Work roots, profile paths, local identities and personal SIDs replaced. source_sha256/bytes describe retained originals (or explicitly marked generated pre-redaction records); saved_sha256/bytes describe public bytes. Redacted scripts are audit records, not executable inputs. MANIFEST.json is hashed by archive-metadata.json outside the ZIP, avoiding self-reference.", "files": manifest_rows}
    members["MANIFEST.json"] = jsonbytes(manifest)
    require(len(members) <= MAX_FILES and sum(map(len, members.values())) <= MAX_TOTAL, "Public inventory outside bound")
    inputs.unchanged()
    # Admission is complete before even an in-memory archive is constructed.
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
        for name, raw in sorted(members.items()):
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 20, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o600 << 16
            handle.writestr(entry, raw)
    archive_raw = buffer.getvalue()
    require(len(archive_raw) <= MAX_TOTAL, "Archive outside bound")
    with zipfile.ZipFile(io.BytesIO(archive_raw)) as handle:
        require(handle.testzip() is None and len(handle.namelist()) == len(members)
                and set(handle.namelist()) == set(members), "ZIP CRC or member inventory mismatch")
        for name, expected in members.items():
            require(handle.read(name) == expected, "ZIP saved member differs")
        for row in manifest_rows:
            raw = handle.read(row["path"])
            require(len(raw) == row["saved_bytes"] and digest(raw) == row["saved_sha256"], "ZIP manifest digest mismatch")
    outputs = {"evidence-redacted.zip": archive_raw, "execution-summary.json": members["execution-summary.json"],
               "source-identities.json": members["source-identities.json"], "MANIFEST.json": members["MANIFEST.json"]}
    metadata = {"schema": 1, "archive": "evidence-redacted.zip", "bytes": len(archive_raw), "sha256": digest(archive_raw),
                "entries": len(members), "manifest_files": len(manifest_rows), "raw_command_streams_verified": 2 * len(commands),
                "crc_and_manifest_verified": True, "original_hashes_distinct_from_saved_hashes": True,
                "saved_files": {name: {"bytes": len(raw), "sha256": digest(raw)} for name, raw in outputs.items()},
                "metadata_self_hash_omitted_to_avoid_self_reference": True}
    outputs["archive-metadata.json"] = jsonbytes(metadata)
    inputs.unchanged()
    OUT.mkdir(exist_ok=False)
    for name, raw in outputs.items():
        with (OUT / name).open("xb") as handle:
            handle.write(raw)
        require(bounded_read(OUT / name, OUT, MAX_TOTAL) == raw, "Saved output differs from verified bytes")
    print(json.dumps(metadata), flush=True)


if __name__ == "__main__":
    main()
