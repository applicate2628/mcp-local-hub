"""Fixed, offline Go qualification for the perftools version probe.

Source acquisition reads one pinned public repository commit. No installed tool
is probed by the selected tests: their children are the current test image.
Only a timed-out direct Popen child is terminated through its retained handle;
such a failure retains the workspace and never claims descendant settlement.
"""
import sys
sys.dont_write_bytecode = True

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-perftools-probe-20261122-e21a1792")
SOURCE = ROOT / "source"
PIN = "99dd76ccd453ccd56d9adbcd6f4d4d06ce5cb57c"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GOFMT = GO.with_name("gofmt.exe")
GCC = GO.with_name("gcc.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
TOOLS = {
    GO: "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113",
    GOFMT: "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5",
    GCC: "f6ff9378c1edb591131304518eac6456708d28720284105930d0d687136bcdd3",
    GIT: "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48",
}
PATHS = ("internal/perftools/discovery.go", "internal/perftools/discovery_test.go")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def main():
    phase = sys.argv[1]
    if phase not in {"prepare", "format", "control", "candidate", "build", "vet"}:
        raise ValueError("Unknown fixed phase")
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise ValueError("Unexpected qualification root")
    for path in (ROOT, *ROOT.parents):
        if path.is_symlink() or path.lstat().st_file_attributes & 0x400:
            raise ValueError("Reparse point in qualification root")
    out = ROOT / "evidence" / phase
    out.mkdir(parents=True, exist_ok=False)
    runtime = ROOT / "runtime" / phase
    runtime.mkdir(parents=True, exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "telemetry", "xdg", "empty-hooks"):
        (runtime / name).mkdir()
    (runtime / "telemetry" / "mode").write_bytes(b"off\n")
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_", "GO")) and k.upper() not in {"BASH_ENV", "ENV", "SSH_ASKPASS"}}
    env.update({
        "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
        "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off",
        "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "TEST_TELEMETRY_DIR": str(runtime / "telemetry"),
        "GOCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gocache",
        "GOMODCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache",
        "GOPATH": str(runtime / "gopath"), "GOTMPDIR": str(runtime / "tmp"),
        "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
        "LOCALAPPDATA": str(runtime / "localappdata"), "XDG_CONFIG_HOME": str(runtime / "xdg"),
        "XDG_CACHE_HOME": str(runtime / "xdg"), "XDG_DATA_HOME": str(runtime / "xdg"),
        "CC": str(GCC), "CGO_ENABLED": "1", "GOMAXPROCS": "4", "PYTHONDONTWRITEBYTECODE": "1",
        "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "empty-git-config"),
        "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never",
        "GIT_OPTIONAL_LOCKS": "0",
    })
    system = Path(env["SystemRoot"] if "SystemRoot" in env else env["SYSTEMROOT"])
    env["PATH"] = os.pathsep.join((str(GO.parent), str(GIT.parent), str(system / "System32")))
    for path, expected in TOOLS.items():
        if sha(path) != expected:
            raise ValueError("Tool bytes differ: " + str(path))
    for name in ("GOROOT", "GOCACHE", "GOMODCACHE"):
        if not Path(env[name]).is_dir():
            raise ValueError("Missing existing tool/cache: " + name)
    receipt = {"source": PIN, "phase": phase, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "runner_sha256": sha(Path(__file__)), "commands": [], "completed": False,
               "tools_sha256": {str(p): sha(p) for p in TOOLS},
               "environment": {k: env[k] for k in ("GOROOT", "GOPROXY", "GOSUMDB", "GOTOOLCHAIN", "GOFLAGS", "GOCACHE", "GOMODCACHE", "TEMP", "USERPROFILE", "TEST_TELEMETRY_DIR", "PATH")},
               "whole_process_tree_qualification": False, "installed_tool_probes": False}
    save(out / "started.json", receipt)

    def run(label, executable, args, cwd=SOURCE, expected=0, timeout=180):
        row = {"label": label, "executable": str(executable), "args": list(args), "expected_exit": expected,
               "cwd": str(cwd), "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        receipt["commands"].append(row)
        save(out / (label + ".started.json"), row)
        start = time.monotonic()
        try:
            with (out / (label + ".stdout")).open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
                child = subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
                row["pid"] = child.pid
                save(out / (label + ".launched.json"), row)
                try:
                    row["exit_code"] = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    receipt["retain_workspace_descendants_unresolved"] = True
                    child.terminate()
                    row["exit_code"] = child.wait(timeout=15)
        except BaseException as error:
            row["error"] = type(error).__name__ + ": " + str(error)
            raise
        finally:
            row["seconds"] = time.monotonic() - start
            for stream in ("stdout", "stderr"):
                path = out / (label + "." + stream)
                if path.exists():
                    row[stream + "_sha256"] = sha(path)
            save(out / (label + ".json"), row)
        print(json.dumps({"label": label, "exit": row["exit_code"], "seconds": row["seconds"]}), flush=True)
        if row.get("timed_out") or row["exit_code"] != expected:
            raise RuntimeError("Command did not satisfy exit oracle: " + label)
        return (out / (label + ".stdout")).read_bytes()

    def git(label, args, cwd=SOURCE, timeout=180):
        return run(label, GIT, ["-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(runtime / "empty-hooks"),
            "-c", "credential.helper=", "-c", "core.askPass=", "-c", "core.fsmonitor=false", "-c", "gc.auto=0", *args], cwd, timeout=timeout)

    try:
        if phase == "prepare":
            SOURCE.mkdir(exist_ok=False)
            git("init", ["init", "."])
            git("fetch", ["fetch", "--depth=1", "--no-tags", "https://github.com/applicate2628/mcp-local-hub.git", PIN], timeout=600)
            git("checkout", ["checkout", "--detach", PIN])
        receipt["head_before"] = git("head-before", ["rev-parse", "HEAD"]).decode().strip()
        if receipt["head_before"] != PIN:
            raise ValueError("Wrong source commit")
        receipt["tree"] = git("tree", ["rev-parse", "HEAD^{tree}"]).decode().strip()
        if git("status-before", ["status", "--porcelain=v1", "--untracked-files=all"]).strip():
            raise ValueError("Source is not clean")
        group = "control" if phase == "control" else "candidate"
        overlay_paths = {str(SOURCE / p): str(ROOT / group / p) for p in PATHS}
        if phase not in {"prepare"}:
            receipt["inputs_before"] = {p: sha(ROOT / group / p) for p in PATHS}
            overlay = out / "overlay.json"
            save(overlay, {"Replace": overlay_paths})
        if phase == "format":
            run("gofmt", GOFMT, ["-w", *overlay_paths.values()])
            receipt["formatted"] = {p: sha(ROOT / group / p) for p in PATHS}
        elif phase in {"candidate", "control"}:
            selector = "^TestVersionProbeOutput$" if phase == "control" else "^(TestVersionProbe(Output|Cancellation)|TestProbeMissingPath)$"
            raw = run("tests", GO, ["test", "-overlay", str(overlay), "-race", "-json", "-count=1", "-timeout=90s", "./internal/perftools", "-run", selector], expected=1 if phase == "control" else 0)
            events = [json.loads(line) for line in raw.decode().splitlines()]
            receipt["tests"] = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
            result = receipt["tests"]
            if result["skip"]:
                raise RuntimeError("Unexpected test skip")
            if phase == "candidate":
                if result["fail"] or not {"TestVersionProbeOutput", "TestVersionProbeCancellation", "TestProbeMissingPath", "PACKAGE:mcp-local-hub/internal/perftools"}.issubset(result["pass"]):
                    raise RuntimeError("Missing candidate root PASS or unexpected failure")
            else:
                expected_fail = {"TestVersionProbeOutput/" + x for x in ("stdout-overflow", "stderr-overflow", "combined-overflow")}
                expected_fail.update(("TestVersionProbeOutput", "PACKAGE:mcp-local-hub/internal/perftools"))
                if set(result["fail"]) != expected_fail or raw.count(b"overflow accepted:") != 3:
                    raise RuntimeError("Negative-control failure set differs")
        elif phase in {"build", "vet"}:
            run(phase, GO, [phase, "-overlay", str(overlay), "./..."], timeout=300)
        else:
            receipt["go_version"] = run("go-version", GO, ["version"]).decode().strip()
        if phase not in {"prepare", "format"} and receipt["inputs_before"] != {p: sha(ROOT / group / p) for p in PATHS}:
            raise RuntimeError("Candidate inputs changed while running")
        if git("status-after", ["status", "--porcelain=v1", "--untracked-files=all"]).strip():
            raise RuntimeError("Source changed while running")
        receipt["head_after"] = git("head-after", ["rev-parse", "HEAD"]).decode().strip()
        if receipt["head_after"] != PIN or any(sha(p) != v for p, v in TOOLS.items()):
            raise RuntimeError("Source/tool identity drift")
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / "receipt.json", receipt)
        print(json.dumps({"phase": phase, "completed": receipt["completed"], "error": receipt.get("error"), "tests": receipt.get("tests")}), flush=True)


if __name__ == "__main__":
    main()
