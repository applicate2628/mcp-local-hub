# API helper dispatcher: кандидат и собственное source review

## Содержание

1. [Статус и состав](#статус-и-состав)
2. [Контракт admission и завершения](#контракт-admission-и-завершения)
3. [Первые операции и state binding](#первые-операции-и-state-binding)
4. [Что проверено](#что-проверено)
5. [Что остаётся UNQUALIFIED](#что-остаётся-unqualified)

## Статус и состав

Кандидат расположен в /workspace/scratch/247107d5cc84/mcphub-p0/api-candidate. База 75dbc6406123e22468f168b861d5e0622c9d5769, совместимые исходные входы PR #658 f9966f008aed4d0cfa80d88cc80c12d08e03634f. Три изменённых существующих файла имеют одинаковые base blobs между pinned trees: main_test.go 0aebe605b377efd27cbcf8b57d4c417b151ce298, secrets_test.go 2454c53a777b727d386c7a28ccd886e9d2b0d9d9, intent_audit_caller_oracle_test.go 267856a46c7ad7553b1d0bdf3d9a824c06ec02cd.

Всего пять Go-файлов:

- main_test.go: ранняя классификация и два вида завершения до обычных fixtures.
- main_helper_dispatch_test.go: чистый package-local classifier; нет shared framework или production изменений.
- main_helper_dispatch_validation_test.go: положительные и отрицательные таблицы без файловых записей и child process execution.
- secrets_test.go: parent helper selector стал anchored.
- intent_audit_caller_oracle_test.go: parent helper selector стал anchored.

candidate.patch содержит точную unified diff; source-manifest.json — SHA-256 всех пяти кандидатов и Git blob identities исходных изменённых файлов. Автор этого source-only участка не применял кандидат к репозиторию, не публиковал, не собирал и не исполнял его. Последующие проверки root фиксируются отдельно в helper-publication-summary.md и runtime receipts.

## Контракт admission и завершения

При активной известной helper-роли допускается ровно argv=[exe, -test.run=^ExactTestName$]. Лишние аргументы, split-form, broad/empty selector, unanchored selector, повторные selectors, дополнительные bench/list/count flags и несколько активных ролей отвергаются до общего MkdirTemp, изменения окружения, API state overrides и m.Run.

Диагностика invalid invocation фиксированная; она не печатает пути, секретные значения или env. Ошибка возвращает exit code 3. Изолированные dedicated helper selectors без sentinel тоже отвергаются; обычные parent selectors oracle/fence без marker остаются нормальными тестами.

**Таблица 1. Допущенные роли.**

| Role | Входы | Selector | Завершение |
|---|---|---|---|
| Caller-start-time oracle | MCPHUB_TEST_CALLER_START_TIME_CHILD_STATEDIR: absolute/clean/NUL-free; MCPHUB_TEST_CALLER_START_TIME_CHILD_DELAY_MS: целое ≥0 без overflow milliseconds→time.Duration | ^TestIntentAudit_CallerStartTimeAgainstIndependentOracle$ | Прежний direct fastpath; unexpected return →3 |
| Vault flock | MCPHUB_TEST_HOLD_VAULT_LOCK=1; MCPHUB_TEST_VAULT_PATH, MCPHUB_TEST_READY_PATH, MCPHUB_TEST_RELEASE_PATH: absolute/clean/NUL-free | ^TestVaultFlockHelperProcess$ | must-exit |
| Upgrade fence holder | MCPHUB_TEST_UPGRADE_FENCE_HOLDER=1; MCPHUB_TEST_UPGRADE_FENCE_STATE_DIR: absolute/clean/NUL-free | ^TestUpgradeFenceReacquiresAfterHolderProcessDeath$ | must-exit / parent kill |
| Adopt lease | MCPHUB_A2_ROLE ∈ {A-settle-window, wait-try, wait-try-hold, try, crash}; absolute/clean/NUL-free MCPHUB_A2_STATE; CheckManifestName-valid MCPHUB_A2_ENTRY без reserved .lease suffix | ^TestAdoptLeaseRaceChild$ | crash — must-exit; остальные — normal return |
| Stdio admission | MCPHUB_STDIO_BRIDGE_ADMISSION_HELPER ∈ {ready, legacy, hang}; MCPHUB_STDIO_BRIDGE_ADMISSION_PORT ∈ [1,65535] | ^TestFrozenStdioBridgeAdmissionHelper$ | must-exit / owned parent reap |

Для must-exit возврат m.Run порождает фиксированную диагностику: code 0 заменяется на 3, ненулевой код сохраняется. Это закрывает ложный PASS при отсутствующем compiled test или неожиданном возврате listener/holder. Для returning A2 ролей сохраняется исходный код m.Run, в том числе обычный 0; intentional crash не превращён в нормальный cleanup.

Исходные контракты: [internal/api/secrets_test.go:975](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/secrets_test.go#L975), [internal/api/upgrade_fence_test.go:104](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/upgrade_fence_test.go#L104), [internal/api/adopt_lease_owner_test.go:268](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/adopt_lease_owner_test.go#L268), [internal/api/stdio_bridge_admission_test.go:65](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/stdio_bridge_admission_test.go#L65), [internal/api/intent_audit_caller_oracle_test.go:25](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/intent_audit_caller_oracle_test.go#L25).

## Первые операции и state binding

**Таблица 2. Корень и первая значимая операция каждого helper.**

| Role | Первая операция после admission | Почему перенос выше общего TestMain не теряет state isolation |
|---|---|---|
| Oracle | daemonStateRootOverride=stateDir, затем delay и NewAPI().AppendIntentAudit | Override задан телом до AppendIntentAudit→DaemonStateDir→audit flock/append. Parent stateDir=t.TempDir. |
| API vault | WithVaultLock: MkdirAll(parent vault), flock(vault+.lock); callback WriteFile(ready), Stat(release) | Тело не вызывает OpenVault/Set или API audit hooks. Все три пути переданы parent; vault и barrier files созданы/выбраны parent fixtures. |
| Upgrade holder | AcquireUpgradeFence(stateDir): Lstat(lock), затем ledgered flock; WriteFile(holder-ready) | Только explicit stateDir. Не использует default API state resolver. Parent stateDir=t.TempDir, parent retained Process выполняет Kill/Wait. |
| Adopt lease | daemonStateRootOverride=stateDir, затем tryAcquireAdoptManifestLease(entry) | Override задан до adoptManifestLeasePath→DaemonStateDir и platform namespace owner. Parent isolateStateDir создаёт hardened root и bootstrap namespace. |
| Stdio | net.Listen на 127.0.0.1:port, HTTP Serve | Нет API state resolution; owned provisional process получает неизменённые request.Args и parent-owned lifecycle. |

Источники: [internal/secrets/vault_lock.go:35](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/secrets/vault_lock.go#L35), [internal/api/upgrade_fence.go:63](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/upgrade_fence.go#L63), [internal/api/lock_release_ledger.go:140](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/lock_release_ledger.go#L140), [internal/api/adopted_entries.go:710](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/adopted_entries.go#L710), [internal/api/adopt_lease_owner_posix.go:71](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/adopt_lease_owner_posix.go#L71), [internal/api/adopt_lease_owner_windows.go:105](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/adopt_lease_owner_windows.go#L105), [internal/api/state_paths_test.go:68](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/state_paths_test.go#L68), [internal/api/intent_audit.go:467](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/intent_audit.go#L467), [internal/api/stdio_bridge_admission.go:382](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/stdio_bridge_admission.go#L382).

API vault helper необходимо отличать от CLI concurrent secret helper. API init wires secrets.SetVaultFileReader(ReadStateFileInodeAnchored) и writer→WriteStateFileBytesLockHeld. CLI OpenVault/Set достигает этих API callbacks, strict-mode state reads и возможного fallback audit, поэтому ему нужен parent-bound API root до OpenVault/Set. API vault helper вызывает только WithVaultLock; его callback не входит в этот путь. [internal/api/state_read_inode_anchor.go:16](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/state_read_inode_anchor.go#L16) [internal/api/state_read_inode_anchor.go:91](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/api/state_read_inode_anchor.go#L91)

Никакая из новых API m.Run-helper ролей не открывает supervisor pipe; EnableSupervisorIPCTestPipeIsolation для них не нужен. Это проверенный локальный вывод об этих телах, не общее правило для ранних helpers других пакетов.

## Что проверено

Проведено собственное чтение всей candidate diff: порядок validation-before-mutation; exact argv и selector exclusivity; все фактические call sites; возвращаемые/не возвращаемые роли; direct paths и транзитивный API state; отсутствие изменения production locks/process custody; совместимость обычного TestMain.

Дополнительно выполнены локальные текстовые assertions:

- Tail main_test.go начиная с EnableSupervisorIPCTestPipeIsolation совпадает с base полностью.
- Classifier call предшествует этому tail и общему fixture allocation.
- В secrets_test.go единственное изменение — добавление anchors к helper selector.
- В oracle test единственное изменение — добавление anchors к parent selector.
- Сохранены hashes точных пяти candidate файлов.

В добавленных pure таблицах описаны все допустимые role values и отрицательные случаи: отсутствие/расширение selector, extra test flags, смешанные роли, неправильные marker values, отсутствующие/relative/unclean/NUL paths, malformed/negative/overflow delay, unknown A2 role, traversal/reserved lease entry, unknown stdio mode и неверные ports. Эти Go-тесты **не запускались**. Текстовые assertions не являются компиляцией или test PASS.

## Что остаётся UNQUALIFIED

1. Go compilation, gofmt, vet, focused tests, race/native checks и обязательные полные gates не выполнялись: текущая работа разрешала чтение и candidate edits, не Go/process execution.
2. Absolute/clean path validation не доказывает владение inode/handle, не исключает hardlink/reparse substitution и не вводит новый native checker. WithVaultLock выполняет MkdirAll и flock без предварительного ownership verifier; ready WriteFile также работает по переданному пути. Arbitrary absolute inputs — **UNQUALIFIED**. Положительные будущие вызовы должны использовать конкретные owned parent fixtures; нельзя выдавать helper admission за capability security boundary.
3. Native lifecycle после нового раннего dispatch ещё не исполнялся. Не получено нового доказательства освобождения Windows Jobs/handles, lock settlement, отсутствия child-local roots или работы под race detector.
4. Caller-time oracle остаётся отдельной direct ролью. A2 сохраняет существующее state binding в самом helper; новое дублирующее fixture создание не добавлено.
5. Проверенный scope — четыре добавленные API helper-группы и существующий oracle. Этот кандидат не утверждает полноту всего API/non-helper gate; общий аудит и required fixture qualification остаются за координатором.
