package cli

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gofrs/flock"
	"github.com/spf13/cobra"

	"mcp-local-hub/internal/api/apitest"
	"mcp-local-hub/internal/gui"
)

// ---------------------------------------------------------------
// Scenario 1: Healthy --force (bare flag activates via handshake)
// ---------------------------------------------------------------

func TestForce_HealthyIncumbent_BareFlagActivates(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	srv := healthyIncumbentServer(t, os.Getpid())
	defer srv.Close()
	port := portFromHTTPTestURL(t, srv.URL)
	if err := gui.WritePidport(pidport, os.Getpid(), port); err != nil {
		t.Fatal(err)
	}
	// Pre-acquire the flock so AcquireSingleInstance returns busy and
	// the --force path is exercised.
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	_ = c.Execute()
	out := buf.String()
	if !strings.Contains(out, "activated existing mcphub gui") {
		t.Errorf("expected 'activated existing mcphub gui'; got %q", out)
	}
}

// ---------------------------------------------------------------
// Scenario 2: Healthy --force --kill --yes prints notice and activates
// ---------------------------------------------------------------

func TestForce_HealthyIncumbent_KillFlagPrintsNoticeAndActivates(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	srv := healthyIncumbentServer(t, os.Getpid())
	defer srv.Close()
	port := portFromHTTPTestURL(t, srv.URL)
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d %d\n", os.Getpid(), port)), 0o600); err != nil {
		t.Fatal(err)
	}
	// Pre-acquire the flock so AcquireSingleInstance returns busy and
	// the --force --kill path is exercised rather than normal startup.
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	_ = c.Execute()
	out := buf.String()
	if !strings.Contains(out, "incumbent is healthy") {
		t.Errorf("expected 'incumbent is healthy' notice; got %q", out)
	}
	if !strings.Contains(out, "activating instead of killing") {
		t.Errorf("expected 'activating instead of killing' notice; got %q", out)
	}
}

// ---------------------------------------------------------------
// Scenario 3: Stuck — bare --force is PRINT-ONLY (Option C, bug
// 2026-06-22-explorer-folder-window-orphan-flood). The diagnostic block
// already prints the lock-folder path; auto-opening explorer.exe is the
// highest-frequency trigger of the reveal-window flood, so it is gated
// behind --reveal. Bare --force must NOT spawn the open-folder seam;
// --force --reveal must.
// ---------------------------------------------------------------

// setupStuckForceFixture writes a pidport whose recorded PID is alive
// (this test process) but whose port is closed, then pre-acquires the
// flock so AcquireSingleInstance returns busy and --force routes to the
// diagnostic path. Returns the temp dir for MCPHUB_GUI_TEST_PIDPORT_DIR
// and registers flock cleanup on t.
func setupStuckForceFixture(t *testing.T) string {
	t.Helper()
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	const probablyClosedPort = 1
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d %d\n", os.Getpid(), probablyClosedPort)), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	t.Cleanup(func() { _ = fl.Unlock() })
	return dir
}

func TestForce_StuckIncumbent_BareFlagIsPrintOnly(t *testing.T) {
	dir := setupStuckForceFixture(t)

	// Mock the open-folder seam and assert it is NOT invoked.
	prevSpawn := gui.OpenFolderSpawnForTest()
	defer gui.RestoreOpenFolderSpawn(prevSpawn)
	spawned := false
	gui.SetOpenFolderSpawn(func(name string, args ...string) error {
		spawned = true
		return nil
	})

	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Errorf("expected typed exit code error; got %v", err)
	} else if fe.ExitCode() != 2 {
		t.Errorf("exit code = %d, want 2", fe.ExitCode())
	}
	out := buf.String()
	if !strings.Contains(out, "Cannot acquire") {
		t.Errorf("expected diagnostic block; got %q", out)
	}
	if spawned {
		t.Errorf("bare --force must be print-only; open-folder seam was invoked")
	}
}

func TestForce_StuckIncumbent_RevealFlagOpensFolder(t *testing.T) {
	dir := setupStuckForceFixture(t)

	// Mock the open-folder seam and assert it IS invoked with --reveal.
	prevSpawn := gui.OpenFolderSpawnForTest()
	defer gui.RestoreOpenFolderSpawn(prevSpawn)
	var spawnedName string
	gui.SetOpenFolderSpawn(func(name string, args ...string) error {
		spawnedName = name
		return nil
	})

	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--reveal"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Errorf("expected typed exit code error; got %v", err)
	} else if fe.ExitCode() != 2 {
		t.Errorf("exit code = %d, want 2", fe.ExitCode())
	}
	out := buf.String()
	if !strings.Contains(out, "Cannot acquire") {
		t.Errorf("expected diagnostic block; got %q", out)
	}
	if spawnedName == "" {
		t.Errorf("--force --reveal must open the lock folder; seam was not invoked")
	}
}

// ---------------------------------------------------------------
// Scenario 4: --force --kill happy path (seam-mocked gate)
// ---------------------------------------------------------------

func TestForce_KillHappyPath_SeamMocked(t *testing.T) {
	// This scenario uses a seam to bypass the three-part gate's
	// strict cmdline/image checks (which would reject the test
	// binary as non-mcphub). Real-process proof is in scenario 8.
	prevGate := gui.IdentityGateForTest()
	defer gui.RestoreIdentityGate(prevGate)
	gui.SetIdentityGate(func(v gui.Verdict) (refused bool, reason string) { return false, "" })

	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	// Spawn a child sleep process so we have a real PID we can kill.
	var sleepCmd *exec.Cmd
	if runtime.GOOS == "windows" {
		sleepCmd = exec.Command("powershell", "-NoExit", "-Command", "Start-Sleep -Seconds 60")
	} else {
		sleepCmd = exec.Command("sleep", "60")
	}
	if err := sleepCmd.Start(); err != nil {
		t.Skipf("cannot spawn sleep helper: %v", err)
	}
	defer func() {
		_ = sleepCmd.Process.Kill()
	}()
	pid := sleepCmd.Process.Pid
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 1\n", pid)), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	// Release the flock when the child dies — simulate the OS
	// auto-release so the acquire-poll loop can succeed.
	go func() {
		_, _ = sleepCmd.Process.Wait()
		fl.Unlock()
	}()

	// Use a delayed cancel: ctx stays active long enough for the
	// kill+acquire path to complete (so iter-11's pre-kill ctx
	// check doesn't refuse), then cancels to make startGuiServer
	// exit via <-ctx.Done() rather than blocking until the test
	// timeout. Pre-iter-11 used immediate cancel; that legitimately
	// short-circuits the new cancel-before-kill safety check.
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go func() {
		// 3s gives runForceKill enough time for: cli Probe (~50ms +
		// any retry) + KillRecordedHolder's internal probe (~50ms) +
		// killProcess (instant) + wait-for-exit (~100ms typical) +
		// acquire-poll (~50ms when flock is released). Then cancel
		// triggers startGuiServer's <-ctx.Done() path so the test
		// terminates instead of blocking until the suite timeout.
		time.Sleep(3 * time.Second)
		cancel()
	}()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.ExecuteContext(ctx)
	if err != nil {
		// Acceptable outcomes: context.Canceled (startGuiServer exited
		// cleanly), forceExitError 0 (healthy-early-exit), or exit 3
		// (race-lost). Assert it is NOT exit 7 (refused) or exit 4 (failed).
		var fe interface{ ExitCode() int }
		if errors.As(err, &fe) {
			if fe.ExitCode() == 7 || fe.ExitCode() == 4 {
				t.Errorf("happy path exit code = %d (refused/failed); want 0, 3, or context cancel", fe.ExitCode())
			}
		}
	}
}

// ---------------------------------------------------------------
// Scenario 4b: --force --kill rewrites pidport with current PID + port
// (Codex PR #23 P2 #2)
// ---------------------------------------------------------------

// TestForce_KillRewritesPidportWithCurrentPID pins the Codex PR #23
// P2 #2 fix. After --force --kill takeover succeeds, startGuiServer
// must write a fresh pidport with the current process's PID + the
// actually-bound port — NOT leave the killed incumbent's stale PID +
// port in the file. Before the fix, the conditional
// RewritePidportPort(actualPort) only fired when actualPort !=
// requestedPort and only updated the port field; if the operator
// passed --port=N and the bind succeeded on N, the pidport kept the
// killed incumbent's PID forever.
//
// To exercise the actualPort==requestedPort case (where the bug
// silently elided the rewrite), discover a free ephemeral port by
// briefly binding+closing it, then pass that port via --port=N.
// There's a microsecond-wide race where another process could grab
// the port between close and re-bind; on a quiet test machine this
// is reliable, and a one-off bind failure is a clear test signal
// rather than a silent false-pass.
//
// Approach: simulate the takeover via the IdentityGateForTest seam
// (same pattern as scenario 4), spawn a real sleep child that the
// kill path actually terminates so the flock auto-releases, then run
// the gui command with --port=N and a deadline-bounded context.
// Poll the pidport until it contains os.Getpid() (proof the rewrite
// happened) OR the deadline expires, then assert.
func TestForce_KillRewritesPidportWithCurrentPID(t *testing.T) {
	prevGate := gui.IdentityGateForTest()
	defer gui.RestoreIdentityGate(prevGate)
	gui.SetIdentityGate(func(v gui.Verdict) (refused bool, reason string) { return false, "" })

	// Discover a free ephemeral port: bind on :0, read the port the
	// OS picked, close. The actualPort==requestedPort branch is the
	// one the P2 #2 bug hid in.
	freePort := pickFreePort(t)

	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")

	// Spawn a sleep helper so Probe sees a live PID. The kill path
	// then terminates this child, the OS releases its flock, and our
	// acquire-poll succeeds.
	var sleepCmd *exec.Cmd
	if runtime.GOOS == "windows" {
		sleepCmd = exec.Command("powershell", "-NoExit", "-Command", "Start-Sleep -Seconds 60")
	} else {
		sleepCmd = exec.Command("sleep", "60")
	}
	if err := sleepCmd.Start(); err != nil {
		t.Skipf("cannot spawn sleep helper: %v", err)
	}
	defer func() { _ = sleepCmd.Process.Kill() }()
	stalePid := sleepCmd.Process.Pid
	const stalePort = 1
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d %d\n", stalePid, stalePort)), 0o600); err != nil {
		t.Fatal(err)
	}

	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	// Release the flock when the child dies — simulate the OS
	// auto-release so the acquire-poll loop inside KillRecordedHolder
	// can succeed.
	go func() {
		_, _ = sleepCmd.Process.Wait()
		_ = fl.Unlock()
	}()

	// Run the command with a context that we cancel as soon as the
	// pidport has been rewritten with our PID. 10s overall deadline
	// keeps the test bounded if the rewrite never happens.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", fmt.Sprintf("%d", freePort), "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)

	cmdDone := make(chan error, 1)
	go func() { cmdDone <- c.ExecuteContext(ctx) }()

	// Poll the pidport: succeed as soon as we observe
	// (os.Getpid(), freePort) — that's the proof startGuiServer's
	// WritePidport landed in the actualPort==requestedPort branch.
	// Fail if the takeover happened (cmdDone fires early) without
	// ever rewriting the pidport with our PID.
	deadline := time.Now().Add(8 * time.Second)
	var observedPid, observedPort int
	for time.Now().Before(deadline) {
		pid, port, rerr := gui.ReadPidport(pidport)
		if rerr == nil && pid == os.Getpid() && port == freePort {
			observedPid = pid
			observedPort = port
			break
		}
		select {
		case err := <-cmdDone:
			// Command exited before we observed the rewrite.
			// Re-check the pidport (it may have written and then
			// the test's polling missed the window before
			// shutdown). If still stale, fail with the command
			// error for context.
			pid2, port2, rerr2 := gui.ReadPidport(pidport)
			if rerr2 == nil && pid2 == os.Getpid() && port2 == freePort {
				observedPid = pid2
				observedPort = port2
				break
			}
			t.Fatalf("command exited (err=%v) but pidport still has pid=%d port=%d (stale=%d:%d, want %d:%d)",
				err, pid2, port2, stalePid, stalePort, os.Getpid(), freePort)
		case <-time.After(50 * time.Millisecond):
		}
		if observedPid != 0 {
			break
		}
	}
	// Cancel the context so startGuiServer shuts down cleanly.
	cancel()
	// Drain the command goroutine so the test doesn't leak it.
	select {
	case <-cmdDone:
	case <-time.After(5 * time.Second):
		t.Logf("warning: command did not exit within 5s after cancel")
	}

	if observedPid == 0 {
		t.Fatalf("pidport never rewritten with current PID + freePort=%d; last read: pid=%d port=%d (stale incumbent was pid=%d port=%d)",
			freePort, observedPid, observedPort, stalePid, stalePort)
	}
	if observedPid == stalePid {
		t.Errorf("pidport still contains the killed incumbent's PID %d — WritePidport did not run", stalePid)
	}
	if observedPid != os.Getpid() {
		t.Errorf("pidport pid = %d, want os.Getpid() = %d", observedPid, os.Getpid())
	}
	if observedPort != freePort {
		t.Errorf("pidport port = %d, want freePort = %d", observedPort, freePort)
	}
}

// pickFreePort returns an ephemeral port discovered by binding :0 and
// immediately closing. There's a small race window before the next
// caller binds the same port; tests using this helper accept that on
// a quiet machine (and a port collision is loud, not silent).
func pickFreePort(t *testing.T) int {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("pickFreePort: listen: %v", err)
	}
	port := ln.Addr().(*net.TCPAddr).Port
	if cerr := ln.Close(); cerr != nil {
		t.Fatalf("pickFreePort: close: %v", cerr)
	}
	return port
}

// ---------------------------------------------------------------
// Scenario 5: --force --kill refuses non-mcphub image
// ---------------------------------------------------------------

func TestForce_KillRefusesNonMcphubImage(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	// os.Getppid is the shell (or test runner parent) — image does NOT
	// match mcphub.exe/mcphub.
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 1\n", os.Getppid())), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 7 {
		t.Errorf("exit code = %d, want 7 (KillRefused)", fe.ExitCode())
	}
}

// ---------------------------------------------------------------
// Scenario 6: --force --kill non-interactive without --yes → exit 6
// ---------------------------------------------------------------

func TestForce_KillNonInteractiveWithoutYesExits6(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 1\n", os.Getpid())), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	// `go test` runs without a TTY by default, so --force --kill without
	// --yes triggers the non-interactive guard (exit 6).
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 6 {
		t.Errorf("exit code = %d, want 6 (NonInteractive)", fe.ExitCode())
	}
}

// ---------------------------------------------------------------
// PreRunE flag validation (GitHub Codex bot review on PR #23, P2)
// ---------------------------------------------------------------

// TestForce_FlagValidation_KillRequiresForce, _YesRequiresKill cover
// the cobra PreRunE rejecting destructive-flag misuse before any
// runtime path runs. PreRunE errors surface as plain cobra errors
// (NOT typed forceExitError); cobra's default handling is exit 1
// after printing usage. We assert the error message text and that
// the error is NOT a forceExitError (the runtime exit-code map is
// reserved for runtime outcomes, not operator misuse).
func TestForce_FlagValidation_KillRequiresForce(t *testing.T) {
	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--no-browser", "--no-tray", "--kill"})
	err := c.Execute()
	if err == nil {
		t.Fatal("expected validation error for --kill without --force; got nil")
	}
	if !strings.Contains(err.Error(), "--kill requires --force") {
		t.Errorf("error = %q; want substring '--kill requires --force'", err)
	}
	var fe interface{ ExitCode() int }
	if errors.As(err, &fe) {
		t.Errorf("validation error should NOT be a forceExitError; got %T", err)
	}
}

func TestForce_FlagValidation_YesRequiresKill(t *testing.T) {
	for _, args := range [][]string{
		// --yes alone: covered by --yes && !kill (kill not set → trips)
		{"--no-browser", "--no-tray", "--yes"},
		// --force --yes (forgot --kill): the bug Codex bot flagged on PR #23.
		{"--no-browser", "--no-tray", "--force", "--yes"},
	} {
		c := newGuiCmdRealForTest()
		c.SetArgs(args)
		err := c.Execute()
		if err == nil {
			t.Errorf("args=%v: expected validation error; got nil", args)
			continue
		}
		if !strings.Contains(err.Error(), "--yes requires --force --kill") {
			t.Errorf("args=%v: error = %q; want substring '--yes requires --force --kill'", args, err)
		}
		var fe interface{ ExitCode() int }
		if errors.As(err, &fe) {
			t.Errorf("args=%v: validation error should NOT be a forceExitError; got %T", args, err)
		}
	}
}

// ---------------------------------------------------------------
// Codex iter-6 P2 #1: --force --kill against non-killable verdicts
// must NOT prompt the operator.
// ---------------------------------------------------------------

// TestForce_KillMalformedPidport_NoPromptExits4 pins the iter-6 fix
// (no destructive prompt for non-killable verdicts) AND the iter-8
// P2 #2 exit-code update: kill-mode malformed → exit 4 ("pidport
// unrecoverable" per memo §Exit codes), not exit 2 (which is
// reserved for bare --force diagnostic).
func TestForce_KillMalformedPidport_NoPromptExits4(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	if err := os.WriteFile(pidport, []byte("garbage not a pidport"), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	// --yes ensures we don't depend on TTY check (which fires first
	// at exit 6 in go test). The iter-6 gating is between Probe and
	// the prompt and must fire even in --yes mode.
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 4 {
		t.Errorf("exit code = %d, want 4 (kill-mode pidport unrecoverable per iter-8 P2 #2)", fe.ExitCode())
	}
}

// TestForce_KillOutOfRangePort_ClassifiesMalformed pins the iter-8
// P2 #1 fix: a pidport with a live PID but a corrupt out-of-range
// port (e.g. 70000) must classify as VerdictMalformed and exit 4
// in kill mode — NOT pass through to the LiveUnreachable kill path
// where the otherwise-healthy GUI would be terminated for bad
// metadata alone.
func TestForce_KillOutOfRangePort_ClassifiesMalformed(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	// Use os.Getpid() so PID is alive (we want to assert the port
	// validation kicks in BEFORE the kill path; without the iter-8
	// fix this would have classified as LiveUnreachable and tried
	// to kill the test runner itself via the identity gate).
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 70000\n", os.Getpid())), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 4 {
		t.Errorf("exit code = %d, want 4 (out-of-range port → Malformed in kill mode)", fe.ExitCode())
	}
}

// TestForce_KillDeadPID_NoPromptExits3 pins iter-6 P2 #1 for the
// VerdictDeadPID branch: a pidport pointing at a dead PID skips the
// prompt and returns exit 3 (race-lost / already-recovered).
func TestForce_KillDeadPID_NoPromptExits3(t *testing.T) {
	// Find a likely-dead PID: spawn a short-lived child, capture its
	// PID, wait for it to exit. PID may recycle on long-uptime
	// systems, but the probability over a sub-second test window is
	// negligible.
	var deadCmd *exec.Cmd
	if runtime.GOOS == "windows" {
		deadCmd = exec.Command("cmd", "/C", "exit", "0")
	} else {
		deadCmd = exec.Command("sh", "-c", "exit 0")
	}
	if err := deadCmd.Run(); err != nil {
		t.Skipf("cannot spawn short-lived child: %v", err)
	}
	deadPid := deadCmd.Process.Pid

	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 1\n", deadPid)), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 3 {
		t.Errorf("exit code = %d, want 3 (DeadPID skips kill prompt)", fe.ExitCode())
	}
}

// ---------------------------------------------------------------
// Scenario 7: --force --kill race-lost → exit 3
// ---------------------------------------------------------------

func TestForce_KillRaceLost(t *testing.T) {
	// Inject seam: identity gate passes so the test binary's sleep
	// child PID is accepted as a valid target.  The postKillHook
	// immediately re-acquires the flock from a "competitor" goroutine
	// so the acquire-poll loop inside KillRecordedHolder always sees
	// ErrSingleInstanceBusy and eventually returns VerdictRaceLost.
	prevGate := gui.IdentityGateForTest()
	defer gui.RestoreIdentityGate(prevGate)
	gui.SetIdentityGate(func(v gui.Verdict) (refused bool, reason string) { return false, "" })

	prevHook := gui.PostKillHookForTest()
	defer gui.RestorePostKillHook(prevHook)

	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")

	// Spawn a sleep child so Probe sees a live PID.
	var sleepCmd *exec.Cmd
	if runtime.GOOS == "windows" {
		sleepCmd = exec.Command("powershell", "-NoExit", "-Command", "Start-Sleep -Seconds 60")
	} else {
		sleepCmd = exec.Command("sleep", "60")
	}
	if err := sleepCmd.Start(); err != nil {
		t.Skipf("cannot spawn sleep helper: %v", err)
	}
	defer func() { _ = sleepCmd.Process.Kill() }()

	pid := sleepCmd.Process.Pid
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d 1\n", pid)), 0o600); err != nil {
		t.Fatal(err)
	}

	// Pre-acquire the lock as the "original holder".
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}

	// competitor flock — held by the "race winner" after the kill.
	flCompetitor := flock.New(pidport + ".lock")

	// postKillHook: release the original holder lock (simulating OS
	// auto-release after kill), then immediately re-acquire as the
	// competitor so the acquire-poll loop always sees the flock busy.
	gui.SetPostKillHook(func() {
		fl.Unlock()
		// Spin until we acquire as the competitor.
		for i := 0; i < 20; i++ {
			if ok, _ := flCompetitor.TryLock(); ok {
				return
			}
			time.Sleep(5 * time.Millisecond)
		}
	})

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	// Release competitor flock after the command finishes.
	_ = flCompetitor.Unlock()

	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Errorf("expected typed forceExitError from race-lost path; got %v", err)
		return
	}
	if fe.ExitCode() != 3 {
		t.Errorf("exit code = %d, want 3 (RaceLost)", fe.ExitCode())
	}
}

// ---------------------------------------------------------------
// Scenario 8: Malformed pidport → exit 2
// ---------------------------------------------------------------

func TestForce_MalformedPidport(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	if err := os.WriteFile(pidport, []byte("garbage not a pidport"), 0o600); err != nil {
		t.Fatal(err)
	}
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	c := newGuiCmdRealForTest()
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 2 {
		t.Errorf("exit code = %d, want 2 (Malformed reaches the diagnostic-only path)", fe.ExitCode())
	}
}

// ---------------------------------------------------------------
// Scenario 8b: KillRecordedHolder re-probe sees Healthy after
// cli's first Probe saw LiveUnreachable (Codex PR #23 P2 #2 iter-2).
// ---------------------------------------------------------------

// TestForce_KillRecoveryHealthyBetweenProbes pins the iter-2 fix for
// the runForceKill switch's missing VerdictHealthy arm.
// KillRecordedHolder's internal probe runs AFTER cli's first Probe
// (and AFTER the user confirmation prompt — `--yes` skips the prompt
// but the timing window is real). If the incumbent recovers to
// healthy in between (e.g., Server.Start finally bound during the
// prompt), KillRecordedHolder honors "never kill healthy" and
// returns Verdict{Class: Healthy}. Without the iter-2 arm this
// fell to the default "internal: unrecognized verdict class" arm
// and exited 1.
//
// Setup: a counting ping handler returns {ok:false} on the first
// request and {ok:true,pid:ourPid} on subsequent requests. Pidport
// mtime is backdated past probeStartupWindow so neither cli's first
// Probe nor KillRecordedHolder's internal probe triggers the
// startup-window retry (ensures each call makes exactly one ping
// request and we control the transition timing). cli's first Probe
// → ok:false → LiveUnreachable; KillRecordedHolder's probe →
// ok:true → Healthy → cli's iter-2 switch arm fires →
// "incumbent recovered to healthy" + exit 0.
func TestForce_KillRecoveryHealthyBetweenProbes(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")

	// Counting ping handler: first request fails, subsequent succeed.
	// Activate-window handler returns 204 so TryActivateIncumbent
	// doesn't error.
	var pingCount int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/api/activate-window" {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if r.URL.Path != "/api/ping" {
			http.NotFound(w, r)
			return
		}
		count := atomic.AddInt32(&pingCount, 1)
		w.Header().Set("Content-Type", "application/json")
		if count == 1 {
			// First probe (cli) sees a failed ping.
			_ = json.NewEncoder(w).Encode(map[string]any{"ok": false})
			return
		}
		// Subsequent probes (KillRecordedHolder's internal probe)
		// see a healthy incumbent.
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "pid": os.Getpid()})
	}))
	defer srv.Close()
	port := portFromHTTPTestURL(t, srv.URL)

	if err := gui.WritePidport(pidport, os.Getpid(), port); err != nil {
		t.Fatal(err)
	}
	// Backdate pidport mtime past probeStartupWindow (5s) so the
	// retry loop is disabled and each Probe call makes exactly one
	// ping request. Without this, cli's first Probe might retry-
	// then-succeed and we'd never reach KillRecordedHolder.
	oldMtime := time.Now().Add(-1 * time.Hour)
	if err := os.Chtimes(pidport, oldMtime, oldMtime); err != nil {
		t.Fatalf("Chtimes: %v", err)
	}

	// Pre-acquire flock so AcquireSingleInstance returns busy and
	// the --force --kill path is exercised. The seam below makes
	// the identity gate pass so we reach KillRecordedHolder's
	// internal Probe (which is what populates the Healthy verdict).
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	prevGate := gui.IdentityGateForTest()
	defer gui.RestoreIdentityGate(prevGate)
	gui.SetIdentityGate(func(v gui.Verdict) (refused bool, reason string) { return false, "" })

	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetErr(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()

	// Expect exit code 0. The cli wraps the exit code in
	// forceExitError even on success (so cmd/mcphub/main.go can
	// route via os.Exit(code)), so a forceExitError with
	// ExitCode()==0 is the success signal here, not nil.
	if err == nil {
		// Surprising — cobra returned nil. Acceptable only if the
		// output contains the success notice; fall through to the
		// output check.
	} else {
		var fe interface{ ExitCode() int }
		if !errors.As(err, &fe) {
			t.Errorf("expected typed forceExitError with ExitCode()==0; got %v", err)
		} else if fe.ExitCode() != 0 {
			t.Errorf("exit code = %d, want 0 (Healthy re-verdict success)", fe.ExitCode())
		}
	}
	out := buf.String()
	if !strings.Contains(out, "incumbent recovered to healthy") {
		t.Errorf("expected 'incumbent recovered to healthy' notice; got %q", out)
	}
}

// ---------------------------------------------------------------
// Scenario 9: Real subprocess E2E
// ---------------------------------------------------------------

func TestForce_RealSubprocessE2E(t *testing.T) {
	requireGuiSpawnTests(t)
	// Use the existing ensureMcphubBinary pattern from
	// daemon_reliability_test.go.
	bin := ensureMcphubBinary(t)
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")
	// Phase A: spawn a first mcphub gui that holds the lock.
	first := exec.Command(bin, "gui", "--port", "0", "--no-browser", "--no-tray")
	first.Env = append(os.Environ(), "MCPHUB_GUI_TEST_PIDPORT_DIR="+dir)
	if err := first.Start(); err != nil {
		t.Fatalf("spawn first gui: %v", err)
	}
	// t.Cleanup (NOT defer) so the process is reaped BEFORE t.TempDir
	// removes pidportDir — Wait closes the kernel handle to the
	// pidport.lock file; without it, RemoveAll fails on Windows with
	// "file in use by another process". Sonnet review on PR #23
	// codex P1 (TestForce_RealSubprocessE2E zombie + cleanup race).
	t.Cleanup(func() {
		if first.Process != nil {
			_ = first.Process.Kill()
		}
		_ = first.Wait()
	})

	// Wait for first gui to write pidport.
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if _, err := os.Stat(pidport); err == nil {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	if _, err := os.Stat(pidport); err != nil {
		t.Fatalf("first gui did not write pidport within deadline: %v", err)
	}

	// Phase B: spawn a second mcphub gui --force --kill --yes.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	second := exec.CommandContext(ctx, bin, "gui", "--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes")
	second.Env = append(os.Environ(), "MCPHUB_GUI_TEST_PIDPORT_DIR="+dir)
	out, err := second.CombinedOutput()
	t.Logf("second gui output:\n%s", string(out))
	if err != nil {
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			t.Logf("second gui exit code: %d", ee.ExitCode())
		}
	}
	// Acceptable outcomes from the second invocation:
	//   a) "force-killed ... and acquired lock"  — kill succeeded, E2E
	//      exercised the full KillRecordedHolder + acquire path.
	//   b) "race" / "Race"                       — kill succeeded but a
	//      competitor won the new flock (VerdictRaceLost, exit 3).
	//   c) "incumbent is healthy"                — the first gui was still
	//      healthy when probed; runForceKill hit the Healthy early-exit
	//      guard and correctly refused to kill. This is valid E2E coverage
	//      of the --force --kill entry point and the Healthy guard; the
	//      kill-path hardware proof lives in Scenario 4 (seam-mocked) and
	//      the real binary was invoked end-to-end here.
	outStr := string(out)
	if !strings.Contains(outStr, "force-killed") &&
		!strings.Contains(outStr, "Race") &&
		!strings.Contains(outStr, "race") &&
		!strings.Contains(outStr, "incumbent is healthy") {
		t.Errorf("expected force-killed, race, or healthy-guard output from second gui; got %q", outStr)
	}
}

// ---------------------------------------------------------------
// Codex iter-9 P2 #1: identity gate must run BEFORE the destructive
// confirmation prompt. Without this, the operator could be asked
// "Kill PID X (mcphub gui)?" for a PID that the gate later refuses
// (e.g. recorded PID is `mcphub daemon`, recycled PID, macOS
// unsupported), and the refusal arrives only AFTER consent.
// ---------------------------------------------------------------

// TestForce_KillNonGUIMcphubSubcommand_RefusedBeforePrompt pins the
// iter-9 P2 #1 fix. Setup: pidport refers to a live PID whose
// argv[1] is "daemon" (not "gui"). The image basename matches, so
// the basename gate passes; the argv-subcommand gate refuses.
//
// With --yes (which would normally skip the prompt), the cli's
// pre-prompt CheckIdentityGate must observe the refusal and exit 7
// without ever proceeding to KillRecordedHolder. The diagnostic on
// stderr must mention the argv-gate refusal so the operator knows
// why the kill didn't fire.
//
// Cross-platform: ProcessIDOverride seam injects the synthetic
// identity on every runner (linux/windows/macOS), so the test runs
// uniformly without needing a real `mcphub daemon` subprocess.
func TestForce_KillNonGUIMcphubSubcommand_RefusedBeforePrompt(t *testing.T) {
	dir := apitest.HardenedTempDir(t)
	pidport := filepath.Join(dir, "gui.pidport")

	// pidport must record a live PID so probeOnce reaches
	// LiveUnreachable (and the gate runs). Use os.Getpid() — the
	// processID override below replaces the result regardless.
	const probablyClosedPort = 1
	if err := os.WriteFile(pidport, []byte(fmt.Sprintf("%d %d\n", os.Getpid(), probablyClosedPort)), 0o600); err != nil {
		t.Fatal(err)
	}
	// Backdate mtime so probe doesn't retry the LiveUnreachable
	// classification.
	oldMtime := time.Now().Add(-1 * time.Hour)
	if err := os.Chtimes(pidport, oldMtime, oldMtime); err != nil {
		t.Fatalf("Chtimes: %v", err)
	}

	// Pre-acquire flock so AcquireSingleInstance returns busy and
	// the --force --kill path is exercised.
	fl := flock.New(pidport + ".lock")
	if ok, _ := fl.TryLock(); !ok {
		t.Fatal("could not pre-lock")
	}
	defer fl.Unlock()

	// Inject a synthetic identity that mimics a `mcphub daemon`
	// subprocess: image basename passes (mcphub / mcphub.exe), but
	// argv[1] == "daemon" fails the argv-gate.
	prevProcessID := gui.ProcessIDForTest()
	defer gui.RestoreProcessID(prevProcessID)
	mcphubBinary := mcphubBinaryNameForCliTest()
	gui.SetProcessIDOverride(func(pid int) (gui.ProcessIdentity, error) {
		return gui.ProcessIdentity{
			Alive:     true,
			ImagePath: mcphubBinary,
			Cmdline:   []string{mcphubBinary, "daemon", "wolfram"},
			// Start time well before pidport mtime so the
			// start-time gate would also pass — the argv gate is
			// what we want to trip.
			StartTime: time.Now().Add(-2 * time.Hour),
		}, nil
	})

	// If the gate ran AFTER the prompt instead of before, the
	// destructive prompt would block reading from stdin (no TTY in
	// `go test`). The non-TTY guard fires earlier (exit 6) without
	// --yes, so we use --yes to confirm the gate runs in the
	// post-non-TTY path.

	// Buffer both stdout and stderr because cobra's OutOrStderr()
	// returns the OUT writer when set (which the test helper sets
	// to os.Stdout). Capturing both leaves the assertion robust
	// against minor stream-routing changes in the cli.
	var buf bytes.Buffer
	c := newGuiCmdRealForTest()
	c.SetOut(&buf)
	c.SetErr(&buf)
	c.SetArgs([]string{"--port", "0", "--no-browser", "--no-tray", "--force", "--kill", "--yes"})
	t.Setenv("MCPHUB_GUI_TEST_PIDPORT_DIR", dir)
	err := c.Execute()

	// Exit code 7 — VerdictKillRefused per the exit-code map.
	var fe interface{ ExitCode() int }
	if !errors.As(err, &fe) {
		t.Fatalf("expected typed exit code error; got %v", err)
	}
	if fe.ExitCode() != 7 {
		t.Errorf("exit code = %d, want 7 (kill refused at argv gate before prompt)", fe.ExitCode())
	}

	// Refusal message names the argv gate so the operator can act
	// on the refusal.
	got := buf.String()
	if !strings.Contains(got, "kill refused") {
		t.Errorf("output = %q; want a 'kill refused' line so operator sees the refusal reason", got)
	}
	// Codex iter-10 P2 #2 redacted: format is now `argv subcommand
	// is "<token>", not 'gui'` (only the offending subcommand, not
	// the full argv, to avoid leaking secrets from commands like
	// `mcphub secrets set --value <SECRET>`).
	if !strings.Contains(got, `argv subcommand is "daemon", not 'gui'`) {
		t.Errorf("output = %q; want the argv-gate diagnose so operator knows WHICH gate refused", got)
	}
}

// mcphubBinaryNameForCliTest mirrors the in-package helper from
// internal/gui/single_instance_test.go for cli-side use. Kept
// duplicated rather than exported because matchBasename's per-OS
// rule is an implementation detail of the gui package.
func mcphubBinaryNameForCliTest() string {
	if runtime.GOOS == "windows" {
		return `C:\Program Files\mcphub\mcphub.exe`
	}
	return "/usr/local/bin/mcphub"
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------

// healthyIncumbentServer creates an httptest.Server that mimics a
// healthy mcphub gui incumbent:
//   - GET /api/ping  → 200 {"ok":true,"pid":<pid>}
//   - POST /api/activate-window → 204 NoContent (required by TryActivateIncumbent)
//   - everything else → 200 {"ok":true,"pid":<pid>}
//
// TryActivateIncumbent checks resp2.StatusCode != http.StatusNoContent
// and returns an error on mismatch, so the activate-window endpoint
// must return exactly 204.
func healthyIncumbentServer(t *testing.T, pid int) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/api/activate-window" {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "pid": pid})
	}))
}

// portFromHTTPTestURL extracts the numeric port from an httptest URL
// like "http://127.0.0.1:12345".
func portFromHTTPTestURL(t *testing.T, u string) int {
	t.Helper()
	const prefix = "http://127.0.0.1:"
	if !strings.HasPrefix(u, prefix) {
		t.Fatalf("unexpected httptest URL %q", u)
	}
	rest := u[len(prefix):]
	var port int
	for _, c := range rest {
		if c < '0' || c > '9' {
			break
		}
		port = port*10 + int(c-'0')
	}
	return port
}

// newGuiCmdRealForTest builds a fresh gui cobra command with the real
// RunE wired so --force flows actually execute. The command's I/O is
// wired to the test process's standard streams.
func newGuiCmdRealForTest() *cobra.Command {
	c := newGuiCmdReal()
	c.SetIn(os.Stdin)
	c.SetOut(os.Stdout)
	c.SetErr(os.Stderr)
	return c
}

// ---------------------------------------------------------------
// Codex iter-5 P2: main.go's force-exit branch must only match the
// cli's own sentinel, not arbitrary errors that happen to satisfy
// `interface{ ExitCode() int }` such as *os/exec.ExitError.
// ---------------------------------------------------------------

// TestForceExitError_SatisfiesMcphubMarker pins the positive case:
// the cli's forceExitError implements the combined matcher main.go
// uses, so legitimate --force / --force --kill exit codes still
// route through os.Exit(code).
func TestForceExitError_SatisfiesMcphubMarker(t *testing.T) {
	err := forceExit(7)
	var fe interface {
		ExitCode() int
		IsMcphubForceExit() bool
	}
	if !errors.As(err, &fe) {
		t.Fatalf("forceExit(7) should satisfy the combined matcher; got %v", err)
	}
	if fe.ExitCode() != 7 {
		t.Errorf("ExitCode() = %d, want 7", fe.ExitCode())
	}
	if !fe.IsMcphubForceExit() {
		t.Errorf("IsMcphubForceExit() = false, want true")
	}
}

// TestExecExitError_DoesNotShortCircuitMain pins the iter-5 P2 fix.
// Cobra commands like `mcp manifest edit` and `mcp secrets edit`
// wrap subprocess failures with `fmt.Errorf("...: %w", err)`. The
// child's *exec.ExitError satisfies `interface{ ExitCode() int }`,
// so a bare ExitCode-only matcher in main.go would have routed those
// errors to `os.Exit(<child code>)` and silently dropped the
// contextual "error: ..." diagnostic.
//
// Post-fix: main.go matches the combined
// `interface{ ExitCode() int; IsMcphubForceExit() bool }`, which
// *exec.ExitError does NOT satisfy. This test runs a child process
// that exits non-zero, wraps the error the same way the editor
// callsites in cli/manifest.go and cli/secrets.go do, and asserts
// the combined matcher rejects it.
func TestExecExitError_DoesNotShortCircuitMain(t *testing.T) {
	// Generate a real *exec.ExitError. On Windows, `cmd /C exit 7`
	// reliably yields exit code 7 without needing a POSIX shell.
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.Command("cmd", "/C", "exit 7")
	} else {
		cmd = exec.Command("sh", "-c", "exit 7")
	}
	runErr := cmd.Run()
	if runErr == nil {
		t.Fatal("child process exited 0; expected non-zero exit for *exec.ExitError")
	}
	var ee *exec.ExitError
	if !errors.As(runErr, &ee) {
		t.Fatalf("child error is not *exec.ExitError: %T (%v)", runErr, runErr)
	}
	if ee.ExitCode() != 7 {
		t.Fatalf("child exit code = %d, want 7", ee.ExitCode())
	}

	// Wrap exactly like cli/manifest.go ("editor %s: %w") and
	// cli/secrets.go ("editor: %w") — main.go's matcher must reject
	// the wrapped form.
	wrapped := fmt.Errorf("editor %s: %w", "vim", runErr)

	// Bare ExitCode-only match (the pre-fix matcher) MUST still
	// match — that demonstrates the bug we're guarding against.
	var feBare interface{ ExitCode() int }
	if !errors.As(wrapped, &feBare) {
		t.Fatalf("regression: pre-fix bare ExitCode matcher should still match wrapped *exec.ExitError; got false")
	}
	if feBare.ExitCode() != 7 {
		t.Errorf("bare matcher ExitCode = %d, want 7 (exec.ExitError)", feBare.ExitCode())
	}

	// Post-fix combined matcher — the one main.go now uses — MUST
	// NOT match the wrapped *exec.ExitError, because *exec.ExitError
	// does not implement IsMcphubForceExit().
	var feCombined interface {
		ExitCode() int
		IsMcphubForceExit() bool
	}
	if errors.As(wrapped, &feCombined) {
		t.Errorf(
			"combined matcher must reject wrapped *exec.ExitError; matched ExitCode=%d "+
				"(this would silently suppress the 'error: ...' diagnostic in main.go)",
			feCombined.ExitCode(),
		)
	}
}

// ---------------------------------------------------------------
// Verdict-class → exit-code mapping (review finding: the new
// gui.VerdictIndeterminate class was unhandled by both switches)
// ---------------------------------------------------------------

// TestForceKillVerdictExitMaps_CoverEveryVerdictClass pins BOTH runForceKill
// mappings against the FULL gui.VerdictClass enum, so a class can never again
// be added upstream and silently land in an "internal: unexpected/unrecognized
// verdict class" arm — which is what happened to gui.VerdictIndeterminate: a
// legitimate, expected outcome (an ambiguous platform identity probe) was
// reported to the operator as an mcphub bug with exit 1, and the Verdict's own
// retry guidance was dropped.
//
// The mappings are exercised directly because runForceKill has no probe seam
// (it runs a real gui.Probe against a real pidport), and gui.VerdictIndeterminate
// requires a platform-level OpenProcess/kill(2) failure that a test cannot
// manufacture on demand.
//
// MUTATION: delete the `case gui.VerdictIndeterminate` arm from either helper —
// that helper's Indeterminate subtest fails with "terminal/mapped=false, want a
// non-destructive exit 4".
func TestForceKillVerdictExitMaps_CoverEveryVerdictClass(t *testing.T) {
	// Every class the enum defines today. If a new class is appended upstream
	// without extending this list, the exhaustiveness check at the bottom
	// fails.
	allClasses := []gui.VerdictClass{
		gui.VerdictHealthy,
		gui.VerdictLiveUnreachable,
		gui.VerdictDeadPID,
		gui.VerdictMalformed,
		gui.VerdictKilledRecovered,
		gui.VerdictKillRefused,
		gui.VerdictKillFailed,
		gui.VerdictRaceLost,
		gui.VerdictIndeterminate,
	}

	t.Run("preKill", func(t *testing.T) {
		want := map[gui.VerdictClass]struct {
			code     int
			terminal bool
		}{
			// Non-destructive terminal outcomes: no kill is attempted.
			gui.VerdictMalformed:     {4, true},
			gui.VerdictIndeterminate: {4, true}, // review finding
			gui.VerdictDeadPID:       {3, true},
			// Proceeds to the kill path.
			gui.VerdictLiveUnreachable: {0, false},
			// Handled before the mapping, or genuinely unexpected from Probe.
			gui.VerdictHealthy:         {0, false},
			gui.VerdictKilledRecovered: {0, false},
			gui.VerdictKillRefused:     {0, false},
			gui.VerdictKillFailed:      {0, false},
			gui.VerdictRaceLost:        {0, false},
		}
		for _, class := range allClasses {
			exp, ok := want[class]
			if !ok {
				t.Fatalf("class %q has no expectation — extend this table when a VerdictClass is added", class)
			}
			code, terminal := preKillVerdictExit(class)
			if code != exp.code || terminal != exp.terminal {
				t.Errorf("preKillVerdictExit(%q) = (%d, %v), want (%d, %v)",
					class, code, terminal, exp.code, exp.terminal)
			}
		}
		// gui.VerdictIndeterminate must NEVER authorize the kill path, and must
		// never be reported as an internal error.
		if code, terminal := preKillVerdictExit(gui.VerdictIndeterminate); !terminal || code != 4 {
			t.Fatalf("preKillVerdictExit(Indeterminate) = (%d, %v), want a non-destructive exit 4 — an ambiguous liveness probe must not fall into the 'internal: unexpected verdict class' arm", code, terminal)
		}
	})

	t.Run("postKill", func(t *testing.T) {
		want := map[gui.VerdictClass]struct {
			code   int
			mapped bool
		}{
			gui.VerdictKillRefused:   {7, true},
			gui.VerdictKillFailed:    {4, true},
			gui.VerdictMalformed:     {4, true},
			gui.VerdictIndeterminate: {4, true}, // review finding
			gui.VerdictRaceLost:      {3, true},
			gui.VerdictDeadPID:       {3, true},
			// Handled by runForceKill before this mapping (both exit 0).
			gui.VerdictHealthy:         {0, false},
			gui.VerdictKilledRecovered: {0, false},
			// Never produced by KillRecordedHolder as a failure verdict.
			gui.VerdictLiveUnreachable: {0, false},
		}
		for _, class := range allClasses {
			exp, ok := want[class]
			if !ok {
				t.Fatalf("class %q has no expectation — extend this table when a VerdictClass is added", class)
			}
			code, mapped := postKillVerdictExit(class)
			if code != exp.code || mapped != exp.mapped {
				t.Errorf("postKillVerdictExit(%q) = (%d, %v), want (%d, %v)",
					class, code, mapped, exp.code, exp.mapped)
			}
		}
		if code, mapped := postKillVerdictExit(gui.VerdictIndeterminate); !mapped || code != 4 {
			t.Fatalf("postKillVerdictExit(Indeterminate) = (%d, %v), want a non-destructive exit 4 — a SKIPPED kill must not be reported as an unrecognized class", code, mapped)
		}
	})

	// Exhaustiveness: String() falls through to "VerdictClass(%d)" for any
	// value the enum does not name, so scanning past the last known class
	// proves the list above is complete.
	if next := gui.VerdictIndeterminate + 1; !strings.HasPrefix(next.String(), "VerdictClass(") {
		t.Fatalf("gui.VerdictClass gained a new member %q after VerdictIndeterminate; extend allClasses and both expectation tables", next)
	}
}
