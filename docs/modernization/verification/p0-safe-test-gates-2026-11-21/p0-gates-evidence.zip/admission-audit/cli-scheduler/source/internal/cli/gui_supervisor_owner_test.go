package cli

import (
	"bytes"
	"context"
	"errors"
	"os"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// safeBuffer is a concurrency-safe stderr sink for the respawn-loop
// tests: the loop goroutine writes to it via fmt.Fprintf while the test
// goroutine polls its contents, so a plain *bytes.Buffer would race
// (bytes.Buffer is not safe for concurrent Write/String). Mirrors the
// production stderrSink io.Writer contract.
type safeBuffer struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (b *safeBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.Write(p)
}

func (b *safeBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.String()
}

// newSyntheticOwner builds a supervisorOwner the respawn loop can drive
// WITHOUT a real `mcphub supervise` binary. The loop only ever reads
// owner.exitedCh, owner.stopRequested, and owner.Pid()/Spawned() — never
// proc.Wait() (startExitMonitor owns that in production; here the test
// substitutes the publish by sending on exitedCh directly). spawned is
// caller-controlled so adopted-mode (no-op Stop) owners can stand in as
// harmless orphans.
func newSyntheticOwner(spawned bool) *supervisorOwner {
	return &supervisorOwner{
		spawned:    spawned,
		exitedCh:   make(chan exitInfo, 1),
		stderrBuf:  newBoundedBuffer(256),
		stderrSink: supervisorMonitorStderr,
	}
}

// newTestManager builds a manager with shrunk timing so the sliding
// window is engineered deterministically large per the
// race-window-assertion discipline (no reliance on the natural 5-min
// window). spawnFn is the test-injected respawn seam.
func newTestManager(ctx context.Context, first *supervisorOwner, sink *safeBuffer,
	spawnFn func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error)) *supervisorManager {
	m := newSupervisorManager(ctx, "mcphub-test", false, time.Millisecond, first)
	m.spawnFn, m.stderrSink = spawnFn, sink
	m.backoffBase, m.backoffCap = time.Millisecond, 2*time.Millisecond
	return m
}

// TestBoundedBuffer verifies the supervisor-stderr capture sink keeps
// the FIRST `cap` bytes of writes and drops the rest, including across
// multiple Write calls. PR #212 r5 silent-failure finding 2.
func TestBoundedBuffer(t *testing.T) {
	t.Run("empty", func(t *testing.T) {
		b := newBoundedBuffer(16)
		if got := b.String(); got != "" {
			t.Fatalf("empty buffer String = %q, want \"\"", got)
		}
	})

	t.Run("under_cap_single_write", func(t *testing.T) {
		b := newBoundedBuffer(16)
		n, err := b.Write([]byte("hello"))
		if err != nil || n != 5 {
			t.Fatalf("Write returned n=%d err=%v; want n=5 nil", n, err)
		}
		if got := b.String(); got != "hello" {
			t.Fatalf("String = %q, want %q", got, "hello")
		}
	})

	t.Run("over_cap_drops_tail", func(t *testing.T) {
		b := newBoundedBuffer(8)
		n, err := b.Write([]byte("first chunk overflows"))
		// Returns the input len (caller's contract — pretend we
		// consumed everything to avoid blocking the source process's
		// stdio write loop).
		if err != nil || n != len("first chunk overflows") {
			t.Fatalf("Write n=%d err=%v; want n=%d nil", n, err, len("first chunk overflows"))
		}
		// Buffer holds exactly the first 8 bytes.
		if got := b.String(); got != "first ch" {
			t.Fatalf("String = %q, want %q (first 8 bytes only)", got, "first ch")
		}
	})

	t.Run("multiple_writes_first_bytes_retained", func(t *testing.T) {
		b := newBoundedBuffer(10)
		_, _ = b.Write([]byte("hello "))
		_, _ = b.Write([]byte("world overflow"))
		// First 10 bytes = "hello worl"
		if got := b.String(); got != "hello worl" {
			t.Fatalf("String = %q, want %q", got, "hello worl")
		}
	})
}

// TestProbeSupervisor_ContextCanceled exercises the no-supervisor /
// expected-pre-bind case via a context that has already been canceled.
// DialSupervisorIPCStatus returns a context-cancellation error wrapping
// dial failure; in our environment the wrap classifies as not
// ErrSupervisorIPCUnavailable (since the underlying dial path
// never even fires), so probeSupervisor returns the error verbatim.
// The point of the test is to assert that probeSupervisor's signature
// — (bool, error) — behaves as documented for the error path: bool is
// false, error is non-nil.
func TestProbeSupervisor_ContextCanceled(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel() // cancel BEFORE the call so the probe sees ctx.Err

	ok, err := probeSupervisor(ctx, 100*time.Millisecond)
	if ok {
		t.Fatalf("probeSupervisor on canceled ctx returned ok=true (want false)")
	}
	// We don't assert a specific error wrap chain — only that one is
	// surfaced rather than silently collapsed to (false, nil).
	if err == nil {
		// If err is nil here it means the implementation chose to
		// map ctx.Cancel into the "pre-bind" silent path. That's
		// arguably correct behavior (cancellation = no probe ran),
		// so accept both shapes but flag a notable behavior change
		// if it ever changes again.
		t.Log("probeSupervisor mapped canceled ctx to silent (false, nil) — acceptable per current contract")
	}
}

// TestStartExitMonitor_UnexpectedExitEmitsWarning verifies that when
// the supervisor exits BEFORE Stop() sets stopRequested=true, the
// background monitor writes an actionable warning containing the
// captured stderr tail to the configured sink. PR #212 r6 reliability
// finding 1.
//
// Uses sleep+fork via os.StartProcess to simulate a real process exit
// without needing a heavyweight supervisor binary. The monitor is
// fed a fake stderr buffer pre-populated with a known panic-tail
// string; on exit-without-stopRequested it should appear in the
// emitted warning text.
//
// The test deliberately exercises only the monitor's "unexpected
// exit" path. The "expected shutdown" path (stopRequested=true) is
// covered by the integration smoke that drives Stop() against a real
// supervisor and asserts no warning fires.
func TestStartExitMonitor_UnexpectedExitEmitsWarning(t *testing.T) {
	// Spawn a tiny child that exits with non-zero status quickly.
	// `cmd /c exit 7` (Windows) / `sh -c 'exit 7'` (POSIX) — both
	// produce a *os.Process whose Wait returns a non-nil err since
	// the exit code is non-zero. We don't shell out here; instead
	// we construct an exec.Cmd that always exits 0 and craft the
	// exitErr classification from the captured ExitState below.
	//
	// To keep this test platform-independent without a shell, run
	// the test binary itself with a flag-less invocation that
	// completes quickly. The test process exit produces a
	// non-nil err iff the test binary returned non-zero; for our
	// purposes a successful exit is acceptable — the monitor's
	// "unexpected exit" path fires on ANY exit (err nil or non-nil)
	// where stopRequested=false, because Wait returning at all
	// while stop has not been called means the supervisor died
	// before its shutdown was requested.
	//
	// The simplest deterministic approach: stub the test by
	// constructing a supervisorOwner with a synthetic exit channel
	// and call startExitMonitor on a fake proc, then post a fake
	// exitInfo manually. Since the monitor itself holds proc.Wait,
	// we need a REAL Process. Use the current test process via
	// os.FindProcess — but Wait on someone else's process is
	// disallowed.
	//
	// Pragmatic fallback: directly test the monitor's classification
	// logic by NOT calling startExitMonitor, instead exercising the
	// stderr-writing code path through a helper. Since the warning-
	// emit logic is currently inlined in startExitMonitor, refactor-
	// to-test would broaden scope. Skip the e2e for the monitor in
	// this test and assert the supporting infrastructure (the sink
	// var supervisorMonitorStderr can be swapped, the bounded buffer
	// captures correctly, stopRequested atomic.Bool flips) so a
	// future regression of those pieces is caught.
	t.Skip("end-to-end monitor test deferred: requires real subprocess + Wait wiring; covered by integration smoke")
}

// TestSupervisorMonitorStderr_SwapForTests asserts the package-level
// stderrSink var (supervisorMonitorStderr) can be swapped and the
// captured writes are isolated per swap, so future tests can inject
// a buffer to assert warning content. PR #212 r6 testability seam.
func TestSupervisorMonitorStderr_SwapForTests(t *testing.T) {
	originalSink := supervisorMonitorStderr
	t.Cleanup(func() { supervisorMonitorStderr = originalSink })

	var buf bytes.Buffer
	supervisorMonitorStderr = &buf

	// Write directly to verify the swap is observable. A real
	// monitor would call fmt.Fprintf against this sink.
	_, _ = supervisorMonitorStderr.Write([]byte("test-payload\n"))

	if got := buf.String(); !strings.Contains(got, "test-payload") {
		t.Fatalf("swapped sink did not receive write: got=%q", got)
	}
}

// TestSupervisorOwner_StopAdoptedIsNoOp verifies the adopted-mode
// shutdown semantics: when spawned=false (GUI adopted an externally-
// managed supervisor), Stop() returns nil without sending IPC exit or
// signaling Kill. The original supervisor owner keeps lifecycle
// ownership.
func TestSupervisorOwner_StopAdoptedIsNoOp(t *testing.T) {
	s := &supervisorOwner{spawned: false}
	err := s.Stop(context.Background(), 5000)
	if err != nil {
		t.Fatalf("Stop on adopted owner returned err=%v; want nil", err)
	}
}

// TestSupervisorOwner_StopNilProcReturnsError verifies the defensive
// guard: if spawned=true but proc is nil (programmer error), Stop()
// returns a clear error rather than panic-on-nil-deref.
func TestSupervisorOwner_StopNilProcReturnsError(t *testing.T) {
	s := &supervisorOwner{spawned: true, proc: nil}
	err := s.Stop(context.Background(), 5000)
	if err == nil {
		t.Fatal("Stop on spawned=true + nil proc returned nil; want defensive error")
	}
	if !strings.Contains(err.Error(), "no Process handle") {
		t.Fatalf("Stop error = %v; want message containing 'no Process handle'", err)
	}
}

// TestSupervisorOwner_StopIdempotent asserts that sync.Once gates
// repeated Stop() calls; second call returns the same error as
// the first without re-running the shutdown logic.
func TestSupervisorOwner_StopIdempotent(t *testing.T) {
	s := &supervisorOwner{spawned: false} // adopted mode → fast return path
	err1 := s.Stop(context.Background(), 5000)
	err2 := s.Stop(context.Background(), 5000)
	if !errors.Is(err1, err2) && err1 != err2 {
		t.Fatalf("Stop() not idempotent: first=%v second=%v", err1, err2)
	}
}

// --- supervisorManager bounded-respawn-loop tests (T1–T5) ---
//
// All hermetic: no real `mcphub supervise` binary, no real os.Process.
// The respawn loop consumes owner.exitedCh (a synthetic publish stands
// in for startExitMonitor's production publish) and respawns via the
// injected spawnFn seam. Timing is shrunk to microseconds via
// newTestManager so assertions are deterministic, not race-window flaky.

// TestGuiSupervisorManager_RespawnOnUnexpectedExit (T1): an unexpected
// supervisor-child exit triggers a respawn AND the manager's live
// handle swaps to the newly-spawned owner. Determinism comes from a
// sync channel fired by the fake spawnFn, not a sleep.
func TestGuiSupervisorManager_RespawnOnUnexpectedExit(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	ownerA := newSyntheticOwner(true)
	ownerB := newSyntheticOwner(true)

	spawned := make(chan struct{}, 1)
	var calls atomic.Int32
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		spawned <- struct{}{}
		return ownerB, nil
	}

	var sink safeBuffer
	m := newTestManager(ctx, ownerA, &sink, spawnFn)
	go m.runRespawnLoop(ctx)

	// Fire ownerA's unexpected death (stopRequested unset, not shutting
	// down) → the loop must respawn.
	ownerA.exitedCh <- exitInfo{exitErr: errors.New("supervisor died")}

	select {
	case <-spawned:
	case <-time.After(2 * time.Second):
		t.Fatal("spawnFn was not called within 2s after an unexpected exit")
	}
	if got := calls.Load(); got != 1 {
		t.Fatalf("spawnFn call count = %d; want 1", got)
	}

	// The live handle must have swapped to ownerB. Poll briefly because
	// the install happens just after spawnFn returns.
	deadline := time.Now().Add(time.Second)
	for {
		if m.currentOwner() == ownerB {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("manager.currentOwner() did not swap to ownerB; still %p", m.currentOwner())
		}
		time.Sleep(time.Millisecond)
	}
}

// TestGuiSupervisorManager_RespawnAdoptedOwnerDoesNotHang (BLOCKER fix 1):
// when a respawn ADOPTS an already-bound foreign supervisor,
// ensureSupervisorRunning returns spawned=false with a NIL exitedCh
// (production gui_supervisor_owner.go:93-94). The loop must NOT block
// forever receiving on that nil channel — it installs the adopted owner
// for status and ends the loop.
func TestGuiSupervisorManager_RespawnAdoptedOwnerDoesNotHang(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	ownerA := newSyntheticOwner(true)
	// Mirror the production adopted owner exactly: spawned=false, NO
	// exitedCh (nil). newSyntheticOwner always allocates a channel, so it
	// would NOT reproduce the nil-channel hang — build it inline.
	adopted := &supervisorOwner{spawned: false}
	var calls atomic.Int32
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		return adopted, nil
	}

	var sink safeBuffer
	m := newTestManager(ctx, ownerA, &sink, spawnFn)

	done := make(chan struct{})
	go func() { m.runRespawnLoop(ctx); close(done) }()

	// ownerA dies unexpectedly → loop respawns → adopts the foreign
	// supervisor. Pre-fix the loop then blocked forever on the adopted
	// owner's nil exitedCh; the fix installs + returns.
	ownerA.exitedCh <- exitInfo{exitErr: errors.New("supervisor died")}

	select {
	case <-done:
		// loop returned — no nil-channel hang
	case <-time.After(2 * time.Second):
		t.Fatal("runRespawnLoop hung on an adopted owner's nil exitedCh (BLOCKER not fixed)")
	}
	if got := calls.Load(); got != 1 {
		t.Fatalf("spawnFn calls = %d; want 1", got)
	}
	if m.currentOwner() != adopted {
		t.Fatal("adopted owner was not installed for status visibility")
	}
}

// TestGuiSupervisorManager_CtxCancelUnblocksReceive (BLOCKER fix 2):
// the loop's receive on the current owner's exitedCh must have a
// ctx.Done() escape, so a GUI shutdown that cancels ctx returns the
// loop even when no exit value is ever delivered (the shutdown
// dual-consumer race where Stop() drains the cap-1 channel first leaves
// the loop with no future value). Pre-fix: a bare receive leaks the
// goroutine forever.
func TestGuiSupervisorManager_CtxCancelUnblocksReceive(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())

	ownerA := newSyntheticOwner(true)
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		return newSyntheticOwner(true), nil
	}
	var sink safeBuffer
	m := newTestManager(ctx, ownerA, &sink, spawnFn)

	done := make(chan struct{})
	go func() { m.runRespawnLoop(ctx); close(done) }()

	// Let the loop reach its blocking receive (no exit is ever fired),
	// then cancel ctx. The ctx-escape must unblock + return the loop.
	time.Sleep(20 * time.Millisecond)
	cancel()

	select {
	case <-done:
		// loop returned via the ctx escape — no goroutine leak
	case <-time.After(2 * time.Second):
		t.Fatal("runRespawnLoop did not return on ctx cancel (no ctx escape on the receive → leak)")
	}
}

// TestGuiSupervisorManager_SpawnErrorTripsCapNotPark (MEDIUM fix): a
// PERSISTENT spawn error must RETRY (each attempt is a window slot)
// until the cap trips — NOT park the loop forever after a single
// failure (the pre-fix `continue` fell through to the top receive on
// the already-drained dead owner). Distinct from CapStopsLoop which
// exercises spawn-SUCCESS-then-redie and never the error branch.
func TestGuiSupervisorManager_SpawnErrorTripsCapNotPark(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var calls atomic.Int32
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		return nil, errors.New("spawn failed (port collision)")
	}
	var sink safeBuffer
	ownerA := newSyntheticOwner(true)
	m := newTestManager(ctx, ownerA, &sink, spawnFn)
	m.windowCapCount = 3
	m.windowDur = 10 * time.Second
	go m.runRespawnLoop(ctx)

	// One unexpected death kicks off the respawn; spawnFn always errors.
	ownerA.exitedCh <- exitInfo{exitErr: errors.New("supervisor died")}

	deadline := time.Now().Add(2 * time.Second)
	for {
		if strings.Contains(sink.String(), "respawn cap reached") {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("cap-reached not recorded on persistent spawn error (loop parked after 1 failure?); spawnFn calls=%d, sink=%q", calls.Load(), sink.String())
		}
		time.Sleep(time.Millisecond)
	}
	// The error path must RETRY (multiple spawn attempts), not park after one.
	if got := calls.Load(); got < 2 {
		t.Fatalf("spawnFn called %d times; a persistent error must RETRY (>=2) to trip the cap, not park after 1", got)
	}
}

// TestGuiSupervisorManager_CapStopsLoop (T2): repeated unexpected exits
// exceeding the window cap make the loop STOP respawning (no infinite
// spawn) and record the cap-reached signal in the stderr shadow.
func TestGuiSupervisorManager_CapStopsLoop(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var calls atomic.Int32
	// Each respawned owner immediately re-dies, driving the loop toward
	// the cap. spawnFn returns a fresh synthetic owner whose exitedCh we
	// pre-fire so the next loop iteration observes another unexpected
	// exit without external help.
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		o := newSyntheticOwner(true)
		o.exitedCh <- exitInfo{exitErr: errors.New("re-died")}
		return o, nil
	}

	var sink safeBuffer
	ownerA := newSyntheticOwner(true)
	m := newTestManager(ctx, ownerA, &sink, spawnFn)
	m.windowCapCount = 3           // shrink cap
	m.windowDur = 10 * time.Second // keep the window wide so none prune mid-burst
	go m.runRespawnLoop(ctx)

	// Kick off the cascade.
	ownerA.exitedCh <- exitInfo{exitErr: errors.New("supervisor died")}

	// Wait for the loop to settle: the cap-reached line appears, then no
	// further spawns.
	deadline := time.Now().Add(2 * time.Second)
	for {
		if strings.Contains(sink.String(), "respawn cap reached") {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("cap-reached signal not recorded; spawnFn called %d times, sink=%q", calls.Load(), sink.String())
		}
		time.Sleep(time.Millisecond)
	}

	// Bound the spawn count: cap=3 means the window can hold at most 3
	// entries before the 4th exit trips len(window)>cap and stops. So
	// spawnFn fires at most cap (3) times.
	at := calls.Load()
	if at > 3 {
		t.Fatalf("spawnFn called %d times; cap=3 should bound respawns to <=3", at)
	}

	// The count must PLATEAU — no more spawns after the cap fires.
	time.Sleep(50 * time.Millisecond)
	if after := calls.Load(); after != at {
		t.Fatalf("loop kept respawning after cap: %d -> %d (must plateau)", at, after)
	}
}

// TestGuiSupervisorManager_ShutdownSuppressesRespawn (T3): no respawn
// after Stop()/shutdown — covers all three suppression sources.
func TestGuiSupervisorManager_ShutdownSuppressesRespawn(t *testing.T) {
	// (a) manager.Stop() latched shuttingDown BEFORE the exit fires.
	t.Run("stop_latched_first", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		var calls atomic.Int32
		spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
			calls.Add(1)
			return newSyntheticOwner(true), nil
		}
		ownerA := newSyntheticOwner(false) // adopted → manager.Stop is a no-op
		var sink safeBuffer
		m := newTestManager(ctx, ownerA, &sink, spawnFn)
		go m.runRespawnLoop(ctx)

		if err := m.Stop(context.Background(), 5000); err != nil {
			t.Fatalf("manager.Stop returned %v; want nil for adopted owner", err)
		}
		// Now fire the exit — must be classified EXPECTED (shuttingDown).
		ownerA.exitedCh <- exitInfo{}

		time.Sleep(50 * time.Millisecond)
		if got := calls.Load(); got != 0 {
			t.Fatalf("spawnFn called %d times after manager.Stop; want 0", got)
		}
		if m.currentOwner() != ownerA {
			t.Fatalf("currentOwner changed after shutdown; want unchanged ownerA")
		}
	})

	// (b) ctx cancel suppresses respawn.
	t.Run("ctx_cancel", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())

		var calls atomic.Int32
		spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
			calls.Add(1)
			return newSyntheticOwner(true), nil
		}
		ownerA := newSyntheticOwner(true)
		var sink safeBuffer
		m := newTestManager(ctx, ownerA, &sink, spawnFn)
		go m.runRespawnLoop(ctx)

		cancel()
		ownerA.exitedCh <- exitInfo{}

		time.Sleep(50 * time.Millisecond)
		if got := calls.Load(); got != 0 {
			t.Fatalf("spawnFn called %d times after ctx cancel; want 0", got)
		}
	})

	// (c) per-owner stopRequested suppresses respawn (Stop ran on this
	// specific owner before shuttingDown was observed).
	t.Run("owner_stop_requested", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		var calls atomic.Int32
		spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
			calls.Add(1)
			return newSyntheticOwner(true), nil
		}
		ownerA := newSyntheticOwner(true)
		ownerA.stopRequested.Store(true) // simulate Stop() having run on this owner
		var sink safeBuffer
		m := newTestManager(ctx, ownerA, &sink, spawnFn)
		go m.runRespawnLoop(ctx)

		ownerA.exitedCh <- exitInfo{}

		time.Sleep(50 * time.Millisecond)
		if got := calls.Load(); got != 0 {
			t.Fatalf("spawnFn called %d times for stopRequested owner; want 0", got)
		}
	})

	// (d) install-abort: shutdown latches WHILE spawnFn is mid-flight;
	// the just-spawned orphan must be Stop()'d and NOT installed.
	t.Run("install_abort_stops_orphan", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		release := make(chan struct{})
		entered := make(chan struct{}, 1)
		orphan := newSyntheticOwner(false) // adopted → its Stop is a clean fast no-op
		var once sync.Once
		spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
			once.Do(func() { entered <- struct{}{} })
			<-release // block mid-spawn until the test latches shutdown
			return orphan, nil
		}
		ownerA := newSyntheticOwner(true)
		var sink safeBuffer
		m := newTestManager(ctx, ownerA, &sink, spawnFn)
		go m.runRespawnLoop(ctx)

		// Fire the exit to start a respawn; wait until spawnFn is blocked.
		ownerA.exitedCh <- exitInfo{exitErr: errors.New("died")}
		select {
		case <-entered:
		case <-time.After(2 * time.Second):
			t.Fatal("spawnFn was not entered")
		}

		// Stop now receives the blocked loop, so release only AFTER observing
		// its actual shutdown latch. This remains the adopted-orphan branch.
		stopped := make(chan struct{})
		go func() { _ = m.Stop(context.Background(), 5000); close(stopped) }()
		deadline := time.Now().Add(2 * time.Second)
		for {
			m.mu.Lock()
			latched := m.shuttingDown
			m.mu.Unlock()
			if latched {
				break
			}
			if time.Now().After(deadline) {
				close(release)
				<-stopped
				t.Fatal("manager did not latch shutdown")
			}
			time.Sleep(time.Millisecond)
		}
		close(release)
		select {
		case <-stopped:
		case <-time.After(2 * time.Second):
			t.Fatal("manager did not receive adopted orphan loop completion")
		}
		if m.currentOwner() == orphan {
			t.Fatal("orphan was installed despite shutdown")
		}
	})
}

// TestGuiSupervisorManager_WindowResetNoFalseCap (T4): the sliding
// window prunes aged entries, so a second burst after the window
// elapses gets the full cap budget again rather than tripping a false
// cap from stale entries.
func TestGuiSupervisorManager_WindowResetNoFalseCap(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var calls atomic.Int32
	spawned := make(chan struct{}, 8)
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		spawned <- struct{}{}
		return newSyntheticOwner(true), nil
	}
	ownerA := newSyntheticOwner(true)
	var sink safeBuffer
	m := newTestManager(ctx, ownerA, &sink, spawnFn)
	m.windowCapCount = 2
	m.windowDur = 30 * time.Millisecond // tiny window so entries age out fast
	go m.runRespawnLoop(ctx)

	// First burst: one unexpected exit → one respawn (window=1, under
	// cap=2). currentOwner swaps to a fresh owner.
	ownerA.exitedCh <- exitInfo{exitErr: errors.New("die-1")}
	select {
	case <-spawned:
	case <-time.After(2 * time.Second):
		t.Fatal("first respawn did not occur")
	}

	// Let the window fully prune (sleep > windowDur).
	time.Sleep(60 * time.Millisecond)

	// Second burst on the now-current owner. With the window pruned, this
	// must respawn again (not be suppressed as a false cap).
	cur := m.currentOwner()
	if cur == nil {
		t.Fatal("no current owner after first respawn")
	}
	cur.exitedCh <- exitInfo{exitErr: errors.New("die-2")}
	select {
	case <-spawned:
	case <-time.After(2 * time.Second):
		t.Fatal("second respawn did not occur after window reset (false cap?)")
	}

	if got := calls.Load(); got < 2 {
		t.Fatalf("spawnFn called %d times across two bursts; want >=2", got)
	}
	if strings.Contains(sink.String(), "respawn cap reached") {
		t.Fatalf("cap-reached fired falsely after window reset: sink=%q", sink.String())
	}
}

// TestGuiSupervisorManager_AdoptedNeverArmed (T5): an adopted owner is
// never armed — startGuiServer constructs no manager for it, and even a
// manager built around an adopted owner that receives a synthetic exit
// triggers no respawn (the loop is simply not launched). Here we assert
// the contract directly: when the loop is NOT launched, a fired exit
// produces no spawnFn call, and Stop stays a no-op.
func TestGuiSupervisorManager_AdoptedNeverArmed(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var calls atomic.Int32
	spawnFn := func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		return newSyntheticOwner(true), nil
	}
	adopted := newSyntheticOwner(false)
	if adopted.Spawned() {
		t.Fatal("synthetic adopted owner reports Spawned()=true")
	}
	var sink safeBuffer
	m := newTestManager(ctx, adopted, &sink, spawnFn)
	// Deliberately do NOT launch runRespawnLoop — mirrors startGuiServer's
	// gate (loop launched only when first.Spawned()==true).

	// Fire an exit; with no loop consuming exitedCh, nothing respawns.
	adopted.exitedCh <- exitInfo{exitErr: errors.New("adopted died")}
	time.Sleep(50 * time.Millisecond)
	if got := calls.Load(); got != 0 {
		t.Fatalf("spawnFn called %d times for adopted-mode manager; want 0", got)
	}

	// Stop stays a clean no-op for adopted mode.
	if err := m.Stop(context.Background(), 5000); err != nil {
		t.Fatalf("manager.Stop on adopted owner returned %v; want nil", err)
	}
}

// --- armSupervisorManager REAL-wiring integration tests (W1–W3) ---
//
// The T1–T5 manager tests above drive a manager built by newTestManager,
// which INJECTS spawnFn directly. They never exercise the production
// construct-and-arm path: startGuiServer obtains a seed owner from
// ensureSupervisorRunning, then armSupervisorManager builds the manager
// via newSupervisorManager — which reads the PACKAGE-LEVEL spawnSupervisorFn
// seam — and launches runRespawnLoop. The §5 deploy-verification found the
// live respawn loop did not visibly fire; these tests close that gap by
// driving armSupervisorManager and asserting the loop is genuinely armed
// THROUGH the real wiring (package seam, production newSupervisorManager,
// production runRespawnLoop), only the `mcphub supervise` binary stubbed
// via the spawnSupervisorFn swap.

// TestArmSupervisorManager_SpawnedOwnerArmsRespawnLoopViaPackageSeam (W1):
// a Spawned()==true seed owner makes armSupervisorManager (1) construct a
// manager and (2) launch its respawn loop. A simulated supervisor-child
// death then drives a respawn THROUGH the package-level spawnSupervisorFn
// seam (NOT an injected spawnFn) and the manager's live handle swaps to
// the respawned owner — proving newSupervisorManager wired spawnFn from
// spawnSupervisorFn AND runRespawnLoop was started by armSupervisorManager.
func TestArmSupervisorManager_SpawnedOwnerArmsRespawnLoopViaPackageSeam(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Swap the PACKAGE-LEVEL spawn seam (restored via t.Cleanup) so the
	// respawn fires through the SAME path newSupervisorManager reads —
	// no real `mcphub supervise` binary. This is the load-bearing
	// difference from the newTestManager tests, which inject spawnFn.
	origSpawnFn := spawnSupervisorFn
	t.Cleanup(func() { spawnSupervisorFn = origSpawnFn })

	respawned := newSyntheticOwner(true)
	spawnedCh := make(chan struct{}, 1)
	var calls atomic.Int32
	spawnSupervisorFn = func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		select {
		case spawnedCh <- struct{}{}:
		default:
		}
		return respawned, nil
	}

	// Seed owner is GUI-spawned → armSupervisorManager must construct +
	// arm. Capture the stderr sink swap too so respawn-loop warnings
	// don't leak to the real os.Stderr during the test.
	origSink := supervisorMonitorStderr
	t.Cleanup(func() { supervisorMonitorStderr = origSink })
	var sink safeBuffer
	supervisorMonitorStderr = &sink

	seed := newSyntheticOwner(true)
	manager := armSupervisorManager(ctx, seed, "mcphub-test", false)
	if manager == nil {
		t.Fatal("armSupervisorManager returned nil for a Spawned() owner; want a constructed manager")
	}
	if manager.currentOwner() != seed {
		t.Fatalf("manager.currentOwner() = %p; want the seed owner %p", manager.currentOwner(), seed)
	}
	// The manager MUST have been seeded from the package seam, not an
	// injected one — assert the field identity so a future refactor that
	// forgets to read spawnSupervisorFn is caught.
	if manager.spawnFn == nil {
		t.Fatal("manager.spawnFn is nil; newSupervisorManager did not seed it from spawnSupervisorFn")
	}

	// Fire the seed owner's UNEXPECTED death (stopRequested unset, not
	// shutting down). The armed loop must respawn through the package seam.
	seed.exitedCh <- exitInfo{exitErr: errors.New("supervisor died")}

	// The production newSupervisorManager backoff base is 1s (the real
	// first-attempt backoff). Give a generous 5s window so the genuine
	// production timing is exercised, not a shrunk test cadence.
	select {
	case <-spawnedCh:
	case <-time.After(5 * time.Second):
		t.Fatalf("spawnSupervisorFn was not called within 5s after an unexpected exit; the respawn loop was NOT armed by armSupervisorManager (spawnFn calls=%d)", calls.Load())
	}
	if got := calls.Load(); got != 1 {
		t.Fatalf("spawnSupervisorFn call count = %d; want exactly 1", got)
	}

	// The live handle must swap to the respawned owner — proving the loop
	// installed the package-seam result through the real runRespawnLoop.
	deadline := time.Now().Add(2 * time.Second)
	for {
		if manager.currentOwner() == respawned {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("manager.currentOwner() did not swap to the respawned owner; still %p", manager.currentOwner())
		}
		time.Sleep(time.Millisecond)
	}

	// Clean shutdown so the loop goroutine exits before the test ends.
	// cancel() (deferred at the top) drives the loop's ctx.Done() escape;
	// manager.Stop latches shuttingDown and stops the current owner. We do
	// NOT assert Stop's return value here: the respawned synthetic owner is
	// spawned=true with a nil proc, so its stop() returns the documented
	// "no Process handle recorded" guard error (TestSupervisorOwner_
	// StopNilProcReturnsError). The cleanup intent is loop termination, which
	// the deferred cancel guarantees; Stop is best-effort latch-and-stop.
	_ = manager.Stop(context.Background(), 5000)
}

// Adopted actors remain no-stop/no-respawn; explicit restart still has the
// same GUI lifetime coordinator after initialization has settled.
func TestArmSupervisorManager_AdoptedOwnerHasCoordinatorNoLoop(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	origSpawnFn := spawnSupervisorFn
	t.Cleanup(func() { spawnSupervisorFn = origSpawnFn })
	var calls atomic.Int32
	spawnSupervisorFn = func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		calls.Add(1)
		return newSyntheticOwner(true), nil
	}

	adopted := newSyntheticOwner(false)
	manager := armSupervisorManager(ctx, adopted, "mcphub-test", false)
	if manager == nil || manager.currentOwner() != adopted || !manager.initialized || manager.loopDone != nil {
		t.Fatal("adopted initialization lost coordinator or armed automatic respawn")
	}

	// Fire the adopted owner's exit — with no loop launched, nothing
	// respawns through the seam.
	adopted.exitedCh <- exitInfo{exitErr: errors.New("adopted died")}
	if err := manager.Stop(context.Background(), 5000); err != nil {
		t.Fatalf("adopted Stop: %v", err)
	}
	if got := calls.Load(); got != 0 {
		t.Fatalf("spawnSupervisorFn called %d times for adopted owner; want 0 (no loop armed)", got)
	}
}

func TestArmSupervisorManager_NilOwnerHasCoordinatorNoLoop(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	manager := armSupervisorManager(ctx, nil, "mcphub-test", false)
	if manager == nil || manager.currentOwner() != nil || !manager.initialized || manager.loopDone != nil {
		t.Fatal("absent initialization lost coordinator or armed automatic respawn")
	}
	if err := manager.Stop(context.Background(), 5000); err != nil {
		t.Fatalf("absent Stop: %v", err)
	}
}

// TestSupervisorSetupFaultError_BroadRemediationAndCause pins the EXHAUSTIVE
// enumeration on this helper. ReadSupervisorLockOwner →
// readStateFileInodeAnchored + json.Unmarshal fails on a PRESENT sidecar via
// exactly FIVE non-IsNotExist classes, and the message must name a
// cause-appropriate remediation for each — a single `repair-state-dacl`
// instruction is a dead end for the corrupt-JSON, wrong-owner, and irregular
// cases (that command only re-grants an OWNED, REGULAR file's DACL). The
// destructive remediations (delete / take-ownership) must carry the
// "stop the supervisor first" ordering guard, and the underlying cause must
// stay wrapped so the operator can tell which class applies. The state-dir
// RESOLVE failure has its own dedicated error (supervisorStateDirResolveError)
// and no longer routes through here.
func TestSupervisorSetupFaultError_BroadRemediationAndCause(t *testing.T) {
	cause := errors.New("read supervisor.lock.owner.json: DACL refused for path")
	err := supervisorSetupFaultError(cause)
	if err == nil {
		t.Fatal("supervisorSetupFaultError returned nil")
	}
	msg := err.Error()
	// All FIVE distinct remediation classes must be named.
	for _, want := range []string{
		"repair-state-dacl",               // (a) DACL/mode refusal
		"delete the corrupt sidecar",      // (b) corrupt/malformed JSON
		"take ownership",                  // (c) wrong-owner sidecar
		"symlink/irregular sidecar",       // (d) irregular/symlink sidecar
		"MCPHUB_REQUIRE_SINGLE_USER_HOME", // (e) strict-parent gate
	} {
		if !strings.Contains(msg, want) {
			t.Errorf("message missing remediation hint %q; got: %s", want, msg)
		}
	}
	// The platform-specific take-ownership command must be the correct one.
	if runtime.GOOS == "windows" {
		if !strings.Contains(msg, "/setowner") {
			t.Errorf("Windows message missing the icacls /setowner take-ownership command; got: %s", msg)
		}
		if strings.Contains(msg, "chown") {
			t.Errorf("Windows message leaked the POSIX chown command; got: %s", msg)
		}
	} else {
		if !strings.Contains(msg, "chown") {
			t.Errorf("POSIX message missing the chown take-ownership command; got: %s", msg)
		}
		if strings.Contains(msg, "/setowner") {
			t.Errorf("POSIX message leaked the Windows icacls /setowner command; got: %s", msg)
		}
	}
	// The DESTRUCTIVE remediations (b/c/d) are ORDER-SENSITIVE — deleting or
	// replacing the sidecar while a supervisor still holds supervisor.lock.lock
	// makes the next AcquireSupervisorLock fail closed (supervisor_lock.go:76-83).
	// The message must carry the "stop the supervisor first" guard, and it must
	// appear for MORE than one case (the delete AND the take-ownership paths).
	if strings.Count(msg, "stop any running supervisor") < 2 {
		t.Errorf("message missing the 'stop the supervisor first' ordering guard on the destructive remediations (want it on the delete AND take-ownership paths); got: %s", msg)
	}
	// The final catch-all line must point the operator at the wrapped cause so a
	// future 6th class is still diagnosable.
	if !strings.Contains(msg, "wrapped error below names the exact cause") {
		t.Errorf("message missing the 'wrapped error names the exact cause' catch-all line; got: %s", msg)
	}
	// Cause stays wrapped for diagnosis (errors.Is reaches it).
	if !errors.Is(err, cause) {
		t.Errorf("cause not preserved through wrap; got: %s", msg)
	}
}

// TestSupervisorStateDirResolveError_PlatformRemediationAndCause pins the
// Fable-5 P3 fix AND the round-2 correction: the top-of-function
// api.DaemonStateDir() RESOLVE failure has a DEDICATED error (not routed through
// supervisorSetupFaultError), and every remediation hint must name ONLY inputs
// the resolver actually honors (verified against internal/api/state_paths*.go):
//   - Linux → $XDG_DATA_HOME (fallback ~/.local/share); the resolver does NOT
//     read $XDG_STATE_HOME.
//   - macOS → ~/Library/Application Support (no XDG at all).
//   - Windows → windows.KnownFolderPath(FOLDERID_LocalAppData) DIRECTLY, with NO
//     %LOCALAPPDATA% env fallback, so the message must NOT tell the user to set
//     %LOCALAPPDATA%.
//
// The underlying resolver cause must stay wrapped for diagnosis.
func TestSupervisorStateDirResolveError_PlatformRemediationAndCause(t *testing.T) {
	cause := errors.New("SHGetKnownFolderPath(LocalAppData) unavailable")
	err := supervisorStateDirResolveError(cause)
	if err == nil {
		t.Fatal("supervisorStateDirResolveError returned nil")
	}
	msg := err.Error()

	// Platform-appropriate remediation hint must be present; hints for other
	// platforms and stale/incorrect env-var guidance must NOT appear.
	switch runtime.GOOS {
	case "windows":
		if !strings.Contains(msg, "Known Folder") {
			t.Errorf("Windows message missing the Known-Folder remediation hint; got: %s", msg)
		}
		// The resolver has NO %LOCALAPPDATA% env fallback → the message must not
		// tell the operator to set that env var (round-2 correction).
		if strings.Contains(msg, "set %LOCALAPPDATA%") {
			t.Errorf("Windows message wrongly prescribes setting %%LOCALAPPDATA%% (no env fallback in the resolver); got: %s", msg)
		}
		if strings.Contains(msg, "Library/Application Support") || strings.Contains(msg, "XDG_DATA_HOME") {
			t.Errorf("Windows message leaked a POSIX remediation hint; got: %s", msg)
		}
	case "darwin":
		if !strings.Contains(msg, "Library/Application Support") {
			t.Errorf("macOS message missing the ~/Library/Application Support hint; got: %s", msg)
		}
		if strings.Contains(msg, "XDG_DATA_HOME") || strings.Contains(msg, "Known Folder") {
			t.Errorf("macOS message leaked a wrong-platform hint; got: %s", msg)
		}
	default: // linux
		if !strings.Contains(msg, "XDG_DATA_HOME") {
			t.Errorf("Linux message missing the $XDG_DATA_HOME hint; got: %s", msg)
		}
		if strings.Contains(msg, "Library/Application Support") || strings.Contains(msg, "Known Folder") {
			t.Errorf("Linux message leaked a wrong-platform hint; got: %s", msg)
		}
	}

	// The stale $XDG_STATE_HOME guidance (resolver never reads it) must NEVER
	// appear on ANY platform, and neither must the %LOCALAPPDATA%-set guidance.
	if strings.Contains(msg, "XDG_STATE_HOME") {
		t.Errorf("message references $XDG_STATE_HOME, which the state-dir resolver never reads; got: %s", msg)
	}
	if strings.Contains(msg, "set %LOCALAPPDATA%") {
		t.Errorf("message prescribes setting %%LOCALAPPDATA%%, which the resolver ignores; got: %s", msg)
	}

	// This dedicated error must NOT prescribe the sidecar remediations —
	// they are all dead ends for a state-root RESOLVE failure.
	for _, forbidden := range []string{"repair-state-dacl", "delete the sidecar"} {
		if strings.Contains(msg, forbidden) {
			t.Errorf("state-dir resolve error leaked the sidecar remediation %q (dead end here); got: %s", forbidden, msg)
		}
	}

	// Cause stays wrapped for diagnosis (errors.Is reaches it).
	if !errors.Is(err, cause) {
		t.Errorf("cause not preserved through wrap; got: %s", msg)
	}
}

func TestSupervisorOwnerAlreadyExitedRetainsOutcomeWithoutControl(t *testing.T) {
	for _, originalErr := range []error{nil, errors.New("fixture original native exit failure")} {
		exited := make(chan struct{})
		close(exited)
		owner := &supervisorOwner{
			spawned: true,
			// Synthetic immutable identity only: this branch must use neither a
			// process operation nor any control proof/IPC acquisition.
			proc:       &os.Process{Pid: 4242},
			exitDone:   exited,
			exitResult: exitInfo{exitErr: originalErr},
		}
		if err := owner.Stop(context.Background(), 5000); err != originalErr {
			t.Fatal("known original exit was discarded or retargeted through IPC")
		}
		if err := owner.Stop(context.Background(), 5000); err != originalErr {
			t.Fatal("repeat Stop changed the acquired original outcome")
		}
	}
}

// This invokes the same completion producer as the sole real monitor. The
// error operand is synthetic; native Wait receiving remains a separate gate.
func TestSupervisorOwnerFinalSnapshotReceivesWaitBeforeMonitorNotification(t *testing.T) {
	want := errors.New("original Wait failure")
	owner := &supervisorOwner{exitDone: make(chan struct{})}
	var snapshots []supervisorCreationSnapshot
	owner.attempt = &supervisorCreationAttempt{receive: func(snapshot supervisorCreationSnapshot) error {
		snapshots = append(snapshots, snapshot)
		return nil
	}}
	owner.receiveExitOutcome(want)
	select {
	case <-owner.exitDone:
	default:
		t.Fatal("original completion was not published")
	}
	if len(snapshots) != 0 {
		t.Fatal("original completion invoked its observer")
	}
	// Deterministically enter final creator publication before the monitor's
	// later notification. No observer blocks and no second Wait is introduced.
	owner.attempt.publish(func(snapshot *supervisorCreationSnapshot) { snapshot.Finished = true })
	if len(snapshots) != 1 || !snapshots[0].Finished || !snapshots[0].WaitReceived || !errors.Is(snapshots[0].WaitError, want) || !errors.Is(owner.exitResult.exitErr, want) {
		t.Fatalf("completion lost actual received Wait: %#v", snapshots)
	}
}

// The spawn barrier stands for an admitted creator whose return/settlement has
// not reached the manager yet. No child, IPC connection or native operation is
// created. The wrapper receives the ORIGINAL loop return, not a second loop.
func TestQuit041ManagerStopReceivesInflightLoopAndCause(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	entered, release, loopDone := make(chan struct{}), make(chan struct{}), make(chan struct{})
	var releaseOnce sync.Once
	unblock := func() { releaseOnce.Do(func() { close(release) }) }
	defer unblock()
	orphanCause := errors.New("fixture unpublished owner stop failure")
	orphan := newSyntheticOwner(true)
	orphan.exitDone = make(chan struct{})
	close(orphan.exitDone)
	orphan.stoppedOnce.Do(func() { orphan.stoppedErr = orphanCause })
	seed := newSyntheticOwner(true)
	seed.exitDone = make(chan struct{})
	close(seed.exitDone)
	var sink safeBuffer
	m := newTestManager(ctx, seed, &sink, func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
		close(entered)
		<-release
		return orphan, nil
	})
	go func() { defer close(loopDone); m.runRespawnLoop(ctx) }()
	defer func() {
		unblock()
		cancel()
		select {
		case <-loopDone:
		case <-time.After(2 * time.Second):
			t.Error("original respawn loop was not settled")
		}
	}()
	seed.exitedCh <- exitInfo{exitErr: errors.New("fixture runtime exit")}
	select {
	case <-entered:
	case <-time.After(2 * time.Second):
		t.Fatal("respawn never entered the controlled unpublished window")
	}
	stopped := make(chan error, 1)
	go func() { stopped <- m.Stop(context.Background(), 5000) }()
	waitQuit041ManagerShutdown(t, m)
	// This is a controlled, indefinitely blocked spawn, not a naturally short
	// race window. The timer bounds the observation only; it grants no custody.
	var early bool
	var result error
	select {
	case result = <-stopped:
		early = true
	case <-time.After(50 * time.Millisecond):
	}
	unblock()
	select {
	case <-loopDone:
	case <-time.After(2 * time.Second):
		t.Fatal("original loop did not finish after releasing its spawn")
	}
	if !early {
		select {
		case result = <-stopped:
		case <-time.After(2 * time.Second):
			t.Fatal("manager Stop did not receive settled loop")
		}
	}
	if m.currentOwner() == orphan {
		t.Error("shutdown installed the unpublished owner")
	}
	if early {
		t.Error("manager Stop returned while its admitted spawn and original loop were pending")
	}
	if !errors.Is(result, orphanCause) {
		t.Error("shutdown-wins unpublished Stop cause did not reach manager result")
	}
}

// An injected cached pending Stop result is not native failed-Kill proof. It
// exercises the existing manager's receiving obligation without touching a PID.
func TestQuit041ManagerStopReceivesOriginalExitAfterPendingStop(t *testing.T) {
	pendingCause := errors.New("fixture original Stop returned pending")
	original := newSyntheticOwner(true)
	original.exitDone = make(chan struct{})
	original.stoppedOnce.Do(func() { original.stoppedErr = pendingCause })
	var sink safeBuffer
	m := newTestManager(context.Background(), original, &sink, nil)
	stopped := make(chan error, 1)
	go func() { stopped <- m.Stop(context.Background(), 5000) }()
	waitQuit041ManagerShutdown(t, m)
	var early bool
	var result error
	select {
	case result = <-stopped:
		early = true
	case <-time.After(50 * time.Millisecond):
	}
	close(original.exitDone)
	if !early {
		select {
		case result = <-stopped:
		case <-time.After(2 * time.Second):
			t.Fatal("manager did not receive original exit completion")
		}
	}
	if early {
		t.Error("manager Stop returned while original exitDone was pending")
	}
	if !errors.Is(result, pendingCause) {
		t.Error("original pending Stop cause was lost")
	}
}

func waitQuit041ManagerShutdown(t *testing.T, m *supervisorManager) {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for {
		m.mu.Lock()
		latched := m.shuttingDown
		m.mu.Unlock()
		if latched {
			return
		}
		if time.Now().After(deadline) {
			t.Error("manager did not latch shutdown")
			return
		}
		time.Sleep(time.Millisecond)
	}
}

// Original sender completion is controlled independently from process exit.
// Both are injected retained outcomes, not native failed-Kill/IPC evidence.
func TestQuit041ManagerStopReceivesOriginalSenderAfterExit(t *testing.T) {
	pendingCause := errors.New("fixture original Stop pending")
	senderCause := errors.New("fixture original sender closure failure")
	killCause := errors.New("fixture original Kill failure")
	original := newSyntheticOwner(true)
	original.exitDone = make(chan struct{})
	close(original.exitDone)
	original.ipcDone = make(chan struct{})
	original.killErr = killCause
	original.stoppedOnce.Do(func() { original.stoppedErr = pendingCause })
	var sink safeBuffer
	m := newTestManager(context.Background(), original, &sink, nil)
	stopped := make(chan error, 1)
	go func() { stopped <- m.Stop(context.Background(), 5000) }()
	waitQuit041ManagerShutdown(t, m)
	var early bool
	var result error
	select {
	case result = <-stopped:
		early = true
	case <-time.After(50 * time.Millisecond):
	}
	original.ipcErr = senderCause
	close(original.ipcDone)
	if !early {
		select {
		case result = <-stopped:
		case <-time.After(2 * time.Second):
			t.Fatal("original sender was not received")
		}
	}
	if early {
		t.Error("manager returned after process exit while original sender was pending")
	}
	for _, cause := range []error{pendingCause, senderCause, killCause} {
		if !errors.Is(result, cause) {
			t.Errorf("acquired original cause not retained: %v", cause)
		}
	}
	if !strings.Contains(sink.String(), "supervisor settlement unconfirmed") {
		t.Error("pending sender did not emit the fixed safe custody diagnostic")
	}
}

func TestQuit041ManagerQuiescePreservesAcceptedCurrent(t *testing.T) {
	current := newSyntheticOwner(true)
	current.exitDone = make(chan struct{})
	var sink safeBuffer
	m := newTestManager(context.Background(), current, &sink, nil)
	m.loopDone = make(chan struct{})
	go m.runRespawnLoop(m.ctx)
	if err := m.Quiesce(context.Background()); err != nil {
		t.Fatal(err)
	}
	called := true
	current.stoppedOnce.Do(func() { called = false })
	if called {
		t.Error("self-restart quiescence stopped the accepted current owner")
	}
	select {
	case <-current.exitDone:
		t.Error("quiescence fabricated accepted current exit")
	default:
	}
	select {
	case <-m.loopDone:
	default:
		t.Error("quiescence returned before its original arm completed")
	}
}

// Both errors recover through the original retry/backoff. Only a genuine typed
// startup cleanup failure remains a required final receiving failure.
func TestQuit041ManagerRecoveredStartupCleanupCauseRetained(t *testing.T) {
	for _, cleanup := range []bool{false, true} {
		t.Run(map[bool]string{false: "transient", true: "cleanup"}[cleanup], func(t *testing.T) {
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			cause := errors.New("fixture startup failure")
			attempts := 0
			seed := newSyntheticOwner(true)
			var sink safeBuffer
			m := newTestManager(ctx, seed, &sink, func(context.Context, string, bool, time.Duration, supervisorAttemptReceiver) (*supervisorOwner, error) {
				attempts++
				if attempts == 1 {
					if cleanup {
						return nil, errors.Join(errSupervisorLaunchSettlement, cause)
					}
					return nil, cause
				}
				return newSyntheticOwner(false), nil
			})
			m.loopDone = make(chan struct{})
			go m.runRespawnLoop(m.ctx)
			seed.exitedCh <- exitInfo{exitErr: errors.New("fixture runtime exit")}
			select {
			case <-m.loopDone:
			case <-time.After(2 * time.Second):
				t.Fatal("original recovery loop did not finish")
			}
			result := m.Quiesce(context.Background())
			if attempts != 2 {
				t.Fatalf("original retry changed: %d attempts", attempts)
			}
			if errors.Is(result, cause) != cleanup {
				t.Fatalf("cleanup=%t final result=%v", cleanup, result)
			}
		})
	}
}

