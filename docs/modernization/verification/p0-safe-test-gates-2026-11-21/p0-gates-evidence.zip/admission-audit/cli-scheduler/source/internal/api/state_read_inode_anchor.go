package api

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"mcp-local-hub/internal/secrets"
)

// GUIRestartNonceFileLeaf is the prefix of generation-bound state-file leaves
// authorized for restart-child readiness credentials.
const GUIRestartNonceFileLeaf = "gui-restart-nonce"

func init() {
	secrets.SetVaultFileReader(ReadStateFileInodeAnchored)
	secrets.SetVaultFileWriter(func(path string, data []byte, _ os.FileMode) error {
		return WriteStateFileBytesLockHeld(path, data)
	})
}

// ReadStateFileInodeAnchored exposes the internal state-file anchored reader to
// sibling packages that own trust-sensitive state reads but cannot import
// unexported api helpers. It preserves os.ErrNotExist and all verifier errors so
// each caller can keep its existing missing-file semantics.
func ReadStateFileInodeAnchored(path string) ([]byte, error) {
	return readStateFileInodeAnchored(path)
}

// ReadStateFileInodeAnchoredWithMaxBytes preserves the inode-anchored state
// reader's trust checks while letting an owning caller supply its bounded file
// capacity. It changes only the byte ceiling; strict-mode, access-control,
// audit, and fallback behavior remain identical to ReadStateFileInodeAnchored.
func ReadStateFileInodeAnchoredWithMaxBytes(path string, maxBytes int64) ([]byte, error) {
	if maxBytes <= 0 {
		return nil, fmt.Errorf("state read maximum bytes must be positive")
	}
	return readStateFileInodeAnchoredWithOptions(path, operatorRequiresSingleUserHome, maxBytes, true, false, LogHubMcpEvent, stateReadDefaultParentFallbacksObserved)
}

// ConsumeStateSecretFileInodeAnchored opens an owner-only secret state file,
// unlinks the verified entry while retaining the opened file identity, and
// returns its bytes. The caller owns the returned buffer and must zero it when
// finished. Verification and unlink are performed by the platform-specific
// inode-anchored reader so no post-read path re-walk can leave the credential
// at its original entry.
func ConsumeStateSecretFileInodeAnchored(path string, expectedBytes int64) ([]byte, error) {
	if expectedBytes <= 0 {
		return nil, fmt.Errorf("consume state secret %s: expected size must be positive", path)
	}
	value, err := readStateFileInodeAnchoredWithOptions(
		path,
		func() bool { return true },
		expectedBytes,
		false,
		true,
		LogHubMcpEvent,
		nil,
	)
	if err != nil {
		return nil, err
	}
	if int64(len(value)) != expectedBytes {
		actual := len(value)
		zeroStateSecretBytes(value)
		return nil, fmt.Errorf("consume state secret %s: size = %d, want %d bytes", path, actual, expectedBytes)
	}
	return value, nil
}

// ReadStateFileInodeAnchoredWithAuditSink is a per-call variant of
// ReadStateFileInodeAnchored that redirects the relax-fallback diagnostic
// event (readStateFileInodeAnchoredWithOptions' "unhardened-parent/file-
// fallback" warn events) to sink instead of the process-default
// LogHubMcpEvent. A nil sink is exactly equivalent to
// ReadStateFileInodeAnchored — this is a strictly additive entry point; no
// existing caller's behavior changes.
//
// Unlike a package-level override, this composes safely with concurrent or
// parallel callers in the same process (each call carries its own sink),
// which matters because this same process (e.g. a test binary, or the GUI
// in-process) may have OTHER callers that expect the LogHubMcpEvent default.
//
// finding 1 (work-items/bugs/2026-07-26-route-daemon-state-read-unhardened-
// parent-fallback-writes-hub-mcp-log.md): the read-only `mcphub route` front
// daemon passes RouteReadOnlyStderrSink here (via Registry.SetAuditSink and
// LSPWorkspaceRootTrustedWithAuditSink) so its registry and trusted-root
// reads never reach the GUI-owned shared hub-mcp.log even when the parent-
// DACL/mode gate hits its default-relax fallback.
func ReadStateFileInodeAnchoredWithAuditSink(path string, sink func(level, event string, fields map[string]any) error) ([]byte, error) {
	if sink == nil {
		return readStateFileInodeAnchoredWithOptions(path, operatorRequiresSingleUserHome, stateFileReadCapBytes(path), true, false, LogHubMcpEvent, stateReadDefaultParentFallbacksObserved)
	}
	return readStateFileInodeAnchoredWithOptions(path, operatorRequiresSingleUserHome, stateFileReadCapBytes(path), true, false, sink, nil)
}

// ReadStateFileInodeAnchoredEnvStrictOnly is the bootstrap variant for recovery
// paths that must not consult persisted supervisor-intent strict_mode while
// reading the state needed to repair that same persisted posture. It still
// honors MCPHUB_REQUIRE_SINGLE_USER_HOME and keeps the inode/symlink checks.
func ReadStateFileInodeAnchoredEnvStrictOnly(path string) ([]byte, error) {
	return readStateFileInodeAnchoredEnvStrictOnly(path)
}

func readStateFileInodeAnchoredEnvStrictOnly(path string) ([]byte, error) {
	return readStateFileInodeAnchoredWithStrictPolicy(path, operatorRequiresSingleUserHomeEnvOnly)
}

func readStateFileInodeAnchoredEnvStrictOnlyNoAudit(path string) ([]byte, error) {
	return readStateFileInodeAnchoredWithStrictPolicyNoAudit(path, operatorRequiresSingleUserHomeEnvOnly)
}

func isSecretBearingStateFilePath(path string) bool {
	base := strings.ToLower(filepath.Base(path))
	switch base {
	case hubMcpTokensFileLeaf,
		hubMcpEndpointFileLeaf,
		hubMcpControlTokenFileLeaf,
		"hub-mcp-control.tok",
		GUIRestartNonceFileLeaf,
		"secrets.age",
		".age-key":
		return true
	}
	if strings.HasPrefix(base, GUIRestartNonceFileLeaf+"-") {
		return true
	}
	// Adopt pre-adopt provenance snapshots (<state-dir>/adopt-provenance/<manifest>/
	// <client>.snapshot) pin the client's WHOLE pre-adopt config, which may embed
	// literal secret env values (adopted_entries.go writeAdoptClientSnapshot). Treat
	// them as secret-bearing so a read-broadened snapshot hard-fails like secrets.age
	// instead of warn-and-proceeding (bug 2026-07-11 P2-2) — the compensating control
	// for the snapshots the classifier fix deliberately retains longer.
	if strings.HasSuffix(base, adoptSnapshotFileSuffix) {
		return true
	}
	return strings.Contains(base, "token") ||
		strings.Contains(base, "secret") ||
		strings.Contains(base, "credential") ||
		strings.Contains(base, "vault")
}

func zeroStateSecretBytes(value []byte) {
	for i := range value {
		value[i] = 0
	}
}

func operatorRequiresSingleUserHomeEnvOnly() bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(RequireSingleUserHomeEnv))) {
	case "1", "true":
		return true
	default:
		return false
	}
}
