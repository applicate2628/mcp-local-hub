package daemon

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"mcp-local-hub/internal/mcpcompat/readinesswire"
)

type sessionContractHTTPResult struct {
	status int
	header http.Header
	body   []byte
}

func TestStdioHostInitializeChildExitWritesTypedFailureWithoutSession(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	h, err := NewStdioHost(HostConfig{
		Command: daemonTestPython(t),
		Args: []string{"-u", "-c", `
import sys
sys.stdin.readline()
sys.stderr.write("ERR_NEVER_ON_WIRE\\n")
sys.stderr.flush()
raise SystemExit(23)
`},
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := h.Start(ctx); err != nil {
		t.Fatal(err)
	}
	defer h.Stop()
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	initBody := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"child-exit-test","version":"1"}}}`
	result := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	if result.status != http.StatusBadGateway {
		t.Fatalf("initialize status=%d want=502 body=%s", result.status, result.body)
	}
	if result.header.Get("Content-Type") != readinesswire.MediaTypeV1 {
		t.Fatalf("initialize content type=%q want=%q body=%s", result.header.Get("Content-Type"), readinesswire.MediaTypeV1, result.body)
	}
	failure := readinesswire.DecodeFailureResponse(result.status, result.header.Get("Content-Type"), strings.NewReader(string(result.body)))
	if failure.FailureID != readinesswire.FailureReadinessChildExited || failure.Stage != readinesswire.StageInitialize || failure.HTTPStatus != http.StatusBadGateway || !failure.Retryable {
		t.Fatalf("initialize failure=%#v", failure)
	}
	if result.header.Get("Mcp-Session-Id") != "" {
		t.Fatalf("failed initialize minted session %q", result.header.Get("Mcp-Session-Id"))
	}
	h.sessionMu.Lock()
	sessionCount := len(h.sessions)
	h.sessionMu.Unlock()
	if sessionCount != 0 {
		t.Fatalf("failed initialize session count=%d want=0", sessionCount)
	}
	if strings.Contains(string(result.body), "ERR_NEVER_ON_WIRE") {
		t.Fatalf("typed failure leaked child stderr: %s", result.body)
	}
}

func sessionContractRequest(
	t *testing.T,
	client *http.Client,
	method string,
	url string,
	body string,
	sessionID string,
	protocolVersion string,
) sessionContractHTTPResult {
	t.Helper()
	var reader io.Reader
	if body != "" {
		reader = strings.NewReader(body)
	}
	req, err := http.NewRequest(method, url+"/mcp", reader)
	if err != nil {
		t.Fatal(err)
	}
	if body != "" {
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Accept", "application/json, text/event-stream")
	}
	if sessionID != "" {
		req.Header.Set("Mcp-Session-Id", sessionID)
	}
	if protocolVersion != "" {
		req.Header.Set("MCP-Protocol-Version", protocolVersion)
	}
	resp, err := client.Do(req)
	if err != nil {
		t.Fatalf("%s /mcp: %v", method, err)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read %s response: %v", method, err)
	}
	return sessionContractHTTPResult{status: resp.StatusCode, header: resp.Header.Clone(), body: raw}
}

func TestStdioHostHTTPProtocolAndSessionContractR1(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	h, err := NewStdioHost(HostConfig{
		Command: daemonTestPython(t),
		Args: []string{"-u", "-c", `
import json, sys
seen = 0
for line in sys.stdin:
    msg = json.loads(line)
    seen += 1
    if msg.get("method") == "initialize":
        result = {"protocolVersion":"2025-11-25", "capabilities":{}, "seen":seen}
    else:
        result = {"seen":seen}
    sys.stdout.write(json.dumps({"jsonrpc":"2.0", "id":msg.get("id"), "result":result}) + "\n")
    sys.stdout.flush()
`},
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := h.Start(ctx); err != nil {
		t.Fatal(err)
	}
	defer h.Stop()
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	initBody := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"r1-test","version":"1"}}}`
	invalidInitialize := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "qa-invalid-version")
	if invalidInitialize.status != http.StatusBadRequest {
		t.Fatalf("initialize with invalid protocol header status=%d want=400 body=%s", invalidInitialize.status, invalidInitialize.body)
	}
	first := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	second := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	if first.status != http.StatusOK || second.status != http.StatusOK {
		t.Fatalf("initialize statuses = %d, %d; want 200, 200", first.status, second.status)
	}
	sid1 := first.header.Get("Mcp-Session-Id")
	sid2 := second.header.Get("Mcp-Session-Id")
	if sid1 == "" || sid2 == "" || sid1 == sid2 {
		t.Fatalf("initialize session ids must be nonempty and distinct: first=%q second=%q", sid1, sid2)
	}

	callBody := `{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}`
	for _, tc := range []struct {
		name    string
		sid     string
		version string
		want    int
	}{
		{name: "missing session", version: "2025-11-25", want: http.StatusBadRequest},
		{name: "unknown session", sid: "qa-invalid-session", version: "2025-11-25", want: http.StatusNotFound},
		{name: "unsupported version", sid: sid1, version: "qa-invalid-version", want: http.StatusBadRequest},
		{name: "session version mismatch", sid: sid1, version: "2025-03-26", want: http.StatusBadRequest},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, callBody, tc.sid, tc.version)
			if got.status != tc.want {
				t.Fatalf("status=%d want=%d body=%s", got.status, tc.want, got.body)
			}
		})
	}

	deleted := sessionContractRequest(t, ts.Client(), http.MethodDelete, ts.URL, "", sid1, "2025-11-25")
	if deleted.status != http.StatusNoContent {
		t.Fatalf("DELETE status=%d want=204 body=%s", deleted.status, deleted.body)
	}
	afterDelete := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, callBody, sid1, "2025-11-25")
	if afterDelete.status != http.StatusNotFound {
		t.Fatalf("deleted session status=%d want=404 body=%s", afterDelete.status, afterDelete.body)
	}

	valid := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, callBody, sid2, "2025-11-25")
	if valid.status != http.StatusOK {
		t.Fatalf("second session status=%d want=200 body=%s", valid.status, valid.body)
	}
	var envelope struct {
		Result struct {
			Seen int `json:"seen"`
		} `json:"result"`
	}
	if err := json.Unmarshal(valid.body, &envelope); err != nil {
		t.Fatalf("decode valid response: %v body=%s", err, valid.body)
	}
	if envelope.Result.Seen != 2 {
		t.Fatalf("subprocess saw %d messages; want 2 (one initialize plus one valid call)", envelope.Result.Seen)
	}
}

func TestStdioHostInvalidInitializeResponseDoesNotPoisonCache(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	h, err := NewStdioHost(HostConfig{
		Command: daemonTestPython(t),
		Args: []string{"-u", "-c", `
import json, sys
seen = 0
for line in sys.stdin:
    msg = json.loads(line)
    seen += 1
    version = "2024-11-05" if seen == 1 else "2025-03-26"
    result = {"protocolVersion":version, "capabilities":{}, "seen":seen}
    sys.stdout.write(json.dumps({"jsonrpc":"2.0", "id":msg.get("id"), "result":result}) + "\n")
    sys.stdout.flush()
`},
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := h.Start(ctx); err != nil {
		t.Fatal(err)
	}
	defer h.Stop()
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	initBody := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"cache-test","version":"1"}}}`
	first := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	if first.status != http.StatusBadGateway || first.header.Get("Mcp-Session-Id") != "" {
		t.Fatalf("invalid initialize response status=%d session=%q, want 502 and no session; body=%s", first.status, first.header.Get("Mcp-Session-Id"), first.body)
	}
	if first.header.Get("Content-Type") != readinesswire.MediaTypeV1 {
		t.Fatalf("legacy protocol failure content type=%q, want %q", first.header.Get("Content-Type"), readinesswire.MediaTypeV1)
	}
	failure := readinesswire.DecodeFailureResponse(first.status, first.header.Get("Content-Type"), strings.NewReader(string(first.body)))
	if failure.FailureID != readinesswire.FailureBackingProtocolUnsupported || failure.Stage != readinesswire.StageInitialize || failure.RequestedProtocol != "2025-03-26" || failure.NegotiatedProtocol != "2024-11-05" || failure.SupportedFloor != "2025-03-26" {
		t.Fatalf("legacy protocol failure = %#v", failure)
	}

	second := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	if second.status != http.StatusOK || second.header.Get("Mcp-Session-Id") == "" {
		t.Fatalf("valid retry status=%d session=%q, want 200 and a session; body=%s", second.status, second.header.Get("Mcp-Session-Id"), second.body)
	}
	third := sessionContractRequest(t, ts.Client(), http.MethodPost, ts.URL, initBody, "", "")
	var response struct {
		Result struct {
			Seen int `json:"seen"`
		} `json:"result"`
	}
	if err := json.Unmarshal(third.body, &response); err != nil {
		t.Fatal(err)
	}
	if third.status != http.StatusOK || response.Result.Seen != 2 {
		t.Fatalf("cached retry status=%d seen=%d, want 200 and seen=2; body=%s", third.status, response.Result.Seen, third.body)
	}
}

func TestStdioHostSessionRegistryEvictsOldestAtBoundR1(t *testing.T) {
	h, err := NewStdioHost(HostConfig{Command: echoSubprocCommand(t), Args: echoSubprocArgs()})
	if err != nil {
		t.Fatal(err)
	}
	ids := make([]string, 0, maxStdioHTTPSessions+1)
	for i := 0; i < maxStdioHTTPSessions+1; i++ {
		sid, err := h.createSession("2025-11-25")
		if err != nil {
			t.Fatalf("create session %d: %v", i, err)
		}
		ids = append(ids, sid)
	}
	h.sessionMu.Lock()
	gotCount := len(h.sessions)
	h.sessionMu.Unlock()
	if gotCount != maxStdioHTTPSessions {
		t.Fatalf("session count=%d want=%d", gotCount, maxStdioHTTPSessions)
	}
	if _, ok := h.lookupSession(ids[0]); ok {
		t.Fatal("oldest session survived bounded-registry eviction")
	}
	if _, ok := h.lookupSession(ids[len(ids)-1]); !ok {
		t.Fatal("newest session was not retained")
	}
}
