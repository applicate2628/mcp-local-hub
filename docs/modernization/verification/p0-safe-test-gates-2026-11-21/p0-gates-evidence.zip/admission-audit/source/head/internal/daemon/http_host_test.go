package daemon

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// mockUpstream is a test helper: wraps an httptest.Server that impersonates
// an MCP server and records the requests it sees. responseMode controls
// whether it replies as application/json or text/event-stream.
type mockUpstream struct {
	t            *testing.T
	server       *httptest.Server
	responseMode string // "json" or "sse"
	lastBody     []byte
}

func newMockUpstream(t *testing.T, mode string) *mockUpstream {
	t.Helper()
	m := &mockUpstream{t: t, responseMode: mode}
	m.server = httptest.NewServer(http.HandlerFunc(m.handle))
	return m
}

func (m *mockUpstream) URL() string      { return m.server.URL }
func (m *mockUpstream) LastBody() []byte { return m.lastBody }

func (m *mockUpstream) Close() { m.server.Close() }

// handle replies to the three MCP methods we care about for bridge tests:
// initialize, tools/list, resources/read. Any other method returns
// a -32601. The reply shape depends on m.responseMode.
func (m *mockUpstream) handle(w http.ResponseWriter, r *http.Request) {
	body, _ := io.ReadAll(r.Body)
	m.lastBody = body
	var msg map[string]json.RawMessage
	_ = json.Unmarshal(body, &msg)
	var method string
	_ = json.Unmarshal(msg["method"], &method)
	id := msg["id"]

	var result json.RawMessage
	switch method {
	case "initialize":
		result = json.RawMessage(`{"protocolVersion":"2025-03-26","capabilities":{"resources":{},"tools":{}},"serverInfo":{"name":"mock","version":"1"}}`)
	case "tools/list":
		result = json.RawMessage(`{"tools":[{"name":"native_tool","description":"a native tool"}]}`)
	case "resources/read":
		var params struct {
			URI string `json:"uri"`
		}
		_ = json.Unmarshal(msg["params"], &params)
		escaped, _ := json.Marshal("resource body for " + params.URI)
		result = json.RawMessage(fmt.Sprintf(`{"contents":[{"uri":%q,"mimeType":"text/plain","text":%s}]}`, params.URI, string(escaped)))
	default:
		w.WriteHeader(http.StatusOK)
		errResp, _ := json.Marshal(map[string]any{
			"jsonrpc": "2.0",
			"id":      json.RawMessage(id),
			"error":   map[string]any{"code": -32601, "message": "method not found: " + method},
		})
		_, _ = w.Write(errResp)
		return
	}

	respBody, _ := json.Marshal(map[string]any{
		"jsonrpc": "2.0",
		"id":      json.RawMessage(id),
		"result":  result,
	})

	switch m.responseMode {
	case "sse":
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Mcp-Session-Id", "mock-session")
		w.WriteHeader(http.StatusOK)
		_, _ = fmt.Fprintf(w, "event: message\ndata: %s\n\n", respBody)
		if flusher, ok := w.(http.Flusher); ok {
			flusher.Flush()
		}
	default:
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Mcp-Session-Id", "mock-session")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(respBody)
	}
}

// newHTTPHostAgainstMock stands up an HTTPHost wired directly to the
// mock upstream. Skips the real subprocess — we inject httpClient and
// upstreamURL after construction.
func newHTTPHostAgainstMock(t *testing.T, upstream *mockUpstream) *HTTPHost {
	t.Helper()
	h := &HTTPHost{
		httpClient:   upstream.server.Client(),
		streamClient: upstream.server.Client(),
		getTokens:    make(chan struct{}, maxHTTPHostGETStreams),
		upstreamURL:  upstream.URL(),
		bridge:       NewProtocolBridge(),
		done:         make(chan struct{}),
		childExited:  make(chan struct{}),
		started:      true, // skip Start() — no subprocess to spawn
	}
	return h
}

func TestHTTPHost_JSON_InjectsReadResourceOnToolsList(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()

	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	// initialize first so capabilities are cached.
	post(t, ts.URL, "application/json",
		`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`)

	// tools/list
	body := post(t, ts.URL, "application/json", `{"jsonrpc":"2.0","id":2,"method":"tools/list"}`)
	var out struct {
		Result struct {
			Tools []struct {
				Name string `json:"name"`
			} `json:"tools"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &out); err != nil {
		t.Fatalf("unmarshal: %v (body=%s)", err, body)
	}
	names := map[string]bool{}
	for _, tl := range out.Result.Tools {
		names[tl.Name] = true
	}
	if !names["native_tool"] || !names["__read_resource__"] {
		t.Errorf("tools/list missing expected entries: %+v", names)
	}
}

func TestHTTPHost_JSON_RewritesReadResourceCall(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	post(t, ts.URL, "application/json",
		`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`)

	// tools/call __read_resource__ → upstream sees resources/read, client sees
	// tools/call-shaped content.
	body := post(t, ts.URL, "application/json",
		`{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"__read_resource__","arguments":{"uri":"resource://workflow"}}}`)

	// Verify upstream saw resources/read with correct uri.
	var upstreamMsg map[string]json.RawMessage
	_ = json.Unmarshal(upstream.LastBody(), &upstreamMsg)
	var upstreamMethod string
	_ = json.Unmarshal(upstreamMsg["method"], &upstreamMethod)
	if upstreamMethod != "resources/read" {
		t.Errorf("upstream method = %q, want resources/read", upstreamMethod)
	}

	// Verify client saw content[] with reshaped body.
	var out struct {
		Result struct {
			Content []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			} `json:"content"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &out); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(out.Result.Content) != 1 {
		t.Fatalf("expected 1 content, got %d: %s", len(out.Result.Content), body)
	}
	if !strings.Contains(out.Result.Content[0].Text, "resource body for resource://workflow") {
		t.Errorf("content missing resource body: %s", out.Result.Content[0].Text)
	}
}

func TestHTTPHost_SSE_InjectsAndReshapes(t *testing.T) {
	upstream := newMockUpstream(t, "sse")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	// initialize over SSE — client accepts only SSE.
	initBody := postAcceptSSE(t, ts.URL,
		`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`)
	// Extract data: payload.
	initPayload := extractSSEDataPayload(t, initBody)
	if !strings.Contains(string(initPayload), `"resources"`) {
		t.Fatalf("initialize response missing resources capability: %s", initPayload)
	}

	// tools/list over SSE — expect __read_resource__ in the data payload.
	listBody := postAcceptSSE(t, ts.URL, `{"jsonrpc":"2.0","id":2,"method":"tools/list"}`)
	listPayload := extractSSEDataPayload(t, listBody)
	if !strings.Contains(string(listPayload), "__read_resource__") {
		t.Errorf("SSE tools/list did not have __read_resource__ injected: %s", listPayload)
	}

	// tools/call __read_resource__ over SSE.
	callBody := postAcceptSSE(t, ts.URL,
		`{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"__read_resource__","arguments":{"uri":"resource://x"}}}`)
	callPayload := extractSSEDataPayload(t, callBody)
	if !strings.Contains(string(callPayload), `"content"`) {
		t.Errorf("SSE tools/call response missing reshaped content: %s", callPayload)
	}
	if !strings.Contains(string(callPayload), "resource body for resource://x") {
		t.Errorf("SSE tools/call content missing upstream body: %s", callPayload)
	}
}

func TestHTTPHost_POSTBodyTooLarge(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	tooLarge := strings.Repeat("a", int(maxHTTPHostBodyBytes)+1)
	req, err := http.NewRequest(http.MethodPost, ts.URL+"/mcp", strings.NewReader(tooLarge))
	if err != nil {
		t.Fatalf("new request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("do request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusRequestEntityTooLarge {
		t.Fatalf("status = %d, want %d", resp.StatusCode, http.StatusRequestEntityTooLarge)
	}
	if len(upstream.LastBody()) != 0 {
		t.Fatalf("expected request to be rejected before proxying upstream")
	}
}

// TestHTTPHost_InitializeForwardsAndPreservesSessionID verifies that
// EVERY initialize reaches upstream (no cache-based short-circuit) and
// that upstream's Mcp-Session-Id header is copied to the client's
// response. Caching + replaying initialize in HTTPHost would strip the
// session-id, breaking every subsequent POST/GET from the client.
//
// This is the regression guard for a real bug caught in empirical
// testing (Phase 5): the old implementation short-circuited and
// returned "Bad Request: Missing session ID" on the second client call.
func TestHTTPHost_InitializeForwardsAndPreservesSessionID(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	// Client uses net/http directly so we can inspect response headers.
	doInit := func(id int) (body []byte, sessionID string) {
		body = post(t, ts.URL, "application/json",
			`{"jsonrpc":"2.0","id":`+strconv.Itoa(id)+`,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`)
		// Re-issue to capture headers (post() discards them).
		req, _ := http.NewRequest("POST", ts.URL+"/mcp", strings.NewReader(
			`{"jsonrpc":"2.0","id":`+strconv.Itoa(id+100)+`,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Accept", "application/json")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("POST: %v", err)
		}
		defer resp.Body.Close()
		return body, resp.Header.Get("Mcp-Session-Id")
	}

	body1, sid1 := doInit(1)
	upstream1 := append([]byte(nil), upstream.LastBody()...)
	body2, sid2 := doInit(2)
	upstream2 := upstream.LastBody()

	// Every initialize must reach upstream (both upstream bodies must be set).
	if len(upstream1) == 0 || len(upstream2) == 0 {
		t.Fatalf("upstream did not see both initializes: u1=%q u2=%q", upstream1, upstream2)
	}
	// mock writes the same Mcp-Session-Id ("mock-session") for every
	// response. What we're guarding is that the proxy COPIED that header
	// to the client — not that each session is distinct.
	if sid1 != "mock-session" || sid2 != "mock-session" {
		t.Errorf("Mcp-Session-Id not propagated: sid1=%q sid2=%q", sid1, sid2)
	}
	// And the response bodies must have the client-sent ids (1 and 2).
	var r1, r2 map[string]any
	_ = json.Unmarshal(body1, &r1)
	_ = json.Unmarshal(body2, &r2)
	if r1["id"].(float64) != 1 || r2["id"].(float64) != 2 {
		t.Errorf("id not preserved on forwarded initialize: r1.id=%v r2.id=%v", r1["id"], r2["id"])
	}
}

// TestHTTPHost_InitializeCapabilitiesCachedForInjection verifies that
// even though initialize itself is NOT short-circuited, the response
// capabilities ARE cached — so the next tools/list correctly decides
// whether to inject synthetic tools.
func TestHTTPHost_InitializeCapabilitiesCachedForInjection(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	// initialize: upstream advertises resources capability.
	post(t, ts.URL, "application/json",
		`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}`)

	// tools/list: should inject __read_resource__ because the bridge
	// cached capabilities.resources from initialize.
	body := post(t, ts.URL, "application/json", `{"jsonrpc":"2.0","id":2,"method":"tools/list"}`)
	if !strings.Contains(string(body), "__read_resource__") {
		t.Errorf("capability cache not populated — tools/list did not get __read_resource__: %s", body)
	}
}

func TestHTTPHost_POSTBodyTooLargeRejected(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	req, _ := http.NewRequest("POST", ts.URL+"/mcp", strings.NewReader(strings.Repeat("x", int(maxHTTPHostBodyBytes)+1)))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusRequestEntityTooLarge {
		t.Fatalf("status = %d, want %d", resp.StatusCode, http.StatusRequestEntityTooLarge)
	}
}

func TestHTTPHost_UpstreamJSONBodyTooLargeRejected(t *testing.T) {
	largeUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(strings.Repeat("y", int(maxHTTPHostBodyBytes)+1)))
	}))
	defer largeUpstream.Close()

	h := &HTTPHost{
		httpClient:   largeUpstream.Client(),
		streamClient: largeUpstream.Client(),
		upstreamURL:  largeUpstream.URL,
		bridge:       NewProtocolBridge(),
		done:         make(chan struct{}),
		childExited:  make(chan struct{}),
		started:      true,
	}
	ts := httptest.NewServer(h.HTTPHandler())
	defer ts.Close()

	req, _ := http.NewRequest("POST", ts.URL+"/mcp", strings.NewReader(`{"jsonrpc":"2.0","id":1,"method":"tools/list"}`))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadGateway {
		t.Fatalf("status = %d, want %d", resp.StatusCode, http.StatusBadGateway)
	}
}

// --- SSE parser edge cases ---

func TestStreamSSE_PassesThroughNonJSONDataLines(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)

	// Simulated SSE stream with mix of JSON data, non-JSON comments,
	// and event fields. Must preserve non-data lines as-is.
	in := strings.NewReader(
		"event: keepalive\n" +
			": server-sent comment\n" +
			"data: not json here\n" +
			"\n" +
			"event: message\n" +
			"data: {\"jsonrpc\":\"2.0\",\"id\":5,\"result\":{\"tools\":[]}}\n" +
			"\n",
	)
	w := &fakeFlushResponseWriter{header: http.Header{}}

	h.bridge.CacheInitialize(json.RawMessage(`{"result":{"capabilities":{"resources":{}}}}`))
	h.streamSSEResponse(w, in, "tools/list", nil)

	out := w.buf.String()
	if !strings.Contains(out, "event: keepalive") {
		t.Errorf("keepalive event not preserved: %q", out)
	}
	if !strings.Contains(out, ": server-sent comment") {
		t.Errorf("SSE comment not preserved: %q", out)
	}
	if !strings.Contains(out, "data: not json here") {
		t.Errorf("non-JSON data line not preserved: %q", out)
	}
	// The JSON data line should have been transformed (tools/list → __read_resource__ injected).
	if !strings.Contains(out, "__read_resource__") {
		t.Errorf("JSON data line not transformed: %q", out)
	}
}

// --- test helpers ---

func post(t *testing.T, url, contentType, body string) []byte {
	t.Helper()
	req, _ := http.NewRequest("POST", url+"/mcp", strings.NewReader(body))
	req.Header.Set("Content-Type", contentType)
	req.Header.Set("Accept", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		t.Logf("POST %s returned HTTP %d: %s", url, resp.StatusCode, raw)
	}
	return raw
}

func postAcceptSSE(t *testing.T, url, body string) []byte {
	t.Helper()
	req, _ := http.NewRequest("POST", url+"/mcp", strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "text/event-stream")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	return raw
}

func extractSSEDataPayload(t *testing.T, sseBody []byte) []byte {
	t.Helper()
	for _, line := range strings.Split(string(sseBody), "\n") {
		if strings.HasPrefix(line, "data: ") {
			return []byte(strings.TrimPrefix(line, "data: "))
		}
	}
	t.Fatalf("no data: line in SSE body: %s", sseBody)
	return nil
}

// fakeFlushResponseWriter is a minimal http.ResponseWriter + http.Flusher
// impl used by streamSSEResponse tests so we can inspect written bytes.
type fakeFlushResponseWriter struct {
	header http.Header
	buf    strings.Builder
	status int
}

func (f *fakeFlushResponseWriter) Header() http.Header         { return f.header }
func (f *fakeFlushResponseWriter) WriteHeader(statusCode int)  { f.status = statusCode }
func (f *fakeFlushResponseWriter) Write(b []byte) (int, error) { return f.buf.Write(b) }
func (f *fakeFlushResponseWriter) Flush()                      {}

// TestHTTPHost_GETUsesStreamClient_NoClientTimeout guards against
// regression of the 60 s httpClient timeout being applied to
// long-lived SSE subscriptions. The test asserts that GET /mcp routes
// through h.streamClient (no timeout) by making the upstream respond
// with a stream that is still open when the assertion runs.
func TestHTTPHost_GETUsesStreamClient_NoClientTimeout(t *testing.T) {
	// Upstream that holds a GET open and slowly emits keepalive frames.
	// If the proxy used httpClient with 60 s timeout, the test would
	// still pass because it only runs for ~200 ms — so instead we
	// assert the CLIENT IDENTITY: streamClient must have Timeout 0.
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)

	if h.streamClient == nil {
		t.Fatal("streamClient must be non-nil for GET SSE passthrough")
	}
	// streamClient is used for GET; it must have NO overall timeout so
	// the MCP notifications channel can stay open for the session.
	// httpClient is allowed to keep its 60 s bound for POST request-
	// response exchanges. The test harness's mock client copies the
	// timeout from httptest.Server which may be zero — so rather than
	// asserting numeric values, we assert that the two clients are
	// DISTINCT pointers when constructed by NewHTTPHost.
	realHost, err := NewHTTPHost(HTTPHostConfig{
		Command:      "true",
		UpstreamPort: 12345,
	})
	if err != nil {
		t.Fatalf("NewHTTPHost: %v", err)
	}
	if realHost.httpClient == realHost.streamClient {
		t.Error("httpClient and streamClient must be distinct so GET SSE isn't bounded by the 60 s POST timeout")
	}
	if realHost.streamClient.Timeout != 0 {
		t.Errorf("streamClient.Timeout = %v, want 0 (long-lived SSE)", realHost.streamClient.Timeout)
	}
	if realHost.httpClient.Timeout == 0 {
		t.Error("httpClient.Timeout = 0 — POST requests should have a finite bound to avoid stuck handlers")
	}
}

func TestHTTPHost_GETPassthrough_RejectsWhenStreamLimitReached(t *testing.T) {
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()
	h := newHTTPHostAgainstMock(t, upstream)
	h.getTokens = make(chan struct{}, 1)
	h.getTokens <- struct{}{} // simulate an already active stream

	req := httptest.NewRequest(http.MethodGet, "/mcp", nil)
	rr := httptest.NewRecorder()
	h.forwardPassthrough(rr, req)

	if rr.Code != http.StatusTooManyRequests {
		t.Fatalf("status=%d, want %d", rr.Code, http.StatusTooManyRequests)
	}
}

// --- waitForReady / Start guardrail ---

func TestHTTPHost_WaitForReady_ReturnsImmediatelyWhenUpstreamReady(t *testing.T) {
	// httptest.Server is up before Start() is called, so waitForReady
	// should return on the very first probe.
	upstream := newMockUpstream(t, "json")
	defer upstream.Close()

	h, err := NewHTTPHost(HTTPHostConfig{
		Command:       "true", // no-op command
		UpstreamPort:  parsePort(t, upstream.URL()),
		HealthTimeout: 2 * time.Second,
	})
	if err != nil {
		t.Fatalf("NewHTTPHost: %v", err)
	}
	h.httpClient = upstream.server.Client()

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	if err := h.waitForReady(ctx); err != nil {
		t.Fatalf("waitForReady failed when upstream already up: %v", err)
	}
}

func TestHTTPHost_WaitForReady_HangingProbeBoundedByHealthTimeout(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer listener.Close()

	accepted := make(chan struct{})
	done := make(chan struct{})
	go func() {
		defer close(done)
		conn, err := listener.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		close(accepted)
		_, _ = io.Copy(io.Discard, conn)
	}()

	_, port, err := net.SplitHostPort(listener.Addr().String())
	if err != nil {
		t.Fatalf("split listener address: %v", err)
	}
	portNum, err := strconv.Atoi(port)
	if err != nil {
		t.Fatalf("parse listener port: %v", err)
	}

	h, err := NewHTTPHost(HTTPHostConfig{
		Command:       "true",
		UpstreamPort:  portNum,
		HealthTimeout: 100 * time.Millisecond,
	})
	if err != nil {
		t.Fatalf("NewHTTPHost: %v", err)
	}
	h.httpClient = &http.Client{Timeout: 5 * time.Second}

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	start := time.Now()
	err = h.waitForReady(ctx)
	elapsed := time.Since(start)
	if err == nil {
		t.Fatal("waitForReady unexpectedly succeeded against a hanging listener")
	}
	select {
	case <-accepted:
	default:
		t.Fatal("waitForReady did not connect to the hanging listener")
	}
	if elapsed >= time.Second {
		t.Fatalf("waitForReady elapsed %v, want it bounded by HealthTimeout instead of caller/client timeout", elapsed)
	}
	if elapsed < 100*time.Millisecond {
		t.Fatalf("waitForReady elapsed %v, want it to wait for HealthTimeout", elapsed)
	}

	listener.Close()
	<-done
}

func parsePort(t *testing.T, urlStr string) int {
	t.Helper()
	_, port, err := net.SplitHostPort(strings.TrimPrefix(urlStr, "http://"))
	if err != nil {
		t.Fatalf("parse port from %q: %v", urlStr, err)
	}
	p := 0
	fmt.Sscanf(port, "%d", &p)
	return p
}

// ExitState must return nil safely before the subprocess is even
// spawned. The cli/daemon.go fallback formatChildExit also accepts nil,
// so the contract is "nil before exit is normal." This guards against a
// regression where ExitState dereferences h.cmd (which is nil during
// the no-spawn-yet window between NewHTTPHost and Start).
func TestHTTPHost_ExitState_NilBeforeStart(t *testing.T) {
	h, err := NewHTTPHost(HTTPHostConfig{
		Command:      "true",
		UpstreamPort: 9999,
	})
	if err != nil {
		t.Fatalf("NewHTTPHost: %v", err)
	}
	if got := h.ExitState(); got != nil {
		t.Errorf("ExitState() before Start = %v, want nil", got)
	}
}

// deleteRecordingUpstream records DELETE /mcp requests so a test can assert
// the bridge forwarded the client-origin session termination upstream
// (Finding 4). statusForDelete overrides the status it answers (0 -> 204).
type deleteRecordingUpstream struct {
	mu              sync.Mutex
	server          *httptest.Server
	deleteHits      int
	lastDeleteSID   string
	lastDeletePV    string
	lastDeleteAuth  string
	statusForDelete int
}

func newDeleteRecordingUpstream(t *testing.T, statusForDelete int) *deleteRecordingUpstream {
	t.Helper()
	u := &deleteRecordingUpstream{statusForDelete: statusForDelete}
	u.server = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			u.mu.Lock()
			u.deleteHits++
			u.lastDeleteSID = r.Header.Get("Mcp-Session-Id")
			u.lastDeletePV = r.Header.Get("MCP-Protocol-Version")
			u.lastDeleteAuth = r.Header.Get("Authorization")
			status := u.statusForDelete
			u.mu.Unlock()
			if status == 0 {
				status = http.StatusNoContent
			}
			w.WriteHeader(status)
			return
		}
		// Non-DELETE: a trivial OK so any stray request is harmless.
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"jsonrpc":"2.0","id":1,"result":{}}`))
	}))
	t.Cleanup(u.server.Close)
	return u
}

func (u *deleteRecordingUpstream) snapshot() (hits int, sid, pv string) {
	u.mu.Lock()
	defer u.mu.Unlock()
	return u.deleteHits, u.lastDeleteSID, u.lastDeletePV
}

func (u *deleteRecordingUpstream) deleteHitsCount() int {
	u.mu.Lock()
	defer u.mu.Unlock()
	return u.deleteHits
}

func (u *deleteRecordingUpstream) lastAuth() string {
	u.mu.Lock()
	defer u.mu.Unlock()
	return u.lastDeleteAuth
}

// newHTTPHostAgainstURL wires an HTTPHost directly to an arbitrary upstream
// URL, skipping Start() (no subprocess). Used by the DELETE-forward tests
// that need a non-mockUpstream server.
func newHTTPHostAgainstURL(upstreamURL string, client *http.Client) *HTTPHost {
	return &HTTPHost{
		httpClient:   client,
		streamClient: client,
		getTokens:    make(chan struct{}, maxHTTPHostGETStreams),
		upstreamURL:  upstreamURL,
		bridge:       NewProtocolBridge(),
		done:         make(chan struct{}),
		childExited:  make(chan struct{}),
		started:      true,
	}
}

// TestHTTPHost_DELETE_ForwardsSessionTerminationUpstream is the Finding 4
// regression guard: a DELETE /mcp on the bridge must be forwarded to the
// native-http upstream carrying the client's Mcp-Session-Id (the upstream
// minted a session per initialize, so the bridge-local 204 alone would
// leak it), and the client still receives 204.
func TestHTTPHost_DELETE_ForwardsSessionTerminationUpstream(t *testing.T) {
	upstream := newDeleteRecordingUpstream(t, 0) // 204 upstream
	h := newHTTPHostAgainstURL(upstream.server.URL, upstream.server.Client())
	ts := httptest.NewServer(h.HTTPHandler())
	t.Cleanup(ts.Close)

	req, err := http.NewRequest(http.MethodDelete, ts.URL+"/mcp", nil)
	if err != nil {
		t.Fatalf("build DELETE: %v", err)
	}
	req.Header.Set("Mcp-Session-Id", "client-issued-session")
	req.Header.Set("MCP-Protocol-Version", "2025-06-18")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("DELETE: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusNoContent {
		t.Fatalf("client DELETE status = %d, want 204", resp.StatusCode)
	}
	hits, sid, pv := upstream.snapshot()
	if hits != 1 {
		t.Fatalf("upstream DELETE hits = %d, want 1 (bridge must forward the teardown)", hits)
	}
	if sid != "client-issued-session" {
		t.Errorf("upstream DELETE Mcp-Session-Id = %q, want the client's session id", sid)
	}
	if pv != "2025-06-18" {
		t.Errorf("upstream DELETE MCP-Protocol-Version = %q, want 2025-06-18 (forwarded when present)", pv)
	}
}

// TestHTTPHost_DELETE_BestEffortWhenUpstreamRejects: a daemon whose upstream
// does not implement DELETE answers 405/404; the bridge must STILL 204 the
// client (Finding 4 best-effort — a shutdown must not surface the upstream's
// rejection).
func TestHTTPHost_DELETE_BestEffortWhenUpstreamRejects(t *testing.T) {
	upstream := newDeleteRecordingUpstream(t, http.StatusMethodNotAllowed)
	h := newHTTPHostAgainstURL(upstream.server.URL, upstream.server.Client())
	ts := httptest.NewServer(h.HTTPHandler())
	t.Cleanup(ts.Close)

	req, err := http.NewRequest(http.MethodDelete, ts.URL+"/mcp", nil)
	if err != nil {
		t.Fatalf("build DELETE: %v", err)
	}
	req.Header.Set("Mcp-Session-Id", "client-issued-session")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("DELETE: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusNoContent {
		t.Fatalf("client DELETE status = %d, want 204 even when upstream returns 405", resp.StatusCode)
	}
	if hits, _, _ := upstream.snapshot(); hits != 1 {
		t.Errorf("upstream DELETE hits = %d, want 1 (forward attempted regardless of upstream support)", hits)
	}
}

// TestHTTPHost_DELETE_ForwardsAuthorizationUpstream is the finding #5
// regression guard: the bridge DELETE forwards via copyHeadersForUpstream
// (same allowlist as POST/GET), so an auth-protected native-http upstream
// sees Authorization on the teardown DELETE. The pre-#5 hand-rolled
// session-only copy dropped Authorization, so an auth-protected upstream
// 401'd the teardown and leaked the upstream session while the bridge 204'd.
func TestHTTPHost_DELETE_ForwardsAuthorizationUpstream(t *testing.T) {
	upstream := newDeleteRecordingUpstream(t, 0)
	h := newHTTPHostAgainstURL(upstream.server.URL, upstream.server.Client())
	ts := httptest.NewServer(h.HTTPHandler())
	t.Cleanup(ts.Close)

	req, err := http.NewRequest(http.MethodDelete, ts.URL+"/mcp", nil)
	if err != nil {
		t.Fatalf("build DELETE: %v", err)
	}
	req.Header.Set("Mcp-Session-Id", "client-issued-session")
	req.Header.Set("MCP-Protocol-Version", "2025-06-18")
	req.Header.Set("Authorization", "Bearer secret-token")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("DELETE: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusNoContent {
		t.Fatalf("client DELETE status = %d, want 204", resp.StatusCode)
	}
	hits, sid, pv := upstream.snapshot()
	if hits != 1 {
		t.Fatalf("upstream DELETE hits = %d, want 1", hits)
	}
	if sid != "client-issued-session" {
		t.Errorf("upstream DELETE Mcp-Session-Id = %q, want the client's session id", sid)
	}
	if pv != "2025-06-18" {
		t.Errorf("upstream DELETE MCP-Protocol-Version = %q, want 2025-06-18 (allowlist omits it; set explicitly)", pv)
	}
	if got := upstream.lastAuth(); got != "Bearer secret-token" {
		t.Errorf("upstream DELETE Authorization = %q, want %q (#5: copyHeadersForUpstream must forward Authorization)", got, "Bearer secret-token")
	}
}

// TestHTTPHost_DELETE_DetachedFromInboundContext is the finding #1 (Invariant
// D-detach) regression guard: the bridge DELETE forward is DETACHED from
// r.Context(), so a native-http client that disconnects before the bridge's
// 204 (its request context already cancelled) does NOT abort the upstream
// DELETE — the upstream session is still released. A regression bound to
// r.Context() would record 0 upstream hits here.
func TestHTTPHost_DELETE_DetachedFromInboundContext(t *testing.T) {
	upstream := newDeleteRecordingUpstream(t, 0)
	h := newHTTPHostAgainstURL(upstream.server.URL, upstream.server.Client())

	// A DELETE request whose context is ALREADY cancelled (client gone).
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodDelete, h.upstreamURL, nil)
	if err != nil {
		t.Fatalf("build DELETE: %v", err)
	}
	req.Header.Set("Mcp-Session-Id", "client-issued-session")

	// Call the forward directly (same package): with the fix it uses a
	// detached context.Background()-derived context, so the cancelled inbound
	// ctx does NOT abort the upstream DELETE.
	h.forwardDeleteUpstream(req)

	if hits := upstream.deleteHitsCount(); hits != 1 {
		t.Errorf("upstream DELETE hits = %d, want 1 (#1 D-detach: a cancelled inbound request context must NOT abort the upstream teardown)", hits)
	}
}
