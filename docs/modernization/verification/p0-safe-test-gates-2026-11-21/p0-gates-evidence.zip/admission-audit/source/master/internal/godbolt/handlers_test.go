package godbolt

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

// fakeGodbolt is a minimal godbolt-like stub that echoes the Accept
// header and payload back so tests can assert we sent the right request
// and still receive a valid JSON response to exercise the parser.
func fakeGodbolt(t *testing.T, gotAccept *string, gotPayload *map[string]any) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		*gotAccept = r.Header.Get("Accept")
		body, _ := io.ReadAll(r.Body)
		_ = json.Unmarshal(body, gotPayload)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"code":0,"asm":[{"text":"ret"}],"stdout":[],"stderr":[]}`))
	}))
}

// TestGodboltDisabled_BlocksOutboundRequests is the security guard
// regression test: with MCPHUB_GODBOLT_DISABLE set, the server must
// refuse to send source code off-host. Verifies both the compile
// (POST) path and the resource (GET) path return ErrGodboltDisabled
// without ever reaching the test httptest.Server.
func TestGodboltDisabled_BlocksOutboundRequests(t *testing.T) {
	t.Setenv("MCPHUB_GODBOLT_DISABLE", "1")

	var reached bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		reached = true
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	// POST path (invokeCompile)
	_, err := gs.invokeCompile(t.Context(), srv.URL+"/api/compiler/x/compile", []byte(`{}`))
	if err == nil {
		t.Fatal("invokeCompile: expected error when MCPHUB_GODBOLT_DISABLE set")
	}

	// GET path (fetchResource)
	_, err = gs.fetchResource(srv.URL + "/api/languages")
	if err == nil {
		t.Fatal("fetchResource: expected error when MCPHUB_GODBOLT_DISABLE set")
	}

	if reached {
		t.Error("test server was reached despite MCPHUB_GODBOLT_DISABLE — kill switch failed")
	}
}

func TestGodboltDisabled_BlocksFormatToolOutboundRequests(t *testing.T) {
	t.Setenv("MCPHUB_GODBOLT_DISABLE", "1")

	var reached bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		reached = true
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	rawArgs, _ := json.Marshal(map[string]any{
		"formatter": "clangformat",
		"source":    "int main(){}",
	})

	result, err := gs.formatTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("formatTool returned unexpected error: %v", err)
	}
	if !result.IsError {
		t.Fatal("formatTool: expected IsError=true when MCPHUB_GODBOLT_DISABLE set")
	}
	text, ok := result.Content[0].(*mcp.TextContent)
	if !ok {
		t.Fatalf("Content[0] is not TextContent: %T", result.Content[0])
	}
	if !strings.Contains(text.Text, ErrGodboltDisabled.Error()) {
		t.Fatalf("formatTool error = %q, want to contain %q", text.Text, ErrGodboltDisabled.Error())
	}
	if reached {
		t.Fatal("formatTool reached remote server despite MCPHUB_GODBOLT_DISABLE")
	}
}

func TestCompileTool_SendsAcceptJSON(t *testing.T) {
	var gotAccept string
	var gotPayload map[string]any
	srv := fakeGodbolt(t, &gotAccept, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	out, err := gs.invokeCompile(t.Context(), srv.URL+"/api/compiler/gcc/compile", []byte(`{"source":"int main(){}"}`))
	if err != nil {
		t.Fatalf("invokeCompile: %v", err)
	}
	if gotAccept != "application/json" {
		t.Errorf("Accept header = %q, want application/json", gotAccept)
	}
	if !strings.Contains(string(out), `"asm":[{"text":"ret"}]`) {
		t.Errorf("response body missing structured asm field: %s", out)
	}
}

func TestInvokeCompile_RejectsOversizedResponse(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(bytes.Repeat([]byte("a"), int(maxGodboltResponseBytes+1)))
	}))
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	_, err := gs.invokeCompile(t.Context(), srv.URL+"/api/compiler/gcc/compile", []byte(`{"source":"int main(){}"}`))
	if err == nil {
		t.Fatal("invokeCompile: expected size limit error")
	}
	if !strings.Contains(err.Error(), "response body exceeds") {
		t.Fatalf("invokeCompile: unexpected error %v", err)
	}
}

// mockCallToolRequest wraps raw JSON bytes as a CallToolRequest so tests
// can invoke compileTool/compileCMakeTool without constructing the full
// MCP request plumbing.
type mockCallToolRequest struct {
	Arguments json.RawMessage
}

// The real mcp.CallToolRequest has Params typed as *CallToolParamsRaw,
// whose Arguments field is json.RawMessage; we mimic that structure
// minimally.
func (m *mockCallToolRequest) toReal() *mcp.CallToolRequest {
	r := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{}}
	r.Params.Arguments = m.Arguments
	return r
}

func TestCompileTool_PassesFiltersExecuteParametersAndTools(t *testing.T) {
	var gotAccept string
	var gotPayload map[string]any
	srv := fakeGodbolt(t, &gotAccept, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	rawArgs, _ := json.Marshal(map[string]any{
		"compiler_id":    "gcc-13.2",
		"source":         "int main(){return 0;}",
		"user_arguments": "-O3",
		"filters": map[string]any{
			"execute":   true,
			"intel":     true,
			"optOutput": true,
		},
		"execute_parameters": map[string]any{
			"stdin": "42\n",
			"args":  []string{"--flag"},
		},
		"tools": []map[string]any{
			{"id": "llvm-mcatrunk", "args": "-mcpu=skylake -timeline"},
			{"id": "pahole", "args": ""},
		},
	})

	_, err := gs.compileTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("compileTool returned error: %v", err)
	}

	opts, ok := gotPayload["options"].(map[string]any)
	if !ok {
		t.Fatalf("options missing from payload: %+v", gotPayload)
	}
	filters, ok := opts["filters"].(map[string]any)
	if !ok {
		t.Fatalf("filters not forwarded: options=%+v", opts)
	}
	if filters["execute"] != true || filters["intel"] != true || filters["optOutput"] != true {
		t.Errorf("filters missing expected values: %+v", filters)
	}
	execParams, ok := opts["executeParameters"].(map[string]any)
	if !ok {
		t.Fatalf("executeParameters not forwarded: options=%+v", opts)
	}
	if execParams["stdin"] != "42\n" {
		t.Errorf("stdin not forwarded: %+v", execParams)
	}

	// tools lives INSIDE options per the official Compiler Explorer
	// API docs — putting it at top level gets silently dropped.
	tools, ok := opts["tools"].([]any)
	if !ok {
		t.Fatalf("tools not forwarded inside options: options=%+v", opts)
	}
	if len(tools) != 2 {
		t.Fatalf("expected 2 tools, got %d: %+v", len(tools), tools)
	}
	firstTool, ok := tools[0].(map[string]any)
	if !ok {
		t.Fatalf("tools[0] is not an object: %T", tools[0])
	}
	if firstTool["id"] != "llvm-mcatrunk" {
		t.Errorf("tools[0].id = %v, want llvm-mcatrunk", firstTool["id"])
	}
}

func TestFormatTool_RejectsOversizedResponse(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(bytes.Repeat([]byte("a"), int(maxGodboltResponseBytes+1)))
	}))
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	rawArgs, _ := json.Marshal(map[string]any{
		"formatter": "clangformat",
		"source":    "int main(){}",
	})

	res, err := gs.formatTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("formatTool returned error: %v", err)
	}
	if !res.IsError {
		t.Fatal("formatTool: expected tool-level error")
	}
	text, ok := res.Content[0].(*mcp.TextContent)
	if !ok {
		t.Fatalf("formatTool: expected TextContent, got %T", res.Content[0])
	}
	if !strings.Contains(text.Text, "response body exceeds") {
		t.Fatalf("formatTool: expected size limit error, got %q", text.Text)
	}
}

// fakeFormatGodbolt echoes the formatter request payload back and returns
// a valid {"answer", "exit"} body so format-style tests can assert the
// style options reached the wire.
func fakeFormatGodbolt(t *testing.T, gotURL *string, gotPayload *map[string]any) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		*gotURL = r.URL.String()
		body, _ := io.ReadAll(r.Body)
		_ = json.Unmarshal(body, gotPayload)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"answer":"int main() {}\n","exit":0}`))
	}))
}

func TestFormatTool_ForwardsStyleOptions(t *testing.T) {
	var gotURL string
	var gotPayload map[string]any
	srv := fakeFormatGodbolt(t, &gotURL, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	rawArgs, _ := json.Marshal(map[string]any{
		"formatter": "clangformat",
		"source":    "int main(){}",
		"base":      "Google",
		"useSpaces": true,
		"tabWidth":  4,
	})

	res, err := gs.formatTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("formatTool returned error: %v", err)
	}
	if res.IsError {
		text := res.Content[0].(*mcp.TextContent).Text
		t.Fatalf("formatTool unexpected IsError: %s", text)
	}
	if gotURL != "/api/format/clangformat" {
		t.Errorf("godbolt URL = %q, want /api/format/clangformat", gotURL)
	}
	if gotPayload["base"] != "Google" {
		t.Errorf("base not forwarded: %+v", gotPayload)
	}
	if gotPayload["useSpaces"] != true {
		t.Errorf("useSpaces not forwarded: %+v", gotPayload)
	}
	// JSON numbers unmarshal into float64 through map[string]any.
	if gotPayload["tabWidth"] != float64(4) {
		t.Errorf("tabWidth not forwarded: %+v", gotPayload)
	}
	if gotPayload["source"] != "int main(){}" {
		t.Errorf("source not forwarded: %+v", gotPayload)
	}
}

// TestFormatTool_OmitsUnsetStyleOptions guards the pointer-based
// presence detection: an omitted useSpaces/tabWidth/base must NOT be
// sent (so the formatter's own defaults apply), not silently coerced to
// false / 0 / "".
func TestFormatTool_OmitsUnsetStyleOptions(t *testing.T) {
	var gotURL string
	var gotPayload map[string]any
	srv := fakeFormatGodbolt(t, &gotURL, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	rawArgs, _ := json.Marshal(map[string]any{
		"formatter": "clangformat",
		"source":    "int main(){}",
	})

	res, err := gs.formatTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("formatTool returned error: %v", err)
	}
	if res.IsError {
		t.Fatalf("formatTool unexpected IsError: %s", res.Content[0].(*mcp.TextContent).Text)
	}
	if _, ok := gotPayload["base"]; ok {
		t.Errorf("base sent despite being unset: %+v", gotPayload)
	}
	if _, ok := gotPayload["useSpaces"]; ok {
		t.Errorf("useSpaces sent despite being unset: %+v", gotPayload)
	}
	if _, ok := gotPayload["tabWidth"]; ok {
		t.Errorf("tabWidth sent despite being unset: %+v", gotPayload)
	}
}

// TestFormatTool_ForwardsExplicitZeroValues verifies the pointer seam
// sends an explicit useSpaces:false (the meaningful "use tabs" choice)
// rather than dropping it as if unset.
func TestFormatTool_ForwardsExplicitZeroValues(t *testing.T) {
	var gotURL string
	var gotPayload map[string]any
	srv := fakeFormatGodbolt(t, &gotURL, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}
	rawArgs, _ := json.Marshal(map[string]any{
		"formatter": "clangformat",
		"source":    "int main(){}",
		"useSpaces": false,
		"tabWidth":  0,
	})

	res, err := gs.formatTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("formatTool returned error: %v", err)
	}
	if res.IsError {
		t.Fatalf("formatTool unexpected IsError: %s", res.Content[0].(*mcp.TextContent).Text)
	}
	v, ok := gotPayload["useSpaces"]
	if !ok || v != false {
		t.Errorf("explicit useSpaces:false not forwarded: %+v", gotPayload)
	}
	w, ok := gotPayload["tabWidth"]
	if !ok || w != float64(0) {
		t.Errorf("explicit tabWidth:0 not forwarded: %+v", gotPayload)
	}
}

func TestShortlinkInfoTool_DelegatesToResource(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"sessions":[{"source":"int main(){}","language":"c++"}]}`))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	rawArgs, _ := json.Marshal(map[string]any{"linkid": "abc123"})
	result, err := gs.shortlinkInfoTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("shortlinkInfoTool: %v", err)
	}
	if gotURL != "/api/shortlinkinfo/abc123" {
		t.Errorf("godbolt URL = %q, want /api/shortlinkinfo/abc123", gotURL)
	}
	if result.IsError {
		t.Fatalf("unexpected IsError result: %s", result.Content[0].(*mcp.TextContent).Text)
	}
	if len(result.Content) == 0 {
		t.Fatal("empty Content")
	}
	text, ok := result.Content[0].(*mcp.TextContent)
	if !ok {
		t.Fatalf("Content[0] is not TextContent: %T", result.Content[0])
	}
	if !strings.Contains(text.Text, `"source":"int main(){}"`) {
		t.Errorf("response missing stored source: %s", text.Text)
	}
}

func TestShortlinkInfoTool_MissingLinkIDReturnsError(t *testing.T) {
	gs := &GodboltServer{httpClient: http.DefaultClient, baseURL: "http://unused"}
	rawArgs, _ := json.Marshal(map[string]any{})
	result, err := gs.shortlinkInfoTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("shortlinkInfoTool: %v", err)
	}
	if !result.IsError {
		t.Fatal("expected IsError=true for missing linkid")
	}
}

func TestGetShortlinkInfo_ExtractsLinkID(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"sessions":[]}`))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://shortlinkinfo/xY9zK"
	result, err := gs.getShortlinkInfo(t.Context(), req)
	if err != nil {
		t.Fatalf("getShortlinkInfo: %v", err)
	}
	if gotURL != "/api/shortlinkinfo/xY9zK" {
		t.Errorf("godbolt URL = %q, want /api/shortlinkinfo/xY9zK", gotURL)
	}
	rc := result.Contents[0]
	if rc.MIMEType != "application/json" {
		t.Errorf("MIME = %q, want application/json", rc.MIMEType)
	}
	if rc.URI != "resource://shortlinkinfo/xY9zK" {
		t.Errorf("URI = %q, want resource://shortlinkinfo/xY9zK", rc.URI)
	}
}

func TestGetPopularArguments(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"-O3":{"description":"optimize","timesused":100}}`))
	}))
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://popularArguments/gcc-13.2"

	result, err := gs.getPopularArguments(t.Context(), req)
	if err != nil {
		t.Fatalf("getPopularArguments: %v", err)
	}
	if gotURL != "/api/popularArguments/gcc-13.2" {
		t.Errorf("godbolt URL = %q, want /api/popularArguments/gcc-13.2", gotURL)
	}
	if len(result.Contents) == 0 {
		t.Fatal("empty Contents")
	}
	rc := result.Contents[0]
	if rc == nil {
		t.Fatal("Contents[0] is nil")
	}
	if !strings.Contains(rc.Text, `"-O3"`) {
		t.Errorf("response text missing -O3 entry: %s", rc.Text)
	}
	if rc.MIMEType != "application/json" {
		t.Errorf("MIME = %q, want application/json", rc.MIMEType)
	}
	if rc.URI != "resource://popularArguments/gcc-13.2" {
		t.Errorf("URI = %q, want resource://popularArguments/gcc-13.2", rc.URI)
	}
}

func TestGetCompilers_ExtractsLanguageID(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`[{"id":"gcc-13.2","name":"GCC 13.2"}]`))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://compilers/cpp"
	_, err := gs.getCompilers(t.Context(), req)
	if err != nil {
		t.Fatalf("getCompilers: %v", err)
	}
	if gotURL != "/api/compilers/cpp" {
		t.Errorf("godbolt URL = %q, want /api/compilers/cpp", gotURL)
	}
}

func TestGetLibraries_ExtractsLanguageID(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`[]`))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://libraries/rust"
	_, err := gs.getLibraries(t.Context(), req)
	if err != nil {
		t.Fatalf("getLibraries: %v", err)
	}
	if gotURL != "/api/libraries/rust" {
		t.Errorf("godbolt URL = %q, want /api/libraries/rust", gotURL)
	}
}

func TestGetInstructionInfo_ExtractsBothParams(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "text/plain")
		_, _ = w.Write([]byte("MOV instruction docs"))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://asm/x86/mov"
	_, err := gs.getInstructionInfo(t.Context(), req)
	if err != nil {
		t.Fatalf("getInstructionInfo: %v", err)
	}
	if gotURL != "/api/asm/x86/mov" {
		t.Errorf("godbolt URL = %q, want /api/asm/x86/mov (both instruction_set and opcode must extract correctly)", gotURL)
	}
}

func TestListCompilersTool_DelegatesToResource(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`[{"id":"gcc-13.2","name":"GCC 13.2"}]`))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	rawArgs, _ := json.Marshal(map[string]any{"language_id": "c++"})
	result, err := gs.listCompilersTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("listCompilersTool: %v", err)
	}
	if gotURL != "/api/compilers/c++" {
		t.Errorf("godbolt URL = %q, want /api/compilers/c++", gotURL)
	}
	if result.IsError {
		t.Fatalf("unexpected IsError result")
	}
	if len(result.Content) == 0 {
		t.Fatal("empty Content")
	}
	text, ok := result.Content[0].(*mcp.TextContent)
	if !ok {
		t.Fatalf("Content[0] is not TextContent: %T", result.Content[0])
	}
	if !strings.Contains(text.Text, `"gcc-13.2"`) {
		t.Errorf("response missing compiler id: %s", text.Text)
	}
}

func TestListCompilersTool_MissingLanguageIDReturnsError(t *testing.T) {
	gs := &GodboltServer{httpClient: http.DefaultClient, baseURL: "http://unused"}
	rawArgs, _ := json.Marshal(map[string]any{})
	result, err := gs.listCompilersTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("listCompilersTool: %v", err)
	}
	if !result.IsError {
		t.Fatal("expected IsError=true for missing language_id")
	}
}

func TestGetVersionTool_DelegatesToResource(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Header().Set("Content-Type", "text/plain")
		_, _ = w.Write([]byte("Compiler Explorer v42"))
	}))
	defer srv.Close()
	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	result, err := gs.getVersionTool(t.Context(), (&mockCallToolRequest{Arguments: json.RawMessage(`{}`)}).toReal())
	if err != nil {
		t.Fatalf("getVersionTool: %v", err)
	}
	if gotURL != "/api/version" {
		t.Errorf("godbolt URL = %q, want /api/version", gotURL)
	}
	text := result.Content[0].(*mcp.TextContent).Text
	if !strings.Contains(text, "Compiler Explorer v42") {
		t.Errorf("response missing version string: %s", text)
	}
}

func TestLookupInstructionTool_RequiresBothParams(t *testing.T) {
	gs := &GodboltServer{httpClient: http.DefaultClient, baseURL: "http://unused"}

	cases := []map[string]any{
		{"instruction_set": "x86"},
		{"opcode": "mov"},
		{},
	}
	for i, c := range cases {
		rawArgs, _ := json.Marshal(c)
		result, err := gs.lookupInstructionTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
		if err != nil {
			t.Fatalf("case %d: %v", i, err)
		}
		if !result.IsError {
			t.Errorf("case %d: expected IsError for args %+v", i, c)
		}
	}
}

func TestCompileCMakeTool_MirrorsCompileToolSurface(t *testing.T) {
	var gotAccept string
	var gotPayload map[string]any
	srv := fakeGodbolt(t, &gotAccept, &gotPayload)
	defer srv.Close()

	gs := &GodboltServer{httpClient: srv.Client(), baseURL: srv.URL + "/api"}

	rawArgs, _ := json.Marshal(map[string]any{
		"compiler_id":    "gcc-13.2",
		"source":         "cmake_minimum_required(VERSION 3.20)\nproject(x)\n",
		"user_arguments": "-O3",
		"filters":        map[string]any{"execute": true},
		"execute_parameters": map[string]any{
			"stdin": "hello\n",
		},
		"tools": []map[string]any{
			{"id": "pahole", "args": ""},
		},
	})

	_, err := gs.compileCMakeTool(t.Context(), (&mockCallToolRequest{Arguments: rawArgs}).toReal())
	if err != nil {
		t.Fatalf("compileCMakeTool: %v", err)
	}

	if gotAccept != "application/json" {
		t.Errorf("Accept header = %q, want application/json", gotAccept)
	}
	opts := gotPayload["options"].(map[string]any)
	filters := opts["filters"].(map[string]any)
	if filters["execute"] != true {
		t.Errorf("filters.execute not forwarded: %+v", filters)
	}
	execParams := opts["executeParameters"].(map[string]any)
	if execParams["stdin"] != "hello\n" {
		t.Errorf("executeParameters.stdin not forwarded: %+v", execParams)
	}
	tools, ok := opts["tools"].([]any)
	if !ok || len(tools) != 1 {
		t.Fatalf("tools not forwarded inside options or wrong count: %+v", opts["tools"])
	}
}
