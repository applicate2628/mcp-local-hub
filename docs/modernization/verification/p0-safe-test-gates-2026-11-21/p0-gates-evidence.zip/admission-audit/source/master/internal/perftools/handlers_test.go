package perftools

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/modelcontextprotocol/go-sdk/mcp"
)

func TestDetectTools_ReportsInstalledWithVersion(t *testing.T) {
	catalog := DetectTools()

	if catalog == nil {
		t.Fatal("DetectTools returned nil")
	}
	if catalog.ClangTidy == nil || catalog.Hyperfine == nil ||
		catalog.LLVMObjdump == nil || catalog.IWYU == nil {
		t.Errorf("catalog missing entries: %+v", catalog)
	}
	// If any tool is marked Installed it must have a non-empty Version and Path.
	for name, info := range catalog.AsMap() {
		if info.Installed && info.Version == "" {
			t.Errorf("%s marked installed but Version empty: %+v", name, info)
		}
		if info.Installed && info.Path == "" {
			t.Errorf("%s marked installed but Path empty: %+v", name, info)
		}
		if !info.Installed && info.Error == "" {
			t.Errorf("%s marked NOT installed but Error empty: %+v", name, info)
		}
	}
}

func TestListToolsTool_MirrorsResourceCatalog(t *testing.T) {
	// Gate open: all four tools must appear in the advertised catalog.
	t.Setenv(hyperfineOptInEnv, "1")
	tb := &PerfToolbox{tools: DetectTools()}
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: json.RawMessage(`{}`)}}
	result, err := tb.listToolsTool(t.Context(), req)
	if err != nil {
		t.Fatalf("listToolsTool: %v", err)
	}
	if result.IsError {
		t.Fatalf("unexpected IsError")
	}
	if len(result.Content) == 0 {
		t.Fatal("empty Content")
	}
	text := result.Content[0].(*mcp.TextContent).Text
	// Same JSON catalog shape as resource://tools — must mention all four tool names.
	for _, name := range []string{"clang-tidy", "hyperfine", "llvm-objdump", "include-what-you-use"} {
		if !strings.Contains(text, name) {
			t.Errorf("list_tools output missing entry for %q: %s", name, text)
		}
	}
}

// TestListToolsTool_HidesHyperfineWhenGateClosed guards the discovery
// contract: when the hyperfine gate is CLOSED, list_tools must NOT
// advertise hyperfine, so a client following "check tools first, then
// call" never attempts a tools/call that would 404. Otherwise the
// contract regresses from "callable if advertised" to "maybe callable".
func TestListToolsTool_HidesHyperfineWhenGateClosed(t *testing.T) {
	t.Setenv(hyperfineOptInEnv, "")
	tb := &PerfToolbox{tools: DetectTools()}
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: json.RawMessage(`{}`)}}
	result, err := tb.listToolsTool(t.Context(), req)
	if err != nil {
		t.Fatalf("listToolsTool: %v", err)
	}
	text := result.Content[0].(*mcp.TextContent).Text
	if strings.Contains(text, "hyperfine") {
		t.Errorf("hyperfine advertised despite closed gate; list_tools output: %s", text)
	}
	// The other three remain visible.
	for _, name := range []string{"clang-tidy", "llvm-objdump", "include-what-you-use"} {
		if !strings.Contains(text, name) {
			t.Errorf("non-gated tool %q missing from list_tools: %s", name, text)
		}
	}
}

func TestToolsResource_ReturnsJSONCatalog(t *testing.T) {
	// Gate open: all four tools must appear in the JSON body.
	t.Setenv(hyperfineOptInEnv, "1")
	srv := &PerfToolbox{tools: DetectTools()}

	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://tools"

	result, err := srv.getToolsResource(t.Context(), req)
	if err != nil {
		t.Fatalf("getToolsResource: %v", err)
	}
	if len(result.Contents) == 0 {
		t.Fatal("empty Contents")
	}
	rc := result.Contents[0]
	if rc == nil || rc.Text == "" {
		t.Fatalf("Contents[0] has no text: %+v", rc)
	}

	var parsed map[string]any
	if err := json.Unmarshal([]byte(rc.Text), &parsed); err != nil {
		t.Fatalf("resource text is not valid JSON: %v\n%s", err, rc.Text)
	}
	for _, key := range []string{"clang-tidy", "hyperfine", "llvm-objdump", "include-what-you-use"} {
		if _, ok := parsed[key]; !ok {
			t.Errorf("catalog missing key %q in JSON: %s", key, rc.Text)
		}
	}
}

// TestToolsResource_HidesHyperfineWhenGateClosed — resource-transport
// twin of the list_tools test. Discovery must stay consistent across
// both transports.
func TestToolsResource_HidesHyperfineWhenGateClosed(t *testing.T) {
	t.Setenv(hyperfineOptInEnv, "")
	srv := &PerfToolbox{tools: DetectTools()}
	req := &mcp.ReadResourceRequest{Params: &mcp.ReadResourceParams{}}
	req.Params.URI = "resource://tools"
	result, err := srv.getToolsResource(t.Context(), req)
	if err != nil {
		t.Fatalf("getToolsResource: %v", err)
	}
	rc := result.Contents[0]
	var parsed map[string]any
	if err := json.Unmarshal([]byte(rc.Text), &parsed); err != nil {
		t.Fatalf("invalid JSON: %v", err)
	}
	if _, has := parsed["hyperfine"]; has {
		t.Errorf("hyperfine key advertised despite closed gate: %s", rc.Text)
	}
	for _, key := range []string{"clang-tidy", "llvm-objdump", "include-what-you-use"} {
		if _, ok := parsed[key]; !ok {
			t.Errorf("non-gated tool %q missing from JSON: %s", key, rc.Text)
		}
	}
}

func TestClangTidy_ParsesRealOutput(t *testing.T) {
	cat := DetectTools()
	if !cat.ClangTidy.Installed {
		t.Skip("clang-tidy not on PATH; integration test skipped")
	}

	// Tiny C++ source with a clearly-flagged performance issue —
	// pass-by-value of a non-trivial type.
	dir := t.TempDir()
	srcPath := dir + "/t.cpp"
	if err := os.WriteFile(srcPath, []byte(
		"#include <string>\nvoid f(std::string s){(void)s;}\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	// Minimal compile_commands.json pointing at the temp file.
	ccPath := dir + "/compile_commands.json"
	cc := `[{"directory":"` + filepathFwd(dir) + `","file":"` + filepathFwd(srcPath) +
		`","command":"clang++ -std=c++17 -c ` + filepathFwd(srcPath) + `"}]`
	if err := os.WriteFile(ccPath, []byte(cc), 0o644); err != nil {
		t.Fatal(err)
	}

	tb := &PerfToolbox{tools: cat}
	args, _ := json.Marshal(map[string]any{
		"files":        []string{srcPath},
		"project_root": dir,
		"checks":       "performance-unnecessary-value-param",
	})
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: args}}

	result, err := tb.clangTidyTool(t.Context(), req)
	if err != nil {
		t.Fatalf("clangTidyTool: %v", err)
	}
	if result.IsError {
		t.Fatalf("tool returned IsError=true: %+v", contentText(result))
	}

	body := contentText(result)
	// Expect JSON with at least one diagnostic referencing our check.
	if !strings.Contains(body, "performance-unnecessary-value-param") {
		t.Errorf("expected performance-unnecessary-value-param diagnostic in output:\n%s", body)
	}
	// Must be valid JSON.
	var parsed map[string]any
	if err := json.Unmarshal([]byte(body), &parsed); err != nil {
		t.Fatalf("tool output is not valid JSON: %v\n%s", err, body)
	}
	if _, ok := parsed["diagnostics"]; !ok {
		t.Errorf("output JSON missing diagnostics key: %s", body)
	}
}

func TestValidateClangTidyInputs_DisallowedExtraArgs(t *testing.T) {
	tests := []string{
		"-load",
		"--load=plugin.so",
		"-fix",
		"--fix-errors",
		"--fix-notes", // implicitly enables --fix per clang-tidy docs
		"-fix-notes",  // single-dash form
		"--export-fixes=/tmp/fixes.yaml",
		"--config=path",    // config file can carry ExtraArgs / ExtraArgsBefore
		"-config-file=foo", // single-dash form
		"--config-file=/etc/x",
	}

	for _, arg := range tests {
		err := validateClangTidyInputs(".", []string{"main.cpp"}, []string{arg})
		if err == nil {
			t.Fatalf("expected error for disallowed arg %q", arg)
		}
	}
}

func TestValidateClangTidyInputs_RejectsDashPrefixedFiles(t *testing.T) {
	err := validateClangTidyInputs(".", []string{"--export-fixes=/tmp/pwned.yaml"}, nil)
	if err == nil {
		t.Fatal("expected error for dash-prefixed file path")
	}
}

func TestValidateClangTidyInputs_AllowsSafeArgs(t *testing.T) {
	err := validateClangTidyInputs(".", []string{"main.cpp"}, []string{"--quiet", "-header-filter=.*"})
	if err != nil {
		t.Fatalf("expected safe args to pass validation, got error: %v", err)
	}
}

// TestLLVMObjdumpTool_RejectsExtraArgsPathValuedFlag asserts the tool
// handler surface returns IsError for path-valued llvm-objdump flags
// like `--build-id=/tmp/foo` or `--dsym=/tmp/foo` that previously
// passed the basic "starts with -" gate but read attacker-chosen
// files.
func TestLLVMObjdumpTool_RejectsExtraArgsPathValuedFlag(t *testing.T) {
	root := t.TempDir()
	bin := filepath.Join(root, "build", "app.exe")
	if err := os.MkdirAll(filepath.Dir(bin), 0o755); err != nil {
		t.Fatalf("mkdir build dir: %v", err)
	}
	if err := os.WriteFile(bin, []byte("fake"), 0o644); err != nil {
		t.Fatalf("write fixture: %v", err)
	}
	tb := &PerfToolbox{tools: &ToolCatalog{
		LLVMObjdump: &ToolInfo{Installed: true, Path: "not-used"},
	}}

	cases := []struct {
		name      string
		extraArgs []string
	}{
		{"build-id-eq", []string{"--build-id=/tmp/foo"}},
		{"build-id-bare", []string{"--build-id"}},
		{"debug-file-directory-eq", []string{"--debug-file-directory=/tmp/foo"}},
		{"dsym-eq", []string{"--dsym=/tmp/foo"}},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			args, _ := json.Marshal(map[string]any{
				"binary":       bin,
				"project_root": root,
				"extra_args":   tc.extraArgs,
			})
			req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: args}}

			res, err := tb.llvmObjdumpTool(t.Context(), req)
			if err != nil {
				t.Fatalf("llvmObjdumpTool: %v", err)
			}
			if !res.IsError {
				t.Fatalf("expected IsError=true for hostile extra_args %v", tc.extraArgs)
			}
			if body := contentText(res); !strings.Contains(body, "path-valued") {
				t.Fatalf("expected path-valued error, got: %s", body)
			}
		})
	}
}

// contentText extracts the Text field from the first TextContent in a
// CallToolResult. Used by every handler test in this file.
func contentText(r *mcp.CallToolResult) string {
	if len(r.Content) == 0 {
		return ""
	}
	if tc, ok := r.Content[0].(*mcp.TextContent); ok {
		return tc.Text
	}
	return ""
}

// filepathFwd returns a filesystem path with forward slashes so it can
// be safely embedded inside a JSON string literal without escape hell.
func filepathFwd(p string) string {
	return strings.ReplaceAll(p, `\`, `/`)
}

func TestHyperfine_ComparesTwoCommands(t *testing.T) {
	cat := DetectTools()
	if !cat.Hyperfine.Installed {
		t.Skip("hyperfine not on PATH; integration test skipped")
	}

	tb := &PerfToolbox{tools: cat}
	// Shell builtins are available on both Windows and POSIX. Select the
	// shell explicitly so hyperfine does not infer a command execution mode.
	commands := []string{"echo first", "echo second"}
	args, _ := json.Marshal(map[string]any{
		"commands":   commands,
		"extra_args": []string{"--shell=default"},
		"warmup":     1,
		"min_runs":   3,
		"max_runs":   5,
	})
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: args}}

	result, err := tb.hyperfineTool(t.Context(), req)
	if err != nil {
		t.Fatalf("hyperfineTool: %v", err)
	}
	if result.IsError {
		t.Fatalf("tool returned IsError=true: %s", contentText(result))
	}

	body := contentText(result)
	var parsed struct {
		Results []struct {
			Command string   `json:"command"`
			Mean    *float64 `json:"mean"`
			Summary struct {
				TimeWallClock struct {
					Mean *float64 `json:"mean"`
					Unit string   `json:"unit"`
				} `json:"time_wall_clock"`
			} `json:"summary"`
		} `json:"results"`
	}
	if err := json.Unmarshal([]byte(body), &parsed); err != nil {
		t.Fatalf("tool output not valid JSON: %v\n%s", err, body)
	}
	if len(parsed.Results) != len(commands) {
		t.Fatalf("expected %d results, got %+v", len(commands), parsed.Results)
	}
	// The adapter preserves the installed tool's JSON. Older hyperfine puts
	// mean at the result root; newer versions expose named timing summaries.
	for i, r := range parsed.Results {
		mean := r.Mean
		if mean == nil {
			mean = r.Summary.TimeWallClock.Mean
			if r.Summary.TimeWallClock.Unit != "second" {
				t.Errorf("results[%d] wall-clock unit = %q", i, r.Summary.TimeWallClock.Unit)
			}
		}
		if mean == nil || *mean < 0 {
			t.Errorf("results[%d] missing or negative wall-clock mean: %+v", i, r)
		}
		if r.Command != commands[i] {
			t.Errorf("results[%d] command = %q, want %q", i, r.Command, commands[i])
		}
	}
}

func TestLLVMObjdump_DisassemblesBinary(t *testing.T) {
	cat := DetectTools()
	if !cat.LLVMObjdump.Installed {
		t.Skip("llvm-objdump not on PATH; integration test skipped")
	}
	if _, err := exec.LookPath("go"); err != nil {
		t.Skip("go toolchain not on PATH; integration test skipped")
	}

	// Build a small dedicated binary with symbols intact. The `go test`
	// harness links its own test binary with `-s -w`, which strips the
	// classic symbol table and would cause llvm-objdump to emit
	// "missing symbol" when we pass --disassemble-symbols.
	tmp := t.TempDir()
	src := filepath.Join(tmp, "main.go")
	if err := os.WriteFile(src, []byte("package main\nfunc main() { println(\"ok\") }\n"), 0o644); err != nil {
		t.Fatalf("write src: %v", err)
	}
	exe := filepath.Join(tmp, "hello.exe")
	build := exec.Command("go", "build", "-o", exe, src)
	build.Env = append(os.Environ(), "GOFLAGS=")
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("go build: %v: %s", err, out)
	}

	tb := &PerfToolbox{tools: cat}
	// Narrow to the main symbol so the disassembly stays well under the
	// handler's bounded output cap.
	args, _ := json.Marshal(map[string]any{
		"binary":       exe,
		"project_root": tmp,
		"function":     "main.main",
	})
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: args}}

	result, err := tb.llvmObjdumpTool(t.Context(), req)
	if err != nil {
		t.Fatalf("llvmObjdumpTool: %v", err)
	}
	if result.IsError {
		t.Fatalf("tool returned IsError=true: %s", contentText(result))
	}

	body := contentText(result)
	// At minimum the disassembly should contain a section marker.
	if !strings.Contains(body, "Disassembly") && !strings.Contains(body, "section") {
		t.Errorf("expected disassembly header in output:\n%s", body[:min(len(body), 500)])
	}
}

func TestIWYU_ParsesSuggestions(t *testing.T) {
	cat := DetectTools()
	if !cat.IWYU.Installed {
		t.Skip("include-what-you-use not on PATH; integration test skipped")
	}

	// Minimal source with a deliberately unused include — iwyu should flag it.
	dir := t.TempDir()
	srcPath := dir + "/t.cpp"
	if err := os.WriteFile(srcPath, []byte(
		"#include <string>\n#include <vector>\nint main(){std::vector<int> v; (void)v; return 0;}\n"),
		0o644); err != nil {
		t.Fatal(err)
	}

	tb := &PerfToolbox{tools: cat}
	args, _ := json.Marshal(map[string]any{
		"file":         srcPath,
		"project_root": dir,
		"extra_args":   []string{"-std=c++17"},
	})
	req := &mcp.CallToolRequest{Params: &mcp.CallToolParamsRaw{Arguments: args}}

	result, err := tb.iwyuTool(t.Context(), req)
	if err != nil {
		t.Fatalf("iwyuTool: %v", err)
	}
	if result.IsError {
		// iwyu can fail for environmental reasons (missing stdlib headers in
		// the temp compile) — treat as skip rather than test failure.
		t.Skipf("iwyu returned IsError, treating as environment skip: %s",
			contentText(result))
	}

	body := contentText(result)
	var parsed map[string]any
	if err := json.Unmarshal([]byte(body), &parsed); err != nil {
		t.Fatalf("tool output not valid JSON: %v\n%s", err, body)
	}
	// At minimum the response carries a reports[] array.
	reports, ok := parsed["reports"].([]any)
	if !ok {
		t.Fatalf("expected reports[] in output, got: %+v", parsed)
	}
	if len(reports) == 0 {
		// Allow graceful skip if iwyu produced no parseable blocks — this
		// can happen if iwyu's output format varies by version.
		t.Skip("reports[] is empty — iwyu produced no parseable output for the test file")
	}
}
