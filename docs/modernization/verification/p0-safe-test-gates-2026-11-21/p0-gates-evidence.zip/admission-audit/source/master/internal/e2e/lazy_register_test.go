// Package e2e — end-to-end integration tests that straddle the api +
// daemon packages. Living here rather than inside internal/api avoids the
// import cycle that would arise from api -> daemon -> api.
package e2e

import (
	"bytes"
	"context"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"mcp-local-hub/internal/api"
	"mcp-local-hub/internal/api/apitest"
	"mcp-local-hub/internal/clients"
	"mcp-local-hub/internal/config"
	"mcp-local-hub/internal/daemon"
	"mcp-local-hub/internal/scheduler"
)

// fakeScheduler implements api.TestSchedulerIface and records Create calls
// so the test can inspect scheduler state.
type fakeScheduler struct {
	tasks        map[string]bool
	xml          map[string][]byte
	createdSpecs []scheduler.TaskSpec
	createErr    error
}

func newFakeScheduler() *fakeScheduler {
	return &fakeScheduler{tasks: map[string]bool{}, xml: map[string][]byte{}}
}

func (f *fakeScheduler) Create(spec scheduler.TaskSpec) error {
	if f.createErr != nil {
		return f.createErr
	}
	exported := fakeSchedulerXMLForSpec(spec)
	f.tasks[spec.Name] = true
	f.xml[spec.Name] = append([]byte(nil), exported...)
	f.createdSpecs = append(f.createdSpecs, spec)
	return nil
}
func (f *fakeScheduler) Delete(name string) error {
	delete(f.tasks, name)
	delete(f.xml, name)
	return nil
}
func (f *fakeScheduler) Run(name string) error { return nil }
func (f *fakeScheduler) ExportXML(name string) ([]byte, error) {
	if b, ok := f.xml[name]; ok {
		return append([]byte(nil), b...), nil
	}
	return nil, scheduler.ErrTaskNotFound
}
func (f *fakeScheduler) ImportXML(name string, xml []byte) error {
	f.xml[name] = append([]byte(nil), xml...)
	f.tasks[name] = true
	return nil
}

// fakeSchedulerXMLForSpec projects TaskSpec into the Task Scheduler XML shape
// consumed by the API's post-create verifier. It is generic over the supplied
// task data: no task name, command, arguments, path, or schedule is special.
func fakeSchedulerXMLForSpec(spec scheduler.TaskSpec) []byte {
	xmlText := func(value string) string {
		var escaped bytes.Buffer
		_ = xml.EscapeText(&escaped, []byte(value))
		return escaped.String()
	}
	trigger := ""
	if spec.WeeklyTrigger != nil {
		days := []string{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}
		trigger = fmt.Sprintf(
			`<CalendarTrigger><StartBoundary>2026-01-04T%02d:%02d:00</StartBoundary><Enabled>true</Enabled><ScheduleByWeek><DaysOfWeek><%s/></DaysOfWeek><WeeksInterval>1</WeeksInterval></ScheduleByWeek></CalendarTrigger>`,
			spec.WeeklyTrigger.HourLocal,
			spec.WeeklyTrigger.MinuteLocal,
			days[spec.WeeklyTrigger.DayOfWeek],
		)
	}
	restart := ""
	if spec.RestartOnFailure {
		restart = "<RestartOnFailure><Interval>PT1M</Interval><Count>3</Count></RestartOnFailure>"
	}
	return []byte(fmt.Sprintf(
		`<Task><RegistrationInfo><Description>%s</Description></RegistrationInfo><Triggers>%s</Triggers><Principals><Principal id="Author"><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals><Settings>%s<AllowHardTerminate>true</AllowHardTerminate><StartWhenAvailable>false</StartWhenAvailable><RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable><MultipleInstancesPolicy>StopExisting</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>false</Hidden><RunOnlyIfIdle>false</RunOnlyIfIdle><WakeToRun>false</WakeToRun><ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Priority>7</Priority></Settings><Actions Context="Author"><Exec><Command>%s</Command><Arguments>%s</Arguments><WorkingDirectory>%s</WorkingDirectory></Exec></Actions></Task>`,
		xmlText(spec.Description),
		trigger,
		restart,
		xmlText(spec.Command),
		xmlText(strings.Join(spec.Args, " ")),
		xmlText(spec.WorkingDir),
	))
}

func TestFakeScheduler_CreateExportDeleteRestoreContract(t *testing.T) {
	sch := newFakeScheduler()
	spec := scheduler.TaskSpec{
		Name:        "contract-task",
		Description: "contract description",
		Command:     `C:\test\mcphub.exe`,
		Args:        []string{"workspace-weekly-refresh"},
		WorkingDir:  `C:\test`,
		WeeklyTrigger: &scheduler.WeeklyTrigger{
			DayOfWeek: 2, HourLocal: 4, MinuteLocal: 35,
		},
	}
	if err := sch.Create(spec); err != nil {
		t.Fatalf("Create: %v", err)
	}
	exported, err := sch.ExportXML(spec.Name)
	if err != nil {
		t.Fatalf("ExportXML after Create: %v", err)
	}
	if want := fakeSchedulerXMLForSpec(spec); !bytes.Equal(exported, want) {
		t.Fatalf("ExportXML after Create differs from created task data:\n got %s\nwant %s", exported, want)
	}
	if !sch.tasks[spec.Name] || len(sch.createdSpecs) != 1 {
		t.Fatalf("Create state = task present %v, specs %d; want true, 1", sch.tasks[spec.Name], len(sch.createdSpecs))
	}

	if err := sch.Delete(spec.Name); err != nil {
		t.Fatalf("Delete: %v", err)
	}
	if sch.tasks[spec.Name] {
		t.Fatal("Delete left task presence behind")
	}
	if _, err := sch.ExportXML(spec.Name); !errors.Is(err, scheduler.ErrTaskNotFound) {
		t.Fatalf("ExportXML after Delete error = %v, want ErrTaskNotFound", err)
	}

	if err := sch.ImportXML(spec.Name, exported); err != nil {
		t.Fatalf("ImportXML restore: %v", err)
	}
	restored, err := sch.ExportXML(spec.Name)
	if err != nil {
		t.Fatalf("ExportXML after restore: %v", err)
	}
	if !sch.tasks[spec.Name] || !bytes.Equal(restored, exported) {
		t.Fatalf("restored state = task present %v, XML equal %v; want true, true", sch.tasks[spec.Name], bytes.Equal(restored, exported))
	}
}

func TestFakeScheduler_FailedCreateDoesNotPublishTask(t *testing.T) {
	sch := newFakeScheduler()
	createErr := errors.New("injected create failure")
	sch.createErr = createErr
	spec := scheduler.TaskSpec{Name: "failed-contract-task", Command: `C:\test\mcphub.exe`}

	if err := sch.Create(spec); !errors.Is(err, createErr) {
		t.Fatalf("Create error = %v, want %v", err, createErr)
	}
	if sch.tasks[spec.Name] || len(sch.createdSpecs) != 0 {
		t.Fatalf("failed Create published state = task present %v, specs %d; want false, 0", sch.tasks[spec.Name], len(sch.createdSpecs))
	}
	if _, err := sch.ExportXML(spec.Name); !errors.Is(err, scheduler.ErrTaskNotFound) {
		t.Fatalf("ExportXML after failed Create error = %v, want ErrTaskNotFound", err)
	}
}

// fakeClient implements api.TestClientIface. A parent map is shared across
// every client instance so tests can count total entries across clients.
type fakeClientsMap struct {
	entries map[string]map[string]string
	exists  map[string]bool
}

type fakeClient struct {
	parent *fakeClientsMap
	name   string
}

func (c *fakeClient) Exists() bool { return c.parent.exists[c.name] }
func (c *fakeClient) BackupKeep(keepN int) (string, error) {
	return fmt.Sprintf("/backup/%s/%d", c.name, keepN), nil
}
func (c *fakeClient) AddEntry(e clients.MCPEntry) error {
	c.parent.entries[c.name][e.Name] = e.URL
	return nil
}
func (c *fakeClient) RemoveEntry(name string) error {
	delete(c.parent.entries[c.name], name)
	return nil
}
func (c *fakeClient) GetEntry(name string) (*clients.MCPEntry, error) {
	url, ok := c.parent.entries[c.name][name]
	if !ok {
		return nil, nil
	}
	return &clients.MCPEntry{Name: name, URL: url}, nil
}
func (c *fakeClient) AllStdioEntries() ([]clients.StdioEntry, error) {
	return nil, nil
}
func (c *fakeClient) FindStdioLanguageServerEntries() ([]clients.LanguageServerStdioEntry, error) {
	return nil, nil
}

func countEntries(fc *fakeClientsMap) int {
	n := 0
	for _, m := range fc.entries {
		n += len(m)
	}
	return n
}

// fakeLifecycle is the BackendLifecycle double used by the E2E test. It
// replaces the real subprocess spawner so the test never touches a real
// LSP binary.
type fakeLifecycle struct {
	kind             string
	materializeCount atomic.Int32
	stopCount        atomic.Int32
}

func (f *fakeLifecycle) Kind() string { return f.kind }

func (f *fakeLifecycle) Materialize(ctx context.Context) (daemon.MCPEndpoint, error) {
	f.materializeCount.Add(1)
	return &fakeEndpoint{}, nil
}

func (f *fakeLifecycle) Stop() error { f.stopCount.Add(1); return nil }

type fakeEndpoint struct{ closed atomic.Bool }

func (e *fakeEndpoint) SendRequest(ctx context.Context, req *daemon.JSONRPCRequest) (*daemon.JSONRPCResponse, error) {
	if e.closed.Load() {
		return nil, errors.New("endpoint closed")
	}
	return &daemon.JSONRPCResponse{
		Jsonrpc: "2.0",
		ID:      req.ID,
		Result:  json.RawMessage(`{"ok":true}`),
	}, nil
}

func (e *fakeEndpoint) Close() error { e.closed.Store(true); return nil }

// TestE2E_LazyRegisterFullLifecycle exercises the full workspace-scoped
// lazy flow in-process:
//
//  1. api.Register(workspace, ["python"]) — allocates port, creates
//     scheduler task, writes client entries, seeds LifecycleConfigured.
//  2. LazyProxy from internal/daemon wrapped in httptest.Server replaces
//     the subprocess the scheduler would normally launch.
//  3. Client posts initialize + tools/list — synthetic responses, no
//     materialization.
//  4. Client posts tools/call — triggers materialization; registry shows
//     LifecycleActive.
//  5. Status reflects the 5-state lifecycle on the row.
//  6. api.Unregister(workspace, nil) — scheduler task deleted, unproven
//     client entries preserved with a typed warning, registry empty.
func TestE2E_LazyRegisterFullLifecycle(t *testing.T) {
	if runtime.GOOS != "windows" {
		// api.Status calls scheduler.New() directly (no test seam), and
		// the Linux/macOS scheduler returns "linux scheduler not yet
		// implemented" until F2 (systemd backend) lands. The e2e flow
		// reaches Status() at step 4 to assert lifecycle progression,
		// so the test can't run on non-Windows even though Register's
		// scheduler use IS faked via api.InstallTestHooks. Tracked as
		// backlog F2 (Linux scheduler) + a follow-up Status test seam.
		t.Skip("e2e flow exercises api.Status which uses real scheduler.New(); not implemented on non-Windows yet")
	}
	stateDir := apitest.HardenedTempDir(t)
	defer api.SetDaemonStateRootForTest(stateDir)()
	t.Setenv("MCPHUB_E2E_SCHEDULER", "none")

	dir := t.TempDir()
	regPath := filepath.Join(stateDir, "workspaces.yaml")

	sch := newFakeScheduler()
	fc := &fakeClientsMap{
		entries: map[string]map[string]string{"codex-cli": {}},
		exists:  map[string]bool{"codex-cli": true},
	}
	restore := api.InstallTestHooks(
		func() (api.TestSchedulerIface, error) { return sch, nil },
		func() map[string]api.TestClientIface {
			return map[string]api.TestClientIface{"codex-cli": &fakeClient{parent: fc, name: "codex-cli"}}
		},
		regPath,
	)
	defer restore()

	// Stub the canonical mcphub binary so Register's `mcphub setup`
	// preflight succeeds. CI runners (and any clean dev box without a
	// prior `mcphub setup`) lack ~/.local/bin/mcphub, so without this
	// override the very first Register call fails with a "run mcphub
	// setup once" error before the lazy-lifecycle path is exercised.
	stubPath := filepath.Join(dir, api.MCPHubBinaryName())
	if err := os.WriteFile(stubPath, []byte("stub-binary\n"), 0o755); err != nil {
		t.Fatalf("create stub mcphub binary: %v", err)
	}
	defer api.SetTestCanonicalMcphubPath(stubPath)()

	ws := t.TempDir()
	m := &config.ServerManifest{
		Name:     "mcp-language-server",
		Kind:     config.KindWorkspaceScoped,
		PortPool: &config.PortPool{Start: 9400, End: 9599},
		Languages: []config.LanguageSpec{
			{Name: "python", Backend: "mcp-language-server", Transport: "stdio", LspCommand: "pyright-langserver", ExtraFlags: []string{"--stdio"}},
		},
		ClientBindings: []config.ClientBinding{{Client: "codex-cli", URLPath: "/mcp"}},
	}
	_ = m // retained for documentation; Register loads the embedded manifest

	// --- Step 1: Register -------------------------------------------------
	//
	// api.Register consumes the SHIPPED mcp-language-server manifest from
	// the embedded FS, not the one we constructed above. That is fine —
	// we only need a valid (workspace, python) registration to drive the
	// subsequent proxy test. We ask explicitly for python to keep the
	// fake-client matrix tiny.
	a := api.NewAPI()
	buf := &bytes.Buffer{}
	report, err := a.Register(ws, []string{"python"}, api.RegisterOpts{Writer: buf})
	if err != nil {
		t.Fatalf("Register: %v", err)
	}
	if len(report.Entries) != 1 {
		t.Fatalf("Register entries = %d, want 1", len(report.Entries))
	}

	// Registry observations.
	reg := api.NewRegistry(regPath)
	if err := reg.Load(); err != nil {
		t.Fatal(err)
	}
	if len(reg.Workspaces) != 1 {
		t.Fatalf("registry len = %d, want 1", len(reg.Workspaces))
	}
	entry := reg.Workspaces[0]
	if entry.Lifecycle != api.LifecycleConfigured {
		t.Errorf("initial Lifecycle = %q, want %q", entry.Lifecycle, api.LifecycleConfigured)
	}
	if entry.Port < 9400 || entry.Port > 9599 {
		t.Errorf("Port = %d, outside pool [9400-9599]", entry.Port)
	}
	expectedTask := fmt.Sprintf("mcp-local-hub-lsp-%s-python", entry.WorkspaceKey)
	if entry.TaskName != expectedTask {
		t.Errorf("TaskName = %q, want %q", entry.TaskName, expectedTask)
	}

	// Scheduler side effect: a daemon workspace-proxy task was created.
	sawProxy := false
	for _, s := range sch.createdSpecs {
		if len(s.Args) >= 2 && s.Args[0] == "daemon" && s.Args[1] == "workspace-proxy" {
			sawProxy = true
			break
		}
	}
	if !sawProxy {
		t.Error("scheduler did not receive a daemon workspace-proxy spec")
	}
	// And the shared weekly-refresh task (from M4 Ensure wire-in M5 fix).
	if !sch.tasks[api.WeeklyRefreshTaskName] {
		t.Errorf("shared weekly-refresh task %q not created", api.WeeklyRefreshTaskName)
	}

	// Client side effect.
	if n := countEntries(fc); n != 1 {
		t.Errorf("client entries after Register = %d, want 1", n)
	}
	clientBefore, err := json.Marshal(fc.entries)
	if err != nil {
		t.Fatalf("snapshot client entries after Register: %v", err)
	}

	// --- Step 2: Spin up the lazy proxy wrapped in httptest.Server --------
	fake := &fakeLifecycle{kind: "mcp-language-server"}
	proxy := daemon.NewLazyProxy(daemon.LazyProxyConfig{
		WorkspaceKey:  entry.WorkspaceKey,
		WorkspacePath: entry.WorkspacePath,
		Language:      "python",
		BackendKind:   "mcp-language-server",
		Port:          0, // httptest picks; the registry row stores the scheduler port
		Lifecycle:     fake,
		RegistryPath:  regPath,
	})
	srv := httptest.NewServer(proxy.Handler())
	defer srv.Close()

	postJSON := func(body string) string {
		req, _ := http.NewRequest(http.MethodPost, srv.URL+"/mcp", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Accept", "application/json, text/event-stream")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("post: %v", err)
		}
		defer resp.Body.Close()
		b, _ := io.ReadAll(resp.Body)
		return string(b)
	}

	// --- Step 3: initialize + tools/list are synthetic --------------------
	initResp := postJSON(`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"e2e","version":"1"}}}`)
	if !strings.Contains(initResp, "serverInfo") {
		t.Errorf("initialize response missing serverInfo: %s", initResp)
	}
	listResp := postJSON(`{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}`)
	if !strings.Contains(listResp, "tools") {
		t.Errorf("tools/list response missing tools: %s", listResp)
	}
	if got := fake.materializeCount.Load(); got != 0 {
		t.Fatalf("materialize called %d times during synthetic handshake, want 0", got)
	}

	// --- Step 4: tools/call triggers exactly one materialization ---------
	callResp := postJSON(`{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"hover","arguments":{}}}`)
	if !strings.Contains(callResp, "\"ok\":true") {
		t.Errorf("tools/call forwarded response missing ok payload: %s", callResp)
	}
	if got := fake.materializeCount.Load(); got != 1 {
		t.Errorf("materialize called %d times after first tools/call, want 1", got)
	}

	// Wait briefly for the proxy's PutLifecycleWithTimestamps to settle.
	time.Sleep(20 * time.Millisecond)
	if err := reg.Load(); err != nil {
		t.Fatal(err)
	}
	afterCall := reg.Workspaces[0]
	if afterCall.Lifecycle != api.LifecycleActive {
		t.Errorf("post-materialize Lifecycle = %q, want %q", afterCall.Lifecycle, api.LifecycleActive)
	}
	if afterCall.LastMaterializedAt.IsZero() {
		t.Error("LastMaterializedAt should be stamped after materialization")
	}

	// --- Step 5: Status fails loud without a supervisor -------------------
	// Status must return ErrSupervisorDown when its IPC-backed daemon-state
	// source is unavailable; lifecycle persistence was verified above.
	_, err = a.Status()
	if !errors.Is(err, api.ErrSupervisorDown) {
		t.Fatalf("Status error = %v, want ErrSupervisorDown", err)
	}

	// --- Step 6: Unregister ----------------------------------------------
	unregisterReport, err := a.Unregister(ws, nil)
	if err != nil {
		t.Fatalf("Unregister: %v", err)
	}
	if err := reg.Load(); err != nil {
		t.Fatal(err)
	}
	if len(reg.Workspaces) != 0 {
		t.Errorf("registry len after Unregister = %d, want 0", len(reg.Workspaces))
	}
	clientAfter, err := json.Marshal(fc.entries)
	if err != nil {
		t.Fatalf("snapshot client entries after Unregister: %v", err)
	}
	if !bytes.Equal(clientAfter, clientBefore) {
		t.Errorf("unproven client entries changed after Unregister: before=%s after=%s", clientBefore, clientAfter)
	}
	preserved := false
	for _, diagnostic := range unregisterReport.Diagnostics() {
		if diagnostic.Code() == api.RegistrationCodeUnregisterClientPreserved &&
			diagnostic.Severity() == api.RegistrationSeverityWarning &&
			diagnostic.Participant() == "codex-cli" && diagnostic.PlanIdentity() == entry.ClientEntries["codex-cli"] {
			preserved = true
		}
	}
	if !preserved || len(unregisterReport.Warnings) == 0 {
		t.Errorf("Unregister diagnostics=%+v warnings=%v, want client preservation warning for codex-cli/%s", unregisterReport.Diagnostics(), unregisterReport.Warnings, entry.ClientEntries["codex-cli"])
	}
	if sch.tasks[entry.TaskName] {
		t.Errorf("scheduler still has task %q after Unregister", entry.TaskName)
	}

	// --- Cleanup: close the proxy so Stop() path is exercised once -------
	shutdownCtx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := proxy.Stop(shutdownCtx); err != nil {
		t.Errorf("proxy.Stop: %v", err)
	}
	if got := fake.stopCount.Load(); got != 1 {
		t.Errorf("lifecycle.Stop count = %d, want 1", got)
	}
}
