# Вход в полный Go gate: исходники, изоляция и реальные процессы

Дата: 2026-11-21. Репозиторий: `applicate2628/mcp-local-hub`. База — `75dbc6406123e22468f168b861d5e0622c9d5769`; PR #658 — `f9966f008aed4d0cfa80d88cc80c12d08e03634f`.

## Оглавление

1. [Результат и предел проверки](#результат-и-предел-проверки)
2. [Недостающая изоляция и минимальная композиция](#недостающая-изоляция-и-минимальная-композиция)
3. [Все найденные TestMain](#все-найденные-testmain)
4. [Входы до Skip и внешние процессы](#входы-до-skip-и-внешние-процессы)
5. [Контракты ранних helpers](#контракты-ранних-helpers)
6. [Что можно проверять следующим этапом](#что-можно-проверять-следующим-этапом)
7. [Артефакты и проверка исходников](#артефакты-и-проверка-исходников)

## Результат и предел проверки

Восстановлен адресный изоляционный остаток #658: **четыре новых TestMain и двенадцать изменённых тестовых файлов**, включая один benchmark. Существующие API test hooks и поддержка защищённых временных каталогов уже присутствуют в master; широкое перенесение production-кода для этой изоляции не требуется. Точные 16 путей и Git blob SHA приведены в [манифесте overlay](test-isolation-overlay-manifest.json).

**Полный `go test ./...` по этому аудиту не запущен и не допущен одним лишь перенаправлением среды.** Выключение opt-in переменных и `-short` не устраняет все реальные процессы: часть discovery запускает утилиты до `Skip`, часть обычных тестов компилирует новые бинарники или выполняет shell, а обязательный native CLI oracle требует квалифицированного Product. Следующий максимум — offline компиляция с уже доступными зависимостями, точные квалифицированные fixtures и отдельная проверка существующих внешних инструментов. Пропущенный обязательный oracle нельзя объявить зелёным полным gate.

Здесь **D** означает заранее созданную и проверенную владельцем область внутри `D:\dev\ChatGPT`. `argv` — полный массив аргументов процесса; `cwd` — его рабочий каталог; IPC — межпроцессное взаимодействие; ACL — список прав доступа. Абсолютный путь или значение TEMP/HOME не доказывает принадлежность D, отсутствие junction/reparse в предках или устойчивость пространства имён к подмене.

Прочитаны точные деревья и целевые исходники, а не выполнены тела всех 1368 тестовых файлов. В master дерево содержит 1368 `_test.go` в 64 каталогах; вложенный модуль `third_party/gofrs-flock` имеет свой `go.mod` и четыре файла. После его исключения остаётся 1364 файла в 63 каталогах. Это **не** число пакетов, реально выбранных Go для ОС/архитектуры/build tags; соответствующая статическая инвентаризация — [test-package-inventory.json](test-package-inventory.json).

## Недостающая изоляция и минимальная композиция

**Таблица 1. Новые в #658 владельцы package-wide state root.**

| Путь | Обычный вход и cleanup | Композиционное условие |
|---|---|---|
| `internal/daemon/main_test.go:37` | После helper admission: MkdirTemp → HardenedDirForTestMain → API override/cache reset → m.Run → restore/reset → RemoveTestMainRoot → exit | Использовать проверяемый локальный daemon candidate и companion `host_original_windows_test.go`; исходный #658 admission не знает master-only private fixture |
| `internal/api/lsp_routing/main_test.go:15` | Тот же самостоятельный жизненный цикл state root | Импорт пакета API не выполняет API TestMain; этот файл реально нужен этому test executable |
| `internal/api/serena_routing/main_test.go:15` | Самостоятельный защищённый state root и явный cleanup после m.Run | Нужен независимо от LSP/API test executable |
| `internal/oneapirun/main_test.go:16` | Самостоятельный защищённый API state root, сброс strict-mode cache и явный cleanup | Не перенаправляет автоматически `hubtemp.Dir` или выбранные внешние shell/cache пути |

Все четыре исходника создают свой первый каталог через `os.MkdirTemp("", …)`. Следовательно, внешний TEMP/TMP/TMPDIR должен указывать на подготовленную область **до старта test executable**. Установка environment внутри тестовой функции для этого первого действия запоздает. `HardenedDirForTestMain` нужен до тестовых потомков; cleanup исполняется явно, поскольку `os.Exit` не выполняет defer.

**Таблица 2. Остальные адресные overlay источники.** Полные SHA и обе исходные версии есть в JSON.

| Каталог | Точные имена файлов | Назначение / ограничение |
|---|---|---|
| `cmd/mcphub` | `main_test.go` | Убирает наследованный NoAutoGUI из callback fixtures; это не TestMain |
| `internal/api/lsp_routing` | `resolver_test.go`, `resolver_benchmark_test.go` | Защищённые временные state roots; второй файл относится к benchmarks |
| `internal/api/serena_routing` | `resolver_test.go`, `shared_observer_public_test.go` | Защищённые roots; resolver delta также меняет сравнение allocations, поэтому это не только механическая замена TempDir |
| `internal/cli` | `gui_force_test.go`, `supervise_reconcile_ipc_test.go` | Защищённые fixtures и fake Scheduler List до dispatch. Для gui_force использовать CLI candidate с двумя дополнительными `-NoProfile/-NonInteractive` |
| `internal/daemon` | `host_original_windows_test.go`, `lazy_proxy_test.go`, `lazy_proxy_readiness_test.go` | Companion переносит оригинальные helper constants/устанавливает native checker; два lazy файла защищают конкретные roots |
| `internal/oneapirun` | `async_owner_test.go`, `async_test.go` | Защищённые per-test state roots |

Манифест описывает изоляционную семью, а не отменяет сохранённый root полезный остаток полного PR. Он не разрешает merge PR или замену master деревом #658. Master-only `internal/daemon/isolated_stdio_windows_test.go` остаётся источником настоящего `TestOwnedIsolatedStdioFixture`; добавлять вторую реализацию helper в #658 не требуется. Локальные daemon/CLI/API candidates применяются адресно и не перезаписываются исходным overlay поверх них.

Девять support-файлов API в манифесте имеют одинаковые blob SHA в обеих версиях, в том числе `internal/api/testhooks.go`, `internal/api/apitest/hardened_tempdir_{posix,windows}.go` и `internal/api/apitest/testmain_cleanup.go`. Это подтверждённая совместимость исходных API, не результат компиляции.

## Все найденные TestMain

**Таблица 3. Восемь уже существующих TestMain в точном master.** Вместе с Таблицей 1 это двенадцать входов композиции; ОС/build tags определяют их участие в конкретном запуске.

| Исходник | Существенный вход до обычных тестов |
|---|---|
| `internal/api/main_test.go:65` | Сначала caller-start-time oracle; обычный путь устанавливает IPC discriminator, API state override, client environment/audit и тестовые seams. Отдельный API candidate расширяет helper admission с сохранением этого tail |
| `internal/api/daemon_env_overlay/main_test.go:44` | MkdirTemp, API root override/cache reset, m.Run, restore/RemoveAll. Не переносить повторно: оба blob одинаковы |
| `internal/gui/main_test.go:195` | Классифицирует GUI helpers до root; normal path создаёт свой state/client layout, IPC discriminator и audit. Возвращающиеся helpers нельзя автоматически переводить в новый ранний путь |
| `internal/mcproute/main_test.go:15` | Уже создаёт защищённый state root, API override, client env/audit и cleanup. Новый дублирующий TestMain не нужен |
| `internal/cli/settings_registry_test.go:292` | Старые direct/selected-test roles; normal path содержит no-op reconcile default, IPC discriminator, state/client isolation/audit и cleanup. CLI candidate сохраняет normal tail |
| `internal/cbuild/handlers_test.go:19` | Marker-only fake executable branches до m.Run; обычного package state root здесь нет |
| `internal/sonnet/strict_driver_test.go:21` | `MCPHUB_SONNET_STRICT_DRIVER_HELPER_EXIT`: stdout/stderr и os.Exit до m.Run. Этот Sonnet — инженерный симулятор, не внешний языковой model provider |
| `internal/vcpkgmcp/pinstatus/remote_process_linux_test.go:18` | Linux-only procfs classifier raw command; обычный путь m.Run |

`go test -run '^$'` всё равно запускает init/TestMain. Это runtime smoke, а не compile-only проверка. Кроме TestMain есть более ранний CLI `init` actor в `upgrade_gui_qualified_fixture_windows_test.go:244`, включаемый собственным fixture marker; чистота marker environment нужна до входа процесса.

Для ordinary cbuild entry убрать наследованные `MCP_CBUILD_FAKE_CTEST`, `MCP_CBUILD_PROTOCOL_FAKE_CMAKE`, `MCP_CBUILD_FAKE_LIST`, `MCP_CBUILD_FAKE_ARGV`; они могут сделать ложный успешный ранний выход. Аналогично не наследовать Sonnet strict-driver helper marker, Kimi/remote-process helper markers и специальные CLI/API роли в обычный suite. Child markers передаются только соответствующим реальным parent fixtures.

API/CLI/GUI клиентский audit не просто считает ошибки после исполнения: его construction/access проверки могут прервать обращение до файлового ввода-вывода (`internal/clients/config_path_sandbox_audit.go:134–139,272–284`). Это полезный защитный контракт, но лексическая проверка client paths не заменяет native проверку владельца и предков. Native API state resolver на Windows может использовать KnownFolder API и игнорировать обычные переменные профиля; поэтому process-local API override и отдельный subprocess contract нужны оба.

## Входы до Skip и внешние процессы

**Таблица 4. Подтверждённые источником ветви, существенные для полного gate.** Точные внешние argv/cwd/outputs CMake/perftools вынесены в [external-tools.md](external-tools.md).

| Область и точный вход | Что происходит и где находится граница допуска |
|---|---|
| `internal/perftools`: `TestDetectTools_ReportsInstalledWithVersion`, `TestListToolsTool_*`, `TestToolsResource_*` | DetectTools запускает найденные PATH `clang-tidy`, `hyperfine`, `llvm-objdump`, `include-what-you-use` с `--version`. Эти probes происходят также до per-tool Skip интеграций и не имеют context timeout. Version-запрос не является установкой, но запускаемый образ нужно квалифицировать |
| `internal/perftools`: `TestClangTidy_ParsesRealOutput`, `TestIWYU_ParsesSuggestions`, LLVM tests | Common runner вызывает установленный oneAPI capture при первом EnvOverlay, если найден setvars. Это возможно и перед собственным test executable. LLVM fixture дополнительно делает PATH `go build` собственного main.go; exe в temp затем читается, не запускается. Кеши/toolchain требуют внешнего контроля |
| `internal/perftools`: `TestHyperfine_ComparesTwoCommands` | Прямой вызов handler обходит registration gate; JSON создаётся в OS temp, Hyperfine запускает default shell с echo и калибровочными командами. Существующая версия и внутренний shell argv пока UNQUALIFIED |
| `internal/perftools`: `TestRunCaptureLimited_EnforcesStdoutLimit` | Исходный bash `-lc` читает startup до printf. Текущий двухфайловый shell candidate отделяет execution owner с явной средой, использует `-p -c`; unit oracle больше не вызывает oneAPI. Прежний discovery-seam вариант отклонён из-за sync.Once interference и сохранён только как evidence |
| `internal/perftools`: `TestClangTidyTool_RejectsOversizedOutput` | Отдельный POSIX fake с `#!/usr/bin/env bash`, PATH head/tr; без `-p`. Windows Skip стоит до fixture, но POSIX startup-ветвь остаётся открытой и не закрывается stdout candidate |
| `internal/cbuild`: `TestCMakeIntegration` | После PATH lookup создаёт собственный project temp, выполняет list-presets и configure **до** Skip о недоступной toolchain. Fixture задаёт свой build dir и не содержит FetchContent/install, но compiler/generator/launcher и их argv выбираются средой, пока UNQUALIFIED |
| `internal/cbuild`: `TestVcpkgIntegration` | Пустой VCPKG_ROOT → ранний Skip; иначе реальный `<root>/vcpkg list`. Это запрос установленной базы, не install. Идентичность инструмента и его собственные побочные эффекты отдельно квалифицируются |
| `internal/oneapirun`: `TestRunInOneAPIEnvTool_TrivialCommandExitZero`, `...ReportsEnvSourceFromSeams`, `...Timeout`, `...DefaultTimeoutWhenOmitted` | Discovery capture замокан newTestServer, но реальные cmd/sh остаются. Windows echo: `cmd /c "echo hi"`; timeout: `cmd /c "ping -n 6 127.0.0.1 > NUL"`; POSIX timeout: `sh -c "sleep 5"`. `hubtemp.Dir` использует LOCALAPPDATA или user cache/home независимо от API override; нужные roots задаются до первого EnsurePrivateDir |
| `internal/binaryadmission`: `TestCanonicalEntryStageRefusesRedirectedInstallationDirectory` | `windows_canonical_entry_native_windows_test.go:523`: `cmd /c mklink /J <redirect> <outside>`, затем Skip на ошибке. Явные пути из temp, но процесс уже запущен до Skip. `/d` отсутствует: startup/AutoRun требует отдельной квалификации; fixture не запускает установленный Product |
| `internal/cli`: reliability, GUI, native Product | Три reliability tests без полного opt-in делают nested `go build -tags test_state_path_env` и запускают собственный exe. `MCPHUB_GUI_SPAWN_TESTS` закрывает только три конкретных GUI-теста. Обязательный `TestRunV5UpgradeWindows_UnreadableIntentAbortsUpgrade` делает t.Fatal без абсолютного `MCPHUB_CANONICAL_ENTRY_FIXTURE`; нельзя заменить его Skip ради full green. Полный список в CLI audit |
| `internal/scheduler`: `TestSchedulerCOMTargetLifecycle` | Первым проверяет `MCPHUB_TARGET_SCHEDULER_QA=1`, иначе Skip до операций. При включении это реальные Create/Run/Stop/Delete системной задачи; текущая политика их не допускает. Уникальное имя задачи не меняет класс операции |
| `internal/autostart` и обычные CLI Scheduler tests | В проверенных путях scheduler seams устанавливаются до task operations; одно создание объекта New не означает Create/Run задачи. Не обнаружен доказанный default native task mutation, но это не общее разрешение всех ветвей |
| `internal/e2e`: `TestE2E_LazyRegisterFullLifecycle` | Windows: HardenedTempDir, API root override, `MCPHUB_E2E_SCHEDULER=none`, fake hooks и собственный canonical stub до Register. Scheduler New учитывает none; комментарий теста не доказывает реальную системную задачу. Product admission и настоящий запуск пока отдельно квалифицируются |
| `internal/e2e`: CST/console fixtures | Реальный Sonnet/CST/console workflow не включать автоматически. Default CST Python probe требует `MCPHUB_CST_PROBE_TEST_PYTHON` и пропускается при отсутствии до exec; другие ветви имеют собственные generation/native/ASCII/selector opt-ins либо build tags `cst_vptr_probe`, `windows_console_integration` и `test_state_path_env` |
| `internal/sonnet`: `TestRealAttRes16ThroughMCP` | Первая проверка `SONNET_REAL_ATT_RUN=1`; без неё Skip до real sample. Другие strict-driver tests используют свой test executable и собственный sample/RunRoot; это не квотный model call |
| `internal/kimi`: `TestRunWithContainedStreamSettlesStubbornChild` | Реальный original test executable/descendant, markers и parent temp; runner dependencies замоканы. В прочитанных шести Kimi test sources не найден реальный платный/Kimi model call. Это всё ещё реальная process custody fixture, требующая Wait/cleanup квалификации |
| `internal/vcpkgmcp/pinstatus`: `TestDefaultRemoteRefsRealCommandStreamsAndSettles`, cancellation/read-failure tests | Собственный test executable и, в некоторых режимах, grandchild; не реальный git remote. Нужно квалифицировать containment исходных процессов и parent-owned ready/release/pids paths |

Godbolt handler tests в прочитанном файле используют `httptest` и fake HTTP dependencies либо завершаются валидацией: название пакета не означает реальный remote compile. Аналогично слова Sonnet/Kimi в имени пакета сами по себе не разрешают и не доказывают внешний model invocation.

Точные CST native gates в `internal/e2e/cst_saved_field_result_tree_probe_windows_test.go`: `MCPHUB_CST_GENERATION_RUN=1` для `TestCSTSavedFieldBundleCompletenessLine10Diagnostic` и семейства GenerateLine10 (проверки :2486/:3446); `MCPHUB_CST_RESULT_TREE_RUN=1` для `TestCSTSavedFieldOwnedResultTreeProbe` (:3671); `MCPHUB_CST_ASCII_NATIVE_RUN=1` для `TestCSTSavedFieldASCIIPointCalibrationNative` (:7303); `MCPHUB_CST_SELECTOR_BINDING_RUN=1` для `TestCSTSavedFieldSelectorBindingNative` (:7384). Их не включать. `MCPHUB_CST_PROBE_TEST_PYTHON` включает отдельные synthetic Python fixtures, а `MCPHUB_CST_ASCII_WORK_ITEM` задаёт внешний work-item источник для section/fake сценариев; эти ambient inputs также не наследовать в ordinary gate без их адресной квалификации.

На Windows `cmd /c` без `/d` может выполнять Command Processor AutoRun. POSIX bash без `-p` может выполнять BASH_ENV. Это доказанный вход startup-политики, а не утверждение, что на конкретном хосте уже установлен такой callback. Простое перенаправление HOME/TEMP не закрывает этот вход. Подробная первичная документация приведена в external-tools.md.

## Контракты ранних helpers

Для ролей, которые штатно делают `os.Exit` или удерживаются до parent kill, обычный post-m.Run cleanup недостижим: ранний dispatch устраняет allocation, которым этот cleanup не сможет распорядиться. Возвращающиеся роли требуют отдельного доказательства state/IPC контракта. API A2 helpers сами связывают parent state до lease access и не открывают supervisor pipe; для остальных возвращающихся ролей normal setup сохраняется. Одни только имена test functions не доказывают отсутствие state read/write.

CLI candidate документирован отдельно: [README](../cli-candidate/README.md), [manifest](../cli-candidate/manifest.json). Его exact argv admission сохраняет реальные старые семь ролей и разрешает четыре новые. Массив аргументов проверяется полностью; поиск `-test.run=` по всем словам заменён, потому что `--`, positional и alias/split flags иначе расходились с Go flag.Parse. Для обычных вызовов без markers общий Go CLI не переписывается.

Root-sensitive CLI secrets helper до `WithVaultLock` сверяет `api.DaemonStateDirReadOnly()` с parent vault root. Direct vault/key paths сами по себе недостаточны: API-installed reader/writer могут читать strict-mode intent и писать audit в state root. Candidate связывает in-memory API root до m.Run и не создаёт новый package root. Новый parent oracle использует исходный test executable, десятисекундный context deadline, один Cmd.Wait и отдельный child temp; ожидаемая baseline ошибка возникает до lock/write, а остаток package root ограничен parent-owned D.

API candidate и родственный caller-start-time контракт находятся в [API-helper-candidate.md](cli-scheduler/API-helper-candidate.md) и `../api-candidate/`. Реальный vault-lock helper является другим сценарием: lock/ready/release по переданным путям, без чтения самого vault через API reader. Нельзя переносить на него вывод о root-free поведении CLI secrets helper. Native проверки/последние изменения этого кандидата принимаются root отдельным review; этот отчёт не заменяет его freeze.

Для new roles, которые обязаны выйти или быть reaped, возврат m.Run с нулём должен стать ненулевой диагностикой: иначе отсутствующий compiled helper даёт ложный PASS. Original returning roles сохраняют свой старый m.Run exit contract. Windows leaf checks не являются доказательством владельца, ancestors, hardlinks или отсутствия concurrent namespace substitution; реальные positive fixtures создаёт parent внутри подготовленной D области.

## Что можно проверять следующим этапом

**Таблица 5. Ступени следующего gate при действующей политике.** Это условия исполнения root, не запись о выполнении.

| Ступень | Допустимый следующий результат | Обязательное входное условие |
|---|---|---|
| Источники | Diff/форматирование, сверка exact overlays и проверка локальных manifest | Не перезаписывать новые candidates старым source overlay; не запускать инструменты, скачивающие зависимости |
| Offline compilation | Go build/vet и `go test -c` по известным пакетам, с явным output в D | Уже квалифицированный локальный toolchain; `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`; очистить управляющие GOFLAGS/-toolexec, не использовать ambient direct-fetch обходы; все cache/temp/output roots подготовлены в D. Cache miss останавливает проверку, не разрешает download |
| Compile-only граница | Test binary получен, init/TestMain не выполнялись | `go test -c` — без последующего запуска. `-run '^$'`, `-list` и обычный `go test` эту границу не сохраняют |
| Pure admission/native fixture checks | Точные новые validator selectors и собственные path fixtures | Normal TestMain уже reviewed; parent root/temp создан до запуска. Native leaf test Skip не засчитывается как подтверждение reparse rejection |
| Cooperative helper oracle | Реальные CodeGraph EOF, API lock/release, CLI concurrent vault и daemon helper по утверждённым caller paths | Только исходный test executable, точный argv/env, удерживаемый process handle/Wait, parent-owned D и отдельные roots для baseline/candidate. Не запускать старую fail-open broad-selector invocation ради negative control |
| Существующие утилиты | Version/list qualification и затем адресный audited integration | Установки не нужны; отдельно определить реальные образы, argv, startup/config и все пути записи. Version/list не считать install, но не подменять ими квалификацию полной CMake/setvars/Hyperfine цепочки |
| Полный default suite | Возможен только после закрытия открытых input branches и обязательных native fixtures | Нельзя считать `-short`, закрытые model flags или env redirect доказательством безопасности всех первых операций. Зафиксировать реальные skips и оставшийся NOT_RUN |
| Реальные системные задачи / внешние models / CI | Не входят в текущий допуск | Не включать Scheduler QA, реальные CST/Sonnet workflow, квотные models, установки, CI или загрузку зависимостей |

На Windows дополнительно заранее связать TEMP/TMP, профильные LOCALAPPDATA/APPDATA/USERPROFILE и нужные cache roots с отдельными подготовленными D каталогами; на POSIX аналогично TMPDIR/HOME/XDG cache/state. Это маршрутизация известных путей, не security sandbox. Из кода `hubtemp.Dir` следует отдельная зависимость от cache/home; из native API resolver — отдельная необходимость in-memory override или документированного tagged child contract.

Важные candidates, единственные source copies, manifests, rejected evidence и результаты остаются вне trash. Подтверждённо неиспользуемые disposable результаты root переносит в разрешённый trash по правилу пользователя; автоматическая очистка trash не выполнялась.

## Артефакты и проверка исходников

**Таблица 6. Проверяемые результаты этого участка.**

| Артефакт | Содержание |
|---|---|
| [test-isolation-overlay-manifest.json](test-isolation-overlay-manifest.json) | 16 точных источников, 4 new / 12 modified, обе blob identities, companion и candidate precedence, 9 идентичных API support blobs |
| [test-package-inventory.json](test-package-inventory.json) | Оба точных Git tree, counts и каталоги; отдельное исключение вложенного модуля, без выдуманного runtime package count |
| [source-manifest.json](source-manifest.json), [additional-source-manifest.json](additional-source-manifest.json) | 133 первоначальных и 43 дополнительных source snapshots, всего 176 уникальных label/path; Git blob пересчитан по сырым байтам, все совпали |
| [cli-scheduler/README.md](cli-scheduler/README.md) | Подробные CLI/Task Scheduler callers, constraints, mandatory Product oracle, real/fake subprocess distinction |
| [external-tools.md](external-tools.md) | Полные известные outer argv CMake/perftools/oneAPI, cwd/env/output domains, pre-Skip calls и честные UNQUALIFIED внутренние цепочки |
| [CLI candidate](../cli-candidate/README.md) | Exact early admission, root-sensitive secrets oracle, два PowerShell profile fixes, manifests и regression cases |
| [Shell candidate](../shell-fixture-candidate/README.md) | Explicit-env private execution owner; stdout unit fixture без login startup/oneAPI; отклонённый cache-poisoning вариант сохранён отдельно |
| [helper-publication-summary.md](helper-publication-summary.md) | Проект отдельных CLI/API описаний, переданные root native результаты и явные pending API/receipt поля; ничего не публиковалось |

Источники сохранены под `source/head/` и `source/master/`; исходные Git URL есть в manifests и специализированных отчётах. Go, gofmt, тестовые бинарники, проверяемые внешние утилиты, реальный Scheduler, remote-PC инструменты, CI и публикация этим автором не запускались. Статический byte/diff review не объявляется compilation/runtime PASS. Последующие проверки root фиксируются отдельно по конкретному freeze.
