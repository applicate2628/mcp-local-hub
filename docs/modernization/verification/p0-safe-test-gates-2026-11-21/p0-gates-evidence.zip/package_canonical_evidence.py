"""Package the recorded P0 runs, preservation proof and read-only admission audit."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

WORKSPACE = Path(__file__).resolve().parents[2]
PROJECT = WORKSPACE / "mcphub-p0"
OUT = PROJECT / "publication/canonical"
entries = {}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def add(name, path):
    assert name not in entries and path.is_file() and not path.is_symlink()
    entries[name] = path.read_bytes()

add("recorded-runs/canonical-evidence.zip", PROJECT / "verification/received/canonical-evidence.zip")
add("recorded-runs/export-receipt.json", PROJECT / "verification/received/export-receipt.json")
add("recorded-runs/local-export-verification.json", PROJECT / "verification/received/local-export-verification.json")
add("hygiene/hygiene-public-v2.json", PROJECT / "verification/received/hygiene-public-v2.json")
add("hygiene/export_hygiene_summary_v2.py", PROJECT / "verification/export_hygiene_summary_v2.py")
add("export/export_p0_evidence.py", PROJECT / "verification/export_p0_evidence.py")
add("export/export-p0-evidence-contract.md", PROJECT / "verification/export-p0-evidence-contract.md")
add("preservation/preservation-after-fixes.json", OUT / "preservation-after-fixes.json")
add("preservation/source-commits.json", PROJECT / "publication/source-commits.json")
add("preservation/verify_canonical_successor.py", PROJECT / "verification/verify_canonical_successor.py")
preserved = WORKSPACE / "next-arch-audit/replacement658"
for name in ("preservation-manifest.json", "tree-inputs.json", "verify_preservation.py"):
    add("preservation/" + name, preserved / name)
for file in sorted((preserved / "preserved").rglob("*")):
    if file.is_file():
        add("preservation/original-658/" + file.relative_to(preserved / "preserved").as_posix(), file)
for file in sorted((OUT / "candidate").rglob("*.go")):
    add("preservation/canonical-code/" + file.relative_to(OUT / "candidate").as_posix(), file)
audit = PROJECT / "full-gate-audit"
for file in sorted(audit.rglob("*")):
    if file.is_file() and file.name != "helper-publication-summary.md":
        add("admission-audit/" + file.relative_to(audit).as_posix(), file)
add("package_canonical_evidence.py", Path(__file__))
manifest = {"schema": 1, "purpose": "P0 exact recorded runs, preserved source and full-Go admission boundaries",
            "full_go_suite": "NOT_RUN", "installed_product": "NOT_RUN",
            "private_hygiene_originals": "Retained outside this public archive; hashes and redacted observations included",
            "replay_scope": "Integrity of recorded bytes; no test execution is implied by unpacking or checksums",
            "files": [{"path": name, "bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(entries.items())]}
entries["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for name, raw in sorted(entries.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 21, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        package.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
raw = buffer.getvalue()
target = OUT / "p0-gates-evidence.zip"
if target.exists():
    assert target.read_bytes() == raw
else:
    with target.open("xb") as output:
        output.write(raw)
with zipfile.ZipFile(target) as package:
    assert package.testzip() is None and set(package.namelist()) == set(entries)
    for name, expected in entries.items():
        assert package.read(name) == expected
proof = json.loads((OUT / "preservation-after-fixes.json").read_text())
results = json.loads((PROJECT / "verification/received/local-export-verification.json").read_text())
qualification = {"schema": 1, "archive": {"name": target.name, "bytes": len(raw), "sha256": sha(raw),
                  "entries": len(entries), "manifest_sha256": sha(entries["MANIFEST.json"])},
                 "source_preservation": proof, "recorded_archives": results,
                 "full_go_default": "NOT_RUN", "full_go_tagged_api_cli": "NOT_RUN",
                 "published_head_qualification": "NOT_CLAIMED; exact physical commits plus overlays are recorded inside",
                 "external_review_on_publication_head": "REVIEW_PENDING",
                 "serena_and_architecture_code_in_composed_build": False}
(OUT / "qualification.json").write_text(json.dumps(qualification, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(qualification["archive"]))
