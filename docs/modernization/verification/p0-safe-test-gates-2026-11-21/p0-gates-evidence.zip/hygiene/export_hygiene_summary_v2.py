"""Publish only fixed, redacted hygiene observations; preserve private originals."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib
import json
ROOT=Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5")
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def owned(path):
    current=ROOT
    for part in (None,*path.relative_to(ROOT).parts):
        if part is not None: current/=part
        info=current.lstat()
        if current.is_symlink() or getattr(info,"st_file_attributes",0)&0x400:
            raise RuntimeError("Reparse input refused")
    return path
formatter=owned(ROOT/"evidence/formatter-environment-audit.json").read_bytes()
bash=owned(ROOT/"preserved-input/evidence/bash-path-audit-v2.json").read_bytes()
stderr=owned(ROOT/"preserved-input/bash-path-audit.stderr.txt").read_bytes()
original=json.loads(formatter)
data={
 "schema":1,
 "private_originals_retained":True,
 "formatter":{
  "original_bytes":len(formatter),"original_sha256":digest(formatter),
  "formatter_output_mtime":original["formatter_output_mtime"],
  "environment":{"APPDATA":"<APPDATA>","LOCALAPPDATA":"<LOCALAPPDATA>","USERPROFILE":"<USERPROFILE>",
                 **{k:original["environment"].get(k) for k in ["GOTELEMETRY","GOTELEMETRYDIR","TEST_TELEMETRY_DIR"]}},
  "telemetry":[{"path":"<USERPROFILE_TELEMETRY>","exists":item["exists"],"mode":item["mode"],
                "gofmt_counter_files":[{k:v for k,v in entry.items() if k!="path"} for entry in item["gofmt_counter_files"]]}
               for item in original["telemetry"]],
  "limit":"Read-only after-the-fact metadata found no new counter matching the isolated formatter time; writes through an existing mapped counter cannot be excluded. No C profile cleanup was performed.",
  "followup":"Subsequent reviewed runners bind TEST_TELEMETRY_DIR and profile variables beneath the owned D root and write mode off."
 },
 "bash":{"audit":json.loads(bash),"audit_bytes":len(bash),"audit_sha256":digest(bash),
         "initial_failed_audit_stderr_sha256":digest(stderr),"initial_failed_audit_stderr_bytes":len(stderr),
         "initial_failure":"Read-only inspection of a WindowsApps reparse target failed; none of these launcher candidates was executed by discovery.",
         "qualified_execution":"The selected shell test later used the existing pinned MSYS Bash through p0_shell_runner.py; its execution evidence is separate."},
 "telemetry_prelaunch_refusal":{
   "original_phase":"native-proof-api-control","helper_launched":False,
   "cause":"Proof required LF bytes but Windows text write produced CRLF; installed telemetry mode parser trims surrounding whitespace.",
   "retained_as_failed":True,"v2_bytes_hex":"6f66660d0a",
   "scope":"v2 explicitly admits only off LF or off CRLF and records actual bytes/hash."
 }
}
output=ROOT/"evidence/hygiene-public-v2.json"
owned(output.parent)
with output.open("x",encoding="utf-8",newline="\n") as stream:
    stream.write(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"path":str(output),"bytes":output.stat().st_size,"sha256":digest(output.read_bytes())}))
