#!/usr/bin/env python3
"""Verify the exact PR 658 transfer inputs, using only Python's standard library.

This writes a local proof manifest. It does not create Git objects, move refs,
publish a PR, qualify execution, or authorize closing the original PR.
"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def object_hash(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def tree_hash(leaves):
    root = {}
    for path, (mode, sha) in leaves.items():
        parts = path.split("/")
        assert all(part not in ("", ".", "..") for part in parts), path
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
            assert isinstance(node, dict), path
        assert parts[-1] not in node, path
        node[parts[-1]] = (mode, sha)

    def visit(node):
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, sha = "40000", visit(value)
                order = (name + "/").encode("utf-8")
            else:
                mode, sha = value
                mode = format(int(mode, 8), "o")
                order = name.encode("utf-8")
            entries.append((order, mode.encode() + b" " + name.encode("utf-8") + b"\0" + bytes.fromhex(sha)))
        raw = b"".join(value for _, value in sorted(entries))
        return object_hash("tree", raw)

    return visit(root)


def difference(left, right):
    return sorted(path for path in set(left) | set(right) if left.get(path) != right.get(path))


def responsibility(path):
    if not path.endswith(".go"):
        return "canonical_instructions_plan_evidence"
    if path in {
        "internal/api/hub_mcp_state_read_inode_windows.go",
        "internal/api/hub_mcp_state_read_policy_windows_test.go",
    }:
        return "effective_read_policy_diagnostic"
    if path.startswith("tools/testshards/"):
        return "test_shard_diagnostics_tool"
    return "test_isolation_and_fixture_inputs"


def main():
    input_path = ROOT / "tree-inputs.json"
    raw_input = input_path.read_bytes()
    inputs = json.loads(raw_input)
    sources = {}
    validation = []
    for source in inputs["sources"]:
        assert source["truncated"] is False, source["role"]
        leaves = {path: (mode, sha) for path, mode, sha in source["leaves"]}
        assert len(leaves) == len(source["leaves"]), source["role"]
        actual_tree = tree_hash(leaves)
        assert actual_tree == source["root_tree_sha"], (source["role"], actual_tree, source["root_tree_sha"])
        sources[source["role"]] = (source, leaves)
        validation.append({"role": source["role"], "commit": source["commit"], "root_tree_sha": actual_tree, "leaf_count": len(leaves)})

    base_meta, base = sources["merge_base"]
    master_meta, master = sources["master"]
    head_meta, head = sources["pr658"]
    residue = difference(base, head)
    master_delta = difference(base, master)
    overlap = sorted(set(residue) & set(master_delta))
    assert len(residue) == 28 and not overlap, (len(residue), overlap)
    assert set(residue) == {item["path"] for item in inputs["pr658_files"]}

    candidate = dict(master)
    records = []
    groups = {}
    classes = {"documentation_plan_evidence": 0, "test_go": 0, "production_go": 0, "executable_repository_tool_go": 0}
    for path in residue:
        assert base.get(path) == master.get(path), path
        assert path in head, "Unexpected source deletion: " + path
        raw = (ROOT / "preserved" / path).read_bytes()
        mode, expected_blob = head[path]
        actual_blob = object_hash("blob", raw)
        assert actual_blob == expected_blob, (path, actual_blob, expected_blob)
        candidate[path] = head[path]
        group = responsibility(path)
        groups.setdefault(group, []).append(path)
        if not path.endswith(".go"):
            classes["documentation_plan_evidence"] += 1
        elif path.endswith("_test.go"):
            classes["test_go"] += 1
        elif path.startswith("tools/"):
            classes["executable_repository_tool_go"] += 1
        else:
            classes["production_go"] += 1
        records.append({
            "path": path,
            "mode": mode,
            "merge_base_blob": base.get(path, (None, None))[1],
            "master_blob": master.get(path, (None, None))[1],
            "preserved_pr658_blob": expected_blob,
            "payload_sha256": hashlib.sha256(raw).hexdigest(),
            "payload_bytes": len(raw),
            "responsibility": group,
            "source_url": "https://github.com/" + inputs["repository"] + "/blob/" + head_meta["commit"] + "/" + path,
        })

    assert difference(master, candidate) == residue
    proof = {
        "schema_version": 1,
        "status": "STATIC_EXACT_TRANSFER_PROOF_ONLY_NOT_PUBLISHED_OR_RUNTIME_QUALIFIED",
        "repository": inputs["repository"],
        "input_sha256": hashlib.sha256(raw_input).hexdigest(),
        "source_trees_verified_against_git_commit_tree_ids": validation,
        "overlap_proof": {
            "merge_base": base_meta["commit"],
            "master_changed_physical_paths": len(master_delta),
            "pr662_github_changed_file_records": len(inputs["pr662_files"]),
            "pr658_changed_paths": len(residue),
            "overlap_paths": overlap,
            "master_delta_paths": master_delta,
        },
        "candidate_exact_transfer": {
            "intended_single_parent": master_meta["commit"],
            "expected_git_root_tree_sha": tree_hash(candidate),
            "leaf_count": len(candidate),
            "changed_paths_vs_master": residue,
            "all_other_entries_equal_master": True,
            "all_28_payloads_equal_pr658_exact_git_blobs": True,
            "payload_bytes": sum(item["payload_bytes"] for item in records),
            "note": "A later helper correction, architecture migration, or plan update is a separate reviewed delta. This tree identifies the exact preservation checkpoint only.",
        },
        "file_class_counts": classes,
        "responsibility_groups": groups,
        "preserved_files": records,
        "related_current_prs": inputs["current_related_prs"],
        "publication_constraints": {
            "no_refs_or_prs_changed_by_this_verifier": True,
            "old_pr658_must_remain_open_until_preservation_and_published_readback_are_proved": True,
            "retain_original_source_branch": True,
            "no_merge_commit_no_force_push_no_ci_dispatch": True,
        },
    }
    output = ROOT / "preservation-manifest.json"
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verified_source_tree_ids": validation, "overlap_paths": overlap, "counts": classes, "candidate": proof["candidate_exact_transfer"], "manifest": str(output)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
