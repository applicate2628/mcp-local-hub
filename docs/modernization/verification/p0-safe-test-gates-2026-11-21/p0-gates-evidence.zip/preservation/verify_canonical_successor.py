"""Check the narrow code delta after the exact 28-file preservation checkpoint."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PRESERVED = ROOT.parent / "next-arch-audit/replacement658"
OUT = ROOT / "publication/canonical"
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

prior = json.loads((PRESERVED / "preservation-manifest.json").read_text())
source = json.loads((ROOT / "publication/source-commits.json").read_text())["canonical"]
changed = {f["path"]: f for f in source["files"]}
assert set(changed) == {"internal/daemon/main_test.go", "internal/daemon/main_dispatch_test.go", "internal/cli/gui_force_test.go"}
rows = []
for item in prior["preserved_files"]:
    path = item["path"]
    original = (PRESERVED / "preserved" / path).read_bytes()
    assert blob(original) == item["preserved_pr658_blob"]
    assert sha(original) == item["payload_sha256"]
    candidate_path = OUT / "candidate" / path
    candidate = candidate_path.read_bytes() if path in changed else original
    if path in changed:
        assert sha(candidate) == changed[path]["sha256"] and blob(candidate) == changed[path]["git_blob"]
    rows.append({"path": path, "original_blob": blob(original), "candidate_blob": blob(candidate),
                 "same_bytes": original == candidate, "responsibility": item["responsibility"]})
assert len(rows) == 28 and sum(r["same_bytes"] for r in rows) == 26

path = "internal/cli/gui_force_test.go"
old = (PRESERVED / "preserved" / path).read_bytes()
new = (OUT / "candidate" / path).read_bytes()
before = b'exec.Command("powershell", "-NoExit", "-Command", "Start-Sleep -Seconds 60")'
after = b'exec.Command("powershell", "-NoProfile", "-NonInteractive", "-NoExit", "-Command", "Start-Sleep -Seconds 60")'
assert old.count(before) == 2 and old.replace(before, after) == new

path = "internal/daemon/main_test.go"
old = (PRESERVED / "preserved" / path).read_bytes()
new = (OUT / "candidate" / path).read_bytes()
tail = b'\tisolatedRoot, err := os.MkdirTemp("", "mcphub-daemon-test-state-")'
assert old[old.index(tail):] == new[new.index(tail):]
begin = b'func validateStdioOriginalHelperInvocation('
end = b'\n}\n'
def original_validator(raw):
    start = raw.index(begin)
    finish = raw.index(end, start) + len(end)
    return raw[start:finish]
assert original_validator(old) == original_validator(new)

result = {
    "status": "LOCAL_CODE_DELTA_VERIFIED_PUBLICATION_READBACK_REQUIRED",
    "old_pr": 658, "old_pr_head": "f9966f008aed4d0cfa80d88cc80c12d08e03634f",
    "preservation_checkpoint_commit": "858812988833a84368c60fba1540ae601155fa71",
    "preservation_checkpoint_tree": "dba685c090952a93a80a1e82403c4646ad8aaed1",
    "code_commit": source["commit"], "code_tree": source["tree"],
    "all_28_original_payloads_retained_in_checkpoint": True,
    "unchanged_original_paths_at_code_commit": 26,
    "reviewed_changes_after_checkpoint": {
        "internal/daemon/main_test.go": {"ordinary_tail_byte_identical": True, "original_validator_byte_identical": True,
                                         "new_scope": "Admit the private master stdio fixture before package-state allocation; fail on an unexpected return."},
        "internal/cli/gui_force_test.go": {"exactly_two_argument_insertions": True,
                                         "new_scope": "Disable profiles and interactivity in the existing two PowerShell fixtures.",
                                         "native_cases_executed": False},
        "internal/daemon/main_dispatch_test.go": {"new_file": True, "pure_table_cases": 39}
    },
    "preserved_paths": rows,
    "limits": ["Later plan and evidence updates must be checked separately.",
               "This is a source-preservation proof, not full Go or installed-product acceptance.",
               "PR #658 remains open until the replacement is published and read back; its branch is retained."]
}
target = OUT / "preservation-after-fixes.json"
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"verified_original_paths": 28, "unchanged_current_paths": 26,
                  "daemon_normal_tail_sha256": sha(old[old.index(tail):]), "proof_sha256": sha(target.read_bytes())}))
