"""Derive the fixed six-file Relay formatter from reviewed reader formatter v2.

Only local artifacts under this directory are written. Frozen Relay sources
are read and compared with their exact freeze receipt before and after packing.
No helper, gofmt, Go test/build, Git or remote process is executed.
"""
from pathlib import Path
import ast
import base64
import difflib
import hashlib
import json
import zlib


ROOT = Path(__file__).resolve().parent
PARENT = ROOT / "format_stage_remote.py"
PARENT_SHA256 = "bbc55fda331592dab88d6ec10deb95a836aded682f670f6e9df8532b7b052867"
RELAY = ROOT.parent / "relay"
FREEZE = RELAY / "candidate-freeze-preformat.json"
FREEZE_SHA256 = "0fa1a75c2f67b8923b3ed77f5d2427e7ae97aaf0ffa551013abd68e5a2c3403b"
NAMES = [
    "internal/daemon/relay.go",
    "internal/daemon/relay_consumer_profile_test.go",
    "internal/daemon/relay_protocol_contract_test.go",
    "internal/daemon/relay_qualification.go",
    "internal/daemon/relay_response_contract_test.go",
    "internal/daemon/relay_test.go",
]
GOFMT_SHA256 = "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def compact(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("ascii")


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError("Expected one exact parent segment: " + before)
    return text.replace(before, after, 1)


parent_bytes = PARENT.read_bytes()
if sha(parent_bytes) != PARENT_SHA256:
    raise ValueError("Reader parent formatter differs from the reviewed v2")
parent = parent_bytes.decode("utf-8")
derived = parent
for before, after in (
    ("Stage and format exactly 17 pinned reader inputs", "Stage and format exactly six frozen Relay candidate files"),
    ('ROOT = TASK / "reader-stage"', 'ROOT = TASK / "relay-stage"'),
    ('HELPER = TASK / "format_stage_remote.py"', 'HELPER = TASK / "relay_format_stage_remote.py"'),
    ('MANIFEST = TASK / "reader-stage-input.json"', 'MANIFEST = TASK / "relay-stage-input.json"'),
    ('BUNDLE = TASK / "reader-stage-input.b64"', 'BUNDLE = TASK / "relay-stage-input.b64"'),
    ('"reader-format-stage-v1"', '"relay-format-stage-v1"'),
    ('"reader-format-stage-receipt-v1"', '"relay-format-stage-receipt-v1"'),
    ('len(entries) != 17', 'len(entries) != 6'),
    ('"Exactly 17 reviewed Go files are required"', '"Exactly six frozen Relay candidate Go files are required"'),
    ('len({p.casefold() for p in rows}) != 17', 'len({p.casefold() for p in rows}) != 6'),
    ('len(packed["files"]) != 17', 'len(packed["files"]) != 6'),
    ('expected_dirs = {"candidate", "control", "fixtures"}', 'expected_dirs = {"candidate"}'),
    ('for prefix in ("candidate", "control", "fixtures"):', 'for prefix in ("candidate",):'),
    ('"operation_scope": "new stage files and pinned gofmt only; no build/test/Git/installed operations"',
     '"operation_scope": "new stage containing six Relay candidate files; pinned gofmt only; no build/test/Git/installed operations"'),
    ('gofmt={"path": str(GOFMT), "sha256": GOFMT_SHA256}, files_expected=len(files))',
     'gofmt={"path": str(GOFMT), "sha256": GOFMT_SHA256}, files_expected=len(files), file_roles={"candidate": len(files)})'),
):
    derived = once(derived, before, after)
start = derived.index("EXPECTED_PATHS = {\n")
end = derived.index("\n}\n", start) + len("\n}\n")
derived = derived[:start] + "EXPECTED_PATHS = {\n" + "".join('    "candidate/' + name + '",\n' for name in NAMES) + "}\n" + derived[end:]
derived = once(derived,
    '        receipt["fixture_bytes_unchanged"] = all(after_write[name] == before[name] for name in EXPECTED_PATHS if name.startswith("fixtures/"))\n'
    '        if not receipt["fixture_bytes_unchanged"]:\n'
    '            raise RuntimeError("Canonical API fixture bytes changed during formatting")\n',
    "")
if '"control/' in derived or '"fixtures/' in derived or "fixture_bytes_unchanged" in derived:
    raise ValueError("Derived formatter still includes a control or fixture claim")
helper_path = ROOT / "relay_format_stage_remote.py"
compile(derived, str(helper_path), "exec")

# Record byte identity of the unchanged capture, native-temp, environment and
# filesystem guard functions; the source delta remains the review authority.
unchanged = ["sha", "blob", "utc", "pairs_unique", "plain", "missing", "new_dir", "write_new", "save_new", "identity",
             "native_temp", "raise_walk_error", "environment", "check_input_identity", "execute", "require_success"]
def functions(text):
    return {node.name: ast.get_source_segment(text, node) for node in ast.parse(text).body if isinstance(node, ast.FunctionDef)}
old_functions, new_functions = functions(parent), functions(derived)
shared = {}
for name in unchanged:
    if old_functions[name] != new_functions[name]:
        raise ValueError("Parent behavior changed outside the selected scope: " + name)
    shared[name] = sha(new_functions[name].encode())
helper_bytes = derived.encode("utf-8")
helper_path.write_bytes(helper_bytes)
delta = "".join(difflib.unified_diff(parent.splitlines(True), derived.splitlines(True),
                                  fromfile="format_stage_remote.py@" + PARENT_SHA256,
                                  tofile="relay_format_stage_remote.py"))
(ROOT / "relay-format-stage-derived.patch").write_text(delta)

freeze_bytes = FREEZE.read_bytes()
if sha(freeze_bytes) != FREEZE_SHA256:
    raise ValueError("Relay freeze receipt changed")
freeze = json.loads(freeze_bytes)
if freeze["stage"] != "frozen-source-reviewed-format-required" or [row["path"] for row in freeze["files"]] != NAMES:
    raise ValueError("Relay freeze does not select exactly the reviewed six files")
rows, packed = [], []
for original in freeze["files"]:
    raw = (RELAY / "candidate" / original["path"]).read_bytes()
    if len(raw) != original["bytes"] or sha(raw) != original["sha256"] or blob(raw) != original["git_blob"]:
        raise ValueError("Relay frozen candidate bytes changed: " + original["path"])
    path = "candidate/" + original["path"]
    rows.append({"path": path, "bytes": len(raw), "sha256": sha(raw), "git_blob": blob(raw)})
    packed.append({"path": path, "data_base64": base64.b64encode(raw).decode("ascii")})
content = compact({"schema": 1, "files": packed})
bundle = base64.b64encode(zlib.compress(content, level=9))
if zlib.decompress(base64.b64decode(bundle, validate=True)) != content:
    raise ValueError("Local transport round trip differs")
bundle_path = ROOT / "relay-stage-input.b64"
bundle_path.write_bytes(bundle)
plan = {
    "schema": "relay-format-stage-v1", "root": r"D:\dev\ChatGPT\mcp-next-20261122-e21a1792\relay-stage",
    "helper_sha256": sha(helper_bytes),
    "gofmt": {"path": r"C:\msys64\ucrt64\bin\gofmt.exe", "sha256": GOFMT_SHA256},
    "timeouts": {"direct_seconds": 30, "termination_seconds": 10},
    "bundle": {"file": bundle_path.name, "encoding": "base64-zlib-json", "bytes": len(bundle), "sha256": sha(bundle),
               "json_bytes": len(content), "json_sha256": sha(content)},
    "files": rows,
}
manifest = compact(plan)
manifest_path = ROOT / "relay-stage-input.json"
manifest_path.write_bytes(manifest)
if FREEZE.read_bytes() != freeze_bytes:
    raise ValueError("Relay freeze receipt changed while packing")
for original in freeze["files"]:
    raw = (RELAY / "candidate" / original["path"]).read_bytes()
    if len(raw) != original["bytes"] or sha(raw) != original["sha256"] or blob(raw) != original["git_blob"]:
        raise ValueError("Relay source changed while packing: " + original["path"])
receipt = {
    "status": "LOCAL_PREPARED_NOT_RUN", "file_roles": {"candidate": 6}, "source_bytes": sum(row["bytes"] for row in rows),
    "parent_formatter_sha256": PARENT_SHA256, "freeze_receipt_sha256": FREEZE_SHA256,
    "source_base": freeze["base"], "source_files": rows,
    "manifest": {"file": manifest_path.name, "bytes": len(manifest), "sha256": sha(manifest)},
    "bundle": {"file": bundle_path.name, "bytes": len(bundle), "sha256": sha(bundle)},
    "helper": {"file": helper_path.name, "bytes": len(helper_bytes), "sha256": sha(helper_bytes)},
    "delta_sha256": sha(delta.encode()), "unchanged_parent_functions_sha256": shared,
}
(ROOT / "relay-format-stage-input-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: receipt[key] for key in ("status", "file_roles", "source_bytes", "helper", "manifest", "bundle", "delta_sha256")}))
