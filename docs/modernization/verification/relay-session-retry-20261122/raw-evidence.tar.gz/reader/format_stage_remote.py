"""Stage and format exactly 17 pinned reader inputs in one new owned directory.

Run only with the existing Windows Python using -I -S -B and two SHA-256
arguments: manifest, bundle. No Git, Go build/test, shell, download or export.
The only children are the pinned gofmt executable with fixed -w and -l argv.
Timeout handling retains the original Popen process handle, marks descendant
state unresolved BEFORE termination, and never resolves a PID again.
"""
import sys
sys.dont_write_bytecode = True

import base64
import ctypes
from ctypes import wintypes
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import zlib


TASK = Path(r"D:\dev\ChatGPT\mcp-next-20261122-e21a1792")
ROOT = TASK / "reader-stage"
HELPER = TASK / "format_stage_remote.py"
MANIFEST = TASK / "reader-stage-input.json"
BUNDLE = TASK / "reader-stage-input.b64"
GOFMT = Path(r"C:\msys64\ucrt64\bin\gofmt.exe")
GOFMT_SHA256 = "95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5"
DIRECT_TIMEOUT = 30
TERMINATION_TIMEOUT = 10
EXPECTED_PATHS = {
    "candidate/internal/api/managed_backend_install.go",
    "candidate/internal/api/managed_backend_reader_failures_test.go",
    "candidate/internal/api/state_read_beneath_root_common.go",
    "candidate/internal/api/state_read_beneath_root_failures_posix_test.go",
    "candidate/internal/api/state_read_beneath_root_failures_test.go",
    "candidate/internal/api/state_read_beneath_root_failures_windows_test.go",
    "candidate/internal/api/state_read_beneath_root_posix.go",
    "candidate/internal/api/state_read_beneath_root_windows.go",
    "control/internal/api/managed_backend_install.go",
    "control/internal/api/state_read_beneath_root_common.go",
    "control/internal/api/state_read_beneath_root_posix.go",
    "control/internal/api/state_read_beneath_root_windows.go",
    "fixtures/internal/api/intent_audit_caller_oracle_test.go",
    "fixtures/internal/api/main_helper_dispatch_test.go",
    "fixtures/internal/api/main_helper_dispatch_validation_test.go",
    "fixtures/internal/api/main_test.go",
    "fixtures/internal/api/secrets_test.go",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def pairs_unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def plain(path, directory):
    """Read-only admission of every existing ancestor, including drive root."""
    if not path.is_absolute():
        raise ValueError("Expected an absolute path: " + str(path))
    for current in (*reversed(path.parents), path):
        info = current.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Reparse/link path refused: " + str(current))
        expect_directory = current != path or directory
        if not (stat.S_ISDIR(info.st_mode) if expect_directory else stat.S_ISREG(info.st_mode)):
            raise ValueError("Unexpected path type: " + str(current))
    return path


def missing(path):
    try:
        path.lstat()
    except FileNotFoundError:
        return
    raise ValueError("Destination already exists: " + str(path))


def new_dir(path):
    path.relative_to(ROOT)
    plain(path.parent, True)
    missing(path)
    path.mkdir(exist_ok=False)
    plain(path, True)


def write_new(path, raw):
    path.relative_to(ROOT)
    plain(path.parent, True)
    with path.open("xb") as stream:
        stream.write(raw)


def save_new(path, value):
    write_new(path, (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))


def identity(path):
    plain(path, False)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError("File changed while hashing: " + str(path))
    return {"bytes": len(raw), "sha256": sha(raw), "git_blob": blob(raw)}


def native_temp(requested):
    # Same native API selection and exact-path admission as parent Runner.
    previous = {key: os.environ.get(key) for key in ("TEMP", "TMP")}
    try:
        os.environ.update(TEMP=str(requested), TMP=str(requested))
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        name = "GetTempPath2W" if hasattr(kernel, "GetTempPath2W") else "GetTempPathW"
        function = getattr(kernel, name)
        function.argtypes = (wintypes.DWORD, wintypes.LPWSTR)
        function.restype = wintypes.DWORD
        buffer = ctypes.create_unicode_buffer(32768)
        size = function(len(buffer), buffer)
        if not 0 < size < len(buffer) or Path(buffer.value) != requested:
            raise RuntimeError("Native temporary path did not resolve to the owned D: location")
        return {"api": name, "requested": str(requested), "resolved": buffer.value}
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def read_inputs(manifest_sha, bundle_sha):
    for value in (manifest_sha, bundle_sha):
        if not re.fullmatch(r"[0-9a-f]{64}", value):
            raise ValueError("Expected exact lowercase SHA-256 arguments")
    raw = plain(MANIFEST, False).read_bytes()
    if sha(raw) != manifest_sha:
        raise ValueError("Manifest bytes differ from the supplied pin")
    plan = json.loads(raw, object_pairs_hook=pairs_unique)
    if set(plan) != {"schema", "root", "helper_sha256", "bundle", "gofmt", "timeouts", "files"}:
        raise ValueError("Unexpected manifest shape")
    if plan["schema"] != "reader-format-stage-v1" or plan["root"] != str(ROOT):
        raise ValueError("Manifest does not select this exact new stage")
    if plan["gofmt"] != {"path": str(GOFMT), "sha256": GOFMT_SHA256} or plan["timeouts"] != {"direct_seconds": DIRECT_TIMEOUT, "termination_seconds": TERMINATION_TIMEOUT}:
        raise ValueError("Tool or bounded-child parameters differ from review")
    if plan["helper_sha256"] != sha(plain(HELPER, False).read_bytes()):
        raise ValueError("Helper bytes differ from the exact manifest")
    entries = plan["files"]
    if not isinstance(entries, list) or len(entries) != 17:
        raise ValueError("Exactly 17 reviewed Go files are required")
    rows = {}
    for row in entries:
        if not isinstance(row, dict) or set(row) != {"path", "bytes", "sha256", "git_blob"}:
            raise ValueError("Invalid manifest file row")
        path = row["path"]
        if not isinstance(path, str) or path not in EXPECTED_PATHS or path in rows:
            raise ValueError("Unexpected or duplicate file path")
        if type(row["bytes"]) is not int or row["bytes"] <= 0 or not isinstance(row["sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) or not isinstance(row["git_blob"], str) or not re.fullmatch(r"[0-9a-f]{40}", row["git_blob"]):
            raise ValueError("Invalid pinned file identity")
        rows[path] = row
    if set(rows) != EXPECTED_PATHS or len({p.casefold() for p in rows}) != 17:
        raise ValueError("Incomplete or Windows-aliased file set")
    transport = plan["bundle"]
    if not isinstance(transport, dict) or set(transport) != {"file", "encoding", "bytes", "sha256", "json_bytes", "json_sha256"}:
        raise ValueError("Invalid bundle descriptor")
    if transport["file"] != BUNDLE.name or transport["encoding"] != "base64-zlib-json" or transport["sha256"] != bundle_sha:
        raise ValueError("Bundle identity differs from the supplied pin")
    if type(transport["bytes"]) is not int or transport["bytes"] <= 0 or type(transport["json_bytes"]) is not int or transport["json_bytes"] <= 0:
        raise ValueError("Invalid exact bundle lengths")
    encoded = plain(BUNDLE, False).read_bytes()
    if len(encoded) != transport["bytes"] or sha(encoded) != bundle_sha:
        raise ValueError("Bundle bytes differ from the supplied pin")
    compressed = base64.b64decode(encoded, validate=True)
    decoder = zlib.decompressobj()
    content = decoder.decompress(compressed, transport["json_bytes"] + 1)
    if len(content) != transport["json_bytes"] or not decoder.eof or decoder.unconsumed_tail or decoder.unused_data or sha(content) != transport["json_sha256"]:
        raise ValueError("Bundle decompression length, end or digest differs")
    packed = json.loads(content, object_pairs_hook=pairs_unique)
    if not isinstance(packed, dict) or set(packed) != {"schema", "files"} or packed["schema"] != 1 or not isinstance(packed["files"], list) or len(packed["files"]) != 17:
        raise ValueError("Invalid decoded bundle shape")
    files = {}
    for item in packed["files"]:
        if not isinstance(item, dict) or set(item) != {"path", "data_base64"}:
            raise ValueError("Invalid bundled file")
        path = item["path"]
        if not isinstance(path, str) or path not in rows or path in files:
            raise ValueError("Unexpected or duplicate bundled file path")
        value = item["data_base64"]
        row = rows[path]
        if not isinstance(value, str) or len(value) != 4 * ((row["bytes"] + 2) // 3):
            raise ValueError("Bundled file base64 length differs")
        data = base64.b64decode(value, validate=True)
        if len(data) != row["bytes"] or sha(data) != row["sha256"] or blob(data) != row["git_blob"]:
            raise ValueError("Bundled file identity differs: " + path)
        files[path] = data
    if set(files) != EXPECTED_PATHS:
        raise ValueError("Decoded file inventory differs")
    if sha(plain(GOFMT, False).read_bytes()) != GOFMT_SHA256:
        raise ValueError("Installed gofmt differs from the reviewed executable")
    return plan, files


def raise_walk_error(error):
    raise error


def snapshot():
    expected_dirs = {"candidate", "control", "fixtures"}
    for name in EXPECTED_PATHS:
        expected_dirs.update(str(p).replace("\\", "/") for p in Path(name).parents if str(p) != ".")
    files, directories = {}, set()
    for prefix in ("candidate", "control", "fixtures"):
        top = plain(ROOT / prefix, True)
        for current, dirnames, filenames in os.walk(top, followlinks=False, onerror=raise_walk_error):
            current = plain(Path(current), True)
            directories.add(current.relative_to(ROOT).as_posix())
            for name in sorted(dirnames):
                plain(current / name, True)
            for name in sorted(filenames):
                path = current / name
                relative = path.relative_to(ROOT).as_posix()
                if relative not in EXPECTED_PATHS or relative in files:
                    raise ValueError("Unexpected staged file: " + relative)
                files[relative] = identity(path)
    if set(files) != EXPECTED_PATHS or directories != expected_dirs:
        raise ValueError("Staged source file/directory inventory differs")
    return files


def environment(receipt):
    runtime = ROOT / "runtime"
    new_dir(runtime)
    for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "gocache", "gomodcache", "xdg-config", "xdg-cache", "xdg-data"):
        new_dir(runtime / name)
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith(("MCPHUB_", "GIT_", "GO", "PYTHON")) and key.upper() != "SSH_ASKPASS"}
    settings = {
        "GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off",
        "GOWORK": "off", "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "GOMAXPROCS": "4",
        "GOPATH": str(runtime / "gopath"), "GOCACHE": str(runtime / "gocache"), "GOMODCACHE": str(runtime / "gomodcache"),
        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata"),
        "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
        "XDG_CONFIG_HOME": str(runtime / "xdg-config"), "XDG_CACHE_HOME": str(runtime / "xdg-cache"), "XDG_DATA_HOME": str(runtime / "xdg-data"),
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    system = Path(next(value for key, value in env.items() if key.upper() == "SYSTEMROOT"))
    settings["PATH"] = os.pathsep.join((str(GOFMT.parent), str(system / "System32")))
    env.update(settings)
    receipt["environment"] = settings
    receipt["native_temporary_path"] = native_temp(runtime / "tmp")
    return env


def check_input_identity(plan, manifest_sha, bundle_sha):
    for path, expected in ((HELPER, plan["helper_sha256"]), (MANIFEST, manifest_sha), (BUNDLE, bundle_sha), (GOFMT, GOFMT_SHA256)):
        if sha(plain(path, False).read_bytes()) != expected:
            raise RuntimeError("Observed input/tool changed: " + str(path))


def execute(label, flag, env, receipt, retained):
    paths = [str(ROOT / name) for name in sorted(EXPECTED_PATHS)]
    command = [str(GOFMT), flag, *paths]
    out = ROOT / "evidence"
    row = {"label": label, "executable": command[0], "args": command[1:], "cwd": str(ROOT),
           "started_utc": utc(), "settled": False, "timed_out": False,
           "direct_timeout_seconds": DIRECT_TIMEOUT, "termination_timeout_seconds": TERMINATION_TIMEOUT,
           "whole_process_tree_deadline_enforced": False, "process_tree_settlement_observed": False,
           "manifest_sha256": receipt["manifest_sha256"], "helper_sha256": receipt["helper_sha256"]}
    # Retain the row before any receipt/log operation can itself fail.
    receipt["commands"].append(row)
    child = None
    started = time.monotonic()
    try:
        save_new(out / (label + ".started.json"), row)
        print("START " + label, flush=True)
        plain(out, True)
        with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            retained.append(child)
            row["pid"] = child.pid
            save_new(out / (label + ".launched.json"), {**row, "launched_utc": utc()})
            try:
                row["exit_code"] = child.wait(timeout=DIRECT_TIMEOUT)
                row["settled"] = True
            except subprocess.TimeoutExpired:
                row.update(timed_out=True, error_type="TimeoutExpired", error="Direct-child deadline expired; descendant state unresolved")
    except BaseException as error:
        row.update(error_type=type(error).__name__, error=str(error))
    finally:
        if child is not None and not row["settled"]:
            row["termination_method"] = "Popen.terminate on retained original direct-child handle"
            row["process_tree_unresolved"] = True
            receipt["process_tree_unresolved"] = True
            row["retain_runtime_and_logs"] = True
            try:
                child.terminate()
                row["exit_code"] = child.wait(timeout=TERMINATION_TIMEOUT)
                row["settled"] = True
            except BaseException as error:
                row["termination_error"] = type(error).__name__ + ": " + str(error)
        row.update(finished_utc=utc(), seconds=time.monotonic() - started)
        for stream in ("stdout", "stderr"):
            path = out / (label + "." + stream + ".log")
            try:
                raw = plain(path, False).read_bytes()
                row[stream] = {"bytes": len(raw), "sha256": sha(raw), "captured_utc": utc(),
                               "hash_scope": "observed bytes; later writers unresolved" if row.get("process_tree_unresolved") else "bytes after direct-child exit"}
            except Exception as error:
                row[stream + "_capture_error"] = type(error).__name__ + ": " + str(error)
        save_new(out / (label + ".receipt.json"), row)
    return row


def require_success(row):
    if not row.get("settled") or row.get("timed_out") or row.get("process_tree_unresolved") or row.get("error_type") or row.get("exit_code") != 0:
        raise RuntimeError(row["label"] + " did not finish successfully")
    if any(row.get(stream, {}).get("bytes") != 0 or stream + "_capture_error" in row for stream in ("stdout", "stderr")):
        raise RuntimeError(row["label"] + " produced output or uncaptured logs")


def main():
    receipt = {"schema": "reader-format-stage-receipt-v1", "root": str(ROOT), "state": "preflight",
               "completed": False, "started_utc": utc(), "commands": [],
               "direct_child_wait_bounded": True, "whole_process_tree_deadline_enforced": False,
               "process_tree_settlement_observed": False,
               "operation_scope": "new stage files and pinned gofmt only; no build/test/Git/installed operations"}
    created = False
    retained = []
    plan = None
    try:
        if os.name != "nt" or sys.flags.optimize or not sys.flags.isolated or not sys.flags.no_site or not sys.flags.dont_write_bytecode:
            raise RuntimeError("Use the existing Windows Python unoptimized with -I -S -B")
        if len(sys.argv) != 3 or Path(__file__).absolute() != HELPER:
            raise ValueError("Expected the exact helper path and manifest/bundle SHA arguments")
        manifest_sha, bundle_sha = sys.argv[1:]
        plan, files = read_inputs(manifest_sha, bundle_sha)
        receipt.update(manifest_sha256=manifest_sha, bundle_sha256=bundle_sha, helper_sha256=plan["helper_sha256"],
                       gofmt={"path": str(GOFMT), "sha256": GOFMT_SHA256}, files_expected=len(files))
        plain(TASK, True)
        missing(ROOT)
        new_dir(ROOT)
        created = True
        new_dir(ROOT / "evidence")
        env = environment(receipt)
        parents = set()
        for name in files:
            parents.update(p for p in Path(name).parents if str(p) != ".")
        for relative in sorted(parents, key=lambda path: (len(path.parts), str(path))):
            new_dir(ROOT / relative)
        for name in sorted(files):
            write_new(ROOT / name, files[name])
        before = snapshot()
        expected = {row["path"]: {key: row[key] for key in ("bytes", "sha256", "git_blob")} for row in plan["files"]}
        if before != expected:
            raise RuntimeError("Staged pre-format bytes differ from the exact input set")
        receipt.update(state="formatting", files_before=before)
        save_new(ROOT / "receipt-initial.json", receipt)
        check_input_identity(plan, manifest_sha, bundle_sha)
        require_success(execute("gofmt-write", "-w", env, receipt, retained))
        after_write = snapshot()
        receipt["files_after_write"] = after_write
        receipt["fixture_bytes_unchanged"] = all(after_write[name] == before[name] for name in EXPECTED_PATHS if name.startswith("fixtures/"))
        if not receipt["fixture_bytes_unchanged"]:
            raise RuntimeError("Canonical API fixture bytes changed during formatting")
        check_input_identity(plan, manifest_sha, bundle_sha)
        require_success(execute("gofmt-list", "-l", env, receipt, retained))
        after = snapshot()
        receipt["files_after"] = after
        if after != after_write:
            raise RuntimeError("Read-only gofmt -l changed staged source bytes")
        check_input_identity(plan, manifest_sha, bundle_sha)
        receipt.update(state="complete", completed=True, changed_files=[name for name in sorted(before) if before[name] != after[name]])
    except BaseException as error:
        receipt.update(state="failed", completed=False, error_type=type(error).__name__, error=str(error), retain_stage=created)
    finally:
        receipt["finished_utc"] = utc()
        if created:
            try:
                save_new(ROOT / "receipt.json", receipt)
            except BaseException as error:
                receipt.update(state="failed", completed=False, receipt_write_error=type(error).__name__ + ": " + str(error))
        print(json.dumps(receipt, ensure_ascii=False), flush=True)
    return 0 if receipt["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
