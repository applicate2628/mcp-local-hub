# Relay server retry and negotiated version: source review

Status: **source reviewed and frozen; formatting, compilation and execution are pending**. This document records preparation, not a successful qualification. Publication remains with the parent owner.

## Contents

1. [Scope and exact inputs](#1-scope-and-exact-inputs)
2. [Chosen transport contract](#2-chosen-transport-contract)
3. [Own review and corrected findings](#3-own-review-and-corrected-findings)
4. [Admitted qualification plan](#4-admitted-qualification-plan)
5. [Remaining limits](#5-remaining-limits)
6. [Primary sources](#6-primary-sources)

## 1. Scope and exact inputs

Table 1. Source identities.

| Input | Identity and observation |
|---|---|
| Published pull request (PR) #629 | `f11cd6cf1f4031f3a2d7db60fb5d4edf19d0a4da`; all 14 Go changes were fetched by exact commit and verified against Git blob hashes. |
| Current master | `75dbc6406123e22468f168b861d5e0622c9d5769`, tree `cb3eec77c23f9400be962d91c9f23834b84f7643`; worktree was read only. |
| Merge base | `17bc78fc602efa204a74596409c939a3bf1ddc42`; the three existing paths modified by #629 have identical merge-base/master blobs; the other eleven paths are additive. |
| Two additional existing paths | `relay_qualification.go` and `relay_test.go` were fetched from exact #629 and verified identical to master. |
| Model Context Protocol (MCP) Go software development kit (SDK) | Module `github.com/modelcontextprotocol/go-sdk v1.6.1`; official annotated tag `a2ba430ead4795406d1aca6838d393d729144514` resolves to commit `d454bbaf06a342aee5336df3370321d9cdec2478`. Research copies of eight relevant source files match their Git blobs. |
| Windows physical base supplied by the parent | Preserved source `858812988833a84368c60fba1540ae601155fa71`, tree `dba685c090952a93a80a1e82403c4646ad8aaed1`. Full composition and test-entry admission belong to the parent runner review. |

The Relay manifest has 18 source paths: fourteen exact #629 paths, four replacements/additions to existing daemon files, and two new tests, with two replacements overlapping the fourteen. The parent also supplies the two admitted daemon test-entry files. These twenty logical paths alone do **not** prove that the physical preserved base is identical to current master. The eventual execution report must identify the complete tested composition.

The candidate changes six Go files. Production behavior changes are confined to `internal/daemon/relay.go`. The finite qualification receiver gets a mechanical `nil` retry argument, as do eight existing parser test call sites. Two session/shutdown fixtures now provide a protocol version in their initialization result. The remaining two files contain new contract and SDK consumer tests. No dependency, command-line flag, service or framework is added.

Exact paths, SHA-256 hashes, Git blobs, candidate/control differences, anchored selectors and expected results are in [qualification-plan-preformat.json](qualification-plan-preformat.json). The six changed files are frozen in [candidate-freeze-preformat.json](candidate-freeze-preformat.json). The full source delta is [candidate-preformat.diff](candidate-preformat.diff).

## 2. Chosen transport contract

### Initialization and headers

The server chooses the negotiated protocol version through `InitializeResult`; subsequent Hypertext Transfer Protocol (HTTP) requests carry `MCP-Protocol-Version` [1, 2]. The relay observes the matching complete result and forwards it to standard output. Only after the entire newline-delimited output frame succeeds does it publish the session identifier and version together under the existing mutex. An ordinary response header cannot establish a session. This closes the earlier path where a GET request could start before the initialization body or output frame had completed.

The version is taken from a successful response with the matching JavaScript Object Notation Remote Procedure Call (JSON-RPC) identifier. Errors, notifications, missing/null results, mismatched identifiers, empty versions and invalid date strings do not establish negotiated state. These otherwise valid JSON payloads still pass to the peer; this is not a new full MCP schema validator. Date syntax prevents invalid HTTP metadata without selecting a new protocol-version allowlist. Compatibility remains an endpoint decision. Stateless sessions still send the learned version on later POST requests.

MCP requires a string or integer request identifier, and a matching result identifier [3]. Strings are compared after JSON decoding, including equivalent escapes. Numbers retain their decimal coefficient and exponent separately. Removing a decimal point subtracts its fractional digit count from the exponent; removing trailing coefficient zeroes adds their count. A nonzero coefficient with a negative adjusted exponent is not an integer MCP identifier. Zero is canonical regardless of its sign or exponent. Comparison therefore does not round adjacent large integers through `float64`.

Exponent normalization never constructs a power of ten or a large arbitrary-precision integer. Up to eighteen significant exponent digits fit safely in signed 64-bit arithmetic together with the bounded message-size adjustment. Longer decimal exponent strings receive only that small adjustment through a single carry/borrow scan. The request/response byte limits bound the adjustment, so it cannot reverse the sign of such a long exponent. Coefficient scans, exponent scans and copies all have work and storage proportional to admitted input bytes. This is an inspection argument; no CPU or memory performance result has been measured.

If the server minted a session but initialization could not be published, the same POST worker retains that pending identifier locally, closes its response body and attempts `DELETE` under the existing independent two-second cleanup bound. A complete valid result can supply the cleanup version before output succeeds; that value remains local and is not visible to normal POST/GET traffic. `Run` still joins the worker. Successful initialization uses ordinary end-of-lifetime deletion and clears negotiated state, including stateless state, before a subsequent `Run`.

### GET server-sent event retry

Server-sent events (SSE) use a `retry` field containing only ASCII decimal digits. Field parsing removes at most one ASCII space after the colon; other whitespace, signs, decimal points, exponent notation and non-ASCII digits are invalid [4]. The listener begins with its existing one-second delay and persists the latest valid server value across that GET stream's clean reconnects and transport retries. Zero and leading zeroes are accepted.

The retry field takes effect as soon as the field is processed, including a field at end of file. It is independent of the existing event cursor commit. A cursor still advances only after a completed accepted event block; parser or standard-output errors still terminate the stream and do not authorize reconnect or POST replay. The GET listener owns the retry duration. POST and finite qualification readers pass no retry state because those paths do not perform this reconnect operation.

The maximum representable millisecond delay is checked before multiplication into `time.Duration`. A syntactically valid larger integer terminates the GET listener with an explicit error. It cannot wrap into a short or negative wait, or be ignored in favor of an earlier retry. Waits remain context-cancelable. This is an explicit implementation bound, not support for an unbounded integer delay.

## 3. Own review and corrected findings

Table 2. Findings resolved before execution.

| Location/condition | Consequence considered | Correction and distinguishing check |
|---|---|---|
| Initialization session publication before body/output completion | GET could use a newly minted session with no negotiated header. | Defer publication until a matching complete result and successful newline; hold the body and then output newline in two-media tests. |
| Other POST response containing a session header after failed initialization | The retained legacy `setSessionID` branch bypassed paired admission. | Remove header-only establishment; send a late session header in invalid-result and stateless tests. This was also raised by the parent's independent source review. |
| Hidden pending session after output failure | Delaying public state alone would lose the identity needed for best-effort cleanup. | Keep pending identity within the POST worker, close the body before deletion, and join the bounded cleanup. The test expects one cleanup DELETE with the selected version and a two-second joined timeout case. |
| Reusing a floating-point identifier decoder | Adjacent integers above the exactly represented floating-point range could compare equal. | Compare exact decimal representations; test adjacent large values and equivalent numeric syntax. |
| Parsing arbitrarily long exponent digits into `math/big.Int` | Potential superlinear CPU work despite byte limits; no measured incident was claimed. | Remove `math/big`; use bounded-pass decimal carry/borrow. Request-sized carry and response-sized leading-zero cases exercise admitted large inputs. This risk was raised by the parent review. |
| Carry beyond all-nine exponent digits | Trimming zeroes before prepending the carry would lose exponent digits. | Prepend carry before normalization; corrected during own inspection before the freeze. |
| SDK consumer output order versus callback scheduling | Callback concurrency could make a delivery-order assertion depend on SDK scheduling. | Check each consumer payload once, and independently inspect actual serialized relay output order after settlement. |

Own review covered requirements, synchronization and ownership, protocol/header safety, state reset, input-size bounds, compatibility, error/cursor behavior, cleanup order and complexity. No further mandatory source finding remained at the freeze. This does not establish executable correctness: formatting, compilation, race checks, real consumer execution, finite controls and the parent's final review are still pending.

## 4. Admitted qualification plan

Table 3. Candidate selections, all with exact anchored root lists in the JSON plan.

| Phase | Root tests | Purpose |
|---|---:|---|
| New contract | 11 | Header propagation and admission; JSON identifier value; reset; retry grammar/persistence/cancellation/overflow; terminal parser failure. |
| Existing response contract | 25 | Existing response size limits, framing, priming/control events, independent errors, cursor commits, timeouts and no POST redirect replay. |
| Existing ownership neighbors | 23 | The earlier seventeen admitted roots plus the six other output ownership/drain roots; owned interruption, borrowed input, concurrent producers, settlement and finite qualification behavior. |
| Existing session fixtures | 4 | Initialization, subsequent session headers, graceful deletion and release of session references. |
| Actual SDK GET consumer | 1 | Real client over owned stdio pipes, Relay HTTP workers, loopback SDK server and its actual memory event store. |

These are 64 distinct candidate roots, not a count of subtests or expected JSON event records. Requested count is one with Go's race detector. The runner must report the actual nested results, source identity and settlement, not infer them from a wrapper exit code.

The SDK profile negotiates the existing `2025-11-25` SDK baseline, enables logging through the real client operation, then sends 32 SDK `notifications/message` payloads. An HTTP boundary wrapper injects a 75-millisecond retry control and closes the first main GET after four SDK messages. Remaining messages enter the SDK's real event store while that stream is detached. The resumed GET must carry its actual last event identifier and negotiated headers. The test checks all 32 consumer payloads without duplicates/loss, serialized output order, a subsequent client ping, one session DELETE, event-store session cleanup, and joined client/relay/server/HTTP ownership. The wrapper does not synthesize SDK message identifiers or replay responses [5, 6].

Four finite negative-control phases run the **same new contract test file** against exact preceding #629 production plus its unchanged qualification/parser/session test signatures. They select version (three roots), admission/cleanup (two), retry fields/persistence (two), and overflow (one). Each selected root must show assertion failure and the package must fail with the expected child exit code. Global Go timeouts, panics, runner failure, unresolved process descendants and missing output are not valid control results. The real network consumer and old lifetime-sensitive tests are not negative controls.

No full Go suite, installed product, native scheduler, policy/credential operation, external service, model quota, dependency installation/download or manual continuous integration dispatch is included. The parent retains responsibility for an exact reviewed runner, test-entry fixtures, isolated environment, cached toolchain/module identity and subsequent publication.

## 5. Remaining limits

- No test in this increment has yet executed. The local `/usr/bin/go` was observed to be a different program, and no local Go toolchain or formatter was found. The parent must format in the authorized isolated Windows area before deriving final hashes and independent review.
- GET reconnection is the implemented boundary. Resuming a response stream originally opened by POST remains separate; the implementation never resends that POST to obtain an answer of uncertain effect.
- The SDK test is a finite functional consumer profile. It does not close PR #626's peak/retained memory, throughput, latency-distribution or representative production-consumer requirements.
- Existing GET status/retry-count policy, full SSE carriage-return/BOM conformance, and arbitrary-duration support are not generalized here. The documented representable-delay bound remains explicit.
- The complete daemon test package still needs the parent's admitted process-test entry fixtures. A safe root selector alone is not a complete test-binary admission argument.
- The preserved physical source, overlay composition and exact published branch remain different identities until separately bound and verified. No standalone branch, installed product, full-gate or release acceptance is claimed.
- External review of an eventual exact published head remains outstanding; neither source review nor a future focused pass substitutes for it.

## 6. Primary sources

1. [MCP 2025-11-25 — transports](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports): version header, initialization session identifiers, GET, resumption and server retry requirements.
2. [MCP 2025-11-25 — lifecycle](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle): endpoint protocol-version negotiation.
3. [MCP 2025-11-25 — basic messages](https://modelcontextprotocol.io/specification/2025-11-25/basic): string/integer non-null identifiers and matching result identifiers.
4. [WHATWG HTML — server-sent event interpretation](https://html.spec.whatwg.org/multipage/server-sent-events.html#event-stream-interpretation): field parsing and decimal ASCII `retry` semantics.
5. [Go SDK exact `streamable.go`](https://github.com/modelcontextprotocol/go-sdk/blob/d454bbaf06a342aee5336df3370321d9cdec2478/mcp/streamable.go): version headers, main GET stream, event cursor replay, and request-stream close API.
6. [Go SDK exact `event.go`](https://github.com/modelcontextprotocol/go-sdk/blob/d454bbaf06a342aee5336df3370321d9cdec2478/mcp/event.go), [client](https://github.com/modelcontextprotocol/go-sdk/blob/d454bbaf06a342aee5336df3370321d9cdec2478/mcp/client.go), [server](https://github.com/modelcontextprotocol/go-sdk/blob/d454bbaf06a342aee5336df3370321d9cdec2478/mcp/server.go) and [stdio transport](https://github.com/modelcontextprotocol/go-sdk/blob/d454bbaf06a342aee5336df3370321d9cdec2478/mcp/transport.go): actual event-store, consumer, notification, connection and close contracts used by the prepared test.
