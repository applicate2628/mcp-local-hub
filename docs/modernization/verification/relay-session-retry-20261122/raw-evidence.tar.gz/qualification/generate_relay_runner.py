"""Derive fixed Relay argv/oracles from the reviewed retained-owner runner."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import pprint

ROOT = Path(__file__).resolve().parent
parent = (ROOT / "reader_runner.py").read_text()
parent_sha = hashlib.sha256(parent.encode()).hexdigest()
assert parent_sha == "1008740b5420f9a85b1ae2aa9e62ab1691d12f228eec0cbcaaba7d1e32fa7560"
plan = json.loads((ROOT.parent / "relay/qualification-plan-preformat.json").read_text())
oracles = json.loads((ROOT.parent / "relay/control-oracles.json").read_text())["phases"]
paths = sorted([row["path"] for row in plan["files"]] + plan["root_owned_required_overlays"])
assert len(paths) == len(set(paths)) == 20
phases = {"control": set(), "candidate": {"relay-format", "relay-build", "relay-vet"}}

def fmt(label):
    return {"label": label, "kind": "format", "args": ["-l", "{candidate_files}"], "timeout_seconds": 30, "expected_exit_code": 0}

commands = {
    "relay-format": [
        {"label": "relay-version", "kind": "version", "args": ["version"], "timeout_seconds": 30, "expected_exit_code": 0},
        fmt("relay-format"),
    ],
}
for name, phase in plan["phases"].items():
    assert phase["package"] == "./internal/daemon" and phase["count"] == 1 and phase["race"] is True
    phases[phase["variant"]].add(name)
    command = {
        "label": name, "kind": "test",
        "args": ["test", "-overlay", "{overlay}", "-p=2", "-race", "-count=1", "-timeout=90s", "-json", "-run", phase["selector"], "./internal/daemon"],
        "timeout_seconds": 300, "expected_exit_code": phase["expected_exit"],
    }
    if phase["variant"] == "control":
        assert name in oracles and oracles[name]["expected_tests"]["skip"] == []
        command.update(expected_tests=oracles[name]["expected_tests"], required_output=oracles[name]["required_output"])
    else:
        command["required_root_pass_counts"] = {root: 1 for root in phase["roots"]}
        if name == "relay-v3-consumer":
            command["expected_tests"] = {"pass": ["TestRelayConsumerGETSSEResume", "PACKAGE:mcp-local-hub/internal/daemon"], "fail": [], "skip": []}
            command["required_output"] = ["real SDK GET-SSE consumer: sent=32 delivered=32 GETs=2"]
    commands[name] = [fmt(name + "-format"), command]
for kind in ("build", "vet"):
    name = "relay-" + kind
    commands[name] = [fmt(name + "-format"), {"label": name, "kind": kind, "args": [kind, "-overlay", "{overlay}", "-p=2", "./..."], "timeout_seconds": 300, "expected_exit_code": 0}]
assert len(commands) == 12
doc = '''"""Qualify the fixed Relay negotiation/retry composition on preserved source 858.

Derived from the pinned reader runner. Retained-original-Popen execution,
capture, offline D: environment, tool/source/candidate admission and full
3281-file materialized source checks are retained. Changed fixed inputs select
twenty Relay/daemon-entry overlays and exact finite test groups. Windows amd64
is explicit. No Linux phase, arbitrary selection, fetch or checkout exists.

The tests use finite fake transports and owned loopback SDK servers/pipes.
Only the declared real SDK consumer profile exercises GET-origin resumption;
POST-origin resumption and peak/retained-memory claims remain outside scope.
Full default/tagged suites and external exact-head review remain unexecuted.
"""'''
source = doc + parent[parent.index('\nimport sys'):]
source = source.replace('UPSTREAM_OWNER_SHA256 = "d8cb7090ddda09cb14a50759f56397a55ff03f3a6ce9bfc29f226788217ed17e"', 'UPSTREAM_OWNER_SHA256 = "' + parent_sha + '"')
start, end = source.index('PHASES = '), source.index('TOOL_PINS = ')
source = source[:start] + '\n'.join([
    'PHASES = ' + pprint.pformat(phases, width=110),
    'EXPECTED_PATHS = ' + pprint.pformat(paths, width=110),
    'COMMANDS = ' + pprint.pformat(commands, width=120, sort_dicts=False),
]) + '\n' + source[end:]
source = source.replace('Invalid reader composition', 'Invalid Relay composition')
source = source.replace('Each reader composition requires its eight change paths and five canonical API entry paths', 'Each Relay composition requires its eighteen source paths and two canonical daemon entry paths')
source = source.replace('Each reader phase must retain all thirteen reviewed overlays', 'Each Relay phase must retain all twenty reviewed overlays')
source = source.replace('Reader command arguments, deadlines or terminal-event oracles changed', 'Relay command arguments, deadlines or terminal-event oracles changed')
source = source.replace('"GOOS": "linux" if self.phase == "reader-linux-compile" else "windows",', '"GOOS": "windows",')
source = source.replace('"GOARCH": "amd64", "CGO_ENABLED": "0" if self.phase == "reader-linux-compile" else "1",', '"GOARCH": "amd64", "CGO_ENABLED": "1",')
source = source.replace('Use reader_runner.py', 'Use relay_runner.py')
ast.parse(source)
(ROOT / "relay_runner.py").write_text(source)
(ROOT / "relay_runner.delta.patch").write_text(''.join(difflib.unified_diff(parent.splitlines(True), source.splitlines(True), fromfile="reader_runner.py", tofile="relay_runner.py")))
(ROOT / "relay-runner-scope.json").write_text(json.dumps({"parent_sha256": parent_sha, "runner_sha256": hashlib.sha256(source.encode()).hexdigest(), "paths": paths, "phases": {k: sorted(v) for k, v in phases.items()}, "commands": commands}, indent=2) + "\n")
print(json.dumps({"runner_bytes": len(source.encode()), "runner_sha256": hashlib.sha256(source.encode()).hexdigest(), "paths": len(paths), "phases": len(commands)}))
