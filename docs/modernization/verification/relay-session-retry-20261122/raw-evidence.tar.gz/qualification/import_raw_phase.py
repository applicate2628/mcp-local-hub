from pathlib import Path, PurePosixPath
import base64
import hashlib
import json
import sys
import zlib

root = Path(__file__).resolve().parent
phase, expected = sys.argv[1:]
assert phase.startswith(('reader-', 'relay-')) and all(c.isalnum() or c == '-' for c in phase)
raw = zlib.decompress(base64.b64decode((root / 'remote-transfers' / (phase + '.b64')).read_bytes().removesuffix(b'\n'), validate=True))
assert hashlib.sha256(raw).hexdigest() == expected
data = json.loads(raw)
assert data['phase'] == phase
out = root / 'raw' / phase
out.mkdir(parents=True, exist_ok=False)
inventory = []
for row in data['files']:
    relative = PurePosixPath(row['path'])
    assert not relative.is_absolute() and str(relative) == row['path'] and not any(x in ('..', '.', '') for x in relative.parts)
    content = base64.b64decode(row['base64'], validate=True)
    assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256']
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(content)
    inventory.append({k: row[k] for k in ('path', 'bytes', 'sha256')})
receipt = {'phase': phase, 'transfer_sha256': expected, 'transfer_bytes': len(raw), 'files': inventory}
with (root / 'remote-transfers' / (phase + '-import.json')).open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'phase': phase, 'files': len(inventory), 'bytes': sum(x['bytes'] for x in inventory), 'transfer_sha256': expected}))
