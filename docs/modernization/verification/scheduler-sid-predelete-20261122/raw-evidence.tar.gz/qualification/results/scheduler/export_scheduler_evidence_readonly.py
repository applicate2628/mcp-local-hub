"""Read exactly three settled evidence directories; export bytes in memory only."""
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import zlib

if not (os.name == "nt" and sys.flags.isolated and sys.flags.no_site
        and sys.flags.dont_write_bytecode and not sys.flags.optimize):
    raise RuntimeError("Windows Python -I -S -B required")

root = Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
phases = {
    "scheduler-sid-control": ["owner-control"],
    "scheduler-predelete-control": ["predelete-control"],
    "scheduler-sid-predelete-candidate": [
        "scheduler-owners", "api-owners-hold-recovery", "build", "vet"],
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def guarded(path, directory=False):
    for ancestor in (path, *path.parents):
        info = ancestor.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse path refused: " + str(ancestor))
    info = path.lstat()
    if directory and not stat.S_ISDIR(info.st_mode):
        raise RuntimeError("Not an ordinary directory")
    if not directory and not stat.S_ISREG(info.st_mode):
        raise RuntimeError("Not an ordinary file")
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns

guarded(root, True)
os.chdir(root)
rows = []
checks = []
for phase, commands in phases.items():
    folder = root / "evidence" / phase
    guarded(folder, True)
    expected = {"receipt-initial.json", "receipt.json"}
    for command in commands:
        expected.update(command + suffix for suffix in (
            ".started.json", ".launched.json", ".receipt.json",
            ".stdout.log", ".stderr.log"))
    if set(p.name for p in folder.iterdir()) != expected:
        raise RuntimeError("Evidence directory differs from exact expected file set")
    guarded(folder / "receipt.json")
    receipt = json.loads((folder / "receipt.json").read_bytes())
    if receipt.get("completed") is not True:
        raise RuntimeError("Evidence phase is not complete")
    for name in sorted(expected):
        path = folder / name
        before = guarded(path)
        data = path.read_bytes()
        if guarded(path) != before or len(data) != before[2]:
            raise RuntimeError("Evidence changed during read")
        row = {"path": phase + "/" + name, "bytes": len(data),
               "sha256": sha(data), "data_base64": base64.b64encode(data).decode("ascii")}
        rows.append(row)
        checks.append((path, before, row["sha256"]))
for path, before, digest in checks:
    if guarded(path) != before or sha(path.read_bytes()) != digest or guarded(path) != before:
        raise RuntimeError("Evidence changed before export completion")
for phase, commands in phases.items():
    expected = {"receipt-initial.json", "receipt.json"}
    expected.update(command + suffix for command in commands for suffix in (
        ".started.json", ".launched.json", ".receipt.json", ".stdout.log", ".stderr.log"))
    if set(p.name for p in (root / "evidence" / phase).iterdir()) != expected:
        raise RuntimeError("Evidence file set changed during export")
payload = json.dumps({"schema": 1, "rows": rows}, separators=(",", ":"), ensure_ascii=True).encode()
compressed = zlib.compress(payload, 9)
print(json.dumps({
    "schema": 1, "state": "READ_ONLY_EXPORT_COMPLETE", "files": len(rows),
    "file_bytes": sum(row["bytes"] for row in rows),
    "payload_bytes": len(payload), "payload_sha256": sha(payload),
    "compressed_bytes": len(compressed), "compressed_sha256": sha(compressed),
    "encoding": "base64(zlib(JSON with per-file base64))",
    "data_base64": base64.b64encode(compressed).decode("ascii"),
    "all_files_rechecked": True, "remote_file_writes": False,
}, separators=(",", ":")), flush=True)
