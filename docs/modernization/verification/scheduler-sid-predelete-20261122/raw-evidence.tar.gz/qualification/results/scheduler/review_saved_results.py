"""Recount saved Scheduler evidence only; never execute Go or remote commands."""
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path, PureWindowsPath
import subprocess

B = Path(__file__).resolve().parents[3]
Q = B / "qualification"
RAW = Q / "results/scheduler"
E = B / "evidence"
BASE = "0bdb725ed261c532eba07d645c2a14880d12b9fd"
MASTER = "75dbc6406123e22468f168b861d5e0622c9d5769"
D = PureWindowsPath(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {"path": path.relative_to(B).as_posix(), "bytes": len(data), "sha256": sha(data)}


def save(path, value):
    data = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(data)
    assert path.read_bytes() == data
    return identity(path)


def inventory(rows):
    values = [[row["path"], row["bytes"], row["sha256"]] for row in rows]
    return {"files": len(values), "bytes": sum(row[1] for row in values),
            "inventory_sha256": sha(json.dumps(values, separators=(",", ":"), ensure_ascii=True).encode())}


def git_file(ref, path):
    return subprocess.check_output(["git", "show", ref + ":" + path], cwd=B / "scheduler")


phases, observed = [], {}
for phase in ("scheduler-sid-control", "scheduler-predelete-control", "scheduler-sid-predelete-candidate"):
    plan_path = Q / "plans" / (phase + ".json")
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    folder = RAW / phase
    receipt = json.loads((folder / "receipt.json").read_bytes())
    assert receipt["completed"] and not receipt.get("error") and not receipt.get("after_error")
    assert receipt["manifest_sha256"] == sha(plan_bytes)
    assert receipt["runner_sha256"] == plan["runner_sha256"] == sha((Q / "qualify_go.py").read_bytes())
    assert receipt["source_before"] == receipt["source_after"] == inventory(plan["source_files"])
    assert receipt["inputs_before"] == receipt["inputs_after"] == inventory(plan["input_files"])
    assert len(plan["source_files"]) == 3281 and len(plan["input_files"]) == 45
    for row in plan["input_files"]:
        data = (Q / "inputs" / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert len(receipt["commands"]) == len(plan["commands"])
    commands = []
    for command, expected in zip(receipt["commands"], plan["commands"]):
        label = command["label"]
        assert label == expected["label"]
        assert command == json.loads((folder / (label + ".receipt.json")).read_bytes())
        for suffix in ("started", "launched"):
            initial = json.loads((folder / (label + "." + suffix + ".json")).read_bytes())
            for key in ("label", "argv", "cwd", "started_utc", "direct_timeout_seconds", "pid"):
                if key in initial:
                    assert initial[key] == command[key]
            assert not initial["settled"] and not initial["timed_out"]
        assert command["argv"][1:] == expected["args"]
        assert command["exit_code"] == expected["expected_exit_code"]
        assert command["settled"] and command["oracle_pass"] and not command["timed_out"]
        assert not any(key in command for key in ("error_type", "termination_error", "process_tree_unresolved"))
        assert command["direct_timeout_seconds"] == expected["timeout_seconds"] == 300
        for stream in ("stdout", "stderr"):
            data = (folder / (label + "." + stream + ".log")).read_bytes()
            assert command[stream] == {"bytes": len(data), "sha256": sha(data)}
        stdout = (folder / (label + ".stdout.log")).read_bytes()
        assert not (folder / (label + ".stderr.log")).read_bytes()
        events = [json.loads(line) for line in stdout.splitlines()] if expected["args"][0] == "test" else []
        terminal = {action: [event.get("Test", "PACKAGE:" + event["Package"]) for event in events
                            if event.get("Action") == action] for action in ("pass", "fail", "skip")}
        roots = []
        if events:
            assert all(Counter(terminal[action]) == Counter(command["tests"][action]) for action in terminal)
            every = [name for names in terminal.values() for name in names]
            assert all(count == 1 for count in Counter(every).values())
            roots = sorted(name for name in every if "/" not in name and not name.startswith("PACKAGE:"))
            selector = command["argv"][command["argv"].index("-run") + 1]
            assert set(roots) == set(selector[2:-2].split("|"))
        assert all(text.encode() in stdout for text in expected.get("required_output", []))
        row = {key: command[key] for key in ("label", "argv", "exit_code", "seconds", "settled", "timed_out", "oracle_pass", "stdout", "stderr")}
        row.update(command_receipt=identity(folder / (label + ".receipt.json")),
                   race_detector_enabled="-race" in command["argv"], selected_roots=roots,
                   terminal_events=terminal, events_json_lines=len(events),
                   test_counts={action: sum(not name.startswith("PACKAGE:") for name in names) for action, names in terminal.items()},
                   package_counts={action: sum(name.startswith("PACKAGE:") for name in names) for action, names in terminal.items()})
        commands.append(row)
        observed[label] = (row, events)
    phases.append({"phase": phase, "plan": identity(plan_path), "receipt": identity(folder / "receipt.json"),
                   "started_utc": receipt["started_utc"], "finished_utc": receipt["finished_utc"], "completed": True,
                   "source_before_after": receipt["source_before"], "inputs_before_after": receipt["inputs_before"],
                   "local_plan_inputs_all_match": True, "native_scheduler_operations": receipt["native_scheduler_operations"],
                   "tools_sha256": receipt["tools_sha256"], "commands": commands})

candidate_plan = plan
sid_pass = ["TestSchedulerCOMOwnerSIDProjection/" + name for name in
            ("list-SID-literal", "status-SID-literal", "export-retains-raw-owner-without-lookup")]
sid_fail = ["TestWindowsSchedulerCurrentOwnerUsesSID", "TestSchedulerCOMOwnerSIDProjection"] + [
    "TestSchedulerCOMOwnerSIDProjection/" + name for name in
    ("list-same-short-name-different-SID", "list-unknown-after-good", "list-empty-after-good",
     "status-qualified-owner", "status-unknown-owner", "status-empty-owner")]
sid = observed["owner-control"][0]
assert Counter(sid["terminal_events"]["pass"]) == Counter(sid_pass)
assert Counter(sid["terminal_events"]["fail"]) == Counter(sid_fail + ["PACKAGE:mcp-local-hub/internal/scheduler"])
assert not sid["terminal_events"]["skip"]
predelete = json.loads((E / "scheduler-predelete-files.json").read_bytes())["tests"]
control = observed["predelete-control"][0]
expected = predelete["negative_control"]["new_only_expected"]
assert Counter(control["terminal_events"]["pass"]) == Counter(expected["pass_tests"])
assert Counter(control["terminal_events"]["fail"]) == Counter(expected["fail_tests"] + ["PACKAGE:mcp-local-hub/internal/api"])
assert not control["terminal_events"]["skip"]
api, api_events = observed["api-owners-hold-recovery"]
assert observed["scheduler-owners"][0]["test_counts"] == {"pass": 45, "fail": 0, "skip": 0}
assert api["test_counts"] == {"pass": 129, "fail": 0, "skip": 1}
for label in ("scheduler-owners", "api-owners-hold-recovery"):
    assert observed[label][0]["package_counts"] == {"pass": 1, "fail": 0, "skip": 0}
expected_predelete = predelete["candidate_combined_expected"]["terminal_tests"]
predelete_roots = {name.split("/")[0] for name in expected_predelete}
assert Counter(name for name in api["terminal_events"]["pass"] if name.split("/")[0] in predelete_roots) == Counter(expected_predelete)
assert len(expected_predelete) == 39
skip = "TestExecuteInstallToRollbackBackendCompatibility/unsupported_platform"
assert api["terminal_events"]["skip"] == [skip]
skip_output = [event["Output"] for event in api_events if event.get("Test") == skip and "Output" in event]
assert any("native backend is supported on this platform" in line for line in skip_output)

mapping_path = Q / "inputs/scheduler-predelete/overlay.json"
mapping = json.loads(mapping_path.read_bytes())["Replace"]
assert len(mapping) == 39
input_rows = {row["path"]: row for row in candidate_plan["input_files"]}
source_rows = {row["path"]: row for row in candidate_plan["source_files"]}
overlays = []
for source, replacement in sorted(mapping.items()):
    path = PureWindowsPath(source).relative_to(D / "source").as_posix()
    input_path = PureWindowsPath(replacement).relative_to(D / "inputs").as_posix()
    row = dict(input_rows[input_path])
    row.update(source_path=path, source_baseline_sha256=source_rows.get(path, {}).get("sha256"))
    overlays.append(row)

hold_path = "internal/api/install_parsed_manifest.go"
old, master = git_file(BASE, hold_path), git_file(MASTER, hold_path)
qualified_path = Q / "inputs/scheduler" / hold_path
qualified = qualified_path.read_bytes()
guard = b"\t\t\t\t\t\tlen(installSchedulerRecoveryTasks(err)) == 0 &&\n"
assert qualified.count(guard) == old.count(guard) == 1 and master.count(guard) == 0
assert qualified.replace(guard, b"") == master
patch = "".join(difflib.unified_diff(old.decode().splitlines(True), qualified.decode().splitlines(True),
                                  fromfile="a/" + hold_path, tofile="b/" + hold_path))
assert len([line for line in patch.splitlines() if line.startswith("@@ ")]) == 2
patch_path = E / "scheduler-backend-hold-integration-only.patch"
with patch_path.open("xb") as stream:
    stream.write(patch.encode())
missing = ["internal/api/supervisor_backend_run_hold.go", "internal/api/supervisor_backend_hold_passive_windows_test.go"]
for path in missing:
    result = subprocess.run(["git", "cat-file", "-e", BASE + ":" + path], cwd=B / "scheduler", capture_output=True)
    assert result.returncode != 0
assert b"BackendRunHold" not in git_file(BASE, "internal/api/supervisor_intent.go")
assert b"BackendRunHold" in git_file(MASTER, "internal/api/supervisor_intent.go")
proposal = {
    "schema": 1, "status": "INTEGRATION_ONLY_DIFF_NOT_APPLICABLE_STANDALONE", "base": BASE, "master": MASTER,
    "qualified_file": identity(qualified_path), "integration_patch": identity(patch_path),
    "file_identities": {name: {"bytes": len(data), "sha256": sha(data)} for name, data in (("pr660", old), ("master75", master), ("qualified", qualified))},
    "exact_relations": {"qualified_minus_pr660": "Exactly two master Hold hunks; the recovery guard is unchanged.",
                        "qualified_minus_master75": "Exactly the existing #660 len(installSchedulerRecoveryTasks(err)) == 0 guard.",
                        "reverse_guard_removal_is_not_the_qualified_delta": True},
    "hold_effects": ["Merge clones prior.BackendRunHold without sharing its mutable Work slice.",
                     "Preflight clears a nonzero hold only on a cloned temporary probe; desired and authoritative intent remain unchanged."],
    "guard": {"location": "installPlanCoreWithSymlinkConsents, immediately after a.installPlan returns an error",
              "conditions": "invocation == nil, freshProviderInstall, !intentWriteAttempted; no excluded client/forward-commit/settlement errors",
              "purpose": "Outstanding current/later Scheduler recovery names must not manufacture providerInstallUnpublishedRollbackError.",
              "effect_if_removed": "install.go consumes that affirmative wrapper after inner lock release and calls markProviderUnpublishedRollbackSettled; unresolved Scheduler effects could be falsely certified as a settled unpublished provider rollback.",
              "present_in_qualified_source": True, "dedicated_provider_guard_test_in_current_selector": False},
    "standalone_blocker": {"missing_files_in_pr660": missing, "missing_field": "SupervisorIntentFile.BackendRunHold",
                           "missing_type_methods": ["SupervisorBackendRunHold", "clone", "IsZero"],
                           "effect": "Two hunks alone reference an absent master model; composition tests also require absent master fixtures."},
    "accepted_boundary": "Publish only SID + pre-delete source changes on current #660. Keep Hold hunks and fixture in qualification inputs/evidence. No partial Hold transfer, whole-file overlay, merge, rebase, tree synchronization or dependency expansion.",
    "future_requirement": "Full integration with master must retain both Hold behaviors and the Scheduler recovery guard. The executed composition already contains all three.",
    "production_files_changed_by_this_comparison": False, "remote_refs_changed": False,
}
proposal_identity = save(E / "scheduler-backend-hold-proposal.json", proposal)
report = {
    "schema": 1, "status": "OBSERVED_SCOPED_WINDOWS_QUALIFICATION_WITH_EXPECTED_NEGATIVE_CONTROLS",
    "reviewer": "scheduler_residual: candidate author own evidence review, not external published-head review",
    "collection": "Read-only export of exactly three authorized Windows evidence directories. Every byte was hashed and reread remotely before in-memory export; local decoded files match. No Go/Rust/native Scheduler operation during collection.",
    "raw_export": identity(RAW / "raw-export-manifest.json"), "raw_payload": identity(RAW / "raw-export.json.zlib"),
    "raw_tool_result": identity(RAW / "raw-export-tool-result.json"),
    "composition": {"source_head": candidate_plan["source_head"], "source_tree": candidate_plan["source_tree"],
                    "source_inventory": phases[-1]["source_before_after"], "base_pr660": BASE, "master": MASTER,
                    "go_overlay_count": 39, "overlay_map": identity(mapping_path), "overlay_files": overlays,
                    "api_testmain_donor": "b5cd530969b7089e7d7cbaf5308543be8c443f8c", "standalone_pr_head_tested": False,
                    "explanation": "Preserved source858/master75 plus 39 Go overlays. The 45 pinned phase inputs also include maps and alternative control files; 45 is not the active Go overlay count."},
    "phases": phases,
    "totals": {"candidate_test_pass": 174, "candidate_test_fail": 0, "candidate_test_skip": 1,
               "candidate_package_pass": 2, "candidate_package_fail": 0, "candidate_selected_roots": 35,
               "candidate_build_exit": 0, "candidate_vet_exit": 0, "control_test_pass": 5,
               "control_test_fail": 22, "control_package_fail": 2, "control_test_skip": 0},
    "strict_oracles": {"terminal_names_once_each": True, "selected_root_multisets_exact": True,
                       "receipt_terminal_multisets_equal_raw": True, "sid_control_exact_pass": sid_pass,
                       "sid_control_exact_fail": sid_fail, "predelete_control_expected_multisets_exact": True,
                       "predelete_candidate_exact_39_pass_names": expected_predelete,
                       "command_argv_and_stream_hashes_match": True, "all_six_direct_children_settled": True, "timeouts": 0},
    "skip": {"test": skip, "raw_output": skip_output,
             "source": "qualification/inputs/scheduler-predelete/internal/api/install_task_rollback_test.go",
             "condition": "On Windows the unsupported-platform branch skips before clearing MCPHUB_E2E_SCHEDULER or creating a native backend.",
             "interpretation": "Expected platform-specific exclusion, not a native Scheduler PASS."},
    "source_fixture_review": [
        "SID fixture replaces the single Schedule.Service connection and NTAccount translation with in-memory PowerShell objects; leftover native boundaries are rejected. Its Run writes only a marker; Stop/Delete throw. Public queries use withCOMRunner; user.Current is a read-only identity observation.",
        "LastTaskResult script fixture replaces the unique Schedule.Service connection with memory GetTasks/GetFolder/property getters. Public Status/List/Export use withCOMRunner. Real PowerShell children execute substituted production scripts; this is not native Scheduler execution.",
        "Entrypoint tests inject newEntrypointTaskBackendFake and use a lock in t.TempDir. Account-equality cases use pure string predicates.",
        "API ownership mocks PID/image/task observations. installRecoveryPlan replaces schedulerFactoryFn with a memory fake and restores it via t.Cleanup. Snapshots, manifests and protected state directories are newly test-owned. The noop branch uses MCPHUB_E2E_SCHEDULER=none.",
        "Adopt's nextBindableAdoptPortForTest creates a finite loopback listener and closes it before returning; its install callback returns to the memory Scheduler. No external service is used.",
        "The canonical API TestMain redirects client profiles and state, audits configuration paths and seals live IPC, autostart, process lookup and kill paths. The chosen roots do not enter helper-test modes."],
    "source_review_references": [identity(E / "scheduler-predelete-source-review.json"), identity(E / "scheduler-composition-independent-review.json")],
    "backend_hold_proposal": proposal_identity,
    "limits": [
        "This is source858 plus 39 overlays, not execution of a standalone #660 head or readiness to merge.",
        "Native Run/RunOwned/Stop/Delete, real domain resolution, permissions/credentials, native external replacement and process-tree cancellation/lifetime remain unqualified here.",
        "The final XML read-to-Delete window remains. Equal XML does not prove generation, security-descriptor or credential identity.",
        "Retained direct-child receipts do not prove whole-process-tree settlement.",
        "Selected tests used -race; full Go test suites were not run. Full build/vet succeeded for this composition only.",
        "The provider recovery guard is source-bound and unchanged; its dedicated provider-adopt test was not selected in these phases.",
        "External published-head review, publication/readback and cleanup are outside this report.",
        "The first evidence-export command failed at cmd quoting before Python ran. Its raw diagnostic is preserved as transport history, not counted as a Go outcome."],
}
result_identity = save(E / "scheduler-sid-predelete-results.json", report)
print(json.dumps({"results": result_identity, "proposal": proposal_identity,
                  "integration_patch": identity(patch_path), "totals": report["totals"]}, indent=2))
