#!/usr/bin/env python3
"""Freeze reviewed source deltas and complete named qualification inputs for GitHub."""
from pathlib import Path, PureWindowsPath
import gzip, hashlib, io, json, subprocess, sys, tarfile

ROOT = Path(__file__).resolve().parents[1]
REMOTE = PureWindowsPath(r'D:\dev\ChatGPT\mcp-final-20261122-e21a1792')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def identity(data):
    return {'bytes': len(data), 'sha256': digest(data),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT/'repo'), *args])

def main():
    scope = sys.argv[1]
    config = {
        'relay': (626, 'profiles', 'relay-sdk-consumer-profile-20261122',
                  'relay-sdk-profile-publication-README.md',
                  ['internal/daemon/relay_load_test.go', 'internal/daemon/relay_sdk_profile_windows_test.go']),
        'cmake': (624, 'cmake-profile', 'cmake-sdk-consumer-profile-20261122',
                  'cmake-sdk-profile-publication-README.md',
                  ['internal/vcpkgmcp/vcpkgserver/cmake_trace_sdk_profile_windows_test.go',
                   'internal/vcpkgmcp/vcpkgserver/cmake_trace_sdk_memory_windows_test.go',
                   'internal/vcpkgmcp/vcpkgserver/testdata/cmake_trace_sdk_profile_oracle.json']),
        'scheduler': (660, 'scheduler', 'scheduler-sid-predelete-20261122',
                      'scheduler-sid-predelete-README.md', []),
        'architecture': (663, 'architecture', 'architecture-owner-qualification-20261122',
                         'architecture-publication-README.md',
                         ['architecture/baseline.yaml', 'architecture/owners.yaml',
                          'internal/archguard/repository_contract_test.go']),
    }
    number, worktree, docname, readme, codepaths = config[scope]
    initial = json.loads((ROOT/'evidence/initial-state.json').read_text())
    pr = next(p for p in initial['prs'] if p['number'] == number)
    out = ROOT/'publication'/scope
    out.mkdir(parents=True, exist_ok=False)
    tree = out/'tree'
    docs = tree/'docs/modernization/verification'/docname
    docs.mkdir(parents=True)
    archive = {}
    code = {}

    def add(path, as_name=None):
        path = Path(path)
        if not path.is_absolute(): path = ROOT/path
        if path.is_symlink() or not path.is_file(): raise ValueError('Not a regular file: '+str(path))
        name = as_name or path.relative_to(ROOT).as_posix()
        if name.startswith('/') or '..' in Path(name).parts: raise ValueError(name)
        data = path.read_bytes()
        if name in archive and archive[name] != data: raise ValueError('Conflicting input: '+name)
        archive[name] = data
        return data

    def add_dir(path):
        path = ROOT/path
        for file in sorted(path.rglob('*')):
            if file.is_file(): add(file)

    for path in ['qualification/qualify_go.py', 'qualification/stage_inputs.py',
                 'qualification/prepare_source_remote.py', 'qualification/package_publication.py',
                 'qualification/go-runner-followup-review.json',
                 'qualification/go-runner-independent-review.json',
                 'evidence/preserved-source-github-readback.json']:
        add(path)
    add_dir('qualification/results/'+scope)

    if scope == 'cmake':
        plans = [ROOT/'qualification/cmake-package/cmake-sdk-profile-plan.json']
        for name in ['source-bundle-manifest.json', 'format-export.json', 'format-receipt.json',
                     'composition.json', 'final-plan-index.json', 'materialize_cmake_oracle.py',
                     'source-review.json', 'production-overlay-vs-master.patch', 'freeze_cmake_plan.py']:
            add('qualification/cmake-package/'+name)
        add_dir('qualification/cmake-package/materialization')
        add_dir('qualification/cmake-package/raw')
        add('qualification/analyze_cmake_profile.py')
        add('evidence/derive_cmake_profile_oracle.py')
        add('qualification/cmake-input/fixture-manifest.json')
        evidence = sorted((ROOT/'evidence').glob('cmake-sdk-*.json'))
        evidence += sorted((ROOT/'evidence').glob('cmake-sdk-*.patch'))
        evidence += sorted((ROOT/'evidence').glob('cmake-sdk-*.diff'))
    else:
        plans = sorted((ROOT/'qualification/plans').glob(scope+'*.json'))
        if scope == 'scheduler':
            plans = [p for p in plans if p.name != 'scheduler-sid-candidate.json']
            patterns = ['scheduler-sid-*', 'scheduler-predelete-*', 'scheduler-composition-*',
                        'scheduler-backend-hold-*', 'scheduler-residual.json']
            evidence = sorted({p for pattern in patterns for p in (ROOT/'evidence').glob(pattern)
                               if p.is_file()})
            manifests = [json.loads((ROOT/'evidence'/name).read_text())
                         for name in ['scheduler-sid-files.json', 'scheduler-predelete-files.json']]
            codepaths = sorted({row['path'] for manifest in manifests for row in manifest['files']})
            mapping = json.loads((ROOT/'qualification/inputs/scheduler-predelete/overlay.json').read_text())['Replace']
            for dest, source in mapping.items():
                rel = PureWindowsPath(dest).relative_to(REMOTE/'source').as_posix()
                if rel in codepaths:
                    input_rel = PureWindowsPath(source).relative_to(REMOTE/'inputs').as_posix()
                    code[rel] = (ROOT/'qualification/inputs'/input_rel).read_bytes()
            if set(code) != set(codepaths): raise ValueError('Missing scheduler publication source')
            for path in ['qualification/build_scheduler_final_plans.py',
                         'qualification/scheduler-final-plan-index.json']:
                add(path)
        elif scope == 'relay':
            evidence = sorted((ROOT/'evidence').glob('relay-sdk-*.json'))
            for path in ['qualification/formatted-relay.json', 'qualification/composition-origins.json',
                         'qualification/build_scoped_go_plans.py', 'qualification/scoped-go-plan-index.json']:
                add(path)
        else:
            evidence = sorted((ROOT/'evidence').glob('architecture-*'))
            evidence += sorted((ROOT/'evidence').glob('kr-text-*'))
            for path in ['qualification/apply_architecture_candidate_v1.py',
                         'qualification/reference/executed_prepare_architecture.py',
                         'qualification/prepare_architecture.py', 'qualification/build_architecture_plans.py']:
                add(path)
    for p in evidence:
        if p.is_file(): add(p)
    add('evidence/'+readme)
    for p in plans:
        plan = json.loads(add(p))
        for row in plan['input_files']:
            input_path = ROOT/'qualification/inputs'/row['path']
            if scope == 'cmake' and row['path'].startswith('cmake-sdk-profile/'):
                input_path = ROOT/'qualification/cmake-package/formatted/inputs'/row['path']
            data = add(input_path, 'qualification/inputs/'+row['path'])
            if len(data) != row['bytes'] or digest(data) != row['sha256']:
                raise ValueError('Frozen input differs: '+row['path'])
    for path in codepaths:
        if path not in code: code[path] = (ROOT/worktree/path).read_bytes()
        dest = tree/path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(code[path])
    if scope in ['relay', 'cmake', 'scheduler']:
        for path, data in code.items():
            candidates = [b for n, b in archive.items() if n.endswith('/'+path)]
            if data not in candidates: raise ValueError('Published source absent from qualified input: '+path)
    patch = []
    for path, data in sorted(code.items()):
        old = subprocess.run(['git', '-C', str(ROOT/'repo'), 'show', pr['head']+':'+path], capture_output=True)
        import difflib
        patch.extend(difflib.unified_diff(old.stdout.decode().splitlines(True), data.decode().splitlines(True),
                                         fromfile='a/'+path if old.returncode == 0 else '/dev/null', tofile='b/'+path))
    archive['publication/source-delta.patch'] = ''.join(patch).encode()
    archive['publication/source-pins.json'] = encoded({p:identity(b) for p,b in sorted(code.items())})
    source_review = {
        'reviewer':'root', 'base':pr['head'], 'scope':scope,
        'source_paths':list(sorted(code)),
        'requirements':'Only reviewed scoped candidate changes; no base synchronization, merge or unrelated source changes.',
        'qualification_boundary':'Exact input bytes and physical source are bound in preserved plans and results; composed Go evidence is not standalone branch qualification.',
        'security_and_lifecycle':'Reviewed owned resources, cancellation, original-handle behavior, bounded runners and explicit unproven native/full-suite boundaries.',
        'compatibility':'Existing published donor contracts retained. Scheduler BackendRunHold composition stays in evidence, not a partial API import into #660.',
        'mandatory_findings':[],
        'external_published_commit_review':'NOT_RUN',
    }
    archive['publication/root-review.json'] = encoded(source_review)
    redactions=[]
    for name,data in list(archive.items()):
        if b'<user>' in data:
            # Private account name appears in transport wrappers, never qualified source.
            data.decode('utf-8')
            public=data.replace(b'<user>', b'<user>')
            redactions.append({'path':name,'original':identity(data),'public':identity(public),
                               'rule':'Private Windows account component replaced with <user>.'})
            archive[name]=public
    if redactions:
        archive['publication/redactions.json']=encoded({
            'originals_retained_outside_trash':True,
            'public_redacted_bytes_are_not_original_execution_bytes':True,
            'files':redactions})
    members = [{'path':p, **identity(b)} for p,b in sorted(archive.items())]
    archive['archive-index.json'] = encoded({'schema':1,'scope':scope,'files':members,
                                           'index_excludes_itself':True})
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name,data in sorted(archive.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info, io.BytesIO(data))
    (docs/'raw-evidence.tar.gz').write_bytes(buf.getvalue())
    (docs/'README.md').write_bytes((ROOT/'evidence'/readme).read_bytes())
    (docs/'root-review.json').write_bytes(encoded(source_review))
    for p in evidence:
        if p.suffix == '.json' and ('results' in p.name or 'review' in p.name):
            (docs/p.name).write_bytes(p.read_bytes())
    index={'schema':1,'scope':scope,'pr':number,'base':pr['head'],
           'source':{p:identity(b) for p,b in sorted(code.items())},
           'artifacts':{p.name:identity(p.read_bytes()) for p in sorted(docs.iterdir())},
           'archive_members':len(archive), 'archive_bytes_uncompressed':sum(map(len,archive.values()))}
    (docs/'artifact-index.json').write_bytes(encoded(index))
    files=[{'path':p.relative_to(tree).as_posix(),**identity(p.read_bytes())}
           for p in sorted(tree.rglob('*')) if p.is_file()]
    metadata={'schema':1,'scope':scope,'number':number,'branch':pr['branch'],'base':pr['head'],
              'base_tree':git('show','-s','--format=%T',pr['head']).decode().strip(),
              'docs_path':docs.relative_to(tree).as_posix(),'files':files,
              'source_delta':''.join(patch)}
    (out/'publication.json').write_bytes(encoded(metadata))
    print(json.dumps({k:metadata[k] for k in ['scope','number','base','base_tree','docs_path']}))
    print(json.dumps({'code_files':len(code),'publish_files':len(files),'archive_files':len(archive),
                      'archive':identity(buf.getvalue())}))

if __name__ == '__main__': main()
