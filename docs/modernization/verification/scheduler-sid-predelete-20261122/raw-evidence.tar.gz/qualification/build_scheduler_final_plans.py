"""Compose frozen SID and pre-delete changes without replacing prior inputs."""
from pathlib import Path, PureWindowsPath
import base64
import copy
import hashlib
import json
import re
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
Q = ROOT / 'qualification'
INPUTS = Q / 'inputs'
D = PureWindowsPath(r'D:\dev\ChatGPT\mcp-final-20261122-e21a1792')

def sha(b):
    return hashlib.sha256(b).hexdigest()

def dump(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def row(path, b):
    return {'path': path, 'bytes': len(b), 'sha256': sha(b)}

new_files = {}

def put(relative, b):
    p = INPUTS / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(b)
    new_files['inputs/' + relative] = b

manifest = json.loads((ROOT / 'evidence/scheduler-predelete-files.json').read_text())
patch = (ROOT / manifest['patch']['path']).read_bytes()
assert sha(patch) == manifest['patch']['sha256']

# Apply exactly the two reviewed install.go hunks to the frozen SID source.
install_patch = patch.split(b'diff --git a/internal/api/install_task_rollback.go', 1)[0]
sid_install = (INPUTS / 'scheduler/internal/api/install.go').read_bytes()
assert sha(sid_install) == '87b13d863c346063563d2ec599c6adf7af447b78902a2c692870645afbcd831d'
temporary = Q / 'scheduler-composition-apply'
temporary.mkdir()
p = temporary / 'internal/api/install.go'
p.parent.mkdir(parents=True)
p.write_bytes(sid_install)
subprocess.run(['git', 'apply', '--check', '-'], input=install_patch, cwd=temporary, check=True)
subprocess.run(['git', 'apply', '-'], input=install_patch, cwd=temporary, check=True)
combined = p.read_bytes()
assert sha(combined) == manifest['composition']['sid_plus_predelete_install_go']['sha256']
put('scheduler-predelete/internal/api/install.go', combined)
for rel in ('internal/api/install_task_rollback.go', 'internal/api/install_task_rollback_test.go'):
    b = (ROOT / 'mutation-guard' / rel).read_bytes()
    expected = next(r['candidate'] for r in manifest['files'] if r['path'] == rel)
    assert sha(b) == expected['sha256']
    put('scheduler-predelete/' + rel, b)

original_map = json.loads((INPUTS / 'scheduler/overlay.json').read_text())['Replace']
candidate_map = dict(original_map)
for rel in (r['path'] for r in manifest['files']):
    candidate_map[str(D / 'source' / rel)] = str(D / 'inputs/scheduler-predelete' / rel)
put('scheduler-predelete/overlay.json', dump({'Replace': candidate_map}))
control_map = dict(candidate_map)
for rel in ('internal/api/install.go', 'internal/api/install_task_rollback.go'):
    control_map[str(D / 'source' / rel)] = original_map[str(D / 'source' / rel)]
put('scheduler-predelete/control-overlay.json', dump({'Replace': control_map}))

# These files have been prepared locally but have never been staged remotely.
for rel in ['scheduler/overlay.json'] + [p.relative_to(INPUTS).as_posix() for p in sorted((INPUTS / 'scheduler-control').rglob('*')) if p.is_file()]:
    new_files['inputs/' + rel] = (INPUTS / rel).read_bytes()
old_sid_control = (Q / 'plans/scheduler-sid-control.json').read_bytes()
new_files['inputs/plans/scheduler-sid-control.json'] = old_sid_control
index = [{'phase': 'scheduler-sid-control', 'manifest_sha256': sha(old_sid_control)}]

template = json.loads((Q / 'plans/scheduler-sid-candidate.json').read_text())
bound_inputs = list(template['input_files'])
for p in sorted((INPUTS / 'scheduler-predelete').rglob('*')):
    if p.is_file():
        bound_inputs.append(row(p.relative_to(INPUTS).as_posix(), p.read_bytes()))

def tests(label, overlay, roots, package, code=0):
    return {'label': label, 'tool': 'go', 'args': [
        'test', '-buildvcs=false', '-overlay', str(D / 'inputs' / overlay),
        '-p=2', '-race', '-count=1', '-timeout=180s', '-json',
        '-run', '^(' + '|'.join(roots) + ')$', package],
        'timeout_seconds': 300, 'expected_exit_code': code,
        'required_tests': {'pass' if code == 0 else 'fail': roots}}

def plan(name, commands):
    value = copy.deepcopy(template)
    value.update(phase=name, input_files=bound_inputs, commands=commands)
    b = dump(value)
    with (Q / 'plans' / (name + '.json')).open('xb') as f:
        f.write(b)
    new_files['inputs/plans/' + name + '.json'] = b
    index.append({'phase': name, 'manifest_sha256': sha(b)})

new_roots = ['TestExecuteInstallToPreDeleteRevalidation', 'TestExecuteInstallToPreDeleteRefusalRollsBackEarlierTask']
control = tests('predelete-control', 'scheduler-predelete/control-overlay.json', new_roots, './internal/api', 1)
expected = manifest['tests']['negative_control']['new_only_expected']
control['required_tests'] = {'pass': expected['pass_tests'], 'fail': expected['fail_tests']}
control['required_output'] = ['PREDELETE-REFUSAL', 'PREDELETE-EFFECTS', 'PREDELETE-EARLIER-CAUSES']
plan('scheduler-predelete-control', [control])

api_roots = ['TestSchedulerPortOwnerRequiresCurrentSID', 'TestPortHeldByOurDaemon',
             'TestInstallMergePreservesBackendRunHold', 'TestInstallPreflightPreservesBackendRunHold']
files = ['install_task_rollback_test.go', 'install_task_recovery_test.go',
         'install_task_mutation_failure_test.go', 'install_prune_recovery_test.go']
for name in files:
    p = INPUTS / ('scheduler-predelete' if name == 'install_task_rollback_test.go' else 'scheduler') / 'internal/api' / name
    api_roots += re.findall(r'^func (Test\w+)\(t \*testing.T\)', p.read_text(), re.M)
assert len(api_roots) == len(set(api_roots))
commands = copy.deepcopy(template['commands'])
for c in commands:
    c['args'] = [a.replace('inputs\\scheduler\\overlay.json', 'inputs\\scheduler-predelete\\overlay.json') for a in c['args']]
commands[1] = tests('api-owners-hold-recovery', 'scheduler-predelete/overlay.json', api_roots, './internal/api')
plan('scheduler-sid-predelete-candidate', commands)

review = {
    'status': 'SOURCE_REVIEWED_RUNTIME_NOT_RUN',
    'reviewer': 'root',
    'source_manifest_sha256': sha((ROOT / 'evidence/scheduler-predelete-files.json').read_bytes()),
    'reviewed': ['Both install.go mutation call sites and surrounding rollback ownership',
                 'Full new pre-delete helper and previous rollback owner',
                 'Full candidate patch including fixture phase changes and every new assertion'],
    'findings': [],
    'composition': {'install_go_sha256': sha(combined), 'go_overlay_files': len(candidate_map),
                    'sid_preserved': True, 'old_source_and_inputs_unchanged': True,
                    'backend_hold_file_sha256': sha((INPUTS / 'scheduler/internal/api/install_parsed_manifest.go').read_bytes())},
    'acceptance': ['Changed, absent, empty or failed current XML reads refuse current-task mutation',
                   'Current-task refusal does not acquire a compensation; prior tasks retain rollback',
                   'Optional prune emits a named warning and retains snapshot',
                   'Source tests check exact effects, original errors, and retained external occupant'],
    'limitations': ['Name-based Delete remains non-atomic after the last XML read',
                    'Identical XML cannot distinguish task generations',
                    'No native Task Scheduler or installed Product execution is authorized by this plan',
                    'Required-test declarations are minimum sets; observed terminal events require exact post-review'],
    'selected_api_roots': api_roots,
}
(ROOT / 'evidence/scheduler-predelete-root-review.json').write_bytes(dump(review))
archive = Q / 'scheduler-final-plans.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for rel, b in new_files.items():
        z.writestr(rel, b)
b = archive.read_bytes()
(Q / 'scheduler-final-plans.b64').write_bytes(base64.b64encode(b))
result = {'plans': index, 'bundle_bytes': len(b), 'bundle_sha256': sha(b),
          'base64_bytes': len(base64.b64encode(b)), 'new_files': len(new_files),
          'api_roots': len(api_roots)}
(Q / 'scheduler-final-plan-index.json').write_bytes(dump(result))
print(json.dumps(result))
