//go:build windows

package scheduler

import (
	"bytes"
	"context"
	"encoding/xml"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unicode/utf8"

	"mcp-local-hub/internal/process"
)

// windowsScheduler shells out to `schtasks.exe` for all operations.
// We build a Task Scheduler XML document per spec, pipe it to `schtasks /Create /XML`,
// and parse the output of `/Query` for Status/List.
type windowsScheduler struct {
	username     string // e.g., "alice"
	schtasksPath string
}

func newPlatformScheduler() (Scheduler, error) {
	u, err := user.Current()
	if err != nil {
		return nil, fmt.Errorf("user.Current: %w", err)
	}
	schtasksPath, err := resolveSchtasksPath()
	if err != nil {
		return nil, err
	}
	// u.Username is typically "MACHINE\\user" on Windows — strip the domain.
	name := u.Username
	if i := strings.LastIndex(name, "\\"); i >= 0 {
		name = name[i+1:]
	}
	return &windowsScheduler{username: name, schtasksPath: schtasksPath}, nil
}

func resolveSchtasksPath() (string, error) {
	systemRoot := os.Getenv("SystemRoot")
	if systemRoot == "" {
		systemRoot = os.Getenv("WINDIR")
	}
	if systemRoot == "" {
		return "", fmt.Errorf("resolve schtasks path: SystemRoot/WINDIR is empty")
	}
	return filepath.Join(systemRoot, "System32", "schtasks.exe"), nil
}

// dayNames maps Go weekday ints to Task Scheduler XML element names.
var dayNames = map[int]string{
	0: "Sunday",
	1: "Monday",
	2: "Tuesday",
	3: "Wednesday",
	4: "Thursday",
	5: "Friday",
	6: "Saturday",
}

// buildCreateXML serializes a TaskSpec into a Task Scheduler XML document.
// Exposed (lowercase) for testing within the same package.
func buildCreateXML(spec TaskSpec, userName string) string {
	var buf bytes.Buffer
	buf.WriteString(`<?xml version="1.0" encoding="UTF-16"?>`)
	buf.WriteString("\n")
	buf.WriteString(`<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">`)
	buf.WriteString("\n  <RegistrationInfo>\n")
	buf.WriteString(fmt.Sprintf("    <Description>%s</Description>\n", xmlEscape(spec.Description)))
	buf.WriteString(fmt.Sprintf("    <Author>%s</Author>\n", xmlEscape(userName)))
	buf.WriteString(fmt.Sprintf("    <Date>%s</Date>\n", time.Now().Format("2006-01-02T15:04:05")))
	buf.WriteString("  </RegistrationInfo>\n")

	// Triggers
	buf.WriteString("  <Triggers>\n")
	if spec.LogonTrigger {
		buf.WriteString("    <LogonTrigger>\n")
		buf.WriteString(fmt.Sprintf("      <UserId>%s</UserId>\n", xmlEscape(userName)))
		buf.WriteString("      <Enabled>true</Enabled>\n")
		buf.WriteString("    </LogonTrigger>\n")
	}
	if spec.WeeklyTrigger != nil {
		wt := spec.WeeklyTrigger
		day := dayNames[wt.DayOfWeek]
		// Weekly recurrence lives inside <CalendarTrigger>, not as a standalone
		// <WeeklyTrigger> child of <Triggers>. Task Scheduler rejects the flat
		// form with:
		//     ERROR: The task XML contains an unexpected node. (N,M):WeeklyTrigger:
		buf.WriteString("    <CalendarTrigger>\n")
		buf.WriteString(fmt.Sprintf("      <StartBoundary>2026-01-04T%02d:%02d:00</StartBoundary>\n", wt.HourLocal, wt.MinuteLocal))
		buf.WriteString("      <Enabled>true</Enabled>\n")
		buf.WriteString("      <ScheduleByWeek>\n")
		buf.WriteString(fmt.Sprintf("        <DaysOfWeek><%s /></DaysOfWeek>\n", day))
		buf.WriteString("        <WeeksInterval>1</WeeksInterval>\n")
		buf.WriteString("      </ScheduleByWeek>\n")
		buf.WriteString("    </CalendarTrigger>\n")
	}
	buf.WriteString("  </Triggers>\n")

	// Principal — run as current user, interactive (needs session)
	buf.WriteString("  <Principals>\n")
	buf.WriteString("    <Principal id=\"Author\">\n")
	buf.WriteString(fmt.Sprintf("      <UserId>%s</UserId>\n", xmlEscape(userName)))
	buf.WriteString("      <LogonType>InteractiveToken</LogonType>\n")
	buf.WriteString("      <RunLevel>LeastPrivilege</RunLevel>\n")
	buf.WriteString("    </Principal>\n")
	buf.WriteString("  </Principals>\n")

	// Settings — restart policy + sane defaults
	//
	// Per Task Scheduler XML schema, the retry policy is a single <RestartOnFailure>
	// container holding <Interval> + <Count> — NOT flat <RestartInterval>/<RestartCount>
	// siblings. Task Scheduler rejects the flat form with
	//     ERROR: The task XML contains an unexpected node. (N,M):RestartInterval:
	buf.WriteString("  <Settings>\n")
	if spec.RestartOnFailure {
		buf.WriteString("    <RestartOnFailure>\n")
		buf.WriteString("      <Interval>PT1M</Interval>\n")
		buf.WriteString("      <Count>3</Count>\n")
		buf.WriteString("    </RestartOnFailure>\n")
	}
	buf.WriteString("    <AllowHardTerminate>true</AllowHardTerminate>\n")
	buf.WriteString("    <StartWhenAvailable>false</StartWhenAvailable>\n")
	buf.WriteString("    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>\n")
	// MultipleInstancesPolicy=StopExisting (was IgnoreNew). v0.3.0-blockers
	// bug #2: D2.4 manual smoke 2026-05-07 found that RestartOnFailure
	// did NOT fire after Task Manager End Task even with correct
	// <RestartOnFailure Count=3 Interval=PT1M> config. Root cause: with
	// IgnoreNew, when TS attempts the auto-restart it sees the previous
	// (just-killed) instance as still "running" in its internal state
	// machine — Task Manager's TerminateProcess doesn't always cleanly
	// transition TS's record — and the new instance is IGNORED. Switching
	// to StopExisting tells TS "stop the lingering instance (no-op when
	// already dead) and start the new one", which lets RestartOnFailure
	// reliably revive killed daemons. mcphub.restart still works as
	// before; status polling is read-only and unaffected.
	buf.WriteString("    <MultipleInstancesPolicy>StopExisting</MultipleInstancesPolicy>\n")
	buf.WriteString("    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>\n")
	buf.WriteString("    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>\n")
	buf.WriteString("    <IdleSettings>\n      <StopOnIdleEnd>false</StopOnIdleEnd>\n      <RestartOnIdle>false</RestartOnIdle>\n    </IdleSettings>\n")
	buf.WriteString("    <AllowStartOnDemand>true</AllowStartOnDemand>\n")
	buf.WriteString("    <Enabled>true</Enabled>\n")
	buf.WriteString("    <Hidden>false</Hidden>\n")
	buf.WriteString("    <RunOnlyIfIdle>false</RunOnlyIfIdle>\n")
	buf.WriteString("    <WakeToRun>false</WakeToRun>\n")
	buf.WriteString("    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>\n") // no timeout
	buf.WriteString("    <Priority>7</Priority>\n")
	buf.WriteString("  </Settings>\n")

	// Actions
	buf.WriteString("  <Actions Context=\"Author\">\n    <Exec>\n")
	buf.WriteString(fmt.Sprintf("      <Command>%s</Command>\n", xmlEscape(spec.Command)))
	if len(spec.Args) > 0 {
		buf.WriteString(fmt.Sprintf("      <Arguments>%s</Arguments>\n", xmlEscape(joinTaskArgs(spec.Args))))
	}
	if spec.WorkingDir != "" {
		buf.WriteString(fmt.Sprintf("      <WorkingDirectory>%s</WorkingDirectory>\n", xmlEscape(spec.WorkingDir)))
	}
	buf.WriteString("    </Exec>\n  </Actions>\n")
	buf.WriteString("</Task>\n")

	return buf.String()
}

// joinTaskArgs concatenates args into a Windows-compatible command line.
// Each arg is escaped via syscall.EscapeArg (stdlib — implements the same
// CommandLineToArgvW-compatible rules Go's own os/exec uses on Windows),
// then joined with single spaces. Without this, arguments containing
// spaces or embedded quotes were fed unescaped into the Task Scheduler
// XML `<Arguments>` element and split into multiple argv tokens at child
// launch — breaking any workspace path like
// `C:\Users\Test User\workspace`.
//
// syscall.EscapeArg is a no-op for args that contain none of the shell
// metacharacters it guards against (space, tab, `"`, `\`), so previously
// simple flag values like `--port` / `9200` / `--language` / `go` render
// identically to the pre-fix output.
func joinTaskArgs(args []string) string {
	if len(args) == 0 {
		return ""
	}
	escaped := make([]string, len(args))
	for i, a := range args {
		escaped[i] = syscall.EscapeArg(a)
	}
	return strings.Join(escaped, " ")
}

func xmlEscape(s string) string {
	var out bytes.Buffer
	_ = xml.EscapeText(&out, []byte(s))
	return out.String()
}

// Create writes the XML to a temp file and invokes `schtasks /Create /XML`.
func (w *windowsScheduler) Create(spec TaskSpec) error {
	xmlDoc := buildCreateXML(spec, w.username)
	tmp, err := os.CreateTemp("", "mcp-local-hub-task-*.xml")
	if err != nil {
		return fmt.Errorf("create temp file: %w", err)
	}
	defer os.Remove(tmp.Name())
	// Task Scheduler requires UTF-16 LE with BOM. Re-encode.
	utf16 := EncodeXMLUTF16LEBOM(xmlDoc)
	if _, err := tmp.Write(utf16); err != nil {
		tmp.Close()
		return fmt.Errorf("write xml: %w", err)
	}
	tmp.Close()

	// Create never opts into replacement. ImportXML owns the explicit /F path.
	// Stdin remains nil, so the child receives EOF rather than interactive input.
	cmd := exec.Command(w.schtasksPath, "/Create", "/TN", spec.Name, "/XML", tmp.Name())
	process.NoConsole(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("schtasks /Create: %w: %s", err, string(out))
	}
	return nil
}

func (w *windowsScheduler) Delete(name string) error {
	_, err := schedulerCOM(context.Background(), schedulerCOMRequest{Operation: "delete", Name: name})
	if errors.Is(err, ErrTaskNotFound) {
		return nil
	}
	return err
}

// ExportXML dumps the full Task Scheduler XML for a task via
// `schtasks /Query /XML`. Returns a "not found" error (captured as
// ErrTaskNotFound so callers can distinguish a missing task from other
// failures) when the task does not exist.
func (w *windowsScheduler) ExportXML(name string) ([]byte, error) {
	response, err := schedulerCOM(context.Background(), schedulerCOMRequest{Operation: "export", Name: name})
	if err != nil {
		return nil, err
	}
	if response.Task == nil || response.Task.XML == "" {
		return nil, fmt.Errorf("%w: empty task XML", ErrTaskCorrupt)
	}
	return []byte(response.Task.XML), nil
}

// ImportXML re-creates a task from raw Task Scheduler XML via
// `schtasks /Create /XML`. Used by install's rollback path to restore
// a task that was deleted in preparation for a re-install that then
// failed mid-sequence. Idempotent: if the task already exists, /F
// overwrites it.
func (w *windowsScheduler) ImportXML(name string, xml []byte) error {
	prepared, err := prepareTaskXMLForImport(xml)
	if err != nil {
		return fmt.Errorf("prepare task XML: %w", err)
	}
	tmp, err := os.CreateTemp("", "mcp-task-restore-*.xml")
	if err != nil {
		return fmt.Errorf("create temp: %w", err)
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(prepared); err != nil {
		tmp.Close()
		return fmt.Errorf("write xml: %w", err)
	}
	tmp.Close()
	cmd := exec.Command(w.schtasksPath, "/Create", "/TN", name, "/XML", tmp.Name(), "/F")
	process.NoConsole(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("schtasks /Create /XML: %w: %s", err, string(out))
	}
	return nil
}

// prepareTaskXMLForImport preserves Task Scheduler's existing UTF-16LE+BOM
// exports exactly. UTF-8 exports are converted once to that required on-disk
// format; malformed or unsupported byte encodings fail before any temp file or
// scheduler mutation is attempted.
func prepareTaskXMLForImport(raw []byte) ([]byte, error) {
	if bytes.HasPrefix(raw, []byte{0xFF, 0xFE}) {
		if !validUTF16LEBOM(raw) {
			return nil, fmt.Errorf("invalid UTF-16LE task XML")
		}
		return append([]byte(nil), raw...), nil
	}
	if bytes.HasPrefix(raw, []byte{0xFE, 0xFF}) {
		return nil, fmt.Errorf("unsupported UTF-16BE task XML")
	}
	raw = bytes.TrimPrefix(raw, []byte{0xEF, 0xBB, 0xBF})
	if !utf8.Valid(raw) {
		return nil, fmt.Errorf("invalid UTF-8 task XML")
	}
	return EncodeXMLUTF16LEBOM(string(raw)), nil
}

func validUTF16LEBOM(raw []byte) bool {
	if len(raw) < 2 || (len(raw)-2)%2 != 0 {
		return false
	}
	for i := 2; i < len(raw); i += 2 {
		unit := uint16(raw[i]) | uint16(raw[i+1])<<8
		switch {
		case unit >= 0xD800 && unit <= 0xDBFF:
			if i+3 >= len(raw) {
				return false
			}
			next := uint16(raw[i+2]) | uint16(raw[i+3])<<8
			if next < 0xDC00 || next > 0xDFFF {
				return false
			}
			i += 2
		case unit >= 0xDC00 && unit <= 0xDFFF:
			return false
		}
	}
	return true
}

func (w *windowsScheduler) Run(name string) error {
	cmd := exec.Command(w.schtasksPath, "/Run", "/TN", name)
	process.NoConsole(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("schtasks /Run: %w: %s", err, string(out))
	}
	return nil
}

func (w *windowsScheduler) Stop(name string) error {
	_, err := schedulerCOM(context.Background(), schedulerCOMRequest{Operation: "stop", Name: name})
	if errors.Is(err, ErrTaskNotFound) || errors.Is(err, ErrTaskNotRunning) {
		return nil
	}
	return err
}

// statusQueryTimeout bounds the per-task `schtasks /Query`. Measured at ~177ms
// on a loaded reference host, so 15s never cuts a healthy answer; its job is to
// stop a wedged schtasks child from blocking the caller forever. Status sits on
// the GUI readiness path (via the port-ownership gate), where a bare
// exec.Command + CombinedOutput() is an unbounded wait with no recovery.
const statusQueryTimeout = 15 * time.Second

func (w *windowsScheduler) Status(name string) (TaskStatus, error) {
	response, err := schedulerCOM(context.Background(), schedulerCOMRequest{Operation: "status", Name: name})
	if err != nil {
		return TaskStatus{}, err
	}
	if response.Task == nil {
		return TaskStatus{}, fmt.Errorf("%w: missing status task", ErrTaskCorrupt)
	}
	return taskStatusFromCOM(*response.Task)
}

func (w *windowsScheduler) List(prefix string) ([]TaskStatus, error) {
	return w.ListContext(context.Background(), prefix)
}

func (w *windowsScheduler) ListContext(ctx context.Context, prefix string) ([]TaskStatus, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	response, err := schedulerCOM(ctx, schedulerCOMRequest{Operation: "list", Prefix: prefix})
	if err != nil {
		return nil, err
	}
	results := make([]TaskStatus, 0, len(response.Tasks))
	for _, task := range response.Tasks {
		status, statusErr := taskStatusFromCOM(task)
		if statusErr != nil {
			return nil, statusErr
		}
		if sameWindowsUser(status.Owner, w.username) {
			results = append(results, status)
		}
	}
	return results, nil
}

// sameWindowsUser compares a Task Scheduler "Run As User" value against the
// current user's short username (no DOMAIN\ prefix), case-insensitively.
func sameWindowsUser(owner, currentShortName string) bool {
	return WindowsUsersEquivalent(owner, currentShortName)
}
