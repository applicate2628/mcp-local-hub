"""Capture only the explicitly admitted R25 evidence; never run a tool or test.

Run on Windows from the fixed R25 root with a reviewed archive-index SHA-256.
Each invocation writes a new publication directory. Raw bytes remain private
on D:. A completion marker is written only after ZIP and input readbacks.
"""
import sys
sys.dont_write_bytecode = True

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import types
import uuid
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121")
WORKSPACE = Path(r"D:\dev\ChatGPT")
OWNER = WORKSPACE / "mcp-r17-current-task-recovery-20261121/check_recovery.py"
LIMIT = 512 * 1024 * 1024
PROFILE_PLAIN = br"<USER_PROFILE>"
PROFILE_JSON = br"<USER_PROFILE>"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def common_signature(info):
    # The observed Windows Python 3.14.7 path and descriptor APIs disagree
    # about ctime. Compare it strictly within each API, not across the APIs.
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_birthtime_ns, info.st_file_attributes)


def signature(info):
    return (*common_signature(info), info.st_ctime_ns)


def no_reparse(path):
    path.relative_to(WORKSPACE)
    for item in [*reversed(path.parents), path]:
        info = item.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Link/reparse traversal refused")


def read_regular(path, limit=LIMIT // 4):
    no_reparse(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, "Input is not a bounded regular file: " + str(path))
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        require(common_signature(before) == common_signature(opened), "Input identity changed while opening: " + str(path))
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    no_reparse(path)
    path_after = path.lstat()
    require(signature(before) == signature(path_after), "Input path changed while reading: " + str(path))
    require(signature(opened) == signature(after), "Opened input changed while reading: " + str(path))
    require(len(raw) == after.st_size and common_signature(after) == common_signature(path_after), "Input identity changed after reading: " + str(path))
    return raw, (signature(path_after), signature(after))


def bootstrap_index(pin):
    require(re.fullmatch(r"[0-9a-f]{64}", pin), "Invalid index digest")
    raw, _ = read_regular(ROOT / "archive-index.json")
    require(sha(raw) == pin, "Index differs from the externally reviewed pin")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate index key")
            result[key] = value
        return result
    index = json.loads(raw, object_pairs_hook=unique)
    require(index.get("schema") == "r25-archive-index-v1" and index.get("root") == str(ROOT), "Index schema/root differs")
    entries = index["files"]
    require(isinstance(entries, list) and len({r["path"] for r in entries}) == len(entries), "Duplicate support pin")
    pins = {item["path"]: item["sha256"] for item in entries}
    # Execute only the locally pinned verifier bytes, never code from a ZIP or a
    # mutable import search path. Its main guard is inactive in this module.
    code, _ = read_regular(ROOT / "verify_public_archive.py")
    require(sha(code) == pins["verify_public_archive.py"], "Verifier source pin differs")
    module = types.ModuleType("r25_pinned_archive_verifier")
    module.__file__ = str(ROOT / "verify_public_archive.py")
    exec(compile(code, module.__file__, "exec"), module.__dict__)
    return index, module


def inventory(index, verifier):
    paths = {"archive-index.json": ROOT / "archive-index.json"}
    for item in index["files"]:
        name = verifier.safe_name(item["path"])
        require(("/" not in name and name.endswith((".py", ".json", ".txt"))) or name.startswith("transfer-readbacks/"), "Support path outside allowlist")
        require(name != "archive-index.json", "Index cannot pin itself")
        paths[name] = ROOT / name
    for name in ("evidence", "scopes", "format"):
        top = ROOT / name
        if name == "format" and not os.path.lexists(top):
            continue
        no_reparse(top)
        require(top.is_dir(), "Expected admitted evidence directory")
        for current, directories, files in os.walk(top, followlinks=False):
            for child in [*directories, *files]:
                no_reparse(Path(current) / child)
            for child in files:
                path = Path(current) / child
                member = verifier.safe_name(path.relative_to(ROOT).as_posix())
                require(member not in paths, "Duplicate input path")
                paths[member] = path
                require(len(paths) <= 49998, "Too many evidence files")
    require(len(paths) == len({name.casefold() for name in paths}), "Case-colliding input names")
    return paths


def source_inputs(index, files, verifier):
    paths, absent = {}, set()
    for entry in index["scopes"]:
        scope = entry["scope"]
        require(re.fullmatch(r"[a-z][a-z0-9-]{0,40}", scope), "Invalid scope")
        raw = files["scopes/" + scope + "/manifest.json"]
        require(sha(raw) == entry["manifest_sha256"], "Scope manifest pin differs")
        plan = verifier.decode(raw)
        directory = plan["source_directory"]
        require(re.fullmatch(r"source-pr[0-9]+", directory), "Unsafe source directory")
        rows = [(item, item["original_git_blob"]) for item in plan["files"]]
        rows += [(item, item["git_blob"]) for item in plan.get("source_evidence", [])]
        for item, original_blob in rows:
            name = verifier.safe_name(item["path"])
            require(name.endswith(".go"), "Only explicit Go source inputs are admitted")
            path = ROOT / directory / name
            if original_blob is None:
                no_reparse(path.parent)
                require(not os.path.lexists(path), "New-file source unexpectedly exists")
                absent.add(path)
            else:
                member = "originals/" + directory + "/" + name
                paths[member] = path
    require(not set(paths.values()) & absent, "Contradictory original source pins")
    return paths, absent


def sanitize(raw):
    escaped = raw.count(PROFILE_JSON)
    value = raw.replace(PROFILE_JSON, b"<USER_PROFILE>")
    plain = value.count(PROFILE_PLAIN)
    return value.replace(PROFILE_PLAIN, b"<USER_PROFILE>"), {"json_escaped": escaped, "plain": plain}


def write_new(path, raw):
    no_reparse(path.parent)
    with path.open("xb") as stream:
        stream.write(raw)
    require(read_regular(path)[0] == raw, "Publication readback differs")


def write_zip(path, members):
    require(len(members) == len({name.casefold() for name in members}), "Duplicate ZIP members")
    no_reparse(path.parent)
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, raw in sorted(members.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, raw)
    with zipfile.ZipFile(io.BytesIO(read_regular(path, LIMIT)[0])) as archive:
        require(len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members) and archive.testzip() is None, "ZIP membership/CRC differs")
        require(all(sha(archive.read(name)) == sha(raw) for name, raw in members.items()), "ZIP member readback differs")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index-sha256", required=True)
    args = parser.parse_args()
    require(os.name == "nt" and not sys.flags.optimize and Path(__file__).absolute().parent == ROOT, "Use the fixed Windows R25 root")
    no_reparse(ROOT)
    index, verifier = bootstrap_index(args.index_sha256)
    base_paths = inventory(index, verifier)
    files, signatures, total = {}, {}, 0
    for name, path in base_paths.items():
        files[name], signatures[name] = read_regular(path)
        total += len(files[name])
        require(total <= LIMIT - 8 * 1024 * 1024, "Capture exceeds archive bounds")
    sources, absent = source_inputs(index, files, verifier)
    paths = {**base_paths, **sources, "frozen-owner/check_recovery.py": OWNER}
    for name in set(paths) - set(base_paths):
        files[name], signatures[name] = read_regular(paths[name])
        total += len(files[name])
        require(total <= LIMIT - 8 * 1024 * 1024, "Capture exceeds archive bounds")
    require(len(files) <= 49998 and len(files) == len({name.casefold() for name in files}), "Excessive or colliding input names")
    public, mapping = {}, {}
    for name, raw in sorted(files.items()):
        public[name], counts = sanitize(raw)
        mapping[name] = {"path": name, "original_bytes": len(raw), "original_sha256": sha(raw),
                         "public_bytes": len(public[name]), "public_sha256": sha(public[name]),
                         "changed": public[name] != raw, "replacement_counts": counts}
    summary = verifier.verify_evidence(files, mapping, args.index_sha256, public=False)
    require(verifier.verify_evidence(public, mapping, args.index_sha256) == summary, "Redaction changed evidence interpretation")
    summary_raw = encoded(summary)
    manifest = {"schema": "r25-raw-public-file-map-v1", "index_sha256": args.index_sha256,
                "captured_utc": datetime.now(timezone.utc).isoformat(), "files": list(mapping.values()),
                "summary_sha256": sha(summary_raw),
                "redaction": "Two exact case-sensitive profile literals, plain and JSON-escaped, replaced by <USER_PROFILE>; all other input bytes unchanged.",
                "raw_archive_role": "Private original evidence retained on D:; do not publish raw.zip."}
    generated = {"_package/summary.json": summary_raw, "_package/manifest.json": encoded(manifest)}
    publication = ROOT / "publication"
    if not publication.exists():
        publication.mkdir()
    no_reparse(publication)
    destination = publication / (datetime.now(timezone.utc).strftime("package-%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex)
    destination.mkdir()
    no_reparse(destination)
    write_zip(destination / "raw.zip", {**files, **generated})
    write_zip(destination / "public.zip", {**public, **generated})
    write_new(destination / "manifest.public.json", generated["_package/manifest.json"])
    write_new(destination / "summary.public.json", summary_raw)
    require(inventory(index, verifier) == base_paths, "Evidence membership changed during capture")
    for name, path in paths.items():
        raw, observed = read_regular(path)
        require(observed == signatures[name] and sha(raw) == sha(files[name]), "Input changed before completion")
    for path in absent:
        no_reparse(path.parent)
        require(not os.path.lexists(path), "Previously absent original appeared")
    completion = {"schema": "r25-package-completion-v1", "state": "COMPLETE", "index_sha256": args.index_sha256,
                  "qualification_state": summary["qualification_state"], "files": []}
    for name in ("raw.zip", "public.zip", "manifest.public.json", "summary.public.json"):
        raw, _ = read_regular(destination / name, LIMIT)
        completion["files"].append({"path": name, "bytes": len(raw), "sha256": sha(raw), "private": name == "raw.zip"})
    write_new(destination / "archives.json", encoded(completion))  # Last write: no marker means an incomplete publication.
    print(json.dumps({"packaging_state": "COMPLETE", "publication": str(destination), "summary": summary}))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RuntimeError, zipfile.BadZipFile) as error:
        print(json.dumps({"packaging_state": "INCOMPLETE", "error_type": type(error).__name__, "reason": str(error),
                          "note": "Existing evidence was not modified. Any new partial publication is retained without a completion marker."}))
        sys.exit(2)
