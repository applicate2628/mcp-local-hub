"""Format one retained diagnostic source; no product or test execution."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess

ROOT = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121")
TOOL = Path(r"C:\msys64\ucrt64\bin\gofmt.exe")
SOURCE_SHA = "e9815112b207377fd9fc6d0d91c0a522611be770dcb2946e19cfa22dd50f94c5"
source = ROOT / "format/cmake-retention-before.go"
target = ROOT / "format/cmake-retention-formatted.go"
if Path(__file__).resolve().parent != ROOT or hashlib.sha256(source.read_bytes()).hexdigest() != SOURCE_SHA:
    raise RuntimeError("Formatting input differs")
with target.open("xb") as stream:
    stream.write(source.read_bytes())
environment = {key: value for key, value in os.environ.items() if key.upper() in {
    "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "SYSTEMDRIVE", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE"}}
environment.update(TEMP=str(ROOT / "format"), TMP=str(ROOT / "format"), GOENV="off",
                   GOTOOLCHAIN="local", GOTELEMETRY="off")
command = [str(TOOL), "-w", str(target)]
result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, timeout=60)
record = {"utc": dt.datetime.now(dt.timezone.utc).isoformat(), "command": command,
          "tool_sha256": hashlib.sha256(TOOL.read_bytes()).hexdigest(), "input_sha256": SOURCE_SHA,
          "output_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "exit_code": result.returncode,
          "stdout": result.stdout.decode("utf-8", "strict"), "stderr": result.stderr.decode("utf-8", "strict")}
with (ROOT / "format/receipt.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record))
raise SystemExit(result.returncode)
