import sys
sys.dont_write_bytecode = True
import json, os
from pathlib import Path
p = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121\archive-index.json")
keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns", "st_birthtime_ns", "st_file_attributes")
def fields(info):
    return {k: getattr(info, k, None) for k in keys}
before = p.lstat()
with p.open("rb") as f:
    opened = os.fstat(f.fileno())
    raw = f.read()
    after = os.fstat(f.fileno())
print(json.dumps({"path":str(p),"before":fields(before),"opened":fields(opened),"after":fields(after),"path_after":fields(p.lstat()),"bytes_read":len(raw),"python":sys.version}, indent=2))
