"""Decode the one owned R25 transfer and verify every admitted file."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121")
EXPECTED = "0086b54adaeeb3dc6b6567bbdde352dd80acb56688beadf14d1e1edf1b59630d"
if Path(__file__).resolve().parent != ROOT:
    raise RuntimeError("Unexpected transfer root")
raw = base64.b64decode((ROOT / "cmake-input.b64").read_text(), validate=True)
if len(raw) != 14545 or hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise RuntimeError("Transfer checksum differs")
records = []
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    names = archive.namelist()
    if len(names) != 3 or len(set(names)) != len(names) or archive.testzip() is not None:
        raise RuntimeError("Archive membership or CRC differs")
    for name in names:
        path = PurePosixPath(name)
        if path.is_absolute() or any(part in (".", "..") for part in path.parts) or "\\" in name or ":" in name:
            raise RuntimeError("Unexpected archive path")
        target = ROOT / name
        if target.exists():
            raise RuntimeError("Refuse to replace an existing payload")
    for name in names:
        data = archive.read(name)
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
        reread = target.read_bytes()
        if reread != data:
            raise RuntimeError("Payload readback differs")
        records.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
with (ROOT / "cmake-input-readback.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump({"archive_bytes": len(raw), "archive_sha256": EXPECTED, "files": records}, stream, indent=2)
print(json.dumps({"archive_sha256": EXPECTED, "files": len(records), "verified": True}))
