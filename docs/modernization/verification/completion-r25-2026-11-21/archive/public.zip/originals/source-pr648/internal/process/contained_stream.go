package process

import (
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"sync"
	"time"
)

// ContainedRunStage identifies the owner stage that produced a contained-run
// failure. The string values are stable internal diagnostics; Error never
// includes command, environment, path, or stream content.
type ContainedRunStage string

const (
	ContainedStageValidate    ContainedRunStage = "validate"
	ContainedStagePipeSetup   ContainedRunStage = "pipe_setup"
	ContainedStageContainment ContainedRunStage = "containment"
	ContainedStageStart       ContainedRunStage = "start"
	ContainedStageStdout      ContainedRunStage = "stdout"
	ContainedStageStderr      ContainedRunStage = "stderr"
	ContainedStageWait        ContainedRunStage = "wait"
	ContainedStageExit        ContainedRunStage = "exit"
	ContainedStageContext     ContainedRunStage = "context"
	ContainedStageCleanup     ContainedRunStage = "cleanup"
)

var (
	ErrInvalidCleanupTimeout  = errors.New("invalid cleanup timeout")
	ErrContainmentUnavailable = errors.New("process containment unavailable")
	ErrCleanupTimeout         = errors.New("process cleanup timeout")

	errInvalidContainedRun = errors.New("invalid contained stream request")
	errContainedExit       = errors.New("contained process exited non-zero")
)

const maxContainedCleanupTimeout time.Duration = time.Duration(math.MaxUint32) * time.Millisecond

// ContainedStreamOptions configures one finite contained process invocation.
// Stderr is borrowed for the duration of RunContainedStream and is never
// closed by the runner.
type ContainedStreamOptions struct {
	CleanupTimeout          time.Duration
	Stderr                  io.Writer
	AbsoluteCleanupDeadline time.Time
	StdoutByteLimit         int64
	StderrByteLimit         int64
}

// ContainedRunError preserves a primary lifecycle cause plus an optional
// ordered cleanup cause. Error is deliberately fixed-text and secret-free.
type ContainedRunError struct {
	Stage        ContainedRunStage
	Cause        error
	ExitCode     *int
	CleanupStage ContainedRunStage
	CleanupCause error
}

func (e *ContainedRunError) Error() string {
	if e == nil {
		return "contained process failed"
	}
	return "contained process " + string(e.Stage) + " failed"
}

// Unwrap keeps the primary cause first and the cleanup cause second.
func (e *ContainedRunError) Unwrap() []error {
	if e == nil {
		return nil
	}
	out := make([]error, 0, 2)
	if e.Cause != nil {
		out = append(out, e.Cause)
	}
	if e.CleanupCause != nil {
		out = append(out, e.CleanupCause)
	}
	return out
}

type containedReadFile interface {
	io.Reader
	io.Closer
	Fd() uintptr
}

type containedWriteFile interface {
	io.Writer
	io.Closer
	Fd() uintptr
}

type containedInputFile interface {
	io.Reader
	io.Closer
	Fd() uintptr
}

type containedWaitResult struct {
	exitCode int
	exited   bool
	err      error
}

type containedChild interface {
	start(*exec.Cmd, containedInputFile, containedWriteFile, containedWriteFile) error
	wait() containedWaitResult
	terminate(uint32) error
	close() error
}

// containedDeadlineChild is an additive private capability for platform
// children whose cleanup has multiple phases. RunContainedStream owns the one
// absolute cleanup deadline; implementations must not extend or resample it.
type containedDeadlineChild interface {
	terminateBy(time.Time) error
}

// containedDeferredReapChild keeps the direct POSIX group leader waitable
// until terminate has signaled its process group. This prevents a numeric
// process-group ID from being recycled between cmd.Wait and kill(-pid).
type containedDeferredReapChild interface {
	reapBy(time.Time) (containedWaitResult, bool)
}

type containedStreamDependencies struct {
	newChild func(*exec.Cmd) (containedChild, error)
	pipe     func() (containedReadFile, containedWriteFile, error)
	openNull func() (containedInputFile, error)
}

func defaultContainedStreamDependencies() containedStreamDependencies {
	return containedStreamDependencies{
		newChild: newPlatformContainedChild,
		pipe: func() (containedReadFile, containedWriteFile, error) {
			return os.Pipe()
		},
		openNull: openContainedNull,
	}
}

type containedPlatformError struct {
	stage ContainedRunStage
	cause error
}

func (e *containedPlatformError) Error() string { return "contained platform operation failed" }
func (e *containedPlatformError) Unwrap() error { return e.cause }

type ownedCloser struct {
	mu     sync.Mutex
	closer io.Closer
	closed bool
	err    error
}

func ownCloser(c io.Closer) *ownedCloser {
	return &ownedCloser{closer: c}
}

func (c *ownedCloser) close() error {
	if c == nil {
		return nil
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed {
		return nil
	}
	c.closed = true
	if c.closer == nil {
		return nil
	}
	c.err = c.closer.Close()
	return c.err
}

func (c *ownedCloser) snapshot() ContainedStreamSlot {
	if c == nil {
		return ContainedStreamSlot{}
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	return ContainedStreamSlot{Acquired: c.closer != nil, CloseAttempted: c.closed, Closed: c.closed && c.err == nil, CloseError: c.err}
}

func closeOwned(closers ...*ownedCloser) error {
	var out error
	for _, closer := range closers {
		if err := closer.close(); err != nil {
			out = errors.Join(out, err)
		}
	}
	return out
}

func containedError(stage ContainedRunStage, cause error, cleanup error) error {
	if cause == nil && cleanup == nil {
		return nil
	}
	if cause == nil {
		return &ContainedRunError{
			Stage: ContainedStageCleanup,
			Cause: cleanup,
		}
	}
	out := &ContainedRunError{Stage: stage, Cause: cause}
	if cleanup != nil {
		out.CleanupStage = ContainedStageCleanup
		out.CleanupCause = cleanup
	}
	return out
}

func validateContainedStream(
	ctx context.Context,
	cmd *exec.Cmd,
	options ContainedStreamOptions,
	consumeStdout func(io.Reader) error,
) (uint32, error) {
	if ctx == nil || cmd == nil || consumeStdout == nil {
		return 0, &ContainedRunError{Stage: ContainedStageValidate, Cause: errInvalidContainedRun}
	}
	if err := ctx.Err(); err != nil {
		return 0, &ContainedRunError{Stage: ContainedStageValidate, Cause: err}
	}
	if cmd.Process != nil || cmd.ProcessState != nil ||
		cmd.Stdin != nil || cmd.Stdout != nil || cmd.Stderr != nil ||
		len(cmd.ExtraFiles) != 0 || cmd.Cancel != nil || cmd.WaitDelay != 0 {
		return 0, &ContainedRunError{Stage: ContainedStageValidate, Cause: errInvalidContainedRun}
	}
	if options.CleanupTimeout < time.Millisecond ||
		options.CleanupTimeout > maxContainedCleanupTimeout ||
		options.CleanupTimeout%time.Millisecond != 0 {
		return 0, &ContainedRunError{
			Stage: ContainedStageValidate,
			Cause: ErrInvalidCleanupTimeout,
		}
	}
	// This is the only duration-to-milliseconds conversion in the seam.
	return uint32(options.CleanupTimeout / time.Millisecond), nil
}

// RunContainedStream runs one finite command with fail-closed descendant
// containment while the caller consumes stdout incrementally.
func RunContainedStream(
	ctx context.Context,
	cmd *exec.Cmd,
	options ContainedStreamOptions,
	consumeStdout func(io.Reader) error,
) error {
	return runContainedStreamWithDependencies(
		ctx,
		cmd,
		options,
		consumeStdout,
		defaultContainedStreamDependencies(),
	)
}

func runContainedStreamWithDependencies(
	ctx context.Context,
	cmd *exec.Cmd,
	options ContainedStreamOptions,
	consumeStdout func(io.Reader) error,
	deps containedStreamDependencies,
) error {
	return runContainedStreamCore(ctx, cmd, options, consumeStdout, deps, nil)
}

func runContainedStreamCore(
	ctx context.Context,
	cmd *exec.Cmd,
	options ContainedStreamOptions,
	consumeStdout func(io.Reader) error,
	deps containedStreamDependencies,
	receipt *ContainedStreamReceiptV1,
) (returned error) {
	var child containedChild
	var native ContainedNativeSnapshot
	var nativeSettled bool
	var stdinCloser, stdoutReadCloser, stdoutWriteCloser, stderrReadCloser, stderrWriteCloser *ownedCloser
	var stdoutCount, stderrCount *containedCountingReader
	var stdoutCompleted, stderrCompleted, waitCompleted bool
	var stdoutErr, stderrErr error
	var finalWait containedWaitResult
	var startupObservationErr error
	defer func() {
		if receipt == nil {
			return
		}
		receipt.IOSettlement = ContainedIOSettlement{Stdin: stdinCloser.snapshot(), StdoutRead: stdoutReadCloser.snapshot(), StdoutWrite: stdoutWriteCloser.snapshot(), StderrRead: stderrReadCloser.snapshot(), StderrWrite: stderrWriteCloser.snapshot(), Stdout: stdoutCount.snapshot(stdoutCompleted, stdoutErr), Stderr: stderrCount.snapshot(stderrCompleted, stderrErr)}
		receipt.RootWaitKnown = waitCompleted && finalWait.exited
		receipt.RootExitCode = finalWait.exitCode
		receipt.RootExitError = finalWait.err
		if nativeSettled {
			if !native.RootIdentity.Known && receipt.RootIdentity.Known {
				native.RootIdentity = receipt.RootIdentity
			}
			native.RootWaitKnown = receipt.RootWaitKnown
			native.RootExitCode = receipt.RootExitCode
			receipt.NativeSettlement = &ContainedProcessSettlement{owner: child, snapshot: native}
			receipt.RootIdentity = native.RootIdentity
			receipt.TerminalAction = native.TerminalAction
		}
		var e *ContainedRunError
		if errors.As(returned, &e) {
			receipt.Stage = e.Stage
			receipt.PrimaryError = e.Cause
			receipt.CleanupError = e.CleanupCause
		} else {
			receipt.PrimaryError = returned
		}
	}()
	cleanupTimeoutMs, err := validateContainedStream(ctx, cmd, options, consumeStdout)
	if err != nil {
		return err
	}
	if deps.newChild == nil || deps.pipe == nil || deps.openNull == nil {
		return &ContainedRunError{Stage: ContainedStageValidate, Cause: errInvalidContainedRun}
	}
	if receipt != nil && (options.AbsoluteCleanupDeadline.IsZero() || !time.Now().Before(options.AbsoluteCleanupDeadline) || options.StdoutByteLimit <= 0 || options.StderrByteLimit <= 0 || options.Stderr == nil) {
		return &ContainedRunError{Stage: ContainedStageValidate, Cause: errInvalidContainedRun}
	}
	if receipt != nil {
		workDeadline, finite := ctx.Deadline()
		if !finite || options.AbsoluteCleanupDeadline.Before(workDeadline) || options.AbsoluteCleanupDeadline.After(workDeadline.Add(options.CleanupTimeout)) {
			return &ContainedRunError{Stage: ContainedStageValidate, Cause: errInvalidContainedRun}
		}
	}

	child, err = deps.newChild(cmd)
	if err != nil {
		return &ContainedRunError{
			Stage: ContainedStageContainment,
			Cause: errors.Join(ErrContainmentUnavailable, err),
		}
	}
	if child == nil {
		return &ContainedRunError{
			Stage: ContainedStageContainment,
			Cause: errors.Join(ErrContainmentUnavailable, errInvalidContainedRun),
		}
	}
	observe, observedAvailable := child.(containedObservedChild)
	settleNative := func(natural bool) error {
		if receipt == nil || nativeSettled {
			return nil
		}
		nativeSettled = true
		if !observedAvailable {
			native.Error = ErrContainmentUnavailable
			return native.Error
		}
		cleanupCtx, cancel := containedCleanupContext(options.AbsoluteCleanupDeadline)
		defer cancel()
		var settleErr error
		native, settleErr = observe.settleContained(cleanupCtx, natural)
		native.Error = errors.Join(native.Error, settleErr)
		return settleErr
	}
	childCloser := ownCloser(closerFunc(func() error {
		e := settleNative(false)
		closeErr := child.close()
		if receipt != nil {
			native.HandlesClosed = closeErr == nil
			native.Error = errors.Join(native.Error, closeErr)
		}
		return errors.Join(e, closeErr)
	}))
	if receipt != nil && !observedAvailable {
		return containedError(ContainedStageContainment, ErrContainmentUnavailable, childCloser.close())
	}
	if receipt != nil {
		observe.prepareContainedObservation()
	}

	stdoutRead, stdoutWrite, err := deps.pipe()
	if err != nil {
		return containedError(
			ContainedStagePipeSetup,
			err,
			closeOwned(childCloser),
		)
	}
	stdoutReadCloser = ownCloser(stdoutRead)
	stdoutWriteCloser = ownCloser(stdoutWrite)

	stderrRead, stderrWrite, err := deps.pipe()
	if err != nil {
		return containedError(
			ContainedStagePipeSetup,
			err,
			closeOwned(stdoutWriteCloser, stdoutReadCloser, childCloser),
		)
	}
	stderrReadCloser = ownCloser(stderrRead)
	stderrWriteCloser = ownCloser(stderrWrite)

	stdin, err := deps.openNull()
	if err != nil {
		return containedError(
			ContainedStagePipeSetup,
			err,
			closeOwned(stderrWriteCloser, stderrReadCloser, stdoutWriteCloser, stdoutReadCloser, childCloser),
		)
	}
	stdinCloser = ownCloser(stdin)

	if receipt != nil {
		receipt.StartAttempted = true
	}
	if err := child.start(cmd, stdin, stdoutWrite, stderrWrite); err != nil {
		stage := ContainedStageStart
		cause := err
		var platformErr *containedPlatformError
		if errors.As(err, &platformErr) {
			stage = platformErr.stage
			cause = platformErr.cause
			if stage == ContainedStageContainment {
				cause = errors.Join(ErrContainmentUnavailable, cause)
			}
		}
		return containedError(
			stage,
			cause,
			closeOwned(stdinCloser, stderrWriteCloser, stderrReadCloser, stdoutWriteCloser, stdoutReadCloser, childCloser),
		)
	}
	if receipt != nil {
		var identityErr error
		receipt.RootIdentity, identityErr = observe.containedRootIdentity()
		startupObservationErr = identityErr
	}

	// The child owns duplicated standard handles now. Closing the parent's
	// copies is mandatory for EOF and never transfers reader ownership.
	cleanupErr := errors.Join(startupObservationErr, closeOwned(stdinCloser, stderrWriteCloser, stdoutWriteCloser))

	type streamResult struct {
		err error
	}
	stdoutDone := make(chan streamResult, 1)
	stderrDone := make(chan streamResult, 1)
	waitDone := make(chan containedWaitResult, 1)

	var stdoutSource io.Reader = stdoutRead
	var stderrSource io.Reader = stderrRead
	if receipt != nil {
		stdoutCount = &containedCountingReader{reader: stdoutRead, state: ContainedIOStream{WorkerStarted: true, Limit: options.StdoutByteLimit}}
		stderrCount = &containedCountingReader{reader: stderrRead, state: ContainedIOStream{WorkerStarted: true, Limit: options.StderrByteLimit}}
		stdoutSource = stdoutCount
		stderrSource = stderrCount
	}
	go func() {
		stdoutDone <- streamResult{err: consumeStdout(stdoutSource)}
	}()
	stderrTarget := options.Stderr
	if stderrTarget == nil {
		stderrTarget = io.Discard
	}
	go func() {
		_, copyErr := io.Copy(stderrTarget, stderrSource)
		stderrDone <- streamResult{err: copyErr}
	}()
	go func() {
		waitDone <- child.wait()
	}()

	var (
		stdoutResult            streamResult
		stderrResult            streamResult
		waitResult              containedWaitResult
		ctxErr                  error
		teardown                = cleanupErr != nil
		readersClosed           bool
		stdoutBeforeReaderClose bool
		stderrBeforeReaderClose bool
	)

	for !teardown {
		select {
		case stdoutResult = <-stdoutDone:
			stdoutCompleted = true
			stdoutBeforeReaderClose = !readersClosed
			if stdoutResult.err != nil {
				teardown = true
			}
		case stderrResult = <-stderrDone:
			stderrCompleted = true
			stderrBeforeReaderClose = !readersClosed
			if stderrResult.err != nil {
				teardown = true
			}
		case waitResult = <-waitDone:
			waitCompleted = true
			teardown = true
		case <-ctx.Done():
			ctxErr = ctx.Err()
			teardown = true
		}
	}

	cleanupDeadline := options.AbsoluteCleanupDeadline
	if receipt == nil {
		cleanupDeadline = time.Now().Add(time.Duration(cleanupTimeoutMs) * time.Millisecond)
	}
	_, deadlineAware := child.(containedDeadlineChild)
	var terminateErr error
	if receipt != nil {
		terminateErr = settleNative(waitCompleted && waitResult.exited && ctxErr == nil && stdoutResult.err == nil && stderrResult.err == nil)
	} else if deadlineChild, ok := child.(containedDeadlineChild); ok {
		terminateErr = deadlineChild.terminateBy(cleanupDeadline)
	} else {
		terminateErr = child.terminate(cleanupTimeoutMs)
	}
	if terminateErr != nil {
		cleanupErr = errors.Join(cleanupErr, terminateErr)
		// Kill-on-close is the final Windows backstop; on POSIX this is a
		// harmless no-op. Closing readers then releases owner-blocked I/O.
		if receipt != nil {
			cleanupErr = errors.Join(cleanupErr, observe.closeContainedJobBackstop())
		} else {
			cleanupErr = errors.Join(cleanupErr, childCloser.close())
		}
		cleanupErr = errors.Join(cleanupErr, closeOwned(stdoutReadCloser, stderrReadCloser))
		readersClosed = true
	}
	if deferred, ok := child.(containedDeferredReapChild); ok {
		// POSIX terminateBy reaps only after its group signal; this retrieves
		// that one final wait result without issuing a second wait.
		if reaped, completed := deferred.reapBy(cleanupDeadline); completed {
			waitResult = reaped
			waitCompleted = true
		}
	}

	drainReady := func() {
		for {
			drained := false
			if !stdoutCompleted {
				select {
				case stdoutResult = <-stdoutDone:
					stdoutCompleted = true
					stdoutBeforeReaderClose = !readersClosed
					drained = true
				default:
				}
			}
			if !stderrCompleted {
				select {
				case stderrResult = <-stderrDone:
					stderrCompleted = true
					stderrBeforeReaderClose = !readersClosed
					drained = true
				default:
				}
			}
			if !waitCompleted {
				select {
				case waitResult = <-waitDone:
					waitCompleted = true
					drained = true
				default:
				}
			}
			if !drained {
				return
			}
		}
	}

	// Completions published before termination returned outrank an already
	// expired deadline. Repeating this drain when the timer fires closes the
	// select race between a ready completion and a ready timer.
	drainReady()
	joinTimer := time.NewTimer(time.Until(cleanupDeadline))
	defer joinTimer.Stop()
	joinTimeout := joinTimer.C
joinLoop:
	for !stdoutCompleted || !stderrCompleted || !waitCompleted {
		select {
		case stdoutResult = <-stdoutDone:
			stdoutCompleted = true
			stdoutBeforeReaderClose = !readersClosed
		case stderrResult = <-stderrDone:
			stderrCompleted = true
			stderrBeforeReaderClose = !readersClosed
		case waitResult = <-waitDone:
			waitCompleted = true
		case <-joinTimeout:
			drainReady()
			if stdoutCompleted && stderrCompleted && waitCompleted {
				joinTimeout = nil
				continue
			}
			joinErr := ErrCleanupTimeout
			if deadlineAware {
				joinErr = errors.Join(joinErr, errors.New("POSIX_JOIN_TIMEOUT"))
			}
			cleanupErr = errors.Join(cleanupErr, joinErr)
			if !readersClosed {
				cleanupErr = errors.Join(cleanupErr, childCloser.close())
				cleanupErr = errors.Join(cleanupErr, closeOwned(stdoutReadCloser, stderrReadCloser))
				readersClosed = true
			}
			// wait() remains the single reaper and may complete asynchronously,
			// but a kernel-stuck wait cannot extend the request past its one
			// advertised cleanup deadline.
			break joinLoop
		}
	}

	if !readersClosed {
		cleanupErr = errors.Join(cleanupErr, closeOwned(stdoutReadCloser, stderrReadCloser))
	}
	cleanupErr = errors.Join(cleanupErr, childCloser.close())
	stdoutErr, stderrErr = stdoutResult.err, stderrResult.err
	finalWait = waitResult

	var primaryStage ContainedRunStage
	var primary error
	var exitCode *int

	// A genuine consumer failure outranks cancellation and process outcomes.
	if startupObservationErr != nil {
		primaryStage = ContainedStageStart
		primary = startupObservationErr
	} else if stdoutResult.err != nil && stdoutBeforeReaderClose {
		primaryStage = ContainedStageStdout
		primary = stdoutResult.err
	} else if ctxErr != nil {
		primaryStage = ContainedStageContext
		primary = ctxErr
	} else if stderrResult.err != nil && stderrBeforeReaderClose {
		primaryStage = ContainedStageStderr
		primary = stderrResult.err
	} else if waitResult.exited && waitResult.exitCode != 0 {
		code := waitResult.exitCode
		exitCode = &code
		primaryStage = ContainedStageExit
		primary = waitResult.err
		if primary == nil {
			primary = errContainedExit
		}
	} else if waitResult.err != nil {
		primaryStage = ContainedStageWait
		primary = waitResult.err
	}

	if primary == nil {
		return containedError(ContainedStageCleanup, nil, cleanupErr)
	}
	out := &ContainedRunError{
		Stage:    primaryStage,
		Cause:    primary,
		ExitCode: exitCode,
	}
	if cleanupErr != nil {
		out.CleanupStage = ContainedStageCleanup
		out.CleanupCause = cleanupErr
	}
	return out
}

type closerFunc func() error

func (f closerFunc) Close() error {
	if f == nil {
		return nil
	}
	return f()
}

func fixedContainedError(stage ContainedRunStage, err error) error {
	if err == nil {
		return nil
	}
	return &containedPlatformError{stage: stage, cause: fmt.Errorf("platform %s: %w", stage, err)}
}
