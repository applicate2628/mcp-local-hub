"""Decode the one owned R25 transfer and verify every admitted file."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121")
EXPECTED = "17a1e304f87f598d4178f45aa85f46503fcb8e9ea2327b6889a9ef059d9ee2fd"
if Path(__file__).resolve().parent != ROOT:
    raise RuntimeError("Unexpected transfer root")
raw = base64.b64decode((ROOT / "go-budget-input.b64").read_text(), validate=True)
if len(raw) != 24561 or hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise RuntimeError("Transfer checksum differs")
records = []
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    names = archive.namelist()
    if len(names) != 2 or len(set(names)) != len(names) or archive.testzip() is not None:
        raise RuntimeError("Archive membership or CRC differs")
    for name in names:
        path = PurePosixPath(name)
        if path.is_absolute() or any(part in (".", "..") for part in path.parts) or "\\" in name or ":" in name:
            raise RuntimeError("Unexpected archive path")
        target = ROOT / name
        if target.exists():
            raise RuntimeError("Refuse to replace an existing payload")
    for name in names:
        data = archive.read(name)
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
        reread = target.read_bytes()
        if reread != data:
            raise RuntimeError("Payload readback differs")
        records.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
with (ROOT / "go-budget-input-readback.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump({"archive_bytes": len(raw), "archive_sha256": EXPECTED, "files": records}, stream, indent=2)
print(json.dumps({"archive_sha256": EXPECTED, "files": len(records), "verified": True}))
