import sys
sys.dont_write_bytecode = True
import hashlib, importlib.util, json, os
from pathlib import Path
root = Path(r"D:\dev\ChatGPT\mcp-r25-focused-20261121")
p = root / "package_evidence.py"
if hashlib.sha256(p.read_bytes()).hexdigest() != "80029a94fcc3e70c89d1e0ca16662587db3bb683e0d768fcfac2549241622b60":
    raise RuntimeError("Probe requires original packager")
spec = importlib.util.spec_from_file_location("r25_readonly_capture_probe", p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
index, verifier = m.bootstrap_index("36697e659091c0c99fbf45105eec03a34c017200623afa9ec1161ed7af3ef8f6")
paths = m.inventory(index, verifier)
files, bad = {}, []
keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns", "st_birthtime_ns", "st_file_attributes")
def values(info):
    return {k: getattr(info, k, None) for k in keys}
for name, path in paths.items():
    try:
        files[name] = m.read_regular(path)[0]
    except Exception as error:
        before = path.lstat()
        with path.open("rb") as f:
            opened = os.fstat(f.fileno())
            raw = f.read()
            after = os.fstat(f.fileno())
        bad.append({"name": name, "error": str(error), "before":values(before), "opened":values(opened), "after":values(after), "path_after":values(path.lstat()), "sha256":hashlib.sha256(raw).hexdigest()})
if not bad:
    extra, absent = m.source_inputs(index, files, verifier)
    extra["frozen-owner/check_recovery.py"] = m.OWNER
    for name,path in extra.items():
        try:
            m.read_regular(path)
        except Exception as error:
            before = path.lstat()
            with path.open("rb") as f:
                opened = os.fstat(f.fileno())
                raw = f.read()
                after = os.fstat(f.fileno())
            bad.append({"name":name,"error":str(error),"before":values(before),"opened":values(opened),"after":values(after),"path_after":values(path.lstat()),"sha256":hashlib.sha256(raw).hexdigest()})
print(json.dumps({"inputs":len(paths),"failures":bad},indent=2))
