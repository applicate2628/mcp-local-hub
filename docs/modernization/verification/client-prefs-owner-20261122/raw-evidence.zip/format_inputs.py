"""Format only named, pre-hashed candidate inputs with the existing gofmt."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
assert Path(__file__).resolve().parent == ROOT and len(sys.argv) == 3
assert hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() == "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
raw = q.own(sys.argv[1]).read_bytes()
assert q.sha(raw) == sys.argv[2]
plan = json.loads(raw)
phase = plan["phase"]
assert re.fullmatch(r"format-[a-z0-9-]{1,40}", phase)
paths = []
for row in plan["files"]:
    assert row["path"].startswith("inputs/") and row["path"].endswith(".go")
    path = q.own(row["path"])
    data = path.read_bytes()
    assert len(data) == row["bytes"] and q.sha(data) == row["sha256"]
    paths.append(path)
assert paths and len(set(paths)) == len(paths)
out = q.own("evidence/" + phase)
out.mkdir(parents=True, exist_ok=False)
runtime = q.own("runtime/" + phase)
runtime.mkdir(parents=True, exist_ok=False)
env = q.environment(runtime, {})
for name, digest in q.PINS.items():
    assert q.sha(Path(name).read_bytes()) == digest
row = {"argv": [str(q.GOFMT), "-w", *map(str, paths)], "before": plan["files"],
       "settled": False, "timed_out": False, "started_utc": q.now()}
q.save(out / "started.json", row)
child = None
try:
    with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
        child = subprocess.Popen(row["argv"], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        row["pid"] = child.pid
        row["exit_code"] = child.wait(timeout=60)
        row["settled"] = True
except subprocess.TimeoutExpired:
    row["timed_out"] = True
    raise
finally:
    if child is not None and not row["settled"]:
        child.terminate()
        row["exit_code"] = child.wait(timeout=10)
        row["settled"] = True
    row["after"] = [{"path": str(p.relative_to(ROOT)).replace("\\", "/"),
                     "bytes": len(p.read_bytes()), "sha256": q.sha(p.read_bytes())} for p in paths]
    row["finished_utc"] = q.now()
    q.save(out / "receipt.json", row)
assert row["exit_code"] == 0 and not row["timed_out"]
check = q.execute(out, env, {"label": "gofmt-check", "tool": "gofmt",
                  "args": ["-l", *map(str, paths)], "timeout_seconds": 60, "expected_exit_code": 0}, ROOT)
assert check["oracle_pass"]
formatted = [{**r, "base64": base64.b64encode(p.read_bytes()).decode()} for r, p in zip(row["after"], paths)]
payload = base64.b64encode(zlib.compress(json.dumps(formatted).encode(), 9))
with q.own(phase + "-formatted.b64").open("xb") as stream:
    stream.write(payload)
print(json.dumps({"phase": phase, "files": len(paths), "formatted_sha256": q.sha(payload),
                  "formatted_bytes": len(payload), "completed": True}), flush=True)
