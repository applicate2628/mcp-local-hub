"""Pure data and hash helpers for the separately reviewed A3 preparation."""
import hashlib
import json
from pathlib import PurePosixPath, PureWindowsPath

REMOTE = PureWindowsPath(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
BASE_COMMIT = "65fea0b567a80f8793ccd417e9503c674e340f72"
BASE_TREE = "67991d80a424d61d2eecff9b72f7ca20ae31febb"
BASE_COUNT = 3283
BASE_BYTES = 55719013
RUNNER_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
FORMATTER_SHA = "9a94606db871d5102f76266119b9ad84e7aa5c8cc76f651d26d5bd37c02bb8a1"
BASELINE_SHA = "f7a7ad049c2e27b0df8fca68e1cb772909d3eed504fbb6ccf07ffdc0f0a0dd7a"
SOURCE_URL = "https://codeload.github.com/applicate2628/mcp-local-hub/zip/" + BASE_COMMIT
SOURCE_PREFIX = "mcp-local-hub-" + BASE_COMMIT + "/"
BASE_DIRECTORY = "architecture-base-source"
CANDIDATE_DIRECTORY = "architecture-source"
FILES = (
    "internal/gui/client_install_prefs.go",
    "internal/gui/client_install_prefs_test.go",
    "internal/gui/server.go",
)
ROOTS = [
    "TestClientInstallPrefs_UsesServerAPI",
    "TestClientInstallPrefs_ServersKeepIndependentDependencies",
    "TestClientInstallPrefs_GetDefault",
    "TestClientInstallPrefs_PostPersistsAndReturnsSnapshot",
    "TestClientInstallPrefs_PostUnknownClientIs400",
    "TestClientInstallPrefs_PostEmptySetIs400",
    "TestClientInstallPrefs_MethodNotAllowed",
    "TestClientInstallPrefs_CrossOriginRejected",
]
INDEPENDENCE_ROOT = ROOTS[1]
STEPS = [
    "first_initial_read", "second_initial_read", "first_mutation",
    "second_after_first_mutation", "second_mutation", "first_after_second_mutation",
]
CONTROL_FAILURES = {
    "first_initial_read": "selected=[vscode], want [cursor]",
    "second_after_first_mutation": "selected=[claude-code], want [vscode]",
    "first_after_second_mutation": "selected=[codex-cli], want [claude-code]",
}
PACKAGE = "mcp-local-hub/internal/gui"
REMOVED = {
    "24d9c30a73077273cecb80e7e46f46eb1e787d5d4579b9e25488b8f661056a9d": ("mutable_global", "clientInstallPrefsViewFn"),
    "2b533332b231b11e1941ec5d908bd5b5961849a9243135a0d222411590c436fd": ("api_construction", "clientInstallPrefsSetNames"),
    "3c49a37917a4fa67c001fbf39954303f9f54f3ea27af7c6ae38d8180b4198846": ("api_construction", "clientInstallPrefsView"),
    "bc262b12501bc20b069a110fa95df448fe5019a08dd3daa01959b28664eb9c15": ("mutable_global", "clientInstallPrefsSetFn"),
}
SERVER_BUDGET = "e7f29b64ccfbb97e6553b041f6a4c1d9952da9e14de4033f9da9820e976d1d88"
BASE_COUNTERS = dict(expired=0, grown=42, new=387, stale=128, unowned=0, workers=72)
CANDIDATE_COUNTERS = {**BASE_COUNTERS, "stale": 132}
HISTORICAL_ARCHIVE = "docs/modernization/verification/gui-owner-policy-20261122/raw-evidence.zip"
HISTORICAL_ARCHIVE_SHA = "d4a7a6196cad98e658c676adbb77c4d6bf3e3cf75cee9572cffff3c8d0abeb77"
HISTORICAL_SCAN = "evidence/architecture-owner-green/arch-scan.stdout.log"
HISTORICAL_SCAN_SHA = "2c69b7528acfcd7380825479108b617f5706864c2d0ecbed2ba28786be45ccb6"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def safe_relative(name):
    path = PurePosixPath(name)
    reserved = {"CON", "PRN", "AUX", "NUL", *("COM" + str(i) for i in range(1, 10)),
                *("LPT" + str(i) for i in range(1, 10))}
    if not name or path.is_absolute() or path.as_posix() != name:
        raise ValueError("Unclean relative path: " + repr(name))
    for part in path.parts:
        if (part in (".", "..") or part.casefold() == ".git" or
                part.endswith((" ", ".")) or part.split(".", 1)[0].upper() in reserved or
                any(ord(c) < 32 or c in '\\:<>"|?*' for c in part)):
            raise ValueError("Unsafe Windows path: " + repr(name))
    return path


def blob_id(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def file_row(path, raw):
    safe_relative(path)
    return {"path": path, "mode": "100644", "git_blob": blob_id(raw),
            "bytes": len(raw), "sha256": sha(raw)}


def tree_id(rows):
    """Reconstruct Git's tree object bytes, including its directory ordering."""
    root = {}
    folded = set()
    for row in rows:
        path = safe_relative(row["path"])
        if row["mode"] != "100644" or row["path"].casefold() in folded:
            raise ValueError("Non-regular mode or Windows path collision")
        folded.add(row["path"].casefold())
        node = root
        for part in path.parts[:-1]:
            node = node.setdefault(part, {})
            if not isinstance(node, dict):
                raise ValueError("File/directory collision")
        if path.name in node:
            raise ValueError("Duplicate or file/directory collision")
        node[path.name] = bytes.fromhex(row["git_blob"])

    def digest(node):
        ordered = sorted(node.items(), key=lambda kv: kv[0].encode("utf-8") + (b"/" if isinstance(kv[1], dict) else b""))
        body = b"".join((b"40000" if isinstance(value, dict) else b"100644") + b" " +
                        name.encode("utf-8") + b"\0" + (digest(value) if isinstance(value, dict) else value)
                        for name, value in ordered)
        return hashlib.sha1(b"tree " + str(len(body)).encode() + b"\0" + body).digest()
    return digest(root).hex()


def simple_rows(rows):
    return [{key: row[key] for key in ("path", "bytes", "sha256")} for row in rows]


def inventory_summary(rows):
    data = [[row["path"], row["bytes"], row["sha256"]] for row in rows]
    return {"files": len(rows), "bytes": sum(row[1] for row in data),
            "inventory_sha256": sha(json.dumps(data, separators=(",", ":"), ensure_ascii=True).encode())}


def verification_line(counters):
    return "architecture verification: " + " ".join(key + "=" + str(counters[key]) for key in sorted(counters))


def test_terminals(control=False):
    if not control:
        return {"pass": ROOTS + [INDEPENDENCE_ROOT + "/" + step for step in STEPS] + ["PACKAGE:" + PACKAGE], "fail": [], "skip": []}
    return {
        "pass": [INDEPENDENCE_ROOT + "/" + step for step in STEPS if step not in CONTROL_FAILURES],
        "fail": [INDEPENDENCE_ROOT, "PACKAGE:" + PACKAGE] + [INDEPENDENCE_ROOT + "/" + step for step in CONTROL_FAILURES],
        "skip": [],
    }


def qualification_plans(base_rows, candidate_rows, input_rows):
    common = {"schema": 1, "runner_sha256": RUNNER_SHA, "source_head": BASE_COMMIT,
              "base_tree": BASE_TREE, "native_scheduler_operations": False,
              "inputs_directory": "inputs", "input_files": simple_rows(input_rows)}

    def plan(phase, rows, directory, commands):
        return {**common, "phase": phase, "source_tree": tree_id(rows),
                "source_note": "source_head identifies the immutable base; source_tree and the complete source_files inventory identify these physical bytes. No candidate commit is claimed.",
                "source_directory": directory, "source_files": simple_rows(rows), "commands": commands}

    def command(label, args, expected=0, required=(), timeout=360):
        return {"label": label, "tool": "go", "args": args, "timeout_seconds": timeout,
                "expected_exit_code": expected, "required_output": list(required)}

    def test_command(control=False):
        roots = [INDEPENDENCE_ROOT] if control else ROOTS
        args = ["test", "-tags=test_state_path_env", "-race", "-count=1", "-parallel=1", "-timeout=180s", "-json"]
        if control:
            args += ["-overlay", str(REMOTE / "inputs/a3-control/overlay.json")]
        args += ["-run", "^(" + "|".join(roots) + ")$", "./internal/gui"]
        result = command("a3-shared-owner-control" if control else "a3-client-prefs", args,
                         int(control), CONTROL_FAILURES.values() if control else (), timeout=240)
        result["required_tests"] = {key: values for key, values in test_terminals(control).items() if values}
        return result

    def architecture_commands(counters):
        flags = ["--root", ".", "--policy", "architecture/policy.yaml"]
        return [command("arch-scan", ["run", "./tools/archcheck", "scan", *flags],
                        required=['"schema_version": 1', '"module": "mcp-local-hub"']),
                command("arch-verify", ["run", "./tools/archcheck", "verify", *flags,
                        "--owners", "architecture/owners.yaml", "--baseline", "architecture/baseline.yaml",
                        "--workers", "architecture/workers.yaml"], expected=1,
                        required=[verification_line(counters)])]

    format_paths = list(FILES) + [str(REMOTE / "inputs/a3-control" / path) for path in (FILES[0], FILES[2])]
    formatting = {"label": "a3-gofmt-check", "tool": "gofmt", "args": ["-l", *format_paths],
                  "timeout_seconds": 60, "expected_exit_code": 0}
    return {
        "a3-gui-independence.json": plan("a3-gui-independence", candidate_rows, CANDIDATE_DIRECTORY,
                                         [formatting, test_command(True), test_command()]),
        "a3-base-architecture.json": plan("a3-base-architecture", base_rows, BASE_DIRECTORY,
                                          architecture_commands(BASE_COUNTERS)),
        "a3-candidate-architecture.json": plan("a3-candidate-architecture", candidate_rows, CANDIDATE_DIRECTORY,
                                               architecture_commands(CANDIDATE_COUNTERS)),
        "a3-build-vet-optional.json": plan("a3-build-vet-optional", candidate_rows, CANDIDATE_DIRECTORY,
                                           [command("build", ["build", "./..."], timeout=900),
                                            command("vet", ["vet", "./..."], timeout=900)]),
    }
