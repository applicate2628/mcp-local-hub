"""Local preparation from immutable Git blobs; never runs Go or remote commands."""
import sys
sys.dont_write_bytecode = True
import base64
import copy
import difflib
import io
import json
from pathlib import Path
import subprocess
import zipfile
import zlib

import contract as c

PREP = Path(__file__).resolve().parent
ROOT = PREP.parent
REPO = ROOT.parent / "architecture-next"
PINNED_A3 = {
    c.FILES[0]: "6387fdb3a0a49619908543890b6140e91848d98da2722d84cf6d4261b0f1ec28",
    c.FILES[1]: "e5eb8abab621e9edffc799227e7d35402fb44425ad18a24dcc5064b3764957a1",
    c.FILES[2]: "e55eff0f90f83ba1376d20e38d1e34805b76a74340a8ebd1507947389d05e723",
}


def git(*args, input=None):
    return subprocess.run(["git", *args], cwd=REPO, input=input, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout


def write_exact(relative, raw):
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError("Existing prepared artifact differs; preserve it before regeneration: " + relative)
        return
    with path.open("xb") as stream:
        stream.write(raw)


def pin(relative):
    raw = (ROOT / relative).read_bytes()
    return {"path": relative, "bytes": len(raw), "sha256": c.sha(raw)}


def main():
    if c.sha((ROOT / "qualify_go.py").read_bytes()) != c.RUNNER_SHA:
        raise RuntimeError("Local runner no longer matches its pin")
    if c.sha((ROOT / "format_inputs.py").read_bytes()) != c.FORMATTER_SHA:
        raise RuntimeError("Local formatter no longer matches its pin")
    if git("rev-parse", c.BASE_COMMIT + "^{tree}").decode().strip() != c.BASE_TREE:
        raise RuntimeError("Local immutable Git base differs")
    metadata = []
    for line in git("ls-tree", "-r", "-z", "--full-tree", c.BASE_COMMIT).split(b"\0"):
        if not line:
            continue
        header, path = line.split(b"\t", 1)
        mode, kind, oid = header.decode().split()
        if mode != "100644" or kind != "blob":
            raise RuntimeError("Base contains a non-regular tracked entry")
        metadata.append((path.decode("utf-8"), oid))
    # The object IDs come directly from Git; every full blob is read separately
    # from the working tree and independently SHA-256 hashed here.
    batch = io.BytesIO(git("cat-file", "--batch", input="".join(oid + "\n" for _, oid in metadata).encode()))
    base = {}
    base_rows = []
    for path, oid in metadata:
        found, kind, length = batch.readline().decode().split()
        raw = batch.read(int(length))
        if found != oid or kind != "blob" or batch.read(1) != b"\n" or c.blob_id(raw) != oid:
            raise RuntimeError("Git batch blob framing or identity differs")
        base[path] = raw
        base_rows.append(c.file_row(path, raw))
    if batch.read():
        raise RuntimeError("Extra Git batch bytes")
    base_rows.sort(key=lambda row: row["path"])
    if (len(base_rows) != c.BASE_COUNT or sum(row["bytes"] for row in base_rows) != c.BASE_BYTES or
            c.tree_id(base_rows) != c.BASE_TREE):
        raise RuntimeError("Reconstructed local Git tree/count/bytes differ")
    replacement = {}
    for path in c.FILES:
        raw = (ROOT / "inputs/a3" / path).read_bytes()
        if c.sha(raw) != PINNED_A3[path] or raw != (REPO / path).read_bytes():
            raise RuntimeError("Frozen A3 input or working-source readback changed: " + path)
        replacement[path] = raw
    candidate_rows = [c.file_row(path, replacement.get(path, base[path])) for path in sorted(base)]
    candidate_tree = c.tree_id(candidate_rows)
    changed = [old["path"] for old, new in zip(base_rows, candidate_rows) if old != new]
    if changed != sorted(c.FILES):
        raise RuntimeError("Candidate is not exactly the three intended replacements")
    if c.sha(base["architecture/baseline.yaml"]) != c.BASELINE_SHA:
        raise RuntimeError("Baseline bytes changed")
    if base[c.FILES[2]].count(b"\n") != 1265 or replacement[c.FILES[2]].count(b"\n") != 1267:
        raise RuntimeError("Server file-budget source line counts differ")

    prefs = replacement[c.FILES[0]].decode()
    insertion = "\nfunc registerClientInstallPrefsRoutes(s *Server) {\n"
    if prefs.count(insertion) != 1 or prefs.count("s.clientInstallPrefs.") != 3:
        raise RuntimeError("Negative-control edit anchors changed")
    prefs = prefs.replace(insertion, "\n// Negative control only: every request uses the most recently constructed Server.\nvar clientInstallPrefsLastServerForControl *Server\n" + insertion)
    prefs = prefs.replace("s.clientInstallPrefs.", "clientInstallPrefsLastServerForControl.clientInstallPrefs.")
    server = replacement[c.FILES[2]].decode()
    assignment = "\ts.clientInstallPrefs = s.api\n"
    if server.count(assignment) != 1:
        raise RuntimeError("Negative-control constructor anchor changed")
    server = server.replace(assignment, assignment + "\tclientInstallPrefsLastServerForControl = s\n")
    controls = {"inputs/a3-control/" + c.FILES[0]: prefs.encode(),
                "inputs/a3-control/" + c.FILES[2]: server.encode()}
    for path, raw in controls.items():
        write_exact(path, raw)
    overlay = {"Replace": {str(c.REMOTE / c.CANDIDATE_DIRECTORY / path):
                           str(c.REMOTE / "inputs/a3-control" / path) for path in (c.FILES[0], c.FILES[2])}}
    write_exact("inputs/a3-control/overlay.json", c.json_bytes(overlay))
    input_paths = sorted(["inputs/a3/" + path for path in c.FILES] + list(controls) + ["inputs/a3-control/overlay.json"])
    input_pins = [pin(path) for path in input_paths]
    input_rows = [c.file_row(path[len("inputs/"):], (ROOT / path).read_bytes()) for path in input_paths]
    plans = c.qualification_plans(base_rows, candidate_rows, input_rows)
    for name, value in plans.items():
        write_exact("a3-prep/plans/" + name, c.json_bytes(value))
    write_exact("a3-prep/format-control.json", c.json_bytes({"phase": "format-a3-control", "files": [pin(path) for path in sorted(controls)]}))

    historical_raw = base[c.HISTORICAL_ARCHIVE]
    if c.sha(historical_raw) != c.HISTORICAL_ARCHIVE_SHA:
        raise RuntimeError("Historical qualification archive changed")
    with zipfile.ZipFile(io.BytesIO(historical_raw)) as archive:
        scan_raw = archive.read(c.HISTORICAL_SCAN)
        if c.sha(scan_raw) != c.HISTORICAL_SCAN_SHA:
            raise RuntimeError("Historical scan bytes changed")
        historical_plan = json.loads(archive.read("plans/architecture-owner-green.json"))
        historical_verify = archive.read("evidence/architecture-owner-green/arch-verify.stderr.log").decode()
    if historical_verify != c.verification_line(c.BASE_COUNTERS) + "\nexit status 1\n":
        raise RuntimeError("Historical verification does not support the exact expected counters")
    current_by_path = {row["path"]: row for row in c.simple_rows(base_rows)}
    prior_paths = set()
    for row in historical_plan["source_files"]:
        if current_by_path.get(row["path"]) != row:
            raise RuntimeError("Exact #663 base differs from historical qualified bytes: " + row["path"])
        prior_paths.add(row["path"])
    additions = sorted(set(base) - prior_paths)
    expected_additions = ["docs/modernization/verification/gui-owner-policy-20261122/" + name
                          for name in ("README.md", "evidence.json", "raw-evidence.zip")]
    if additions != expected_additions:
        raise RuntimeError("Historical source comparison has unexpected added files")
    report = json.loads(scan_raw)
    report.pop("root")
    if len(report["violations"]) != 2660:
        raise RuntimeError("Unexpected historical scan size")
    next_report = copy.deepcopy(report)
    removed = {row["fingerprint"]: row for row in report["violations"] if row["fingerprint"] in c.REMOVED}
    if set(removed) != set(c.REMOVED):
        raise RuntimeError("Expected four architecture removals are absent from the base scan")
    for fingerprint, (kind, symbol) in c.REMOVED.items():
        row = removed[fingerprint]
        if row["kind"] != kind or row["location"]["symbol"] != symbol or row["location"]["path"] != c.FILES[0]:
            raise RuntimeError("Removed fingerprint describes a different source owner")
    line_maps = {}
    for path in c.FILES:
        old_lines = base[path].splitlines()
        new_lines = replacement[path].splitlines()
        mapping = {}
        for block in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_matching_blocks():
            mapping.update({block.a + i + 1: block.b + i + 1 for i in range(block.size)})
        line_maps[path] = mapping
    next_report["violations"] = [row for row in next_report["violations"] if row["fingerprint"] not in c.REMOVED]
    line_changes = {}
    for row in next_report["violations"]:
        path = row["location"]["path"]
        old_line = row["location"].get("line", 0)
        if path in line_maps and old_line:
            new_line = line_maps[path].get(old_line)
            if new_line is None:
                raise RuntimeError("Surviving violation points to edited text; review its semantics explicitly")
            row["location"]["line"] = new_line
            if new_line != old_line:
                line_changes[row["fingerprint"]] = [old_line, new_line]
        if row["fingerprint"] == c.SERVER_BUDGET:
            if row["metric"] != 1265 or row["evidence"] != "production_advisory_lines":
                raise RuntimeError("Unexpected server file-budget base")
            row["metric"] = 1267
            row["message"] = "file has 1267 lines and exceeds production_advisory_lines"
    next_report["summary"]["api_construction"] -= 2
    next_report["summary"]["mutable_global"] -= 2
    architecture = {
        "historical_archive": c.HISTORICAL_ARCHIVE, "historical_archive_sha256": c.HISTORICAL_ARCHIVE_SHA,
        "historical_scan_sha256": c.HISTORICAL_SCAN_SHA,
        "historical_source_exact_match_except_report_files": additions,
        "base_report_without_root_sha256": c.sha(c.json_bytes(report)),
        "candidate_report_without_root_sha256": c.sha(c.json_bytes(next_report)),
        "base_violation_count": 2660, "candidate_violation_count": 2656,
        "removed": removed, "surviving_line_changes": line_changes,
        "server_file_budget": {"fingerprint": c.SERVER_BUDGET, "before": 1265, "after": 1267, "baseline_max": 1406},
        "base_counters": c.BASE_COUNTERS, "candidate_counters": c.CANDIDATE_COUNTERS,
        "baseline_sha256": c.BASELINE_SHA, "baseline_mutation_authorized_by_this_plan": False,
    }
    source_plan = {
        "schema": 1, "project_execution": False, "native_scheduler_operations": False,
        "source_url": c.SOURCE_URL, "base_commit": c.BASE_COMMIT, "base_tree": c.BASE_TREE,
        "base_directory": c.BASE_DIRECTORY, "candidate_directory": c.CANDIDATE_DIRECTORY,
        "candidate_tree": candidate_tree, "base_files": base_rows, "candidate_files": candidate_rows,
        "input_files": input_pins,
        "preparation_files": [pin("a3-prep/" + name) for name in ("contract.py", "source.py", "check_evidence.py")],
        "qualification_plan_sha256": {name: c.sha(c.json_bytes(value)) for name, value in plans.items()},
        "architecture_expectations": architecture,
    }
    write_exact("a3-prep/source-plan.json", c.json_bytes(source_plan))
    transfer = ["a3-prep/" + name for name in ("contract.py", "source.py", "check_evidence.py", "make_inputs.py", "README.md", "source-plan.json", "format-control.json")]
    transfer += ["a3-prep/plans/" + name for name in plans]
    transfer += list(controls) + ["inputs/a3-control/overlay.json"]
    transfer_rows = [{**pin(path), "base64": base64.b64encode((ROOT / path).read_bytes()).decode()} for path in transfer]
    payload = base64.b64encode(zlib.compress(c.json_bytes(transfer_rows), 9))
    write_exact("a3-prep/transfer.b64", payload)
    summary = {"base_commit": c.BASE_COMMIT, "base_tree": c.BASE_TREE, "candidate_tree": candidate_tree,
               "base": c.inventory_summary(base_rows), "candidate": c.inventory_summary(candidate_rows),
               "changed_files": changed, "source_plan": pin("a3-prep/source-plan.json"),
               "format_control": pin("a3-prep/format-control.json"),
               "qualification_plans": source_plan["qualification_plan_sha256"],
               "transfer": pin("a3-prep/transfer.b64"), "transfer_files": [pin(path) for path in transfer],
               "project_execution": False, "remote_execution": False}
    write_exact("a3-prep/prepared.json", c.json_bytes(summary))
    print(json.dumps({key: value for key, value in summary.items() if key != "transfer_files"}, indent=2))


if __name__ == "__main__":
    main()
