# A3 source preparation retry: observed DOS ZIP metadata

The first preparation stopped at archive metadata validation, before creating either source directory or executing project code. Its original script, plan, archive, initial/final receipts, and diagnostic remain preserved. This retry uses new filenames and `a3-prep/source-results-v2`; it contains no download or process-launch code.

## Diagnosis

The retained codeload archive is 22,469,879 bytes, SHA-256 `e4c4b4fe80673eb5cf93d0f752159564266514b14d03049bbf823fd935b2c089`. The actual Python metadata diagnostic found:

| Entries | Count | ZIP creator system | External attributes | Upper Unix mode |
|---|---:|---:|---:|---:|
| Directories | 192 | 0 — DOS | `0x10` — directory | `0` |
| Files | 3283 | 0 — DOS | `0x0` — normal file | `0` |

All directory names are in the set of parents derived from the independently pinned Git inventory, including the archive root. They have zero uncompressed/compressed length and zero flags. The original script required a Unix directory mode, then would have required Unix regular-file mode `100644`; this archive does not encode either Unix mode. That assumption in the preparation script caused the failure.

The preserved failed receipt is 849 bytes, SHA-256 `aadb195e39fcb3bfb3baba9ca87d85a9b75c5552198abf659675fcf6c2ab5aa1`. It binds the immutable download, the original source-plan hash `7a1a2dee75252fd0caa5360f1a30cb464a5b2aa2e43efffb15a1a155ab209b2c`, the failed metadata check, and `project_execution=false`.

## Narrow admission change

`source_v2.py` accepts only the actual retained archive, by exact path, size, SHA-256, and prior receipt. It admits only the observed DOS creator/attribute pairs: zero-length expected directory records with `create_system=0`, `external_attr=0x10`, no Unix mode, no flags and zero CRC; expected file records with `create_system=0`, `external_attr=0x0`, no Unix mode, and independently declared Git mode exactly `100644`. Any other mode/attribute representation is rejected. The full directory set must equal the 192 directories derived from the pinned file inventory.

ZIP's DOS metadata does not encode Git's executable bit. The retry therefore does **not** claim to obtain Git mode from those missing Unix bits. The Git mode comes from the independently read immutable Git tree. Each admitted file must match that tree's declared `100644` entry, byte length, SHA-256, and Git blob identifier; reconstruction of all entries must reproduce Git root `67991d80a424d61d2eecff9b72f7ca20ae31febb` before any source directory is created. Files are then created as ordinary files from the verified bytes. No archive permissions, links, special-file metadata, or extraction targets are applied.

Prefix checks, safe Windows path checks, duplicate rejection, encryption rejection, complete file inventory checks, the three exact candidate replacements, complete materialized readback, baseline preservation, runner pinning, and exact qualification-plan derivation remain unchanged. The retained archive and prior receipt are hashed before use, after ZIP verification, and after materialization. All original preparation files are also pinned before and after the retry.

## Execution and independent readback

1. Review the versioned diffs and `prepared-v2.json`; transfer the five new files in `transfer-v2.b64` using its exact hash. The existing scripts, plans, archive, and receipts are not overwritten.
2. Run Python only: `python a3-prep/source_v2.py a3-prep/source-plan-v2.json SOURCE_PLAN_V2_SHA256`, using the exact hash from `prepared-v2.json`.
3. Copy `a3-prep/source-results-v2/manifest.json`, its initial/final receipts, the unchanged prior `a3-prep/source-results/receipt.json`, and the four derived `a3-prep/remote-plans/` files back to the local evidence export.
4. Before project execution, run `python a3-prep/check_evidence_v2.py source EXPORT_ROOT SOURCE_PLAN_V2_SHA256`. It independently verifies the complete source inventories and all original plan hashes, and also checks the preserved failed-attempt receipt and exact observed archive-encoding counts.
5. The four Go qualification plans, source/control bytes, root selections, negative-control assertions, architecture expectations, baseline, and installed runner are unchanged. Subsequent raw execution evidence is checked through `check_evidence_v2.py tests`, `architecture`, `optional`, or `all` with the same version-2 source-plan hash.

The retry preparation itself performs no network access, Go/native execution, installation, baseline edit, or cleanup. A failed retry retains its fresh outputs for investigation. The original source preparation failure remains part of the evidence rather than being overwritten or reported as a success.
