"""Independently check copied source manifests and raw A3 execution evidence.

Usage: python check_evidence.py source|tests|architecture|optional|all EXPORT_ROOT SOURCE_PLAN_SHA256
EXPORT_ROOT mirrors the owned D-root paths. This checker runs no project code
and writes nothing. Its stdout may be retained as the verification result.
"""
import sys
sys.dont_write_bytecode = True
from collections import Counter
import json
from pathlib import Path
import stat

import contract as c

LOCAL = Path(__file__).resolve().parent.parent


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(root, relative):
    path = c.safe_relative(relative)
    current = root
    for part in (None, *path.parts):
        if part is not None:
            current /= part
        info = current.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Reparse point in evidence path")
    return current.read_bytes()


def load(root, relative):
    return json.loads(read(root, relative))


def source_evidence(export, source_plan, plan_sha):
    raw_manifest = read(export, "a3-prep/source-results/manifest.json")
    manifest = json.loads(raw_manifest)
    receipt = load(export, "a3-prep/source-results/receipt.json")
    require(receipt.get("completed") is True and receipt.get("project_execution") is False and
            receipt.get("native_scheduler_operations") is False, "Source preparation did not complete within scope")
    require(receipt["plan_sha256"] == plan_sha, "Source receipt belongs to a different plan")
    require(receipt["manifest"] == {"bytes": len(raw_manifest), "sha256": c.sha(raw_manifest)}, "Manifest receipt/hash mismatch")
    require(manifest["base_commit"] == c.BASE_COMMIT, "Wrong manifest base commit")
    for kind, directory in (("base", c.BASE_DIRECTORY), ("candidate", c.CANDIDATE_DIRECTORY)):
        rows = manifest[kind + "_files"]
        require(rows == source_plan[kind + "_files"], "Remote complete inventory differs from independent local Git blobs: " + kind)
        expected_tree = source_plan[kind + "_tree"]
        require(manifest[kind + "_tree"] == expected_tree == c.tree_id(rows), "Reconstructed manifest Git tree differs: " + kind)
        require(manifest[kind + "_directory"] == directory, "Manifest source destination differs")
        require(receipt[kind + "_readback"] == c.inventory_summary(rows), "Source readback summary differs")
    require(receipt["zip_reconstructed_git_tree"] == c.BASE_TREE and
            receipt["zip_inventory"] == c.inventory_summary(source_plan["base_files"]), "ZIP tree was not verified against the independent base")
    require(receipt["archive"]["url"] == c.SOURCE_URL, "Source download URL differs")
    expected_inputs = []
    for row in source_plan["input_files"]:
        raw = read(LOCAL, row["path"])
        require({"path": row["path"], "bytes": len(raw), "sha256": c.sha(raw)} == row, "Local frozen input changed")
        expected_inputs.append(c.file_row(row["path"][len("inputs/"):], raw))
    require(manifest["input_files"] == expected_inputs, "Remote input inventory differs from frozen inputs")
    plans = c.qualification_plans(manifest["base_files"], manifest["candidate_files"], manifest["input_files"])
    require(manifest["qualification_plan_sha256"] == source_plan["qualification_plan_sha256"], "Remote plan pin set differs")
    for name, value in plans.items():
        remote_raw = read(export, "a3-prep/remote-plans/" + name)
        local_raw = read(LOCAL, "a3-prep/plans/" + name)
        require(remote_raw == local_raw == c.json_bytes(value), "Remote-derived plan bytes differ: " + name)
        require(c.sha(remote_raw) == source_plan["qualification_plan_sha256"][name], "Plan pin differs: " + name)
    return {"complete_inventory_match": True, "base": c.inventory_summary(manifest["base_files"]),
            "candidate": c.inventory_summary(manifest["candidate_files"]),
            "base_tree": c.BASE_TREE, "candidate_tree": source_plan["candidate_tree"], "remote_plans_match": True}


def phase_evidence(export, name, source_plan):
    raw_plan = read(LOCAL, "a3-prep/plans/" + name + ".json")
    require(c.sha(raw_plan) == source_plan["qualification_plan_sha256"][name + ".json"], "Local phase plan pin differs")
    plan = json.loads(raw_plan)
    directory = "evidence/" + name + "/"
    receipt = load(export, directory + "receipt.json")
    require(receipt.get("completed") is True and receipt.get("native_scheduler_operations") is False,
            "Phase did not finish its declared oracles: " + name)
    require(receipt["manifest_sha256"] == c.sha(raw_plan) and receipt["runner_sha256"] == c.RUNNER_SHA,
            "Phase plan/runner pin differs")
    require(receipt["source_head"] == c.BASE_COMMIT and receipt["source_tree"] == plan["source_tree"], "Phase source identity differs")
    for kind in ("source", "inputs"):
        expected = c.inventory_summary(plan["source_files"] if kind == "source" else plan["input_files"])
        require(receipt[kind + "_before"] == receipt[kind + "_after"] == expected,
                "Complete source or pinned inputs changed: " + name)
    require(len(receipt["commands"]) == len(plan["commands"]), "Missing or extra phase command")
    result = {}
    for command, phase_row in zip(plan["commands"], receipt["commands"]):
        label = command["label"]
        row = load(export, directory + label + ".receipt.json")
        require(row == phase_row, "Command and phase receipts disagree")
        started = load(export, directory + label + ".started.json")
        launched = load(export, directory + label + ".launched.json")
        executable = "C:\\msys64\\ucrt64\\bin\\" + ("go.exe" if command["tool"] == "go" else "gofmt.exe")
        argv = [executable, *command["args"]]
        cwd = str(c.REMOTE / plan["source_directory"])
        require(row["argv"] == started["argv"] == launched["argv"] == argv and
                row["cwd"] == started["cwd"] == launched["cwd"] == cwd, "Command argv/cwd differs from the reviewed plan")
        require(row["pid"] == launched["pid"] and type(row["pid"]) is int and row["pid"] > 0, "Original direct-child identity missing")
        require(row["direct_timeout_seconds"] == started["direct_timeout_seconds"] ==
                launched["direct_timeout_seconds"] == command["timeout_seconds"], "Command deadline differs")
        require(row.get("settled") is True and row.get("timed_out") is False and row.get("oracle_pass") is True and
                not row.get("error_type") and not row.get("process_tree_unresolved") and
                row["exit_code"] == command["expected_exit_code"], "Command did not settle within its exact oracle")
        streams = {}
        for stream in ("stdout", "stderr"):
            raw = read(export, directory + label + "." + stream + ".log")
            require(row[stream] == {"bytes": len(raw), "sha256": c.sha(raw)}, "Raw output differs from receipt: " + label)
            streams[stream] = raw
        output = streams["stdout"] + streams["stderr"]
        for needle in command.get("required_output", []):
            require(needle.encode() in output, "Required command diagnostic absent")
        if command["tool"] == "gofmt":
            require(not output, "Formatting check returned output")
        result[label] = {"receipt": row, **streams}
    return result


def check_test_command(command, control):
    require(not command["stderr"], "Test command emitted unexpected stderr")
    require(b"WARNING: DATA RACE" not in command["stdout"] and
            b"race detected during execution of test" not in command["stdout"],
            "Expected control failure cannot admit a data race")
    terminals = {"pass": [], "fail": [], "skip": []}
    runs = []
    outputs = {}
    for line in command["stdout"].splitlines():
        event = json.loads(line)  # Malformed/non-JSON stdout is not silently ignored.
        require(isinstance(event, dict) and event.get("Package") == c.PACKAGE, "Unexpected test JSON package")
        action = event.get("Action")
        name = event.get("Test", "PACKAGE:" + c.PACKAGE)
        if action in terminals:
            terminals[action].append(name)
        if action == "run":
            runs.append(name)
        if action == "output":
            outputs[name] = outputs.get(name, "") + event.get("Output", "")
    expected = c.test_terminals(control)
    for action in terminals:
        require(Counter(terminals[action]) == Counter(expected[action]), "Exact test terminal set differs: " + action)
    require(command["receipt"]["tests"] == terminals, "Raw JSON and receipt test events differ")
    expected_runs = [name for names in expected.values() for name in names if not name.startswith("PACKAGE:")]
    require(Counter(runs) == Counter(expected_runs), "Selected roots/subtests did not each run exactly once")
    if control:
        for step, diagnostic in c.CONTROL_FAILURES.items():
            name = c.INDEPENDENCE_ROOT + "/" + step
            require(diagnostic in outputs.get(name, ""), "Control failed before its ownership/selection assertion: " + step)
    return {"terminal_counts": {key: len(value) for key, value in terminals.items()}, "terminals": terminals,
            "specific_selection_failures_confirmed": control, "skips": 0}


def architecture_evidence(export, source_plan):
    reports = {}
    expectations = source_plan["architecture_expectations"]
    for kind, name, counters in (("base", "a3-base-architecture", c.BASE_COUNTERS),
                                 ("candidate", "a3-candidate-architecture", c.CANDIDATE_COUNTERS)):
        commands = phase_evidence(export, name, source_plan)
        require(not commands["arch-scan"]["stderr"], "Architecture scan emitted stderr")
        report = json.loads(commands["arch-scan"]["stdout"])
        expected_root = str(c.REMOTE / (c.BASE_DIRECTORY if kind == "base" else c.CANDIDATE_DIRECTORY))
        require(report.pop("root") == expected_root, "Scan used a different physical root")
        require(c.sha(c.json_bytes(report)) == expectations[kind + "_report_without_root_sha256"],
                "Full architecture report differs from its independently predicted exact delta: " + kind)
        require(len(report["violations"]) == expectations[kind + "_violation_count"], "Architecture violation total differs")
        require(dict(Counter(row["kind"] for row in report["violations"])) == report["summary"], "Architecture summary disagrees with raw findings")
        verify = commands["arch-verify"]
        require(verify["stdout"] == b"" and verify["stderr"].decode() == c.verification_line(counters) + "\nexit status 1\n",
                "Architecture verification did not preserve all six exact debt counters")
        reports[kind] = {row["fingerprint"]: row for row in report["violations"]}
        require(len(reports[kind]) == len(report["violations"]), "Duplicate architecture fingerprint")
    before, after = reports["base"], reports["candidate"]
    require(set(before) - set(after) == set(c.REMOVED) and not set(after) - set(before), "Scan did not remove exactly the four intended findings")
    require({key: before[key] for key in c.REMOVED} == expectations["removed"], "Removed architecture finding semantics differ")
    require(before[c.SERVER_BUDGET]["metric"] == 1265 and after[c.SERVER_BUDGET]["metric"] == 1267,
            "Server file-budget metric differs")
    return {"base_findings": len(before), "candidate_findings": len(after), "removed_fingerprints": sorted(c.REMOVED),
            "base_counters": c.BASE_COUNTERS, "candidate_counters": c.CANDIDATE_COUNTERS,
            "architecture_gate": "FAILED", "baseline_unchanged_sha256": c.BASELINE_SHA,
            "four_removal_scan_delta_confirmed": True, "baseline_edit_performed": False}


def main():
    require(len(sys.argv) == 4, __doc__)
    mode, export_name, plan_sha = sys.argv[1:]
    require(mode in ("source", "tests", "architecture", "optional", "all"), "Unknown evidence mode")
    export = Path(export_name).absolute()
    raw_plan = read(LOCAL, "a3-prep/source-plan.json")
    require(c.sha(raw_plan) == plan_sha, "Local source-plan hash differs from reviewed caller pin")
    plan = json.loads(raw_plan)
    for row in plan["preparation_files"]:
        raw = read(LOCAL, row["path"])
        require(len(raw) == row["bytes"] and c.sha(raw) == row["sha256"], "Preparation/checker bytes changed")
    result = {"source": source_evidence(export, plan, plan_sha)}
    if mode in ("tests", "all"):
        commands = phase_evidence(export, "a3-gui-independence", plan)
        result["control"] = check_test_command(commands["a3-shared-owner-control"], True)
        result["candidate"] = check_test_command(commands["a3-client-prefs"], False)
    if mode in ("architecture", "all"):
        result["architecture"] = architecture_evidence(export, plan)
    if mode == "optional" or (mode == "all" and (export / "evidence/a3-build-vet-optional/receipt.json").exists()):
        commands = phase_evidence(export, "a3-build-vet-optional", plan)
        require(all(not command["stdout"] and not command["stderr"] for command in commands.values()), "Optional build/vet emitted output")
        result["build_vet"] = "PASSED"
    else:
        result["build_vet"] = "NOT_CHECKED"
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
