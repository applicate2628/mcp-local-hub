"""Prepare a versioned, offline retry for the observed codeload DOS ZIP encoding."""
import sys
sys.dont_write_bytecode = True
import base64
import json
from pathlib import Path
import zlib

import contract as c

PREP = Path(__file__).resolve().parent
ROOT = PREP.parent
OLD_PLAN_SHA = "7a1a2dee75252fd0caa5360f1a30cb464a5b2aa2e43efffb15a1a155ab209b2c"
ARCHIVE = {"path": "a3-prep/source-results/source.zip", "bytes": 22469879,
           "sha256": "e4c4b4fe80673eb5cf93d0f752159564266514b14d03049bbf823fd935b2c089", "url": c.SOURCE_URL}
PRIOR_RECEIPT = {"path": "a3-prep/source-results/receipt.json", "bytes": 849,
                 "sha256": "aadb195e39fcb3bfb3baba9ca87d85a9b75c5552198abf659675fcf6c2ab5aa1"}


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError("Versioned edit anchor is not unique: " + old[:100])
    return text.replace(old, new)


def write_exact(name, raw):
    path = PREP / name
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError("Existing retry artifact differs; preserve before regenerating: " + name)
        return
    with path.open("xb") as stream:
        stream.write(raw)


def pin(name):
    raw = (PREP / name).read_bytes()
    return {"path": "a3-prep/" + name, "bytes": len(raw), "sha256": c.sha(raw)}


def main():
    raw_plan = (PREP / "source-plan.json").read_bytes()
    if c.sha(raw_plan) != OLD_PLAN_SHA:
        raise RuntimeError("Original frozen source plan changed")
    plan = json.loads(raw_plan)
    for row in plan["preparation_files"]:
        raw = (ROOT / row["path"]).read_bytes()
        if len(raw) != row["bytes"] or c.sha(raw) != row["sha256"]:
            raise RuntimeError("Original preparation file changed")

    source = (PREP / "source.py").read_text()
    source = replace_once(source,
        '"""Windows preparation only: download exact source, verify, and write fresh trees.',
        '"""Offline Windows retry: verify the retained exact archive and write fresh trees.')
    source = replace_once(source, "import time\n", "")
    source = replace_once(source, "import urllib.request\n", "")
    source = replace_once(source, 'own("a3-prep/source.py")', 'own("a3-prep/source_v2.py")')
    source = replace_once(source,
        '    for destination in (c.BASE_DIRECTORY, c.CANDIDATE_DIRECTORY, "a3-prep/remote-plans", "a3-prep/source-results"):\n',
        '''    retained = plan["retained_archive"]
    prior_receipt_pin = plan["prior_attempt_receipt"]
    if (retained != RETAINED_ARCHIVE or prior_receipt_pin != PRIOR_RECEIPT or
            plan.get("prior_source_plan_sha256") != PRIOR_PLAN_SHA):
        raise RuntimeError("Retry must use only the exact retained archive and failed attempt")
    check_pins([retained, prior_receipt_pin])
    prior = json.loads(own(prior_receipt_pin["path"]).read_bytes())
    if (prior.get("completed") is not False or prior.get("project_execution") is not False or
            prior.get("native_scheduler_operations") is not False or prior.get("plan_sha256") != PRIOR_PLAN_SHA or
            prior.get("archive") != retained or prior.get("error") != "Unadmitted archive directory"):
        raise RuntimeError("Preserved failure receipt does not describe the admitted attempt")
    for destination in (c.BASE_DIRECTORY, c.CANDIDATE_DIRECTORY, "a3-prep/remote-plans", "a3-prep/source-results-v2"):
''')
    source = replace_once(source, '    out = own("a3-prep/source-results")', '    out = own("a3-prep/source-results-v2")')
    source = replace_once(source,
        '    save(out / "receipt-initial.json", receipt)\n',
        '    receipt.update(archive=retained, archive_reused=True, prior_attempt_receipt=prior_receipt_pin)\n    save(out / "receipt-initial.json", receipt)\n')
    start = source.index('        archive = out / "source.zip"\n')
    end = source.index('        expected = {row["path"]: row for row in plan["base_files"]}\n', start)
    source = source[:start] + '        archive = own(retained["path"])\n' + source[end:]
    source = replace_once(source, '        contents = {}\n', '        contents = {}\n        directory_names = set()\n')
    source = replace_once(source,
        '''                    if name not in expected_dirs or not stat.S_ISDIR(mode):
                        raise RuntimeError("Unadmitted archive directory")
                    continue
''',
        '''                    # This exact codeload ZIP uses DOS directory attributes
                    # and carries no Unix modes. Admit only the observed tuple;
                    # no archive-provided permissions or links are materialized.
                    if (name not in expected_dirs or info.create_system != 0 or info.external_attr != 0x10 or mode != 0 or
                            info.flag_bits != 0 or info.file_size != 0 or info.compress_size != 0 or info.CRC != 0):
                        raise RuntimeError("Unadmitted DOS archive directory: " + repr(info.filename))
                    directory_names.add(name)
                    continue
''')
    source = replace_once(source,
        '''                if name not in expected or name in contents or mode != 0o100644:
                    raise RuntimeError("Unadmitted ZIP path or mode: " + name)
''',
        '''                # DOS attributes do not encode Git's executable bit. The
                # independently pinned Git inventory supplies that declaration;
                # exact blobs plus the reconstructed Git root verify it below.
                if (name not in expected or name in contents or info.create_system != 0 or
                        info.external_attr != 0 or mode != 0 or expected[name]["mode"] != "100644"):
                    raise RuntimeError("Unadmitted DOS ZIP file or declared Git mode: " + name)
''')
    source = replace_once(source,
        '''        if set(contents) != set(expected):
            raise RuntimeError("ZIP file set differs from the exact Git tree")
''',
        '''        if set(contents) != set(expected) or directory_names != expected_dirs:
            raise RuntimeError("ZIP file/directory set differs from the exact Git tree")
        check_pins([retained, prior_receipt_pin])
        receipt["archive_entry_encoding"] = {"create_system": 0, "directory_external_attr": 16,
                                             "file_external_attr": 0, "directories": len(directory_names),
                                             "files": len(contents)}
''')
    source = replace_once(source,
        '        check_pins(plan["preparation_files"] + plan["input_files"])\n',
        '        check_pins(plan["preparation_files"] + plan["input_files"] + [retained, prior_receipt_pin])\n')
    constants = '\nPRIOR_PLAN_SHA = ' + repr(OLD_PLAN_SHA) + '\nRETAINED_ARCHIVE = ' + repr(ARCHIVE) + '\nPRIOR_RECEIPT = ' + repr(PRIOR_RECEIPT) + '\n'
    source = replace_once(source, '\n\ndef sha(raw):\n', constants + '\n\ndef sha(raw):\n')
    compile(source, "source_v2.py", "exec")
    if "urllib" in source or "urlopen" in source or "subprocess" in source.replace("launches no subprocess", ""):
        raise RuntimeError("Retry unexpectedly contains network/process execution code")
    write_exact("source_v2.py", source.encode())

    checker = (PREP / "check_evidence.py").read_text()
    checker = replace_once(checker, "Usage: python check_evidence.py ", "Usage: python check_evidence_v2.py ")
    checker = replace_once(checker, '"a3-prep/source-results/manifest.json"', '"a3-prep/source-results-v2/manifest.json"')
    checker = replace_once(checker, '"a3-prep/source-results/receipt.json"', '"a3-prep/source-results-v2/receipt.json"')
    checker = replace_once(checker, '"a3-prep/source-plan.json"', '"a3-prep/source-plan-v2.json"')
    checker = replace_once(checker,
        '    require(receipt["archive"]["url"] == c.SOURCE_URL, "Source download URL differs")\n',
        '''    require(receipt["archive"] == source_plan["retained_archive"] and receipt.get("archive_reused") is True,
            "Retry did not preserve the pinned retained archive")
    prior_pin = source_plan["prior_attempt_receipt"]
    prior_raw = read(export, prior_pin["path"])
    require(len(prior_raw) == prior_pin["bytes"] and c.sha(prior_raw) == prior_pin["sha256"],
            "Preserved failure receipt changed")
    prior = json.loads(prior_raw)
    require(prior.get("completed") is False and prior.get("project_execution") is False and
            prior.get("native_scheduler_operations") is False and
            prior["plan_sha256"] == source_plan["prior_source_plan_sha256"] and
            prior["archive"] == source_plan["retained_archive"] and
            prior.get("error") == "Unadmitted archive directory", "Prior attempt provenance differs")
    require(receipt["prior_attempt_receipt"] == prior_pin and receipt["archive_entry_encoding"] ==
            {"create_system": 0, "directory_external_attr": 16, "file_external_attr": 0, "directories": 192, "files": 3283},
            "Observed DOS archive encoding or complete entry counts differ")
''')
    compile(checker, "check_evidence_v2.py", "exec")
    write_exact("check_evidence_v2.py", checker.encode())

    retry_plan = {**plan,
        "preparation_files": [pin(name) for name in ("contract.py", "source_v2.py", "check_evidence_v2.py",
                                                       "source.py", "check_evidence.py", "source-plan.json")],
        "retained_archive": ARCHIVE, "prior_attempt_receipt": PRIOR_RECEIPT,
        "prior_source_plan_sha256": OLD_PLAN_SHA}
    write_exact("source-plan-v2.json", c.json_bytes(retry_plan))
    names = ["source_v2.py", "check_evidence_v2.py", "source-plan-v2.json", "make_retry.py", "README-v2.md"]
    rows = [{**pin(name), "base64": base64.b64encode((PREP / name).read_bytes()).decode()} for name in names]
    payload = base64.b64encode(zlib.compress(c.json_bytes(rows), 9))
    write_exact("transfer-v2.b64", payload)
    prepared = {"schema": 1, "source_plan": pin("source-plan-v2.json"),
                "files": [pin(name) for name in names], "transfer": pin("transfer-v2.b64"),
                "prior_source_plan_sha256": OLD_PLAN_SHA, "retained_archive": ARCHIVE,
                "prior_attempt_receipt": PRIOR_RECEIPT, "qualification_plan_sha256": plan["qualification_plan_sha256"],
                "project_execution": False, "remote_execution": False, "network_access": False}
    write_exact("prepared-v2.json", c.json_bytes(prepared))
    print(json.dumps(prepared, indent=2))


if __name__ == "__main__":
    main()
