"""Reconstruct the frozen v2 source plan from retained v1; no project execution."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
raw=(ROOT/'source-plan.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='7a1a2dee75252fd0caa5360f1a30cb464a5b2aa2e43efffb15a1a155ab209b2c'
p=json.loads(raw)
p.update({'preparation_files': [{'path': 'a3-prep/contract.py', 'bytes': 9772, 'sha256': 'fce2a3bd69948819cc289a9f6de585650821d3649da1c91c78b0efd72e508541'}, {'path': 'a3-prep/source_v2.py', 'bytes': 14141, 'sha256': '01acaa1f744e1c7b4ace5f23da0078ebff00aa28ff07df5f72bea457b1ce3c87'}, {'path': 'a3-prep/check_evidence_v2.py', 'bytes': 14575, 'sha256': '812c6c86317bc06204063b2d6dab29c23b0556b34e75e3a7a0a9271680466b67'}, {'path': 'a3-prep/source.py', 'bytes': 12453, 'sha256': '980cf35d47e39076ab3675d5ab0f1b25535d53329198f637c2893c79de01d8f8'}, {'path': 'a3-prep/check_evidence.py', 'bytes': 13487, 'sha256': '8f1f4985d677c53f3c7e35c362eee1305cc72eecd72f6fdcc46c93d7a4f66f48'}, {'path': 'a3-prep/source-plan.json', 'bytes': 1747870, 'sha256': '7a1a2dee75252fd0caa5360f1a30cb464a5b2aa2e43efffb15a1a155ab209b2c'}], 'retained_archive': {'path': 'a3-prep/source-results/source.zip', 'bytes': 22469879, 'sha256': 'e4c4b4fe80673eb5cf93d0f752159564266514b14d03049bbf823fd935b2c089', 'url': 'https://codeload.github.com/applicate2628/mcp-local-hub/zip/65fea0b567a80f8793ccd417e9503c674e340f72'}, 'prior_attempt_receipt': {'path': 'a3-prep/source-results/receipt.json', 'bytes': 849, 'sha256': 'aadb195e39fcb3bfb3baba9ca87d85a9b75c5552198abf659675fcf6c2ab5aa1'}, 'prior_source_plan_sha256': '7a1a2dee75252fd0caa5360f1a30cb464a5b2aa2e43efffb15a1a155ab209b2c'})
result=(json.dumps(p,indent=2,ensure_ascii=False)+'\n').encode()
assert hashlib.sha256(result).hexdigest()=='f99660c7981f3f2c8f545fd75295878dbf3e6cc94dd4a79be182eb3aa7b1d9ab'
with (ROOT/'source-plan-v2.json').open('xb') as f:f.write(result)
print(json.dumps({'created':'source-plan-v2.json','bytes':len(result),'sha256':hashlib.sha256(result).hexdigest()}))
