# A3: exact source preparation and focused qualification plans

These files prepare a reviewable qualification of the three frozen client-install preference changes. **No Go command, remote command, installed Product, native scheduler operation, or publication was run while preparing them.** The parent agent owns admission and execution. The existing A1/A2 source, plans, and execution files are not modified by this preparation.

## Contents

1. [Source identity](#source-identity)
2. [Preparation and readback](#preparation-and-readback)
3. [Qualification order](#qualification-order)
4. [Test and negative-control meaning](#test-and-negative-control-meaning)
5. [Architecture evidence and baseline](#architecture-evidence-and-baseline)
6. [Files and limits](#files-and-limits)

## Source identity

The base is pull request #663 commit `65fea0b567a80f8793ccd417e9503c674e340f72`, Git tree `67991d80a424d61d2eecff9b72f7ca20ae31febb`: **3,283 regular `100644` files, 55,719,013 bytes**. `make_inputs.py` reads every full blob through local Git's `ls-tree` and `cat-file`, checks its Git object identifier, independently computes SHA-256, and reconstructs the tree hash. It reads no base bytes from the modified working tree.

The candidate replaces exactly these files with the frozen `inputs/a3/` bytes:

| File | SHA-256 |
|---|---|
| `internal/gui/client_install_prefs.go` | `6387fdb3a0a49619908543890b6140e91848d98da2722d84cf6d4261b0f1ec28` |
| `internal/gui/client_install_prefs_test.go` | `e5eb8abab621e9edffc799227e7d35402fb44425ad18a24dcc5064b3764957a1` |
| `internal/gui/server.go` | `e55eff0f90f83ba1376d20e38d1e34805b76a74340a8ebd1507947389d05e723` |

`prepared.json` records the computed candidate tree, complete inventory digests, transfer hash, and every plan hash. `source-plan.json` contains all base and candidate files with path, byte size, SHA-256, mode, and Git blob identifier. A candidate tree hash identifies physical content; it does not claim a new commit exists.

The remote root is exactly `D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba`. A fresh base goes into `architecture-base-source`; a fresh candidate goes into `architecture-source`. Neither destination is reused or overwritten.

## Preparation and readback

1. Review the scripts, source plan, control diff, and literal command arrays. Transfer `transfer.b64` through the existing pinned receiver using its full SHA-256 from `prepared.json`. The receiver creates only the listed new files; the already transferred `inputs/a3/` bytes are not sent again. No full source archive is transferred from this workspace.
2. On Comet, run **Python only**: `python a3-prep/source.py a3-prep/source-plan.json SOURCE_PLAN_SHA256`. Replace the final argument with the exact reviewed value in `prepared.json`.
3. `source.py` downloads only the immutable codeload ZIP for the pinned commit, inside the owned D-root. It rejects unexpected archive roots, paths, modes, duplicates, encryption, extra/missing files, size differences, and content differences. Before creating either source tree, it reconstructs the Git root from every ZIP blob and compares it with both the immutable Git tree and the full independent local inventory. It executes no subprocess or project code and installs nothing.
4. The script writes both fresh physical trees, reads every materialized file again, and produces `a3-prep/source-results/manifest.json` plus initial/final receipts. It derives full qualification manifests from those actual remote bytes in `a3-prep/remote-plans/`; every byte must match the independently prepared local plan hash.
5. Copy the source manifest, source receipts, and all four `remote-plans/` files back to an evidence export directory that mirrors their paths under the remote root. Run local Python: `python a3-prep/check_evidence.py source EXPORT_ROOT SOURCE_PLAN_SHA256`. **Do not begin project execution until this independent comparison passes.** The ZIP itself need not be copied back.

All preparation outputs are exclusive creations. On failure, scripts preserve the archive, partial source, and receipts for investigation; they neither erase nor overwrite them. Any later cleanup follows the user's trash-first rule after the files are confirmed unnecessary.

## Qualification order

The existing runner is used unchanged: `qualify_go.py`, SHA-256 `a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e`. It pins the already installed compiler, formatter, and C compiler, uses the existing D-drive module/build caches with downloads disabled, and redirects temporary/profile/state paths into the owned runtime. No installation or cache population from the network is authorized by these plans.

| Order | Plan | Purpose and exact outcome oracle |
|---|---|---|
| 1 | `a3-prep/format-control.json` | Format only the two new control files with the existing `format_inputs.py`; no candidate file is changed. |
| 2 | `a3-prep/remote-plans/a3-gui-independence.json` | Read-only formatting check; semantic control with one root, expected exit 1; candidate with all eight roots, expected exit 0. |
| 3 | `a3-prep/remote-plans/a3-base-architecture.json` | Actual unfiltered `archcheck scan` and `verify` on the fresh exact base. |
| 4 | `a3-prep/remote-plans/a3-candidate-architecture.json` | Actual unfiltered `archcheck scan` and `verify` on the fresh candidate with unchanged baseline. |
| Optional | `a3-prep/remote-plans/a3-build-vet-optional.json` | `go build ./...` and `go vet ./...`; does not launch built project executables. |

For step 1, the existing `format_inputs.py` hash is `9a94606db871d5102f76266119b9ad84e7aa5c8cc76f651d26d5bd37c02bb8a1`. Its result must retain the exact two byte/hash records in the reviewed format plan. If formatting changes bytes, stop: read them back, review, and regenerate all affected pins before qualification. The runner also checks all input hashes before and after every phase and performs a read-only formatting check before either test.

Each Go phase is invoked separately as `python qualify_go.py a3-prep/remote-plans/PLAN.json PLAN_SHA256`, using the exact matching hash in `prepared.json`. No script here starts these phases automatically. The architecture phases do not use overlays. The only overlay is the two-file GUI negative control; no API or command-line source from another head is substituted.

Copy the raw stdout/stderr logs, started/launched/command receipts, and phase receipts back with their original paths. `check_evidence.py tests`, `architecture`, or `all` checks the corresponding evidence, always including the source-manifest check. `optional` additionally admits the optional build/vet evidence. The checker compares raw stream hashes, argument arrays, working directories, original direct-child identifiers, exit codes, settled/no-timeout state, and complete source/input inventories before and after.

## Test and negative-control meaning

The candidate selection consists of exactly eight roots:

- `TestClientInstallPrefs_UsesServerAPI`
- `TestClientInstallPrefs_ServersKeepIndependentDependencies`
- `TestClientInstallPrefs_GetDefault`
- `TestClientInstallPrefs_PostPersistsAndReturnsSnapshot`
- `TestClientInstallPrefs_PostUnknownClientIs400`
- `TestClientInstallPrefs_PostEmptySetIs400`
- `TestClientInstallPrefs_MethodNotAllowed`
- `TestClientInstallPrefs_CrossOriginRejected`

Both commands use `-tags=test_state_path_env -race -count=1 -parallel=1 -timeout=180s -json` and anchored root selections. The first test checks that a newly constructed server retains its existing API. The remaining HTTP route tests inject each server's own in-memory preference dependency, preserving production route registration, method dispatch, validation mapping, same-origin protection, and POST readback. The two-server test interleaves reads and writes after both fake dependencies have been installed.

The control is **a semantic mutation representing shared dependency ownership, not a historical whole-head replay**. It adds one package variable containing the most recently constructed `*Server`, assigns it in the existing constructor, and redirects the three preference operations through that server. The compatible constructor, interface, test fixture, and every frozen assertion remain intact. Because the global points to the server, the fake installed by the test after construction remains the dependency actually called. The control neither creates an extra API nor reaches real preference storage.

Only `TestClientInstallPrefs_ServersKeepIndependentDependencies` runs under that overlay. Its exact required failures are:

| Subtest | Required diagnostic |
|---|---|
| `first_initial_read` | `selected=[vscode], want [cursor]` |
| `second_after_first_mutation` | `selected=[claude-code], want [vscode]` |
| `first_after_second_mutation` | `selected=[codex-cli], want [claude-code]` |

The other three subtests must pass. With parent and package events, the control requires exactly **3 PASS / 5 FAIL / 0 SKIP**. The candidate requires **15 PASS / 0 FAIL / 0 SKIP**: eight roots, six independence subtests, and the package. These are terminal-event totals, not fifteen independent scenarios. `check_evidence.py` requires every exact event once and rejects all skipped tests; a nonzero exit or a row-count failure alone cannot satisfy the control.

The existing GUI `TestMain` isolates state and client configuration roots and installs the fake scheduler/autostart dependencies. `newEphemeralServer` retains real route registration, disables unrelated event-log persistence, and closes its broadcaster at cleanup. The HTTP calls are in-process; they start no network listener or installed Product. The tests may use their isolated test directories; they do not establish that two production servers have separate on-disk settings. Production settings storage remains shared.

## Architecture evidence and baseline

The exact #663 base includes the previous qualification archive. Local preparation verifies that its 3,280 qualified source files match this base byte for byte; the only three additions are that qualification's report files. The previous raw scan and verification are anchored by the immutable base tree and their hashes. They support the following expected counters, but fresh base and candidate commands must still produce the same evidence.

| Counter | Fresh base expectation | Candidate expectation with unchanged baseline |
|---|---:|---:|
| All scan findings | 2660 | 2656 |
| New | 387 | 387 |
| Grown | 42 | 42 |
| Expired | 0 | 0 |
| Stale | 128 | 132 |
| Unowned | 0 | 0 |
| Workers | 72 | 72 |

Both `verify` commands are expected to exit 1: the global architecture gate remains **FAILED**. Expected failure satisfying a runner oracle is not a successful architecture gate. The raw six-counter summary is checked exactly, not inferred from the exit code.

The scan comparison requires exactly the four pinned `client_install_prefs.go` fingerprints to disappear: two mutable globals and two request-time `api.NewAPI` constructions. It rejects all new fingerprints and any additional removal. Every surviving finding must retain its semantics, with only the precise line-number shifts derived from unchanged source lines and the explicit `server.go` file-budget metric change **1265 → 1267**. That metric remains below its unchanged baseline maximum of 1406. Complete normalized report hashes bind these predictions; the raw JSON remains the evidence.

`architecture/baseline.yaml` stays byte-for-byte at SHA-256 `f7a7ad049c2e27b0df8fca68e1cb772909d3eed504fbb6ccf07ffdc0f0a0dd7a` throughout preparation and all supplied phases. No baseline-generation or baseline-edit command is supplied. Only after the actual two scans prove the exact four removals may the parent prepare a separately reviewed four-entry baseline change and a new full source inventory. No unrelated existing debt is accepted or removed here.

## Files and limits

- `contract.py`: pure constants, Git hashing, complete inventory hashing, exact test oracles, and plan construction.
- `make_inputs.py`: local Git blob inventory, frozen-input verification, two control files, expected plans, prior-evidence comparison, and transfer payload generation.
- `source.py`: Python-only immutable download, full verification, fresh materialization, complete remote readback, and plan derivation.
- `check_evidence.py`: independent local manifest comparison and strict raw-event/report verification. It executes nothing and writes nothing.
- `source-plan.json`, `plans/`, `format-control.json`, `prepared.json`: reviewable inputs, hashes, and literal command arrays.
- `inputs/a3-control/`: two control-only Go sources and their overlay map; none is a publication candidate.

The pinned runner enforces a deadline on each original direct child and retains unresolved process-tree state on timeout. It does not claim to independently prove descendant-tree settlement. Any timeout, unresolved child state, inventory mismatch, unexpected counter, skip, or unexpected test failure is a stop condition that preserves the evidence. Full native product behavior, real preference disk concurrency, all ordinary Go tests, performance, and publication remain outside these focused qualification plans.
