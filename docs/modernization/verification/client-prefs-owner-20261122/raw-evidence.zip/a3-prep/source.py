"""Windows preparation only: download exact source, verify, and write fresh trees.

This script launches no subprocess, runs no project code, installs nothing, and
does not modify an existing source directory. All written paths are in ROOT.
"""
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import time
import urllib.request
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
EXPECTED_RUNNER = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def own(relative):
    path = PurePosixPath(relative)
    if (not relative or path.is_absolute() or path.as_posix() != relative or
            any(part in (".", "..", ".git") for part in path.parts) or
            "\\" in relative or ":" in relative):
        raise ValueError("Invalid owned relative path")
    current = ROOT
    for part in (None, *path.parts):
        if part is not None:
            current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Reparse point in owned path")
    return current


def save(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
    return {"bytes": len(raw), "sha256": sha(raw)}


def check_pins(rows):
    for row in rows:
        raw = own(row["path"]).read_bytes()
        if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
            raise RuntimeError("Pinned preparation input changed: " + row["path"])


def read_inventory(directory, contract):
    rows = []
    def walk_error(error):
        raise error
    for parent, dirs, files in os.walk(own(directory), followlinks=False, onerror=walk_error):
        for name in dirs + files:
            own((Path(parent) / name).relative_to(ROOT).as_posix())
        for name in files:
            path = Path(parent) / name
            if not stat.S_ISREG(path.lstat().st_mode):
                raise RuntimeError("Non-regular materialized file")
            rows.append(contract.file_row(path.relative_to(own(directory)).as_posix(), path.read_bytes()))
    return sorted(rows, key=lambda row: row["path"])


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 3:
        raise RuntimeError("Use normal Python on the owned Windows host with the exact plan SHA256")
    for ancestor in (*reversed(ROOT.parents), ROOT):
        info = ancestor.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Owned root has a reparse ancestor")
    if Path(__file__).resolve() != own("a3-prep/source.py"):
        raise RuntimeError("Unexpected preparation script location")
    raw_plan = own(sys.argv[1]).read_bytes()
    if sha(raw_plan) != sys.argv[2]:
        raise RuntimeError("Preparation plan differs from the reviewed hash")
    plan = json.loads(raw_plan)
    if plan.get("schema") != 1 or plan.get("project_execution") is not False or plan.get("native_scheduler_operations") is not False:
        raise RuntimeError("Unadmitted preparation scope")
    if sha(own("qualify_go.py").read_bytes()) != EXPECTED_RUNNER:
        raise RuntimeError("Pinned qualification runner changed")
    check_pins(plan["preparation_files"] + plan["input_files"])
    spec = importlib.util.spec_from_file_location("a3_contract", own("a3-prep/contract.py"))
    c = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(c)
    if (plan["source_url"] != c.SOURCE_URL or plan["base_commit"] != c.BASE_COMMIT or
            plan["base_tree"] != c.BASE_TREE or plan["base_directory"] != c.BASE_DIRECTORY or
            plan["candidate_directory"] != c.CANDIDATE_DIRECTORY):
        raise RuntimeError("Wrong source identity or destinations")
    if c.tree_id(plan["base_files"]) != c.BASE_TREE or len(plan["base_files"]) != c.BASE_COUNT:
        raise RuntimeError("Invalid independently supplied base inventory")
    if sum(row["bytes"] for row in plan["base_files"]) != c.BASE_BYTES:
        raise RuntimeError("Base byte total differs")
    if c.tree_id(plan["candidate_files"]) != plan["candidate_tree"]:
        raise RuntimeError("Invalid independently supplied candidate inventory")
    for destination in (c.BASE_DIRECTORY, c.CANDIDATE_DIRECTORY, "a3-prep/remote-plans", "a3-prep/source-results"):
        if own(destination).exists():
            raise RuntimeError("Destination already exists; preserve and investigate: " + destination)
    out = own("a3-prep/source-results")
    out.mkdir()
    receipt = {"schema": 1, "plan_sha256": sha(raw_plan), "base_commit": c.BASE_COMMIT,
               "base_tree": c.BASE_TREE, "candidate_tree": plan["candidate_tree"],
               "project_execution": False, "native_scheduler_operations": False,
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "completed": False}
    save(out / "receipt-initial.json", receipt)
    try:
        archive = out / "source.zip"
        start = time.monotonic()
        request = urllib.request.Request(c.SOURCE_URL, headers={"User-Agent": "mcphub-exact-source-preparation", "Accept-Encoding": "identity"})
        with urllib.request.urlopen(request, timeout=30) as response, archive.open("xb") as stream:
            if response.status != 200 or response.geturl() != c.SOURCE_URL:
                raise RuntimeError("Immutable source response changed URL or status")
            total = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > 128 * 1024 * 1024 or time.monotonic() - start > 300:
                    raise RuntimeError("Source download exceeded its byte/time bound")
                stream.write(chunk)
        receipt["archive"] = {"path": "a3-prep/source-results/source.zip", "bytes": archive.stat().st_size,
                              "sha256": sha(archive.read_bytes()), "url": c.SOURCE_URL}
        expected = {row["path"]: row for row in plan["base_files"]}
        expected_dirs = {""}
        for name in expected:
            expected_dirs.update(str(p) for p in PurePosixPath(name).parents if str(p) != ".")
        contents = {}
        seen_archive = set()
        with zipfile.ZipFile(archive) as zipped:
            for info in zipped.infolist():
                if not info.filename.startswith(c.SOURCE_PREFIX) or info.flag_bits & 1:
                    raise RuntimeError("Archive prefix/encryption is not admitted")
                if info.filename in seen_archive:
                    raise RuntimeError("Duplicate ZIP entry")
                seen_archive.add(info.filename)
                name = info.filename[len(c.SOURCE_PREFIX):]
                mode = info.external_attr >> 16
                if info.is_dir():
                    name = name[:-1]
                    if name and c.safe_relative(name).as_posix() != name:
                        raise RuntimeError("Unclean archive directory")
                    if name not in expected_dirs or not stat.S_ISDIR(mode):
                        raise RuntimeError("Unadmitted archive directory")
                    continue
                c.safe_relative(name)
                if name not in expected or name in contents or mode != 0o100644:
                    raise RuntimeError("Unadmitted ZIP path or mode: " + name)
                if info.file_size != expected[name]["bytes"]:
                    raise RuntimeError("ZIP size differs from independently pinned blob")
                raw = zipped.read(info)
                if c.file_row(name, raw) != expected[name]:
                    raise RuntimeError("ZIP blob differs from local Git inventory: " + name)
                contents[name] = raw
        if set(contents) != set(expected):
            raise RuntimeError("ZIP file set differs from the exact Git tree")
        base_rows = [c.file_row(name, contents[name]) for name in sorted(contents)]
        reconstructed = c.tree_id(base_rows)
        if reconstructed != c.BASE_TREE or base_rows != plan["base_files"]:
            raise RuntimeError("ZIP's reconstructed Git root differs")
        receipt["zip_reconstructed_git_tree"] = reconstructed
        receipt["zip_inventory"] = c.inventory_summary(base_rows)
        # All archive bytes and the reconstructed Git root are validated before
        # either source tree is created. No project command is part of this script.
        replacements = {}
        for name in c.FILES:
            replacements[name] = own("inputs/a3/" + name).read_bytes()
        candidate_rows = [c.file_row(name, replacements.get(name, contents[name])) for name in sorted(contents)]
        if candidate_rows != plan["candidate_files"] or c.tree_id(candidate_rows) != plan["candidate_tree"]:
            raise RuntimeError("Candidate differs from exactly three frozen replacements")
        baseline = "architecture/baseline.yaml"
        if sha(contents[baseline]) != c.BASELINE_SHA or baseline in replacements:
            raise RuntimeError("Architecture baseline is not the frozen base")
        for directory, replacement in ((c.BASE_DIRECTORY, {}), (c.CANDIDATE_DIRECTORY, replacements)):
            own(directory).mkdir()
            for name in sorted(contents):
                target = own(directory + "/" + name)
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as stream:
                    stream.write(replacement.get(name, contents[name]))
        actual_base = read_inventory(c.BASE_DIRECTORY, c)
        actual_candidate = read_inventory(c.CANDIDATE_DIRECTORY, c)
        if actual_base != base_rows or actual_candidate != candidate_rows:
            raise RuntimeError("Materialized source readback differs")
        actual_inputs = []
        for row in plan["input_files"]:
            actual_inputs.append(c.file_row(row["path"][len("inputs/"):], own(row["path"]).read_bytes()))
        plans = c.qualification_plans(actual_base, actual_candidate, actual_inputs)
        plan_dir = own("a3-prep/remote-plans")
        plan_dir.mkdir()
        actual_plan_pins = {}
        for name, value in plans.items():
            raw = c.json_bytes(value)
            if sha(raw) != plan["qualification_plan_sha256"][name]:
                raise RuntimeError("Plan derived from remote bytes differs from local reviewed plan")
            with (plan_dir / name).open("xb") as stream:
                stream.write(raw)
            actual_plan_pins[name] = sha(raw)
        manifest = {"schema": 1, "base_commit": c.BASE_COMMIT,
                    "base_directory": c.BASE_DIRECTORY, "base_tree": c.tree_id(actual_base), "base_files": actual_base,
                    "candidate_directory": c.CANDIDATE_DIRECTORY, "candidate_tree": c.tree_id(actual_candidate),
                    "candidate_files": actual_candidate, "input_files": actual_inputs,
                    "qualification_plan_sha256": actual_plan_pins}
        receipt["manifest"] = save(out / "manifest.json", manifest)
        receipt["base_readback"] = c.inventory_summary(actual_base)
        receipt["candidate_readback"] = c.inventory_summary(actual_candidate)
        check_pins(plan["preparation_files"] + plan["input_files"])
        if sha(own("qualify_go.py").read_bytes()) != EXPECTED_RUNNER:
            raise RuntimeError("Qualification runner changed during source preparation")
        if sha(own(sys.argv[1]).read_bytes()) != receipt["plan_sha256"]:
            raise RuntimeError("Preparation plan changed during materialization")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / "receipt.json", receipt)
        print(json.dumps({key: receipt.get(key) for key in ("completed", "base_tree", "candidate_tree", "base_readback", "candidate_readback", "error")}), flush=True)


if __name__ == "__main__":
    main()
