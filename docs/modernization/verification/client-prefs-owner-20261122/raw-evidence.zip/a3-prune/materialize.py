"""Materialize only the reviewed four-entry baseline change in a fresh source."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,importlib.util,json,os
ROOT=Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def module(name,path,digest):
    assert sha(path.read_bytes())==digest
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value
assert os.name=='nt' and not sys.flags.optimize and len(sys.argv)==2
assert Path(__file__).resolve()==ROOT/'a3-prune/materialize.py'
assert sha(Path(__file__).read_bytes())==sys.argv[1]
q=module('qualification',ROOT/'qualify_go.py','a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e')
c=module('a3contract',q.own('a3-prep/contract.py'),'fce2a3bd69948819cc289a9f6de585650821d3649da1c91c78b0efd72e508541')
pruner=module('a3prune',q.own('a3-prune/prune.py'),'aaee5be8ef622cc387d99aa88b11c4cb1138e409ae7b6ba4299959c1d06ee567')
raw=q.own('a3-prep/source-plan-v2.json').read_bytes();assert sha(raw)=='f99660c7981f3f2c8f545fd75295878dbf3e6cc94dd4a79be182eb3aa7b1d9ab'
source_plan=json.loads(raw)
raw=q.own('a3-prep/remote-plans/a3-candidate-architecture.json').read_bytes();assert sha(raw)=='23ee34cdb9583b68afe8d8d5df11a222ac274b6297eb9325fdf9aebdfea0938f'
old_plan=json.loads(raw)
for relative in ['architecture-final-source','a3-prune/receipt-initial.json','a3-prune/receipt.json','a3-prune/qualification-plan.json']:
    assert not q.own(relative).exists(),relative
receipt={'schema':1,'started_utc':q.now(),'completed':False,'project_execution':False,'native_scheduler_operations':False,'script_sha256':sys.argv[1]}
q.save(q.own('a3-prune/receipt-initial.json'),receipt)
try:
    receipt['source_before']=q.check_files('architecture-source',old_plan['source_files'],True)
    receipt['inputs_before']=q.check_files('inputs',old_plan['input_files'])
    old=q.own('architecture-source/architecture/baseline.yaml').read_bytes()
    new,removed=pruner.prune(old)
    assert sha(new)=='5b856cb5d791a2edd9cf8af861533a8537b274c79efdd369aaf16ac97b254ae2'
    assert sorted(removed)==sorted(c.REMOVED)
    rows=[c.file_row(row['path'],new) if row['path']=='architecture/baseline.yaml' else row for row in source_plan['candidate_files']]
    tree=c.tree_id(rows);assert tree=='d398dc284d85722bc3ffafa5eaafdacf88eaf8c4'
    commands=[dict(old_plan['commands'][1])]
    commands[0]['required_output']=[c.verification_line(c.BASE_COUNTERS)]
    commands.extend({'label':verb,'tool':'go','args':[verb,'./...'],'timeout_seconds':900,'expected_exit_code':0} for verb in ['build','vet'])
    plan={**old_plan,'phase':'a3-pruned-architecture','source_directory':'architecture-final-source','source_tree':tree,
          'source_files':[{k:row[k] for k in ['path','bytes','sha256']} for row in rows],'commands':commands}
    plan_raw=c.json_bytes(plan);assert sha(plan_raw)=='e8b693645a6fe9023eadc505a6070e12ef8eed5f2ca008cd6aa7efe9a81c9b72'
    q.own('architecture-final-source').mkdir()
    by_name={row['path']:row for row in source_plan['candidate_files']}
    for row in rows:
        name=row['path'];data=q.own('architecture-source/'+name).read_bytes();prior=by_name[name]
        assert len(data)==prior['bytes'] and sha(data)==prior['sha256']
        if name=='architecture/baseline.yaml':data=new
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
        target=q.own('architecture-final-source/'+name);target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(data)
    receipt['final_source']=q.check_files('architecture-final-source',plan['source_files'],True)
    assert receipt['final_source']==c.inventory_summary(rows)
    receipt['source_after']=q.check_files('architecture-source',old_plan['source_files'],True)
    receipt['inputs_after']=q.check_files('inputs',old_plan['input_files'])
    assert receipt['source_before']==receipt['source_after'] and receipt['inputs_before']==receipt['inputs_after']
    with q.own('a3-prune/qualification-plan.json').open('xb') as f:f.write(plan_raw)
    receipt.update(source_tree=tree,plan_sha256=sha(plan_raw),baseline_before_sha256=sha(old),baseline_after_sha256=sha(new),
                   entries_before=2401,entries_after=2397,removed_fingerprints=sorted(removed),unrelated_blocks_preserved=True,completed=True)
except BaseException as error:
    receipt.update(error_type=type(error).__name__,error=str(error));raise
finally:
    receipt['finished_utc']=q.now();q.save(q.own('a3-prune/receipt.json'),receipt);print(json.dumps(receipt),flush=True)
