"""Remove only the four entries proved absent by both actual architecture scans."""
import hashlib,re
OLD_SHA = 'f7a7ad049c2e27b0df8fca68e1cb772909d3eed504fbb6ccf07ffdc0f0a0dd7a'
FINGERPRINTS = ['24d9c30a73077273cecb80e7e46f46eb1e787d5d4579b9e25488b8f661056a9d', '2b533332b231b11e1941ec5d908bd5b5961849a9243135a0d222411590c436fd', '3c49a37917a4fa67c001fbf39954303f9f54f3ea27af7c6ae38d8180b4198846', 'bc262b12501bc20b069a110fa95df448fe5019a08dd3daa01959b28664eb9c15']
def prune(raw):
    assert hashlib.sha256(raw).hexdigest()==OLD_SHA
    matches=list(re.finditer(rb'(?m)^    - fingerprint: ([0-9a-f]{64})\n',raw))
    assert len(matches)==2401 and len({m[1] for m in matches})==2401
    prefix=raw[:matches[0].start()]
    assert prefix==b'schema_version: 1\ngenerated_from: 1b875e3ad9f0ca7d4bc306edb6c22431b66da6c7\nentries:\n'
    kept=[];removed={}
    for i,m in enumerate(matches):
        block=raw[m.start():matches[i+1].start() if i+1<len(matches) else len(raw)]
        key=m[1].decode()
        if key in FINGERPRINTS:
            assert b'        path: internal/gui/client_install_prefs.go\n' in block
            removed[key]=block
        else:kept.append(block)
    assert sorted(removed)==FINGERPRINTS and len(kept)==2397
    return prefix+b''.join(kept),removed
