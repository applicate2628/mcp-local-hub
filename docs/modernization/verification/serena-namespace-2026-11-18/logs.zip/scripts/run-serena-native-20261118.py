"""Exact-source Serena lifetime verification and bounded telemetry reproduction."""
import ctypes, datetime, hashlib, json, os, pathlib, re, subprocess, sys, time
from ctypes import wintypes as wt

BASE = pathlib.Path(r"D:\dev\ChatGPT")
TASK = BASE / "serena-review-20261118"
REPO = BASE / "mcp-local-hub-pr637-review-20261117"
COMMIT = "84615d465c54d52588ac17c37174d68096d0da90"
GO = r"C:\msys64\ucrt64\bin\go.exe"
GOROOT = r"C:\msys64\ucrt64\lib\go"
GIT = r"C:\Program Files\Git\cmd\git.exe"
CACHE = BASE / "mcp-pr616-qualification-20261114"
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
adv = ctypes.WinDLL("advapi32", use_last_error=True)
PVOID = ctypes.c_void_p
k32.GetCurrentProcess.restype = wt.HANDLE
k32.CloseHandle.argtypes, k32.CloseHandle.restype = [wt.HANDLE], wt.BOOL
k32.LocalFree.argtypes, k32.LocalFree.restype = [PVOID], PVOID
k32.GetFileAttributesW.argtypes, k32.GetFileAttributesW.restype = [wt.LPCWSTR], wt.DWORD
adv.OpenProcessToken.argtypes = [wt.HANDLE, wt.DWORD, ctypes.POINTER(wt.HANDLE)]
adv.OpenProcessToken.restype = wt.BOOL
adv.GetTokenInformation.argtypes = [wt.HANDLE, wt.DWORD, PVOID, wt.DWORD, ctypes.POINTER(wt.DWORD)]
adv.GetTokenInformation.restype = wt.BOOL
adv.ConvertSidToStringSidW.argtypes = [PVOID, ctypes.POINTER(wt.LPWSTR)]
adv.ConvertSidToStringSidW.restype = wt.BOOL
adv.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [wt.LPCWSTR, wt.DWORD, ctypes.POINTER(PVOID), ctypes.POINTER(wt.DWORD)]
adv.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype = wt.BOOL
adv.GetNamedSecurityInfoW.argtypes = [wt.LPWSTR, wt.DWORD, wt.DWORD, ctypes.POINTER(PVOID), ctypes.POINTER(PVOID), ctypes.POINTER(PVOID), ctypes.POINTER(PVOID), ctypes.POINTER(PVOID)]
adv.GetNamedSecurityInfoW.restype = wt.DWORD
adv.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes = [PVOID, wt.DWORD, wt.DWORD, ctypes.POINTER(wt.LPWSTR), ctypes.POINTER(wt.DWORD)]
adv.ConvertSecurityDescriptorToStringSecurityDescriptorW.restype = wt.BOOL
class SECURITY_ATTRIBUTES(ctypes.Structure):
    _fields_ = [("nLength", wt.DWORD), ("lpSecurityDescriptor", PVOID), ("bInheritHandle", wt.BOOL)]
k32.CreateDirectoryW.argtypes = [wt.LPCWSTR, ctypes.POINTER(SECURITY_ATTRIBUTES)]
k32.CreateDirectoryW.restype = wt.BOOL
def checked(ok):
    if not ok:
        raise ctypes.WinError(ctypes.get_last_error())
def free(pointer):
    if k32.LocalFree(ctypes.cast(pointer, PVOID)):
        raise ctypes.WinError(ctypes.get_last_error())
token = wt.HANDLE()
checked(adv.OpenProcessToken(k32.GetCurrentProcess(), 0x0008, ctypes.byref(token)))
try:
    size = wt.DWORD()
    adv.GetTokenInformation(token, 1, None, 0, ctypes.byref(size))
    assert ctypes.get_last_error() == 122 and size.value
    user = ctypes.create_string_buffer(size.value)
    checked(adv.GetTokenInformation(token, 1, user, size, ctypes.byref(size)))
    sid_text = wt.LPWSTR()
    checked(adv.ConvertSidToStringSidW(ctypes.cast(user, ctypes.POINTER(PVOID))[0], ctypes.byref(sid_text)))
    try:
        sid = sid_text.value
    finally:
        free(sid_text)
finally:
    checked(k32.CloseHandle(token))
def private_root(path):
    assert path.is_relative_to(BASE) and not path.exists() and not path.is_symlink()
    for ancestor in reversed([path.parent, *path.parent.parents]):
        attrs = k32.GetFileAttributesW(str(ancestor))
        assert attrs != 0xFFFFFFFF and attrs & 0x10 and not attrs & 0x400, str(ancestor)
    sddl = f"O:{sid}D:P(A;OICI;FA;;;{sid})(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)"
    descriptor = PVOID()
    checked(adv.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl, 1, ctypes.byref(descriptor), None))
    try:
        sa = SECURITY_ATTRIBUTES(ctypes.sizeof(SECURITY_ATTRIBUTES), descriptor, False)
        checked(k32.CreateDirectoryW(str(path), ctypes.byref(sa)))
    finally:
        free(descriptor)
    actual, actual_text = PVOID(), wt.LPWSTR()
    err = adv.GetNamedSecurityInfoW(str(path), 1, 5, None, None, None, None, ctypes.byref(actual))
    if err:
        raise ctypes.WinError(err)
    try:
        checked(adv.ConvertSecurityDescriptorToStringSecurityDescriptorW(actual, 1, 5, ctypes.byref(actual_text), None))
        observed = actual_text.value
    finally:
        if actual_text:
            free(actual_text)
        free(actual)
    assert observed.startswith(f"O:{sid}D:P")
    assert set(re.findall(r"\([^)]*\)", observed)) == {f"(A;OICI;FA;;;{sid})", "(A;OICI;FA;;;SY)", "(A;OICI;FA;;;BA)"}
    return {"path":str(path), "sddl":observed, "ancestor_reparse_points":False}
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
def write_json(path, value):
    path.write_bytes((json.dumps(value, indent=2) + "\n").encode("utf-8"))

task_policy = private_root(TASK)
BOOT = TASK / "bootstrap"
BOOT.mkdir()
for leaf in ("temp", "home", "appdata", "localappdata", "gopath"):
    (BOOT / leaf).mkdir()
OUT = TASK / "evidence"
OUT.mkdir()
env = {key:value for key,value in os.environ.items() if key.upper() in
       {"SYSTEMROOT", "WINDIR", "COMSPEC", "SYSTEMDRIVE", "PROCESSOR_ARCHITECTURE", "NUMBER_OF_PROCESSORS"}}
env.update({
 "PATH":r"C:\msys64\ucrt64\bin;C:\Program Files\Git\cmd;C:\Windows\System32;C:\Windows",
 "PATHEXT":".COM;.EXE;.BAT;.CMD", "GOROOT":GOROOT,
 "GOCACHE":str(CACHE/"gocache"), "GOMODCACHE":str(CACHE/"gomodcache"), "GOPATH":str(BOOT/"gopath"),
 "GOENV":"off", "GOTOOLCHAIN":"local", "GOWORK":"off", "GOFLAGS":"", "GO111MODULE":"on",
 "GOPROXY":"off", "GOSUMDB":"off", "GOVCS":"*:off", "GOAUTH":"off",
 "GOPRIVATE":"", "GONOPROXY":"none", "GONOSUMDB":"none",
 "CGO_ENABLED":"0", "GOOS":"windows", "GOARCH":"amd64", "GOAMD64":"v1", "GOEXPERIMENT":"", "GOFIPS140":"off",
 "GOCACHEPROG":"", "GOMAXPROCS":"4", "TEST_TELEMETRY_DIR":"", "GO_TELEMETRY_CHILD":"", "GO_TELEMETRY_CHILD_UPLOAD":"",
 "HOME":str(BOOT/"home"), "USERPROFILE":str(BOOT/"home"),
 "APPDATA":str(BOOT/"appdata"), "LOCALAPPDATA":str(BOOT/"localappdata"),
 "GIT_CONFIG_NOSYSTEM":"1", "GIT_CONFIG_GLOBAL":os.devnull, "PYTHONDONTWRITEBYTECODE":"1",
})
for key in ("TEMP", "TMP", "TMPDIR", "GOTMPDIR"):
    env[key] = str(BOOT/"temp")
receipt = {"schema":"serena-exact-source-review-v1", "source_commit":COMMIT, "stages":[],
           "task_policy":task_policy, "windows":list(sys.getwindowsversion()[:3]), "installs_executed":False,
           "integration_performed":False, "positive_preparation_tests_executed":False}
def save():
    write_json(OUT/"receipt.json", receipt)
def git(*args):
    return subprocess.check_output([GIT, "-C", str(REPO), *args], env=env, text=True, timeout=30).strip()
def run(name, argv, child_env=None, cwd=None, timeout=300):
    print("START", name, flush=True)
    started = time.perf_counter()
    item = {"name":name, "argv":argv, "cwd":str(cwd or REPO),
            "started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(), "timeout_seconds":timeout}
    stdout, stderr = OUT/(name+".stdout.log"), OUT/(name+".stderr.log")
    try:
        with stdout.open("xb") as fo, stderr.open("xb") as fe:
            result = subprocess.run(argv, cwd=cwd or REPO, env=child_env or env,
                                    stdout=fo, stderr=fe, timeout=timeout, check=False)
        item["exit_code"] = result.returncode
    except subprocess.TimeoutExpired:
        item["exit_code"], item["wrapper_timeout"] = None, True
    item["wall_seconds"] = round(time.perf_counter()-started, 3)
    for stream in (stdout, stderr):
        item[stream.name] = {"bytes":stream.stat().st_size, "sha256":sha(stream)}
    receipt["stages"].append(item)
    save()
    print("END", name, "exit", item["exit_code"], "seconds", item["wall_seconds"], flush=True)
    assert item["exit_code"] == 0, name
    return stdout.read_text(encoding="utf-8")
assert git("rev-parse", "HEAD") == COMMIT
assert not git("status", "--porcelain=v1", "--untracked-files=all")
receipt["source_clean_before"] = True
save()

# Only owned sibling directories are used. The before run suppresses the telemetry
# sidecar with GO_TELEMETRY_CHILD=2 and mode=local; it cannot enable uploads.
probe = TASK/"telemetry-probe"
probe.mkdir()
probes = {}
for name, sanitized in (("before", False), ("after", True)):
    root = probe/name
    root.mkdir()
    external, private_app = root/"external", root/"work"/"appdata"
    external.mkdir()
    private_app.mkdir(parents=True)
    (external/"mode").write_bytes(b"local")
    child = dict(env)
    child["APPDATA"] = str(private_app)
    child["LOCALAPPDATA"] = str(root/"work"/"localappdata")
    pathlib.Path(child["LOCALAPPDATA"]).mkdir()
    child["TEST_TELEMETRY_DIR"] = "" if sanitized else str(external)
    child["GO_TELEMETRY_CHILD"] = "" if sanitized else "2"
    child["GO_TELEMETRY_CHILD_UPLOAD"] = ""
    run("telemetry-"+name+"-off", [GO,"telemetry","off"], child, root, 30)
    version = run("telemetry-"+name+"-version", [GO,"version"], child, root, 30)
    external_files = sorted(str(p.relative_to(external)) for p in external.rglob("*") if p.is_file())
    local_mode = private_app/"go"/"telemetry"/"mode"
    assert local_mode.read_text().strip().startswith("off")
    assert (external/"mode").read_text() == "local"
    counts = [p for p in external.rglob("*.count") if p.is_file()]
    assert bool(counts) is (not sanitized), (name, external_files)
    probes[name] = {"external_files":external_files, "counter_count":len(counts), "private_mode":local_mode.read_text(),
                    "version":version.strip(), "external_mode":"local", "sidecar_suppressed":not sanitized}
receipt["telemetry_probe"] = probes
write_json(OUT/"telemetry-probe.json", probes)
save()

run("private-telemetry-off", [GO,"telemetry","off"], timeout=30)
builder = BOOT/"test-serena-publisher.exe"
run("compile-builder", [GO,"build","-mod=readonly","-buildvcs=false","-trimpath","-o",str(builder),"./tools/test-serena-publisher"], timeout=300)
PUB = TASK/"publisher"
run("source-issued-build", [str(builder),"--checkout",str(REPO),"--expected-commit",COMMIT,
    "--go",GO,"--go-root",GOROOT,"--module-cache",str(CACHE/"gomodcache"),"--work-root",str(PUB),"--timeout","10m"], timeout=660)
proof = json.loads((PUB/"proof"/"publisher.json").read_bytes())
source = json.loads((PUB/"proof"/"source-preparation.json").read_bytes())
image = PUB/"bin"/"serena-qualification.test.exe"
assert proof["commit"] == COMMIT and proof["role"] == "serena-qualification"
assert proof["ordinary_product_admission"] is False and proof["tests_executed"] is False
assert proof["retained_input_handles_closed"] is True and proof["sha256"] == sha(image)
assert source["git_commit"] == COMMIT and source["dirty_selected_source"] is False
assert source["source_input"]["source_epoch"] == proof["source_input"]["source_epoch"]
stage_proofs = {}
for name in ("private-telemetry-off","go-version","version-resource","compile"):
    stage = json.loads((PUB/"proof"/(name+".settlement.json")).read_bytes())
    assert stage["process_and_io_complete"] is True and stage["root_wait_known"] is True
    assert stage["exit_code"] == 0 and not stage["failure"]
    stage_proofs[name] = stage
receipt["publisher"] = proof
receipt["publisher_stage_proofs"] = stage_proofs
save()

RUN = TASK/"run"
run_policy = private_root(RUN)
for leaf in ("temp","home","appdata","localappdata"):
    (RUN/leaf).mkdir()
run_env = dict(env)
for key in ("TEMP","TMP","TMPDIR","GOTMPDIR"):
    run_env[key] = str(RUN/"temp")
run_env.update({"HOME":str(RUN/"home"), "USERPROFILE":str(RUN/"home"),
 "APPDATA":str(RUN/"appdata"), "LOCALAPPDATA":str(RUN/"localappdata"),
 "MCPHUB_SERENA_QUALIFICATION_RUN_ROOT":str(RUN), "MCPHUB_E2E_SCHEDULER":"none"})
receipt["run_policy"] = run_policy
receipt["qualification_image_sha256_before"] = sha(image)
save()
raw = run("namespace-lifetime", [str(image),"-test.v","-test.count=1","-test.parallel=1",
        "-test.timeout=3m","-test.run=^TestSerenaQualificationNamespaceLifetime$"], run_env, RUN, 210)
passed = re.findall(r"(?m)^\s*--- PASS: ([^ ]+) ", raw)
expected = {
 "TestSerenaQualificationNamespaceLifetime",
 "TestSerenaQualificationNamespaceLifetime/MCPHUB_STATE_DIR_OVERRIDE",
 "TestSerenaQualificationNamespaceLifetime/MCPHUB_SERENA_QUALIFICATION_RUN_ROOT",
 "TestSerenaQualificationNamespaceLifetime/in-memory_state_root",
 "TestSerenaQualificationNamespaceLifetime/canceled_request",
}
assert set(passed) == expected and len(passed) == 5, passed
assert "--- FAIL:" not in raw and "--- SKIP:" not in raw and re.search(r"(?m)^PASS\r?$", raw)
receipt["namespace_tests"] = {"pass_count":5, "names":passed, "fail_count":0, "skip_count":0}
receipt["source_clean_after"] = not git("status","--porcelain=v1","--untracked-files=all")
receipt["source_head_after"] = git("rev-parse","HEAD")
receipt["qualification_image_sha256_after"] = sha(image)
assert receipt["source_clean_after"] and receipt["source_head_after"] == COMMIT
assert receipt["qualification_image_sha256_after"] == proof["sha256"]
receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({"source_commit":COMMIT, "image_sha256":proof["sha256"], "namespace_tests":receipt["namespace_tests"],
                  "telemetry_before_count":probes["before"]["counter_count"], "telemetry_after_count":probes["after"]["counter_count"]}), flush=True)
