"""Task-local offline verification; no install or native scheduler operations."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-continuation-20261122-e51f")
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
SOURCE_CACHE = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\arch-input\source-arch")
HEAD = "1cabce12655f810b742e6c31369441cacd72573c"
TREE = "8eed2215a72d8f56164afa562e277dd5ae387f28"
EXPECTED = {
    "architecture/baseline.yaml": "e0620345b7999fdb97462172d20226255e3397345078e98178098ddcd082632c",
    "internal/gui/server.go": "edcffcc94cb1078801d1329e04e1e98824527f5c9eb080fcdb20560675131325",
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def guarded(path):
    parts = path.relative_to(ROOT).parts
    current = ROOT
    for part in (None, *parts):
        if part is not None:
            current = current / part
        if current.exists():
            info = current.lstat()
            if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Task path contains a reparse point")
    return path

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Unexpected execution root")
    phase = sys.argv[1]
    if phase not in {"prepare-architecture", "architecture"}:
        raise ValueError("Unknown phase")
    evidence = guarded(ROOT / "evidence" / phase)
    evidence.mkdir(parents=True, exist_ok=False)
    runtime = guarded(ROOT / "runtime" / phase)
    runtime.mkdir(parents=True, exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "xdg-config", "xdg-cache", "xdg-data"):
        (runtime / name).mkdir()
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_"))}
    env.update({
        "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
        "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off",
        "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "GOMAXPROCS": "4", "CGO_ENABLED": "1",
        "GOCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gocache",
        "GOMODCACHE": r"D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache",
        "GOPATH": str(runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")),
        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
        "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"),
        "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
        "XDG_CONFIG_HOME": str(runtime / "xdg-config"), "XDG_CACHE_HOME": str(runtime / "xdg-cache"),
        "XDG_DATA_HOME": str(runtime / "xdg-data"), "MCPHUB_NO_AUTO_GUI": "1",
        "MCPHUB_E2E_SCHEDULER": "none", "PYTHONDONTWRITEBYTECODE": "1",
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"),
        "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never",
    })
    env["PATH"] = str(GO.parent) + os.pathsep + env.get("PATH", "")
    for path in (GO, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOMODCACHE"]), Path(env["GOCACHE"])):
        if not path.exists():
            raise RuntimeError("Required pre-existing tool/cache missing: " + str(path))
    receipt = {"phase": phase, "source_head": HEAD, "source_tree": TREE, "commands": [],
               "runner_sha256": digest(Path(__file__)), "go_sha256": digest(GO),
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "native_scheduler_operations": False, "installed_product_operations": False,
               "dependency_downloads": False, "completed": False}
    receipt_path = evidence / "receipt.json"
    def save():
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    def run(label, args, cwd, expected=0, timeout=180):
        item = {"label": label, "args": list(map(str, args)), "expected_exit": expected,
                "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        receipt["commands"].append(item)
        save()
        started = time.monotonic()
        out = evidence / (label + ".stdout")
        err = evidence / (label + ".stderr")
        try:
            with out.open("xb") as stdout, err.open("xb") as stderr:
                completed = subprocess.run(list(map(str, args)), cwd=cwd, env=env,
                                           stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                           timeout=timeout, check=False)
            item["exit_code"] = completed.returncode
            item["direct_child_waited"] = True
        except subprocess.TimeoutExpired:
            item["timed_out"] = True
            item["direct_child_waited"] = True
            item["descendant_settlement"] = "not_established; retain task workspace"
            raise
        finally:
            item["seconds"] = round(time.monotonic() - started, 3)
            for key, path in (("stdout", out), ("stderr", err)):
                if path.exists():
                    item[key] = {"bytes": path.stat().st_size, "sha256": digest(path)}
            save()
        print(json.dumps({"label": label, "exit_code": completed.returncode, "seconds": item["seconds"]}), flush=True)
        if completed.returncode != expected:
            raise RuntimeError("Unexpected exit for " + label)
        return out.read_bytes()
    source = guarded(ROOT / "architecture")
    try:
        version = run("go-version", [GO, "version"], ROOT).decode().strip()
        if version != "go version go1.27.4 windows/amd64":
            raise RuntimeError("Unexpected Go version")
        if phase == "prepare-architecture":
            if source.exists():
                raise RuntimeError("Source already exists")
            run("clone-cache", [GIT, "-c", "core.autocrlf=false", "clone", "--no-hardlinks", "--no-checkout", SOURCE_CACHE, source], ROOT)
            run("set-source-remote", [GIT, "remote", "set-url", "origin", "https://github.com/applicate2628/mcp-local-hub.git"], source)
            run("fetch-source", [GIT, "fetch", "--no-tags", "--refetch", "origin", HEAD], source, timeout=600)
            run("checkout-source", [GIT, "-c", "core.autocrlf=false", "checkout", "--detach", HEAD], source)
            tree = run("source-tree", [GIT, "rev-parse", "HEAD^{tree}"], source).decode().strip()
            if tree != TREE or run("source-clean", [GIT, "status", "--porcelain"], source).strip():
                raise RuntimeError("Source identity mismatch")
            patch = ROOT / "architecture.patch"
            if digest(patch) != "349cb21b1789055c62e623015be0e1e154ff3eba803749d4bf547f28b7e3d971":
                raise RuntimeError("Patch identity mismatch")
            run("apply-check", [GIT, "apply", "--check", patch], source)
            run("apply", [GIT, "apply", patch], source)
        for relative, expected in EXPECTED.items():
            if digest(source / relative) != expected:
                raise RuntimeError("Candidate identity mismatch: " + relative)
        receipt["candidate_sha256"] = EXPECTED
        if phase == "architecture":
            formatted = run("format", [GO.with_name("gofmt.exe"), "-l", "internal/gui/server.go"], source)
            if formatted.strip():
                raise RuntimeError("Formatting differs")
            selected = r"^(TestManifest.*|TestReadinessHandler_DraftPOST_(CreateModeExistingManifestBlocks|EditTargetExistingManifestDoesNotBlock|EditTargetMissingManifestBlocks|MirrorsManifestWriteGate)|TestMarketplaceInstall_Hub(HappyPath|EmbeddedNameCollisionGraceful|RetryableManifestLeaseConflict409))$"
            run("gui-focused", [GO, "test", "-json", "-race", "-count=1", "-timeout=90s", "-parallel=1", "-run", selected, "./internal/gui"], source, timeout=240)
            run("archcheck-build", [GO, "build", "-o", runtime / "archcheck.exe", "./tools/archcheck"], source)
            common = ["--root", source, "--policy", source / "architecture/policy.yaml"]
            run("arch-scan", [runtime / "archcheck.exe", "scan", *common], source)
            run("arch-verify", [runtime / "archcheck.exe", "verify", *common, "--owners", source / "architecture/owners.yaml", "--baseline", source / "architecture/baseline.yaml", "--workers", source / "architecture/workers.yaml"], source, expected=1)
            run("build", [GO, "build", "./..."], source, timeout=240)
            run("vet", [GO, "vet", "./..."], source, timeout=240)
            for relative, expected in EXPECTED.items():
                if digest(source / relative) != expected:
                    raise RuntimeError("Candidate changed during verification")
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()

if __name__ == "__main__":
    main()
