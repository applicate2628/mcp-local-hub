"""Preserve completed architecture evidence; no execution of repository code."""
import base64
import collections
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-continuation-20261122-e51f")
ABSENT = [
    "c68604a1a100ec4a66f31c53660c3cf424d50412c383d8398a3ca9e296ef6666",
    "8a177f66eab2784270b7c113f4d1f0b00542b471d38ea1266f2abb0a0d848a7d",
    "f5b25fba0b9f9d9446daad4ff897e9dab5bb4afab4482262483840bc08d98926",
    "6842ac72d8e1be0944e78e5d14aa1e76a7f0aacda6a20b9696989a121a2aff6d",
    "bae8c75bbf3a838740cd10b9043bdf6da334baff95d4d34d81dcf6f5c6e8aa68",
    "66aa2c139d7a9a8f63aeb09863c60706eba8cf8eea8d13a6c5629c2a3210c485",
    "beb70d485bbe7b0e16fc31b848e2dfd634eae4e0a921e4304c9b7bfd24a1eeb2",
    "897b89e0a0d3cf60c83a5bf06e046b6724864b70ebd6290ba44116c4afde348f",
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(relative):
    path = ROOT / relative
    current = ROOT
    for part in (None, *path.relative_to(ROOT).parts):
        if part is not None:
            current = current / part
        stat = current.lstat()
        if current.is_symlink() or getattr(stat, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Evidence path contains a reparse point")
    return path.read_bytes()


def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Unexpected execution root")
    files = {name: read(name) for name in ("qualify.py", "recover_architecture.py", "export_architecture.py", "architecture.patch")}
    receipts = {}
    for phase in ("prepare-architecture", "recover-architecture-1", "architecture"):
        prefix = "evidence/" + phase + "/"
        files[prefix + "receipt.json"] = read(prefix + "receipt.json")
        receipt = json.loads(files[prefix + "receipt.json"])
        if not receipt.get("finished_utc") or any(not c.get("direct_child_waited") or c.get("timed_out") for c in receipt["commands"]):
            raise RuntimeError("Execution remains unsettled: " + phase)
        if phase != "prepare-architecture" and not receipt.get("completed"):
            raise RuntimeError("Expected completed phase: " + phase)
        receipts[phase] = receipt
        for command in receipt["commands"]:
            label = command["label"]
            if not label or any(c not in "abcdefghijklmnopqrstuvwxyz-" for c in label):
                raise RuntimeError("Unexpected command label")
            for stream in ("stdout", "stderr"):
                name = prefix + label + "." + stream
                data = files[name] = read(name)
                if sha(data) != command[stream]["sha256"] or len(data) != command[stream]["bytes"]:
                    raise RuntimeError("Evidence content changed: " + name)
    arch = receipts["architecture"]
    for name, expected in arch["candidate_sha256"].items():
        if sha(read("architecture/" + name)) != expected:
            raise RuntimeError("Candidate changed: " + name)
    if sha(files["evidence/prepare-architecture/receipt.json"]) != receipts["recover-architecture-1"]["predecessor_receipt_sha256"]:
        raise RuntimeError("Predecessor receipt changed")
    scan = json.loads(files["evidence/architecture/arch-scan.stdout"])
    present = {v["fingerprint"] for v in scan["violations"]}
    events = [json.loads(line) for line in files["evidence/architecture/gui-focused.stdout"].splitlines() if line.strip()]
    terminal = [e for e in events if e.get("Test") and e.get("Action") in ("pass", "fail", "skip")]
    summary = {
        "source_head": arch["source_head"], "source_tree": arch["source_tree"],
        "candidate_sha256": arch["candidate_sha256"], "go_sha256": arch["go_sha256"],
        "commands": [{k: c[k] for k in ("label", "exit_code", "seconds", "direct_child_waited")} for c in arch["commands"]],
        "test_terminal_counts": dict(collections.Counter(e["Action"] for e in terminal)),
        "test_top_level_counts": dict(collections.Counter(e["Action"] for e in terminal if "/" not in e["Test"])),
        "package_terminal_events": [e for e in events if not e.get("Test") and e.get("Action") in ("pass", "fail", "skip")],
        "scan_count": len(scan["violations"]), "scan_summary": scan["summary"],
        "deleted_fingerprint_absence": {fingerprint: fingerprint not in present for fingerprint in ABSENT},
        "verify_summary": files["evidence/architecture/arch-verify.stderr"].decode().strip(),
        "archcheck_sha256": sha(read("runtime/architecture/archcheck.exe")),
        "qualifier_sha256": sha(files["qualify.py"]), "recovery_sha256": sha(files["recover_architecture.py"]),
        "source_fetch_count_kind": "explicit fetch commands", "explicit_source_fetches": receipts["recover-architecture-1"]["source_fetch_attempts"],
        "finished_utc": arch["finished_utc"],
    }
    files["observed-summary.json"] = (json.dumps(summary, indent=2) + "\n").encode()
    manifest = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(files.items())}
    files["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    out = ROOT / "evidence" / "architecture-qualification-evidence.zip"
    with zipfile.ZipFile(out, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
    data = out.read_bytes()
    encoded = base64.b64encode(data).decode("ascii")
    export = out.with_suffix(".b64")
    with export.open("x", encoding="ascii", newline="\n") as handle:
        handle.write("\n".join(encoded[i:i + 4000] for i in range(0, len(encoded), 4000)) + "\n")
    print(json.dumps({"archive_bytes": len(data), "archive_sha256": sha(data), "base64_lines": (len(encoded) + 3999) // 4000, "summary": summary}))


if __name__ == "__main__":
    main()
