"""One source-only recovery attempt; no tools installed or dependencies fetched."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-continuation-20261122-e51f")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
HEAD = "1cabce12655f810b742e6c31369441cacd72573c"
TREE = "8eed2215a72d8f56164afa562e277dd5ae387f28"
EXPECTED = {
    "architecture/baseline.yaml": "e0620345b7999fdb97462172d20226255e3397345078e98178098ddcd082632c",
    "internal/gui/server.go": "edcffcc94cb1078801d1329e04e1e98824527f5c9eb080fcdb20560675131325",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guarded(path):
    current = ROOT
    for part in (None, *path.relative_to(ROOT).parts):
        if part is not None:
            current = current / part
        if current.exists():
            info = current.lstat()
            if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Task path contains a reparse point")
    return path


def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Unexpected execution root")
    previous = guarded(ROOT / "evidence" / "prepare-architecture" / "receipt.json")
    old_hash = digest(previous)
    old = json.loads(previous.read_bytes())
    if old.get("completed") or not old.get("finished_utc") or old.get("source_head") != HEAD:
        raise RuntimeError("Previous failed preparation identity mismatch")
    if not old.get("commands") or any(not x.get("direct_child_waited") or x.get("timed_out") for x in old["commands"]):
        raise RuntimeError("Previous preparation is unsettled")
    if old["commands"][-1].get("label") != "fetch-source" or old["commands"][-1].get("exit_code") != 128:
        raise RuntimeError("Unexpected predecessor outcome")
    required = {
        ROOT / "qualify.py": "84231591aaface7284be6a4a768a4393cc71d6738839ae34d7f349400fdbf594",
        ROOT / "architecture.patch": "349cb21b1789055c62e623015be0e1e154ff3eba803749d4bf547f28b7e3d971",
    }
    for path, expected in required.items():
        if digest(guarded(path)) != expected:
            raise RuntimeError("Input hash mismatch: " + path.name)
    if digest(GO) != "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113":
        raise RuntimeError("Go tool identity mismatch")
    source = guarded(ROOT / "architecture")
    guarded(source / ".git")
    if {p.name for p in source.iterdir()} != {".git"}:
        raise RuntimeError("Expected the existing unpopulated clone")
    if (source / ".git" / "objects" / "info" / "alternates").exists():
        raise RuntimeError("Unexpected linked object store")
    evidence = guarded(ROOT / "evidence" / "recover-architecture-1")
    evidence.mkdir(exist_ok=False)
    runtime = guarded(ROOT / "runtime" / "recover-architecture-1")
    runtime.mkdir(exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata", "hooks"):
        (runtime / name).mkdir()
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_"))}
    env.update({
        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
        "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"),
        "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
        "PYTHONDONTWRITEBYTECODE": "1", "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"), "GIT_OPTIONAL_LOCKS": "0",
        "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never",
    })
    git = [str(GIT), "-c", "core.autocrlf=false", "-c", "core.symlinks=false",
           "-c", "core.fsmonitor=false", "-c", "core.hooksPath=" + str(runtime / "hooks")]
    receipt = {
        "phase": "recover-architecture-1", "source_head": HEAD, "source_tree": TREE,
        "runner_sha256": digest(Path(__file__)), "predecessor_receipt_sha256": old_hash,
        "input_sha256": {p.name: h for p, h in required.items()},
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "dependency_downloads": False, "native_scheduler_operations": False,
        "installed_product_operations": False, "commands": [], "completed": False,
    }

    def save():
        (evidence / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

    def run(label, args, allowed=(0,), timeout=60):
        item = {"label": label, "args": git + list(map(str, args)),
                "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        receipt["commands"].append(item)
        save()
        out, err = evidence / (label + ".stdout"), evidence / (label + ".stderr")
        started = time.monotonic()
        try:
            with out.open("xb") as stdout, err.open("xb") as stderr:
                child = subprocess.Popen(item["args"], cwd=source, env=env, stdin=subprocess.DEVNULL,
                                         stdout=stdout, stderr=stderr)
                item["pid"] = child.pid
                item["direct_child_waited"] = False
                save()
                try:
                    code = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    item["timed_out"] = True
                    item["settlement"] = "unsettled; no termination requested; retain task workspace"
                    raise
                item["exit_code"] = code
                item["direct_child_waited"] = True
        finally:
            item["seconds"] = round(time.monotonic() - started, 3)
            for key, path in (("stdout", out), ("stderr", err)):
                if path.exists():
                    item[key] = {"bytes": path.stat().st_size, "sha256": digest(path)}
            save()
        print(json.dumps({"label": label, "exit_code": code, "seconds": item["seconds"]}), flush=True)
        if code not in allowed:
            raise RuntimeError("Unexpected exit for " + label)
        return code, out.read_bytes()

    try:
        if run("source-remote", ["remote", "get-url", "origin"])[1].decode().strip() != "https://github.com/applicate2628/mcp-local-hub.git":
            raise RuntimeError("Unexpected source remote")
        exists, _ = run("head-object", ["cat-file", "-e", HEAD + "^{commit}"], allowed=(0, 128))
        if exists:
            receipt["source_fetch_attempts"] = 1
            run("fetch-exact-head", ["-c", "protocol.version=2", "-c", "http.version=HTTP/1.1",
                                    "-c", "http.lowSpeedLimit=1", "-c", "http.lowSpeedTime=30",
                                    "fetch", "--depth=1", "--no-tags", "--no-recurse-submodules", "origin", HEAD],
                timeout=180)
        else:
            receipt["source_fetch_attempts"] = 0
        if run("exact-tree", ["rev-parse", HEAD + "^{tree}"])[1].decode().strip() != TREE:
            raise RuntimeError("Source tree identity mismatch")
        run("checkout", ["checkout", "--detach", HEAD])
        if run("exact-head", ["rev-parse", "HEAD"])[1].decode().strip() != HEAD:
            raise RuntimeError("Source commit identity mismatch")
        if run("source-clean", ["status", "--porcelain"])[1].strip():
            raise RuntimeError("Unexpected source changes")
        patch = ROOT / "architecture.patch"
        run("apply-check", ["apply", "--check", patch])
        run("apply", ["apply", patch])
        actual = run("candidate-status", ["status", "--porcelain"])[1].decode().replace("\r\n", "\n")
        if actual != " M architecture/baseline.yaml\n M internal/gui/server.go\n":
            raise RuntimeError("Unexpected candidate delta")
        for relative, expected in EXPECTED.items():
            if digest(guarded(source / relative)) != expected:
                raise RuntimeError("Candidate hash mismatch: " + relative)
        receipt["candidate_sha256"] = EXPECTED
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["predecessor_receipt_unchanged"] = digest(previous) == old_hash
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        if not receipt["predecessor_receipt_unchanged"]:
            raise RuntimeError("Predecessor receipt changed")


if __name__ == "__main__":
    main()
