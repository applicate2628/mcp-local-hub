# R16: потребитель supervisor status и необходимые проверки

**Результат:** узкое объединение Windows-наблюдения одной обычной строки `Running` имеет предметную основу: текущий производственный путь трижды открывает один `CurrentPID`, а чтение памяти выполняется после закрытия дескриптора, на котором проверены исполняемый образ и время создания. Из этого не следует ни измеренный выигрыш всего status, ни необходимость Rust, общего реестра процессов или изменения решений о перезапуске.

**База:** `applicate2628/mcp-local-hub@a7d92d2852c4f6eb8afb0569ef76a545e38aacf7`. Документ фиксирует чтение исходников и проект проверок **до реализации**. На этом этапе продуктовые файлы не изменялись; тесты, продукт, измерения и удалённые команды не запускались. #659, поиск владельца порта по PID, не пересматривался. Параллельные рабочие каталоги Rust не открывались. Последующая разрешённая CLI-реализация в staging описана отдельно в `cli-review.md`; этот аудит не является её результатом исполнения.

PID — идентификатор процесса; RSS (*resident set size*) — резидентная память, в этом Windows-коде размер рабочего набора в байтах; IPC — межпроцессное взаимодействие; CLI — интерфейс командной строки; JSON — текстовый формат структурированных данных; TTL — время допустимого использования кешированного результата. `handle` ниже означает системный дескриптор конкретного объекта процесса, а не его числовой PID.

## Оглавление

1. [Доказательная база и границы](#scope)
2. [Настоящий caller и три открытия](#consumer)
3. [Обязательные данные и политика ошибок](#errors)
4. [Параллельность, блокировки и время жизни](#lifetime)
5. [Минимальная точка подмены без reflect](#seam)
6. [Существующие проверки и пробелы](#existing-tests)
7. [Минимальный содержательный план проверок](#test-plan)
8. [Что обосновано и что пока не доказано](#claims)
9. [Самопроверка и источники](#review)

<a id="scope"></a>
## 1. Доказательная база и границы

Отправной материал — `consumer-audit/process/consumer-map.md`, разделы 2–3 и 5–6. Существенные утверждения проверены по исходникам закреплённой базы, а не приняты из карты без чтения. Рекурсивное дерево GitHub для указанного коммита получено без усечения. `supervise_status.go`, `supervise_liveness.go`, `pid_alive_windows.go`, `pid_identity_windows.go` и `process_rss_windows.go` дополнительно получены через `github_fetch_file` на этой базе; локальные извлечённые копии совпали с ними после исключения различия в завершающем переводе строки. Строки в ссылках относятся к опубликованным файлам.

Прочитаны нужные участки диспетчера IPC, runtime tracker, канонического предиката liveness, Windows-функций процесса, платформенных заглушек и перечисленных ниже тестов. Индексный поиск GitHub использован только для поиска мест употребления; выводы о коде основаны на чтении точной базы. В частности, найденные обращения к `supervisorLivenessProbeFns` принадлежат status, liveness, readiness observer и target settlement; нельзя менять общий предикат так, будто у него единственный диагностический потребитель.

Применены полностью прочитанные навыки `go-concurrency-lifecycle` и `go-testing-and-verification`: отдельно установлены владелец ресурса, границы блокировок, проекция ошибок и наблюдаемые свойства тестов. Это не результат запуска их рекомендованных проверок.

<a id="consumer"></a>
## 2. Настоящий caller и три открытия

Непосредственный производственный caller — ветвь `case "status"` в `dispatchIPCRequest`: она вызывает `supervisorStatusDaemons(deps.stateDir, deps.runtimeTracker, deps.statusCoalescer)` и передаёт строки в `result.daemons`. Ошибка чтения исходных данных становится `STATUS_FAILED`; успешный ответ содержит `state`, `daemons`, `reconcile_ready`, `intent_files_loaded`. Это фактический producer протокола, а не вспомогательный benchmark [И1, строки 2263–2284].

`supervisorStatusDaemons` читает intent, копирует состояния tracker, один раз получает снимок владельцев портов и обходит daemon descriptors. Для строки с найденным runtime entry, `State == running` и без ожидающего завершения stop receipt он вызывает общий `supervisorDaemonEntryLiveWithProbe`. Только после этой классификации применяется условие выдачи `ram_bytes` [И2, строки 175–229, 288–347, 430–444].

**Таблица 1. Обычная успешная Windows-строка `Running`.**

| Шаг | Точное место | Прочитанные данные и время жизни | Использование результата |
|---|---|---|---|
| Состояние daemon | `supervise_status.go:190, 288–296` | Копия `CurrentPID`, `StartedAt`, `State`, дополнительных полей tracker; затем отдельное чтение stop receipt | Выбор ветви, публичные `current_pid`, `started_at`, `state` |
| Первое открытие | `supervise_liveness.go:880–891`; `pid_alive_windows.go:13–43` | `IsPidAlive → QueryPIDState`: `OpenProcess(SYNCHRONIZE)`, `WaitForSingleObject(handle, 0)`, закрытие при возврате | Обязательный gate `PIDAlive`; отказ ведёт к `pid_dead` |
| Второе открытие | `supervise_liveness.go:894–927`; `pid_identity_windows.go:600–612, 635–670` | `OpenProcess(QUERY_LIMITED_INFORMATION | SYNCHRONIZE)`; image path и creation time на этом одном дескрипторе; затем закрытие | Сопоставление с ожидаемым исполняемым файлом и `StartedAt` |
| Порт | `supervise_liveness.go:928–1004`; `supervise_status.go:202–229` | Замыкание читает общий map владельцев портов; это отдельное наблюдение, возможно кешированное | Решение `Running` / `Restarting`, grace и исключение `port_owner_unverified` |
| Третье открытие | `supervise_status.go:438–441`; `process_rss_windows.go:57–81` | `OpenProcess(QUERY_LIMITED_INFORMATION)`, `GetProcessMemoryInfo`, закрытие | Только optional `ram_bytes`; возвращённое zero или неизвестность опускают поле |

Точные Windows-реализации приведены в [И3]–[И5]. **Три открытия — условное число для этой успешной ветви**, а не формула для каждого запроса. Ранний отказ заканчивает liveness до следующего шага; неработающие строки не читают RSS; stop receipt образует другую ветвь. Это также не пара `ProcessStartTime + ResidentSetSizeByPID`: здесь создание читает `identityFromHandle` внутри `VerifyPIDIdentity`.

Ожидаемый image принадлежит daemon: `daemonExpectedIdentityExe(d.Command)` использует настроенную команду, разрешение короткого имени через `PATH`, абсолютный путь и разрешение символических ссылок. Собственный executable supervisor является fallback для пустой/неразрешимой команды, а не общей заменой настроенного image [И6, строки 740–784]. Сравнение сохраняет path, basename и время создания; по умолчанию допустимое абсолютное расхождение времён — **2 секунды**, а не точное равенство [И4, строки 635–654; И7, строки 9–38]. Новый наблюдатель не должен незаметно менять этот контракт.

<a id="errors"></a>
## 3. Обязательные данные и политика ошибок

В status «обязательно» означает необходимость для обычного решения о корректном живом процессе. Это не означает, что каждый такой отказ возвращается как ошибка всего IPC-запроса.

**Таблица 2. Реальная проекция результатов в текущей базе.**

| Условие | Канонический результат | Публичная строка status |
|---|---|---|
| Нет intent-файла или он не содержит daemon | Пустой список | Успешный ответ с `daemons: []` |
| Ошибка чтения/разбора intent, кроме отсутствия | Ошибка `supervisorStatusDaemons` | `STATUS_FAILED` в IPC envelope |
| `CurrentPID <= 0` у проверяемой Running-строки | `missing_pid` | `Restarting`, `current_pid: 0`; `stale_pid` появляется только при прежнем ненулевом PID |
| Liveness сообщает dead | `pid_dead` | `Restarting`, прежний PID в `stale_pid`, `current_pid: 0`, RAM отсутствует |
| Liveness не удалось прочитать | `QueryPIDState` возвращает unknown/error, но `IsPidAlive` сворачивает это в `false` | Та же проекция `Restarting`. Это существующая потеря различия, а не доказательство фактической смерти процесса |
| Нет `StartedAt` или ожидаемого image при включённом identity probe | `pid_identity_missing` | `Restarting`, PID очищается только в локальной строке |
| Identity сообщает уже завершившийся процесс | `pid_dead` | Та же проекция отказа |
| Image/creation query failed, image/time mismatch или другая identity error | `pid_identity_mismatch` и текст ошибки внутри verdict | `Restarting`; status не выдаёт отдельное поле с `IdentityDetail` |
| `ErrProcessIdentityUnsupported` | Сохраняется положительный PIDAlive; проверка порта продолжается | Совместимость неподдерживаемой платформы; это не разрешённый fallback при обычном Windows query failure |
| Владелец порта неизвестен из-за ошибки снимка | В grace — live; после grace — `port_owner_unverified` | Status специально сохраняет `Running` и `current_pid`; RAM по-прежнему optional |
| Чужой владелец/сам supervisor; либо порт не привязан после grace | Отрицательный port verdict | `Restarting`, `stale_pid`, `current_pid: 0`, RAM не выдаётся |
| RSS недоступен или равен нулю | Не меняет liveness/identity | `ram_bytes` отсутствует; не `0`, не `STATUS_FAILED`, не новая причина перезапуска |
| Есть stop receipt | Обычная liveness-ветвь пропущена | `Stopping` либо `Failed`, `stop_settlement` сохраняется; подробность ниже |

Основания: [И1, строки 2263–2284], [И2, строки 175–229, 320–400, 430–442], [И3, строки 13–43], [И6, строки 880–1004]. У публичного `started_at` отдельный источник: **время из tracker**, форматируемое `daemonRuntimeStartedAt`, а не только что прочитанная creation time [И2, строки 363, 465–470].

### Особенность stop receipt, которую нельзя исправлять попутно

`stopPending` исключает обычный liveness gate. Позднее меняется `row["state"]` на `Stopping`/`Failed`, но локальный `stateText` не переписывается. Поэтому entry с исходным `stateText == "Running"` и положительным PID может получить RSS даже при публичном `Stopping`/`Failed` [И2, строки 320, 368–400, 438–441].

Это точное наблюдение кода, не предположение. Для узкого изменения обычного status-наблюдения безопаснее сохранить эту ветвь с прежним optional RSS. Новый обязательный image/liveness gate или требование права `SYNCHRONIZE` для неё будет отдельным изменением поведения. Существующий тест stop receipt проверяет state и диагностический receipt, **но не наличие/отсутствие RAM** [И15, строки 257–284].

### Ошибка закрытия — отдельное решение контракта

Три старых helper вызывают `defer windows.CloseHandle(h)` без проверки возвращаемой ошибки [И3, строка 29; И4, строка 611; И5, строка 68]. Если новое наблюдение сохраняет ошибку закрытия, это полезная новая наблюдаемость, но её проекция в status должна быть явно выбрана и проверена. Нельзя одновременно обещать полное сохранение всех старых error outcomes и молча делать close error новой причиной `Restarting`. Ошибку закрытия следует сохранять отдельно или в составной ошибке с первичной причиной; optional RSS error нельзя объединять с обязательным identity failure так, чтобы корректная живая строка переставала быть Running только из-за памяти.

<a id="lifetime"></a>
## 4. Параллельность, блокировки и время жизни

**Таблица 3. Владельцы и границы синхронизации.**

| Участок | Реально удерживаемая блокировка / владелец | Следствие для изменения |
|---|---|---|
| Один IPC-клиент | Отдельная goroutine запускается accept loop; внутри одного соединения запросы dispatch выполняются последовательно | Два клиента могут одновременно формировать status. Нельзя хранить активный process handle в общей переменной [И1, строки 2078–2090, 2147–2215] |
| `tracker.Snapshot()` | `RLock` только на копирование map; возвращается новая map значений `DaemonRuntimeEntry` | Системные process calls происходят после освобождения tracker lock; это нужно сохранить [И8, строки 830–840] |
| `StopSettlementReceipt`, `CrashCountInWindow` | Собственные короткие `RLock`, не общий lock на всю строку | Полученная строка не является атомарным снимком tracker, receipt и crash history в одну наносекунду [И8, строки 202–219, 846–854] |
| `MarkSpawned` | `Lock` на согласованное обновление `CurrentPID`, `StartedAt`, `PIDGeneration` | Снимок может устареть после возврата; удержание process handle не замораживает tracker [И8, строки 433–453] |
| Coalescer портов | Mutex защищает map/error, timestamp, generation и inflight. Реальный probe идёт вне mutex; cold caller ждёт канал после unlock | Новый process observer не должен попадать под этот mutex; коалесцирование относится к портам, не к process handles [И2, строки 96–172] |
| Native helpers в базе | Каждый владеет собственным временным дескриптором до синхронного возврата | Операционное объединение должно закончить и закрыть своё наблюдение до выдачи строки; не передавать raw handle в JSON/cache |

`Snapshot()` копирует значения структуры, включая её указатели; это не обоснование называть все вложенные данные глубоко скопированными. Нужные для этого изменения `State`, `CurrentPID`, `StartedAt`, `PIDGeneration` являются значениями. Наблюдатель должен читать их из одной выбранной runtime entry и не переписывать сам tracker.

У port coalescer имеется один inflight probe и таймаут 3 секунды; его warm cache при истечении TTL может обслужить запрос старым port map и начать background refresh. Это существующая отдельная граница свежести [И2, строки 37–48, 96–172]. Один process handle **не превращает** image, liveness, RAM, tracker и port snapshot в одновременный снимок всей системы. Даже поля одного процесса читаются последовательно, а процесс может завершиться между проверкой и отправкой JSON.

Новой фоновой goroutine, кеша по PID, общей таблицы дескрипторов или блокировки всей status-операции этот consumer не требует. Синхронный observer одной строки достаточен для привязки полей к одному объекту процесса. Если предлагается borrowing существующего creator handle, это уже иной контракт владельца: status сегодня получает только tracker, а не creator. Заимствование нельзя объявить готовым улучшением без анализа закрытия/retirement соответствующего владельца.

<a id="seam"></a>
## 5. Минимальная точка подмены без reflect

Практический совместимый вариант — **один optional status-only callback в существующем `supervisorLivenessProbe`**, например `ObservePID`. Он ненулевой только в Windows default. Им пользуется только `supervisorStatusDaemons`; общий liveness predicate, автономный sweep, startup/runtime loading, readiness и target settlement его не вызывают.

У обычной Running-строки status получает одно локальное наблюдение, затем передаёт каноническому предикату локальную копию probe, в которой `PIDAlive` и `PIDIdentity` читают данные этого наблюдения. Политика port/grace и построение общего verdict остаются у `supervisorDaemonLivenessVerdictWithProbe`; не нужно копировать её во второй switch. Identity comparison должен использовать прежний comparator, в том числе нормализацию path и 2-секундный допуск; буквальное копирование алгоритма в CLI создаст второй источник правил. Конкретная форма результата должна сохранять различие обязательного состояния/identity и optional RSS, не экспортируя raw handle.

Почему этот seam позволяет обойтись без массовой миграции тестов:

1. `setSupervisorLivenessProbeForTest` полностью заменяет структуру probe и возвращает restore [И6, строки 59–92].
2. Существующие fixtures задают именованные `PIDAlive`, `PIDIdentity`, `PortLive`, `PortOwnerPID`. Новый field у таких литералов равен nil.
3. При nil observer status продолжает прежний путь, включая `rssByPID`. Следовательно, `withFakeRSS`, `installOwnsPortProbe` и status IPC tests сохраняют изоляцию.
4. Новые tests явным образом задают observer и проверяют новую ветвь. Глобальную настройку меняют до старта goroutines и восстанавливают после их завершения.

Это явный выбор capability, а не сравнение адресов функций через `reflect`. Индексный поиск нашёл `defaultSupervisorLivenessProbe` только в production definition и одном тесте выбора платформенного port probe; прямых записей вида `supervisorLivenessProbeFns.<field> = ...` не найдено. Это поддерживает малый размер миграции, но не заменяет повторную проверку всех затронутых литералов при реализации.

Отдельный безусловно включённый глобальный `statusObserver` хуже для существующих seams: тест, подменивший весь liveness probe, неожиданно продолжит выполнять Windows system calls. Чтобы вернуть изоляцию, придётся менять много fixtures либо вводить неявное распознавание подменённых функций. Optional field в уже подменяемой структуре устраняет эту проблему.

Если one-shot observer сразу читает RSS до canonical port verdict, он может выполнить optional чтение для строки, позднее классифицированной как `Restarting`. Публичное отсутствие `ram_bytes` можно сохранить, но внутреннее число чтений уже отличается от старого. Не следует вводить сложный handle/callback lifetime только ради формального сохранения этой последовательности без конкретного требования; одновременно нельзя заявлять неизменность числа syscalls для всех отрицательных ветвей. Это должно быть сознательное небольшое решение реализации.

<a id="existing-tests"></a>
## 6. Существующие проверки и пробелы

**Таблица 4. Что действительно проверяет существующий тестовый код, без заявления о его запуске.**

| Файл и тест | Имеющийся seam / oracle | Чего он не доказывает |
|---|---|---|
| `supervise_status_ram_test.go:15–123`: `TestSupervisorStatusEmitsRAMForRunningDaemon`, `...OmitsRAMWhenLookupFails`, `...OmitsRAMWhenZero` | `withFakeRSS`, tracker + isolated intent; проверка PID lookup, positive bytes, полного отсутствия ключа при failure/zero | Fixture намеренно задаёт `PIDIdentity=nil`. Он не связывает RAM с image/creation, не проверяет один handle и Windows access rights [И9] |
| `supervise_status_snapshot_test.go:23–211`: `...TakesPortOwnerSnapshotExactlyOnce`, `...SnapshotErrorStaysRunning`, `...SnapshotOwnerMismatchFlipsRestarting` | Один общий fake port map; states/current/stale projection | `installOwnsPortProbe` также выключает identity. Это проверка порта и policy, не process observation [И10] |
| Тот же файл, строки 251–748: coalescer tests | TTL, cold fan-in, warm stale, generation changes, probe error/timeout; injected snapshot/gen/time | Одно сетевое наблюдение не означает одно process observation; эти тесты не квалифицируют handle lifetime [И10] |
| `supervise_daemon_identity_exe_test.go:161–239`: `TestSupervisorStatusDaemons_ConfiguredCommandIdentityProjection` | `PIDIdentity` получает ожидаемый daemon executable; matching → Running, mismatch → Restarting/current0/stale | Не проверяет создание и RAM на одном объекте; существует условный skip при совпадении тестового daemon path с supervisor [И11] |
| `supervise_liveness_test.go:20–59`: `TestSupervisorStatusDoesNotReportRunningForDeadRecordedPID` | PIDAlive=false → current0/stale; isolated intent | Не отличает реальную смерть от query error и не проверяет RSS suppression через отдельный oracle [И12] |
| `supervise_status_ipc_test.go:16–153`: `TestIPCStatusReadsRuntimeTracker` | Настоящий dispatch через `net.Pipe`, JSON response, Running/Stopped/Idle, PID, workspace, port | Это частичный public contract, не полный golden всей строки и не native IPC transport [И13] |
| `supervise_status_golden_test.go:27–68` | Только словарь `supervisorStatusGUIState`, включая различие idle/empty и сохранение неизвестных значений | Название golden не означает byte-for-byte golden JSON status [И14] |
| `supervise_stop_settlement_test.go:257–284`: `...ProjectsPendingStopReceiptAsStopping` | Receipt и observed port owner в Stopping row | Не проверяет RAM/identity bypass на Stopping/Failed [И15] |
| `supervise_liveness_test.go:1728–1830`: `...SweepConcurrentWithHandlerNoRace` | Одновременные sweep и controller changes, drain barrier, итоговый persisted state | Не вызывает status observer и не доказывает отсутствие race у новой локальной observation [И12] |
| `supervise_liveness_test.go:2130–2166`; `supervise_target_settlement_test.go:213–260` | Платформенный nil PortOwnerPID, unsupported strong proof, TCP-only vs verified identity provenance | Нужны как защита от попутного изменения общего предиката; не доказательство нового Windows observer [И12, И16] |
| `process_rss_test.go:18–41` | Self RSS на Windows, заглушка на других платформах, invalid PID | Self-success не квалифицирует доступ к чужому владельцу, согласованность поколения или cleanup errors [И17] |

Рекомендация — расширить только те existing tests, у которых уже есть подходящий oracle, и добавить несколько новых контрактных случаев. Копировать все tests liveness или создавать отдельную дублирующую policy suite для observer не требуется.

<a id="test-plan"></a>
## 7. Минимальный содержательный план проверок

Ниже — **предложение**, а не выполненные проверки. Сначала устанавливаются конкретные наблюдаемые свойства; счётчики вызовов служат дополнительной проверкой ограниченной операции, не единственным доказательством корректности.

**Таблица 5. Необходимые семейства проверок для минимального изменения.**

| № | Инвариант и слой | Минимальная содержательная постановка | Что должно сломать тест |
|---|---|---|---|
| Т1 | Один объект процесса для обязательных полей и RAM; process unit с внедрёнными native operations | Fake Open фиксирует объект A с PID P, image/time/RAM A. После identity fixture меняет таблицу PID так, что P теперь указывает на B с отличающимися image/time/RAM. Дальнейшее чтение по уже выданному handle возвращает A либо явную неизвестность после exit; lookup по P вернёт B. Проверить отсутствие RAM B в принятом наблюдении, правильную identity, единственное закрытие acquired handle | Повторное открытие по PID для RAM; получение creation/image из другого fake handle; забытое закрытие на ошибке. Счёт `Open==1` дополняет oracle A/B |
| Т2 | Раздельная обязательность; process unit + status projection | Табличные случаи: dead; unknown liveness; image query failure; creation query failure; mismatch; RSS failure; RSS known zero; primary error вместе с close error. Для optional RSS failure/zero обязательное положительное наблюдение остаётся пригодным; ошибочная identity не становится успешной | Один общий `err` делает RSS failure обязательным; замена unknown успешным/default результатом; потеря первичной либо cleanup error |
| Т3 | Публичная policy неизменна; существующий `supervisorStatusDaemons` | Одно Running entry со значимыми `Command`, `StartedAt`, PID и port. Новый observer + локальные port fixtures. Случаи: matching/positive RAM; matching/unknown RAM; identity failure; port snapshot error; foreign owner; unbound past grace. Проверить `state`, `current_pid`, `stale_pid`, точное tracker `started_at`, наличие/отсутствие RAM, отсутствие новых полей | RAM выдаётся после отрицательного port verdict; snapshot error превращается в Restarting; наблюдённое creation time заменяет tracker started_at; обход comparator |
| Т4 | Status-only scope и прежние seams | Nil observer с существующими fake PIDAlive/PIDIdentity/rss должен давать прежнюю строку без native call. Ненулевой observer должен использоваться только status: прямой вызов canonical liveness/sweep не вызывает его (sentinel). Stop receipt с исходным Running entry должен сохранять Stopping/Failed и прежний optional RSS без обязательного identity | Безусловный глобальный observer обходит fixtures; sweep нечаянно перенаправлен; stopPending получил новый mandatory gate; RAM исключена только из-за emitted state |
| Т5 | Независимость параллельных запросов и отсутствие удержания tracker lock | Один раз установить fixture; начать два status-вызова с разными локальными observation tokens, синхронизировать каналами. Заблокировать только получение наблюдения первого, убедиться, что tracker update завершается, затем отпустить оба. Проверить, что значения A/B не смешались и оба ресурса закрыты. После join восстановить globals | Shared current handle/result; lock tracker удержан через probe; defer не закрыл одну ошибочную ветвь; cleanup globals начат до завершения goroutines |
| Т6 | Реальная Windows binding и public transport | Один ограниченный native тест на своём процессе или принадлежащем тесту контролируемом child: production observer читает реальный image/creation/liveness/RSS, завершает lifetime. Отдельно расширить уже имеющийся `net.Pipe` JSON-test для RAM presence/omission; не создавать новый transport harness | Ошибка rights/структуры/syscall adapter; JSON ключ/тип изменился; реальный процессный ресурс не завершён по выбранной модели |

Т1 моделирует существенный промежуток между проверкой identity и RAM, но не является доказательством нативного повторного использования PID на Windows. Т6 проверяет настоящий adapter в доступном контексте владельца; он не подтверждает права другого пользователя, полный установленный Product или систематический native PID reuse. Для таких заявлений потребуются отдельные разрешённые fixtures и вопросы.

Детерминированные каналы в Т5 предпочтительнее случайных задержек. Все тесты с package globals должны выполняться без `t.Parallel`; подмена устанавливается до старта горутин, cleanup после join. Детектор гонок данных при будущем прогоне даст свидетельство только для исполненных путей. Для process unit необходим маленький per-instance набор syscall seams, а не новая общепакетная изменяемая таблица Windows функций.

Новый observer должен оставаться nil вне Windows. На Linux остаётся прежняя liveness/identity через `/proc`, а RSS возвращает `(0,false)`; на других Unix-подобных системах identity может быть unsupported и `PortOwnerPID` остаётся nil, чтобы работала прежняя TCP-проверка. `process_rss_other.go:1–16`, `pid_identity_other.go:1–25`, `pid_alive_linux.go:1–60`, `pid_alive_other.go:1–34` и тесты из таблицы 4 фиксируют эти границы [И18–И21]. Кросс-компиляция может проверить сборку, но не заменяет нативный Unix-прогон.

<a id="claims"></a>
## 8. Что обосновано и что пока не доказано

**Факт исходников:** обычная успешная Windows-строка выполняет три открытия; image+creation проверяются на втором, а память берётся из третьего. `CurrentPID` численно один, но программа не связывает третий handle с проверенным вторым объектом. Закрытие identity handle → последующий RSS reopen — конкретный промежуток, где при завершении A и повторном использовании P процессом B память может быть приписана прежней строке. Эта последовательность является аргументом о контракте и системном риске; падающий native прогон базы не выполнялся и не заявляется.

**Обоснованное направление:** локально устранить независимый повторный lookup для полей одного статусного наблюдения, сохранив обязательную identity, optional RAM, canonical port policy и прежних владельцев restart/terminate. Это самостоятельный малый вопрос качества даже без обещания ускорения.

**Не доказано:** пользовательский инцидент с чужой RAM; величина уменьшения времени `/api/status`; частота трёх открытий на реальном fleet; более высокая надёжность всех Windows liveness checks; atomic snapshot; возможность использовать process observation как creator/termination authority. Нет основания переносить вывод на Rust ABI, владение original child, чужие user fixtures, Linux native отказ, port observation #659 либо R17 scheduler.

**Не следует добавлять:** global PID registry, shared handle cache, новый lifecycle controller, дополнительный poller, параллельный сбор полей одного process handle, копию канонического liveness switch. Никакая из этих конструкций не требуется данным consumer contract. Новое широкое измерение #628 не обосновано до появления конкретного проверяемого вопроса после выбора реализации.

<a id="review"></a>
## 9. Самопроверка и источники

Самостоятельно проверено чтением: точный caller, условие запуска gates, независимость optional RAM, special stopPending projection, 2-секундный identity tolerance, tracker lock scope, параллельные IPC-handlers и содержательные ограничения существующих тестов. Упоминания успешных тестов в исходных комментариях не превращены в результаты этой работы. Общие syscall guarantees оставлены отдельному native-contract аудиту; настоящие Windows/Unix вызовы здесь не выполнялись.

В списке ниже все источники закреплены на одной базе. Указанные в тексте номера строк позволяют проверить каждое утверждение непосредственно в исходнике.

1. <a id="ref1"></a>**И1.** [internal/cli/supervise.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise.go#L2078-L2284).
2. <a id="ref2"></a>**И2.** [internal/cli/supervise_status.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_status.go).
3. <a id="ref3"></a>**И3.** [internal/process/pid_alive_windows.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_alive_windows.go#L13-L43).
4. <a id="ref4"></a>**И4.** [internal/process/pid_identity_windows.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_identity_windows.go#L600-L740).
5. <a id="ref5"></a>**И5.** [internal/process/process_rss_windows.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/process_rss_windows.go#L47-L81).
6. <a id="ref6"></a>**И6.** [internal/cli/supervise_liveness.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_liveness.go).
7. <a id="ref7"></a>**И7.** [internal/process/pid_identity_common.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_identity_common.go#L9-L38).
8. <a id="ref8"></a>**И8.** [internal/cli/supervisor_runtime_tracker.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervisor_runtime_tracker.go).
9. <a id="ref9"></a>**И9.** [internal/cli/supervise_status_ram_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_status_ram_test.go#L15-L123).
10. <a id="ref10"></a>**И10.** [internal/cli/supervise_status_snapshot_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_status_snapshot_test.go).
11. <a id="ref11"></a>**И11.** [internal/cli/supervise_daemon_identity_exe_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_daemon_identity_exe_test.go#L161-L239).
12. <a id="ref12"></a>**И12.** [internal/cli/supervise_liveness_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_liveness_test.go).
13. <a id="ref13"></a>**И13.** [internal/cli/supervise_status_ipc_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_status_ipc_test.go#L16-L153).
14. <a id="ref14"></a>**И14.** [internal/cli/supervise_status_golden_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_status_golden_test.go#L27-L68).
15. <a id="ref15"></a>**И15.** [internal/cli/supervise_stop_settlement_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_stop_settlement_test.go#L257-L284).
16. <a id="ref16"></a>**И16.** [internal/cli/supervise_target_settlement_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/cli/supervise_target_settlement_test.go#L213-L260).
17. <a id="ref17"></a>**И17.** [internal/process/process_rss_test.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/process_rss_test.go#L18-L41).
18. <a id="ref18"></a>**И18.** [internal/process/process_rss_other.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/process_rss_other.go).
19. <a id="ref19"></a>**И19.** [internal/process/pid_identity_other.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_identity_other.go#L1-L25).
20. <a id="ref20"></a>**И20.** [internal/process/pid_alive_linux.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_alive_linux.go).
21. <a id="ref21"></a>**И21.** [internal/process/pid_alive_other.go](https://github.com/applicate2628/mcp-local-hub/blob/a7d92d2852c4f6eb8afb0569ef76a545e38aacf7/internal/process/pid_alive_other.go).
