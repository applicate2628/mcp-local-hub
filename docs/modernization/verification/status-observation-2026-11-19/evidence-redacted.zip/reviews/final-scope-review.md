# Независимое целостное ревью R16 status observation

Дата: 19 ноября 2026, Москва. Прочитан замороженный предложенный diff к #628 `9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9`: пять Go-файлов CLI — интерфейса командной строки — и четыре Go-файла `internal/process`. Ревью выполнено чтением кода; сборки, тесты, удалённые команды и изменения GitHub не выполнялись. Код не редактировался.

## Оглавление

1. [Вывод и замечания](#findings)
2. [Точный прочитанный снимок](#snapshot)
3. [Цепочка наблюдения и потребления](#contract)
4. [Совместимость, остановка и параллельность](#compatibility)
5. [Проверки и их границы](#tests)
6. [Сложность и область PR](#scope)
7. [Остаток до заявления о готовности](#remaining)
8. [Источники](#sources)

<a id="findings"></a>
## 1. Вывод и замечания

**Обязательных дефектов в прочитанном снимке не найдено.** Это результат независимого статического ревью всего предложенного изменения, не runtime PASS, не одобрение слияния и не подтверждение полных обязательных Go-команд. Авторское резюме прочитано после самостоятельного прослеживания кода и тестовых оракулов; его утверждения автоматически не засчитывались.

Ранее обнаруженное другим проверяющим замечание P2 про `WaitForSingleObject` по уже закрытому дескриптору **действительно устранено в текущем коде**: `pid_status_windows_test.go:246–269` не сохраняет закрываемое числовое значение и не выполняет поздний wait; реальный `CloseHandle` обёрнут только для счётчика. Подтверждение основано на прочитанной реализации, не только на чужом отчёте.

**Таблица 1. Существенные ограничения вывода; это не обязательные дефекты нового кода.**

| Место | Условие | Конкретное следствие и квалификация |
|---|---|---|
| `pid_status_windows.go:47–53`; `supervise_status.go:343–351` | Успешные чтения и ошибка `CloseHandle` | Ошибка сохраняется и доходит до существующего identity gate; строка получает Restarting, память не публикуется. Старые helpers игнорировали close error. Это намеренное ужесточение, поэтому нельзя заявлять полное совпадение всех прежних отказов |
| `pid_status_windows.go:66–69`; `supervise_status.go:341` | Процесс выходит после проверки образа/создания | Последний wait даёт Dead; строка становится Restarting без памяти. Старый путь мог сохранить Running. Это ожидаемая дополнительная проверка, не атомарный снимок и не гарантия будущей живости |
| `supervise_status.go:326,465–474` | Есть stop receipt, локальная проекция остаётся Running | Объединённое наблюдение пропускается, остаётся прежний скалярный RSS. Улучшение привязки памяти относится к обычной проверяемой Running-строке, не ко всем Stopping/Failed строкам |
| `pid_status_windows.go:61–65`; `supervise_status.go:366–378` | Обязательная идентичность прошла, но поздний port gate отвергает строку | Необязательная память могла быть уже прочитана; затем она отбрасывается. Три открытия сокращены в выбранной ветви, но производственный выигрыш по времени не доказан |
| `supervise_status.go:341`; прежний predicate `supervise_liveness.go:894–896` | Native state Unknown | Сохраняется прежняя status-проекция bool liveness: Restarting. Новый process-контракт сохраняет Unknown и ошибку; внешняя status-схема нового поля unknown не получает. Сохранение совместимости не является оценкой идеальности этой старой политики |

Оставшиеся особенности не предлагаются к попутному исправлению: они либо составляют согласованную границу, либо требуют отдельного решения о поведении.

<a id="snapshot"></a>
## 2. Точный прочитанный снимок

Полностью прочитаны шесть новых файлов; для трёх изменённых файлов прочитан весь diff и окружающие производственные маршруты, включая исходный canonical predicate. Дополнительно прочитаны исходные Windows identity/liveness/RSS helpers, общий `PIDIdentityProof`, двухсекундный допуск создания, существующий дочерний helper и старые RAM/snapshot/liveness test seams на точном #628. Проверка новой сериализации состояний не заменена подсчётом имён тестов.

**Таблица 2. Контрольные суммы SHA-256 прочитанных файлов до окончательного gofmt.**

| Путь относительно `source/` | SHA-256 |
|---|---|
| `internal/cli/supervise_liveness.go` | `7233594df58e9e8e16c6f97b35670c5e0b8e8e6b20e4d7095fa3e2506f088cf4` |
| `internal/cli/supervise_status.go` | `b56d19d612b753d45b19a4de15478a4ab3b99e568898915a86aafd27007293d6` |
| `internal/cli/supervise_status_process_other.go` | `73b3a54302c01e61b13cfecdc721d3a9420dbf4b97ef556058f09195756aee51` |
| `internal/cli/supervise_status_process_test.go` | `e8e0230182f56a52bf11e7275b0cac5a8fd839918592ea70762ea9b4c90310fa` |
| `internal/cli/supervise_status_process_windows.go` | `bc4e9e93a6986154cde0fbd4ef61173855245881f5dd3a16c5f5d9fb9841a1b2` |
| `internal/process/pid_status.go` | `ec37aec2ef4fdbc5827f47a972e12a494369fc0f3745c9e573f88d3247f348a1` |
| `internal/process/pid_status_windows.go` | `2706fc8634afee5991e564ad64c1bc1ad7f8dc293a07739a45e3ed2ce26e1e57` |
| `internal/process/pid_status_windows_test.go` | `64334cf830a235a926a3c243d5fa5a900fd0d400a074d50ad163a9f78b5e711c` |
| `internal/process/process_rss_windows.go` | `bbb8ee925bb3e742d7dd2eabadf6ffa08e3852e9fd17f0038cd6e39895ac0d3b` |

Сравнение с тремя исходными файлами даёт девять Go-путей **+815/−14 строк**. Из них 646 добавленных строк — два новых тестовых файла; производственный остаток — **+169/−14** в семи файлах. Эти числа относятся к данному предложению, не к полному накопленному diff #628 и не к форматированному/опубликованному будущему коммиту.

<a id="contract"></a>
## 3. Цепочка наблюдения и потребления

**Таблица 3. Прослеженные обязательства.**

| Граница | Место | Проверенный вывод |
|---|---|---|
| Платформа | два `supervise_status_process_*.go`; `supervise_liveness.go:72–79` | Windows default связан с `process.ObservePIDStatus`; `!windows` задаёт типизированный nil. Windows-only symbol не используется в общей сборке |
| Выбор строки | `supervise_status.go:322–328` | Объединённое наблюдение доступно только в прежней ветви найденной Running-записи без stopPending. Флаг выбора фиксируется до вызова observer; отказ не возвращает строку на скалярный RSS |
| Идентичность запроса | `supervise_status.go:333–340` | PID передаёт canonical predicate; образ вычислен из configured command; StartedAt взят из локальной копии tracker. Используется прежнее UTC/RFC3339Nano представление; нулевое время остаётся пустой строкой |
| Один объект | `pid_status_windows.go:34–69` | Один `OpenProcess` с query-limited и synchronize, без наследования; wait, прежний verifier и memory helper получают один handle. Неположительные и превышающие DWORD PID отвергаются до открытия |
| Обязательное и необязательное | `pid_status_windows.go:56–69` | Начальный dead/unknown не достигает identity/RSS. RSS вызывается только после успешного `verifyHandleIdentity`; его false не создаёт обязательную ошибку. После verify failure остаётся финальный wait, первоначальная ошибка не теряется |
| Закрытие и составные ошибки | `pid_status_windows.go:47–54,66–69` | Deferred close установлен сразу после открытия. `errors.Join` сохраняет независимые verify/wait/close причины. При ошибке или не-Alive память очищается. Ни дескриптор, ни право terminate наружу не передаются |
| Proof drift | `supervise_status.go:343–351` | Весь сопоставимый `PIDIdentityProof` из второго canonical gate сравнивается с действительно наблюдённым. Изменившееся разрешение command не может сделать наблюдение образа A доказательством образа B; mismatch присоединяется к сохранённой ошибке |
| Существующий classifier | `supervise_status.go:358–378`; `supervise_liveness.go:886–1010` | Predicate получил локальную копию callbacks, его алгоритм не переписан. Missing-PID/start/image, port/grace и исключение port_owner_unverified сохраняются. Ошибка при Alive попадает в identity gate; Unknown/Dead дают прежний false liveness |
| Публикация памяти | `supervise_status.go:465–474` | Требуются прежняя Running/currentPID проекция, отсутствие обязательной ошибки, Alive, known и положительные bytes. Ни обязательный отказ, ни недоступная память не вызывает scalar fallback после выбранного observer |

`verifyHandleIdentity` повторно используется без копии сопоставления пути/имени и времени создания. Новый proof не задаёт `StartTolerance`; сохранён существующий default из `pid_identity_common.go`. Структура результата содержит только значения, не создаёт новую идентичность владения процессом. Один handle связывает свои поля с одним объектом; портовый снимок и tracker остаются наблюдениями другого времени.

Отдельно проверен случай изменившегося ожидаемого proof: ошибку сохраняет сама локальная переменная `pidStatusErr`, поэтому запрет RAM продолжает действовать и после возврата canonical predicate. Результат первого наблюдения не выдаётся под вторым ожиданием.

<a id="compatibility"></a>
## 4. Совместимость, остановка и параллельность

### Остановка и выходная схема

При `stopPending` новые callbacks не устанавливаются. Существующий receipt по-прежнему проецируется в Stopping/Failed, receipt-поля сохраняются; ниже используется прежний локальный `stateText` и скалярный RSS. Это явно проверяется двумя сценариями нового теста. Строки по-прежнему используют прежние ключи, тип `uint64` для памяти, tracker timestamp, current/stale PID. Значения native error или handle не добавлены в JSON — текстовый формат обмена данными.

### Остальные владельцы решений

Diff `supervise_liveness.go` добавляет только callback и его platform default. Canonical predicate, автономный sweep и target-readiness решения не читают `PIDStatus`. Они продолжают пользоваться прежними scalar callbacks. Новый код не меняет original creator/held interfaces, процедуры termination, stop-settlement owner, Rust или внешний API.

В прочитанных старых RAM/snapshot/liveness тестах probes заменяются целой структурой; новый optional field при этом nil и скалярный путь остаётся. Глобальная reflection-проверка «настоящий это probe или тестовая подмена» не добавлена. Это статическая совместимость прочитанных seams, не утверждение, что все repository tests выполнены.

### Параллельные запросы

`rowProbe`, `pidStatus`, `pidStatusProof`, `pidStatusErr`, `usedPIDStatus` создаются внутри одной итерации. Callbacks используются синхронно до её завершения; они не сохраняются в tracker или глобальном кеше. Нативная операция закрывает handle перед возвратом значения. Дополнительных goroutine, mutex, global active-result переменных или зависимостей между строками не появилось.

Новый callback вызывается после получения прежнего `tracker.Snapshot`, без удержания tracker lock. Новый concurrency-тест блокирует первый запрос внутри observer, разрешает обновление tracker и завершение второго запроса, затем проверяет обе несовпадающие пары PID/start/RAM. Cleanup сначала разблокирует и присоединяет goroutine, после этого восстанавливает глобальные seams: обратный порядок зарегистрированных cleanup корректен. Тест не использует `t.Parallel`; регистрации и восстановление globals происходят вне работающих запросов.

Существующие временные различия между runtime snapshot, stop receipt и port snapshot этим изменением не устранены и за новые гарантии не выдаются.

<a id="tests"></a>
## 5. Проверки и их границы

Новые native contract tests проверяют не только последовательность вызовов: State, отсутствие непригодной памяти, сохранность независимых причин через `errors.Is`, точный proof и handle, права и отсутствие наследования. Сценарий предполагаемого второго открытия возвращает другой handle; oracle отвергает его использование. Это синтетическое доказательное устройство теста, не нативное воспроизведение PID reuse.

NativeSelf вызывает производственный entry point и содержит негативные образ/создание proofs. NativeExitDuringObservation использует существующий child helper: ребёнок ждёт EOF стандартного ввода, creator закрывает ввод и выполняет единственный `cmd.Wait`. Observation owner независимо сохраняет свой query handle до финального wait/close. Deadline взят из test runner, cleanup установлен до последующих потенциально падающих проверок; работа чужих процессов не затрагивается. Сейчас после Close нет использования освобождённого числового значения.

CLI-тесты проверяют полную результирующую map и неизменность tracker, запрещают scalar liveness/identity/RSS после выбора combined observer, отдельно проверяют missing identity, PATH proof drift, stopPending, неподключение observer к canonical predicate и локальность параллельных запросов. Проверки port snapshot error и чужого port owner различаются; неизвестная память не подменяется нулём.

Выполнения этих тестов данный аудит не заявляет. Покрытие native access denied, чужого владельца, настоящего CloseHandle failure, Unix-native поведения и установленного Product не следует из synthetic cases или положительного собственного процесса. Performance-измерений нет. Достаточность полной компиляции и связки всех существующих test helpers установит следующий адресный прогон Root.

<a id="scope"></a>
## 6. Сложность и область PR

Ponytail-разбор не обнаружил обязательного удаления или упрощения. Дополнительный private `pidStatusOps` нужен для осмысленных отказов Win32 и сохранения независимых ошибок; он не стал общим framework или новым долгоживущим владельцем. Два platform-файла обеспечивают compile-time отсутствие Windows symbol на других платформах, без пустых публичных wrappers.

Общий verifier и раскладка memory counters переиспользованы. Из `ResidentSetSizeByPID` вынесено только синхронное чтение по уже имеющемуся handle; это реально разделяемая операция между старым скалярным и новым объединённым путём, не абстракция на будущее. Память, identity и port policy не дублируются по новым registry/manager слоям.

Заметный размер тестов связан с различными требуемыми outcomes и параллельностью. Основания удалять проверки ради меньшего diff не найдены. Производственная правка +169/−14 строк остаётся одной ответственностью: согласованное native status observation и его потребитель. **Вывод прежнего scope-аудита сохраняется: разумно продолжать существующий #628**, актуализировав его название/описание и добавив отдельные доказательства новой реализации. Нового PR либо переноса кода #659 эта граница не требует.

Сохранённые benchmark и evidence #628 не менять и не объявлять приёмкой нового кода; сравнение двух полей собственного процесса по-прежнему относится к историческому точному исходнику. В новом изменении нет основания утверждать ускорение приложения или завершение R16 целиком.

<a id="remaining"></a>
## 7. Остаток до заявления о готовности

1. Root выполняет gofmt, собственное чтение окончательного diff и адресные проверки точного общего дерева; они не выполнены данным проверяющим.
2. При смысловых изменениях после таблицы 2 повторно прочитать изменённую границу; форматирование отличать от изменения поведения.
3. Зафиксировать реальные exit codes, test/subtest outcomes и ограничения. Полные ранее неуспешные Go-критерии адресным результатом не снимать.
4. При публикации продолжить существующий #628 без интеграции других веток, сохранить точные старые доказательства и обновить активный остаток плана. Новые измерения допустимы только при отдельном конкретном вопросе.

<a id="sources"></a>
## 8. Источники

1. Прочитанный proposed source: `<LOCAL_REVIEW_ROOT>/r16-status-audit/source/internal/cli` и `<LOCAL_REVIEW_ROOT>/r16-status-audit/source/internal/process`; точные SHA-256 — таблица 2.
2. [Baseline status](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/cli/supervise_status.go), [baseline liveness](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/cli/supervise_liveness.go).
3. [Identity helpers](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/process/pid_identity_windows.go), [общий proof и state](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/process/terminate_pid.go), [допуск времени создания](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/process/pid_identity_common.go), [скалярный RSS](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/process/process_rss_windows.go).
4. [Исходный native child](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/process/pid_identity_windows_test.go), [старые RAM tests](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/cli/supervise_status_ram_test.go), [старые snapshot tests](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/cli/supervise_status_snapshot_test.go), [старые liveness tests](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/internal/cli/supervise_liveness_test.go).
5. [Предыдущий scope-аудит](scope.md), [независимое native-ревью и исправленный P2](native-implementation-review.md), [самостоятельное ревью автора CLI](cli-review.md). Последние два отчёта не заменяли чтение исходников.
