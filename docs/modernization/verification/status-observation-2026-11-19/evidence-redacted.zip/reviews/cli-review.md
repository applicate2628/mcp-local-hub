# R16: самостоятельное ревью CLI-изменения

## Результат и граница

Подготовлены **пять Go-файлов только в CLI staging** на базе #628 `9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9`. Хэши GitHub blobs двух изменённых исходных файлов совпали с прочитанной базой master `a7d92d2852c4f6eb8afb0569ef76a545e38aacf7`: `supervise_status.go` — `eb14c0e3fd7cf2854c3a0a0ea642008a37ce8565`, `supervise_liveness.go` — `0bddde41d34889d79e3407754bf5b0e107dc1b39`.

Изменены `source/internal/cli/supervise_status.go` и `supervise_liveness.go`; добавлены `supervise_status_process_windows.go`, `supervise_status_process_other.go`, `supervise_status_process_test.go`. Native process implementation принадлежит root и этим агентом не менялась. Команды тестирования, сборки, измерения, удалённые команды и GitHub mutations **не выполнялись**. Статус готовности к исполнению или прохождение тестов не заявляются.

## Что изменилось

В `supervisorLivenessProbe` добавлен optional callback `PIDStatus`. Windows default связывает его с согласованным `process.ObservePIDStatus`; вне Windows он имеет typed nil. Общий `supervisorDaemonLivenessVerdictWithProbe` не менялся и не обращается к новому field. Старые тесты, заменяющие всю структуру probe, сохраняют скалярные `PIDAlive`, `PIDIdentity`, `rssByPID`.

Обычная Running-строка status создаёт **локальную копию** probe. Её `PIDAlive` выполняет одно наблюдение с ожидаемым PID, daemon command и tracker start time; `PIDIdentity` возвращает сохранённый обязательный error. Если разрешение `PATH`/символической ссылки между двумя каноническими gates изменило ожидаемый proof, callback сохраняет `ErrProcessIdentityMismatch`, соединяя его с исходной ошибкой. Это устраняет риск принять наблюдение A как доказательство другого ожидаемого image B.

Память выдаётся из этого же результата только при `State == PIDStateAlive`, `err == nil`, известном положительном числе байтов и прежнем разрешающем state/PID условии строки. После выбора combined observer нет fallback к `rssByPID`, даже когда память или обязательное наблюдение недоступны. `stopPending` сохраняет прежний отдельный скалярный RAM-путь; состояния `Stopping`/`Failed` не получают нового обязательного identity gate.

## Конкретная самостоятельная проверка чтением

**Таблица 1. Проверенные свойства кода, без runtime PASS.**

| Требование | Проверенный участок / результат чтения |
|---|---|
| Не копировать classifier | Изменение передаёт `rowProbe` прежнему `supervisorDaemonEntryLiveWithProbe`. Port/grace, unsupported, target provenance и restart policy остались в старом предикате |
| Не менять autonomous sweep / readiness | Новый field читается только в status; constructor назначает capability, но canonical predicate его не вызывает |
| Не принимать иной proof | `pidStatusProof` сохраняется перед callback; весь сравнимый `PIDIdentityProof` проверяется в `PIDIdentity`, ошибка несоответствия включается в сохранённый error |
| Missing identity не обходится | Нулевой PID отсекается существующим predicate до observation. Нулевой `StartedAt` кодируется пустой строкой через `daemonRuntimeStartedAt`; канонический missing gate остаётся после PIDAlive. Искусственного `PIDAlive=true` нет |
| Обязательный error не превращается в память | Выдача RAM требует `pidStatusErr == nil`; Unknown/Dead не дают положительного PIDAlive. Error при Alive передаётся canonical identity gate |
| Не маскировать ошибку метрики повторным lookup | `usedPIDStatus` выбирается до вызова observer; scalar RSS находится только в `else`. Unknown/zero bytes не вызывают fallback |
| Не смешивать параллельные запросы | Результат, proof, error, row probe и used flag локальны одной итерации. Новых глобальных активных handles, кешей, mutex или goroutines нет |
| Не удерживать tracker lock | В callback используются значения уже полученного runtime snapshot; новый код не берёт tracker lock. Native вызывается на прежнем уровне после `Snapshot()` |
| Не менять stop receipt | Combined adapter создаётся только внутри прежнего `!stopPending` условия. Ниже используется тот же local `stateText`, включая историческую RAM-особенность Stopping/Failed |
| Не менять Unix default | Отдельный `!windows` файл задаёт typed nil; native symbol `ObservePIDStatus` упоминается только в `windows` файле |
| Публичные поля | Сохраняются map keys, numeric RAM type, tracker `started_at`, port error exception, current/stale PID projection. Никакого native результата/handle в JSON не добавлено |

В статическом diff у `supervise_status.go` **+43/−10**, у `supervise_liveness.go` **+5/−0** относительно извлечённых исходников; изменения комментария отдельно уточняют eager RAM. `git diff --no-index --check` для этих файлов и нового тестового файла не вывел замечаний по пробелам. Его код 1 относится к no-index сравнению разных файлов; он не представлен как успешный тест. `gofmt` не запускался: исполняемый файл не найден в scratch `PATH`; окончательное форматирование и компиляция остаются за общим проходом root.

## Написанные адресные тесты

Все имена соответствуют селектору `TestSupervisorStatusPID.*`. В новом файле **7 test-функций**, 12 явно именованных subtests, без `t.Parallel`.

**Таблица 2. Назначение тестов.**

| Тест | Наблюдаемый oracle |
|---|---|
| `TestSupervisorStatusPIDObservationProjectsResults` | Восемь осмысленных исходов: успешное наблюдение, unknown/zero RAM, обязательный error, unknown liveness/error, exit, port snapshot error, foreign owner. Сравнивается полная status map; проверяется неизменность tracker и запрет всех трёх scalar paths после выбора observer |
| `...KeepsMissingIdentityGate` | Нулевой PID не вызывает observer; пустой start не принимается даже permissive observer, который вернул Alive и RAM |
| `...KeepsPendingStopRAM` | Отдельно Stopping и Failed: combined observer/liveness не вызываются, прежняя optional RAM и receipt сохраняются |
| `...RejectsChangedCommandProof` | Реальный producer получает bare command из PATH A; observer меняет PATH на B с другим lookup fixture. Canonical второй proof отличается, и строка обязана стать Restarting без RAM. Fixture-файлы не исполняются; ни child process, ни symlink permissions не нужны |
| `...DoesNotChangeCanonicalLiveness` | При наличии field canonical predicate использует прежние scalar callbacks; status observer является запрещённым sentinel |
| `...ConcurrentRequestsStayLocal` | Первый status блокируется внутри observer; tracker обновляется, второй status завершается со своим PID/start/RAM, затем завершается первый со своим snapshot. Каналы задают порядок; cleanup отпускает и присоединяет все запущенные goroutines до восстановления globals |
| `...PlatformDefault` | Windows default содержит callback, остальные сборки — nil; function pointer reflection не используется |

`reflect.DeepEqual` применяется только в тестовом oracle полной map, не для определения того, является ли production probe тестовой подменой. Existing RAM tests продолжают служить проверкой nil-observer fallback; их код не переписан. New tests используют имеющиеся `withFakeRSS`, `withFakePortOwnersSnapshot`, `beginStopSettlementForTest`; последний helper дополнительно прочитан на точной #628 базе, он создаёт receipt через tracker owner без запуска процесса.

## Оставшиеся пределы

Ни один из написанных тестов ещё не исполнялся; количество написанных cases не является числом PASS. Сборка, форматирование, race-enabled запуск и native-process tests должны быть выполнены совместно после готовности обоих участков.

Eager optional RSS может быть прочитан внутри observer до последующего отрицательного port verdict; поле при этом не выдаётся. Один handle обеспечивает привязку полей к объекту процесса, но не одновременность tracker/port/RAM и не сохранение liveness после возврата. Новая политика native close error также является отдельным улучшением относительно старых helpers, игнорировавших CloseHandle error; нельзя заявлять абсолютную идентичность всех отказов.

Нативная привязка image/time/RAM, права, последовательность final wait/close и сохранение независимых ошибок проверяются в process-части root. CLI-чтение не квалифицирует чужого владельца, полный Windows Product, Unix native отказы или производительность всего status.
