## Связанный Go-контракт R16 — 18–19 ноября 2026 (МСК)

Выбранный картой PID-only/metrics-fallback контракт реализован в самостоятельном [Draft #659](https://github.com/applicate2628/mcp-local-hub/pull/659), `a3568df`: ошибка наблюдения порта отделена от отсутствия, сохранены статусные метрики, ограничения исполнения и TestMain-изоляция. [Отчёт и границы](https://github.com/applicate2628/mcp-local-hub/blob/a3568dfe3426afaca4176d57a2310097e5214e77/docs/modernization/verification/port-observation-2026-11-18/RESULTS.md) · [проверка точного опубликованного коммита](https://github.com/applicate2628/mcp-local-hub/pull/659#pullrequestreview-5965249309).

Это исправление владельца `internal/api` не зависит от измерительного helper этого PR. **Head #628 остаётся `9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9`; его исходники и сохранённые измерения не менялись и не повторялись.** Адресный PASS #659 не является новым результатом #628; оба полных Go gate на коде исправления остаются FAIL. Основания закрыть #628 как полностью поглощённый не получены. Реальный status, commandline/PPID/CIM и нативная приёмка остаются отдельными задачами.

## Исходная карта реальных потребителей — 18 ноября 2026

[Карта R16 и следующий контракт](https://github.com/applicate2628/mcp-local-hub/blob/385d0ae7a58012001ec06ebddc658bcd90c1fd18/docs/modernization/plans/measurement-consumers-2026-11-18.md#process). Единственный production caller RSS — supervisor status. Обычная успешная Windows-строка может открыть CurrentPID трижды: liveness, image/creation и RSS; это другой сценарий, чем буквальная пара helper-функций benchmark. Два production helper blob совпали с master.

Установлены operation-local snapshots/batches, HTTP/status cache и существующие retained owners. Пять из шести `lookupProcess` call sites используют только PID/ok; status fallback читает также RAM/uptime. Карта выбрала совместное сохранение PID-only получения, metrics fallback, found/absent/unknown, timeout/WaitDelay, Unix и TestMain seal. Этот узкий контракт теперь реализован отдельно в #659. Ветви смешения ошибки запроса с отсутствием существовали до #628; его измерительные исходники их не исправляют.

Решение — сохранить Go и существующих владельцев; Rust или глобальный process registry не обоснованы. Полный commandline/PPID census и R17 scheduler остаются отдельными. **HEAD `9c2ae02b` не менялся; сохранённая серия не повторялась, новых тестов/измерений нет.**

## Проверяемый результат — 18 ноября 2026

**Текущий HEAD: `9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9`, Draft.** Чистый измеренный исходник: `c028db723295f02909969b57f9d1ee8837a22344`. Новые коммиты добавляют только каталог доказательств; производственные исходники, тесты и зависимости неизменны.

[Отчёт, исходные журналы и воспроизведение](https://github.com/applicate2628/mcp-local-hub/blob/9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9/docs/modernization/verification/native-observation-2026-11-18/RESULTS.md).

- Windows build 22631, Intel Core i5-10400, Go 1.27.4, `GOMAXPROCS=4`, существующие offline-кеши.
- Два теста native observation с `-race -count=3`: **6 PASS, 0 FAIL/SKIP**. `go vet ./internal/process` — exit 0.
- Все 3 пробных сочетания и **30** основных образцов прошли. Медианы для двух полей собственного процесса: **3175,500 нс** при двух открытиях, **1875,000 нс** при одном и **564,150 нс** при удерживаемом дескрипторе. Во всех режимах **104 B/op, 2 allocs/op** — выделенных байтов и выделений памяти на операцию.
- В `logs.zip` сохранены 14 исходных файлов, точные аргументы и коды возврата; `manifest.json` и `SHA256SUMS` проверены по байтам коммита. Атрибуты только этого каталога исключают изменение контрольных сумм при преобразовании концов строк.

Приобретение удерживаемого дескриптора исключено из его таймера. Другие процессы, отказы доступа, полный снимок процесса и выигрыш всего Hub не измерены. Старые числа остаются историческими; полной приёмки, независимого безопасностного PASS и выигрыша Rust нет. Слияния, установки и ручной CI не выполнялись.

---

## Ревью представительности — 18 ноября 2026

Самостоятельно и независимо проверены изменённый измерительный исходник, существующие функции наблюдения и границы данных. Нового введённого дефекта не установлено. Два поля собственного процесса и дескриптор, открытый до начала таймера, не квалифицируют весь снимок процессов, длительное удержание ресурсов или необходимость Rust/общего реестра.

[Ревью точного текущего коммита](https://github.com/applicate2628/mcp-local-hub/pull/628#pullrequestreview-5962471074). Сохранённые выборки, тесты и сборки в этом проходе **не повторялись**. Полного поглощения PR другими изменениями не доказано; самостоятельная ответственность сохраняется. Черновой статус и полные обязательные проверки остаются открытыми.

## Исторические записи

## Исторический checkpoint — 14 ноября 2026

**Head на 14 ноября: `c028db723295f02909969b57f9d1ee8837a22344`. Accepted master: `17bc78fc602efa204a74596409c939a3bf1ddc42`.**

Синхронизация с принятым master без изменения observation patch. Оба native-observation tests прошли race×3; go vet ./internal/process прошёл. Старые benchmark результаты не выдаются за новые замеры.

[Versioned branch audit, checks and reserved work](https://github.com/applicate2628/mcp-local-hub/blob/21442f167b02bb3de5b2ba42a9df1adfed672254/docs/modernization/verification/branch-audit-2026-11-14/RESULTS.md).

История сохранена обычными fast-forward updates двухродительских merge-коммитов, без force-push. Не выполнены merge в master, установка, изменения активной чужой сессии или явный bot/CI dispatch.

---

## Historical implementation and verification record

Следующее описание относится к прежнему head и сохраняется как история; текущая база и свежие проверки указаны выше.

## RX-16: сначала проверить существующий native Go

Один Windows-only `_test.go` файл. Производственные helpers, API, зависимости и установка не меняются. Выполняется часть #623: не приписывать языку выигрыш от устранения повторных системных операций.

**Exact head:** `30dc96ded0110984bd66e149d125c3d1178bf1da`, база `76d11b33`. Новая работа #616 не затронута; `process_start_time_windows.go`/`process_rss_windows.go` на #616 `53645ec7` совпадают с измеренной базой.

### Что измеряется

Только текущий собственный тестовый процесс, два поля: kernel creation time и working-set bytes. Сравнение:

1. Существующие Go helpers: отдельный OpenProcess/CloseHandle для каждого поля.
2. Те же нативные API и существующая структура memory counters: один open/query/close на оба поля.
3. Те же queries через уже удерживаемый handle; **цена его приобретения находится вне timed loop** и не скрывается.

Никакого перечисления пользовательских процессов/command lines, COM/WMI/CIM, shell, subprocess или права terminate. Это диагностическое наблюдение, не creator authority.

### Реальные результаты

Windows 11 build 26100 / amd64, Core i7-14700K, Go 1.27.3, GOMAXPROCS=4, локальный toolchain/cache. По 10 повторов `-benchtime=1s`:

| Режим | Медиана, нс/два поля | Min–max, нс | Аллокации |
|---|---:|---:|---:|
| Два существующих open | 1872.5 | 1791–2043 | 104 B/op, 2 allocs/op |
| Один open на наблюдение | 1069.5 | 1061–1192 | 104 B/op, 2 allocs/op |
| Удерживаемый handle | 341.35 | 336.6–366 | 104 B/op, 2 allocs/op |

**Вывод ограниченный:** текущие native Go helpers уже микросекундные. Для этих двух полей сначала устранять повторное открытие/использовать существующего владельца. Само по себе это не обосновывает Rust rewrite и не измеряет общий эффект для Хаба.

Полный legacy snapshot также использует parent PID, executable path, command line и attribution rules. Этот опыт **не заменяет его**: отсутствие недоступного поля нельзя выдавать за отсутствие процесса. COM removal требует отдельной проверки потребителей и контракта unknown/denied/unsupported.

### Проверки

- Отрицательный zero-result stub: тесты обнаружили неверную creation identity и ошибочную успешную интерпретацию invalid handle.
- Затем реальные queries: `TestNativeObservationMatchesSelfCreation` сверяет creation time с текущим helper, проверяет ненулевой own RSS и сохранность borrowed handle после повторных чтений.
- `TestNativeObservationFailureIsNotAbsent`: invalid handle возвращает ошибку; неверный PID не становится успешным нулевым наблюдением.
- `go test -race ./internal/process -run '^TestNativeObservation' -count=3` прошёл. Это scope двух новых tests, не все native paths.
- Все 30 benchmark samples прошли проверки результата. No install/download/privilege/runtime/config changes.

### Непройденный baseline gate не скрыт

`go vet ./internal/process` предупреждает о `unsafe.Pointer` в **существующем** `proc_thread_attribute_observed.go:56,67,73,95`. Тот же отказ воспроизведён на неизменённом master с новым файлом временно вынесенным и затем восстановленным. **Не заявляется package-vet PASS или merge-ready.** Отдельные исправления текущего PR #616 могут менять собственные gates; они не засчитываются этому снимку автоматически.

### Команды

```sh
go test -race ./internal/process -run '^TestNativeObservation' -count=3
go test ./internal/process -run '^$' -bench '^BenchmarkNativeProcessObservation$' -benchtime=1s -count=10 -benchmem
```

Осталось: representative process counts/poll frequencies, реальные чужие denied/exit/reuse cases под owned fixtures, fuller observation contract, Linux/macOS и сравнение у принимаемого владельца. Нет Rust implementation, COM-replacement claim, независимого review или полного repository gate.

**Draft; без merge, CI/bot dispatch и изменения working installation.**
