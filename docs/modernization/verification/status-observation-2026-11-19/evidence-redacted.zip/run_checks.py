"""Bounded status-observation checks, using existing offline Windows tools."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

SOURCE = Path(r"<SOURCE>")
WORK = Path(r"<WORK>")
GO = Path(r"<GO_BIN>\go.exe")
GIT = Path(r"<GIT>")
BASE = "9c2ae02bc1c3a5cf2e1fcd16101043d63bbd6fd9"
phase = sys.argv[1]
out = WORK / phase
out.mkdir(exist_ok=False)
runtime_dir = WORK / "runtime" / phase
for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "cross"):
    (runtime_dir / name).mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("MCPHUB_")}
env.update({
    "GOROOT": r"<GO_ROOT>", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "",
    "GOCACHE": r"<GO_CACHE_ROOT>\gocache",
    "GOMODCACHE": r"<GO_CACHE_ROOT>\gomodcache",
    "GOPATH": str(runtime_dir / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1",
    "MCPHUB_E2E_SCHEDULER": "none", "USERPROFILE": str(runtime_dir / "profile"),
    "APPDATA": str(runtime_dir / "appdata"), "LOCALAPPDATA": str(runtime_dir / "localappdata"),
    "TEMP": str(runtime_dir / "tmp"), "TMP": str(runtime_dir / "tmp"),
    "TMPDIR": str(runtime_dir / "tmp"), "GOTMPDIR": str(runtime_dir / "tmp"),
    "PYTHONDONTWRITEBYTECODE": "1",
})
env["PATH"] = str(GO.parent) + os.pathsep + env.get("PATH", "")
for p in (GO, GO.with_name("gofmt.exe"), Path(env["CC"]), Path(env["GOROOT"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    assert p.exists(), p
spec = json.loads((WORK / "files.json").read_text(encoding="utf-8"))
paths = [f["path"] for f in spec]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output([str(GIT), "-C", str(SOURCE), *args], env=env, text=True).strip()

receipt = {"phase": phase, "base": BASE, "head": git("rev-parse", "HEAD"),
           "go_version": subprocess.check_output([str(GO), "version"], env=env, text=True).strip(),
           "windows": list(sys.getwindowsversion()[:3]), "runner_sha256": digest(Path(__file__)),
           "environment": {k: env[k] for k in ("GOPROXY", "GOSUMDB", "GOVCS", "GOTOOLCHAIN", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")},
           "source_sha256_before": {p: digest(SOURCE / p) for p in paths}, "commands": []}
assert receipt["head"] == BASE or phase.startswith("published"), receipt["head"]

def save():
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

def run(name, args, executable=GO, overrides=None):
    command_env = dict(env)
    command_env.update(overrides or {})
    stdout, stderr = out / (name + ".stdout.log"), out / (name + ".stderr.log")
    record = {"name": name, "executable": executable.name, "arguments": args,
              "environment_overrides": overrides or {}, "started_utc": datetime.now(timezone.utc).isoformat()}
    print("START", name, flush=True)
    start = time.monotonic()
    with stdout.open("wb") as fo, stderr.open("wb") as fe:
        done = subprocess.run([str(executable), *args], cwd=SOURCE, env=command_env, stdout=fo, stderr=fe)
    record.update({"exit_code": done.returncode, "seconds": round(time.monotonic() - start, 3),
                   "finished_utc": datetime.now(timezone.utc).isoformat(),
                   "stdout_sha256": digest(stdout), "stderr_sha256": digest(stderr), "stderr_bytes": stderr.stat().st_size})
    if "-json" in args and args[0] == "test":
        events = []
        for line in stdout.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                continue
        record["tests"] = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a]
                           for a in ("pass", "fail", "skip")}
    receipt["commands"].append(record)
    save()
    print(json.dumps({k: record[k] for k in ("name", "exit_code", "seconds", "stderr_bytes")}), flush=True)
    return record

contract = "^(TestObservePIDStatus.*|TestSupervisorStatusPID.*|TestDefaultSupervisorStatusPID.*)$"
affected = "^(TestObservePIDStatus.*|TestResidentSetSizeByPID.*|TestNativeObservation.*|TestExecutablePathMatches.*|TestNormalizeWindowsExecutablePath.*|TestSupervisorStatus.*|TestDefaultSupervisor.*|TestSupervisorDaemonEntryLive.*|TestSupervisorLiveness.*|TestDispatchIPCRequest.*Status.*)$"
if phase.startswith("format"):
    if phase == "format":
        assert all(digest(SOURCE / f["path"]) == f["sha256"] for f in spec), "source transfer mismatch"
    assert run("gofmt", ["-w", *paths], GO.with_name("gofmt.exe"))["exit_code"] == 0
    assert run("diff-check", ["diff", "--check"], GIT)["exit_code"] == 0
    files = [{"path": p, "content": (SOURCE / p).read_text(encoding="utf-8"), "sha256": digest(SOURCE / p)} for p in paths]
    (out / "formatted-files.json").write_text(json.dumps(files, ensure_ascii=False), encoding="utf-8")
elif phase.startswith("contract") or phase.startswith("published"):
    run("contract-race", ["test", "-mod=readonly", "-json", "-race", "-count=2", "-timeout=120s", "-run", contract, "./internal/process", "./internal/cli"])
    run("contract-tagged-race", ["test", "-mod=readonly", "-json", "-race", "-tags=test_state_path_env", "-count=1", "-timeout=120s", "-run", contract, "./internal/process", "./internal/cli"])
elif phase == "affected":
    run("affected-race", ["test", "-mod=readonly", "-json", "-race", "-count=1", "-timeout=300s", "-run", affected, "./internal/process", "./internal/cli"])
    run("affected-tagged-race", ["test", "-mod=readonly", "-json", "-race", "-tags=test_state_path_env", "-count=1", "-timeout=300s", "-run", affected, "./internal/process", "./internal/cli"])
elif phase == "gates":
    for name, args in (("build", ["build", "./..."]), ("vet", ["vet", "./..."]),
                       ("full-test", ["test", "-count=1", "-timeout", "5m", "./..."]),
                       ("state-tag-full", ["test", "-tags=test_state_path_env", "-count=1", "-timeout", "5m", "./internal/api/", "./internal/cli/"])):
        run(name, args)
elif phase == "cross-build":
    run("linux-compile", ["test", "-mod=readonly", "-c", "-o", str(runtime_dir / "cross"), "./internal/process", "./internal/cli"],
        overrides={"GOOS": "linux", "GOARCH": "amd64", "CGO_ENABLED": "0"})
elif phase == "controls":
    target = SOURCE / "internal/process/pid_status_windows.go"
    original = target.read_bytes()
    old = b"state, waitErr := pidStatusState(h, ops.wait)"
    new = b"state, waitErr := PIDStateAlive, error(nil)"
    assert original.count(old) == 1
    changed = original.replace(old, new)
    (out / "final-wait.original.go").write_bytes(original)
    (out / "final-wait.mutated.go").write_bytes(changed)
    try:
        target.write_bytes(changed)
        record = run("omitted-final-wait", ["test", "-mod=readonly", "-json", "-count=1", "-timeout=120s", "-run",
                                          "^TestObservePIDStatusNativeExitDuringObservation$", "./internal/process"])
        output = "".join(json.loads(line).get("Output", "") for line in (out / "omitted-final-wait.stdout.log").read_text().splitlines() if line.startswith("{"))
        receipt["control_matched"] = (record["exit_code"] == 1 and record["stderr_bytes"] == 0
            and record["tests"]["fail"] == ["TestObservePIDStatusNativeExitDuringObservation", "PACKAGE:mcp-local-hub/internal/process"]
            and not record["tests"]["skip"] and "exited original observation=" in output)
    finally:
        target.write_bytes(original)
        receipt["control_restored_exact_bytes"] = target.read_bytes() == original
        save()
    assert receipt["control_matched"] and receipt["control_restored_exact_bytes"]
else:
    raise ValueError(phase)
receipt["source_sha256_after"] = {p: digest(SOURCE / p) for p in paths}
receipt["source_stable"] = phase.startswith("format") or receipt["source_sha256_after"] == receipt["source_sha256_before"]
receipt["status_after"] = git("status", "--porcelain=v1", "--untracked-files=all")
save()
assert receipt["source_stable"]
print("COMPLETE", phase, flush=True)
