"""Materialize pinned source from existing non-trash caches; execute no tests."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-owners-20261122-e51f")
RUNNER = "3d691d1e2d78b3d81abc29ee64162ab04d299246da31039b7e76fc422b85108a"
BUNDLE = "9c578ef7e2f1a58710fd748ab59c4399e7f80505eee929be28fd50a8bc8d7d55"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
CACHE = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\arch-input\source-arch")
PRESERVED = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")
helper = ROOT / "qualify_go.py"
if hashlib.sha256(helper.read_bytes()).hexdigest() != RUNNER:
    raise RuntimeError("Runner differs from reviewed source")
spec = importlib.util.spec_from_file_location("qualify_go", helper)
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def guard(path):
    path.relative_to(Path(r"D:\dev\ChatGPT"))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.exists():
            info = current.lstat()
            if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Reparse path refused")

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 2 or sys.argv[1] not in ("architecture", "scheduler"):
        raise RuntimeError("Unexpected bootstrap entry")
    phase = sys.argv[1]
    raw = q.own("source-inputs.b64").read_bytes()
    if q.sha(raw) != BUNDLE:
        raise RuntimeError("Source manifest transport changed")
    inputs = json.loads(zlib.decompress(base64.b64decode(raw, validate=True)))
    source = inputs[phase]
    out = q.own("evidence/bootstrap-" + phase)
    runtime = q.own("runtime/bootstrap-" + phase)
    out.mkdir(parents=True, exist_ok=False)
    runtime.mkdir(parents=True, exist_ok=False)
    env = q.environment(runtime, {})
    receipt = {"phase": phase, "started_utc": q.now(), "completed": False, "runner_sha256": RUNNER,
               "bootstrap_sha256": q.sha(Path(__file__).read_bytes()), "source_bundle_sha256": BUNDLE,
               "source_head": source["head"], "source_tree": source["tree"], "commands": [],
               "tests_executed": False, "native_scheduler_operations": False, "installed_product_operations": False,
               "dependency_downloads": False, "whole_process_tree_settlement_claimed": False}

    def run(label, args, cwd, timeout=300):
        row = {"label": label, "argv": [str(GIT), *map(str, args)], "cwd": str(cwd), "started_utc": q.now(),
               "settled": False, "timed_out": False, "whole_process_tree_deadline_enforced": False}
        receipt["commands"].append(row)
        q.save(out / (label + ".started.json"), row)
        child = None
        start = time.monotonic()
        try:
            with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
                child = subprocess.Popen(row["argv"], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                row["pid"] = child.pid
                q.save(out / (label + ".launched.json"), row)
                try:
                    row["exit_code"] = child.wait(timeout=timeout)
                    row["settled"] = True
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    raise
        finally:
            if child is not None and not row["settled"]:
                row.update(process_tree_unresolved=True, retain_runtime_and_logs=True,
                           termination_method="Popen.terminate with retained original direct-child handle")
                child.terminate()
                row["exit_code"] = child.wait(timeout=10)
                row["settled"] = True
            row.update(seconds=time.monotonic() - start, finished_utc=q.now())
            for stream in ("stdout", "stderr"):
                p = out / (label + "." + stream + ".log")
                if p.exists():
                    data = p.read_bytes()
                    row[stream] = {"bytes": len(data), "sha256": q.sha(data)}
            q.save(out / (label + ".receipt.json"), row)
        if row["exit_code"] != 0 or row["timed_out"]:
            raise RuntimeError("Bootstrap command failed: " + label)
        return (out / (label + ".stdout.log")).read_bytes().decode("utf-8").strip()

    try:
        for tool, expected in q.PINS.items():
            if q.sha(Path(tool).read_bytes()) != expected:
                raise RuntimeError("Existing tool changed: " + tool)
        receipt["tools_sha256"] = q.PINS
        receipt["git_sha256"] = q.sha(GIT.read_bytes())
        version = q.execute(out, env, {"label": "go-version", "tool": "go", "args": ["version"], "timeout_seconds": 30,
                                     "expected_exit_code": 0, "required_output": ["go version go1.27.4 windows/amd64"]}, ROOT)
        receipt["commands"].append(version)
        if not version["oracle_pass"]:
            raise RuntimeError("Go version refused")
        if phase == "architecture":
            guard(CACHE)
            dest = q.own("architecture")
            if dest.exists():
                raise RuntimeError("Fresh source destination already exists")
            run("clone-cache", ["-c", "core.autocrlf=false", "clone", "--no-hardlinks", "--no-checkout", CACHE, dest], ROOT)
            run("set-origin", ["remote", "set-url", "origin", "https://github.com/applicate2628/mcp-local-hub.git"], dest)
            run("fetch-source", ["fetch", "--no-tags", "origin", source["head"]], dest)
            run("checkout-source", ["-c", "core.autocrlf=false", "checkout", "--detach", source["head"]], dest)
            if run("source-tree", ["rev-parse", "HEAD^{tree}"], dest) != source["tree"] or run("source-clean", ["status", "--porcelain"], dest):
                raise RuntimeError("Architecture source identity differs")
            receipt["source_inventory"] = q.check_files("architecture", source["files"], True)
        else:
            guard(PRESERVED)
            if run("source-head", ["rev-parse", "HEAD"], PRESERVED) != source["head"] or run("source-tree", ["rev-parse", "HEAD^{tree}"], PRESERVED) != source["tree"]:
                raise RuntimeError("Preserved source identity differs")
            if q.own("source").exists():
                raise RuntimeError("Fresh preserved-source destination already exists")
            for row in source["files"]:
                path = PRESERVED / row["path"]
                guard(path)
                data = path.read_bytes()
                if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                    raise RuntimeError("Preserved source changed: " + row["path"])
                dest = q.own("source/" + row["path"])
                dest.parent.mkdir(parents=True, exist_ok=True)
                with dest.open("xb") as stream:
                    stream.write(data)
            receipt["source_inventory"] = q.check_files("source", source["files"], True)
        if q.sha(GIT.read_bytes()) != receipt["git_sha256"]:
            raise RuntimeError("Git changed during preparation")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        q.save(out / "receipt.json", receipt)
        print(json.dumps({k: receipt.get(k) for k in ("phase", "completed", "error", "source_inventory", "git_sha256")}), flush=True)

if __name__ == "__main__":
    main()
