"""Materialize admitted GUI candidate and one-file behavior control; execute nothing."""
import sys
sys.dont_write_bytecode = True
import base64
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-owners-20261122-e51f")
RUNNER_SHA = "3d691d1e2d78b3d81abc29ee64162ab04d299246da31039b7e76fc422b85108a"

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 2:
        raise RuntimeError("Wrong environment or bundle pin")
    runner=ROOT/"qualify_go.py"
    if hashlib.sha256(runner.read_bytes()).hexdigest()!=RUNNER_SHA:
        raise RuntimeError("Runner changed")
    spec=importlib.util.spec_from_file_location("owned_q",runner);q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    raw=(ROOT/"architecture-stage.b64").read_bytes()
    if q.sha(raw)!=sys.argv[1]:raise RuntimeError("Stage bundle differs")
    config=json.loads(gzip.decompress(base64.b64decode(raw,validate=True)))
    if config["schema"]!=1 or config["native_scheduler_operations"] is not False:raise RuntimeError("Wrong scope")
    allowed={"internal/gui/"+n for n in ("gui_owner_lifecycle.go","single_instance.go","gui_owner_lifecycle_test.go","gui_owner_policy_test.go")}
    if {r["path"] for r in config["candidates"]}!=allowed or len(config["candidates"])!=4:raise RuntimeError("Unadmitted source changes")
    out=q.own("evidence/apply-architecture");out.mkdir(parents=True,exist_ok=False)
    receipt={"started_utc":q.now(),"completed":False,"bundle_sha256":q.sha(raw),"helper_sha256":q.sha(Path(__file__).read_bytes()),
             "runner_sha256":RUNNER_SHA,"tests_executed":False,"native_scheduler_operations":False,"source_head":"c7617d1027888271a83c3b724171e1363289995e"}
    q.save(out/"receipt-initial.json",receipt)
    try:
        receipt["source_before"]=q.check_files("architecture",config["source_before"],True)
        receipt["candidate_inputs"]=q.check_files("inputs/candidate/architecture",config["candidates"],True)
        for row in config["candidates"]:
            data=q.own("inputs/candidate/architecture/"+row["path"]).read_bytes()
            q.own("architecture/"+row["path"]).write_bytes(data)
        receipt["source_after"]=q.check_files("architecture",config["source_after"],True)
        receipt["payloads"]=[]
        for row in config["payloads"]:
            if not row["path"].startswith(("inputs/architecture-control/","plans/architecture-owner-")):raise RuntimeError("Unadmitted payload location")
            data=base64.b64decode(row["content"],validate=True)
            if len(data)!=row["bytes"] or q.sha(data)!=row["sha256"]:raise RuntimeError("Payload differs")
            p=q.own(row["path"]);p.parent.mkdir(parents=True,exist_ok=True)
            with p.open("xb")as f:f.write(data)
            receipt["payloads"].append({k:row[k] for k in ("path","bytes","sha256")})
        receipt["controls"]=q.check_files("inputs/architecture-control",config["control_files"],True)
        overlay=json.loads(q.own("inputs/architecture-control/overlay.json").read_text())
        expected={str(q.own("architecture/internal/gui/gui_owner_lifecycle.go")):str(q.own("inputs/architecture-control/internal/gui/gui_owner_lifecycle.go"))}
        if overlay!={"Replace":expected}:raise RuntimeError("Unadmitted overlay membership")
        receipt["overlay_membership_exact"]=True
        receipt["completed"]=True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__,error=str(error));raise
    finally:
        receipt["finished_utc"]=q.now();q.save(out/"receipt.json",receipt)
        print(json.dumps({k:receipt.get(k) for k in ("completed","error","source_before","source_after","controls")}),flush=True)

if __name__=="__main__":main()
