"""Stage eight admitted candidate files and format only their owned copies."""
import sys
sys.dont_write_bytecode = True
import base64
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-owners-20261122-e51f")
RUNNER_SHA = "3d691d1e2d78b3d81abc29ee64162ab04d299246da31039b7e76fc422b85108a"

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != ROOT or len(sys.argv) != 2:
        raise RuntimeError("Wrong environment or bundle pin")
    runner = ROOT / "qualify_go.py"
    if hashlib.sha256(runner.read_bytes()).hexdigest() != RUNNER_SHA:
        raise RuntimeError("Runner changed")
    spec = importlib.util.spec_from_file_location("owned_qualification_runner", runner)
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    bundle = (ROOT / "candidate-inputs.b64").read_bytes()
    if q.sha(bundle) != sys.argv[1]:
        raise RuntimeError("Bundle pin mismatch")
    rows = json.loads(gzip.decompress(base64.b64decode(bundle, validate=True)))
    if len(rows) != 8 or len({r["path"] for r in rows}) != 8:
        raise RuntimeError("Require exactly eight independent admitted Go inputs")
    out = q.own("evidence/format-inputs"); out.mkdir(parents=True, exist_ok=False)
    runtime = q.own("runtime/format-inputs"); runtime.mkdir(parents=True, exist_ok=False)
    receipt = {"started_utc": q.now(), "completed": False, "bundle_sha256": q.sha(bundle),
               "runner_sha256": RUNNER_SHA, "helper_sha256": q.sha(Path(__file__).read_bytes()),
               "native_scheduler_operations": False, "tests_executed": False,
               "whole_process_tree_settlement_claimed": False, "commands": []}
    q.save(out / "receipt-initial.json", receipt)
    try:
        env = q.environment(runtime, {})
        for p, digest in q.PINS.items():
            if q.sha(Path(p).read_bytes()) != digest:
                raise RuntimeError("Installed tool changed: " + p)
        receipt["tools_sha256"] = q.PINS
        inputs = []
        for row in rows:
            path = row["path"]
            if not path.startswith(("architecture/internal/gui/", "scheduler/internal/api/")) or not path.endswith(".go"):
                raise RuntimeError("Unexpected candidate input")
            data = base64.b64decode(row["content"], validate=True)
            if len(data) != row["bytes"] or q.sha(data) != row["sha256"]:
                raise RuntimeError("Candidate input pin mismatch")
            for prefix in ("inputs/preformat/", "inputs/candidate/"):
                p = q.own(prefix + path); p.parent.mkdir(parents=True, exist_ok=True)
                with p.open("xb") as stream:
                    stream.write(data)
            inputs.append({k: row[k] for k in ("path", "bytes", "sha256")})
        receipt["before"] = q.check_files("inputs/candidate", inputs, True)
        cmd = {"label": "gofmt-write", "argv": [str(q.GOFMT), "-w", *[str(q.own("inputs/candidate/" + r["path"])) for r in rows]],
               "cwd": str(ROOT), "started_utc": q.now(), "settled": False, "timed_out": False,
               "whole_process_tree_deadline_enforced": False}
        q.save(out / "gofmt-write.started.json", cmd)
        child = None; start = time.monotonic()
        try:
            with (out / "gofmt-write.stdout.log").open("xb") as stdout, (out / "gofmt-write.stderr.log").open("xb") as stderr:
                child = subprocess.Popen(cmd["argv"], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                         stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                cmd["pid"] = child.pid; q.save(out / "gofmt-write.launched.json", cmd)
                try:
                    cmd["exit_code"] = child.wait(timeout=60); cmd["settled"] = True
                except subprocess.TimeoutExpired:
                    cmd["timed_out"] = True
        finally:
            if child is not None and not cmd["settled"]:
                cmd.update(process_tree_unresolved=True, retain_runtime_and_logs=True,
                           termination_method="Popen.terminate using retained direct-child handle")
                try:
                    child.terminate(); cmd["exit_code"] = child.wait(timeout=10); cmd["settled"] = True
                except BaseException as error:
                    cmd["termination_error"] = type(error).__name__ + ": " + str(error)
            cmd.update(finished_utc=q.now(), seconds=time.monotonic()-start)
            for kind in ("stdout", "stderr"):
                p = out / ("gofmt-write." + kind + ".log")
                if p.exists():
                    raw = p.read_bytes(); cmd[kind] = {"bytes": len(raw), "sha256": q.sha(raw)}
            q.save(out / "gofmt-write.receipt.json", cmd); receipt["commands"].append(cmd)
        if not cmd["settled"] or cmd["timed_out"] or cmd.get("exit_code") != 0:
            raise RuntimeError("Formatter did not settle successfully")
        formatted = []
        for row in rows:
            data = q.own("inputs/candidate/" + row["path"]).read_bytes()
            formatted.append({"path": row["path"], "bytes": len(data), "sha256": q.sha(data), "content": base64.b64encode(data).decode("ascii")})
        final_inventory = [{k: row[k] for k in ("path", "bytes", "sha256")} for row in formatted]
        receipt["after"] = q.check_files("inputs/candidate", final_inventory, True)
        receipt["preformat_unchanged"] = q.check_files("inputs/preformat", inputs, True)
        check = q.execute(out, env, {"label": "gofmt-check", "tool": "gofmt", "args": ["-l", *[str(q.own("inputs/candidate/"+r["path"])) for r in rows]],
                                    "timeout_seconds": 60, "expected_exit_code": 0}, ROOT)
        receipt["commands"].append(check)
        if not check["oracle_pass"]:
            raise RuntimeError("Formatted inputs do not pass gofmt")
        raw = base64.b64encode(gzip.compress(json.dumps(formatted, separators=(",", ":")).encode(), mtime=0))
        with (out / "formatted-inputs.b64").open("xb") as stream:
            stream.write(raw)
        receipt["export"] = {"path": "evidence/format-inputs/formatted-inputs.b64", "bytes": len(raw), "sha256": q.sha(raw)}
        receipt["formatted_files"] = final_inventory
        for p, digest in q.PINS.items():
            if q.sha(Path(p).read_bytes()) != digest:
                raise RuntimeError("Tool changed during formatting")
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now(); q.save(out / "receipt.json", receipt)
        print(json.dumps({k: receipt.get(k) for k in ("completed", "error", "before", "after", "export")}), flush=True)

if __name__ == "__main__":
    main()
