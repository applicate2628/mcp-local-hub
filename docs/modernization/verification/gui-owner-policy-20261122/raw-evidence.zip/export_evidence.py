"""Archive completed architecture evidence; execute no tools or product code.

Usage: export_evidence.py architecture <reviewed-exporter-sha256>
Scheduler v2/historical-failure export is intentionally not admitted yet.
Exact behavioral-oracle analysis also belongs to the independent local verifier.
"""
import sys
sys.dont_write_bytecode = True
import base64
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import zipfile
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-p0-owners-20261122-e51f")
RUNNER = "3d691d1e2d78b3d81abc29ee64162ab04d299246da31039b7e76fc422b85108a"
PHASES = ["bootstrap-architecture", "format-inputs", "apply-architecture", "architecture-owner-red", "architecture-owner-green"]
PINS = {
    "qualify_go.py": RUNNER,
    "bootstrap.py": "f1b7fa10c34bfae7d4e9461b55469d2c5c57074c73faa86ad679645de0bdade9",
    "format_inputs.py": "824a36f90a1d72bcb7aadfb5a239fac385fb431e460580436b5c63dd0382f00b",
    "source-inputs.b64": "9c578ef7e2f1a58710fd748ab59c4399e7f80505eee929be28fd50a8bc8d7d55",
    "candidate-inputs.b64": "c0370d06ca817112b3870eeb6fce0163d7278ca30ea1a55b7290f570ea52ef97",
    "apply_architecture.py": "2c43ada95c0b5fe86968b012bebb6bc83afcb3f2233ad9aafdc7058401e1563c",
    "architecture-stage.b64": "516eab362fb488c065d8ba3b5c23b70056bb86ee59ee6fa371edd851fe2c93f0",
}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")

def guard(path):
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "Reparse/symlink ancestry refused")

def summary(rows):
    require(len({r["path"] for r in rows}) == len(rows), "Duplicate inventory paths")
    triples = [[r["path"], r["bytes"], r["sha256"]] for r in rows]
    return {"files": len(rows), "bytes": sum(r["bytes"] for r in rows), "inventory_sha256": sha(json.dumps(triples, separators=(",", ":"), ensure_ascii=True).encode())}

def main():
    require(os.name == "nt" and not sys.flags.optimize and len(sys.argv) == 3 and sys.argv[1] == "architecture"
            and Path(__file__).absolute().parent == ROOT, "Use the owned architecture exporter with its reviewed SHA-256")
    guard(ROOT); guard(Path(__file__).absolute()); guard(ROOT / "qualify_go.py")
    exporter_hash = sha(Path(__file__).read_bytes())
    require(exporter_hash == sys.argv[2] and sha((ROOT / "qualify_go.py").read_bytes()) == RUNNER, "Exporter/runner pin changed")
    spec = importlib.util.spec_from_file_location("owned_export_runner", ROOT / "qualify_go.py")
    q = importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
    require(q.ROOT == ROOT, "Runner root differs")
    files, receipts = {}, {}
    def read(relative):
        path = q.own(relative); info = path.lstat()
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "Nonordinary export input: " + relative)
        raw = path.read_bytes()
        require(relative not in files or files[relative] == raw, "Input changed during export: " + relative)
        files[relative] = raw
        return raw
    def document(relative):
        return json.loads(read(relative))
    def walk(directory, capture=True):
        found = set()
        def failed(error):
            raise error
        for parent, directories, names in os.walk(q.own(directory), followlinks=False, onerror=failed):
            for name in directories + names:
                require(name != ".git", "Git metadata is not an evidence/backing payload")
                relative = (Path(parent) / name).relative_to(ROOT).as_posix()
                path = q.own(relative); info = path.lstat()
                require(stat.S_ISDIR(info.st_mode) if name in directories else stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "Nonordinary evidence/backing path")
                if name in names:
                    found.add(relative)
                    if capture:
                        read(relative)
        return found
    def check_inputs(directory, rows):
        require(walk(directory) == {directory + "/" + r["path"] for r in rows}, "Backing-directory membership changed")
        return q.check_files(directory, rows, True)
    for path, digest in PINS.items():
        require(sha(read(path)) == digest, "Pinned helper/transport changed: " + path)
    require(sha(read("export_evidence.py")) == exporter_hash, "Exporter changed")
    for tool, digest in q.PINS.items():
        guard(Path(tool)); require(sha(Path(tool).read_bytes()) == digest, "Installed tool changed")
    phase_files = {}
    for phase in PHASES:
        prefix = "evidence/" + phase + "/"
        receipt = document(prefix + "receipt.json"); receipts[phase] = receipt
        require(receipt.get("completed") is True and receipt.get("runner_sha256") == RUNNER
                and receipt.get("native_scheduler_operations") is False and receipt.get("started_utc") and receipt.get("finished_utc")
                and not any(receipt.get(k) for k in ("error", "error_type", "source_after_error", "inputs_after_error", "process_tree_unresolved")), "Incomplete/unadmitted phase: " + phase)
        if "tools_sha256" in receipt:
            require(receipt["tools_sha256"] == q.PINS, "Recorded tool inventory differs")
        for command in receipt.get("commands", []):
            label = command["label"]
            require(re.fullmatch(r"[a-z][a-z0-9-]{0,63}", label) and command.get("settled") is True and command.get("timed_out") is False
                    and not any(command.get(k) for k in ("error", "error_type", "termination_error", "process_tree_unresolved", "retain_runtime_and_logs", "retained_unsettled", "termination_method"))
                    and (command.get("oracle_pass") is True if "oracle_pass" in command else command.get("exit_code") == 0), "Failed or unsettled command: " + phase + "/" + label)
            require(document(prefix + label + ".receipt.json") == command, "Command and phase receipts differ")
            for suffix in ("started.json", "launched.json"):
                read(prefix + label + "." + suffix)
            for stream in ("stdout", "stderr"):
                raw = read(prefix + label + "." + stream + ".log")
                require({"bytes": len(raw), "sha256": sha(raw)} == command[stream], "Raw command log differs")
        phase_files[phase] = walk(prefix.rstrip("/"))
    bootstrap, formatting, applied = (receipts[p] for p in PHASES[:3])
    require(bootstrap["bootstrap_sha256"] == PINS["bootstrap.py"] and bootstrap["source_bundle_sha256"] == PINS["source-inputs.b64"]
            and formatting["helper_sha256"] == PINS["format_inputs.py"] and formatting["bundle_sha256"] == PINS["candidate-inputs.b64"]
            and applied["helper_sha256"] == PINS["apply_architecture.py"] and applied["bundle_sha256"] == PINS["architecture-stage.b64"], "Phase helper/transport pins differ")
    git = Path(r"C:\Program Files\Git\cmd\git.exe"); guard(git)
    require(sha(git.read_bytes()) == bootstrap["git_sha256"], "Installed Git differs from bootstrap receipt")
    source = json.loads(zlib.decompress(base64.b64decode(files["source-inputs.b64"], validate=True)))["architecture"]
    stage = json.loads(gzip.decompress(base64.b64decode(files["architecture-stage.b64"], validate=True)))
    require(stage["source_before"] == source["files"] and bootstrap["source_head"] == source["head"] and bootstrap["source_tree"] == source["tree"]
            and bootstrap["source_inventory"] == applied["source_before"] == summary(source["files"]), "Parent source provenance differs")
    current = q.check_files("architecture", stage["source_after"], True)
    require(current == applied["source_after"] == summary(stage["source_after"]), "Final complete source inventory differs")
    candidates = check_inputs("inputs/candidate/architecture", stage["candidates"])
    controls = check_inputs("inputs/architecture-control", stage["control_files"])
    require(candidates == applied["candidate_inputs"] and controls == applied["controls"] and applied.get("overlay_membership_exact") is True, "Materialized input inventories differ")
    original = json.loads(gzip.decompress(base64.b64decode(files["candidate-inputs.b64"], validate=True)))
    preformat = [{"path": r["path"].removeprefix("architecture/"), "bytes": r["bytes"], "sha256": r["sha256"]} for r in original if r["path"].startswith("architecture/")]
    require(len(preformat) == len(stage["candidates"]) == 4, "Require four candidate/preformat files")
    preimages = check_inputs("inputs/preformat/architecture", preformat)
    formatted = read("evidence/format-inputs/formatted-inputs.b64")
    require(formatting["export"] == {"path": "evidence/format-inputs/formatted-inputs.b64", "bytes": len(formatted), "sha256": sha(formatted)}, "Formatted transport differs")
    require(applied["payloads"] == [{k: r[k] for k in ("path", "bytes", "sha256")} for r in stage["payloads"]], "Materializer payload membership differs")
    for row in stage["payloads"]:
        raw = read(row["path"])
        require(len(raw) == row["bytes"] and sha(raw) == row["sha256"] and raw == base64.b64decode(row["content"], validate=True), "Pinned stage payload changed")
    for phase in PHASES[3:]:
        name = "plans/" + phase + ".json"; plan = document(name); receipt = receipts[phase]
        require(sha(files[name]) == receipt["manifest_sha256"] and plan["runner_sha256"] == RUNNER and plan["phase"] == phase
                and plan["source_directory"] == "architecture" and plan["source_files"] == stage["source_after"]
                and plan["inputs_directory"] == "inputs/architecture-control" and plan["input_files"] == stage["control_files"]
                and receipt["source_before"] == receipt["source_after"] == current
                and receipt["inputs_before"] == receipt["inputs_after"] == controls, "Runnable plan/source/input identity differs")
        require([r["label"] for r in receipt["commands"]] == [r["label"] for r in plan["commands"]], "Planned command membership differs")
        for actual, expected in zip(receipt["commands"], plan["commands"]):
            require(actual["exit_code"] == expected["expected_exit_code"] and actual.get("oracle_pass") is True, "Command failed its declared oracle")
    limits = {
        "source": "Exact #663 parent plus four physical candidate files. Complete final source inventory checked once; root Git metadata excluded. Parent HEAD/tree do not identify composed bytes.",
        "control": "One overlay file restores two original function bodies. Expected red is evidence of detected behavior, not a passing implementation.",
        "qualification": "Selected tests, scan, build and vet only. Architecture verify is expected exit 1, not a passing architecture gate. Full test suite, native Scheduler/product operations and production GUI integration: NOT_RUN.",
        "processes": "Recorded direct children settled without timeout or recovery flags. No independent descendant-tree settlement proof is claimed.",
        "formatting": "Shared original formatting evidence contains all eight inputs; this archive additionally includes four architecture candidate files and four preimages.",
        "scope": "Full phase logs/receipts, plans, helpers, source inventories and input bytes; no runtime, build outputs, full source copy or Git metadata. Scheduler v1/v2 is outside this export.",
    }
    generated = {"verification/export-checks.json": encoded({"schema": 1, "group": "architecture", "verified_utc": q.now(), "phases": PHASES,
        "exporter_sha256": exporter_hash, "runner_sha256": RUNNER, "source_inventory": current,
        "input_inventories": {"candidate": candidates, "control": controls, "preformat": preimages}, "qualification_limits": limits})}
    for relative, raw in list(files.items()):
        require(read(relative) == raw, "Captured input changed")
    for phase, found in phase_files.items():
        require(walk("evidence/" + phase, capture=False) == found, "Evidence membership changed")
    for tool, digest in q.PINS.items():
        guard(Path(tool)); require(sha(Path(tool).read_bytes()) == digest, "Tool changed before export")
    payload = {**files, **generated}
    rows = [{"path": name, "bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(payload.items())]
    manifest = encoded({"schema": 1, "group": "architecture", "files": rows, "qualification_limits": limits,
                        "manifest_scope": "All ZIP payloads except manifest.json itself; transport pins the manifest and ZIP."})
    out = "exports/architecture"; q.own(out).mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(q.own(out + "/raw-evidence.zip"), "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted({**payload, "manifest.json": manifest}.items()):
            entry = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0)); entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, raw)
    raw = q.own(out + "/raw-evidence.zip").read_bytes(); transport = base64.b64encode(raw); chunks = []
    for number, start in enumerate(range(0, len(transport), 180000)):
        part = transport[start:start + 180000]; name = "part-%03d.b64" % number
        with q.own(out + "/" + name).open("xb") as stream:
            stream.write(part)
        chunks.append({"path": name, "bytes": len(part), "sha256": sha(part)})
    metadata = {"schema": 1, "group": "architecture", "files": len(rows), "zip_path": "raw-evidence.zip", "zip_bytes": len(raw),
                "zip_sha256": sha(raw), "manifest_sha256": sha(manifest), "base64_bytes": len(transport), "base64_sha256": sha(transport),
                "exporter_sha256": exporter_hash, "chunks": chunks, "completed": True}
    q.save(q.own(out + "/transport.json"), metadata)
    print(json.dumps(metadata), flush=True)

if __name__ == "__main__":
    main()
