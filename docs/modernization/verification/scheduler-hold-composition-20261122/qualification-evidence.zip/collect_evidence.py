"""Export fixed task evidence and source overlays; no test or product execution."""
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path(r'D:\dev\ChatGPT\mcp-scheduler-20261122-e21a1792')
if os.name != 'nt' or Path(__file__).resolve().parent != ROOT:
    raise SystemExit('Use the fixed task root on Windows')

def read(relative):
    path = ROOT / relative
    for node in [ROOT, *reversed(path.parents), path]:
        if node == ROOT or ROOT in node.parents:
            info = node.lstat()
            if node.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
                raise RuntimeError('Reparse export input: ' + str(node))
    return path.read_bytes()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

manifest = json.loads(read('manifest.json'))
paths = {'manifest.json', 'master-tree.json', 'qualify_scheduler.py', 'inspect_source.py', 'collect_evidence.py'}
paths.update('overlays/' + item['path'] for item in manifest['files'])
paths.add('control/' + manifest['control']['path'])
for item in manifest['files']:
    if sha(read('overlays/' + item['path'])) != item['candidate']['sha256']:
        raise RuntimeError('Overlay drift: ' + item['path'])
if sha(read('control/' + manifest['control']['path'])) != manifest['control']['sha256']:
    raise RuntimeError('Control drift')
if sha(read('master-tree.json')) != manifest['master_tree_manifest']['sha256']:
    raise RuntimeError('Master tree manifest drift')
for phase in ('format', 'control', 'candidate', 'build', 'vet'):
    receipt_path = 'evidence/' + phase + '/receipt.json'
    receipt = json.loads(read(receipt_path))
    if not receipt['completed'] or receipt['qualification_status'] != 'PASS':
        raise RuntimeError('Phase has not qualified: ' + phase)
    if sha(read('manifest.json')) != receipt['manifest_sha256'] or sha(read('qualify_scheduler.py')) != receipt['runner_sha256']:
        raise RuntimeError('Receipt/input binding differs: ' + phase)
    paths.update((receipt_path, 'evidence/' + phase + '/overlay.json'))
    for row in receipt['commands']:
        label = row['label']
        prefix = 'evidence/' + phase + '/' + label
        for suffix in ('.started.json', '.result.json', '.stdout.log', '.stderr.log'):
            relative = prefix + suffix
            raw = read(relative)
            if suffix in ('.stdout.log', '.stderr.log'):
                stream = suffix.split('.')[1]
                if {'bytes': len(raw), 'sha256': sha(raw)} != row[stream]:
                    raise RuntimeError('Command log drift: ' + relative)
            paths.add(relative)
for label in ('before-build', 'after-vet'):
    relative = 'evidence/source-inventory-' + label + '.json'
    receipt = json.loads(read(relative))
    if not receipt['exact_file_inventory']:
        raise RuntimeError('Source inventory differs: ' + label)
    paths.add(relative)

payload = {relative: read(relative) for relative in sorted(paths)}
archive = ROOT / 'qualification-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for relative, raw in payload.items():
        info = zipfile.ZipInfo(relative, date_time=(2026, 11, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        target.writestr(info, raw)
raw = archive.read_bytes()
transfer = ROOT / 'evidence-transfer'
transfer.mkdir(exist_ok=False)
parts = []
for number, offset in enumerate(range(0, len(raw), 35000)):
    block = raw[offset:offset + 35000]
    name = 'part-' + str(number).zfill(3) + '.b64'
    (transfer / name).write_bytes(base64.b64encode(block))
    parts.append({'name': name, 'bytes': len(block), 'sha256': sha(block)})
receipt = {'schema': 1, 'exported_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
           'archive': archive.name, 'bytes': len(raw), 'sha256': sha(raw), 'parts': parts,
           'members': [{'path': path, 'bytes': len(body), 'sha256': sha(body)} for path, body in payload.items()]}
with (ROOT / 'export-receipt.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: receipt[key] for key in ('archive', 'bytes', 'sha256')} | {'members': len(payload), 'parts': len(parts)}))
