"""Read-only inventory supplement; writes only a new receipt in this task root."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(r'D:\dev\ChatGPT\mcp-scheduler-20261122-e21a1792')
SOURCE = Path(r'D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\source-master')

def fail(error):
    raise error

if os.name != 'nt' or len(sys.argv) != 2 or sys.argv[1] not in ('before-build', 'after-vet'):
    raise SystemExit('Use one fixed inventory label on Windows')
expected = {item['path']: item['git_blob'] for item in json.loads((ROOT / 'master-tree.json').read_bytes())}
actual = {}
reparse = []
directories = 0
for current, subdirs, files in os.walk(SOURCE, followlinks=False, onerror=fail):
    current = Path(current)
    if current == SOURCE and '.git' in subdirs:
        subdirs.remove('.git')
    for name in [*subdirs, *files]:
        path = current / name
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            reparse.append(path.relative_to(SOURCE).as_posix())
    directories += len(subdirs)
    for name in files:
        path = current / name
        relative = path.relative_to(SOURCE).as_posix()
        raw = path.read_bytes()
        actual[relative] = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
receipt = {
    'schema': 1, 'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'label': sys.argv[1], 'source': str(SOURCE), 'git_metadata_excluded': '.git/',
    'tracked_expected': len(expected), 'actual_files': len(actual), 'directories': directories,
    'extra_files': sorted(set(actual) - set(expected)),
    'missing_files': sorted(set(expected) - set(actual)),
    'changed_files': sorted(p for p in expected.keys() & actual.keys() if expected[p] != actual[p]),
    'reparse_entries': sorted(reparse),
}
receipt['exact_file_inventory'] = not any(receipt[k] for k in ('extra_files', 'missing_files', 'changed_files', 'reparse_entries'))
target = ROOT / 'evidence' / ('source-inventory-' + sys.argv[1] + '.json')
with target.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
raise SystemExit(0 if receipt['exact_file_inventory'] else 1)
