"""Fixed offline Windows qualification of the master/#660 composition.

Only the ten pinned API roots are executed. The scheduler is an in-memory
fixture; one adopt fixture briefly binds and closes its own loopback listener.
Profiles and temporary data are task-owned on D. Existing compiler/module
caches on D are reused. No package download, installed product, native task,
external review, or publication is performed. Direct child waits are bounded;
the harness makes no whole-process-tree settlement claim.
"""
import sys
sys.dont_write_bytecode = True
from collections import Counter
import ctypes
from ctypes import wintypes
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(r'D:\dev\ChatGPT\mcp-scheduler-20261122-e21a1792')
SOURCE = Path(r'D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\source-master')
GO = Path(r'C:\msys64\ucrt64\bin\go.exe')
GOFMT = GO.with_name('gofmt.exe')
GIT = Path(r'C:\Program Files\Git\cmd\git.exe')
CC = GO.with_name('gcc.exe')
TOOL_PINS = {
    GO: '0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113',
    GOFMT: '95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5',
    GIT: '177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48',
    CC: 'f6ff9378c1edb591131304518eac6456708d28720284105930d0d687136bcdd3',
}
MANIFEST_SHA256 = '7c014dba3137707dfc8b13a1f911b8f019fa1ce9ab14bc5333ebaaa81769b016'
PHASES = {'format', 'candidate', 'control', 'build', 'vet'}
PACKAGE = 'mcp-local-hub/internal/api'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def ordinary(path):
    info = path.lstat()
    if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
        raise RuntimeError('Reparse input refused: ' + str(path))

def checked(relative):
    path = ROOT / relative
    path.relative_to(ROOT)
    for parent in (ROOT, *list(path.parents)[:-1]):
        if parent == ROOT or ROOT in parent.parents:
            ordinary(parent)
    ordinary(path)
    return path

def native_temp(expected):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    name = 'GetTempPath2W' if hasattr(kernel, 'GetTempPath2W') else 'GetTempPathW'
    fn = getattr(kernel, name)
    fn.argtypes = (wintypes.DWORD, wintypes.LPWSTR)
    fn.restype = wintypes.DWORD
    buf = ctypes.create_unicode_buffer(32768)
    previous = {key: os.environ.get(key) for key in ('TEMP', 'TMP')}
    try:
        os.environ.update(TEMP=str(expected), TMP=str(expected))
        count = fn(len(buf), buf)
        if not 0 < count < len(buf) or Path(buf.value) != expected:
            raise RuntimeError('Windows temporary path differs from owned TMP')
        return {'api': name, 'path': str(expected)}
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

def input_check(manifest):
    if sha(checked('manifest.json').read_bytes()) != MANIFEST_SHA256:
        raise RuntimeError('Manifest drift')
    raw_tree = checked('master-tree.json').read_bytes()
    if sha(raw_tree) != manifest['master_tree_manifest']['sha256']:
        raise RuntimeError('Master tree manifest drift')
    for item in manifest['files']:
        raw = checked('overlays/' + item['path']).read_bytes()
        if sha(raw) != item['candidate']['sha256'] or blob(raw) != item['candidate']['git_blob']:
            raise RuntimeError('Candidate drift: ' + item['path'])
    control = manifest['control']
    if sha(checked('control/' + control['path']).read_bytes()) != control['sha256']:
        raise RuntimeError('Control drift')
    for path, digest in TOOL_PINS.items():
        ordinary(path)
        if sha(path.read_bytes()) != digest:
            raise RuntimeError('Tool drift: ' + str(path))
    return json.loads(raw_tree)

def source_check(tree):
    ordinary(SOURCE)
    actual = []
    for item in tree:
        path = SOURCE / item['path']
        ordinary(path)
        raw = path.read_bytes()
        actual_blob = blob(raw)
        if actual_blob != item['git_blob']:
            raise RuntimeError('Materialized source differs from master: ' + item['path'])
        actual.append(item['path'] + '\0' + actual_blob)
    return {'tracked_files': len(actual), 'path_blob_manifest_sha256': sha('\n'.join(actual).encode())}

def execute(out, env, label, exe, args, timeout):
    row = {'label': label, 'executable': str(exe), 'args': args, 'cwd': str(SOURCE),
           'started_utc': utc(), 'direct_timeout_seconds': timeout,
           'settled': False, 'timed_out': False, 'whole_process_tree_deadline_enforced': False}
    save(out / (label + '.started.json'), row)
    child = None
    start = time.monotonic()
    try:
        with (out / (label + '.stdout.log')).open('xb') as stdout, (out / (label + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen([str(exe), *args], cwd=SOURCE, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            row['pid'] = child.pid
            try:
                row['exit_code'] = child.wait(timeout=timeout)
                row['settled'] = True
            except subprocess.TimeoutExpired:
                row['timed_out'] = True
                row['process_tree_unresolved'] = True
                child.terminate()  # original retained Popen handle; never resolve a PID
                row['exit_code'] = child.wait(timeout=15)
                row['settled'] = True
    except BaseException as error:
        row['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        row.update(seconds=time.monotonic() - start, finished_utc=utc())
        for stream in ('stdout', 'stderr'):
            path = out / (label + '.' + stream + '.log')
            if path.exists():
                raw = path.read_bytes()
                row[stream] = {'bytes': len(raw), 'sha256': sha(raw)}
        save(out / (label + '.result.json'), row)
    return row

def main():
    if os.name != 'nt' or sys.flags.optimize or len(sys.argv) != 2 or sys.argv[1] not in PHASES or Path(__file__).resolve().parent != ROOT:
        raise SystemExit('Use the exact Windows root and one fixed qualification phase')
    phase = sys.argv[1]
    ordinary(ROOT)
    manifest = json.loads(checked('manifest.json').read_bytes())
    tree = input_check(manifest)
    out = ROOT / 'evidence' / phase
    runtime = ROOT / 'runtime' / phase
    out.mkdir(parents=True, exist_ok=False)
    runtime.mkdir(parents=True, exist_ok=False)
    for part in ('tmp', 'profile', 'appdata', 'localappdata', 'gopath', 'telemetry', 'xdg-config', 'xdg-data', 'xdg-cache'):
        (runtime / part).mkdir()
    (runtime / 'telemetry' / 'mode').write_bytes(b'off\n')
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GO', 'MCPHUB_', 'GIT_')) and k.upper() not in ('CC', 'CXX', 'CGO_ENABLED')}
    system = Path(os.environ['SystemRoot'])
    env.update(GOROOT=r'C:\msys64\ucrt64\lib\go', GOENV='off', GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off', GOVCS='*:off', GOWORK='off', GOFLAGS='-mod=readonly',
               GOCACHE=r'D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gocache', GOMODCACHE=r'D:\dev\ChatGPT\mcp-pr616-qualification-20261114\gomodcache',
               GOPATH=str(runtime / 'gopath'), CC=str(CC), CGO_ENABLED='1', GOMAXPROCS='4', GOTELEMETRY='off', TEST_TELEMETRY_DIR=str(runtime / 'telemetry'),
               USERPROFILE=str(runtime / 'profile'), APPDATA=str(runtime / 'appdata'), LOCALAPPDATA=str(runtime / 'localappdata'),
               TEMP=str(runtime / 'tmp'), TMP=str(runtime / 'tmp'), TMPDIR=str(runtime / 'tmp'), GOTMPDIR=str(runtime / 'tmp'),
               XDG_CONFIG_HOME=str(runtime / 'xdg-config'), XDG_DATA_HOME=str(runtime / 'xdg-data'), XDG_CACHE_HOME=str(runtime / 'xdg-cache'),
               MCPHUB_NO_AUTO_GUI='1', MCPHUB_E2E_SCHEDULER='none', PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', GIT_CONFIG_NOSYSTEM='1',
               GIT_CONFIG_GLOBAL=str(runtime / 'no-global-config'), GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never')
    env['PATH'] = os.pathsep.join((str(GO.parent), str(system / 'System32'), str(GIT.parent)))
    for cache in ('GOCACHE', 'GOMODCACHE'):
        ordinary(Path(env[cache]))
    receipt = {'schema': 1, 'phase': phase, 'started_utc': utc(), 'completed': False,
               'source_head': manifest['source_head'], 'source_tree': manifest['source_tree'],
               'manifest_sha256': MANIFEST_SHA256, 'runner_sha256': sha(Path(__file__).read_bytes()),
               'source_pr660': manifest['source_pr660'], 'source_api_testmain': manifest['source_api_testmain'],
               'native_scheduler_operations': False, 'installed_product_execution': False,
               'whole_process_tree_deadline_enforced': False, 'process_tree_settlement_observed': False,
               'environment': {key: env[key] for key in ('GOROOT','GOENV','GOTOOLCHAIN','GOPROXY','GOSUMDB','GOVCS','GOWORK','GOCACHE','GOMODCACHE','GOPATH','CC','CGO_ENABLED','GOMAXPROCS','GOTELEMETRY','TEST_TELEMETRY_DIR','USERPROFILE','APPDATA','LOCALAPPDATA','TEMP','TMP','GOTMPDIR','MCPHUB_NO_AUTO_GUI','MCPHUB_E2E_SCHEDULER','PATH')},
               'tools_sha256': {str(p): d for p, d in TOOL_PINS.items()}, 'commands': []}
    try:
        receipt['native_temporary_path'] = native_temp(runtime / 'tmp')
        receipt['source_before'] = source_check(tree)
        replaced = {str(SOURCE / item['path']): str(ROOT / 'overlays' / item['path']) for item in manifest['files']}
        if phase == 'control':
            replaced[str(SOURCE / manifest['control']['path'])] = str(ROOT / 'control' / manifest['control']['path'])
        overlay = out / 'overlay.json'
        save(overlay, {'Replace': replaced})
        receipt['overlay_sha256'] = sha(overlay.read_bytes())
        if phase == 'format':
            rows = [('go-version', GO, ['version'], 30), ('gofmt', GOFMT, ['-l', *replaced.values()], 30)]
        elif phase in ('candidate', 'control'):
            roots = manifest['required_roots'] if phase == 'candidate' else manifest['required_roots'][:2]
            selector = '^(' + '|'.join(roots) + ')$'
            rows = [('test', GO, ['test','-overlay',str(overlay),'-mod=readonly','-race','-json','-count=1','-timeout=90s','-parallel=1','-p=4','-run',selector,'./internal/api/'], 360)]
        else:
            rows = [(phase, GO, [phase,'-overlay',str(overlay),'-mod=readonly','-p=4','./...'], 360)]
        for label, exe, args, deadline in rows:
            input_check(manifest)
            row = execute(out, env, label, exe, args, deadline)
            receipt['commands'].append(row)
            if not row['settled'] or row['timed_out'] or row.get('error'):
                raise RuntimeError('Command did not settle ordinarily: ' + label)
            expected = 1 if phase == 'control' else 0
            if row['exit_code'] != expected:
                raise RuntimeError('Unexpected command exit: ' + label)
            raw = (out / (label + '.stdout.log')).read_bytes()
            if label == 'go-version' and raw.strip() != b'go version go1.27.4 windows/amd64':
                raise RuntimeError('Unexpected Go version')
            if label == 'gofmt' and raw.strip():
                raise RuntimeError('Formatter reported unformatted source')
            if label == 'test':
                events = [json.loads(line) for line in raw.decode('utf-8').splitlines()]
                terminal = {kind: [e.get('Test','PACKAGE:'+e.get('Package','')) for e in events if e.get('Action') == kind] for kind in ('pass','fail','skip')}
                receipt['terminal_events'] = terminal
                if terminal['skip']:
                    raise RuntimeError('A selected test was skipped')
                if phase == 'candidate':
                    counts = Counter(terminal['pass'])
                    if terminal['fail'] or any(counts[root] != 1 for root in manifest['required_roots']) or counts['PACKAGE:'+PACKAGE] != 1:
                        raise RuntimeError('Candidate did not pass every required root exactly once')
                else:
                    if terminal['pass'] or Counter(terminal['fail']) != Counter([*roots,'PACKAGE:'+PACKAGE]):
                        raise RuntimeError('Control did not fail exactly the two intended roots and package')
                    if b'HOLD-MERGE: install merge lost' not in raw or b'HOLD-PREFLIGHT: temporary write probe failed' not in raw:
                        raise RuntimeError('Control diagnostic differs from the frozen oracle')
        input_check(manifest)
        receipt['source_after'] = source_check(tree)
        if receipt['source_after'] != receipt['source_before']:
            raise RuntimeError('Source changed during qualification')
        receipt['temporary_residue'] = sorted(p.relative_to(runtime / 'tmp').as_posix() for p in (runtime / 'tmp').rglob('*'))
        if receipt['temporary_residue']:
            raise RuntimeError('Temporary runtime entries remain after direct child exit')
        receipt.update(completed=True, qualification_status='PASS', command_outcome='EXPECTED_FAIL' if phase == 'control' else 'PASS')
    except BaseException as error:
        receipt.update(qualification_status='FAILED', error=type(error).__name__ + ': ' + str(error))
    finally:
        receipt['finished_utc'] = utc()
        save(out / 'receipt.json', receipt)
        print(json.dumps({'phase': phase, 'qualification_status': receipt.get('qualification_status'), 'completed': receipt['completed'], 'error': receipt.get('error'), 'terminal_counts': {k:len(v) for k,v in receipt.get('terminal_events',{}).items()}}), flush=True)
    return 0 if receipt['completed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
