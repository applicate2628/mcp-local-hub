package api

import (
"bytes"
"context"
"encoding/json"
"errors"
"fmt"
"io"
"net"
"net/http"
"net/url"
"os"
"os/exec"
"os/user"
"path/filepath"
"reflect"
"runtime"
"strconv"
"strings"
"sync"
"time"

"mcp-local-hub/internal/binaryadmission"
"mcp-local-hub/internal/clients"
"mcp-local-hub/internal/config"
"mcp-local-hub/internal/mcpcompat/readinesswire"
"mcp-local-hub/internal/process"
"mcp-local-hub/internal/scheduler"
"mcp-local-hub/internal/secrets"
)

// pruneBackupsForBackupPath is the post-commit retention seam. Production uses
// the clients owner; tests inject only its lock-lifecycle result.
var pruneBackupsForBackupPath = clients.PruneBackupsForBackupPath

// classifyInstallClientMutation keeps install settlement on the single
// clients-owned classifier. The variable is a narrow fault-injection seam for
// transaction tests; production always points at clients.ClassifyClientMutation.
var classifyInstallClientMutation = clients.ClassifyClientMutation

// mcphubShortName is the bare executable name. Used for Antigravity relay
// entries (subprocess spawners like Node's child_process do honor PATH) and
// for the install preflight "is mcphub on PATH?" check.
var mcphubShortName = func() string {
	if runtime.GOOS == "windows" {
		return "mcphub.exe"
	}
	return "mcphub"
}()

// The explicit local-install target and the admitted runtime image are
// separate policies. Generated launchers require a native absolute image,
// never a bare PATH command which could name npm's script shim.
// testCanonicalMcphubPathOverride is the test seam for canonicalMcphubPath.
// Production leaves it empty; unit tests that need a deterministic (or
// deliberately missing) binary path set it in their setup and restore
// in defer.
var testCanonicalMcphubPathOverride string

// canonicalInstallRelayPathFn resolves the existing single-binary relay path.
// The plan freezes its result before mutation so later ambient changes cannot
// make the expected and written client entries disagree.
var canonicalInstallRelayPathFn = canonicalMcphubPath

// LocalInstallMcphubPath is the fixed optional local-install policy. It is not
// runtime-image discovery and must not follow an npm payload or active owner.
func LocalInstallMcphubPath() (string, error) {
	if testCanonicalMcphubPathOverride != "" {
		return testCanonicalMcphubPathOverride, nil
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("resolve user home: %w", err)
	}
	return filepath.Join(home, ".local", "bin", mcphubShortName), nil
}

// CanonicalManifestDir returns the single default disk-manifest root shared by
// every product process context. It derives only from the canonical installed
// product path and performs no filesystem access or directory creation.
func CanonicalManifestDir() (string, error) {
	canonicalExecutable, err := LocalInstallMcphubPath()
	if err != nil {
		return "", fmt.Errorf("resolve canonical manifest root: %w", err)
	}
	if canonicalExecutable == "" || !filepath.IsAbs(canonicalExecutable) || filepath.Clean(canonicalExecutable) != canonicalExecutable {
		return "", fmt.Errorf("resolve canonical manifest root: canonical product path must be clean and absolute")
	}
	return filepath.Join(filepath.Dir(canonicalExecutable), "servers"), nil
}

func canonicalMcphubPath() (string, error) {
	return RuntimeMcphubExecutable()
}

// RuntimeProductImageError preserves the specific ownership/admission cause
// while allowing install dry-run to distinguish it from prior-read advisories.
type RuntimeProductImageError struct{ Cause error }

func (e *RuntimeProductImageError) Error() string {
	return "E_RUNTIME_PRODUCT_IMAGE: " + e.Cause.Error()
}
func (e *RuntimeProductImageError) Unwrap() error { return e.Cause }

var selfMcphubImage struct {
	once sync.Once
	path string
	err  error
}

// SelfMcphubExecutable is the native image already entered by this process.
// It never searches PATH, which may name an npm command script rather than PE.
func SelfMcphubExecutable() (string, error) {
	selfMcphubImage.once.Do(func() {
		path, err := os.Executable()
		if err != nil {
			selfMcphubImage.err = fmt.Errorf("resolve running native image: %w", err)
			return
		}
		path, err = filepath.Abs(path)
		if err == nil {
			path, err = filepath.EvalSymlinks(path)
		}
		if err != nil {
			selfMcphubImage.err = fmt.Errorf("resolve running native image path: %w", err)
			return
		}
		selfMcphubImage.path = filepath.Clean(path)
	})
	return selfMcphubImage.path, selfMcphubImage.err
}

func admitRuntimeMcphubImage(path string) error {
	if path == "" || !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return fmt.Errorf("runtime product image must be clean and absolute")
	}
	if runtime.GOOS == "windows" {
		_, err := binaryadmission.AdmitWindowsRole(binaryadmission.WindowsArtifact{Path: path, Role: binaryadmission.WindowsArtifactRoleProduct})
		return err
	}
	info, err := os.Stat(path)
	if err != nil {
		return err
	}
	if !info.Mode().IsRegular() || info.Mode()&0o111 == 0 {
		return fmt.Errorf("runtime product image is not an executable regular file")
	}
	return nil
}

// RuntimeMcphubExecutable is the one generated-launch authority. An already
// authenticated and admitted supervisor owner wins over an invoking helper.
// The supervisor recognizes its own lock generation without calling its IPC.
func RuntimeMcphubExecutable() (path string, err error) {
	defer func() {
		if err != nil {
			err = &RuntimeProductImageError{Cause: err}
		}
	}()
	if testCanonicalMcphubPathOverride != "" {
		return testCanonicalMcphubPathOverride, nil
	}
	candidate, err := SelfMcphubExecutable()
	if err != nil {
		return "", err
	}
	stateDir, err := daemonStateDirReadOnly()
	if err != nil {
		return "", fmt.Errorf("runtime product state: %w", err)
	}
	if _, err := os.Stat(stateDir); err != nil {
		if !os.IsNotExist(err) {
			return "", fmt.Errorf("inspect runtime product state: %w", err)
		}
		return selectRuntimeMcphubImage(candidate, nil, admitRuntimeMcphubImage)
	}
	running, _, err := SupervisorRunningUnderStateDir(stateDir)
	if err != nil {
		return "", fmt.Errorf("observe runtime product owner: %w", err)
	}
	if !running {
		return selectRuntimeMcphubImage(candidate, nil, admitRuntimeMcphubImage)
	}
	lockPath := filepath.Join(stateDir, "supervisor.lock")
	owner, err := ReadSupervisorLockOwner(lockPath)
	if err != nil {
		return "", fmt.Errorf("read runtime product owner: %w", err)
	}
	var proof SupervisorRecoveryStatusV1
	if owner.PID == os.Getpid() {
		started, ok := process.ProcessStartTime(os.Getpid())
		declared, parseErr := time.Parse(time.RFC3339Nano, owner.StartedAt)
		if !ok || parseErr != nil || !started.Equal(declared) {
			return "", fmt.Errorf("runtime product self-owner generation is unverified")
		}
		proof.Owner = owner
		proof.Server.ImagePath = candidate
	} else {
		proof, err = DialSupervisorIPCRecoveryStatusV1(context.Background(), stateDir)
		if err != nil {
			return "", fmt.Errorf("authenticate runtime product owner: %w", err)
		}
	}
	path, err = selectRuntimeMcphubImage(candidate, &proof, admitRuntimeMcphubImage)
	if err != nil {
		return "", err
	}
	after, err := ReadSupervisorLockOwner(lockPath)
	if err != nil || after.PID != proof.Owner.PID || after.StartedAt != proof.Owner.StartedAt {
		return "", fmt.Errorf("runtime product owner generation changed during admission: %w", errors.Join(err, ErrSupervisorIPCUnavailable))
	}
	return path, nil
}

func selectRuntimeMcphubImage(candidate string, owner *SupervisorRecoveryStatusV1, admit func(string) error) (string, error) {
	if admit == nil {
		return "", fmt.Errorf("runtime product admission owner is unavailable")
	}
	path := candidate
	if owner != nil {
		path = owner.Server.ImagePath
	}
	if err := admit(path); err != nil {
		return "", fmt.Errorf("admit runtime product image: %w", err)
	}
	return path, nil
}

func ensureCanonicalMcphubPresent() (string, error) {
	return ensureRuntimeMcphubPresent(nil)
}

func resolveInstallRuntimeProduct(bypass *InstallParsedManifestBypass) (string, error) {
	if bypass != nil {
		return runtimeMcphubExecutableUnderSupervisorLock(*bypass)
	}
	return canonicalMcphubPath()
}

func ensureRuntimeMcphubPresent(bypass *InstallParsedManifestBypass) (string, error) {
	canonicalPath, err := resolveInstallRuntimeProduct(bypass)
	if err != nil {
		return "", err
	}
	if _, err := os.Stat(canonicalPath); err != nil {
		return "", fmt.Errorf("runtime product image %s not present: %w", canonicalPath, err)
	}
	return canonicalPath, nil
}

// CanonicalAutostartEntrypoint returns the installed executable entrypoint
// owned by setup for the current platform without mutating it.
func CanonicalAutostartEntrypoint() (string, error) {
	canonical, err := ensureCanonicalMcphubPresent()
	if err != nil {
		return "", err
	}
	if runtime.GOOS == "windows" {
		return canonical, nil
	}
	return canonical, nil
}

// Plan describes the side effects that `mcp install --server X` would produce.
// Returned by BuildPlan and rendered by `install --dry-run`.
//
// v0.5.0 Phase 12: SupervisorIntent is the new authoritative seam that
// downstream consumers (migration journal, install reconciler, the
// status-seam IPC backing in health.go) read for "what daemons should
// the supervisor own?". SchedulerTasks is preserved for backward compat
// during the v0.5.x transition — existing call sites (executeInstallTo
// Step 1 at install.go:1589-1632, the prune-set construction at
// install.go:1638-1652, printPlanTo at install.go:1540-1553) continue
// using SchedulerTasks unchanged. A later release removes the legacy
// field once all consumers migrate.
//
// Spec §"Q12 CLI/GUI status seam" + plan §2611-2644.
type Plan struct {
	runtimeProduct           *InstallParsedManifestBypass
	ownedBackendInstall      *managedBackendInstallOperation
	projectAttachment        *projectClientAttachmentPlan
	selectedExecutionPhase   *selectedInstallExecutionPhase
	serenaPreparedRecord     *PreparedSerenaRuntimeRecord
	serenaPreparedBinding    *PreparedSerenaRuntimeBinding
	serenaPreparationRequest *PreparedSerenaRequest
	serenaPreparedInvocation *PreparedSerenaConsumerInvocation
	Server                   string
	CanMigrate               bool
	SchedulerTasks           []ScheduledTaskPlan     // DEPRECATED: kept for v0.5.x backward compat; replaced by SupervisorIntent in v0.6+.
	SupervisorIntent         []SupervisorIntentEntry // v0.5.0 Phase 12 — authoritative for new supervisor-intent.json consumers.
	ClientUpdates            []ClientUpdatePlan
	// installRelayExePath is resolved once before mutation. It is an
	// execution-only value shared by binding expectations and client writers.
	installRelayExePath string
	// clientConfigSettlements is populated only by a lower locked writer after
	// exact readback. It is never a planning prediction or wire field.
	clientConfigSettlements []ClientConfigSettlementV1
	Notices                 []string
	// FullInstall is true when BuildPlan was called with an empty daemonFilter
	// — i.e. the plan covers the whole manifest. Only a full install can
	// safely reconcile (prune) obsolete sibling scheduler tasks from prior
	// installs; a partial install targets one daemon and must leave others
	// alone.
	FullInstall bool
	// supervisorIntentHashesBound is set only by an exact raw-manifest loader.
	// Direct semantic plan construction carries no authority to invent a hash.
	supervisorIntentHashesBound bool
}

type ScheduledTaskPlan struct {
	Name    string
	Command string
	Args    []string
	Trigger string // human-readable
}

// ClientUpdateAction is the typed enum for ClientUpdatePlan.Action. The
// raw string values are kept stable (`add/replace` / `remove`) so logs,
// dry-run output, and JSON debug dumps remain wire-compatible with the
// pre-Phase 5 plan shape. Spec §"Bidirectional install reconciler".
type ClientUpdateAction string

const (
	// ClientUpdateAddReplace adds the entry (or replaces it in place if
	// already present). Used both by the per-server install planner
	// (per-daemon entries) and the full-reconcile gate-ON planner
	// (mcphub-hub aggregate entry).
	ClientUpdateAddReplace ClientUpdateAction = "add/replace"

	// ClientUpdateRemove removes the named entry. ONLY the full-
	// reconcile planner (BuildHubReconcilePlan) emits this; per-server
	// install paths must leave existing entries alone — including the
	// mcphub-hub aggregate (codex r3 general F2 closure).
	ClientUpdateRemove ClientUpdateAction = "remove"
)

// ClientUpdatePlan describes one client-config side effect produced by
// either the per-server install planner (BuildPlan / BuildPlanWithOpts)
// or the full-reconcile planner (BuildHubReconcilePlan). The applier
// (ApplyHubReconcileInOrder for the reconcile path; executeInstallTo
// for the per-server path) consumes the same shape.
//
// EntryName carries the server-name (per-daemon entries) or the
// constant "mcphub-hub" (aggregate entry created on gate ON). The
// applier routes the write to the right adapter method using
// (Action, EntryName).
//
// Headers is populated only for the aggregate entry on gate ON; it
// carries the per-client X-Mcphub-Hub-Token plus the X-Mcphub-Instance-Id
// header the Phase 4 auth gate validates. Per-daemon entries leave
// Headers empty — they hit the daemon directly with no auth header.
//
// DisplayURL carries a redacted form of URL suitable for plan + install
// stdout. For local manifests it equals URL. For transport=remote-http
// it is the manifest's literal pre-expansion URL (with ${secret:KEY}
// placeholders intact) so a path/query token never reaches the
// operator's terminal even when URL embeds it (codex cumulative G6
// review P2 closure — URL-as-secret-bearer is rare but real).
type ClientUpdatePlan struct {
	Client         string
	Path           string
	Action         ClientUpdateAction
	EntryName      string            // "mcphub-hub" for aggregate; "<server>" for per-daemon
	URL            string            // empty for Remove
	DisplayURL     string            // safe-to-print form of URL; falls back to URL when not set
	Headers        map[string]string // F-G5: token + instance id; empty for per-daemon
	ToolTimeoutSec int               // optional client tool-call timeout; zero preserves historical output
	RelayURL       string            // optional direct relay target for relay-stdio clients
	DaemonName     string            // legacy; only meaningful for per-daemon entries

	// codexAlreadyConfigured is an execution-only settled-repeat marker. It is
	// deliberately unexported: the plan still carries the frozen EntryName on
	// every public surface while apply skips a second global config mutation.
	codexAlreadyConfigured bool
}

// InstallOpts controls an install invocation.
type InstallOpts struct {
	requireExistingStdioBridge bool
	ProjectClientRollback      *InstallProjectClientRollback
	ProjectClientCreate        *InstallProjectClientCreate
	SerenaPreparationPolicy    *SerenaPreparationPolicyV2
	Server                     string
	DaemonFilter               string   // empty = all daemons in the manifest
	ClientsInclude             []string // empty = default install clients
	IncludeAllClients          bool
	// SkipClientConfigWrites materializes daemon/supervisor intent while
	// producing no client-config updates. It conflicts with client selectors.
	SkipClientConfigWrites bool
	DryRun                 bool
	Writer                 io.Writer // progress output destination; nil = os.Stderr
	GUIPort                int       // live GUI/router port injected by CLI/GUI; zero means unknown
	RoutingTarget          *ClientRoutingTarget
	SymlinkConsents        []ResolvedSymlinkConsent
	// CodexProjectRoot and CodexWorkingDir are supplied by the composition root
	// when an install must inspect applicable project config layers read-only.
	CodexProjectRoot string
	CodexWorkingDir  string
}

// InstallAllOpts controls a bulk install.
type InstallAllOpts struct {
	ManifestDir       string
	ClientsInclude    []string
	IncludeAllClients bool
	DryRun            bool
	Writer            io.Writer
	GUIPort           int
	RoutingTarget     *ClientRoutingTarget
}

// InstallResult is one row in an InstallAll report.
type InstallResult struct {
	Server                  string
	Err                     error
	Settlement              CommandSettlementV1
	ClientConfigSettlements []ClientConfigSettlementV1
}

func installOptsMayWriteClients(opts InstallOpts) bool {
	return !opts.SkipClientConfigWrites && !(len(opts.ClientsInclude) == 1 && strings.TrimSpace(opts.ClientsInclude[0]) == "")
}

func (a *API) prepareInstallClientRoutingDecision(opts *InstallOpts) (ClientRoutingAuthorityRequest, error) {
	if opts == nil {
		return ClientRoutingAuthorityRequest{}, &MCPFrontTargetInvalidError{Detail: "install routing options are nil"}
	}
	if opts.RoutingTarget != nil {
		if err := ValidateClientRoutingTarget(*opts.RoutingTarget); err != nil {
			return ClientRoutingAuthorityRequest{}, err
		}
		opts.GUIPort = opts.RoutingTarget.Port
		return ExactTarget(*opts.RoutingTarget), nil
	}
	target, err := a.ResolveClientRoutingTarget()
	if err != nil {
		return ClientRoutingAuthorityRequest{}, err
	}
	if opts.GUIPort != 0 {
		legacy := ClientRoutingTarget{Mode: MCPFrontRoutingTargetGUI, Port: opts.GUIPort}
		if err := ValidateClientRoutingTarget(legacy); err != nil {
			return ClientRoutingAuthorityRequest{}, err
		}
		if target.Mode == MCPFrontRoutingTargetGUI {
			return StableGUICompatibility(), nil
		}
	}
	opts.RoutingTarget = &target
	opts.GUIPort = target.Port
	return ExactTarget(target), nil
}

// UninstallReport summarizes what Uninstall actually did. Callers (CLI/GUI)
// render this however they like; the API itself does not print.
type UninstallReport struct {
	Server          string
	TasksDeleted    []string
	TaskDeleteWarns []string
	ClientsUpdated  []string
	ClientWarns     []string
}

// refuseWorkspaceScopedInstall returns a clear error when someone tries to
// `mcphub install --server mcp-language-server`. Workspace-scoped manifests
// require `mcphub register <workspace> [language...]` — there is no implicit
// install semantic for them because the (workspace, language) tuples that a
// workspace-scoped server needs cannot be inferred from the manifest alone.
// Callers may pass a writer for a human-friendly surface; the returned error
// is the machine-readable signal.
func refuseWorkspaceScopedInstall(m *config.ServerManifest, w io.Writer) error {
	if m.Kind != config.KindWorkspaceScoped {
		return nil
	}
	if w != nil {
		fmt.Fprintf(w, "Server %q is workspace-scoped; use `mcphub register <workspace> [language...]` instead of `mcphub install`.\n", m.Name)
	}
	return fmt.Errorf("server %q is workspace-scoped; use `mcphub register <workspace> [language...]`", m.Name)
}

// Install performs the full install flow for one server: reads manifest,
// runs preflight, builds plan, creates scheduler tasks, writes client configs,
// starts daemons.
//
// Task 10 wiring (plan v13 §62 audit-first canonical timing): on a
// non-dry-run path the function emits one Action=server-install audit
// entry per planned scheduler task BEFORE any scheduler / intent / client
// mutation. If audit append fails (incl. ErrIdentityOversize per §51 +
// §62), the install is REJECTED with a wrapped error and end-state is
// identical to never-attempted install. After a successful install the
// function records Desired=running intent for each created task; intent
// failures there are logged + tolerated because the install already
// happened.
func (a *API) Install(opts InstallOpts) error {
	return a.installWithFrozenPlan(context.Background(), opts, nil)
}

// installWithFrozenPlan is the private mutation core shared by the legacy API
// wrapper and the command adapter. The optional receipt callback observes the
// one plan instance that is subsequently applied; it must not re-plan.
func (a *API) installWithFrozenPlan(ctx context.Context, opts InstallOpts, receipt func(InstallMutationReceiptV1)) error {
	if opts.ProjectClientRollback != nil {
		err := a.rollbackProjectClientAttachment(ctx, opts, opts.Writer)
		if receipt != nil {
			r := InstallMutationReceiptV1{DryRun: opts.DryRun, Committed: err == nil && !opts.DryRun}
			if err == nil && !opts.DryRun {
				s := commandSettlementV1(CommandOperationInstall, "rolled_back", nil, ReadinessSnapshotV1{})
				r.projectSettlement = &s
			}
			receipt(r)
		}
		return err
	}
	if err := validateInstallProjectClientCreate(opts); err != nil {
		return err
	}
	return withInstallManifestLease(opts, func(opts InstallOpts) error {
		return a.installWithAdoptLeaseHeld(ctx, opts, receipt)
	})
}

// withInstallManifestLease excludes adopt/de-adopt before the authoritative
// manifest read, not just at the audit barrier. Otherwise a frozen Install can
// outlive provenance close and mistake the missing receipt for an unrelated
// server. Keep the existing outermost lease through apply and rollback; previews
// remain read-only. Callers already inside adopt use the lease-held body.
func withInstallManifestLease(opts InstallOpts, apply func(InstallOpts) error) (err error) {
	if err := checkManifestName(opts.Server); err != nil {
		return err
	}
	if opts.DryRun {
		return apply(opts)
	}
	lease, acquired, leaseErr := acquireAdoptLeaseForApply(manifestMutationLeaseOwner{}, opts.Server)
	if leaseErr != nil || !acquired {
		if leaseErr == nil {
			leaseErr = newLeaseFailure(adoptLeaseFailureBusy, true, false)
		}
		return fmt.Errorf("install: acquire per-manifest lease for %q: %w", opts.Server, leaseErr)
	}
	w := opts.Writer
	if w == nil {
		w = os.Stderr
	}
	terminal := &installCompletionWriter{Writer: w}
	opts.Writer = terminal
	defer func() {
		if unlockErr := lease.Unlock(); unlockErr != nil {
			err = errors.Join(err, fmt.Errorf("install: release per-manifest lease for %q: %w", opts.Server, unlockErr))
		}
		if err == nil && terminal.complete {
			printInstallCompletion(w, terminal.withWarnings)
		}
	}()
	return apply(opts)
}

// Progress and rollback diagnostics stream normally; terminal success waits for
// the outer lease to settle. Adopt already buffers its complete narration.
type installCompletionWriter struct {
	io.Writer
	complete, withWarnings bool
}

func printInstallCompletion(w io.Writer, withWarnings bool) {
	if terminal, ok := w.(*installCompletionWriter); ok {
		terminal.complete, terminal.withWarnings = true, withWarnings
		return
	}
	if withWarnings {
		fmt.Fprintln(w, "\nInstall complete with warnings.")
	} else {
		fmt.Fprintln(w, "\nInstall complete.")
	}
}

// installWithAdoptLeaseHeld loads and applies one plan while its caller owns
// the canonical manifest lease (or is performing a read-only dry run).
func (a *API) installWithAdoptLeaseHeld(ctx context.Context, opts InstallOpts, receipt func(InstallMutationReceiptV1)) error {
	w := opts.Writer
	if w == nil {
		w = os.Stderr
	}
	manifestDir, err := CanonicalManifestDir()
	if err != nil {
		return fmt.Errorf("install: %w", err)
	}
	// Surface a PRE-EXISTING embed-vs-disk collision (a disk manifest shadowing a
	// shipped server name that the embed-first read below ignores). Warn only —
	// never delete the operator's file; NEW such files are refused at
	// ManifestCreateIn.
	if warn := embeddedDiskShadowWarning(opts.Server, manifestDir); warn != "" {
		fmt.Fprintf(w, "warning: %s\n", warn)
	}
	// 1. Load manifest (embed FS first, disk fallback for dev flow).
	//    The canonical installed binary resolves manifests from its
	//    embedded FS so an install launched from any cwd finds the same
	//    18 manifests the daemon sees — previously install opened disk
	//    and failed or saw a stale subset.
	data, err := loadManifestYAMLEmbedFirstFromDir(opts.Server, manifestDir)
	if err != nil {
		return fmt.Errorf("load manifest %s: %w", opts.Server, err)
	}
	m, err := parseManifestForName(opts.Server, data)
	if err != nil {
		return err
	}
	// 1a. Reject workspace-scoped manifests at the Install entrypoint.
	// These require the explicit per-workspace `mcphub register` flow.
	if err := refuseWorkspaceScopedInstall(m, w); err != nil {
		return err
	}
	authorityRequest := CanonicalAtAdmission()
	if IsSerenaServer(m.Name) && installOptsMayWriteClients(opts) {
		var targetErr error
		authorityRequest, targetErr = a.prepareInstallClientRoutingDecision(&opts)
		if targetErr != nil {
			return fmt.Errorf("resolve client routing target: %w", targetErr)
		}
	}
	// 2. Preflight.
	if err := preflightWithScope(m, installScopeFromOpts(opts)); err != nil {
		return err
	}
	// 3. Build plan (opts resolved by the shared single owner).
	plan, err := BuildPlanWithOpts(m, a.installBuildPlanOpts(opts))
	if err != nil {
		return err
	}
	bindPlanSupervisorIntentManifestHash(plan, ManifestHashContent(data))
	return a.installFrozenPlanCore(ctx, m, plan, opts, authorityRequest, w, receipt)
}

// installFrozenPlanCore applies one already-frozen plan and returns its exact
// mutation receipt to the caller. A committed client-config row is evidence of
// its lower transaction only; it never promotes the wider install outcome.
func (a *API) installFrozenPlanCore(ctx context.Context, m *config.ServerManifest, plan *Plan, opts InstallOpts, authorityRequest ClientRoutingAuthorityRequest, w io.Writer, receipt func(InstallMutationReceiptV1)) error {
	if opts.ProjectClientCreate != nil {
		return a.installProjectClientAttachment(ctx, m, plan, opts, w, receipt)
	}
	return a.installFrozenPlanCoreWithManagedDeps(ctx, m, plan, opts, authorityRequest, w, receipt, productionManagedRegistrationInstallDeps(a))
}

func (a *API) installFrozenPlanCoreWithManagedDeps(ctx context.Context, m *config.ServerManifest, plan *Plan, opts InstallOpts, authorityRequest ClientRoutingAuthorityRequest, w io.Writer, receipt func(InstallMutationReceiptV1), deps managedRegistrationInstallCompositionDeps) (err error) {

	selected, selectErr := selectGlobalInstallExecutionPhase(m, plan, opts.DaemonFilter, opts.DryRun, w, opts.SymlinkConsents)
	if selectErr != nil {
		return selectErr
	}
	plan.selectedExecutionPhase = selected
	if err = a.prepareSerenaInstallPlan(ctx, m, plan, opts.DryRun); err != nil {
		return err
	}
	if plan.serenaPreparationRequest != nil {
		bounded, cancel := context.WithDeadline(ctx, plan.serenaPreparationRequest.WorkDeadline)
		defer cancel()
		ctx = bounded
	}
	if plan.serenaPreparedInvocation != nil {
		defer func() {
			proof, closeErr := plan.serenaPreparedInvocation.CloseObserved()
			err = errors.Join(err, closeErr, proof.Validate(plan.serenaPreparedInvocation))
		}()
	}
	// Freeze task and client identities from the exact plan before apply. The
	// receiving port re-reads every client after commit; no post-write
	// observation can become the expected identity.
	frozen := frozenInstallMutationReceipt(plan, opts)
	defer func() {
		frozen.ClientConfigSettlements = append([]ClientConfigSettlementV1(nil), plan.clientConfigSettlements...)
		if !opts.DryRun && err == nil {
			frozen.Committed = true
		}
		if receipt != nil {
			receipt(frozen)
		}
	}()
	// A selected global stdio bridge is not advertisable until the exact frozen
	// supervisor descriptor has completed a contained initialize -> tools/list
	// probe and its provisional process tree has been reaped. This runs before
	// every audit, client, intent, or scheduler writer.
	if err := a.admitFrozenStdioBridgeBeforeMutation(ctx, m, plan, opts); err != nil {
		return err
	}
	var allClients map[string]clients.Client
	var clientConstructionFailures []string
	needsBindingExpectations := receipt != nil && len(plan.ClientUpdates) > 0 && !opts.SkipClientConfigWrites
	needsManagedRegistration := !opts.DryRun && !opts.SkipClientConfigWrites && len(plan.ClientUpdates) > 0
	if needsBindingExpectations || needsManagedRegistration {
		if deps.Clients == nil {
			return fmt.Errorf("managed registration client population is unavailable")
		}
		allClients, clientConstructionFailures = deps.Clients()
	}
	if needsBindingExpectations || needsManagedRegistration {
		if err := freezeInstallRelayExePath(plan); err != nil {
			return err
		}
	}
	if needsBindingExpectations {
		expectations, expectationErr := freezeInstallBindingExpectationsFromClients(plan, m.Name, plan.installRelayExePath, allClients)
		if expectationErr != nil {
			return expectationErr
		}
		frozen.bindingExpectations = expectations
		frozen.RequireBindings = len(expectations) > 0
	}
	// 4. Execute the PR core exactly once. Managed registration runs only after
	// that core commits and may verify/journal/project without a second write.
	materializationCommitted, err := a.executeManagedRegistrationInstall(ctx, m, plan, opts, authorityRequest, w, allClients, clientConstructionFailures, deps)
	if materializationCommitted && !opts.DryRun {
		frozen.Committed = true
	}
	// The rollback proof is produced under inner locks. Consume it only after
	// their deferred releases have settled, while every caller still holds the
	// canonical manifest lease (ordinary Install, bulk install, and adopt).
	var rolledBack *providerInstallUnpublishedRollbackError
	if errors.As(err, &rolledBack) && !errors.Is(err, ErrLockReleaseUnconfirmed) &&
		!errors.Is(err, clients.ErrConfigLockReleaseUnconfirmed) {
		err = errors.Join(err, markProviderUnpublishedRollbackSettled(m.Name))
	}
	return err
}

func freezeInstallRelayExePath(plan *Plan) error {
	if plan == nil {
		return fmt.Errorf("freeze install relay path: nil plan")
	}
	if plan.installRelayExePath != "" {
		return nil
	}
	resolve := canonicalInstallRelayPathFn
	if plan.runtimeProduct != nil {
		resolve = func() (string, error) { return resolveInstallRuntimeProduct(plan.runtimeProduct) }
	}
	path, err := resolve()
	if err != nil {
		return fmt.Errorf("resolve install relay executable: %w", err)
	}
	if strings.TrimSpace(path) == "" {
		return fmt.Errorf("resolve install relay executable: empty path")
	}
	plan.installRelayExePath = path
	return nil
}

// InstallAll is the production entry point for bulk install. Reads
// the authoritative server list from the embed FS (with disk union
// for dev flow) so the canonical installed binary behaves identically
// regardless of cwd or whether a dev source tree sits nearby.
//
// Workspace-scoped manifests are skipped silently — not a failure, just
// not this command's job. Such servers require the explicit per-workspace
// `mcphub register` flow; a notice is emitted to w so the user knows why
// those names were omitted.
func (a *API) InstallAll(dryRun bool, w io.Writer) []InstallResult {
	return a.InstallAllWithOpts(InstallAllOpts{DryRun: dryRun, Writer: w})
}

func (a *API) InstallAllWithOpts(opts InstallAllOpts) []InstallResult {
	names, err := listManifestNamesEmbedFirst()
	if err != nil {
		return []InstallResult{{Err: err}}
	}
	var results []InstallResult
	var skipped []string
	for _, name := range names {
		// Probe the manifest kind cheaply. A parse error here is not
		// fatal — the normal install path will surface the same error
		// with its usual wrapping — so we fall through on failure.
		if data, derr := loadManifestYAMLEmbedFirst(name); derr == nil {
			if mf, perr := parseManifestForName(name, data); perr == nil && mf.Kind == config.KindWorkspaceScoped {
				skipped = append(skipped, name)
				continue
			}
		}
		var receipt InstallMutationReceiptV1
		err := a.installUsingEmbedFirstWithReceipt(InstallOpts{
			Server:            name,
			ClientsInclude:    opts.ClientsInclude,
			IncludeAllClients: opts.IncludeAllClients,
			DryRun:            opts.DryRun,
			Writer:            opts.Writer,
			GUIPort:           opts.GUIPort,
			RoutingTarget:     opts.RoutingTarget,
		}, func(frozen InstallMutationReceiptV1) { receipt = frozen })
		results = append(results, InstallResult{Server: name, Err: err, ClientConfigSettlements: append([]ClientConfigSettlementV1(nil), receipt.ClientConfigSettlements...)})
	}
	if len(skipped) > 0 && opts.Writer != nil {
		fmt.Fprintf(opts.Writer, "Skipped %d workspace-scoped manifest(s); use `mcphub register` instead: %v\n",
			len(skipped), skipped)
	}
	return results
}

// InstallAllFrom installs every manifest under the explicit opts.ManifestDir.
// Retained for test hermetic-filesystem use and legacy callers that pass
// a tempdir; production uses InstallAll which consults the embed FS.
//
// Workspace-scoped manifests in the directory are skipped silently (same
// contract as InstallAll).
func (a *API) InstallAllFrom(opts InstallAllOpts) []InstallResult {
	var results []InstallResult
	entries, err := os.ReadDir(opts.ManifestDir)
	if err != nil {
		return []InstallResult{{Err: err}}
	}
	var skipped []string
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		manifestPath := filepath.Join(opts.ManifestDir, e.Name(), "manifest.yaml")
		if _, err := os.Stat(manifestPath); err != nil {
			continue
		}
		// Skip workspace-scoped manifests — same contract as InstallAll.
		if data, oerr := os.ReadFile(manifestPath); oerr == nil {
			if mf, perr := parseManifestForName(e.Name(), data); perr == nil && mf.Kind == config.KindWorkspaceScoped {
				skipped = append(skipped, e.Name())
				continue
			}
		}
		var receipt InstallMutationReceiptV1
		err := a.installFromManifestDirWithReceipt(InstallOpts{
			Server:            e.Name(),
			ClientsInclude:    opts.ClientsInclude,
			IncludeAllClients: opts.IncludeAllClients,
			DryRun:            opts.DryRun,
			Writer:            opts.Writer,
			GUIPort:           opts.GUIPort,
			RoutingTarget:     opts.RoutingTarget,
		}, opts.ManifestDir, func(frozen InstallMutationReceiptV1) { receipt = frozen })
		results = append(results, InstallResult{Server: e.Name(), Err: err, ClientConfigSettlements: append([]ClientConfigSettlementV1(nil), receipt.ClientConfigSettlements...)})
	}
	if len(skipped) > 0 && opts.Writer != nil {
		fmt.Fprintf(opts.Writer, "Skipped %d workspace-scoped manifest(s); use `mcphub register` instead: %v\n",
			len(skipped), skipped)
	}
	return results
}

// EmbeddedDiskShadowWarning returns the operator-facing pre-existing
// embed-vs-disk collision warning for a server (empty when there is none),
// computed against the SAME dir + byte-compare the Install / installUsingEmbedFirst
// emit sites use. It exists so GUI callers can surface the warning in their HTTP
// RESPONSE (visible to the operator) rather than relying on the CLI Writer, which
// for a nil-Writer GUI install lands on os.Stderr the operator never sees (bot PR
// #494 P2). Single owner: embeddedDiskShadowWarning; this is the exported wrapper
// idiom mirroring IsEmbeddedManifestName. The CLI Install path keeps its own
// stderr warn for `mcphub install` operators.
func EmbeddedDiskShadowWarning(server string) string {
	dir, err := CanonicalManifestDir()
	if err != nil {
		return ""
	}
	return embeddedDiskShadowWarning(server, dir)
}

// installUsingEmbedFirst is the install entry that loads the manifest
// via loadManifestYAMLEmbedFirst. Mirrors Install's audit-first +
// intent-after wiring per Task 10 (plan §62 audit-first canonical).
func (a *API) installUsingEmbedFirst(opts InstallOpts) error {
	return a.installUsingEmbedFirstWithReceipt(opts, nil)
}

func (a *API) installUsingEmbedFirstWithReceipt(opts InstallOpts, receipt func(InstallMutationReceiptV1)) error {
	return a.installWithFrozenPlan(context.Background(), opts, receipt)
}

// installBuildPlanOpts is the SINGLE owner of "which BuildPlanOpts does an
// install entry point use". Every plan-building install entry point — Install,
// installUsingEmbedFirst (the per-server entry InstallAllWithOpts drives), and
// installFromManifestDir — must go through it.
//
// It exists because the three had hand-copied the same struct literal and one
// copy drifted: installUsingEmbedFirst omitted DefaultClientsOverride, so
// `mcphub install --all` and the unfiltered GUI bulk install silently ignored
// the operator's persisted `clients.default_install` set while single-server
// installs honored it. The omission was invisible for as long as every
// commonly-overridden client was ALSO a compile-time default; it became
// reachable the moment cursor moved to opt-in (bot PR #583). Resolving the opts
// in one place makes that class of drift structurally impossible rather than
// re-fixed per site.
func (a *API) installBuildPlanOpts(opts InstallOpts) BuildPlanOpts {
	return BuildPlanOpts{
		DaemonFilter:           opts.DaemonFilter,
		ClientsInclude:         opts.ClientsInclude,
		IncludeAllClients:      opts.IncludeAllClients,
		SkipClientConfigWrites: opts.SkipClientConfigWrites,
		DefaultClientsOverride: a.resolveDefaultClientsOverride(opts),
		GUIPort:                opts.GUIPort,
		CodexProjectRoot:       opts.CodexProjectRoot,
		CodexWorkingDir:        opts.CodexWorkingDir,
		ProjectClientCreate:    opts.ProjectClientCreate,
	}
}

// installFromManifestDir is Install-like but with an explicit manifestDir
// override. Used by InstallAllFrom so tests can point at a tempdir without
// mutating global executable-path state. Mirrors Install's audit-first +
// intent-after wiring per Task 10.
func (a *API) installFromManifestDir(opts InstallOpts, manifestDir string) error {
	return a.installFromManifestDirWithReceipt(opts, manifestDir, nil)
}

func (a *API) installFromManifestDirWithReceipt(opts InstallOpts, manifestDir string, receipt func(InstallMutationReceiptV1)) error {
	return withInstallManifestLease(opts, func(opts InstallOpts) error {
		return a.installFromManifestDirWithAdoptLeaseHeld(opts, manifestDir, receipt)
	})
}

func (a *API) installFromManifestDirWithAdoptLeaseHeld(opts InstallOpts, manifestDir string, receipt func(InstallMutationReceiptV1)) error {
	w := opts.Writer
	if w == nil {
		w = os.Stderr
	}
	manifestPath := filepath.Join(manifestDir, opts.Server, "manifest.yaml")
	data, err := os.ReadFile(manifestPath)
	if err != nil {
		return fmt.Errorf("open %s: %w", manifestPath, err)
	}
	m, err := parseManifestForName(opts.Server, data)
	if err != nil {
		return err
	}
	authorityRequest := CanonicalAtAdmission()
	if IsSerenaServer(m.Name) && installOptsMayWriteClients(opts) {
		var targetErr error
		authorityRequest, targetErr = a.prepareInstallClientRoutingDecision(&opts)
		if targetErr != nil {
			return fmt.Errorf("resolve client routing target: %w", targetErr)
		}
	}
	if err := preflightWithScope(m, installScopeFromOpts(opts)); err != nil {
		return err
	}
	plan, err := BuildPlanWithOpts(m, a.installBuildPlanOpts(opts))
	if err != nil {
		return err
	}
	bindPlanSupervisorIntentManifestHash(plan, ManifestHashContent(data))
	return a.installFrozenPlanCore(context.Background(), m, plan, opts, authorityRequest, w, receipt)
}

func bindPlanSupervisorIntentManifestHash(plan *Plan, manifestHash string) {
	if plan == nil {
		return
	}
	for i := range plan.SupervisorIntent {
		plan.SupervisorIntent[i].manifestHash = manifestHash
	}
	plan.supervisorIntentHashesBound = true
}

func (a *API) installPlanCoreWithRoutingTargetLease(
	ctx context.Context,
	m *config.ServerManifest,
	plan *Plan,
	opts InstallOpts,
	authorityRequest ClientRoutingAuthorityRequest,
	w io.Writer,
) error {
	run := func() error {
		return a.installPlanCoreWithSymlinkConsents(ctx, m, plan, opts.DaemonFilter, opts.DryRun, w, opts.SymlinkConsents)
	}
	return a.withInstallRoutingTargetLease(ctx, m, opts, authorityRequest, run)
}

func (a *API) withInstallRoutingTargetLease(ctx context.Context, m *config.ServerManifest, opts InstallOpts, authorityRequest ClientRoutingAuthorityRequest, run func() error) error {
	if opts.DryRun || !IsSerenaServer(m.Name) || !installOptsMayWriteClients(opts) {
		return run()
	}
	return a.WithClientRoutingAuthorityLease(ctx, authorityRequest, func(ClientRoutingTarget) error {
		return run()
	})
}

// resolveDefaultClientsOverride returns the operator's persisted
// default-install client set ONLY when this install would fall through to
// the compile-time default — i.e. neither IncludeAllClients nor an explicit
// ClientsInclude is set. In every other case it returns nil so the explicit
// selection wins and the predicate never even consults the override.
//
// A read error (corrupt gui-preferences.yaml) is swallowed to nil: the
// install then proceeds on the compile-time default set rather than
// failing the whole install over an unreadable GUI-preference file. The
// override is a convenience layer; it must never make `mcphub install`
// harder to complete than it was before the feature existed.
func (a *API) resolveDefaultClientsOverride(opts InstallOpts) []string {
	if opts.SkipClientConfigWrites || opts.IncludeAllClients || len(opts.ClientsInclude) > 0 {
		return nil
	}
	override, err := a.DefaultInstallClientNamesOverride()
	if err != nil {
		return nil
	}
	return override
}

// installScopeFromOpts is the single InstallOpts -> AdmissionScope adapter used
// by every install entry point before planning or mutation.
func installScopeFromOpts(opts InstallOpts) AdmissionScope {
	return AdmissionScope{
		DaemonFilter:           opts.DaemonFilter,
		ClientsInclude:         opts.ClientsInclude,
		IncludeAllClients:      opts.IncludeAllClients,
		SkipClientConfigWrites: opts.SkipClientConfigWrites,
	}
}

// statusInternalDialFn is the test seam for the IPC status dial used by
// statusInternal. Defaults to the production DialSupervisorIPCStatus;
// tests swap it (and restore via t.Cleanup) to drive the
// ErrSupervisorIPCUnavailable fail-loud path hermetically, without a real
// supervisor.lock on disk. Mirrors the SupervisorIPCStatusFn seam in
// health.go.
var statusInternalDialFn = DialSupervisorIPCStatus

// Status returns the slice of MCP daemons under supervisor management
// (v0.5.0+) — same source DaemonStatusSnapshot uses for /api/status,
// so CLI `mcphub status` and the GUI poller (which feeds the tray
// icon) see the canonical 13-daemon view rather than scheduler.List's
// single supervisor-task row.
//
// Fail-loud contract (deep-review P3, operational-contract divergence
// fix): when the supervisor IPC is unreachable
// (ErrSupervisorIPCUnavailable — no lock owner sidecar, no pipe), this
// surfaces ErrSupervisorDown instead of silently falling back to the
// legacy scheduler scan. Mirrors health.go's DaemonsSection fail-loud
// contract for the SAME condition (health.go:424-437) — pre-fix, `mcphub
// status` (this path) and GET /api/status (health.go, when wired)
// diverged: the GUI failed loud while the CLI silently served stale
// scheduler rows for the deleted v0.4.x task model, misleading an
// operator or monitoring script relying on `mcphub status` into reading
// the legacy scan as current state.
//
// Unlike health.go's SupervisorIPCStatusFn (a nil-by-default package var
// gated on GUI startup wiring, internal/cli/gui.go:398), this path calls
// DialSupervisorIPCStatus unconditionally — there is no "unwired host"
// case to preserve here: `mcphub status` always attempts the real
// supervisor dial, so an IPC-unavailable outcome always means the
// supervisor itself is down, never an unwired seam.
//
// PR #215 fix: before this routing, poller + CLI both saw only the
// supervisor scheduler task, deriveState classified it as Failed
// (no port → alive=false), tray went StateError while Dashboard
// (via DaemonStatusSnapshot's IPC-first path) showed 11 Running
// daemons. Two divergent code paths produced two views of reality;
// unifying them through the IPC seam closes the divergence.
func (a *API) Status() ([]DaemonStatus, error) {
	return a.statusInternal(context.Background())
}

// statusInternal is the IPC-first routing implementation shared by
// Status() (with Background ctx) and StatusContext (with caller ctx).
// The IPC dial deadline is derived from the supplied ctx so that
// caller cancellation (HTTP request cancel, server shutdown, Ctrl+C
// via cobra cmd.Context()) propagates immediately to the supervisor
// pipe read instead of always waiting the full 5s under outage.
// Mirrors the established pattern at health.go:392-401.
//
// PR #215 r2 fix (codex review Finding 2): pre-r2 the IPC ctx was
// derived from context.Background() which severed the caller's
// cancellation chain — a CLI Ctrl+C or HTTP request cancel could
// not interrupt a stalled supervisor IPC dial mid-call.
//
// Deep-review P3 fix: an unreachable supervisor (errors.Is
// ErrSupervisorIPCUnavailable) now returns ErrSupervisorDown instead of
// silently falling through to StatusWithOpts (the legacy scheduler
// scan). See the Status() doc comment for the full rationale and why no
// nil-seam fallback applies on this path.
func (a *API) statusInternal(ctx context.Context) ([]DaemonStatus, error) {
	rows, readiness, err := a.statusReadinessSnapshot(ctx)
	if err != nil {
		return nil, err
	}
	regPath, regErr := DefaultRegistryPath()
	if regErr != nil {
		return nil, regErr
	}
	reg := NewRegistry(regPath)
	if regErr := reg.Load(); regErr != nil {
		return nil, regErr
	}
	if err := applyWorkspaceRegistryMetadata(rows, reg.Workspaces); err != nil {
		return nil, err
	}
	projection, projectionErr := a.ProjectSerenaWorkspaceSnapshotHeld(ctx, reg.Workspaces, SerenaWorkspaceProjectionModeSnapshot, rows, readiness)
	if projectionErr != nil {
		return nil, projectionErr
	}
	return projection.StatusRows, nil
}

// statusReadinessSnapshot performs the sole supervisor IPC observation for a
// status command and reduces readiness from that exact row set.
func (a *API) statusReadinessSnapshot(ctx context.Context) ([]DaemonStatus, ReadinessSnapshotV1, error) {
	ipcCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	rows, err := statusInternalDialFn(ipcCtx)
	if err == nil {
		readiness, readinessErr := a.AssessReadinessFromStatusRows(ctx, rows, nil, false, time.Now().UTC())
		if err := statusReadinessError(readinessErr); err != nil {
			return nil, ReadinessSnapshotV1{}, err
		}
		return rows, readiness, nil
	}
	if errors.Is(err, ErrSupervisorIPCUnavailable) {
		return nil, ReadinessSnapshotV1{}, ErrSupervisorDown
	}
	return nil, ReadinessSnapshotV1{}, err
}

// StatusWithHealth is the pre-M5 shim kept for backwards compatibility. New
// callers should prefer StatusWithOpts.
func (a *API) StatusWithHealth(probeHealth bool) ([]DaemonStatus, error) {
	return a.StatusWithOpts(StatusOpts{ProbeHealth: probeHealth})
}

// StatusOpts bundles the flags governing Status enrichment. ProbeHealth
// toggles the synthetic initialize + tools/list round-trip. When
// ForceMaterialize is also true, workspace-scoped rows receive an
// additional no-op tools/call that triggers real backend materialization
// (the proxy writes LifecycleActive/Missing/Failed to the registry, which
// the enrichment then reloads onto the row).
//
// ForceMaterialize requires ProbeHealth. StatusWithOpts returns
// ErrForceMaterializeRequiresHealth when that invariant is violated —
// both the CLI help and the `--force-materialize` flag description promise
// this dependency. Allowing the flag in isolation would either be a
// silent no-op (confusing) or trigger materialization without the
// operator asking for the accompanying probe.
type StatusOpts struct {
	ProbeHealth      bool
	ForceMaterialize bool
}

// SchedulerObservation describes whether StatusWithOptsDetailed obtained a
// scheduler task snapshot. It is deliberately separate from daemon rows: a
// supervisor-intent or registry row remains useful when the legacy scheduler
// bridge is temporarily unavailable.
type SchedulerObservation string

const (
	SchedulerObservationObserved    SchedulerObservation = "observed"
	SchedulerObservationUnsupported SchedulerObservation = "unsupported"
	SchedulerObservationUnavailable SchedulerObservation = "unavailable"
)

// StatusWithOptsResult is the detailed form of StatusWithOpts. The legacy
// StatusWithOpts wrapper continues to return rows alone so its callers and
// JSON output keep their existing shape.
type StatusWithOptsResult struct {
	Rows        []DaemonStatus
	Observation SchedulerObservation
}

// ErrForceMaterializeRequiresHealth enforces the documented `--health`
// prerequisite for `--force-materialize`. Callers should surface this
// verbatim to the end user.
var ErrForceMaterializeRequiresHealth = errors.New("--force-materialize requires --health")

// StatusWithOpts is Status + optional MCP-level probes. When
// opts.ProbeHealth is true, the function POSTs initialize + tools/list to
// each Running daemon's /mcp endpoint and fills DaemonStatus.Health. When
// opts.ForceMaterialize is also true, workspace-scoped rows get an
// additional no-op tools/call that drives the lazy proxy through
// materialization and records the resulting 5-state lifecycle in the
// registry (which this function then reloads onto the row).
//
// Disabled by default because the probe adds 1-3 s of per-daemon HTTP
// round-trips — acceptable for an interactive command but wasteful for
// repeated polling.
func (a *API) StatusWithOpts(opts StatusOpts) ([]DaemonStatus, error) {
	detailed, err := a.StatusWithOptsDetailed(opts)
	if err != nil {
		return nil, err
	}
	return detailed.Rows, nil
}

// StatusWithOptsDetailed is StatusWithOpts plus the bounded scheduler
// observation outcome. Only typed scheduler.ErrUnavailable is treated as a
// transient unavailable observation; all other operational failures remain
// fail-loud. scheduler.ErrNotImplemented remains the established unsupported
// schedulerless mode.
func (a *API) StatusWithOptsDetailed(opts StatusOpts) (StatusWithOptsResult, error) {
	if opts.ForceMaterialize && !opts.ProbeHealth {
		return StatusWithOptsResult{}, ErrForceMaterializeRequiresHealth
	}
	tasks, observation, err := statusSchedulerTasksDetailed()
	if err != nil {
		return StatusWithOptsResult{}, err
	}
	result := make([]DaemonStatus, 0, len(tasks))
	for _, t := range tasks {
		result = append(result, DaemonStatus{
			TaskName:   t.Name,
			State:      t.State,
			LastResult: int32(t.LastResult),
			NextRun:    t.NextRun,
		})
	}
	// Empty dir → enrichStatus uses the embed-first resolution path so
	// `mcphub status` from %TEMP% sees the same server set that the
	// daemon sees. Registry path is best-effort; if DefaultRegistryPath
	// errors (no $HOME, etc.), workspace-scoped rows get the task-name
	// parse only — their Lifecycle column shows "-" rather than a value.
	regPath, regErr := DefaultRegistryPath()
	if regErr != nil {
		regPath = ""
	}
	// Track every task name already seeded (scheduler tasks, then each merge
	// below) so the supervised/registry/intent merges never double-emit a row.
	// Bare-form key (leading "\" trimmed) so a scheduler-emitted "\mcp-..." row
	// dedups against a registry/intent "mcp-..." entry. Declared OUT of the
	// regPath block so the supervisor-intent merge below dedups even when the
	// registry path can't be resolved.
	seen := make(map[string]bool, len(result))
	for i := range result {
		seen[strings.TrimPrefix(result[i].TaskName, "\\")] = true
	}
	// Merge supervised/registry-backed LSP proxies that have NO scheduler task.
	// The v0.5.x supervised path (register_supervisor.go) writes these as
	// supervisor-intent children only, so sch.List never surfaces them — without
	// this merge they vanish from --workspace-scoped / --health / --force-materialize
	// even though they are registered and running. enrichStatusWithRegistry then
	// overlays Port/Language/Lifecycle and the alive-probe derives their State.
	registryOnlyLive := map[string]bool{}
	if regPath != "" {
		reg := NewRegistry(regPath)
		if err := reg.Load(); err == nil {
			for _, e := range reg.LSPEntries() {
				if e.TaskName == "" {
					continue
				}
				if !IsLazyProxyTaskName(e.TaskName) {
					continue
				}
				bare := strings.TrimPrefix(e.TaskName, "\\")
				if seen[bare] {
					continue
				}
				seen[bare] = true
				registryOnlyLive[bare] = e.Port != 0 && registryOnlyStatusPortLiveFn != nil && registryOnlyStatusPortLiveFn(e.Port)
				result = append(result, DaemonStatus{TaskName: e.TaskName, State: "Stopped"})
			}
		}
	}
	// Merge Phase-F supervisor-only GLOBAL daemons that have NO scheduler task.
	// In v0.6 every GLOBAL install uses SkipSchedulerTasks=true
	// (install_parsed_manifest.go), so a newly installed/migrated global daemon
	// (e.g. `fetch`) exists ONLY in supervisor-intent.json — statusSchedulerTasks
	// never surfaces it, and the LSP merge above only covers workspace-scoped
	// lazy-proxy rows. Without this seed the daemon DISAPPEARS from the
	// --health / --force-materialize / ProbeHealth table even though bare
	// `mcphub status` shows it (that path goes through the supervisor IPC seam).
	//
	// Best-effort + fail-open: a missing/unreadable intent file keeps the
	// scheduler-only behavior. Maintenance descriptors (watchdog/liveness/
	// weekly-refresh) are excluded — they are not probeable daemons — and any
	// descriptor already represented by a scheduler/LSP row is deduped away.
	// The per-row State is seeded "Ready" (the same neutral seed the scheduler
	// path uses) so enrichStatusWithRegistry's alive-probe derives the real
	// state: deriveState("Ready", alive) → "Running" when the port is bound,
	// "Stopped" otherwise. The descriptor carries the authoritative Server/
	// Daemon/Port, which enrichStatusWithRegistry preserves (the manifest-port
	// lookup only overwrites when the manifest actually has a matching port).
	mergeSupervisorOnlyDaemonRows(&result, seen)
	enrichStatusWithSpawnHolds(result)
	if err := enrichStatusWithRegistry(result, "", regPath); err != nil {
		return StatusWithOptsResult{}, err
	}
	finalizeRegistryOnlyWorkspaceStates(result, registryOnlyLive)
	if opts.ProbeHealth {
		probeDaemonHealth(result)
	}
	if opts.ForceMaterialize {
		forceMaterializeWorkspaceScoped(result, regPath)
	}
	return StatusWithOptsResult{Rows: result, Observation: observation}, nil
}

// enrichStatusWithSpawnHolds fills SpawnHoldReason/SpawnHoldPath on rows built
// by the StatusWithOpts family from supervisor-state.json.
//
// WHY THIS EXISTS. StatusWithOpts builds rows from three sources that CANNOT
// know about a spawn hold — the scheduler task list, the registry LSP entries,
// and supervisor-intent.json (the DESCRIPTOR file). The hold lives in
// supervisor-STATE.json, which none of them read. Without this step
// `mcphub status --health`, `--workspace-scoped`, `--force-materialize`,
// StatusWithHealth, and the unwired-host `/api/status` fallback all render a
// held daemon with NO explanation — while bare `mcphub status` (the supervisor
// IPC path) explains it fine.
//
// That asymmetry is the worst possible shape for this feature: `--health` is
// precisely what an operator runs WHEN THEY SUSPECT SOMETHING IS WRONG, so the
// one command most likely to be typed during the incident was the one path that
// dropped the answer. The pre-spawn gate exists because a correct diagnosis
// that never reaches a human is worth nothing.
//
// One enrichment step rather than three constructor patches: the scheduler and
// registry rows have no access to the state file at all, so the fix has to be a
// join, and a single join is also a single place to keep correct.
//
// Best-effort by design: an unreadable/absent state file leaves the rows
// exactly as they were. A missing explanation must never turn a working status
// command into an error.
func enrichStatusWithSpawnHolds(rows []DaemonStatus) {
	if len(rows) == 0 {
		return
	}
	state, err := readSupervisorStateForStatus()
	if err != nil || state == nil || len(state.Daemons) == 0 {
		return
	}
	for i := range rows {
		if rows[i].TaskName == "" {
			continue
		}
		d, ok := state.Daemons[canonicalIntentTaskKey(rows[i].TaskName)]
		if !ok {
			continue
		}
		rows[i].SpawnHoldReason = d.SpawnHoldReason
		rows[i].SpawnHoldPath = d.SpawnHoldPath
	}
}

// readSupervisorStateForStatus loads supervisor-state.json for the status
// join above. Mirrors readSupervisorIntentForStatus (same state dir, same
// best-effort contract, same daemonStateRootOverride test seam).
func readSupervisorStateForStatus() (*SupervisorStateFile, error) {
	stateDir, err := DaemonStateDir()
	if err != nil {
		return nil, err
	}
	return ReadSupervisorState(joinStateFilePath(stateDir, supervisorStateFileLeaf))
}

// readSupervisorIntentForStatus loads the supervisor-intent.json descriptor
// set used to seed Phase-F supervisor-only daemon rows. Best-effort: a
// missing/unreadable intent file (no install yet, parent-dir gate rejection,
// decode error) returns (nil, err) and the caller keeps the scheduler-only
// behavior. Honors the daemonStateRootOverride state-dir test seam (via
// DefaultSupervisorIntentPath → DaemonStateDir), so tests redirect the read to
// a temp dir without env vars.
func readSupervisorIntentForStatus() (*SupervisorIntentFile, error) {
	path, err := DefaultSupervisorIntentPath()
	if err != nil {
		return nil, err
	}
	return ReadSupervisorIntent(path)
}

// mergeSupervisorOnlyDaemonRows appends a status row for every Phase-F
// supervisor-only GLOBAL daemon — a descriptor present in
// supervisor-intent.json with NO matching scheduler task (v0.6 global installs
// use SkipSchedulerTasks=true) and not already merged from the registry LSP
// path. Without this, such daemons (e.g. `fetch`) are invisible to the
// StatusWithOpts health/force-materialize path even though bare
// `mcphub status` (supervisor IPC seam) lists them.
//
// Dedup is by bare (leading-"\" trimmed) task name against the shared `seen`
// set the caller already populated from the scheduler + LSP-merge rows, so a
// daemon present in BOTH scheduler and intent appears exactly once.
//
// Excluded:
//   - descriptors with an empty TaskName (cannot dedup or probe),
//   - maintenance descriptors (watchdog/liveness/weekly-refresh) — not
//     probeable daemons; IsMaintenanceTaskName is the single source of truth,
//   - any descriptor already represented by a scheduler/LSP row.
//
// Seeded State is "Ready" (the neutral scheduler seed) so the downstream
// enrichStatusWithRegistry alive-probe derives the real state from port
// liveness. The descriptor's Server/Daemon/Port are carried onto the row;
// enrichStatusWithRegistry re-derives Server/Daemon from the (global) task
// name and only overwrites Port when the manifest actually has a matching
// entry, so the descriptor's authoritative Port survives an embed miss.
//
// Best-effort + fail-open: a read error keeps the scheduler-only result.
func mergeSupervisorOnlyDaemonRows(result *[]DaemonStatus, seen map[string]bool) {
	intent, err := readSupervisorIntentForStatus()
	if err != nil || intent == nil {
		return
	}
	for _, d := range intent.Daemons {
		if d.TaskName == "" {
			continue
		}
		if IsMaintenanceTaskName(d.TaskName) {
			continue
		}
		bare := strings.TrimPrefix(canonicalIntentTaskKey(d.TaskName), "\\")
		if seen[bare] {
			continue
		}
		seen[bare] = true
		*result = append(*result, DaemonStatus{
			TaskName: canonicalIntentTaskKey(d.TaskName),
			Server:   d.Server,
			Daemon:   d.Daemon,
			Port:     d.Port,
			State:    "Ready",
		})
	}
}

// forceMaterializeProbe is the hook StatusWithOpts uses when
// opts.ForceMaterialize is true. Production path is sendForceMaterializeTools
// which actually POSTs a no-op tools/call over HTTP; tests replace this
// variable so they can assert "Materialize was triggered" without spinning
// up a real HTTP server.
//
// The result string is captured into the registry as LastError when
// non-empty; a nil error + empty string means the probe returned a valid
// JSON-RPC response (either success or JSON-RPC error — classification
// happens inside the hook).
var forceMaterializeProbe = sendForceMaterializeTools

var statusSchedulerFactory = scheduler.New
var restartSchedulerFactory = scheduler.New

// stopSchedulerFactory mirrors restartSchedulerFactory for the Stop /
// StopAll kill paths so tests can swap in a fake scheduler instead of
// touching the OS scheduler (spec §4 Phase A.1).
var stopSchedulerFactory = scheduler.New

func statusSchedulerTasksDetailed() ([]scheduler.TaskStatus, SchedulerObservation, error) {
	sch, err := statusSchedulerFactory()
	if err != nil {
		if errors.Is(err, scheduler.ErrNotImplemented) {
			return nil, SchedulerObservationUnsupported, nil
		}
		if errors.Is(err, scheduler.ErrUnavailable) {
			return nil, SchedulerObservationUnavailable, nil
		}
		return nil, "", err
	}
	tasks, err := sch.List("mcp-local-hub-")
	if err != nil {
		if errors.Is(err, scheduler.ErrNotImplemented) {
			return nil, SchedulerObservationUnsupported, nil
		}
		if errors.Is(err, scheduler.ErrUnavailable) {
			return nil, SchedulerObservationUnavailable, nil
		}
		return nil, "", err
	}
	return tasks, SchedulerObservationObserved, nil
}

func schedulerUnavailableError(err error) bool {
	if err == nil {
		return false
	}
	return errors.Is(err, scheduler.ErrNotImplemented)
}

func SchedulerUnavailableError(err error) bool {
	return schedulerUnavailableError(err)
}

// ReconcileSchedulerUnavailableError additionally accepts transient scheduler
// bridge unavailability. Reconciliation can safely continue from supervisor
// intent without a scheduler snapshot; inventory-dependent operations must
// continue to fail loudly on ErrUnavailable.
func ReconcileSchedulerUnavailableError(err error) bool {
	return schedulerUnavailableError(err) || errors.Is(err, scheduler.ErrUnavailable)
}

// restartSchedulerUnavailableError accepts a transient scheduler bridge
// failure only after Restart has already handled the requested daemon through
// the supervisor. The supervisor result is then the authoritative outcome;
// callers without that result must continue to fail loudly.
func restartSchedulerUnavailableError(err error) bool {
	return schedulerUnavailableError(err) || errors.Is(err, scheduler.ErrUnavailable)
}

// stopSchedulerUnavailableError accepts a transient scheduler bridge failure
// only after Stop has already durably settled the requested daemon through the
// supervisor. The supervisor result is then the authoritative outcome; callers
// without that result must continue to fail loudly.
func stopSchedulerUnavailableError(err error) bool {
	return schedulerUnavailableError(err) || errors.Is(err, scheduler.ErrUnavailable)
}

// forceMaterializeWorkspaceScoped walks rows and for every workspace-scoped
// entry (non-empty Language), sends a real no-op tools/call via the
// forceMaterializeProbe hook. The proxy will drive the backend through
// materialization and record the 5-state lifecycle in the registry.
// After every row is probed, the registry is reloaded and the rows'
// Lifecycle + LastError + timestamp fields are refreshed.
func forceMaterializeWorkspaceScoped(rows []DaemonStatus, regPath string) {
	// Collect tool-call errors per row so we can surface them after
	// the registry reload. LifecycleActive only promises "MCP handshake
	// completed" — the backend may still return JSON-RPC errors at the
	// tool-call layer (e.g., workspace-load failures in gopls or missing
	// file context for pyright). Without this capture, --force-materialize
	// showed "active" while the tool actually errored, misleading
	// operators during incidents.
	toolErr := make([]string, len(rows))
	var probeRows []int
	for i := range rows {
		if rows[i].Language == "" || rows[i].Port == 0 {
			continue
		}
		probeRows = append(probeRows, i)
	}
	if len(probeRows) > 0 {
		workerCount := DefaultLSPMaterializedHardCap
		if workerCount <= 0 || workerCount > len(probeRows) {
			workerCount = len(probeRows)
		}
		jobs := make(chan int)
		var wg sync.WaitGroup
		wg.Add(workerCount)
		for range workerCount {
			go func() {
				defer wg.Done()
				for idx := range jobs {
					toolErr[idx] = forceMaterializeProbe(rows[idx].Port, rows[idx].Backend)
				}
			}()
		}
		for _, idx := range probeRows {
			jobs <- idx
		}
		close(jobs)
		wg.Wait()
	}
	// Always propagate tool-level errors to rows first — this must
	// happen even when the registry reload path below is skipped
	// (empty regPath / unreadable registry). Without this, callers
	// observing rows[i].LastError would see the stale registry value
	// (or empty) instead of the actual --force-materialize outcome.
	for i := range rows {
		if toolErr[i] != "" {
			rows[i].LastError = toolErr[i]
		}
	}
	// Reload the registry once so every workspace-scoped row sees the
	// proxy's post-probe lifecycle + timestamp writes.
	if regPath == "" {
		return
	}
	reg := NewRegistry(regPath)
	if err := reg.Load(); err != nil {
		return
	}
	// Normalize leading "\" on both sides: Windows Task Scheduler's List
	// returns tasks with a leading "\" (e.g. "\mcp-local-hub-lsp-abc-python"),
	// whereas the registry stores the bare "mcp-local-hub-lsp-abc-python" form.
	// Without this the post-probe refresh silently misses every workspace-scoped
	// row on Windows even though the proxy has already written the new state.
	normalizeTaskName := func(s string) string { return strings.TrimPrefix(s, "\\") }
	byTask := make(map[string]WorkspaceEntry, len(reg.Workspaces))
	for _, e := range reg.Workspaces {
		byTask[normalizeTaskName(e.TaskName)] = e
	}
	for i := range rows {
		if rows[i].Language == "" {
			continue
		}
		if e, ok := byTask[normalizeTaskName(rows[i].TaskName)]; ok {
			rows[i].Lifecycle = e.Lifecycle
			rows[i].LastMaterializedAt = e.LastMaterializedAt
			rows[i].LastToolsCallAt = e.LastToolsCallAt
			// Preserve the probe's tool-error if one was captured
			// above; otherwise take the registry's value.
			if toolErr[i] == "" {
				rows[i].LastError = e.LastError
			}
		}
	}
}

// sendForceMaterializeTools POSTs a safe no-op tools/call to
// http://127.0.0.1:<port>/mcp so the lazy proxy triggers its own backend
// materialization. Tool choice per backend:
//
//	mcp-language-server → "hover" (safe, read-only; diagnostics alternative
//	  requires a loaded file that may not exist in the workspace yet)
//	gopls-mcp           → "go_workspace" (no-arg diagnostic equivalent)
//	other               → "tools/call" with a benign empty name; the proxy
//	  materializes before validating the tool name, so any valid
//	  JSON-RPC shape is enough to drive materialization
//
// Returns a non-empty backend-error string when the JSON-RPC response
// carries an "error" field. The proxy's own registry write marks
// LifecycleActive on MCP handshake success — which can diverge from
// the tool-call outcome when the backend speaks MCP but cannot serve
// tool calls (workspace-load errors in gopls, missing file in pyright,
// etc.). The caller surfaces the returned string as LastError so the
// CLI cell reads "OK (synth); backend ERR: <tool response err>"
// instead of hiding a tool-call failure behind LifecycleActive.
//
// Empty return on transport error (unreachable): we already return
// without touching the registry, and the subsequent registry reload
// will show whatever lifecycle the proxy last wrote.
func sendForceMaterializeTools(port int, backend string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	toolName := "hover"
	switch backend {
	case "gopls-mcp":
		toolName = "go_workspace"
	}
	body := fmt.Sprintf(
		`{"jsonrpc":"2.0","id":101,"method":"tools/call","params":{"name":%q,"arguments":{}}}`,
		toolName)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost,
		clients.HubLoopbackURL(port, "/mcp"),
		strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	payload, err := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	if err != nil {
		return ""
	}
	// Streamable HTTP can deliver the response as JSON directly or as a
	// text/event-stream frame. extractSSEPayload (sse.go) pulls the JSON
	// envelope out of an SSE frame (multi-line data:, CRLF, optional space
	// after the colon all handled) and returns the body unchanged when it
	// is plain application/json. One shared owner with singleHealthProbe +
	// capabilityListSubSection.
	jsonBytes := extractSSEPayload(payload)
	var env struct {
		Error *struct {
			Code    int    `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if err := json.Unmarshal(jsonBytes, &env); err != nil {
		return ""
	}
	if env.Error != nil && env.Error.Message != "" {
		// Truncate to match LastError capping.
		msg := env.Error.Message
		if len(msg) > MaxLastErrorBytes {
			msg = msg[:MaxLastErrorBytes] + "…"
		}
		return fmt.Sprintf("backend %s: %s", toolName, msg)
	}
	return ""
}

var healthProbeLivePortFn = portInUse
var preflightPortInUse = portInUse
var registryOnlyStatusPortLiveFn = portInUse

func finalizeRegistryOnlyWorkspaceStates(rows []DaemonStatus, liveByTask map[string]bool) {
	for i := range rows {
		live, ok := liveByTask[strings.TrimPrefix(rows[i].TaskName, "\\")]
		if !ok {
			continue
		}
		if live {
			rows[i].State = "Running"
		} else {
			rows[i].State = "Stopped"
		}
	}
}

// probeDaemonHealth fills DaemonStatus.Health for every Running row
// with a Port. Registry-only workspace-scoped rows may be seeded as
// Stopped before process lookup can prove liveness; for those rows, a
// live TCP port is enough to probe and promote the row to Running.
// The protocol: POST initialize (stream OR json Accept),
// capture Mcp-Session-Id, POST tools/list, count tools in the
// response. Any transport or JSON-RPC error is captured as Err with
// OK=false. Runs concurrently across rows to keep total time bounded.
//
// Workspace-scoped lazy proxies answer both initialize and tools/list
// synthetically from the embedded tool catalog without spawning the
// heavy backend. The probe therefore verifies the proxy is alive but
// says nothing about the underlying LSP binary. We tag those rows with
// Source="proxy-synthetic" so the CLI layer can distinguish them from
// a global-daemon row where a successful probe implies the upstream
// MCP server is also alive.
func probeDaemonHealth(rows []DaemonStatus) {
	var wg sync.WaitGroup
	for i := range rows {
		if rows[i].Port == 0 {
			continue
		}
		if rows[i].State != "Running" {
			if !rows[i].IsWorkspaceScoped || healthProbeLivePortFn == nil || !healthProbeLivePortFn(rows[i].Port) {
				continue
			}
			rows[i].State = "Running"
		}
		if rows[i].State != "Running" {
			continue
		}
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			// codex bot PR #588 P2 closure: the built-in `mcphub route` front
			// daemon is an ordinary global descriptor (nonzero Port, not
			// maintenance-classified), so mergeSupervisorOnlyDaemonRows feeds
			// it here — but it serves ONLY /serena/mcp and /lsp/<language>/mcp
			// (internal/gui/route_adapter.go RouteHandler). The generic probe
			// POSTs to /mcp, which that mux never mounts, so a perfectly
			// healthy front daemon rendered as a FAILED probe in
			// `mcphub status --health` and the GUI health view. Route it to
			// the endpoint it actually serves instead of excluding it (an
			// excluded row loses the "is the data plane up?" signal precisely
			// where an operator goes looking for it).
			if canonicalIntentTaskKey(rows[idx].TaskName) == BuiltinRouteTaskName {
				rows[idx].Health = routeFrontHealthProbeFn(rows[idx].Port)
				return
			}
			h := singleHealthProbeFn(rows[idx].Port)
			// Mark lazy-proxy probes by task-name structure, not by
			// registry-populated Language. Language can be empty when
			// registry enrichment fails (missing/corrupt file) even
			// though the task is clearly a lazy proxy. Without the
			// Source tag the CLI would show "OK (N)" as if a real
			// backend validated, when only the synthetic tools/list
			// responded — misleading during incidents.
			if h != nil && IsLazyProxyTaskName(rows[idx].TaskName) {
				h.Source = "proxy-synthetic"
			}
			rows[idx].Health = h
		}(i)
	}
	wg.Wait()
}

// singleHealthProbe does the initialize → tools/list sequence against
// 127.0.0.1:<port>/mcp with a 3 s total deadline. Returns a
// populated HealthProbe either way — the CLI decides whether OK or
// Err is the user-visible signal.
// singleHealthProbeFn is the test seam for singleHealthProbe. Production
// callers go through it; tests swap the var so the HTTP round-trip path
// is not exercised and the probe result is deterministic.
var singleHealthProbeFn = singleHealthProbe

// RouteFrontHealthSource tags a HealthProbe produced by routeFrontHealthProbe
// rather than the generic /mcp singleHealthProbe. Consumers MUST NOT read
// ToolCount off such a row: the front daemon is a ROUTER, so its tool catalog
// is whatever the currently-registered serena workspaces expose, and
// enumerating it would require a live workspace + a materialized backend. The
// probe therefore proves the MCP LIFECYCLE only, and leaves ToolCount at 0
// with this Source set so no renderer prints a phantom "OK (0)".
const RouteFrontHealthSource = "route-front"

// routeFrontHealthProbeFn is the test seam for routeFrontHealthProbe, mirroring
// singleHealthProbeFn.
var routeFrontHealthProbeFn = routeFrontHealthProbe

// routeFrontHealthProbe health-probes the built-in `mcphub route` front daemon
// on both endpoints it writes into client configuration. It reuses
// AssertMCPFrontRoutesLive — the SAME predicate `mcphub install
// --reconcile-mcp-front` requires before and after client writes. Single owner:
// "the front daemon is healthy" and "the front daemon is safe to reconcile
// clients onto" are the same claim, so they must not drift into two predicates.
//
// tools/list is deliberately NOT part of the probe: /serena/mcp's tools/list
// requires a minted session AND at least one registered serena workspace
// (internal/gui/serena_router_lifecycle.go handleToolsList returns the
// no-workspace error otherwise), so including it would report a healthy front
// daemon as failed on every host that has not registered a workspace yet.
func routeFrontHealthProbe(port int) *HealthProbe {
	if err := AssertMCPFrontRoutesLive(context.Background(), port); err != nil {
		return &HealthProbe{Source: RouteFrontHealthSource, Err: "route front: " + err.Error()}
	}
	return &HealthProbe{OK: true, Source: RouteFrontHealthSource}
}

const maxHealthProbeResponseBytes = 1 << 20 // 1 MiB

const healthProbeSessionCleanupTimeout = 3 * time.Second

var healthProbeHTTPClient = func() *http.Client {
	return &http.Client{Timeout: MCPReadinessProbeBudget}
}

func cleanupHealthProbeSession(client *http.Client, url, sessionID string) error {
	_, err := terminateMCPProbeSession(client, url, sessionID, healthProbeSessionCleanupTimeout)
	return err
}

func singleHealthProbe(port int) *HealthProbe {
	return singleHealthProbeContext(context.Background(), port)
}

// singleHealthProbeContext keeps the established three-second health budget
// while allowing a caller-owned cancellation boundary (such as a provisional
// install admission) to abort the HTTP exchange and reap its process tree.
func singleHealthProbeContext(parent context.Context, port int) (probe *HealthProbe) {
	ctx, cancel := context.WithTimeout(parent, MCPReadinessProbeBudget)
	defer cancel()
	url := clients.HubLoopbackURL(port, "/mcp")
	client := healthProbeHTTPClient()

	initBody := `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"mcphub-health","version":"1"}}}`
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, url, strings.NewReader(initBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	resp, err := client.Do(req)
	if err != nil {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureReadinessHostUnavailable, Stage: readinesswire.StageHost}))
	}
	sessionID := resp.Header.Get("Mcp-Session-Id")
	if resp.StatusCode >= 400 {
		failure := readinesswire.DecodeFailureResponse(resp.StatusCode, resp.Header.Get("Content-Type"), resp.Body)
		_ = resp.Body.Close()
		return healthProbeFromReadiness(readinessFromFailure(failure))
	}
	_ = resp.Body.Close()
	if sessionID != "" {
		defer func() {
			if err := cleanupHealthProbeSession(client, url, sessionID); err != nil {
				cleanup := MCPReadinessResult{
					SchemaVersion: "mcp-readiness-v1", State: MCPReadinessUnready,
					Stage:     MCPReadinessStageSessionCleanup,
					FailureID: MCPReadinessFailureSessionCleanup,
				}
				cleanup.Detail = closedReadinessDetail(cleanup)
				if probe == nil {
					probe = healthProbeFromReadiness(cleanup)
					return
				}
				probe = healthProbeFromReadiness(withSecondaryReadinessFailure(probe.Readiness, cleanup))
			}
		}()
	}

	listBody := `{"jsonrpc":"2.0","id":2,"method":"tools/list"}`
	req2, _ := http.NewRequestWithContext(ctx, http.MethodPost, url, strings.NewReader(listBody))
	req2.Header.Set("Content-Type", "application/json")
	req2.Header.Set("Accept", "application/json, text/event-stream")
	if sessionID != "" {
		req2.Header.Set("Mcp-Session-Id", sessionID)
	}
	resp2, err := client.Do(req2)
	if err != nil {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureReadinessHostUnavailable, Stage: readinesswire.StageToolsList}))
	}
	defer resp2.Body.Close()
	if resp2.StatusCode >= 400 {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.DecodeFailureResponse(resp2.StatusCode, resp2.Header.Get("Content-Type"), resp2.Body)))
	}
	raw, err := io.ReadAll(io.LimitReader(resp2.Body, maxHealthProbeResponseBytes+1))
	if err != nil {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureChildResponseInvalid, Stage: readinesswire.StageToolsList}))
	}
	if len(raw) > maxHealthProbeResponseBytes {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureChildResponseInvalid, Stage: readinesswire.StageToolsList}))
	}
	// SSE-or-JSON: extractSSEPayload (sse.go) pulls the JSON envelope out
	// of a text/event-stream frame and returns the body unchanged when it
	// is plain application/json. One shared owner with
	// capabilityListSubSection + sendForceMaterializeTools.
	payload := extractSSEPayload(raw)
	var parsed struct {
		Error  json.RawMessage `json:"error"`
		Result struct {
			Tools []json.RawMessage `json:"tools"`
		} `json:"result"`
	}
	if err := json.Unmarshal(payload, &parsed); err != nil {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureChildResponseInvalid, Stage: readinesswire.StageToolsList}))
	}
	if len(parsed.Error) > 0 {
		return healthProbeFromReadiness(readinessFromFailure(readinesswire.Failure{FailureID: readinesswire.FailureChildResponseInvalid, Stage: readinesswire.StageToolsList}))
	}
	return healthProbeFromReadiness(MCPReadinessResult{SchemaVersion: "mcp-readiness-v1", State: MCPReadinessReady, Stage: MCPReadinessStageToolsList, ToolCount: len(parsed.Result.Tools)})
}

// Uninstall removes all scheduler tasks and client entries for a server.
// It never prints; the returned UninstallReport carries the outcome for
// CLI/GUI rendering.
// retiredServerNames is the allowlist of server names whose manifests
// have been removed in prior upgrades but may still have stale scheduler
// tasks and client entries on user machines. Only these names trigger
// the manifest-less uninstall fallback; any other unknown name fails
// fast so a typo cannot delete unrelated tasks by prefix overlap.
var retiredServerNames = map[string]bool{
	"gdb": true, // removed in the gdb shared-manifest retirement (PR #13)
}

func (a *API) Uninstall(server string) (*UninstallReport, error) {
	data, err := loadManifestYAMLEmbedFirst(server)
	if err != nil {
		if os.IsNotExist(err) && retiredServerNames[server] {
			return a.uninstallWithoutManifest(server)
		}
		return nil, fmt.Errorf("load manifest %s: %w", server, err)
	}
	m, err := parseManifestForName(server, data)
	if err != nil {
		return nil, err
	}
	report := &UninstallReport{Server: m.Name}
	// Delete tasks scoped to THIS server. The trailing dash narrows
	// "mcp-local-hub-foo-*" without sweeping "mcp-local-hub-foobar-*"
	// (PR #126). The retired-manifest path uninstallWithoutManifest
	// uses the same shape.
	sch, tasks, err := uninstallSchedulerTasksForServer(m.Name)
	if err != nil {
		return nil, err
	}
	// Task 10 plan §65: BEFORE deleting tasks, mark each as
	// Desired=stopped + Reason=uninstalled and append a
	// server-uninstalled audit entry. Audit / intent failures are
	// logged + tolerated — uninstall is idempotent and must remove
	// tasks regardless.
	taskNamesForIntent := make([]string, 0, len(tasks))
	for _, t := range tasks {
		taskNamesForIntent = append(taskNamesForIntent, strings.TrimPrefix(t.Name, "\\"))
	}
	a.recordUninstallIntentForTasks(taskNamesForIntent, nil)
	if sch != nil {
		for _, t := range tasks {
			if err := sch.Delete(t.Name); err != nil {
				report.TaskDeleteWarns = append(report.TaskDeleteWarns, fmt.Sprintf("delete %s: %v", t.Name, err))
			} else {
				report.TasksDeleted = append(report.TasksDeleted, t.Name)
			}
		}
	}
	// v0.6 Phase F (bot PR #288 F1): a global daemon lives in
	// supervisor-intent.json, not in a scheduler task — the sch.List/sch.Delete
	// above removes NOTHING for it. Remove the server's descriptor rows,
	// server-weekly-refresh timer, and stop entries from supervisor-intent.json
	// (under the intent flock, preserving every sibling) and nudge a running
	// supervisor to reconcile so the now-descriptorless daemon is terminated
	// promptly instead of being respawned forever. Best-effort: a cleanup
	// failure is a warning, never a hard error — uninstall is idempotent.
	a.removeServerFromSupervisorIntentBestEffortForManifest(m, report)
	// Remove client entries — but ONLY entries that are unambiguously
	// hub-managed. PR #94's check was too permissive: it treated any
	// loopback HTTP URL as hub-managed, so a user's own MCP server
	// happening to share the manifest name (e.g. user already had a
	// `serena` entry pointing at their own loopback service) would be
	// deleted by uninstall. Use the relay-tuple identity (RelayServer,
	// RelayDaemon, RelayExePath) plus a URL prefix check; only when
	// ALL of those match what this manifest would have installed do we
	// remove the entry.
	allClients := clients.AllClients()
	for _, b := range m.ClientBindings {
		client := allClients[b.Client]
		if client == nil || !client.Exists() {
			continue
		}
		entry, err := client.GetEntry(m.Name)
		if err != nil {
			report.ClientWarns = append(report.ClientWarns, fmt.Sprintf("read %s entry from %s: %v", m.Name, b.Client, err))
			continue
		}
		if entry == nil {
			// No entry under this name in this client; nothing to
			// remove. Not a warning — the binding may have been
			// removed manually or the client never received it.
			continue
		}
		expectedURLs := expectedHubURLs(m, b)
		if !isHubOwnedEntryForAnyExpectedURL(entry, m.Name, b.Daemon, expectedURLs) {
			report.ClientWarns = append(report.ClientWarns, fmt.Sprintf("refusing to remove %s from %s: entry is not hub-managed (neither relay tuple nor URL matches what this manifest would install)", m.Name, b.Client))
			continue
		}
		if err := client.RemoveEntry(m.Name); err != nil {
			report.ClientWarns = append(report.ClientWarns, fmt.Sprintf("remove %s from %s: %v", m.Name, b.Client, err))
			continue
		}
		report.ClientsUpdated = append(report.ClientsUpdated, b.Client)
	}
	return report, nil
}

// expectedHubURL returns the URL that BuildPlan would install for this
// (manifest, binding) combination. Used by uninstall to recognize
// HTTP-native client entries (codex-cli, claude-code, cursor, gemini-cli,
// qwen-cli, vscode) that the hub installed but cannot mark with relay
// metadata because their adapters persist only Name + URL. Returns ""
// if the binding's daemon is unresolvable; callers must treat empty as
// "no URL match available".
//
// G6 remote-http branch (bot r1 P1 closure on PR #170): for
// transport=remote-http the entry URL came from the manifest's URL
// field (after ${secret:KEY} expansion). To recognize the entry on
// uninstall, re-expand the manifest URL and return it. Limitation:
// if a secret was rotated BETWEEN install and uninstall, the entry's
// URL embeds the OLD expansion while this function returns the NEW
// one — uninstall would skip the stale entry. Acceptable trade-off
// vs adding new state-file machinery; URL-as-secret-bearer is rare
// (headers are the dominant credential surface).
func expectedHubURL(m *config.ServerManifest, b config.ClientBinding) string {
	urls := expectedHubURLs(m, b)
	if len(urls) == 0 {
		return ""
	}
	return urls[0]
}

func expectedHubURLs(m *config.ServerManifest, b config.ClientBinding) []string {
	if m.Transport == config.TransportRemoteHTTP {
		urls := make([]string, 0, 3)
		if config.RemoteHTTPURLHasSecretPlaceholderHost(m.URL) {
			urls = append(urls, m.URL)
		}
		// Strict expansion mirrors what install/test-remote accept today.
		// It rejects a placeholder host that now expands to a
		// private/loopback/credentialed value, so an entry an OLDER build
		// installed (when the secret was e.g. 127.0.0.1) would no longer be
		// matchable through this path.
		if expanded, err := expandRemoteHTTPURLSecrets(m.URL, nil); err == nil && expanded != "" {
			if !stringSliceContains(urls, expanded) {
				urls = append(urls, expanded)
			}
		}
		// Lenient expansion for UNINSTALL OWNERSHIP MATCHING ONLY. It does
		// the raw ${secret:KEY} substitution (so it reproduces the exact
		// wire URL an older build wrote into the client config) WITHOUT the
		// install-time public-host rejection. This lets upgraded users
		// clean up an entry whose secret host is now disallowed for new
		// installs; the stricter validation still gates install/test-remote
		// (bot PR #388 r10: install.go:1190). Best-effort: a lookup failure
		// (missing non-host secret) simply yields no extra candidate.
		if lenient, err := ExpandSecrets(m.URL, nil); err == nil && lenient != "" {
			if !stringSliceContains(urls, lenient) {
				urls = append(urls, lenient)
			}
		}
		return urls
	}
	daemon, ok := findDaemon(m, b.Daemon)
	if !ok {
		return nil
	}
	urlPath := b.URLPath
	if urlPath == "" {
		urlPath = "/mcp"
	}
	// Single owner of the loopback-host literal (127.0.0.1, NOT "localhost") —
	// see clients.HubLoopbackURL for the IPv6-fallback / VPN-rerouting rationale.
	return []string{clients.HubLoopbackURL(daemon.Port, urlPath)}
}

func stringSliceContains(values []string, needle string) bool {
	for _, value := range values {
		if value == needle {
			return true
		}
	}
	return false
}

// isHubOwnedEntry reports whether the client entry was placed by this
// hub for the given (server, daemon) binding. Two ownership signals are
// accepted:
//
//  1. Relay-tuple match: RelayExePath set + RelayServer == manifest name
//     + RelayDaemon == binding daemon. Antigravity (the only relay-style
//     adapter today) persists this triple in client config.
//
//  2. Exact URL match: entry.URL equals what BuildPlan would install
//     (http://localhost:<port><urlPath>). HTTP-native adapters
//     (codex-cli, claude-code, cursor, gemini-cli, qwen-cli, vscode)
//     persist only Name + URL — relay-tuple recognition would leave
//     their entries behind on uninstall (Codex finding on PR #128).
//
// Either signal is sufficient. An entry that matches NEITHER (e.g. a
// user-owned MCP server happening to share the manifest name and
// pointing at a different URL or running externally) is preserved.
func isHubOwnedEntry(entry *clients.MCPEntry, server, daemon, expectedURL string) bool {
	if entry == nil {
		return false
	}
	// Signal 1: relay-tuple match.
	if entry.RelayExePath != "" && entry.RelayServer == server && entry.RelayDaemon == daemon {
		return true
	}
	// Signal 2: URL match against what BuildPlan would install — host-agnostic
	// across the loopback family. The exact compare keeps the fast path; the
	// loopback-equivalent compare ALSO recognizes an entry the hub wrote under
	// an earlier URL host as still hub-owned. This matters because the hub
	// switched its written host from "localhost" to "127.0.0.1" (to avoid the
	// ::1 IPv6-fallback / VPN-routing latency): an existing
	// http://localhost:<port>/mcp entry must still be recognized so a
	// re-install REPLACES it with the 127.0.0.1 form instead of orphaning the
	// old one and adding a duplicate.
	if expectedURL != "" && (entry.URL == expectedURL || hubLoopbackEquivalentURL(entry.URL, expectedURL)) {
		return true
	}
	// Signal 3: serena is the dynamic-pool router-fronted server. Its installed
	// client URL is the /serena/mcp router on the LIVE GUI port — which expectedURL
	// (derived from the legacy manifest's 9121 daemon) does NOT match. Recognize the
	// router URL PORT-AGNOSTICALLY (the GUI re-binds its port each start) so
	// uninstall removes serena's client entry instead of refusing it as
	// "not hub-managed" (serena-client-revert-on-manifest-sync uninstall-side).
	if IsSerenaServer(server) && IsHubOwnedSerenaRouterEntry(entry) {
		return true
	}
	return false
}

func isHubOwnedEntryForAnyExpectedURL(entry *clients.MCPEntry, server, daemon string, expectedURLs []string) bool {
	if len(expectedURLs) == 0 {
		return isHubOwnedEntry(entry, server, daemon, "")
	}
	for _, expectedURL := range expectedURLs {
		if isHubOwnedEntry(entry, server, daemon, expectedURL) {
			return true
		}
	}
	return false
}

// hubLoopbackEquivalentURL reports whether a and b are hub loopback URLs
// (http://localhost: / http://127.0.0.1: / http://[::1]:) that differ ONLY in
// the loopback host — i.e. the same :port + path after the host. Used so an
// entry written under a different loopback host (notably the legacy
// "localhost" form) still matches the current 127.0.0.1 form for ownership.
func hubLoopbackEquivalentURL(a, b string) bool {
	sa, oka := stripHubLoopbackHostPrefix(a)
	sb, okb := stripHubLoopbackHostPrefix(b)
	return oka && okb && sa == sb
}

// stripHubLoopbackHostPrefix removes a leading hub loopback host prefix
// ("http://localhost:", "http://127.0.0.1:", or "http://[::1]:") and returns
// the remainder ("<port><path>") plus whether a prefix matched.
func stripHubLoopbackHostPrefix(u string) (string, bool) {
	for _, p := range []string{"http://localhost:", "http://127.0.0.1:", "http://[::1]:"} {
		if rest, ok := strings.CutPrefix(u, p); ok {
			return rest, true
		}
	}
	return "", false
}

// uninstallWithoutManifest cleans up stale scheduler tasks and client
// entries for a retired server whose manifest is no longer shipped.
// Only called by Uninstall for names in retiredServerNames — a typo or
// unknown server name must never reach here, because the task-prefix
// match would delete any task whose name starts with
// "mcp-local-hub-<server>-" (e.g. uninstalling "se" would otherwise
// sweep up "mcp-local-hub-serena-*"). Best-effort: task deletion by
// prefix + RemoveEntry across every known client. An entry that does
// not exist is not an error.
func (a *API) uninstallWithoutManifest(server string) (*UninstallReport, error) {
	report := &UninstallReport{Server: server}
	// Trailing dash matches the main Uninstall path's narrowing from
	// PR #31 so "mcp-local-hub-gdb-default" matches but "mcp-local-hub-
	// gdbtool-*" does not.
	sch, tasks, err := uninstallSchedulerTasksForServer(server)
	if err != nil {
		return nil, err
	}
	// Task 10 plan §65: same uninstall intent + audit recording as
	// the manifest-backed path.
	retiredTaskNames := make([]string, 0, len(tasks))
	for _, t := range tasks {
		retiredTaskNames = append(retiredTaskNames, strings.TrimPrefix(t.Name, "\\"))
	}
	a.recordUninstallIntentForTasks(retiredTaskNames, nil)
	if sch != nil {
		for _, t := range tasks {
			if err := sch.Delete(t.Name); err != nil {
				report.TaskDeleteWarns = append(report.TaskDeleteWarns, fmt.Sprintf("delete %s: %v", t.Name, err))
			} else {
				report.TasksDeleted = append(report.TasksDeleted, t.Name)
			}
		}
	}
	// v0.6 Phase F (bot PR #288 F1): also clear any supervisor-intent
	// descriptor rows / timer / stops a retired server still owns and nudge
	// reconcile — same symmetric cleanup as the manifest-backed path.
	a.removeServerFromSupervisorIntentBestEffort(server, report)
	for name, client := range clients.AllClients() {
		if client == nil || !client.Exists() {
			continue
		}
		// Only touch clients that actually had an entry; RemoveEntry would
		// otherwise rewrite every client config file (generating a backup)
		// just to delete a nonexistent key.
		entry, err := client.GetEntry(server)
		if err != nil {
			report.ClientWarns = append(report.ClientWarns, fmt.Sprintf("lookup %s in %s: %v", server, name, err))
			continue
		}
		if entry == nil {
			continue
		}
		if err := client.RemoveEntry(server); err != nil {
			report.ClientWarns = append(report.ClientWarns, fmt.Sprintf("remove %s from %s: %v", server, name, err))
			continue
		}
		report.ClientsUpdated = append(report.ClientsUpdated, name)
	}
	return report, nil
}

// installedServerNameSet returns the set of currently-installed server
// names (the manifest catalog the longest-installed-prefix disambiguator
// consults). Best-effort by contract: on any catalog read error it returns
// an EMPTY set. blankServerRowOwnedByLongestInstalledPrefix treats an empty
// set as "no sibling proof exists", which makes it claim any prefix-matching
// task — the documented safe full-cleanup fallback (r33-2). This is the
// single source of `installedServers` threaded into the four hyphen-family
// ownership guards (uninstall delete, full-reinstall prune, stop/restart
// per-daemon gate, and the listTasksForServer scope filter).
func installedServerNameSet() map[string]struct{} {
	names, _ := listManifestNamesEmbedFirst()
	out := make(map[string]struct{}, len(names))
	for _, n := range names {
		out[n] = struct{}{}
	}
	return out
}

// taskOwnedByServerExactOrLongestPrefix reports whether a managed scheduler
// task name belongs to `server` under the same disambiguation the
// supervisor-intent ownership uses: an EXACT parsed-server match, OR (for a
// blank/legacy daemon row) the longest-installed-prefix rule. Workspace
// lazy-proxy tasks (`mcp-local-hub-lsp-<key>-<lang>`, no server slug in the
// name) are NOT owned by any global server name and always return false here;
// callers handle those via the dedicated workspace branch instead.
func taskOwnedByServerExactOrLongestPrefix(taskName, server string, installedServers map[string]struct{}) bool {
	if IsLazyProxyTaskName(taskName) {
		return false
	}
	if parsedServer, _ := ParseManagedTaskName(taskName); parsedServer == server {
		return true
	}
	return blankServerRowOwnedByLongestInstalledPrefix(canonicalIntentTaskKey(taskName), server, installedServers)
}

func uninstallSchedulerTasksForServer(server string) (scheduler.Scheduler, []scheduler.TaskStatus, error) {
	sch, err := newScheduler()
	if err != nil {
		if schedulerUnavailableError(err) {
			return nil, nil, nil
		}
		return nil, nil, err
	}
	prefix := "mcp-local-hub-" + server + "-"
	tasks, err := sch.List(prefix)
	if err != nil {
		if schedulerUnavailableError(err) {
			return nil, nil, nil
		}
		return nil, nil, err
	}
	// FIX 1 (bot PR #288 hyphen-family): sch.List is a raw HasPrefix match, so
	// uninstalling `demo` would otherwise sweep sibling `demo-alpha`'s task
	// `\mcp-local-hub-demo-alpha-beta` and DELETE it. Filter to tasks this
	// server actually owns under the longest-installed-prefix disambiguator
	// (the helper expects the canonical leading-backslash form) so both DELETE
	// callers (Uninstall, uninstallWithoutManifest) skip foreign tasks.
	installed := installedServerNameSet()
	owned := tasks[:0]
	for _, t := range tasks {
		if taskOwnedByServerExactOrLongestPrefix(t.Name, server, installed) {
			owned = append(owned, t)
		}
	}
	return sch, owned, nil
}

// BuildPlanOpts controls plan-time filtering.
type BuildPlanOpts struct {
	runtimeProduct      *InstallParsedManifestBypass
	ProjectClientCreate *InstallProjectClientCreate
	DaemonFilter        string
	ClientsInclude      []string
	IncludeAllClients   bool
	// SkipClientConfigWrites selects no client bindings while preserving the
	// daemon and supervisor-intent portions of the plan.
	SkipClientConfigWrites bool

	// DefaultClientsOverride, when non-empty, REPLACES the compile-time
	// clients.DefaultInstallClientNames() fallback used when ClientsInclude
	// is empty and IncludeAllClients is false. It carries the operator's
	// persisted default-install client set (gui-preferences.yaml, resolved
	// by API.DefaultInstallClientNamesEffective) into the plan-builder.
	//
	// The field — not a disk read inside installClientPredicate — is the
	// seam ON PURPOSE: it keeps BuildPlanWithOpts hermetic. A direct
	// BuildPlanWithOpts/BuildPlan caller (every unit test, plus any future
	// caller that wants the pure compile-time default) leaves this nil and
	// gets the {claude-code, codex-cli} set regardless of what
	// gui-preferences.yaml on the host happens to contain. Only the
	// top-level install entry points (Install / installFromManifestDir)
	// resolve the override from disk and populate this.
	DefaultClientsOverride []string

	// GUIPort is the live GUI/hub port for router-fronted servers (serena).
	// HERMETIC field: BuildPlanWithOpts does NO disk read; callers/tests supply
	// it. 0 means unknown.
	GUIPort int

	// CodexProjectRoot and CodexWorkingDir are the composition-root authority for
	// read-only Codex project-layer discovery. They must be supplied together.
	// Empty preserves the existing global-only install behavior.
	CodexProjectRoot string
	CodexWorkingDir  string
}

// BuildPlan translates a manifest into concrete intended actions using the
// default install clients.
func BuildPlan(m *config.ServerManifest, daemonFilter string) (*Plan, error) {
	return BuildPlanWithOpts(m, BuildPlanOpts{DaemonFilter: daemonFilter})
}

// BuildPlanWithOpts translates a manifest into concrete intended actions.
// If DaemonFilter is non-empty, only that daemon and its referencing client
// bindings are included; weekly refresh is skipped because a partial install
// does not imply a full-server restart. An unknown DaemonFilter or client
// selector is an error surfaced before any side effects.
func BuildPlanWithOpts(m *config.ServerManifest, opts BuildPlanOpts) (*Plan, error) {
	if err := validateInstallScopeApplicability(m, AdmissionScope{
		DaemonFilter:           opts.DaemonFilter,
		ClientsInclude:         opts.ClientsInclude,
		IncludeAllClients:      opts.IncludeAllClients,
		SkipClientConfigWrites: opts.SkipClientConfigWrites,
	}); err != nil {
		return nil, err
	}
	// G6 remote-http branch (sub-PR 2): no daemons, no scheduler
	// tasks, no per-daemon ports. Bind URL + expanded Headers
	// directly into each client's config; the client connects
	// straight to the remote endpoint without going through the
	// local hub.
	if m.Transport == config.TransportRemoteHTTP {
		p, err := buildRemoteHTTPPlan(m, opts)
		if err != nil {
			return nil, err
		}
		return freezeCodexInstallTargetNames(p, opts)
	}
	if opts.DaemonFilter != "" {
		if _, ok := findDaemon(m, opts.DaemonFilter); !ok {
			return nil, fmt.Errorf("no daemon %q in manifest %s", opts.DaemonFilter, m.Name)
		}
	}
	includeClient, err := installClientPredicate(opts)
	if err != nil {
		return nil, err
	}
	// Both direct supervisor intent and Windows Scheduler actions remain bound
	// to the canonical one-executable product.
	canonicalPath, err := resolveInstallRuntimeProduct(opts.runtimeProduct)
	if err != nil {
		return nil, err
	}
	taskCommand := canonicalPath
	workDir := filepath.Dir(canonicalPath)
	p := &Plan{Server: m.Name, CanMigrate: canMigrateServer(m.Name), FullInstall: opts.DaemonFilter == "", runtimeProduct: opts.runtimeProduct}
	// Scheduler tasks — one per daemon (global) or lazy (workspace-scoped).
	// SupervisorIntent mirrors SchedulerTasks during the v0.5.x transition
	// (plan §2611-2644). Both fields stay in sync until the supervisor pivot
	// completes and the legacy field is removed in v0.6+.
	for _, d := range m.Daemons {
		if opts.DaemonFilter != "" && d.Name != opts.DaemonFilter {
			continue
		}
		name := supervisorTaskNameForManifestDaemon(m.Name, d.Name)
		args := []string{"daemon", "--server", m.Name, "--daemon", d.Name}
		p.SchedulerTasks = append(p.SchedulerTasks, ScheduledTaskPlan{
			Name:    name,
			Command: taskCommand,
			Args:    args,
			Trigger: "At logon",
		})
		p.SupervisorIntent = append(p.SupervisorIntent, SupervisorIntentEntry{
			Name:       name,
			Command:    canonicalPath,
			Args:       args,
			WorkingDir: workDir,
			Trigger:    "At logon",
			StartupBindDeadlineSeconds: EffectiveStartupBindDeadlineSeconds(SupervisorDaemon{
				Server: m.Name, Daemon: d.Name, Args: args, StartupBindDeadlineSeconds: d.StartupBindDeadlineSeconds,
			}),
		})
	}
	// Weekly refresh restarts the whole server, so it only makes sense for full installs.
	if m.WeeklyRefresh && opts.DaemonFilter == "" {
		name := "mcp-local-hub-" + m.Name + "-weekly-refresh"
		args := []string{"restart", "--server", m.Name}
		p.SchedulerTasks = append(p.SchedulerTasks, ScheduledTaskPlan{
			Name:    name,
			Command: taskCommand,
			Args:    args,
			Trigger: "Weekly Sun 03:00",
		})
		p.SupervisorIntent = append(p.SupervisorIntent, SupervisorIntentEntry{
			Name:       name,
			Command:    canonicalPath,
			Args:       args,
			WorkingDir: workDir,
			Trigger:    "Weekly Sun 03:00",
		})
	}
	// Client updates — one per binding; with a filter, only bindings pointing at the chosen daemon.
	serenaClientDeferredNotice := false
	for _, b := range m.ClientBindings {
		if opts.DaemonFilter != "" && b.Daemon != opts.DaemonFilter {
			continue
		}
		if !includeClient(b.Client) {
			continue
		}
		daemon, ok := findDaemon(m, b.Daemon)
		if !ok {
			return nil, fmt.Errorf("binding references unknown daemon %q", b.Daemon)
		}
		path, err := clientConfigPath(b.Client)
		if err != nil {
			return nil, err
		}
		urlPath := b.URLPath
		if urlPath == "" {
			urlPath = "/mcp"
		}
		if err := validateClientURLPath(urlPath); err != nil {
			return nil, fmt.Errorf("invalid url_path for client %q: %w", b.Client, err)
		}
		// Single owner of the loopback-host literal — see clients.HubLoopbackURL.
		url := clients.HubLoopbackURL(daemon.Port, urlPath)
		relayURL := ""
		if IsSerenaServer(m.Name) {
			if opts.GUIPort <= 0 {
				if !serenaClientDeferredNotice {
					p.Notices = append(p.Notices, "serena client entry deferred: live hub router not resolvable")
					serenaClientDeferredNotice = true
				}
				continue
			}
			url = SerenaRouterClientURL(opts.GUIPort)
			if clients.IsRelayStdio(b.Client) {
				relayURL = url
			}
		}
		// Per-server install path NEVER emits Remove (including a Remove
		// of the mcphub-hub aggregate). The full-reconcile pipeline
		// (BuildHubReconcilePlan / ApplyHubReconcileInOrder) owns gate
		// transitions; per-server installs only refresh their own
		// per-(server, client) bindings.
		p.ClientUpdates = append(p.ClientUpdates, ClientUpdatePlan{
			Client:         b.Client,
			Path:           path,
			Action:         ClientUpdateAddReplace,
			EntryName:      m.Name,
			URL:            url,
			ToolTimeoutSec: b.ToolTimeoutSec,
			RelayURL:       relayURL,
			DaemonName:     b.Daemon,
		})
	}
	return freezeCodexInstallTargetNames(p, opts)
}

func supervisorTaskNameForManifestDaemon(manifestName, daemonName string) string {
	return "mcp-local-hub-" + manifestName + "-" + daemonName
}

// freezeCodexInstallTargetNames is the sole generic-install owner of the
// logical-to-physical Codex key projection. The adapter inspects the global and
// explicitly bounded project layers read-only; the resolved entry name is then
// frozen in ClientUpdatePlan for apply, readback, and CommandCoordinator
// settlement. No non-Codex update is changed.
func freezeCodexInstallTargetNames(p *Plan, opts BuildPlanOpts) (*Plan, error) {
	if p == nil {
		return nil, fmt.Errorf("install plan is nil")
	}
	if opts.ProjectClientCreate != nil {
		// This prospective route never asks the global relocation resolver to
		// pretend an inherited source physically exists in the project.
		for i := range p.ClientUpdates {
			if p.ClientUpdates[i].Client != "codex-cli" {
				return nil, clients.ErrProjectClientInvalid
			}
			p.ClientUpdates[i].EntryName = opts.ProjectClientCreate.LogicalEntryName + "-mcphub"
		}
		return p, nil
	}
	hasCodexUpdate := false
	for _, update := range p.ClientUpdates {
		if update.Client == "codex-cli" {
			hasCodexUpdate = true
			break
		}
	}
	if !hasCodexUpdate {
		return p, nil
	}
	if (opts.CodexProjectRoot == "") != (opts.CodexWorkingDir == "") {
		return nil, fmt.Errorf("%w: Codex project root and working directory must be supplied together", clients.ErrCodexLayerRootUnresolved)
	}
	if opts.CodexProjectRoot == "" {
		return p, nil
	}
	codexClient := clients.AllClients()["codex-cli"]
	adapter, ok := clients.AsCodexTransportClient(codexClient)
	if !ok {
		return nil, fmt.Errorf("CODEX_LAYER_ROOT_UNRESOLVED: Codex transport adapter is unavailable")
	}
	var desiredEntry clients.MCPEntry
	for _, update := range p.ClientUpdates {
		if update.Client == "codex-cli" {
			desiredEntry = clients.MCPEntry{
				Name:           p.Server + "-mcphub",
				URL:            update.URL,
				Headers:        update.Headers,
				ToolTimeoutSec: update.ToolTimeoutSec,
			}
			break
		}
	}
	target, err := adapter.ResolveTransportTarget(clients.CodexTransportTargetRequest{
		LogicalEntryName: p.Server,
		DesiredTransport: clients.CodexTransportHTTP,
		DesiredEntry:     desiredEntry,
		ProjectRoot:      opts.CodexProjectRoot,
		WorkingDir:       opts.CodexWorkingDir,
	})
	if err != nil {
		return nil, err
	}
	if target.ExistingExactTarget {
		settledEntry, settledErr := codexClient.GetEntry(target.TargetEntryName)
		if settledErr != nil {
			return nil, fmt.Errorf("read settled Codex target %q: %w", target.TargetEntryName, settledErr)
		}
		logicalEntry, logicalErr := codexClient.GetEntry(p.Server)
		if logicalErr != nil {
			return nil, fmt.Errorf("read logical Codex source %q: %w", p.Server, logicalErr)
		}
		if logicalEntry == nil && codexInstallTargetMatchesPlan(settledEntry, p.ClientUpdates) {
			for i := range p.ClientUpdates {
				if p.ClientUpdates[i].Client == "codex-cli" {
					p.ClientUpdates[i].EntryName = target.TargetEntryName
					p.ClientUpdates[i].codexAlreadyConfigured = true
				}
			}
			return p, nil
		}
		return nil, fmt.Errorf("%w: exact Codex target %q is not an authorized settled repeat", clients.ErrCodexTargetNameConflict, target.TargetEntryName)
	}
	if target.TargetEntryName == p.Server && target.ProjectLayerPresent {
		settledTargetName := p.Server + "-mcphub"
		settledEntry, settledErr := codexClient.GetEntry(settledTargetName)
		if settledErr != nil {
			return nil, fmt.Errorf("read settled Codex target %q: %w", settledTargetName, settledErr)
		}
		logicalEntry, logicalErr := codexClient.GetEntry(p.Server)
		if logicalErr != nil {
			return nil, fmt.Errorf("read logical Codex source %q: %w", p.Server, logicalErr)
		}
		if logicalEntry == nil && codexInstallTargetMatchesPlan(settledEntry, p.ClientUpdates) {
			for i := range p.ClientUpdates {
				if p.ClientUpdates[i].Client == "codex-cli" {
					p.ClientUpdates[i].EntryName = settledTargetName
					p.ClientUpdates[i].codexAlreadyConfigured = true
				}
			}
			return p, nil
		}
	}
	for i := range p.ClientUpdates {
		if p.ClientUpdates[i].Client == "codex-cli" {
			p.ClientUpdates[i].EntryName = target.TargetEntryName
		}
	}
	return p, nil
}

func codexInstallTargetMatchesPlan(entry *clients.MCPEntry, updates []ClientUpdatePlan) bool {
	if entry == nil {
		return false
	}
	for _, update := range updates {
		if update.Client != "codex-cli" {
			continue
		}
		if entry.URL != update.URL || entry.ToolTimeoutSec != update.ToolTimeoutSec || len(entry.Headers) != len(update.Headers) {
			return false
		}
		for key, value := range update.Headers {
			if entry.Headers[key] != value {
				return false
			}
		}
		return true
	}
	return false
}

func installClientPredicate(opts BuildPlanOpts) (func(string) bool, error) {
	if opts.SkipClientConfigWrites {
		if opts.IncludeAllClients || len(opts.ClientsInclude) > 0 {
			return nil, fmt.Errorf("SkipClientConfigWrites is mutually exclusive with ClientsInclude/IncludeAllClients")
		}
		return func(string) bool { return false }, nil
	}
	if opts.IncludeAllClients && len(opts.ClientsInclude) > 0 {
		return nil, fmt.Errorf("IncludeAllClients is mutually exclusive with ClientsInclude")
	}
	if opts.IncludeAllClients {
		return func(string) bool { return true }, nil
	}
	// Default-client resolution precedence:
	//   1. explicit ClientsInclude (operator/CLI --clients or a caller-
	//      supplied set) — used verbatim;
	//   2. DefaultClientsOverride (the operator's persisted default-install
	//      set, resolved from gui-preferences.yaml by the top-level Install
	//      entry points) — replaces the compile-time fallback;
	//   3. clients.DefaultInstallClientNames() — the compile-time default set.
	// Keeping the override in this field (not a disk read here) is what
	// keeps BuildPlanWithOpts hermetic for direct callers/tests.
	var names []string
	switch {
	case len(opts.ClientsInclude) > 0:
		names = opts.ClientsInclude
	case len(opts.DefaultClientsOverride) > 0:
		names = opts.DefaultClientsOverride
	default:
		names = clients.DefaultInstallClientNames()
	}
	supported := map[string]bool{}
	for _, name := range clients.SupportedClientNames() {
		supported[name] = true
	}
	selected := map[string]bool{}
	for _, name := range names {
		trimmed := strings.TrimSpace(name)
		if trimmed == "" {
			continue
		}
		if !supported[trimmed] {
			return nil, fmt.Errorf("unknown client %q (expected %s)", trimmed, strings.Join(clients.SupportedClientNames(), " | "))
		}
		selected[trimmed] = true
	}
	return func(name string) bool { return selected[name] }, nil
}

func validateClientURLPath(urlPath string) error {
	if !strings.HasPrefix(urlPath, "/") {
		return fmt.Errorf("must start with '/'")
	}
	if strings.HasPrefix(urlPath, "//") {
		return fmt.Errorf("must not start with '//'")
	}
	u, err := url.Parse(urlPath)
	if err != nil {
		return fmt.Errorf("parse url_path: %w", err)
	}
	if u.Scheme != "" || u.Host != "" || u.User != nil {
		return fmt.Errorf("must be a path-only URL")
	}
	return nil
}

func findDaemon(m *config.ServerManifest, name string) (config.DaemonSpec, bool) {
	for _, d := range m.Daemons {
		if d.Name == name {
			return d, true
		}
	}
	return config.DaemonSpec{}, false
}

// buildRemoteHTTPPlan builds the install plan for a G6
// transport=remote-http manifest. No local daemon → no scheduler
// tasks; no per-daemon port → URL comes from manifest.URL directly.
// ${secret:KEY} placeholders in URL + Headers expand at this stage
// against the encrypted vault; missing secrets fail BEFORE any
// client config is touched (G6 spec §"Install path" step 2).
//
// Adapter capability matrix (G6 spec §"Adapter compatibility"):
//   - claude-code, codex-cli, cursor, vscode, gemini-cli: header
//     support confirmed; bind directly.
//   - antigravity: stdio-relay only → install refuses with WARN
//     (handled earlier in Preflight; defense-in-depth check here too).
//
// codex bot r2 P1 closure on PR #169 (the implementation-pending
// gate from sub-PR 1 lands its real handler here).
func buildRemoteHTTPPlan(m *config.ServerManifest, opts BuildPlanOpts) (*Plan, error) {
	// Bot r1 P2 closure on PR #170: remote-http has no daemons,
	// so `--daemon X` makes no sense. Reject explicitly instead
	// of silently treating it as a partial install (which would
	// leave the FullInstall=false flag and skip the full-server
	// reconciliation later).
	if opts.DaemonFilter != "" {
		return nil, fmt.Errorf("manifest %s: transport=remote-http has no daemons; --daemon flag is not applicable (got --daemon=%q)", m.Name, opts.DaemonFilter)
	}
	includeClient, err := installClientPredicate(opts)
	if err != nil {
		return nil, err
	}
	// Resolve ${secret:KEY} placeholders. Missing secrets fail
	// BEFORE any client config write so the operator sees a clear
	// error rather than half-installed entries with placeholder
	// strings.
	expandedURL, err := expandRemoteHTTPURLSecrets(m.URL, nil)
	if err != nil {
		return nil, fmt.Errorf("install remote-http manifest %s: expand url: %w", m.Name, err)
	}
	expandedHeaders, err := ExpandSecretsMap(m.Headers, nil)
	if err != nil {
		return nil, fmt.Errorf("install remote-http manifest %s: expand headers: %w", m.Name, err)
	}
	p := &Plan{
		Server:      m.Name,
		FullInstall: opts.DaemonFilter == "",
	}
	for _, b := range m.ClientBindings {
		if b.Daemon != "" && b.Daemon != "default" {
			// remote-http manifests have no daemons; a binding
			// that names a non-empty / non-default daemon is a
			// manifest authoring mistake.
			return nil, fmt.Errorf("manifest %s: remote-http binding for client %q names daemon=%q but no daemons are declared (remove the daemon: line or use daemon: default)", m.Name, b.Client, b.Daemon)
		}
		if !includeClient(b.Client) {
			continue
		}
		// Defense-in-depth: enforce the canonical remote-http adapter
		// capability matrix (see remote_http_matrix.go). Antigravity
		// is the obvious stdio-relay case; this guard also catches
		// any future binding that names a client not on the matrix.
		// Preflight already rejected antigravity earlier — this
		// ensures direct BuildPlanWithOpts callers (tests, future
		// API consumers) and other off-matrix names see the same
		// rejection at plan build, before any client config is
		// touched.
		if !isRemoteHTTPCapableClient(b.Client) {
			return nil, fmt.Errorf("manifest %s: client=%q is not on the remote-http adapter capability matrix (supported: %v)", m.Name, b.Client, remoteHTTPCapableClients)
		}
		path, err := clientConfigPath(b.Client)
		if err != nil {
			return nil, err
		}
		p.ClientUpdates = append(p.ClientUpdates, ClientUpdatePlan{
			Client:         b.Client,
			Path:           path,
			Action:         ClientUpdateAddReplace,
			EntryName:      m.Name,
			URL:            expandedURL,
			ToolTimeoutSec: b.ToolTimeoutSec,
			// DisplayURL keeps the manifest's literal pre-expansion
			// URL so plan + install stdout never echo path/query
			// tokens that may have come from ${secret:KEY}
			// placeholders. The wire URL above is still expanded.
			DisplayURL: m.URL,
			Headers:    expandedHeaders,
			// DaemonName intentionally empty — remote-http has none.
		})
	}
	return p, nil
}

// Preflight verifies install preconditions. Returns first error found.
// Called by Install before any side effects.
//
// daemonFilter must match the same filter used by BuildPlan — only daemons
// that the install will actually (re)create have their ports checked. Without
// this alignment, a partial install would fail preflight whenever sibling
// daemons (already running from a prior install) occupy their assigned ports,
// even though those ports are not being touched by the current invocation.
func Preflight(m *config.ServerManifest, daemonFilter string) error {
	return preflightWithScope(m, scopeForPreflight(daemonFilter))
}

func preflightWithScope(m *config.ServerManifest, scope AdmissionScope) error {
	for _, finding := range AdmissionCheck(m, scope) {
		if !finding.Optional {
			// SEAM-B: carry the actionable Fix (not just Reason) so the CLI
			// install render can surface a guided fix. Error() keeps Reason as
			// its prefix, so callers asserting on a Reason substring still pass.
			// The gate decision (!finding.Optional) is UNCHANGED.
			return admissionErrorFromFinding(finding)
		}
	}
	return nil
}

// checkSecretRefs resolves every manifest env value and fails fast on
// the first missing secret. Only probes secret: refs — file:/literal/
// $VAR values are left to the resolver at daemon launch (they have
// different failure modes we don't want to pre-empt here).
func checkSecretRefs(env map[string]string) error {
	vault, err := secrets.OpenVault(secrets.DefaultKeyPath(), secrets.DefaultVaultPath())
	if err != nil {
		// No vault yet — only fail if at least one secret: ref is
		// declared. Manifests with no secret refs should install
		// cleanly on a fresh machine without any secrets setup.
		for k, v := range env {
			if strings.HasPrefix(v, "secret:") {
				return fmt.Errorf("env[%s]=%q requires a secrets vault; run `mcphub secrets set %s` first (vault open failed: %v)",
					k, v, strings.TrimPrefix(v, "secret:"), err)
			}
		}
		return nil
	}
	resolver := secrets.NewResolver(vault, nil)
	for k, v := range env {
		if !strings.HasPrefix(v, "secret:") {
			continue
		}
		if _, err := resolver.Resolve(v); err != nil {
			return fmt.Errorf("env[%s]=%q: %w (run `mcphub secrets set %s` to provide it)",
				k, v, err, strings.TrimPrefix(v, "secret:"))
		}
	}
	return nil
}

// portHeldByOurDaemon reports whether `port` is held by THIS server's
// own daemon, distinguishing "idempotent reinstall while my daemon is
// already running" from "foreign process stole the port we need".
// Bug-bash A6 (#6) closure: pre-fix, the Preflight port-in-use check
// raised the SAME error in both cases — operator saw `port 9129 already
// in use` for every server during `install --all` even when those
// daemons were our own running tasks.
//
// v0.6 Phase F moved global daemons from per-daemon scheduler tasks to
// supervisor-intent.json. Accept that supervisor-owned path first: the
// intent must contain THIS server+daemon row with the same port and
// supervisor IPC must report a live PID for that exact task. When the OS
// port-owner lookup is available, the listener PID must also match the
// supervisor-reported live PID.
//
// Three-part identity gate (bot r1 P1 + r2 P1 closure on PR #180):
// scheduler task name alone is not enough — a stale orphan / foreign
// PID can hold the port while a task with the matching name is also
// in "Running" state (recovery race, watchdog restart in flight,
// etc.). We require ALL of:
//
//  1. port-to-PID lookup succeeds with a non-zero PID
//  2. process identity matches our binary, by EITHER:
//     - image basename == "mcphub.exe" (stdio-bridge listener;
//     native-http external port held by our in-process http.Server)
//     - parent image basename == "mcphub.exe" (native-http internal
//     port held by the upstream child spawned by our daemon)
//     If neither matches, a foreign process owns the port → collision.
//  3. scheduler task `\mcp-local-hub-<server>-<daemon>` exists and
//     is in State == "Running"
//
// Test seam: lookupPortPID, processIdentityByPID, and
// schedulerStatusForOwnPort are package vars in production wired to
// the processes.go init helper, the wmic-or-PowerShell identity
// lookup, and scheduler.New().Status respectively. Tests assign
// fakes for each.
func portHeldByOurDaemon(port int, server, daemon string) bool {
	return portHeldByOurDaemonForPortArm(port, server, daemon, true)
}

func portHeldByOurDaemonForPortArm(port int, server, daemon string, allowSupervisorInternalPortMatch bool) bool {
	if portHeldBySupervisorIntentDaemonForPortArm(port, server, daemon, allowSupervisorInternalPortMatch) {
		return true
	}
	if lookupPortPID == nil {
		return false
	}
	pid, found, err := lookupPortPID(port)
	if err != nil || !found || pid <= 0 {
		return false
	}
	// Image-identity gate. Accept ownership when EITHER the port-
	// holder's image is mcphub.exe (stdio-bridge / native-http
	// external) OR its parent image is mcphub.exe (native-http
	// internal port held by upstream child spawned by our daemon).
	if processIdentityByPID == nil {
		return false
	}
	image, parentImage, ok := processIdentityByPID(pid)
	if !ok {
		return false
	}
	if !isMcphubProcessImage(image) && !isMcphubProcessImage(parentImage) {
		return false
	}
	if schedulerStatusForOwnPort == nil {
		return false
	}
	taskName := fmt.Sprintf("\\mcp-local-hub-%s-%s", server, daemon)
	st, err := schedulerStatusForOwnPort(taskName)
	if err != nil {
		return false
	}
	if st.State != "Running" {
		return false
	}
	return statusOwnedByCurrentUser(st.Owner)
}

// portHeldBySupervisorIntentDaemon recognizes ports owned by the v0.6
// supervisor-intent path before falling back to legacy scheduler-task
// ownership checks.
//
// Trust ladder:
//   - Native-http internal port: require the descriptor row plus a live
//     supervisor-reported wrapper PID. When the port-owner lookup and process
//     parent walk are available, also prove the internal listener's parent chain
//     reaches that wrapper PID within a bounded depth; a resolvable chain that
//     does not reach it is a foreign listener and is rejected. If the lookup or
//     walk surface is unavailable, keep the previous live-wrapper-PID downgrade:
//     this matches the best-effort identity-gate posture used elsewhere on
//     hosts without process probes, and avoids breaking valid installs when the
//     OS cannot expose ancestry.
//   - External port:
//     1. Port-owner lookup available: require the live listener PID to equal
//     the live supervisor-reported PID for the matching task.
//     2. Port-owner lookup unavailable: fail closed. Supervisor IPC can prove
//     the descriptor task is live, but it cannot prove that the live task owns
//     the already-occupied client-facing port.
//     3. Supervisor IPC unreachable or no live task PID: fail closed.
//
// Callers reach this only after preflightPortInUse(port) is already true, so a
// missing proof surface cannot mean "port is free"; it leaves the normal port
// collision error in place.
func portHeldBySupervisorIntentDaemon(port int, server, daemon string) bool {
	return portHeldBySupervisorIntentDaemonForPortArm(port, server, daemon, true)
}

func portHeldBySupervisorIntentDaemonForPortArm(port int, server, daemon string, allowInternalPortMatch bool) bool {
	if port == 0 || server == "" || daemon == "" {
		return false
	}
	// Read-only resolver: this ownership probe runs inside Preflight, which a
	// --dry-run also exercises on a port collision — DaemonStateDir would
	// MkdirAll the state directory on a first-run host as a dry-run side
	// effect (bot PR #288 r23). A missing dir simply means no intent file →
	// the read below fails → false (the normal collision error stands).
	stateDir, err := daemonStateDirReadOnly()
	if err != nil {
		return false
	}
	intent, err := ReadSupervisorIntent(joinStateFilePath(stateDir, supervisorIntentFileLeaf))
	if err != nil || intent == nil {
		return false
	}
	row, matchedInternalPort, ok := supervisorIntentDaemonForPort(intent, port, server, daemon, allowInternalPortMatch)
	if !ok {
		return false
	}
	livePIDs, reachable := supervisorOwnedLivePIDsWithReachability(context.Background())
	if !reachable {
		return false
	}
	taskKey := strings.TrimPrefix(supervisorIntentDaemonTaskName(row, server, daemon), `\`)
	livePID, ok := livePIDs[taskKey]
	if !ok || livePID <= 0 {
		return false
	}
	if matchedInternalPort {
		owned, resolved := internalPortListenerChainsToWrapperPID(port, livePID)
		if resolved {
			return owned
		}
		// No usable port-owner or ancestry proof. Keep the documented downgrade:
		// descriptor row + live supervisor wrapper PID is the best available
		// identity signal on hosts where process lookup is unavailable.
		return true
	}
	portPID, havePortPID := supervisorOwnedPortPID(port)
	if !havePortPID {
		return false
	}
	return livePID == portPID
}

const internalPortParentWalkDepth = 3

// internalPortListenerChainsToWrapperPID reports whether the process listening
// on an internal upstream port descends from our supervisor wrapper PID.
//
// The (owned, resolved) pair drives a DOWNGRADE in the caller: resolved=false
// means "this host has no usable identity-probe surface", and the caller then
// trusts the descriptor row alone and returns "held by our daemon". That
// downgrade is only sound for a STRUCTURALLY absent probe surface. A probe that
// ran and timed out must NOT take it — otherwise a foreign process squatting the
// internal port while WMI is congested is reported as ours, and the readiness
// endpoint answers Ready=true on evidence it never obtained.
//
// So a timeout returns (false, TRUE): resolved, and NOT owned. The caller then
// reports the port as not-held, and readiness degrades to an honest not-ready
// instead of a silent lie.
func internalPortListenerChainsToWrapperPID(port int, wrapperPID int) (owned bool, resolved bool) {
	if wrapperPID <= 0 {
		return false, true
	}
	listenerPID, portPIDOutcome := supervisorOwnedPortPIDOutcome(port)
	switch portPIDOutcome {
	case probeSurfaceUnavailable:
		// No port-owner probe wired at all (non-Windows, or an unwired test):
		// the documented downgrade applies.
		return false, false
	case probeUnknown:
		// The port-owner probe ran and did not answer. The caller only reaches
		// here for a port that IS bound (fixedPortStatus gates on
		// !portAvailable), so "bound but no resolvable owner" is an unknown, not
		// a licence to claim ownership.
		return false, true
	}
	if listenerPID == wrapperPID {
		return true, true
	}
	if processNameAndParentByPID == nil {
		return false, false
	}
	cur := listenerPID
	for depth := 0; depth < internalPortParentWalkDepth; depth++ {
		_, parentPID, err := processNameAndParentByPID(cur)
		if err != nil {
			if errors.Is(err, ErrProbeTimeout) {
				// Ownership UNKNOWN — resolved, but explicitly NOT owned.
				return false, true
			}
			// Definitive negative (PID gone, no probe surface for this row):
			// keep the documented downgrade.
			return false, false
		}
		if parentPID == wrapperPID {
			return true, true
		}
		if parentPID <= 0 || parentPID == cur {
			return false, true
		}
		cur = parentPID
	}
	return false, true
}

func supervisorIntentDaemonForPort(intent *SupervisorIntentFile, port int, server, daemon string, allowInternalPortMatch bool) (SupervisorDaemon, bool, bool) {
	if intent == nil {
		return SupervisorDaemon{}, false, false
	}
	for _, row := range intent.Daemons {
		// Identity gate FIRST: a row can only own the probed port if it is the
		// (server, daemon) being checked. Deciding identity before the port
		// relationship is what lets a stdio-bridge row (Port==0, see below) be
		// recognized at all — its runtime HTTP-bridge port never lands in the
		// descriptor, so a port-first match skips it.
		if !supervisorIntentRowMatchesServerDaemon(row, server, daemon) {
			continue
		}
		// Exact external port — the common native-http / explicit-port case.
		if row.Port == port {
			return row, false, true
		}
		if allowInternalPortMatch {
			if row.Port > 0 && row.Port+config.NativeHTTPInternalPortOffset == port {
				return row, true, true
			}
			if row.RuntimeSpec != nil && row.RuntimeSpec.UpstreamPort == port {
				return row, true, true
			}
		}
		// Stdio-bridge daemon: the descriptor records Port==0 because the HTTP
		// bridge port is assigned at spawn, not at install, so it is not in the
		// row. The probed port came from THIS server's own manifest binding, so
		// treat it as an external candidate (matchedInternalPort=false) and let
		// the caller's live-PID-owns-the-probed-port proof (supervisor IPC PID ==
		// netstat port owner) decide ownership — that proof prevents over-claim
		// of a foreign port. Without this, a running stdio server
		// (memory/time/wolfram/gdb/…) fails its OWN reinstall Preflight with a
		// spurious port-in-use: the v0.6 global has no scheduler-task fallback to
		// recognize itself, and the port-first match skipped its Port==0 row.
		if row.Port == 0 {
			return row, false, true
		}
		// server+daemon match but the row records a DIFFERENT non-zero port (or
		// the probe is an internal port while internal matching is disabled):
		// this probe is for another port of a multi-port server — keep scanning.
	}
	return SupervisorDaemon{}, false, false
}

func supervisorIntentRowMatchesServerDaemon(row SupervisorDaemon, server, daemon string) bool {
	if server == "" || daemon == "" {
		return false
	}
	// ALWAYS resolve identity through the owner — INCLUDING a fully-populated row —
	// so a Server/Daemon field that CONTRADICTS the launch argv (a lying cache) fails
	// closed instead of matching on the stale field (commission codex/architect PR
	// #505 r6 P1). A well-formed row (fields agree with argv, empty Args, a proxy
	// subcommand, or a partial `--server X` completed by the field) resolves
	// IdentityFromArgvOrField — byte-identical to the old populated field-compare and
	// the r6 blank-field switch; ONLY a contradicting global argv changes, to
	// fail-closed. The canonical task-name reconstruction stays reserved for a TRUE
	// task-name-only row (no daemon argv to contradict it), which is AMBIGUOUS
	// (demo/alpha-beta and demo-alpha/beta both rebuild \mcp-local-hub-demo-alpha-beta)
	// — so a corrupt global that DOES carry an argv must never reach it.
	rs, rd, src := ResolveDescriptorMatchIdentity(row)
	switch src {
	case IdentityFromArgvOrField:
		return rs == server && rd == daemon
	case IdentityTaskNameSafe:
		want := canonicalIntentTaskKey("mcp-local-hub-" + server + "-" + daemon)
		return canonicalIntentTaskKey(row.TaskName) == want
	default:
		// CorruptGlobalArgv AND any future IdentitySource → fail closed (F3: never
		// let an added source fall open into the task-name match).
		return false
	}
}

func supervisorIntentDaemonTaskName(row SupervisorDaemon, server, daemon string) string {
	if strings.TrimSpace(row.TaskName) != "" {
		return canonicalIntentTaskKey(row.TaskName)
	}
	return canonicalIntentTaskKey("mcp-local-hub-" + server + "-" + daemon)
}

// probeOutcome is the tri-state every OS-fact ownership probe actually has.
// Collapsing it to a bool is what let "the probe timed out" be read as "the
// probe surface is absent", which in turn licensed an ownership downgrade on
// evidence that was never obtained.
type probeOutcome int

const (
	probeResolved           probeOutcome = iota // the probe answered
	probeSurfaceUnavailable                     // no probe wired on this host (non-Windows, unwired test)
	probeUnknown                                // the probe ran but did not answer
)

// supervisorOwnedPortPIDOutcome is the single owner of "who listens on this
// port", reporting WHY it could not answer rather than only that it could not.
//
// A wired lookupPortPID that fails or finds no owner is probeUnknown, not
// probeSurfaceUnavailable: the ownership gate is only consulted for a port that
// is already bound (fixedPortStatus gates on !portAvailable), so "bound, yet no
// resolvable owner" is an unresolved probe — never a reason to claim the port.
func supervisorOwnedPortPIDOutcome(port int) (int, probeOutcome) {
	if lookupPortPID == nil {
		return 0, probeSurfaceUnavailable
	}
	pid, found, err := lookupPortPID(port)
	if err != nil || !found || pid <= 0 {
		return 0, probeUnknown
	}
	return pid, probeResolved
}

func supervisorOwnedPortPID(port int) (int, bool) {
	pid, outcome := supervisorOwnedPortPIDOutcome(port)
	return pid, outcome == probeResolved
}

func statusOwnedByCurrentUser(owner string) bool {
	owner = strings.TrimSpace(owner)
	if owner == "" {
		return false
	}
	cur, err := user.Current()
	if err != nil || cur == nil {
		return false
	}
	// Task Scheduler often reports owner as DOMAIN\user, while Go may
	// return either `user` or `DOMAIN\user` depending on environment.
	u := strings.ToLower(strings.TrimSpace(cur.Username))
	o := strings.ToLower(owner)
	if u == o {
		return true
	}
	if i := strings.LastIndex(u, `\`); i >= 0 && i+1 < len(u) {
		u = u[i+1:]
	}
	if i := strings.LastIndex(o, `\`); i >= 0 && i+1 < len(o) {
		o = o[i+1:]
	}
	return u != "" && u == o
}

// processIdentityByPID is a function-pointer seam returning the image
// basename and parent-process image basename for a PID (e.g.,
// ("mcphub.exe", "svchost.exe") for our own daemon spawned by
// scheduler; ("python.exe", "mcphub.exe") for a native-http upstream
// child spawned by our daemon).
//
// Production init in processes.go wires it via wmic Name+ParentProcessId
// (with PowerShell Get-CimInstance fallback for Windows 11 24H2+ where
// wmic is removed — bot r2 P2 closure). Tests supply fakes. Stays nil
// on non-Windows hosts (matching the lookupProcess pattern) —
// portHeldByOurDaemon then returns false and the Preflight collision
// check fails as before.
var processIdentityByPID func(pid int) (image, parentImage string, ok bool)

// processNameAndParentByPID returns the process image basename plus parent PID
// for callers that need a bounded ancestry walk rather than only the direct
// parent image. Production is wired in processes.go next to processIdentityByPID;
// tests supply fakes.
//
// It returns an ERROR rather than a bool because its one production consumer
// (internalPortListenerChainsToWrapperPID) must distinguish two cases that a
// bool collapses into an indistinguishable `!ok`:
//
//   - the probe ANSWERED "no such process" — a definitive negative, for which
//     the documented "process lookup unavailable" ownership downgrade applies;
//   - the probe DID NOT ANSWER in time (ErrProbeTimeout) — ownership is UNKNOWN,
//     and taking the downgrade there would report a foreign-squatted port as
//     "held by our daemon", i.e. Ready=true on evidence we never obtained.
//
// Collapsing those two is what let a bounded-probe timeout turn a visible hang
// into a silent lie. Callers MUST branch on errors.Is(err, ErrProbeTimeout).
var processNameAndParentByPID func(pid int) (image string, parentPID int, err error)

// errProcessIdentityUnresolved is the NON-TIMEOUT negative: the probe chain
// finished without being cut by a deadline, and produced no identity row.
//
// Deliberately NOT named "process not found", which would overclaim. It covers
// BOTH "the probe answered and the PID is genuinely absent" AND "the probe
// surface failed for a non-timeout reason" (wmic absent AND PowerShell refused,
// e.g. an execution-policy or AppLocker denial). Only the first is proven
// absence; the second is a surface failure.
//
// Both are treated the same by the one consumer
// (internalPortListenerChainsToWrapperPID): they keep the documented
// "process lookup unavailable" ownership downgrade. That is the PRE-EXISTING
// posture, unchanged by the timeout work — a blocked PowerShell is genuinely
// closer to "no probe surface on this host" than to "the probe is mid-answer".
// The distinction that MATTERS for correctness, and the one the timeout fix
// added, is timeout-vs-not: a probe still capable of answering must never
// license the downgrade. Splitting surface-failure from proven-absence is a
// further refinement, not a live defect.
var errProcessIdentityUnresolved = errors.New("process identity unresolved (no timeout)")

const mcphubProcessImageName = "mcphub.exe"

func isMcphubProcessImage(image string) bool {
	return strings.EqualFold(strings.TrimSpace(image), mcphubProcessImageName)
}

// mcphubPIDImageVerified probes the identity of pid. The identity gate is
// BEST-EFFORT hardening only when the lookup surface is structurally
// unavailable (nil seam, e.g. non-Windows hosts where no PID-image probe is
// wired): the caller may proceed in that case to preserve stop --force on
// hosts without the lookup. Once a probe is wired, however, an ok=false result
// means verification was attempted and failed (lookup/parsing failure, exited
// process, PID reuse race, etc.) and must fail closed rather than authorize a
// kill without a positive mcphub image verdict.
func mcphubPIDImageVerified(pid int) (image, parentImage string, verified, lookupAvailable, lookupOK bool) {
	if processIdentityByPID == nil {
		return "", "", false, false, false
	}
	image, parentImage, ok := processIdentityByPID(pid)
	if !ok {
		return image, parentImage, false, true, false
	}
	return image, parentImage, isMcphubProcessImage(image), true, true
}

func requireMcphubPIDImage(pid int) error {
	image, parentImage, verified, lookupAvailable, lookupOK := mcphubPIDImageVerified(pid)
	if !lookupAvailable {
		return nil // best-effort gate: no probe surface → proceed (see doc above)
	}
	if !lookupOK {
		return fmt.Errorf("process identity lookup failed for pid %d", pid)
	}
	if !verified {
		return fmt.Errorf("pid %d image %q parent %q is not %s", pid, image, parentImage, mcphubProcessImageName)
	}
	// SEC-F3 owner-SID arm (additional, fail-closed): a process owned by a
	// DIFFERENT user SID must not be force-killed even when its image matches,
	// mirroring the POSIX reaper's UID gate. Non-Windows is a no-op (true,nil).
	if err := requireMcphubPIDOwnerSID(pid); err != nil {
		return err
	}
	return nil
}

// requireMcphubPIDOwnerSID is the shared SEC-F3 owner-SID arm for the
// stop-force kill gates. It returns nil only when the target PID is proven to
// be owned by the current user; a different-owner SID OR an unverifiable owner
// (token open/query failure) returns a non-nil error so the caller refuses the
// kill (fail closed).
func requireMcphubPIDOwnerSID(pid int) error {
	match, err := processOwnerSIDMatchesCurrentFn(pid)
	if err != nil {
		return fmt.Errorf("owner-SID gate: pid %d ownership unverifiable: %w", pid, err)
	}
	if !match {
		return fmt.Errorf("owner-SID gate: pid %d is owned by a different user; refusing to kill", pid)
	}
	return nil
}

func requireMcphubPortOwnerPID(port, pid int) error {
	image, parentImage, verified, lookupAvailable, lookupOK := mcphubPIDImageVerified(pid)
	if !lookupAvailable {
		return nil // best-effort gate: no probe surface → proceed (see doc above)
	}
	if !lookupOK {
		return fmt.Errorf("process identity lookup failed for port %d pid %d", port, pid)
	}
	if !verified {
		return fmt.Errorf("port owned by foreign process: port %d pid %d image %q parent %q", port, pid, image, parentImage)
	}
	// SEC-F3 owner-SID arm (additional, fail-closed): refuse to taskkill the
	// port owner if it belongs to a different user SID (or its owner cannot be
	// verified). Non-Windows is a no-op (true,nil).
	if err := requireMcphubPIDOwnerSID(pid); err != nil {
		return fmt.Errorf("port %d: %w", port, err)
	}
	return nil
}

// schedulerStatusForOwnPort is a function-pointer seam for the
// own-port detection helper above. Production init wires it to
// scheduler.New().Status; tests replace it with a fake that returns
// canned TaskStatus values.
var schedulerStatusForOwnPort = defaultSchedulerStatusForOwnPort

func defaultSchedulerStatusForOwnPort(taskName string) (scheduler.TaskStatus, error) {
	sch, err := scheduler.New()
	if err != nil {
		return scheduler.TaskStatus{}, err
	}
	return sch.Status(taskName)
}

// portInUse returns true if a listener on the given port accepts connections.
func portInUse(port int) bool {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 300*time.Millisecond)
	if err != nil {
		return false
	}
	conn.Close()
	return true
}

func printPlanTo(w io.Writer, p *Plan) error {
	fmt.Fprintf(w, "Install plan for server %q (dry-run):\n\n", p.Server)
	for _, notice := range p.Notices {
		fmt.Fprintf(w, "  notice: %s\n", notice)
	}
	fmt.Fprintf(w, "  Scheduler tasks to create (%d):\n", len(p.SchedulerTasks))
	for _, t := range p.SchedulerTasks {
		fmt.Fprintf(w, "    \u2022 %s  [%s]\n        %s %v\n", t.Name, t.Trigger, t.Command, t.Args)
	}
	printClientUpdatesTo(w, p)
	fmt.Fprintln(w, "\nNo changes made.")
	_ = clients.Client(nil) // keep import live for later tasks
	return nil
}

func printClientUpdatesTo(w io.Writer, p *Plan) {
	fmt.Fprintf(w, "\n  Client configs to update (%d):\n", len(p.ClientUpdates))
	for _, u := range p.ClientUpdates {
		fmt.Fprintf(w, "    \u2022 %s (%s)\n        %s  \u2192  %s\n", u.Client, u.Path, u.Action, displayURLOf(u))
	}
}

// installPlanOpts carries the per-caller knobs installPlan needs that are
// not derivable from (m, plan). DaemonFilter drives audit-entry emission;
// DryRun short-circuits to a plan print; StartTasks gates Pass B inside
// executeInstallTo. Writer is the progress sink.
type installPlanOpts struct {
	Writer       io.Writer
	DaemonFilter string
	DryRun       bool
	StartTasks   bool
	// Intermediate, when non-nil, is forwarded to executeInstallTo and runs
	// inside its rollback scope between the client-config block and Pass B.
	// Used by InstallParsedManifest to fold the supervisor-intent write into
	// the same rollback stack; legacy callers leave it nil.
	Intermediate intentWriteStep
	// SkipSchedulerPrune, when true, suppresses the full-install obsolete-task
	// reconcile (pruneObsoleteServerTasks) inside executeInstallTo. Set by
	// InstallParsedManifest for workspace-scoped (DaemonTemplate) manifests,
	// which produce ZERO SchedulerTasks: pruning against an empty planned set
	// would delete every registered mcp-local-hub-<server>-* scheduler task
	// for that server. Those daemons live in supervisor-intent.json, not in
	// scheduler tasks, so there is nothing to reconcile here. Legacy callers
	// leave it false (zero value), preserving their reconcile behavior exactly.
	SkipSchedulerPrune bool
	// SkipSchedulerTasks, when true, suppresses Pass A scheduler-task creation
	// (sch.Create per planned daemon) AND the Pass B start inside
	// executeInstallTo. v0.6 Phase F sets it for GLOBAL manifest installs so a
	// fresh install writes supervisor-intent daemon rows (via Intermediate) and
	// defers every daemon spawn to the supervisor reconcile loop — no per-daemon
	// `\mcp-local-hub-<server>-<daemon>` Task Scheduler task is created. The plan
	// still carries SchedulerTasks (for audit/intent task-name derivation), but
	// they are never materialized as OS tasks. Legacy/workspace-scoped callers
	// leave it false; workspace-scoped plans already carry zero SchedulerTasks,
	// so the flag is a no-op there. When true the caller must also set
	// SkipSchedulerPrune=true (the daemon set now lives in supervisor-intent,
	// not in scheduler tasks) and pass a non-nil Intermediate that writes the
	// supervisor-intent rows.
	SkipSchedulerTasks bool
	// AuditTaskNames, when non-empty, OVERRIDES the manifest-derived task list
	// the pre-mutation audit (recordInstallAuditPreMutation) fail-closes on.
	// Set by InstallParsedManifest's workspace-scoped fan-out path: a
	// DaemonTemplate manifest has an EMPTY m.Daemons, so installAuditTaskNames
	// would yield zero entries and the fan-out install would commit
	// per-workspace supervisor-intent daemon rows WITHOUT any fail-closed
	// server-install audit entry. The fan-out path feeds the MATERIALIZED
	// per-workspace task names here so the audit fail-closes BEFORE any
	// intent/scheduler mutation. Legacy callers leave it nil and keep the
	// manifest-derived audit task list (installAuditTaskNames) exactly.
	AuditTaskNames []string
	// SymlinkConsents carries request-scoped, per-client consent pins for
	// client-config symlink writes. Nil preserves the ordinary default refusal.
	SymlinkConsents []ResolvedSymlinkConsent
}

// installExecutionActions is the executor's sole action-predicate owner.
// Creation eligibility and acquisition are distinct: empty declarations do not
// suppress a full-install prune or the existing start-mode acquisition.
type installExecutionActions struct {
	createEligible, create, prune, start, scheduler, clients bool
}

func selectedInstallActions(p *Plan, startTasks, skipPrune, skipTasks bool) installExecutionActions {
	createEligible := !skipTasks
	create := createEligible && len(p.SchedulerTasks) > 0
	prune := p.FullInstall && !skipPrune
	start := startTasks && createEligible
	return installExecutionActions{createEligible: createEligible, create: create, prune: prune,
		start: start, scheduler: create || prune || start, clients: len(p.ClientUpdates) > 0}
}

// selectedInstallExecutionPhase is private invocation-local input binding.
// Manifest encoding is compared in memory only; it is never a persisted phase,
// capability, issuer or write proof. The held caller supplies the real commit.
type selectedInstallExecutionPhase struct {
	manifest                                              *config.ServerManifest
	plan                                                  *Plan
	manifestInput                                         []byte
	server                                                string
	fullInstall, hashesBound, supervisorCommit, workspace bool
	tasks                                                 []ScheduledTaskPlan
	intent                                                []SupervisorIntentEntry
	clients                                               []ClientUpdatePlan
	opts                                                  installPlanOpts
	backend                                               *managedBackendInstallOperation
	attachment, backendAttachment                         *projectClientAttachmentPlan
	backendPublic, attachmentPublic                       ProjectClientCreatePlanV1
}

func selectInstallExecutionPhase(m *config.ServerManifest, p *Plan, opts installPlanOpts, supervisorCommit, workspace bool) (*selectedInstallExecutionPhase, error) {
	if m == nil || p == nil {
		return nil, errors.New("SERENA_INSTALL_PLAN_MISSING")
	}
	manifestInput, err := json.Marshal(m)
	if err != nil {
		return nil, errors.Join(errors.New("SERENA_PREPARED_PRECOMMIT_PLAN_EFFECTS_REFUSED"), err)
	}
	opts.SymlinkConsents = append([]ResolvedSymlinkConsent(nil), opts.SymlinkConsents...)
	tasks := append([]ScheduledTaskPlan(nil), p.SchedulerTasks...)
	for i := range tasks {
		if tasks[i].Args != nil {
			tasks[i].Args = append([]string{}, tasks[i].Args...)
		}
	}
	intent := append([]SupervisorIntentEntry(nil), p.SupervisorIntent...)
	for i := range intent {
		if intent[i].Args != nil {
			intent[i].Args = append([]string{}, intent[i].Args...)
		}
	}
	updates := append([]ClientUpdatePlan(nil), p.ClientUpdates...)
	for i := range updates {
		if updates[i].Headers != nil {
			updates[i].Headers = make(map[string]string, len(p.ClientUpdates[i].Headers))
			for key, value := range p.ClientUpdates[i].Headers {
				updates[i].Headers[key] = value
			}
		}
	}
	selected := &selectedInstallExecutionPhase{manifest: m, plan: p, manifestInput: manifestInput,
		server: p.Server, fullInstall: p.FullInstall, hashesBound: p.supervisorIntentHashesBound,
		supervisorCommit: supervisorCommit, workspace: workspace, tasks: tasks, intent: intent,
		clients: updates, opts: opts, backend: p.ownedBackendInstall, attachment: p.projectAttachment}
	if selected.backend != nil {
		if selected.backend.attachment == nil {
			return nil, errors.New("SERENA_PREPARED_PRECOMMIT_PLAN_EFFECTS_REFUSED")
		}
		if err := selected.backend.public.validate(); err != nil {
			return nil, errors.Join(errors.New("SERENA_PREPARED_PRECOMMIT_PLAN_EFFECTS_REFUSED"), err)
		}
		selected.backendAttachment = selected.backend.attachment
		selected.backendPublic = selected.backend.public
	}
	if selected.attachment != nil {
		if err := selected.attachment.public.validate(); err != nil {
			return nil, errors.Join(errors.New("SERENA_PREPARED_PRECOMMIT_PLAN_EFFECTS_REFUSED"), err)
		}
		selected.attachmentPublic = selected.attachment.public
	}
	return selected, nil
}

func (s *selectedInstallExecutionPhase) executionOptions(intermediate intentWriteStep, auditTasks []string) installPlanOpts {
	opts := s.opts
	opts.Intermediate = intermediate
	opts.AuditTaskNames = auditTasks
	return opts
}

func (s *selectedInstallExecutionPhase) admitPrepared(m *config.ServerManifest, p *Plan, opts installPlanOpts, executing bool) error {
	refused := errors.New("SERENA_PREPARED_PRECOMMIT_PLAN_EFFECTS_REFUSED")
	if s == nil || m == nil || p == nil || s.manifest != m || s.plan != p {
		return refused
	}
	manifestInput, err := json.Marshal(m)
	if err != nil {
		return errors.Join(refused, err)
	}
	if s.backend != p.ownedBackendInstall || s.attachment != p.projectAttachment {
		return refused
	}
	if s.backend != nil && (s.backendAttachment != s.backend.attachment ||
		s.backendPublic != s.backend.public) {
		return refused
	}
	if s.attachment != nil && s.attachmentPublic != s.attachment.public {
		return refused
	}
	if !bytes.Equal(s.manifestInput, manifestInput) || s.server != p.Server ||
		s.fullInstall != p.FullInstall || s.hashesBound != p.supervisorIntentHashesBound ||
		!reflect.DeepEqual(s.tasks, append([]ScheduledTaskPlan(nil), p.SchedulerTasks...)) ||
		!reflect.DeepEqual(s.intent, append([]SupervisorIntentEntry(nil), p.SupervisorIntent...)) ||
		!reflect.DeepEqual(s.clients, append([]ClientUpdatePlan(nil), p.ClientUpdates...)) ||
		s.opts.DaemonFilter != opts.DaemonFilter || s.opts.DryRun != opts.DryRun ||
		s.opts.StartTasks != opts.StartTasks || s.opts.SkipSchedulerPrune != opts.SkipSchedulerPrune ||
		s.opts.SkipSchedulerTasks != opts.SkipSchedulerTasks || !s.supervisorCommit ||
		!reflect.DeepEqual(s.opts.SymlinkConsents, append([]ResolvedSymlinkConsent(nil), opts.SymlinkConsents...)) ||
		(s.workspace && m.DaemonTemplate == nil) || (executing && opts.Intermediate == nil) {
		return refused
	}
	actions := selectedInstallActions(p, opts.StartTasks, opts.SkipSchedulerPrune, opts.SkipSchedulerTasks)
	if actions.scheduler || actions.create || actions.prune || actions.start || actions.clients {
		return refused
	}
	return nil
}

// installPlan is the shared materialization core between api.Install (and
// its embed/dir siblings) and InstallParsedManifest: emit the audit-first
// entries per planned task, then execute the plan with the requested
// daemon-start gating. It deliberately does NOT own dry-run-vs-execute
// policy beyond the short-circuit, the post-success intent record
// (recordInstallIntentPostSuccess for the legacy path / WriteSupervisorIntent
// for the parsed-manifest path), or any rollback ownership — those stay
// caller-specific because they diverge between the two entrypoints.
//
// ctx is accepted for symmetry with the exported InstallParsedManifest
// seam (and to give future cancellation a home); the underlying audit +
// scheduler steps are synchronous and do not yet observe it.
func (a *API) installPlan(ctx context.Context, m *config.ServerManifest, plan *Plan, opts installPlanOpts) error {
	_ = ctx
	if plan.serenaPreparedInvocation != nil {
		if err := plan.selectedExecutionPhase.admitPrepared(m, plan, opts, true); err != nil {
			return err
		}
	}
	w := opts.Writer
	if w == nil {
		w = os.Stderr
	}
	if opts.DryRun {
		return printPlanTo(w, plan)
	}
	// AUDIT-FIRST per plan §62 v12 canonical timing: emit one
	// server-install audit entry per planned task BEFORE any mutation.
	// Failure here (incl. ErrIdentityOversize per §51) aborts with an
	// end-state identical to never-attempted install.
	//
	// opts.AuditTaskNames overrides the manifest-derived list for the
	// workspace-scoped fan-out (whose m.Daemons is empty); legacy callers
	// leave it nil and audit the installAuditTaskNames(m, filter) set.
	if err := a.recordInstallAuditForTasks(installAuditTaskNamesOrOverride(m, opts.DaemonFilter, opts.AuditTaskNames)); err != nil {
		return err
	}
	return executeInstallToWithSymlinkConsents(w, m, plan, a.effectiveBackupKeepN(), opts.StartTasks, opts.Intermediate, opts.SkipSchedulerPrune, opts.SkipSchedulerTasks, opts.SymlinkConsents)
}

// createdTask pairs a scheduler.TaskSpec created in Pass A with the
// human-readable Trigger string from its source ScheduledTaskPlan. Pass B
// iterates the created-tasks slice (not p.SchedulerTasks) and re-applies
// the SAME literal "At logon" filter the single-pass version used, so the
// daemon-start gate is bit-for-bit identical.
type createdTask struct {
	spec    scheduler.TaskSpec
	trigger string
}

// intentWriteStep is the typed shape of executeInstallTo's intermediate
// hook. Runs after scheduler-task creation + per-client-config writes and
// BEFORE Pass B task-start. Returns an idempotent compensator that is
// pushed onto executeInstallTo's single shared rollback stack and runs (in
// reverse) on any later-step failure. MUST NOT mutate the manifest or the
// workspace registry (those are the outer migrate-driver's rollback scope).
// Naming the type keeps the core rollback scope from inviting arbitrary
// future side-effects through a bare func() (func(), error) param.
type intentWriteStep func() (rollback func(), err error)

// executeInstallTo materializes the plan in two passes. Pass A creates
// every scheduler task (no Run); the per-client config block runs between
// the passes, preserving the scheduler-create → client-write → run
// ordering callers depend on; Pass B (gated by startTasks) starts the
// logon-triggered tasks. keepN caps the rolling timestamped-backup set per
// client (older copies are pruned in-place by the adapter); 0 disables
// pruning. Production callers feed it via a.effectiveBackupKeepN().
//
// startTasks=true reproduces the pre-two-pass behavior exactly (start
// logon-triggered daemons immediately). The migrate driver passes false to
// create tasks + write intent while deferring daemon spawn to the
// supervisor.
//
// intermediate, when non-nil, runs in the gap between the per-client config
// block and Pass B, INSIDE the rollback scope. It is the supervisor-intent
// write step for InstallParsedManifest (plan §"v7 executeInstallTo two-pass"
// — intent write is step 6 of the inner rollback). It returns a compensating
// undo that is pushed onto the same rollback stack as the scheduler-task and
// client-config undos; if it returns an error, the whole stack runs and
// executeInstallTo returns that error with every side effect undone. Legacy
// api.Install callers pass nil and observe bit-for-bit identical behavior
// (they record intent via recordInstallIntentPostSuccess AFTER this returns).
//
// skipPrune suppresses the full-install obsolete-task reconcile (step 1b). It
// is true only for workspace-scoped (DaemonTemplate) installs through
// InstallParsedManifest, whose plan carries ZERO SchedulerTasks — pruning
// against an empty planned set would delete every registered
// mcp-local-hub-<server>-* scheduler task for that server. Legacy callers pass
// false and keep the reconcile.
func executeInstallTo(w io.Writer, m *config.ServerManifest, p *Plan, keepN int, startTasks bool, intermediate intentWriteStep, skipPrune bool, skipTasks bool) error {
	return executeInstallToWithSymlinkConsents(w, m, p, keepN, startTasks, intermediate, skipPrune, skipTasks, nil)
}

// InstallClientRollbackIncompleteError is returned (via failAfterRollback) when a
// mid-install failure triggered the compensating rollback but ≥1 client-config
// restore callback FAILED — the client's pre-adopt restoration could not be
// confirmed. The client may have been mutated (Install rewrote it to the hub relay)
// and the restore-from-backup did not succeed, OR the restore write itself failed on
// an otherwise-untouched config. Rollback callbacks are best-effort and cannot return
// errors, so this typed sentinel is the only in-band signal that the client-side
// state is NOT provably reversed.
//
// ExecuteAdoptWithOpts inspects it via errors.As and PRESERVES the pre-adopt
// provenance (row + snapshots + manifest + routed vault keys) instead of deleting
// it, so the still-committed client stays recoverable (bug 2026-07-12). Present
// iff ≥1 client-restore callback errored; otherwise Install's error is
// byte-identical to today (no sentinel).
//
// Clients carries NAMES ONLY — no paths, no config bytes, no secret values.
type InstallClientRollbackIncompleteError struct {
	Clients []string
	cause   error
}

func (e *InstallClientRollbackIncompleteError) Error() string {
	return fmt.Sprintf("install client-config rollback incomplete (clients: %s): %v",
		strings.Join(e.Clients, ", "), e.cause)
}

// Unwrap returns the underlying install failure so errors.Is/As chains (the %w the
// caller wrapped) keep working through this sentinel.
func (e *InstallClientRollbackIncompleteError) Unwrap() error { return e.cause }

// InstallForwardCommittedError reports that install committed a coherent
// forward subset after one client mutation applied but its config-lock release
// could not be confirmed. Client is a name only; cause retains the lifecycle
// error and any mandatory-intent failure. Generic rollback or caller-side abort
// is forbidden for this outcome, but the full requested plan is not certified
// complete because later optional clients may have been skipped.
type InstallForwardCommittedError struct {
	Client string
	cause  error
}

func (e *InstallForwardCommittedError) Error() string {
	return fmt.Sprintf("install forward subset committed at client %s: %v", e.Client, e.cause)
}

func (e *InstallForwardCommittedError) Unwrap() error { return e.cause }

func executeInstallToWithSymlinkConsents(w io.Writer, m *config.ServerManifest, p *Plan, keepN int, startTasks bool, intermediate intentWriteStep, skipPrune bool, skipTasks bool, symlinkConsents []ResolvedSymlinkConsent) error {
	// v0.6 Phase F: when skipTasks is set (GLOBAL manifest install routed to the
	// supervisor model) NEITHER Pass A scheduler-task creation NOR Pass B start
	// runs — the daemons live in supervisor-intent.json and the supervisor
	// reconcile loop spawns them. The caller also sets skipPrune (the daemon set
	// is owned by supervisor-intent, not scheduler tasks) and passes a non-nil
	// intermediate that writes those rows. Folding skipTasks into the Pass A /
	// Pass B / needsScheduler conditions keeps the client-config block + the
	// intermediate supervisor-intent write inside the SAME rollback scope.
	actions := selectedInstallActions(p, startTasks, skipPrune, skipTasks)
	for _, notice := range p.Notices {
		fmt.Fprintf(w, "  notice: %s\n", notice)
	}
	// Acquire the scheduler only when there is real scheduler work: tasks to
	// create, an obsolete-task prune to run, or a Pass B start. A
	// workspace-scoped InstallParsedManifest (zero SchedulerTasks,
	// skipPrune=true, startTasks=false) — and a Phase-F global install
	// (skipTasks=true) — has none. On Linux/macOS scheduler.New() returns "not
	// implemented", so acquiring it unconditionally would fail serena/workspace
	// installs on those hosts before the supervisor-intent write — even though
	// this path has no scheduler dependency and defers daemon starts to the
	// reconciler. sch stays nil in that case and is never dereferenced: every
	// use below is inside the SchedulerTasks loop, the prune block (FullInstall
	// && !skipPrune), or Pass B (startTasks) — exactly the conditions in
	// needsScheduler.
	var sch scheduler.Scheduler
	if actions.scheduler {
		s, serr := newScheduler()
		if serr != nil {
			return fmt.Errorf("scheduler: %w", serr)
		}
		sch = s
	}
	// WorkingDirectory for the scheduler task: anchor at ~/.local/bin/
	// (same directory as the canonical mcphub binary). Using os.Getwd()
	// baked the dev-checkout cwd into the task XML — later invocations
	// from any other cwd broke because scheduler-spawned processes
	// inherited a stale cwd that no longer existed (e.g. R:\Temp\build
	// from a throwaway install run). ~/.local/bin is guaranteed to
	// exist (canonicalMcphubPath just confirmed it) and doesn't rot.
	canonical := p.installRelayExePath
	if canonical == "" {
		var err error
		canonical, err = resolveInstallRuntimeProduct(p.runtimeProduct)
		if err != nil {
			return err
		}
	}
	workDir := filepath.Dir(canonical)

	// Rollback stack: accumulate compensating operations as side effects
	// are applied. On mid-sequence failure, pop and run them in reverse
	// so a failed install does not leave the system in a half-configured
	// state (scheduler tasks for a server whose client entries were never
	// written, or vice-versa).
	var rollback []func()
	var installBackupPaths []string
	// rollbackClientRestoreFailures accumulates the NAMES of clients whose
	// client-config restore did not settle as applied during runRollback — the
	// client's pre-adopt state could not be confirmed (it may have been rewritten
	// to the hub relay and not reversed, OR the restore write itself failed on an
	// otherwise-untouched config).
	// Only the client-restore closure below appends to it — scheduler-task /
	// supervisor-intent undo failures do NOT, and a client whose entry-scoped
	// restore is a no-op (provably unmutated) never appends either (the folded
	// skip-if-unchanged returns nil WITHOUT writing) — so the sentinel is scoped to
	// client-config restores that actually ran and failed.
	var rollbackClientRestoreFailures []string
	// rollbackClientLifecycleErrors retains release-lifecycle failures from
	// restores whose bytes were nevertheless applied. Those restores are
	// reconciled, not rollback-incomplete, but the lifecycle failure must remain
	// visible at the composition boundary.
	var rollbackClientLifecycleErrors []error
	runRollback := func() {
		for i := len(rollback) - 1; i >= 0; i-- {
			rollback[i]()
		}
	}
	// failAfterRollback runs the compensating rollback stack, then returns the
	// caller's error. When ≥1 client-config restore did not settle as applied it
	// wraps the cause in a typed *InstallClientRollbackIncompleteError naming those
	// clients so ExecuteAdoptWithOpts can PRESERVE the pre-adopt provenance instead
	// of deleting it (bug 2026-07-12). A restore that applied but could not confirm
	// lock release contributes only its lifecycle error. With neither class, the
	// returned error remains the bare cause.
	failAfterRollback := func(cause error) error {
		runRollback()
		if len(rollbackClientLifecycleErrors) > 0 {
			joined := make([]error, 0, 1+len(rollbackClientLifecycleErrors))
			joined = append(joined, cause)
			joined = append(joined, rollbackClientLifecycleErrors...)
			cause = errors.Join(joined...)
		}
		if len(rollbackClientRestoreFailures) == 0 {
			return cause
		}
		return &InstallClientRollbackIncompleteError{
			Clients: append([]string(nil), rollbackClientRestoreFailures...),
			cause:   cause,
		}
	}

	// Pass A — create scheduler tasks ONLY (no Run). Collect each created
	// spec + its source trigger so Pass B can start the logon-triggered
	// subset without re-deriving from p.SchedulerTasks.
	//
	// v0.6 Phase F: when createTasks is false (GLOBAL manifest routed to the
	// supervisor model) this whole loop is skipped — no per-daemon
	// `\mcp-local-hub-<server>-<daemon>` Task Scheduler task is created. The
	// daemons are written into supervisor-intent.json by the intermediate hook
	// below and spawned by the supervisor reconcile loop. createdTasks stays
	// empty, so Pass B's start loop is a no-op too.
	var createdTasks []createdTask
	for _, t := range p.SchedulerTasks {
		if !actions.createEligible {
			break
		}
		spec := scheduler.TaskSpec{
			Name:             t.Name,
			Description:      "mcp-local-hub: " + m.Name,
			Command:          t.Command,
			Args:             t.Args,
			WorkingDir:       workDir,
			RestartOnFailure: true,
		}
		if t.Trigger == "At logon" {
			spec.LogonTrigger = true
		} else if t.Trigger == "Weekly Sun 03:00" {
			spec.WeeklyTrigger = &scheduler.WeeklyTrigger{DayOfWeek: 0, HourLocal: 3, MinuteLocal: 0}
		}
		// Snapshot any existing task before replacing it so rollback can
		// put it back. Prior to this, Delete-before-Create made install
		// idempotent but a mid-sequence failure left the user with
		// NOTHING — the old task was gone and the new one never got
		// created. ExportXML gives us the full Task Scheduler XML of
		// whatever was there; rollback feeds it to ImportXML to restore.
		var priorXML []byte
		if xml, err := sch.ExportXML(spec.Name); err == nil {
			priorXML = xml
		}
		_ = sch.Delete(spec.Name)
		if err := sch.Create(spec); err != nil {
			return failAfterRollback(fmt.Errorf("create task %s: %w", spec.Name, err))
		}
		taskName := spec.Name
		savedXML := priorXML // capture for closure
		rollback = append(rollback, func() {
			_ = sch.Delete(taskName)
			if len(savedXML) > 0 {
				if err := sch.ImportXML(taskName, savedXML); err == nil {
					fmt.Fprintf(w, "  rollback: restored prior scheduler task %s\n", taskName)
					return
				}
			}
			fmt.Fprintf(w, "  rollback: deleted scheduler task %s\n", taskName)
		})
		createdTasks = append(createdTasks, createdTask{spec: spec, trigger: t.Trigger})
		fmt.Fprintf(w, "\u2713 Scheduler task created: %s\n", spec.Name)
	}
	// 1b. Reconcile scheduler tasks: prune obsolete tasks left from prior
	// installs that this plan no longer covers (e.g. a `-weekly-refresh`
	// task from a manifest whose `weekly_refresh` flipped to false). Only
	// safe for full installs; partial installs target one daemon and must
	// not touch sibling tasks for daemons outside the filter.
	//
	// skipPrune additionally suppresses this for workspace-scoped
	// (DaemonTemplate) installs: their plan has ZERO SchedulerTasks, so an
	// empty planned set would prune every registered mcp-local-hub-<server>-*
	// task. Those daemons are tracked in supervisor-intent.json, not scheduler
	// tasks — there is nothing for this reconcile to own.
	if actions.prune {
		planned := make(map[string]struct{}, len(p.SchedulerTasks))
		for _, t := range p.SchedulerTasks {
			planned[t.Name] = struct{}{}
		}
		pruneRollbacks, perr := pruneObsoleteServerTasks(sch, m.Name, planned, w)
		if perr != nil {
			// Listing failed — fall through with a warning. Reconciliation
			// is a nice-to-have; a reinstall that can't enumerate prior
			// tasks is still strictly better than aborting the install.
			fmt.Fprintf(w, "\u26a0 Task reconciliation skipped: %v\n", perr)
		} else {
			rollback = append(rollback, pruneRollbacks...)
		}
	}
	// 2. Backup + update client configs.
	// Populate relay-related fields so adapters for stdio-only clients
	// (e.g. Antigravity) can produce their `command`+`args` entry shape
	// invoking `mcphub.exe relay`. HTTP-native adapters ignore these fields.
	// Use an absolute canonical path to avoid PATH/CWD lookup when clients
	// spawn the relay command.
	allClients := clients.AllClients()
	symlinkConsentWriters := clientConfigSymlinkConsentWriters(symlinkConsents)
	var forwardOnlyClientErr *InstallForwardCommittedError

clientUpdates:
	for _, u := range p.ClientUpdates {
		if !actions.clients {
			break
		}
		client := allClients[u.Client]
		if client == nil {
			return failAfterRollback(fmt.Errorf("unknown client %q in binding", u.Client))
		}
		if u.codexAlreadyConfigured {
			fmt.Fprintf(w, "✓ %s logical %s → target %s (already configured)\n", u.Client, m.Name, u.EntryName)
			continue
		}
		if !client.Exists() {
			fmt.Fprintf(w, "\u26a0 Client %s not installed on this machine \u2014 skipping\n", u.Client)
			continue
		}
		// Read the prior entry BEFORE backing up the file or adding the new
		// one. This remains a health gate: adapters such as mimocode can
		// confirm a write-target prior while also surfacing a malformed lower
		// layer. Rollback itself restores from the timestamped backup below,
		// because GetEntry intentionally projects many client schemas into a
		// small MCPEntry shape and can be lossy for direct stdio entries.
		//
		// A GetEntry error MUST abort BEFORE the backup/AddEntry below
		// (bot PR #420 finding 1, data-loss). For a multi-layer adapter
		// (mimocode) GetEntry can confirm a write-target prior yet still
		// fail reading a malformed lower layer, returning (nil, err).
		// Dropping that error would let AddEntry overwrite the write target
		// while the adapter has already said its layered read is corrupt. So
		// fail loud and run the rollback-so-far instead of proceeding from an
		// untrusted read.
		priorEntry, err := client.GetEntry(m.Name)
		if err != nil {
			return failAfterRollback(fmt.Errorf("snapshot prior entry for %s in %s: %w", m.Name, u.Client, err))
		}

		// keepN is the user's `backups.keep_n` setting (default 5). During
		// install, rollback closures hold the returned backup paths until
		// this run commits or rolls back. Take backups without pruning while
		// those closures are live, then prune after the run commits.
		backupKeepN := keepN
		if keepN > 0 {
			backupKeepN = 0
		}
		bak, err := client.BackupKeep(backupKeepN)
		if err != nil {
			return failAfterRollback(fmt.Errorf("backup %s: %w", u.Client, err))
		}
		if keepN > 0 {
			installBackupPaths = append(installBackupPaths, bak)
		}
		fmt.Fprintf(w, "  backup: %s\n", bak)
		entry := installClientEntryV1(m.Name, u, canonical)
		configWriter := symlinkConsentWriters[u.Client]
		if isCodexAliasInstallUpdate(m.Name, u) {
			codex, ok := clients.AsCodexTransportClient(client)
			if !ok {
				return failAfterRollback(fmt.Errorf("CODEX_LAYER_ROOT_UNRESOLVED: Codex transport adapter is unavailable"))
			}
			expectedSource, sourceErr := codexInstallSourceTransport(priorEntry)
			if sourceErr != nil {
				return failAfterRollback(sourceErr)
			}
			result, relocateErr := codex.RelocateHTTPEntry(clients.CodexHTTPRelocation{
				SourceEntryName: m.Name,
				TargetEntryName: u.EntryName,
				Entry:           entry,
				ExpectedSource:  expectedSource,
				WriteConfig:     configWriter,
			})
			if relocateErr != nil {
				return failAfterRollback(fmt.Errorf("relocate Codex entry %s to %s: %w", m.Name, u.EntryName, relocateErr))
			}
			if len(result.SourceSnapshot) == 0 {
				return failAfterRollback(fmt.Errorf("CODEX_CLIENT_CONFIG_READBACK_FAILED: relocation of %s to %s produced no source snapshot", m.Name, u.EntryName))
			}
			inverse := result.ExactInverse()
			if inverse == nil {
				return failAfterRollback(fmt.Errorf("CODEX_CLIENT_CONFIG_READBACK_FAILED: relocation produced no exact inverse"))
			}
			inverse.WriteConfig = configWriter
			targetName := u.EntryName
			rollback = append(rollback, func() {
				_, restoreErr := codex.RestoreRelocatedHTTPEntry(*inverse)
				if restoreErr != nil {
					rollbackClientRestoreFailures = append(rollbackClientRestoreFailures, u.Client)
					fmt.Fprintf(w, "  rollback: restore Codex logical %s from target %s failed: %v\n", m.Name, targetName, restoreErr)
					return
				}
				fmt.Fprintf(w, "  rollback: restored Codex logical %s from target %s\n", m.Name, targetName)
			})
			settlement, settlementErr := NewClientConfigSettlementOwnerV1().Accept(ClientConfigOperationInstall, result)
			if settlement != (ClientConfigSettlementV1{}) {
				p.clientConfigSettlements = append(p.clientConfigSettlements, settlement)
			}
			if settlementErr != nil {
				// The client transaction is already committed. Do not compensate a
				// possibly durable event append; return the retained row and fail
				// the wider install without claiming success.
				return settlementErr
			}
			fmt.Fprintf(w, "✓ %s logical %s → target %s\n", u.Client, m.Name, u.EntryName)
			continue
		}
		// Compensating op registered BEFORE the AddEntry mutation (bug 2026-07-12):
		// restore this entry's exact prior state from the timestamped backup taken
		// immediately above. AddEntry -> SecureWriteClientConfig has post-rename error
		// paths (#1 definitive verify-failure removes the just-published file; #2
		// transient reopen-failure leaves the published file = the hub relay) that
		// return an error with the live config ALREADY mutated. Registering the restore
		// FIRST means such a mutated-then-error AddEntry is still restored during
		// rollback \u2014 before, the closure was appended only after AddEntry success, so a
		// mutated-then-error AddEntry left the client config committed with NO
		// compensator, and adopt aborted (deleting the pre-adopt snapshot that reverses
		// it) = the P1 data-loss. A restore that cannot prove the pre-adopt state
		// appends clientName to rollbackClientRestoreFailures, feeding the sentinel
		// so adopt PRESERVES its provenance instead of aborting; an applied restore
		// with unconfirmed release retains only the lifecycle error. The adapter-level
		// restore is surgical: it restores/removes only entryName, leaving other live
		// entries untouched.
		//
		// The closure has three outcomes (design round-4 — the atomic entry-scoped
		// skip-if-unchanged is now FOLDED INTO the restore body under its single
		// withConfigLock hold, so no separate unlocked pre-check lives here). (1)
		// RECONCILED — the restore returns nil: either it reverted a mutated entry, or
		// the write-target already held the pre-adopt entry value (unmutated client, or
		// a sibling edit left THIS entry untouched) so the body skipped the write. Both
		// mean the client is reconciled to its pre-adopt state with no damage and no
		// sentinel append. (2) APPLIED-RELEASE-UNCONFIRMED — the intended bytes are
		// restored and the lifecycle error remains visible, but no rollback-incomplete
		// sentinel is emitted. (3) RESTORE-FAIL→SENTINEL — a restore that did not
		// settle as applied feeds clientName to rollbackClientRestoreFailures so adopt
		// preserves its recovery provenance.
		clientRef := client
		entryName := m.Name
		clientName := u.Client
		backupPath := bak
		rollbackWriter := configWriter
		rollback = append(rollback, func() {
			restoreErr := clients.RestoreEntryFromBackupForRollbackWithConfigWriter(clientRef, backupPath, entryName, rollbackWriter)
			switch classifyInstallClientMutation(restoreErr) {
			case clients.ClientMutationApplied:
				fmt.Fprintf(w, "  rollback: reconciled %s entry in %s to pre-adopt backup\n", entryName, clientName)
			case clients.ClientMutationAppliedReleaseUnconfirmed:
				rollbackClientLifecycleErrors = append(rollbackClientLifecycleErrors,
					fmt.Errorf("restore %s entry in %s from backup: configuration applied; lock release unconfirmed: %w", entryName, clientName, restoreErr))
				fmt.Fprintf(w, "  rollback: reconciled %s entry in %s to pre-adopt backup; lock release unconfirmed: %v\n", entryName, clientName, restoreErr)
			case clients.ClientMutationNeedsCompensation:
				rollbackClientRestoreFailures = append(rollbackClientRestoreFailures, clientName)
				fmt.Fprintf(w, "  rollback: restore %s entry in %s from backup failed: %v\n", entryName, clientName, restoreErr)
			}
		})
		addErr := clients.AddEntryWithConfigWriter(client, entry, configWriter)
		switch classifyInstallClientMutation(addErr) {
		case clients.ClientMutationApplied:
			fmt.Fprintf(w, "\u2713 %s \u2192 %s\n", u.Client, displayURLOf(u))
		case clients.ClientMutationAppliedReleaseUnconfirmed:
			// The entry is live, so its own pre-armed compensator is now wrong:
			// reacquiring this poisoned leaf is unsafe and rolling independent
			// scheduler state back would strand the applied target. Stop optional
			// client mutations, keep prior side effects, and continue only through
			// the mandatory intermediate intent settlement below.
			rollback = rollback[:len(rollback)-1]
			forwardOnlyClientErr = &InstallForwardCommittedError{
				Client: u.Client,
				cause:  fmt.Errorf("configuration applied; lock release unconfirmed: %w", addErr),
			}
			fmt.Fprintf(w, "\u2713 %s \u2192 %s (configuration applied; lock release unconfirmed)\n", u.Client, displayURLOf(u))
			break clientUpdates
		case clients.ClientMutationNeedsCompensation:
			return failAfterRollback(fmt.Errorf("add entry to %s: %w", u.Client, addErr))
		}
	}
	// Intermediate step (InstallParsedManifest only): write supervisor intent
	// INSIDE the rollback scope so an ordinary write failure undoes scheduler
	// tasks + client configs already applied. After an applied client mutation
	// whose lock release is unconfirmed, this becomes the mandatory forward-only
	// continuation: its failure is joined without compensating the poisoned leaf
	// or independent scheduler state. Legacy api.Install callers pass a nil hook.
	if intermediate != nil {
		undo, err := intermediate()
		if err != nil {
			if forwardOnlyClientErr != nil {
				return &InstallForwardCommittedError{
					Client: forwardOnlyClientErr.Client,
					cause: errors.Join(
						forwardOnlyClientErr.cause,
						fmt.Errorf("complete mandatory install intent after applied client configuration: %w", err),
					),
				}
			}
			return failAfterRollback(err)
		}
		if undo != nil && forwardOnlyClientErr == nil {
			rollback = append(rollback, undo)
		}
	}
	if forwardOnlyClientErr != nil {
		return forwardOnlyClientErr
	}
	postCommitWarnings := false
	for _, backupPath := range installBackupPaths {
		if err := pruneBackupsForBackupPath(backupPath, keepN); err != nil {
			postCommitWarnings = true
			fmt.Fprintf(w, "warning: backup retention lock lifecycle failed; install changes remain committed: %v\n", err)
		}
	}
	// Pass B - start daemons immediately (without waiting for next logon).
	// Gated by startTasks: the migrate driver passes false to defer daemon
	// spawn to the supervisor. A Run failure here is warning-only and must
	// NOT trigger rollback - the install (tasks + client configs) stands;
	// regressing this to a rollback-on-Run-failure would be a P0.
	if actions.start {
		for _, ct := range createdTasks {
			// Skip weekly refresh: triggered on schedule, not on install.
			if ct.trigger != "At logon" {
				continue
			}
			if err := sch.Run(ct.spec.Name); err != nil {
				fmt.Fprintf(w, "\u26a0 failed to start %s immediately: %v (will start at next logon)\n", ct.spec.Name, err)
			} else {
				fmt.Fprintf(w, "\u2713 Started: %s\n", ct.spec.Name)
			}
		}
	}
	printInstallCompletion(w, postCommitWarnings)
	return nil
}

func clientConfigSymlinkConsentWriters(consents []ResolvedSymlinkConsent) map[string]clients.WriteConfigFileFunc {
	if len(consents) == 0 {
		return nil
	}
	writers := make(map[string]clients.WriteConfigFileFunc, len(consents))
	for _, consent := range consents {
		consent := consent
		if strings.TrimSpace(consent.Client) == "" || strings.TrimSpace(consent.OriginalPath) == "" {
			continue
		}
		writers[consent.Client] = func(path string, contents []byte) error {
			if !sameInstallPath(path, consent.OriginalPath) {
				return fmt.Errorf("scoped symlink consent for %s applies to %s, not %s", consent.Client, consent.OriginalPath, path)
			}
			return SecureWriteClientConfigWithConsent(consent, contents)
		}
	}
	return writers
}

func sameInstallPath(a, b string) bool {
	cleanA := filepath.Clean(a)
	cleanB := filepath.Clean(b)
	if runtime.GOOS == "windows" {
		return strings.EqualFold(cleanA, cleanB)
	}
	return cleanA == cleanB
}

// installClientEntryV1 owns the plan-update to adapter write-request mapping.
// The command receipt uses the same request before projecting it through the
// adapter's GetEntry shape, so it cannot certify a hand-copied plan value.
func installClientEntryV1(server string, update ClientUpdatePlan, relayExePath string) clients.MCPEntry {
	entryName := update.EntryName
	if entryName == "" {
		entryName = server
	}
	return clients.MCPEntry{
		Name:           entryName,
		URL:            update.URL,
		Headers:        update.Headers,
		ToolTimeoutSec: update.ToolTimeoutSec,
		RelayServer:    server,
		RelayDaemon:    update.DaemonName,
		RelayExePath:   relayExePath,
		RelayURL:       update.RelayURL,
	}
}

func isCodexAliasInstallUpdate(logicalEntryName string, update ClientUpdatePlan) bool {
	return update.Client == "codex-cli" && update.EntryName != "" && update.EntryName != logicalEntryName
}

func codexInstallSourceTransport(prior *clients.MCPEntry) (clients.CodexTransport, error) {
	if prior == nil {
		return clients.CodexTransportNone, fmt.Errorf("CODEX_LAYER_COLLISION_UNOWNED_GLOBAL: logical Codex source entry is absent")
	}
	if prior.URL != "" {
		return clients.CodexTransportHTTP, nil
	}
	return clients.CodexTransportStdio, nil
}

// schedulerLister is the narrow scheduler subset pruneObsoleteServerTasks
// needs. scheduler.Scheduler satisfies it via its full method set; keeping
// the interface narrow lets tests supply a minimal fake without implementing
// Create / Run / Status / Stop.
type schedulerLister interface {
	List(prefix string) ([]scheduler.TaskStatus, error)
	Delete(name string) error
	ExportXML(name string) ([]byte, error)
	ImportXML(name string, xml []byte) error
}

// buildPruneSetForReconcile derives the set of "planned" task names from a
// supervisor-intent.json snapshot in the same BARE-key shape that
// pruneObsoleteServerTasks expects (see install.go:1773 — `strings.TrimPrefix(
// task.Name, "\\")` strips the canonical leading backslash before the
// prefix/equality check).
//
// supervisor-intent.json stores `task_name` in canonical leading-backslash
// form (e.g. `\mcp-local-hub-memory-default`); the install reconciler and
// the prune-set comparator both work in BARE form (without the backslash).
// This helper bridges the two shapes so reconcile-prune stays identical
// to the established install.go:1639-1642 planned-map invariant.
//
// Nil intent returns an empty (non-nil) map so callers never need a nil-deref
// guard before lookup.
//
// Spec §"Q12 CLI/GUI status seam" + plan §2611-2644.
func buildPruneSetForReconcile(intent *SupervisorIntentFile) map[string]struct{} {
	planned := make(map[string]struct{})
	if intent == nil {
		return planned
	}
	for _, d := range intent.Daemons {
		bare := strings.TrimPrefix(d.TaskName, "\\")
		if bare == "" {
			continue
		}
		planned[bare] = struct{}{}
	}
	for _, t := range intent.MaintenanceTimers {
		bare := strings.TrimPrefix(t.Name, "\\")
		if bare == "" {
			continue
		}
		planned[bare] = struct{}{}
	}
	return planned
}

// pruneObsoleteServerTasks deletes scheduler tasks whose Name starts with
// "mcp-local-hub-<server>-" and are absent from `planned`. Returns one
// rollback closure per successfully-pruned task that restores the task from
// its pre-delete XML snapshot. Callers must append these to their own
// rollback stack so a later install-sequence failure undoes the pruning
// together with the rest of the install.
//
// Only safe to call for full installs. Partial installs (one daemon) would
// see sibling-daemon tasks as "not in plan" and incorrectly prune them.
//
// Failures that are safe to continue past (per-task ExportXML errors,
// per-task Delete errors) are logged as warnings and skipped; only an
// initial List error is returned as fatal because we cannot reason about
// what to prune without an enumeration.
func pruneObsoleteServerTasks(sch schedulerLister, server string, planned map[string]struct{}, w io.Writer) ([]func(), error) {
	prefix := "mcp-local-hub-" + server + "-"
	existing, err := sch.List(prefix)
	if err != nil {
		return nil, fmt.Errorf("list tasks for %s: %w", server, err)
	}
	// FIX 2 (bot PR #288 hyphen-family): `planned` holds only THIS server's own
	// tasks, so a sibling's task (e.g. `\mcp-local-hub-demo-alpha-beta`, owned by
	// installed server `demo-alpha`) is absent from `planned` and a raw-prefix
	// prune of `demo` would DELETE it. Build the installed-server catalog once
	// and skip any task a LONGER installed server name also prefixes — the
	// longest-installed-prefix disambiguator owns it.
	installed := installedServerNameSet()
	var rollbacks []func()
	for _, task := range existing {
		// Windows Task Scheduler prefixes names with a leading backslash
		// (the task-folder separator). Strip it before prefix/equality
		// checks so "\mcp-local-hub-X-foo" matches "mcp-local-hub-X-foo".
		name := strings.TrimPrefix(task.Name, "\\")
		if !strings.HasPrefix(name, prefix) {
			continue
		}
		if _, keep := planned[name]; keep {
			continue
		}
		// Ownership guard: only prune tasks `server` actually owns. A sibling
		// task whose longest installed prefix is a DIFFERENT server survives.
		if !taskOwnedByServerExactOrLongestPrefix(task.Name, server, installed) {
			continue
		}
		// Snapshot XML for rollback. Best-effort: if the backend can't
		// export (platform limitation, ACL, etc.), we still delete but
		// rollback can only log that it cannot recreate.
		var priorXML []byte
		if xml, xerr := sch.ExportXML(name); xerr == nil {
			priorXML = xml
		}
		if derr := sch.Delete(name); derr != nil {
			fmt.Fprintf(w, "\u26a0 Failed to prune obsolete scheduler task %s: %v\n", name, derr)
			continue
		}
		fmt.Fprintf(w, "\u2713 Scheduler task removed (obsolete): %s\n", name)
		taskName := name
		savedXML := priorXML
		rollbacks = append(rollbacks, func() {
			if len(savedXML) == 0 {
				fmt.Fprintf(w, "  rollback: cannot recreate pruned task %s (no XML snapshot)\n", taskName)
				return
			}
			if ierr := sch.ImportXML(taskName, savedXML); ierr != nil {
				fmt.Fprintf(w, "  rollback: restore pruned task %s failed: %v\n", taskName, ierr)
				return
			}
			fmt.Fprintf(w, "  rollback: restored obsolete scheduler task %s\n", taskName)
		})
	}
	return rollbacks, nil
}

// clientConfigPath returns the absolute path to the named client's config.
// Private helper owned by the api package; a parallel copy lives in cli for
// commands that do not yet call through api (secrets, rollback).
func clientConfigPath(name string) (string, error) {
	return clients.ConfigPathForName(name)
}

// Stop stops a running daemon without removing its scheduler task or client
// entries. For each matching task it kills the daemon process by port
// FIRST (schtasks /End only terminates the task's launch action; the
// spawned daemon process keeps the port bound until killed) and then
// calls sch.Stop to clean up the scheduler state. Returns a per-task
// result set so callers can surface partial failures without bailing
// after the first row.
//
// Task 10 wiring (plan §8 + §11 + §51): Stop is the back-compat entry
// for the no-force path. It records Desired=stopped intent + a
// user-stop audit entry BEFORE killing; intent OR audit failure
// (incl. ErrIdentityOversize) returns the error verbatim and skips
// the kill. New callers that need --force should use StopWithOpts.
func (a *API) Stop(server, daemonFilter string) ([]RestartResult, error) {
	if err := ensureSupervisorControlAdmission(context.Background()); err != nil {
		return nil, err
	}
	taskNames, err := stopIntentTaskNamesForServer(server, daemonFilter)
	if err != nil {
		// Codex deep-sec PR #135 Finding 3: same forensic-trail emission as
		// StopWithOpts (no-force path).
		recordStopFailedNoKill(server, false, err)
		return nil, err
	}
	if err := a.recordStopIntent(taskNames, false); err != nil {
		return nil, err
	}
	return a.stopSupervisorAwareKill(server, daemonFilter)
}

// stopSupervisorAwareKill runs the supervisor reconcile pass followed by
// the legacy kill path, skipping any task the supervisor pass already
// handled (spec §4 Phase A.1 — the same combine-and-skip shape Restart
// uses). PRECONDITION: recordStopIntent must already have written
// Desired=stopped for the in-scope tasks; the supervisor reconcile reads
// that intent from disk.
func (a *API) stopSupervisorAwareKill(server, daemonFilter string) ([]RestartResult, error) {
	supResults, supervisorHandled, err := stopSupervisorOwnedDaemons(context.Background(), server, daemonFilter)
	if err != nil {
		return nil, err
	}
	// Reuse the restart skip-set builder: rows with Code ==
	// SUPERVISOR_UNAVAILABLE are dropped (the legacy path should retry
	// them); every other row — success OR reconcile-failed — is skipped
	// so the kill path never taskkills a daemon a live supervisor would
	// respawn.
	handledTasks := schedulerBlockedRestartTaskNames(supResults)
	// The route front is supervisor-only and has no manifest-backed legacy
	// scheduler task. Once its canonical target was settled by the supervisor,
	// do not re-enter listTasksForServer: route is deliberately a reserved
	// manifest name and the fallback has no work to perform.
	if supervisorHandled && isBuiltinRouteTargetSelector(server, daemonFilter) {
		return supResults, nil
	}
	killResults, err := a.stopKillCore(server, daemonFilter, handledTasks)
	if err != nil {
		// Mixed install where the supervisor handled every owned row and
		// the host has no usable scheduler (POSIX beta) — mirror
		// Restart's tolerance.
		if supervisorHandled && stopSchedulerUnavailableError(err) {
			return supResults, nil
		}
		return nil, err
	}
	return append(supResults, killResults...), nil
}

// stopKillCore is the original kill body of Stop. Extracted so Stop
// (no-force) and StopWithOpts (Force toggle) can share the kill path
// after each one has run its own intent/audit recording. handledTasks
// holds bare (no leading backslash) task names the supervisor reconcile
// pass already stopped; those are skipped here so the legacy path never
// taskkills a supervisor-owned daemon (the reaper would observe the
// non-clean exit and respawn it — the churn spec §4 kills).
func (a *API) stopKillCore(server, daemonFilter string, handledTasks map[string]struct{}) ([]RestartResult, error) {
	sch, err := stopSchedulerFactory()
	if err != nil {
		return nil, err
	}
	tasks, err := listTasksForServer(sch, server)
	if err != nil {
		return nil, err
	}
	ports := manifestPortMap("")
	wsByTask := workspaceTasksByName()
	installed := installedServerNameSet()
	var results []RestartResult
	for _, t := range tasks {
		normalized := strings.TrimPrefix(t.Name, "\\")
		if !isHubDaemonSchedulerTaskName(normalized) {
			continue
		}
		if _, already := handledTasks[normalized]; already {
			continue
		}
		if !taskMatchesServerDaemonGate(normalized, server, daemonFilter, installed) {
			continue
		}
		port := portForTask(normalized, ports, wsByTask)
		if port != 0 {
			if err := killByPortFn(port, 5*time.Second); err != nil {
				results = append(results, RestartResult{TaskName: t.Name, Err: "kill daemon: " + err.Error()})
				continue
			}
		}
		_ = sch.Stop(t.Name)
		results = append(results, RestartResult{TaskName: t.Name})
	}
	return results, nil
}

// taskMatchesServerDaemonGate is the exact-identity per-daemon gate shared by
// the stopKillCore and Restart legacy scheduler loops (FIX 3, bot PR #288
// hyphen-family). The previous gate was a bare
// `strings.HasSuffix(normalized, "-"+daemonFilter)`, which matched sibling
// tasks: `stop --server demo --daemon beta` matched
// `\mcp-local-hub-demo-alpha-beta` (server demo-alpha / daemon beta) and killed
// demo-alpha's REAL port.
//
// The gate distinguishes three cases:
//
//   - Workspace lazy-proxy tasks (`mcp-local-hub-lsp-<key>-<lang>`) carry no
//     server slug, so ParseManagedTaskName would mis-split them. They keep the
//     original suffix semantics: an empty daemonFilter targets every workspace
//     proxy listTasksForServer surfaced (preserving `stop --server
//     mcp-language-server`); a non-empty daemonFilter matches the proxy whose
//     `lsp-<key>-<lang>` daemon segment equals it.
//
//   - A NON-EMPTY daemonFilter is matched by exact task-name reconstruction:
//     the task must equal `mcp-local-hub-<server>-<daemonFilter>` verbatim. This
//     is unambiguous even for hyphenated daemon names (`vscode-css`), where
//     ParseManagedTaskName's greedy LastIndex('-') split would otherwise
//     misattribute server/daemon. It rejects `mcp-local-hub-demo-alpha-beta`
//     for (demo, beta) because the exact name is `mcp-local-hub-demo-beta`.
//
//   - An EMPTY daemonFilter (whole-server stop/restart) defers to the SAME
//     longest-installed-prefix ownership used by listTasksForServer's scope
//     filter, so the two layers agree: a sibling-owned task is excluded, a
//     genuinely-owned (exact or longest-prefix) task is included.
func taskMatchesServerDaemonGate(normalized, server, daemonFilter string, installedServers map[string]struct{}) bool {
	if IsLazyProxyTaskName(normalized) {
		if daemonFilter == "" {
			return true
		}
		return strings.HasSuffix(normalized, "-"+daemonFilter)
	}
	if daemonFilter != "" {
		want := strings.TrimPrefix(canonicalIntentTaskKey("mcp-local-hub-"+server+"-"+daemonFilter), `\`)
		return strings.TrimPrefix(normalized, `\`) == want
	}
	return taskOwnedByServerExactOrLongestPrefix(normalized, server, installedServers)
}

// Restart kills the live daemons for one server (+ optional daemon
// filter) by port and re-runs their scheduler tasks. The --server
// counterpart of RestartAll: same semantics, narrower scope.
//
// Task 10 wiring (plan §65 fail-handling table): per task, AFTER a
// successful sch.Run, the function records Desired=running intent +
// a server-restarted audit entry. Audit / intent failures are logged
// to opts.Writer (or os.Stderr by default) and never propagate — the
// restart already happened.
func (a *API) Restart(server, daemonFilter string) ([]RestartResult, error) {
	return a.restartWithFrozenDispatch(context.Background(), server, daemonFilter)
}

// restartWithFrozenDispatch is the receiver-free private mutation core used by
// both the legacy wrapper and the command adapter.
func (a *API) restartWithFrozenDispatch(ctx context.Context, server, daemonFilter string) ([]RestartResult, error) {
	if err := ensureSupervisorControlAdmission(ctx); err != nil {
		return nil, err
	}
	results, supervisorHandled, err := restartSupervisorOwnedDaemons(ctx, server, daemonFilter)
	if err != nil {
		return nil, err
	}
	// Mixed install: a server can have supervisor-owned rows AND legacy
	// scheduler tasks. Don't short-circuit after the supervisor pass —
	// fall through to restart the remaining scheduler tasks for this
	// server, skipping any task name already respawned via the supervisor
	// (same combine-and-skip behavior as RestartAll). Bot PR #268 r3.
	handledTasks := schedulerBlockedRestartTaskNames(results)
	sch, err := restartSchedulerFactory()
	if err != nil {
		if supervisorHandled && restartSchedulerUnavailableError(err) {
			return results, nil
		}
		return nil, err
	}
	tasks, err := listTasksForServer(sch, server)
	if err != nil {
		if supervisorHandled && restartSchedulerUnavailableError(err) {
			return results, nil
		}
		return nil, err
	}
	ports := manifestPortMap("")
	wsByTask := workspaceTasksByName()
	installed := installedServerNameSet()
	for _, t := range tasks {
		normalized := strings.TrimPrefix(t.Name, "\\")
		if !isHubDaemonSchedulerTaskName(normalized) {
			continue
		}
		if _, already := handledTasks[normalized]; already {
			continue
		}
		if !taskMatchesServerDaemonGate(normalized, server, daemonFilter, installed) {
			continue
		}
		port := portForTask(normalized, ports, wsByTask)
		if port != 0 {
			if err := killByPortFn(port, 5*time.Second); err != nil {
				results = append(results, RestartResult{TaskName: t.Name, Err: "kill daemon: " + err.Error()})
				continue
			}
			// DM-3: wait for the OS to actually release the listening
			// socket before triggering /Run. killDaemonByPort confirms
			// process exit, but TIME_WAIT and Windows' AFD socket-close
			// path can briefly hold the bind. Without this, the new
			// daemon's bind fails immediately and Task Scheduler records
			// last_result=1 with no useful diagnostic. 3s is small enough
			// to be invisible in normal restarts and large enough to ride
			// out the typical TIME_WAIT window.
			if err := waitForPortFreeFn(port, 3*time.Second); err != nil {
				results = append(results, RestartResult{TaskName: t.Name, Err: "wait for port: " + err.Error()})
				continue
			}
		}
		_ = sch.Stop(t.Name)
		if err := sch.Run(t.Name); err != nil {
			results = append(results, RestartResult{TaskName: t.Name, Err: err.Error()})
			continue
		}
		// Task 10 plan §65: AFTER /Run success, record Desired=running
		// intent + restart audit entry. Failures are logged + tolerated.
		// We pass `normalized` (no leading backslash) — the canonical
		// task-key normalization in WriteStopIntent (Codex deep-sec
		// PR #135 Finding 1, carried forward to the Phase 4-E2 sub-block
		// writer) prepends "\" before storage so the entry lands under the
		// same key the supervisor reconcile loop
		// (internal/cli/supervise_reconcile.go) indexes via row.TaskName.
		// Phase 4-E2: recordRestartIntentForTask writes the
		// supervisor-intent.json `stops` sub-block via WriteStopIntent, NOT
		// the legacy daemon-intent.json — see install_intent.go.
		a.recordRestartIntentForTask(normalized, nil)
		results = append(results, RestartResult{TaskName: t.Name})
	}
	return results, nil
}

// listTasksForServer returns every scheduler task whose name maps to
// the given server. For global servers that means the classic
// "mcp-local-hub-<server>-" prefix. For workspace-scoped servers (the
// manifest's Kind == workspace-scoped) the per-(workspace, language)
// proxy tasks use "mcp-local-hub-lsp-<key>-<lang>" with NO server slug
// in the name — this helper also queries that prefix so `mcphub stop
// --server mcp-language-server` and `mcphub restart --server
// mcp-language-server` actually target those daemons. Without the
// extended match, workspace-scoped proxies survive every server-scoped
// maintenance command.
func listTasksForServer(sch scheduler.Scheduler, server string) ([]scheduler.TaskStatus, error) {
	primary, err := sch.List("mcp-local-hub-" + server + "-")
	if err != nil {
		return nil, err
	}
	// FIX 4 (bot PR #288 hyphen-family): sch.List is a raw HasPrefix match, so
	// `--server demo` over-captures sibling `demo-alpha`'s task
	// `\mcp-local-hub-demo-alpha-beta`; portForTask would then resolve
	// demo-alpha's REAL port and stop/restart would kill its live daemon. Filter
	// the primary list to tasks `demo` actually owns (exact parsed-server match,
	// or the longest-installed-prefix rule for a blank/legacy daemon row). The
	// workspace lsp-* branch below is left UNTOUCHED — those proxy tasks carry no
	// server slug in the name and are owned via the registry/workspace-path
	// handling in portForTask, not by this server-name filter.
	installed := installedServerNameSet()
	owned := primary[:0]
	for _, t := range primary {
		if taskOwnedByServerExactOrLongestPrefix(t.Name, server, installed) {
			owned = append(owned, t)
		}
	}
	primary = owned
	if !serverIsWorkspaceScoped(server) {
		return primary, nil
	}
	lsp, err := sch.List("mcp-local-hub-lsp-")
	if err != nil {
		// Surface the error. Swallowing would let Stop/Restart
		// report "success" while silently skipping every workspace
		// proxy — a scheduler/service glitch would then leave stale
		// daemons running with no signal to the operator. Wrap so
		// the caller can distinguish primary vs secondary list
		// failure when debugging.
		return nil, fmt.Errorf("list workspace-scoped lazy-proxy tasks: %w", err)
	}
	return append(primary, lsp...), nil
}

// serverIsWorkspaceScoped returns true iff the given server name refers
// to a manifest with Kind == workspace-scoped. Misses (unknown manifest,
// load error) return false — classic behavior.
func serverIsWorkspaceScoped(server string) bool {
	data, err := loadManifestYAMLEmbedFirst(server)
	if err != nil {
		return false
	}
	m, err := parseManifestForName(server, data)
	if err != nil {
		return false
	}
	return m.Kind == config.KindWorkspaceScoped
}

// workspaceTasksByName returns a (taskName → WorkspaceEntry) map from
// the current registry. Used by Stop/Restart to find the right port for
// workspace-scoped lazy-proxy tasks (their ports live in the registry,
// not the manifest). Nil on registry load failure — callers treat it as
// empty and fall back to manifest ports.
func workspaceTasksByName() map[string]WorkspaceEntry {
	regPath, err := DefaultRegistryPath()
	if err != nil {
		return nil
	}
	reg := NewRegistry(regPath)
	if err := reg.Load(); err != nil {
		return nil
	}
	out := make(map[string]WorkspaceEntry, len(reg.Workspaces))
	for _, e := range reg.Workspaces {
		out[strings.TrimPrefix(e.TaskName, "\\")] = e
	}
	return out
}

// portForTask resolves the port for a scheduler task name, trying the
// workspace-scoped registry first (for lazy-proxy tasks) and then
// falling back to the manifest port map (for global daemons).
func portForTask(taskName string, ports map[string]map[string]int, wsByTask map[string]WorkspaceEntry) int {
	if e, ok := wsByTask[taskName]; ok && e.Port != 0 {
		return e.Port
	}
	srv, dmn := parseTaskName(taskName)
	if p, ok := ports[srv][dmn]; ok {
		return p
	}
	return ports[srv]["default"]
}

// RestartResult is one row in a RestartAll/Restart report. JSON tags
// added in Phase 3B-II A3-a (memo D9): the GUI restart handler now
// emits per-task results in JSON, and `error` is NOT omitempty —
// empty-string is the success discriminator the frontend parses.
type RestartResult struct {
	TaskName string `json:"task_name"`
	Err      string `json:"error"`
	Warning  string `json:"warning,omitempty"`
	Code     string `json:"-"`
}

func schedulerBlockedRestartTaskNames(results []RestartResult) map[string]struct{} {
	handledTasks := make(map[string]struct{}, len(results))
	for _, result := range results {
		name := strings.TrimPrefix(result.TaskName, "\\")
		if name == "" {
			continue
		}
		// A row selected from supervisor-intent is supervisor-owned even
		// when its current IPC attempt fails. Falling through to the legacy
		// scheduler would create a second control path after the authenticated
		// compatibility probe chose the strict supervisor protocol.
		handledTasks[name] = struct{}{}
	}
	return handledTasks
}

const supervisorAutostartTaskLeaf = "mcp-local-hub-supervisor"

func isHubInfrastructureTaskName(taskName string) bool {
	name := strings.TrimPrefix(strings.TrimSpace(taskName), "\\")
	// The autostart constant lives in internal/autostart as
	// WindowsTaskName. Keep the leaf local here to avoid an api ->
	// autostart import cycle.
	if name == supervisorAutostartTaskLeaf {
		return true
	}
	return isMaintenanceTaskName(name)
}

func isHubDaemonSchedulerTaskName(taskName string) bool {
	name := strings.TrimPrefix(strings.TrimSpace(taskName), "\\")
	if name == "" || isHubInfrastructureTaskName(name) {
		return false
	}
	server, daemon := ParseManagedTaskName(name)
	return server != "" && daemon != ""
}

// RestartAll stops+starts every scheduler task under our prefix. Returns a
// per-task result list with any errors.
//
// Why we don't rely on scheduler.Stop alone: the task's action (spawning
// the daemon) finishes in milliseconds; the scheduler immediately flips
// the task back to "Ready". `schtasks /End` therefore finds no running
// task instance and silently succeeds, while the daemon process keeps
// running. A subsequent `schtasks /Run` tries to spawn a second daemon,
// hits the bound port, and dies — so the user ends up with the original
// stale daemon they wanted to replace. We have to kill the daemon
// process by port first.
func (a *API) RestartAll() ([]RestartResult, error) {
	return a.restartAllWithFrozenDispatch(context.Background())
}

// restartAllWithFrozenDispatch is the bulk form of the same private mutation
// core. It intentionally does not depend on the readiness receiver.
func (a *API) restartAllWithFrozenDispatch(ctx context.Context) ([]RestartResult, error) {
	if err := ensureSupervisorControlAdmission(ctx); err != nil {
		return nil, err
	}
	results, supervisorHandled, err := restartSupervisorOwnedDaemons(ctx, "", "")
	if err != nil {
		return nil, err
	}
	handledTasks := schedulerBlockedRestartTaskNames(results)

	sch, err := restartSchedulerFactory()
	if err != nil {
		if supervisorHandled && restartSchedulerUnavailableError(err) {
			return results, nil
		}
		return nil, err
	}
	tasks, err := sch.List("mcp-local-hub-")
	if err != nil {
		if supervisorHandled && restartSchedulerUnavailableError(err) {
			return results, nil
		}
		return nil, err
	}
	ports := manifestPortMap("")
	wsByTask := workspaceTasksByName()
	for _, t := range tasks {
		normalized := strings.TrimPrefix(t.Name, "\\")
		if !isHubDaemonSchedulerTaskName(normalized) {
			continue
		}
		if _, alreadyHandled := handledTasks[normalized]; alreadyHandled {
			continue
		}
		port := portForTask(normalized, ports, wsByTask)
		if err := killByPortFn(port, 5*time.Second); err != nil {
			results = append(results, RestartResult{TaskName: t.Name, Err: "kill daemon: " + err.Error()})
			continue
		}
		if port != 0 {
			// DM-3: see Restart() comment. Same TIME_WAIT race applies
			// to RestartAll's per-task kill-then-Run.
			if err := waitForPortFreeFn(port, 3*time.Second); err != nil {
				results = append(results, RestartResult{TaskName: t.Name, Err: "wait for port: " + err.Error()})
				continue
			}
		}
		_ = sch.Stop(t.Name) // no-op for completed actions; preserve for the edge case of a mid-launch task
		if err := sch.Run(t.Name); err != nil {
			results = append(results, RestartResult{TaskName: t.Name, Err: err.Error()})
			continue
		}
		results = append(results, RestartResult{TaskName: t.Name})
	}
	return results, nil
}

// waitForPortFree probes the local 127.0.0.1:port until net.Listen
// succeeds or timeout elapses. Used by Restart paths between
// killDaemonByPort and schtasks /Run to avoid the OS-level TIME_WAIT /
// AFD socket-close race where a new daemon's bind fails immediately
// after the old daemon exited (DM-3). The probe is loopback-only — we
// only ever bind on 127.0.0.1, so a 0.0.0.0 listener probe would race
// with unrelated services and add false negatives.
func waitForPortFree(port int, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	addr := fmt.Sprintf("127.0.0.1:%d", port)
	var lastErr error
	for {
		l, err := net.Listen("tcp", addr)
		if err == nil {
			_ = l.Close()
			return nil
		}
		lastErr = err
		if !time.Now().Before(deadline) {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	// The loop only breaks after at least one failed Listen, so lastErr is
	// always the non-nil bind error here — wrap it unconditionally.
	return fmt.Errorf("port %d still in use after %v: %w", port, timeout, lastErr)
}

// StopAll stops every running scheduler task under our prefix. Leaves tasks
// in place (scheduler will relaunch them at next LogonTrigger unless also
// uninstalled). Kills the daemon process by port (see RestartAll comment
// on why scheduler.Stop alone isn't enough). Returns per-task results so
// the CLI can report failures.
//
// Spec §4 Phase A.1: supervisor-owned daemons are stopped through the
// supervisor IPC reconcile instead of taskkill. Unlike Stop, StopAll
// historically recorded NO stop intent at all — without a Desired=stopped
// entry in daemon-intent.json the reconcile would see desired=running and
// could not stop anything — so the supervisor pass here records intent
// for its own targets FIRST. Legacy scheduler tasks keep the historical
// no-intent kill behavior.
func (a *API) StopAll() ([]RestartResult, error) {
	if err := ensureSupervisorControlAdmission(context.Background()); err != nil {
		return nil, err
	}
	supTargets, err := loadSupervisorOwnedTargets("", "")
	if err != nil {
		return nil, err
	}
	if len(supTargets) > 0 {
		names := make([]string, 0, len(supTargets))
		for _, d := range supTargets {
			names = append(names, strings.TrimPrefix(d.TaskName, `\`))
		}
		// Intent MUST be on disk before the reconcile reads it; a
		// failed intent write fail-closes the supervisor pass the same
		// way Stop's recordStopIntent does. Use the --all who label so
		// the forensic audit log distinguishes a bulk "stop everything"
		// from a targeted `mcphub stop X` (fable F3).
		if err := a.recordStopIntentAs(names, false, auditWhoMcphubStopAll); err != nil {
			return nil, err
		}
	}
	supResults, supervisorHandled, err := stopSupervisorOwnedDaemons(context.Background(), "", "")
	if err != nil {
		return nil, err
	}
	handledTasks := schedulerBlockedRestartTaskNames(supResults)
	sch, err := stopSchedulerFactory()
	if err != nil {
		if supervisorHandled && stopSchedulerUnavailableError(err) {
			return supResults, nil
		}
		return nil, err
	}
	tasks, err := sch.List("mcp-local-hub-")
	if err != nil {
		if supervisorHandled && stopSchedulerUnavailableError(err) {
			return supResults, nil
		}
		return nil, err
	}
	ports := manifestPortMap("")
	wsByTask := workspaceTasksByName()
	results := supResults
	for _, t := range tasks {
		normalized := strings.TrimPrefix(t.Name, "\\")
		if !isHubDaemonSchedulerTaskName(normalized) {
			continue
		}
		if _, already := handledTasks[normalized]; already {
			continue
		}
		port := portForTask(normalized, ports, wsByTask)
		if err := killByPortFn(port, 5*time.Second); err != nil {
			results = append(results, RestartResult{TaskName: t.Name, Err: "kill daemon: " + err.Error()})
			continue
		}
		_ = sch.Stop(t.Name)
		results = append(results, RestartResult{TaskName: t.Name})
	}
	return results, nil
}

// killByPortFn is a test seam for killDaemonByPort. Production callers go
// through this indirection so the Unregister and WeeklyRefreshAll code
// paths can be unit-tested without spawning real processes bound to ports.
// Tests assign a fake in their setup and restore the default in defer.
var killByPortFn = killDaemonByPort

// waitForPortFreeFn is the sibling test seam for waitForPortFree, for the same
// reason: the Restart / RestartAll legacy-scheduler loops must be unit-testable
// without a real net.Listen bind probe against a live daemon's port.
var waitForPortFreeFn = waitForPortFree

var errPortKillUnsupported = errors.New("port kill unsupported: process lookup unavailable")

const daemonPortReleasePollInterval = 200 * time.Millisecond

type portKillOutcome int

const (
	portKillNoPort portKillOutcome = iota
	portKillLookupUnavailable
	portKillNoListener
	portKillKilled
	portKillIdentityMismatch
	portKillProbeUnknown
)

var forceKillByPortFn = killDaemonByPortOutcome

var taskkillProcessTreeByPIDFn = taskkillProcessTreeByPID

func taskkillProcessTreeByPID(pid int) error {
	cmd := exec.Command("taskkill", "/PID", strconv.Itoa(pid), "/F", "/T")
	process.NoConsole(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("taskkill %d: %w: %s", pid, err, strings.TrimSpace(string(out)))
	}
	return nil
}

// killDaemonByPort finds the process listening on 127.0.0.1:port, kills
// its whole tree with taskkill /F /T, and polls until the port is free.
// Returns nil when nothing is listening (nothing to kill), or when the host has
// no process-lookup hook for port-owner discovery.
//
// /T is critical: our hub.exe spawns npx/uvx which spawn node/python.
// Killing only hub.exe leaves the grandchildren running and occupying
// the child-stdin side of the pipe.
func killDaemonByPort(port int, timeout time.Duration) error {
	_, err := killDaemonByPortOutcome(port, timeout)
	return err
}

func killDaemonByPortOutcome(port int, timeout time.Duration) (portKillOutcome, error) {
	if port == 0 {
		return portKillNoPort, nil
	}
	if lookupPortPID == nil {
		return portKillLookupUnavailable, nil
	}
	pid, found, err := lookupPortPID(port)
	if err != nil {
		return portKillNoListener, fmt.Errorf("query port %d before kill: %w", port, err)
	}
	if !found {
		return portKillNoListener, nil
	}
	if err := requireMcphubPortOwnerPID(port, pid); err != nil {
		if errors.Is(err, process.ErrProcessAlreadyExited) {
			// pr301 r5 Finding 2: the PID owning this port exited between
			// lookupPortPID and the owner-SID gate's OpenProcess (a TOCTOU
			// window). The owner-SID arm surfaces the canonical
			// ErrProcessAlreadyExited sentinel. A gone port owner is the
			// already-released SUCCESS condition — there is nothing left to
			// taskkill — so return the benign no-listener outcome (nil error),
			// identical to the !ok no-listener branch above. Treating it as a
			// portKillIdentityMismatch FAILURE would report a failed kill for a
			// daemon that is already gone.
			return portKillNoListener, nil
		}
		return portKillIdentityMismatch, err
	}
	if err := taskkillProcessTreeByPIDFn(pid); err != nil {
		return portKillNoListener, err
	}
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		_, stillUp, err := lookupPortPID(port)
		if err != nil {
			return portKillProbeUnknown, fmt.Errorf("killed pid %d; port %d release unknown: %w", pid, port, err)
		}
		if !stillUp {
			return portKillKilled, nil
		}
		time.Sleep(daemonPortReleasePollInterval)
	}
	return portKillNoListener, fmt.Errorf("port %d still bound after %s", port, timeout)
}
