"""Finite checks for the Go port observation contract; existing offline tools only."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

SOURCE = Path(r"<SOURCE>")
WORK = Path(r"<WORK>")
GO = Path(r"<GO_BIN>\go.exe")
GOFMT = GO.with_name("gofmt.exe")
GIT = r"<GIT>"
BASE = "a7d92d2852c4f6eb8afb0569ef76a545e38aacf7"
phase = sys.argv[1]
WORK.mkdir(exist_ok=True)
if phase == "baseline-failures":
    SOURCE = Path(r"<BASELINE>")
outdir = WORK / phase
outdir.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("MCPHUB_")}
runtime_dir = WORK / "runtime" / phase
for name in ("tmp", "appdata", "localappdata", "profile", "gopath"):
    (runtime_dir / name).mkdir(parents=True, exist_ok=True)
env.update({
    "GOROOT": r"<GO_ROOT>", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "",
    "GOCACHE": r"<GO_CACHE_ROOT>\gocache",
    "GOMODCACHE": r"<GO_CACHE_ROOT>\gomodcache",
    "GOPATH": str(runtime_dir / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1",
    "MCPHUB_E2E_SCHEDULER": "none", "USERPROFILE": str(runtime_dir / "profile"),
    "APPDATA": str(runtime_dir / "appdata"), "LOCALAPPDATA": str(runtime_dir / "localappdata"),
    "TEMP": str(runtime_dir / "tmp"), "TMP": str(runtime_dir / "tmp"),
    "TMPDIR": str(runtime_dir / "tmp"), "GOTMPDIR": str(runtime_dir / "tmp"),
    "PYTHONDONTWRITEBYTECODE": "1",
})
env["PATH"] = str(GO.parent) + os.pathsep + env.get("PATH", "")
for path in (GO, GOFMT, Path(env["CC"]), Path(env["GOROOT"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    assert path.exists(), path

def git(*args):
    return subprocess.check_output([GIT, "-C", str(SOURCE), *args], env=env, text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

spec = json.loads((WORK / "files.json").read_text(encoding="utf-8"))
paths = [f["path"] for f in spec if (SOURCE / f["path"]).exists()]
receipt = {"phase": phase, "base": BASE, "head": git("rev-parse", "HEAD"),
           "go_version": subprocess.check_output([str(GO), "version"], env=env, text=True).strip(),
           "runner_sha256": digest(Path(__file__)), "windows": list(sys.getwindowsversion()[:3]),
           "environment": {k: env[k] for k in ("GOPROXY", "GOSUMDB", "GOVCS", "GOTOOLCHAIN", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")},
           "source_sha256_before": {p: digest(SOURCE / p) for p in paths}, "commands": []}
assert receipt["head"] == BASE or phase.startswith("published"), receipt["head"]

def save():
    (outdir / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

def run(name, arguments, executable=GO):
    started = datetime.now(timezone.utc).isoformat()
    print("START", name, flush=True)
    stdout, stderr = outdir / (name + ".stdout.log"), outdir / (name + ".stderr.log")
    before = time.monotonic()
    with stdout.open("wb") as fo, stderr.open("wb") as fe:
        done = subprocess.run([str(executable), *arguments], cwd=SOURCE, env=env, stdout=fo, stderr=fe)
    record = {"name": name, "executable": executable.name if isinstance(executable, Path) else executable,
              "arguments": arguments, "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "seconds": round(time.monotonic() - before, 3), "exit_code": done.returncode,
              "stdout_sha256": digest(stdout), "stderr_sha256": digest(stderr), "stderr_bytes": stderr.stat().st_size}
    if "-json" in arguments and arguments[0] == "test":
        events = []
        for line in stdout.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                pass
        record["tests"] = {action: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == action]
                           for action in ("pass", "fail", "skip")}
    receipt["commands"].append(record)
    save()
    print(json.dumps({k: record[k] for k in ("name", "exit_code", "seconds", "stderr_bytes")}), flush=True)
    return record

focused = (WORK / "focused-pattern.txt").read_text(encoding="utf-8").strip()
contract = "^(TestQueryLoopbackPortPID.*|TestQueryPortProcessInfo.*|TestPortPID.*|TestEnrichStatusWithRegistry_ScalarFallback.*|TestTestMainSealsLiveFleetAndSlowSeams|TestRunProbeCommand.*)$"
if phase == "format":
    assert all(digest(SOURCE / f["path"]) == f["sha256"] for f in spec), "transfer byte mismatch"
    assert run("gofmt", ["-w", *paths], GOFMT)["exit_code"] == 0
    receipt["formatted"] = {p: digest(SOURCE / p) for p in paths}
    (outdir / "formatted-files.json").write_text(json.dumps([{ "path": p, "content": (SOURCE / p).read_text(encoding="utf-8"), "sha256": digest(SOURCE / p)} for p in paths], ensure_ascii=False), encoding="utf-8")
    assert run("diff-check", ["diff", "--check"], Path(GIT))["exit_code"] == 0
elif phase == "format-final":
    assert run("gofmt", ["-w", *paths], GOFMT)["exit_code"] == 0
    receipt["formatted"] = {p: digest(SOURCE / p) for p in paths}
    (outdir / "formatted-files.json").write_text(json.dumps([{ "path": p, "content": (SOURCE / p).read_text(encoding="utf-8"), "sha256": digest(SOURCE / p)} for p in paths], ensure_ascii=False), encoding="utf-8")
    assert run("diff-check", ["diff", "--check"], Path(GIT))["exit_code"] == 0
elif phase == "baseline-failures":
    old = json.loads((WORK / "affected-final" / "receipt.json").read_text())
    failed = sorted({name.split("/")[0] for name in old["commands"][0]["tests"]["fail"] if not name.startswith("PACKAGE:")})
    pattern = "^(" + "|".join(failed) + ")$"
    run("baseline-same-failures", ["test", "-mod=readonly", "-json", "-race", "-count=1", "-timeout=120s", "-run", pattern, "./internal/api"])
elif phase == "affected-tagged":
    focused = (WORK / "affected-pattern.txt").read_text().strip()
    run("affected-tagged-race", ["test", "-mod=readonly", "-json", "-race", "-tags=test_state_path_env", "-count=1", "-timeout=300s", "-run", focused, "./internal/api"])
elif phase == "controls":
    controls = [
        ("query-error-collapse", "internal/api/processes.go",
         'return 0, false, fmt.Errorf("query loopback port %d: %w", port, err)',
         'return 0, false, nil',
         "^TestPortPIDCollectorFailureReachesKillPolicy$",
         ["TestPortPIDCollectorFailureReachesKillPolicy", "PACKAGE:mcp-local-hub/internal/api"],
         "collector failure became a stop result"),
        ("unexpected-metrics", "internal/api/processes.go",
         '\t\tif pid, found := netstatLinePIDForLoopbackPort(line, port); found {\n\t\t\treturn pid, true, nil',
         '\t\tif pid, found := netstatLinePIDForLoopbackPort(line, port); found {\n\t\t\t_, _ = runProbeCommand(probeCommandTimeout, "wmic", "process", "where", fmt.Sprintf("ProcessId=%d", pid), "get", "WorkingSetSize,CreationDate", "/format:csv")\n\t\t\treturn pid, true, nil',
         "^TestQueryLoopbackPortPIDUsesBoundedCollectorWithoutMetrics$/^exact_listener$",
         ["TestQueryLoopbackPortPIDUsesBoundedCollectorWithoutMetrics/exact_listener", "TestQueryLoopbackPortPIDUsesBoundedCollectorWithoutMetrics", "PACKAGE:mcp-local-hub/internal/api"],
         "child observations = [netstat wmic]"),
        ("benign-enum-with-error", "internal/api/install.go",
         'return portKillProbeUnknown, fmt.Errorf("query port %d before kill: %w", port, err)',
         'return portKillNoListener, fmt.Errorf("query port %d before kill: %w", port, err)',
         "^TestPortPIDSerenaRemovalPreservesIntentWhenProbeIsUnknown$",
         ["TestPortPIDSerenaRemovalPreservesIntentWhenProbeIsUnknown", "PACKAGE:mcp-local-hub/internal/api"],
         "Serena removal = (true, <nil>)"),
    ]
    receipt["controls"] = []
    for name, relative, old, new, pattern, failures, diagnostic in controls:
        path = SOURCE / relative
        original = path.read_bytes()
        text = original.decode("utf-8")
        assert text.count(old) == 1, name
        changed = text.replace(old, new).encode("utf-8")
        (outdir / (name + ".original.go")).write_bytes(original)
        (outdir / (name + ".mutated.go")).write_bytes(changed)
        control = {"name": name, "path": relative, "original_sha256": hashlib.sha256(original).hexdigest(),
                   "mutated_sha256": hashlib.sha256(changed).hexdigest(), "expected_failures": failures,
                   "diagnostic": diagnostic}
        receipt["controls"].append(control)
        try:
            path.write_bytes(changed)
            record = run(name, ["test", "-mod=readonly", "-json", "-count=1", "-timeout=120s", "-run", pattern, "./internal/api"])
            output = "".join(json.loads(line).get("Output", "") for line in (outdir / (name + ".stdout.log")).read_text().splitlines() if line.startswith("{"))
            control["matched_expected_failure"] = (record["exit_code"] == 1 and record["stderr_bytes"] == 0
                and record["tests"]["fail"] == failures and not record["tests"]["skip"] and diagnostic in output)
        finally:
            path.write_bytes(original)
            control["restored_exact_bytes"] = path.read_bytes() == original
            save()
        assert control["restored_exact_bytes"] and control["matched_expected_failure"], control
    receipt["all_controls_matched"] = True
elif phase.startswith("contract") or phase.startswith("published"):
    assert run("contract-race", ["test", "-mod=readonly", "-json", "-race", "-count=1", "-timeout=120s", "-run", contract, "./internal/api"])["exit_code"] == 0
elif phase.startswith("affected"):
    assert run("affected-race", ["test", "-mod=readonly", "-json", "-race", "-count=1", "-timeout=300s", "-run", focused, "./internal/api"])["exit_code"] == 0
    assert run("affected-tagged-race", ["test", "-mod=readonly", "-json", "-race", "-tags=test_state_path_env", "-count=1", "-timeout=300s", "-run", focused, "./internal/api"])["exit_code"] == 0
elif phase == "gates":
    for name, args in (("build", ["build", "./..."]), ("vet", ["vet", "./..."]),
                       ("full-test", ["test", "-count=1", "-timeout", "5m", "./..."]),
                       ("state-tag-full", ["test", "-tags=test_state_path_env", "-count=1", "-timeout", "5m", "./internal/api/", "./internal/cli/"])):
        run(name, args)
else:
    raise ValueError(phase)
receipt["source_sha256_after"] = {p: digest(SOURCE / p) for p in paths}
receipt["source_stable"] = (phase.startswith("format") or receipt["source_sha256_after"] == receipt["source_sha256_before"])
receipt["status_after"] = git("status", "--porcelain=v1", "--untracked-files=all")
save()
assert receipt["source_stable"]
print("COMPLETE", phase, flush=True)
