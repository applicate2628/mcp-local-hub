"""Prepare and perform two public read-only calls; never mutate Scheduler tasks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
ROOT = Path(r'<WORK_ROOT>')
SOURCE = Path(r'<SOURCE_ROOT>')
HEAD = '9721681633440d3593d37ffb8f580e5d98440da2'
TREE = '016c9faa5aaedb3ed7db2e6b23066913824a4f09'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<GIT_EXECUTABLE>')
phase = sys.argv[1]
if phase not in {'prepare', 'verify'}:
    raise SystemExit('Unknown phase')
out = ROOT / ('prepare-v2' if phase=='prepare' else phase)
out.mkdir(exist_ok=False)
runtime = out / 'runtime'
for name in ('tmp','profile','appdata','localappdata','gopath','empty-hooks'):
    (runtime/name).mkdir(parents=True, exist_ok=True)
env = {k:v for k,v in os.environ.items() if not k.upper().startswith(('MCPHUB_', 'GIT_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system/'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({'GOROOT':r'<GO_ROOT>','GOENV':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOVCS':'*:off','GOWORK':'off','GOFLAGS':'-mod=readonly','GOTELEMETRY':'off','GOMAXPROCS':'4','CGO_ENABLED':'1','CC':str(GO.with_name('gcc.exe')),'GOCACHE':r'<GO_CACHE_ROOT>\gocache','GOMODCACHE':r'<GO_CACHE_ROOT>\gomodcache','GOPATH':str(runtime/'gopath'),'MCPHUB_NO_AUTO_GUI':'1','USERPROFILE':str(runtime/'profile'),'APPDATA':str(runtime/'appdata'),'LOCALAPPDATA':str(runtime/'localappdata'),'TEMP':str(runtime/'tmp'),'TMP':str(runtime/'tmp'),'TMPDIR':str(runtime/'tmp'),'GOTMPDIR':str(runtime/'tmp'),'PSModuleAnalysisCachePath':str(runtime/'localappdata/module-analysis-cache'),'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':str(runtime/'no-global-git-config')})
env['PATH'] = os.pathsep.join((str(GO.parent),str(ps.parent),str(system/'System32'),str(GIT.parent)))
receipt = {'phase':phase,'head':HEAD,'tree':TREE,'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[],'scheduler_mutations':False,'whole_process_tree_deadline_enforced':False}
temporary_created=False
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save():
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def move_temporary_source():
    target=SOURCE/'r17_last_result_readonly_probe.go'
    if not temporary_created or not target.exists(): return
    if digest(target)!=receipt['probe_source_sha256'] or not all(x.get('settled') for x in receipt['commands']): return
    trash=Path(r'<OWNED_WORK_ROOT>\trash\r17-last-result-native-build-20261120-v2')
    trash.mkdir(exist_ok=True)
    destination=trash/target.name
    if destination.exists(): raise RuntimeError('Trash destination already exists')
    target.rename(destination)
    receipt['temporary_source_moved_to_trash']=True
def git(*args):
    return subprocess.check_output([str(GIT),'-c','core.hooksPath='+str(runtime/'empty-hooks'),'-C',str(SOURCE),*args],env=env).decode().strip()
def source_state():
    if Path(git('rev-parse','--show-toplevel')).resolve()!=SOURCE.resolve():
        raise RuntimeError('Repository root mismatch')
    state={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1','--untracked-files=all')}
    if state!={'head':HEAD,'tree':TREE,'status':''}:
        raise RuntimeError('Source state mismatch')
    return state
def run(name, executable, args, input_bytes=None):
    record={'name':name,'executable':executable.name,'arguments':args if executable!=ps else ['-NoProfile','-NonInteractive','-Command','<saved snapshot.ps1>'],'started_utc':datetime.now(timezone.utc).isoformat(),'settled':False}
    receipt['commands'].append(record);save()
    clock=time.monotonic()
    with (out/(name+'.stdout.log')).open('xb') as fo,(out/(name+'.stderr.log')).open('xb') as fe:
        with subprocess.Popen([str(executable),*args],cwd=SOURCE,env=env,stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,stdout=fo,stderr=fe,creationflags=0x08000000) as child:
            record['pid']=child.pid;save()
            child.communicate(input=input_bytes)
            record.update(exit_code=child.returncode,settled=True)
    for stream in ('stdout','stderr'):
        path=out/(name+'.'+stream+'.log')
        record[stream+'_sha256']=digest(path);record[stream+'_bytes']=path.stat().st_size
    record['seconds']=round(time.monotonic()-clock,6);save()
    print(json.dumps({k:record[k] for k in ('name','exit_code','settled','seconds','stdout_bytes','stderr_bytes')}),flush=True)
    return record
try:
    receipt['source_before']=source_state()
    probe_bytes=(ROOT/'probe.go').read_bytes()
    snapshot_bytes=(ROOT/'snapshot.ps1').read_bytes()
    receipt['probe_source_sha256']=hashlib.sha256(probe_bytes).hexdigest()
    receipt['runner_sha256']=digest(Path(__file__))
    receipt['snapshot_source_sha256']=hashlib.sha256(snapshot_bytes).hexdigest()
    binary=ROOT/'last-result-readonly.exe'
    if phase=='prepare':
        version=run('go-version',GO,['version'])
        if version['exit_code']!=0: raise RuntimeError('Go version failed')
        target=SOURCE/'r17_last_result_readonly_probe.go'
        with target.open('xb') as f: f.write(probe_bytes)
        temporary_created=True
        fmt=run('gofmt-check',GO.with_name('gofmt.exe'),['-l',str(target)])
        if fmt['exit_code']!=0 or fmt['stdout_bytes']!=0: raise RuntimeError('Probe needs formatting')
        build=run('build',GO,['build','-tags=r17_last_result_native_probe','-trimpath','-o',str(binary),str(target)])
        if build['exit_code']!=0: raise RuntimeError('Probe build failed')
        receipt['binary_sha256']=digest(binary)
        empty=run('empty-manifest',binary,[],b'')
        events=[json.loads(x) for x in (out/'empty-manifest.stdout.log').read_text().splitlines()]
        receipt['negative_admission_control']=empty['exit_code']==1 and not empty['stderr_bytes'] and len(events)==1 and events[0].get('event')=='overall' and events[0].get('error_category')=='invalid_manifest' and events[0].get('backend_type')=='' and events[0].get('pass') is False
        if not receipt['negative_admission_control']: raise RuntimeError('Admission control mismatch')
        move_temporary_source()
        if target.exists(): raise RuntimeError('Temporary source retained')
    else:
        prep=json.loads((ROOT/'prepare-v2/receipt.json').read_text())
        if not prep.get('success') or digest(binary)!=prep['binary_sha256'] or receipt['probe_source_sha256']!=prep['probe_source_sha256'] or receipt['snapshot_source_sha256']!=prep['snapshot_source_sha256'] or digest(Path(__file__))!=prep['runner_sha256']:
            raise RuntimeError('Preparation binding mismatch')
        receipt['binary_sha256']=digest(binary)
        env['R17_SNAPSHOT_PHASE']='before'
        before=run('snapshot-before',ps,['-NoProfile','-NonInteractive','-Command',snapshot_bytes.decode('utf-8')])
        if before['exit_code']!=0 or before['stderr_bytes']: raise RuntimeError('Initial snapshot failed')
        private=json.loads((ROOT/'before-private.json').read_text(encoding='utf-8-sig'))
        manifest={key:private[key] for key in ('head','name','prefix','owner','state','last_result')}
        payload=json.dumps(manifest,ensure_ascii=False).encode('utf-8')
        (out/'manifest-private.json').write_bytes(payload)
        probe=run('public-go-reads',binary,[],payload)
        env['R17_SNAPSHOT_PHASE']='after'
        after=run('snapshot-after',ps,['-NoProfile','-NonInteractive','-Command',snapshot_bytes.decode('utf-8')])
        receipt['stable_private_snapshots']=json.loads((ROOT/'before-private.json').read_text(encoding='utf-8-sig'))==json.loads((ROOT/'after-private.json').read_text(encoding='utf-8-sig'))
        events=[json.loads(x) for x in (out/'public-go-reads.stdout.log').read_text().splitlines()]
        results=[x for x in events if x.get('event')=='result']
        receipt['public_reads_passed']=probe['exit_code']==0 and not probe['stderr_bytes'] and len(events)==5 and [x.get('check') for x in results]==['status','list'] and all(x.get('pass') is True and x.get('observed_last_result')==private['last_result'] for x in results) and events[-1].get('event')=='overall' and events[-1].get('pass') is True and events[-1].get('backend_type')=='*scheduler.windowsScheduler' and events[-1].get('completed_task_exit_qualified') is False and events[-1].get('full_native_qualification') is False
        if not receipt['public_reads_passed'] or after['exit_code']!=0 or after['stderr_bytes'] or not receipt['stable_private_snapshots']:
            raise RuntimeError('Native read qualification failed')
        receipt['last_result_observed']=private['last_result']
        receipt['completed_action_exit_qualified']=False
        receipt['atomic_snapshot_claimed']=False
    receipt['binary_sha256_after']=digest(binary)
    if receipt['binary_sha256_after']!=receipt['binary_sha256']: raise RuntimeError('Binary changed')
    receipt['source_after']=source_state()
    receipt['success']=True
finally:
    if phase=='prepare':
        try: move_temporary_source()
        except Exception as cleanup_error: receipt['cleanup_error_category']=type(cleanup_error).__name__
        receipt['temporary_source_retained']=(SOURCE/'r17_last_result_readonly_probe.go').exists()
        receipt['recovery_required']=receipt['temporary_source_retained']
    receipt['finished_utc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'phase':phase,'success':receipt.get('success',False),'head':HEAD,'binary_sha256':receipt.get('binary_sha256'),'native_value':receipt.get('last_result_observed')}),flush=True)
