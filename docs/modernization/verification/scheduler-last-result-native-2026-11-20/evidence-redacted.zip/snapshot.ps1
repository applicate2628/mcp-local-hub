$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$root = '<WORK_ROOT>'
$phase = $env:R17_SNAPSHOT_PHASE
if ($phase -cnotin @('before', 'after')) { throw 'Invalid snapshot phase' }
$path = Join-Path $root ($phase + '-private.json')
if (Test-Path -LiteralPath $path) { throw 'Snapshot already exists' }
try {
    $expected = [IO.File]::ReadAllText((Join-Path $root 'candidate-private.json'), $utf8) | ConvertFrom-Json
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $folder = $service.GetFolder('\')
    $task = $folder.GetTask(([string]$expected.name).TrimStart('\'))
    $value = $task.LastTaskResult
    if ($null -eq $value) { throw 'Missing result' }
    $instances = $task.GetInstances(0)
    $snapshot = [pscustomobject][ordered]@{
        head = '9721681633440d3593d37ffb8f580e5d98440da2'
        name = '\' + [string]$task.Name
        prefix = [string]$task.Name
        owner = [string]$task.Definition.Principal.UserId
        state = [int]$task.State
        last_result = [int]$value
        result_runtime_type = $value.GetType().FullName
        last_run_ticks = ([datetime]$task.LastRunTime).Ticks
        hidden = [bool]$task.Definition.Settings.Hidden
        instance_count = [int]$instances.Count
        xml = [string]$task.Xml
    }
    [IO.File]::WriteAllText($path, ($snapshot | ConvertTo-Json -Depth 5), $utf8)
    $matches = [ordered]@{}
    foreach ($field in @('head','name','prefix','owner','state','last_result','result_runtime_type','last_run_ticks','hidden','instance_count','xml')) {
        $matches[$field + '_unchanged'] = ($snapshot.$field -ceq $expected.$field)
    }
    $prefixMatches = @($folder.GetTasks(0) | Where-Object {
        ([string]$_.Name).StartsWith([string]$snapshot.prefix) -and ([string]$_.Definition.Principal.UserId) -ieq ([string]$snapshot.owner)
    })
    $matches['single_visible_prefix_match'] = ($prefixMatches.Count -eq 1)
    $pass = -not ($matches.Values -contains $false)
    [pscustomobject]@{phase=$phase;pass=$pass;matches=$matches;last_result=$snapshot.last_result;state=$snapshot.state;visible_instances=$snapshot.instance_count;scheduler_changes=$false} | ConvertTo-Json -Compress -Depth 4
    if (!$pass) { exit 2 }
} catch {
    [IO.File]::WriteAllText((Join-Path $root ($phase + '-error-private.txt')), ($_ | Out-String), $utf8)
    [pscustomobject]@{phase=$phase;pass=$false;observation_failed=$true;scheduler_changes=$false} | ConvertTo-Json -Compress
    exit 1
}
