$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$root = '<WORK_ROOT>'
$privatePath = Join-Path $root 'candidate-private.json'
if (Test-Path -LiteralPath $privatePath) { throw 'Candidate evidence already exists' }
try {
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $currentName = $identity.Name
    $shortName = ($currentName -split '\\')[-1]
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $folder = $service.GetFolder('\')
    $visible = @($folder.GetTasks(0))
    $owned = @($visible | Where-Object {
        $owner = [string]$_.Definition.Principal.UserId
        $owner -ieq $currentName -or $owner -ieq $shortName
    })
    $eligible = @()
    $queryFailures = 0
    foreach ($task in $owned) {
        try {
            $value = $task.LastTaskResult
            if ($null -eq $value) { throw 'Missing result' }
            $state = [int]$task.State
            $instances = $task.GetInstances(0)
            $count = [int]$instances.Count
            if ($state -notin @(1, 3) -or $count -ne 0 -or [int]$value -eq 0) { continue }
            $name = [string]$task.Name
            $prefixMatches = @($owned | Where-Object { ([string]$_.Name).StartsWith($name) })
            if ($prefixMatches.Count -ne 1) { continue }
            $eligible += [pscustomobject][ordered]@{
                head = '9721681633440d3593d37ffb8f580e5d98440da2'
                name = '\' + $name
                prefix = $name
                owner = [string]$task.Definition.Principal.UserId
                state = $state
                last_result = [int]$value
                result_runtime_type = $value.GetType().FullName
                last_run_ticks = ([datetime]$task.LastRunTime).Ticks
                hidden = [bool]$task.Definition.Settings.Hidden
                instance_count = $count
                xml = [string]$task.Xml
            }
        } catch { $queryFailures++ }
    }
    $chosen = @($eligible | Sort-Object name | Select-Object -First 1)
    $summary = [ordered]@{
        mode = 'READ_ONLY_CANDIDATE_OBSERVATION'
        queried_visible_root_tasks = $visible.Count
        current_account_visible_tasks = $owned.Count
        eligible_nonzero_idle_tasks = $eligible.Count
        query_failures = $queryFailures
        selected = ($chosen.Count -eq 1)
        scheduler_changes = $false
        scope = 'visible root tasks under the current account; instances visible to this security context'
    }
    if ($chosen.Count -eq 1) {
        [IO.File]::WriteAllText($privatePath, ($chosen[0] | ConvertTo-Json -Depth 5), $utf8)
        $summary['last_result'] = $chosen[0].last_result
        $summary['result_runtime_type'] = $chosen[0].result_runtime_type
        $summary['state'] = $chosen[0].state
    }
    $summary | ConvertTo-Json -Compress
    if ($chosen.Count -ne 1) { exit 3 }
} catch {
    [IO.File]::WriteAllText((Join-Path $root 'observation-error-private.txt'), ($_ | Out-String), $utf8)
    [pscustomobject]@{mode='READ_ONLY_CANDIDATE_OBSERVATION'; selected=$false; observation_failed=$true; scheduler_changes=$false} | ConvertTo-Json -Compress
    exit 1
}
