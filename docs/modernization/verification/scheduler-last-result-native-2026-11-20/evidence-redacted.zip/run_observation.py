from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
ROOT = Path(r'<WORK_ROOT>')
RUNTIME = ROOT / 'runtime-observation'
RUNTIME.mkdir(exist_ok=False)
env = dict(os.environ)
for key in list(env):
    if key.upper().startswith('MCPHUB_'):
        del env[key]
for key, child in [('TEMP','temp'),('TMP','temp'),('USERPROFILE','profile'),('APPDATA','appdata'),('LOCALAPPDATA','localappdata')]:
    path = RUNTIME / child
    path.mkdir(exist_ok=True)
    env[key] = str(path)
env['PSModuleAnalysisCachePath'] = str(RUNTIME / 'module-analysis-cache')
system = env.get('SYSTEMROOT') or env['SystemRoot']
powershell = str(Path(system) / 'System32/WindowsPowerShell/v1.0/powershell.exe')
env['PATH'] = str(Path(powershell).parent) + ';' + str(Path(system) / 'System32')
source = ROOT / 'observe_candidates.ps1'
argv = [powershell, '-NoProfile', '-NonInteractive', '-Command', source.read_text(encoding='utf-8')]
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
with (ROOT/'observation.stdout.log').open('xb') as out, (ROOT/'observation.stderr.log').open('xb') as err:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, creationflags=0x08000000)
    (ROOT/'observation-start.json').write_text(json.dumps({'pid':child.pid,'started_utc':started,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n')
    code = child.wait()
stdout = (ROOT/'observation.stdout.log').read_bytes()
stderr = (ROOT/'observation.stderr.log').read_bytes()
summary = json.loads(stdout.decode('utf-8-sig')) if stdout else None
receipt = {'started_utc':started,'duration_seconds':round(time.monotonic()-clock,6),'exit_code':code,'settled':True,'stderr_bytes':len(stderr),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'summary':summary,'scheduler_changes':False}
(ROOT/'observation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(code)
