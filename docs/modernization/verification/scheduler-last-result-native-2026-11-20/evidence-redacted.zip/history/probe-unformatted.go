//go:build windows && r17_last_result_native_probe

// Two read-only public calls against an independently observed existing task.
// The owner supplies the private manifest and checks the surrounding snapshots.
// Source: https://github.com/applicate2628/mcp-local-hub/tree/9721681633440d3593d37ffb8f580e5d98440da2/internal/scheduler
package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"runtime"
	"strings"
	"time"
	"unicode/utf8"

	"mcp-local-hub/internal/scheduler"
)

const targetHead = "9721681633440d3593d37ffb8f580e5d98440da2"

type manifest struct {
	Head       string `json:"head"`
	Name       string `json:"name"`
	Prefix     string `json:"prefix"`
	Owner      string `json:"owner"`
	State      int    `json:"state"`
	LastResult *int32 `json:"last_result"`
}

func main() {
	started := time.Now()
	backend, category := "", "not_completed"
	defer func() {
		panicked := recover() != nil
		if panicked {
			category = "panic"
		}
		passed := category == "none"
		status := "FAIL"
		if passed {
			status = "PASS"
		}
		emit(map[string]any{
			"event": "overall", "status": status, "pass": passed,
			"duration_ns": time.Since(started).Nanoseconds(), "backend_type": backend,
			"error_category": category, "panic_recovered": panicked,
			"claim": "observed_native_last_result_transfer_only",
			"completed_task_exit_qualified": false, "full_native_qualification": false,
		})
		if !passed {
			os.Exit(1)
		}
	}()
	backend, category = probe()
}

func probe() (string, string) {
	m, valid := readManifest()
	if !valid {
		return "", "invalid_manifest"
	}
	if runtime.GOOS != "windows" {
		return "", "not_windows"
	}
	if strings.EqualFold(strings.TrimSpace(os.Getenv("MCPHUB_E2E_SCHEDULER")), "none") {
		return "", "scheduler_override_none"
	}
	s, err := scheduler.New()
	backend := fmt.Sprintf("%T", s)
	if err != nil {
		return backend, errorCategory(err)
	}
	if backend != "*scheduler.windowsScheduler" {
		return backend, "unexpected_backend"
	}

	started := begin("status")
	status, err := s.Status(m.Name)
	category := errorCategory(err)
	var observed *scheduler.TaskStatus
	if err == nil {
		observed = &status
		category = inspectStatus(status, m)
	}
	finish("status", started, category, observed)
	if category != "none" {
		return backend, category
	}

	started = begin("list")
	rows, err := s.List(m.Prefix)
	category = errorCategory(err)
	observed = nil
	if err == nil {
		category = "unexpected_row_count"
		if len(rows) == 1 {
			observed = &rows[0]
			category = inspectStatus(rows[0], m)
		}
	}
	finish("list", started, category, observed)
	return backend, category
}

func readManifest() (manifest, bool) {
	var m manifest
	const limit = 64 * 1024
	raw, err := io.ReadAll(io.LimitReader(os.Stdin, limit+1))
	if err != nil || len(raw) > limit || !utf8.Valid(raw) {
		return m, false
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	token, err := decoder.Token()
	if err != nil || token != json.Delim('{') {
		return m, false
	}
	// Require the six exact keys once each; do not accept duplicate or case-folded keys.
	seen := make(map[string]bool, 6)
	for decoder.More() {
		token, err = decoder.Token()
		key, ok := token.(string)
		if err != nil || !ok || seen[key] {
			return m, false
		}
		seen[key] = true
		switch key {
		case "head":
			err = decoder.Decode(&m.Head)
		case "name":
			err = decoder.Decode(&m.Name)
		case "prefix":
			err = decoder.Decode(&m.Prefix)
		case "owner":
			err = decoder.Decode(&m.Owner)
		case "state":
			err = decoder.Decode(&m.State)
		case "last_result":
			err = decoder.Decode(&m.LastResult)
		default:
			return m, false
		}
		if err != nil {
			return m, false
		}
	}
	token, err = decoder.Token()
	if err != nil || token != json.Delim('}') {
		return m, false
	}
	var extra any
	if decoder.Decode(&extra) != io.EOF || len(seen) != 6 || m.Head != targetHead {
		return m, false
	}
	if strings.TrimSpace(m.Prefix) == "" || strings.ContainsAny(m.Prefix, `/\`) || m.Name != `\`+m.Prefix || strings.TrimSpace(m.Owner) == "" {
		return m, false
	}
	return m, (m.State == 1 || m.State == 3) && m.LastResult != nil && *m.LastResult != 0
}

func inspectStatus(status scheduler.TaskStatus, m manifest) string {
	if status.Name != m.Name {
		return "name_mismatch"
	}
	if status.Owner != m.Owner {
		return "owner_mismatch"
	}
	wantRuntime, wantDisplay := scheduler.TaskRuntimeDisabled, "Disabled"
	if m.State == 3 {
		wantRuntime, wantDisplay = scheduler.TaskRuntimeReady, "Ready"
	}
	if status.RuntimeState != wantRuntime || status.State != wantDisplay {
		return "state_mismatch"
	}
	if status.LastResult != int(*m.LastResult) {
		return "last_result_mismatch"
	}
	return "none"
}

func errorCategory(err error) string {
	switch {
	case err == nil:
		return "none"
	case errors.Is(err, scheduler.ErrTaskNotFound):
		return "task_not_found"
	case errors.Is(err, scheduler.ErrTaskNotRunning):
		return "task_not_running"
	case errors.Is(err, scheduler.ErrPermissionDenied):
		return "permission_denied"
	case errors.Is(err, scheduler.ErrTaskCorrupt):
		return "task_corrupt"
	case errors.Is(err, scheduler.ErrUnavailable):
		return "unavailable"
	default:
		return "other_error"
	}
}

func begin(check string) time.Time {
	emit(map[string]any{"event": "begin", "check": check})
	return time.Now()
}

func finish(check string, started time.Time, category string, observed *scheduler.TaskStatus) {
	event := map[string]any{
		"event": "result", "check": check, "pass": category == "none",
		"duration_ns": time.Since(started).Nanoseconds(), "error_category": category,
	}
	if observed != nil {
		event["observed_last_result"] = observed.LastResult
		event["observed_last_result_type"] = fmt.Sprintf("%T", observed.LastResult)
	}
	emit(event)
}

func emit(value any) {
	if json.NewEncoder(os.Stdout).Encode(value) != nil {
		os.Exit(2)
	}
}
