"""Validate saved evidence and package redacted copies; perform no native calls.

Originals remain untouched. Published scripts are review copies with redacted paths.
"""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import zipfile

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')

ROOT = Path(r'<WORK_ROOT>')
SOURCE = r'<SOURCE_ROOT>'
TARGET = SOURCE + r'\r17_last_result_readonly_probe.go'
HEAD = '9721681633440d3593d37ffb8f580e5d98440da2'
TREE = '016c9faa5aaedb3ed7db2e6b23066913824a4f09'
VALUE = 267011
CLAIM = 'observed_native_last_result_transfer_only'
PROCESS_SCOPE = 'work-root marker in executable path or command line'
PINNED = {
    'probe.go': '951b34ef26eb98238efd2589bca29a36c074f4c0424984aa7ecd56f87a1410f1',
    'run_probe.py': '728c5d9fa0431fc65c565b6f38657c6cec935740420f344697cf68e433c34216',
    'snapshot.ps1': 'c327a31e4fe952e87ad64bc0020a3a223fc9af44d09aa46996871ac64165e1d7',
    'last-result-readonly.exe': '25d0d47edfda212512c36df614729eb81b49ef27bf8b2d4bbd21aaa021a66576',
    'history/probe-unformatted.go': '08610c3f23b8db7fa82c600f4322c2c219dcbe10f5df1dd052e18825442dbb0b',
    'history/run_probe-prepare1.py': '29fe2719655e6e14a89480e8316f04a6f286f9b9c40fa972cb4a2c7b2fbb037e',
    'observe_candidates.ps1': 'aa7777092f7eb1b01bd2676bd6309e60f43caa063785ffb7180e187910ef87de',
    'run_observation.py': '15c6eb66b3ce083d0b020b0613a7a07d0797002c2cd32ef0692e1248dffa527c',
    'observe_owned_processes.py': 'a371cdc38aadaa8fa286878f27868a304f535ca21d452b8482f14ece593b78c1',
}
SOURCES = (
    'PROBE.md', 'probe.go', 'run_probe.py', 'snapshot.ps1',
    'observe_candidates.ps1', 'run_observation.py', 'observe_owned_processes.py',
    'history/probe-unformatted.go', 'history/run_probe-prepare1.py', 'package_evidence.py',
)
PRIVATE_FILES = (
    'candidate-private.json', 'before-private.json', 'after-private.json',
    'verify/manifest-private.json',
)
OUTPUTS = ('execution-summary.json', 'evidence-redacted.zip',
           'archive-metadata.json', 'evidence-redacted.base64.txt')
raw_files = {}
stream_checks = {}
missing_recorded_sizes = []


class EvidenceError(Exception):
    pass


def need(condition, label):
    if not condition:
        raise EvidenceError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    if name not in raw_files:
        path = ROOT / name
        need(path.is_file() and ROOT.resolve() in path.resolve().parents,
             'missing_or_outside_root: ' + name)
        raw_files[name] = path.read_bytes()
    return raw_files[name]


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    raise EvidenceError('nonfinite_json_number')


def parse(data):
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def load(name):
    value = parse(read(name))
    need(type(value) is dict, 'json_object_required: ' + name)
    return value


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def integer(value, expected=None):
    return type(value) is int and (expected is None or value == expected)


def instant(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.utcoffset() is not None, 'timestamp_without_timezone')
    return result


def check_stream(name, receipt, stream, require_size=True):
    data = read(name)
    need(sha(data) == receipt[stream + '_sha256'], 'stream_hash: ' + name)
    key = stream + '_bytes'
    if key in receipt:
        need(integer(receipt[key], len(data)), 'stream_size: ' + name)
    else:
        need(not require_size, 'missing_stream_size: ' + name)
        missing_recorded_sizes.append(name)
    stream_checks[name] = {'original_sha256': sha(data), 'original_bytes': len(data),
                           'recorded_size_present': key in receipt}
    return data


def check_phase(name, expected_commands, successful):
    receipt = load(name + '/receipt.json')
    need(receipt['phase'] == ('verify' if name == 'verify' else 'prepare'), 'phase_name')
    need(receipt['head'] == HEAD and receipt['tree'] == TREE, 'phase_identity: ' + name)
    state = {'head': HEAD, 'tree': TREE, 'status': ''}
    need(receipt['source_before'] == state, 'source_before: ' + name)
    need(receipt['scheduler_mutations'] is False and
         receipt['whole_process_tree_deadline_enforced'] is False, 'phase_scope: ' + name)
    need((receipt.get('success') is True) == successful, 'phase_success: ' + name)
    if successful:
        need(receipt['source_after'] == state, 'source_after: ' + name)
    need(instant(receipt['finished_utc']) >= instant(receipt['started_utc']), 'phase_time: ' + name)
    commands = receipt['commands']
    need([c['name'] for c in commands] == [c[0] for c in expected_commands], 'command_order: ' + name)
    expected_logs = set()
    previous = instant(receipt['started_utc'])
    for command, (command_name, code, executable, arguments) in zip(commands, expected_commands):
        need(command['settled'] is True and integer(command['exit_code'], code), 'command_exit: ' + name)
        need(integer(command['pid']) and command['pid'] > 0, 'command_pid: ' + name)
        need(command['executable'] == executable and command['arguments'] == arguments,
             'command_arguments: ' + name)
        started = instant(command['started_utc'])
        need(previous <= started <= instant(receipt['finished_utc']), 'command_time: ' + name)
        previous = started
        need(type(command['seconds']) in (int, float) and command['seconds'] >= 0, 'command_duration')
        for stream in ('stdout', 'stderr'):
            filename = command_name + '.' + stream + '.log'
            expected_logs.add(filename)
            data = check_stream(name + '/' + filename, command, stream)
            if stream == 'stderr':
                need(data == b'', 'command_stderr: ' + name)
    need({p.name for p in (ROOT / name).glob('*.log')} == expected_logs, 'unexpected_log: ' + name)
    return receipt


def events(name, count):
    lines = read(name).decode('utf-8-sig').splitlines()
    need(len(lines) == count and all(line.strip() for line in lines), 'event_count: ' + name)
    result = [parse(line.encode('utf-8')) for line in lines]
    need(all(type(event) is dict for event in result), 'event_object: ' + name)
    return result


def check_overall(event, passed):
    expected = {'event': 'overall', 'status': 'PASS' if passed else 'FAIL', 'pass': passed,
                'backend_type': '*scheduler.windowsScheduler' if passed else '',
                'error_category': 'none' if passed else 'invalid_manifest',
                'panic_recovered': False, 'claim': CLAIM,
                'completed_task_exit_qualified': False, 'full_native_qualification': False}
    need(set(event) == set(expected) | {'duration_ns'}, 'overall_keys')
    need(all(type(event[k]) is type(v) and event[k] == v for k, v in expected.items()), 'overall_values')
    need(integer(event['duration_ns']) and event['duration_ns'] >= 0, 'overall_duration')


def validate():
    for name, expected in PINNED.items():
        need(sha(read(name)) == expected, 'pinned_file: ' + name)
    base = [('go-version', 0, 'go.exe', ['version']),
            ('gofmt-check', 0, 'gofmt.exe', ['-l', TARGET])]
    failed = check_phase('prepare', base, False)
    prep = check_phase('prepare-v2', base + [
        ('build', 0, 'go.exe', ['build', '-tags=r17_last_result_native_probe', '-trimpath',
                               '-o', str(ROOT / 'last-result-readonly.exe'), TARGET]),
        ('empty-manifest', 1, 'last-result-readonly.exe', [])], True)
    ps_args = ['-NoProfile', '-NonInteractive', '-Command', '<saved snapshot.ps1>']
    verify = check_phase('verify', [
        ('snapshot-before', 0, 'powershell.exe', ps_args),
        ('public-go-reads', 0, 'last-result-readonly.exe', []),
        ('snapshot-after', 0, 'powershell.exe', ps_args)], True)
    need(read('prepare/gofmt-check.stdout.log').decode('utf-8-sig').splitlines() == [TARGET], 'formatting_stop')
    need(not any(k in failed for k in ('binary_sha256', 'negative_admission_control', 'source_after')),
         'failed_prepare_has_later_evidence')
    for receipt in (failed, prep):
        need(receipt['temporary_source_moved_to_trash'] is True and
             receipt['temporary_source_retained'] is False and receipt['recovery_required'] is False,
             'temporary_source_recovery')
    for name in ('gofmt-check', 'build'):
        need(read('prepare-v2/' + name + '.stdout.log') == b'', 'unexpected_prepare_output')
    need(read('prepare/go-version.stdout.log') == read('prepare-v2/go-version.stdout.log'), 'go_version_changed')
    need(re.fullmatch(rb'go version go[0-9][^\r\n]* windows/amd64\r?\n', read('prepare-v2/go-version.stdout.log'))
         is not None, 'go_version_platform')
    bindings = {'probe_source_sha256': 'probe.go', 'runner_sha256': 'run_probe.py',
                'snapshot_source_sha256': 'snapshot.ps1'}
    for receipt in (prep, verify):
        need(all(receipt[key] == sha(read(name)) for key, name in bindings.items()), 'successful_source_binding')
        need(receipt['binary_sha256'] == receipt['binary_sha256_after'] == PINNED['last-result-readonly.exe'],
             'binary_binding')
    need(failed['probe_source_sha256'] == sha(read('history/probe-unformatted.go')) and
         failed['runner_sha256'] == sha(read('history/run_probe-prepare1.py')) and
         failed['snapshot_source_sha256'] == sha(read('snapshot.ps1')), 'historical_source_binding')
    need(prep['negative_admission_control'] is True, 'negative_admission_receipt')
    check_overall(events('prepare-v2/empty-manifest.stdout.log', 1)[0], False)

    candidate, before, after = [load(name) for name in PRIVATE_FILES[:3]]
    fields = {'head', 'name', 'prefix', 'owner', 'state', 'last_result', 'result_runtime_type',
              'last_run_ticks', 'hidden', 'instance_count', 'xml'}
    for snapshot in (candidate, before, after):
        need(set(snapshot) == fields and snapshot['head'] == HEAD, 'private_snapshot_schema')
        need(all(type(snapshot[k]) is str and snapshot[k].strip()
                 for k in ('name', 'prefix', 'owner', 'result_runtime_type', 'xml')), 'private_snapshot_strings')
        need(not any(c in snapshot['prefix'] for c in '/\\') and
             snapshot['name'] == '\\' + snapshot['prefix'], 'private_snapshot_name')
        need(integer(snapshot['last_result'], VALUE) and integer(snapshot['state'], 3) and
             snapshot['result_runtime_type'] == 'System.Int32' and snapshot['hidden'] is False and
             integer(snapshot['instance_count'], 0), 'private_snapshot_observation')
        need(integer(snapshot['last_run_ticks']) and snapshot['last_run_ticks'] >= 0, 'private_snapshot_time')
    need(candidate == before == after, 'private_snapshots_differ')
    manifest = {k: before[k] for k in ('head', 'name', 'prefix', 'owner', 'state', 'last_result')}
    need(load('verify/manifest-private.json') == manifest, 'private_manifest_binding')
    for phase in ('before', 'after'):
        snapshot = parse(read('verify/snapshot-' + phase + '.stdout.log'))
        expected_matches = {field + '_unchanged': True for field in fields}
        expected_matches['single_visible_prefix_match'] = True
        need(snapshot['phase'] == phase and snapshot['pass'] is True and
             snapshot['matches'] == expected_matches and
             all(value is True for value in snapshot['matches'].values()) and
             integer(snapshot['last_result'], VALUE) and integer(snapshot['state'], 3) and
             integer(snapshot['visible_instances'], 0) and snapshot['scheduler_changes'] is False,
             'public_snapshot_result')
    public = events('verify/public-go-reads.stdout.log', 5)
    for offset, check in ((0, 'status'), (2, 'list')):
        need(public[offset] == {'event': 'begin', 'check': check}, 'public_begin')
        result = public[offset + 1]
        need(set(result) == {'event', 'check', 'pass', 'duration_ns', 'error_category',
                             'observed_last_result', 'observed_last_result_type'}, 'public_result_keys')
        need(result['event'] == 'result' and result['check'] == check and result['pass'] is True and
             result['error_category'] == 'none' and integer(result['observed_last_result'], VALUE) and
             result['observed_last_result_type'] == 'int' and integer(result['duration_ns']) and
             result['duration_ns'] >= 0, 'public_result_values')
    check_overall(public[-1], True)
    need(verify['stable_private_snapshots'] is True and verify['public_reads_passed'] is True and
         integer(verify['last_result_observed'], VALUE) and verify['completed_action_exit_qualified'] is False and
         verify['atomic_snapshot_claimed'] is False, 'verification_receipt_claims')

    observation = load('observation-receipt.json')
    start = load('observation-start.json')
    need(integer(observation['exit_code'], 0) and observation['settled'] is True and
         observation['scheduler_changes'] is False, 'observation_exit')
    observation_stdout = check_stream('observation.stdout.log', observation, 'stdout', False)
    need(check_stream('observation.stderr.log', observation, 'stderr', False) == b'', 'observation_stderr')
    observed = parse(observation_stdout)
    need(observed == observation['summary'], 'observation_summary_binding')
    need(observed['mode'] == 'READ_ONLY_CANDIDATE_OBSERVATION' and observed['selected'] is True and
         observed['scheduler_changes'] is False and integer(observed['query_failures'], 0) and
         integer(observed['queried_visible_root_tasks'], 16) and integer(observed['current_account_visible_tasks'], 14) and
         integer(observed['eligible_nonzero_idle_tasks'], 7) and integer(observed['last_result'], VALUE) and
         integer(observed['state'], 3) and observed['result_runtime_type'] == 'System.Int32' and
         observed['scope'] == 'visible root tasks under the current account; instances visible to this security context',
         'observation_values')
    need(start['started_utc'] == observation['started_utc'] and integer(start['pid']) and start['pid'] > 0 and
         start['source_sha256'] == sha(read('observe_candidates.ps1')), 'observation_source_binding')

    post = load('post-verify/receipt.json')
    need(post['phase'] == 'post-verify' and integer(post['exit_code'], 0) and post['settled'] is True and
         post.get('timed_out', False) is False and post['scoped_absence_observed'] is True and
         post['whole_process_tree_proven'] is False, 'post_verify_exit')
    post_stdout = check_stream('post-verify/stdout.log', post, 'stdout', False)
    need(check_stream('post-verify/stderr.log', post, 'stderr', False) == b'', 'post_verify_stderr')
    processes = parse(post_stdout)
    need(integer(post['pid']) and post['pid'] > 0 and
         processes == post['observation'] and type(processes['remaining']) is list and
         processes['remaining'] == [] and integer(processes['observer_pid']) and
         processes['observer_pid'] == post['pid'] and processes['scope'] == PROCESS_SCOPE,
         'post_verify_scoped_absence')
    need(type(processes['excluded_pids']) is list and len(processes['excluded_pids']) == 3 and
         all(integer(pid) and pid > 0 for pid in processes['excluded_pids']) and
         processes['excluded_pids'][0] == post['pid'], 'post_verify_exclusions')
    need(post['script_sha256'] == sha(read('observe_owned_processes.py')), 'post_verify_source_binding')
    need(instant(observation['started_utc']) < instant(failed['started_utc']) <= instant(failed['finished_utc']) <
         instant(prep['started_utc']) <= instant(prep['finished_utc']) < instant(verify['started_utc']) <=
         instant(verify['finished_utc']) <= instant(post['started_utc']) <= instant(processes['observed_utc']) <=
         instant(post['finished_utc']), 'phase_chronology')
    return candidate, public, observed, processes


def redactor(candidate):
    private = {candidate['name'], candidate['prefix'], candidate['owner']}
    private.update(value for key in ('USERNAME', 'USERDOMAIN', 'COMPUTERNAME')
                   if (value := os.environ.get(key)))
    private.update(part for part in candidate['owner'].split('\\') if part)
    replacements = [(str(ROOT), '<WORK_ROOT>'), (SOURCE, '<SOURCE_ROOT>'),
                    (r'<GO_CACHE_ROOT>', '<GO_CACHE_ROOT>'),
                    (r'<GO_ROOT>', '<GO_ROOT>'),
                    (r'<GO_BIN>', '<GO_BIN>'),
                    (r'<GIT_EXECUTABLE>', '<GIT_EXECUTABLE>'),
                    (r'<OWNED_WORK_ROOT>', '<OWNED_WORK_ROOT>')]
    replacements.extend((value, '<MACHINE_DIRECTORY>') for key in ('USERPROFILE', 'SYSTEMROOT', 'WINDIR')
                        if (value := os.environ.get(key)))
    replacements.sort(key=lambda pair: len(pair[0]), reverse=True)

    def variants(value):
        return {value, value.replace('\\', '/'), value.replace('\\', '\\\\'),
                json.dumps(value, ensure_ascii=True)[1:-1]}

    identity_patterns = [r'(?<!\w)' + re.escape(value) + r'(?!\w)'
                         for old in sorted(private, key=len, reverse=True)
                         for value in sorted(variants(old), key=len, reverse=True)]
    index = 0
    placeholder = '<REDACTED_0>'
    while any(re.search(pattern, placeholder, re.I) for pattern in identity_patterns):
        index += 1
        placeholder = '<REDACTED_' + str(index) + '>'

    def text(value):
        for old, replacement in replacements:
            for pattern in sorted(variants(old), key=len, reverse=True):
                value = re.sub(re.escape(pattern), lambda _: replacement, value, flags=re.I)
        for pattern in identity_patterns:
            value = re.sub(pattern, lambda _: placeholder, value, flags=re.I)
        return re.sub(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', '<USER_SID>', value)

    def obj(value):
        if isinstance(value, str):
            return text(value)
        if isinstance(value, list):
            return [obj(item) for item in value]
        if isinstance(value, dict):
            return {text(key): obj(item) for key, item in value.items()}
        return value

    def saved(name, data):
        if name.endswith('.json'):
            return json_bytes(obj(parse(data)))
        return text(data.decode('utf-8-sig')).encode('utf-8')

    def scan(data):
        value = data.decode('utf-8')
        need(not any(re.search(pattern, value, flags=re.I) for pattern in identity_patterns),
             'private_value_remains')
        need(candidate['xml'] not in value, 'private_xml_remains')
        need(not re.search(r'<(?:\?xml\b|Task\b|RegistrationInfo\b|Principals\b|Actions\b)', value, re.I),
             'xml_content_remains')
        need(not re.search(r'\b[A-Za-z]:[\\/]+', value), 'machine_path_remains')
        unc = re.escape(chr(92) * 2) + r'[^\\/\s\"\']+[\\/]'
        need(not re.search(unc, value), 'unc_path_remains')
        for pattern in (
            rb'\bgh[pousr]_[A-Za-z0-9]{16,}', rb'\bgithub_pat_[A-Za-z0-9_]{16,}',
            rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}', rb'\bxox[baprs]-[A-Za-z0-9-]{16,}',
            rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}', rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
            rb'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
            rb'(?i)\b(?:password|api[_-]?key|access[_-]?token|client[_-]?secret)[\"\']?\s*[:=]\s*[\"\'][^\"\'\s]{12,}[\"\']',
        ):
            need(re.search(pattern, data) is None, 'credential_shaped_content')
    return saved, scan


def main():
    need(not any((ROOT / name).exists() for name in OUTPUTS), 'output_already_exists')
    candidate, public, observation, processes = validate()
    saved, scan = redactor(candidate)
    included = set(SOURCES) | set(stream_checks) | {
        'prepare/receipt.json', 'prepare-v2/receipt.json', 'verify/receipt.json',
        'observation-receipt.json', 'observation-start.json', 'post-verify/receipt.json',
    }
    need(not (included & set(PRIVATE_FILES)) and not any(name.endswith('.exe') for name in included),
         'forbidden_archive_member')
    summary = {
        'schema': 1, 'validation': 'PASS', 'mode': 'saved_files_only', 'head': HEAD, 'tree': TREE,
        'verified_utc': datetime.now(timezone.utc).isoformat(), 'claim': CLAIM,
        'source_sha256': {name: sha(read(name)) for name in SOURCES},
        'binary_sha256': PINNED['last-result-readonly.exe'],
        'all_recorded_direct_children_settled': True, 'stream_checks': stream_checks,
        'stream_sizes_absent_from_original_receipts': sorted(missing_recorded_sizes),
        'source_before_after_clean_in_both_successful_receipts': True,
        'first_prepare': {'outcome': 'stopped_on_nonempty_gofmt_listing',
                          'build_or_probe_command_recorded': False,
                          'temporary_source_moved_to_trash': True, 'recovery_required': False},
        'negative_empty_manifest_admission': 'PASS', 'private_snapshots_fully_equal': True,
        'private_manifest_matches_snapshot': True,
        'native_observation': {'last_result': VALUE, 'hex': '0x41303', 'result_runtime_type': 'System.Int32',
                               'state': 3, 'hidden': False, 'visible_instances': 0},
        'candidate_counts': {k: observation[k] for k in ('queried_visible_root_tasks',
                            'current_account_visible_tasks', 'eligible_nonzero_idle_tasks', 'query_failures')},
        'public_events': public,
        'post_verify': {'scoped_absence_observed': True, 'remaining': 0, 'scope': PROCESS_SCOPE,
                        'observed_utc': processes['observed_utc']},
        'scheduler_mutations': False, 'packager_native_calls': False,
        'completed_action_exit_qualified': False, 'full_native_qualification': False,
        'atomic_snapshot_claimed': False, 'whole_process_tree_proven': False,
        'whole_process_tree_deadline_enforced': False,
        'limitations': [
            'Only transfer of the observed nonzero native value through Status and List is qualified.',
            'Instance counts cover the current security context; equal snapshots do not prove atomic isolation.',
            'Process absence is scoped to a work-root marker, not an ancestry-complete process tree.',
            'Source head/tree/status are verified from saved receipts; this packager performs no Git operation.',
            'The original observation source hash is a post-launch reread digest, not a capture-bound hash or race protection.',
            'Recorded stream sizes are checked where present; missing historical sizes are computed now and listed separately.',
        ],
    }
    originals = {name: read(name) for name in included}
    originals['execution-summary.json'] = json_bytes(summary)
    members = {}
    manifest = {'schema': 1, 'head': HEAD, 'tree': TREE, 'files': [],
                'redaction': 'Private values and machine paths replaced; scripts are review copies. Receipt hashes describe original streams; saved hashes describe archive bytes. Private JSON and the binary are excluded.'}
    for name in sorted(originals):
        original = originals[name]
        data = saved(name, original)
        scan(data)
        members[name] = data
        manifest['files'].append({'path': name, 'origin': 'generated' if name == 'execution-summary.json' else 'saved_evidence',
                                  'original_sha256': sha(original), 'original_bytes': len(original),
                                  'saved_sha256': sha(data), 'saved_bytes': len(data)})
    members['MANIFEST.json'] = json_bytes(manifest)
    scan(members['MANIFEST.json'])
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    archive_data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
        need(archive.namelist() == list(members), 'archive_members_changed')
        for name, data in members.items():
            need(archive.read(name) == data, 'archive_bytes_changed')
    encoded = base64.b64encode(archive_data).decode('ascii')
    chunks = ('\n'.join(encoded[i:i + 4096] for i in range(0, len(encoded), 4096)) + '\n').encode('ascii')
    metadata = {'head': HEAD, 'tree': TREE, 'archive_file': 'evidence-redacted.zip',
                'archive_sha256': sha(archive_data), 'archive_bytes': len(archive_data),
                'manifest_files': len(manifest['files']), 'archive_members': len(members),
                'base64_file': 'evidence-redacted.base64.txt', 'base64_sha256': sha(chunks),
                'base64_bytes': len(chunks), 'base64_lines': len(chunks.splitlines()), 'base64_chunk_characters': 4096,
                'manifest_sha256': sha(members['MANIFEST.json']),
                'summary_sha256': sha(members['execution-summary.json']), 'credential_shape_scan': 'PASS'}
    metadata_data = json_bytes(metadata)
    scan(metadata_data)
    outputs = {'execution-summary.json': members['execution-summary.json'], 'evidence-redacted.zip': archive_data,
               'archive-metadata.json': metadata_data, 'evidence-redacted.base64.txt': chunks}
    for name, data in outputs.items():
        with (ROOT / name).open('xb') as output:
            output.write(data)
    print(json.dumps(metadata), flush=True)


if __name__ == '__main__':
    try:
        main()
    except EvidenceError as error:
        print(json.dumps({'packaged': False, 'error_category': 'evidence_validation', 'detail': str(error)}), flush=True)
        raise SystemExit(1)
    except Exception as error:
        print(json.dumps({'packaged': False, 'error_category': type(error).__name__}), flush=True)
        raise SystemExit(1)
