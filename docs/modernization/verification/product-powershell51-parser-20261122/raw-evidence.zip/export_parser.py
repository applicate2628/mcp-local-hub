"""Export only the settled parser qualification files without changing them."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-product-encoding-20261122-e51f")
FILES = [
    "inputs/published-477f/build.ps1", "inputs/candidate/build.ps1",
    "inputs/composition/build.ps1", "qualification/test-product-script-parser.ps1",
    "qualify_parser.py", "export_parser.py", "evidence/receipt.json",
]
for label in ("policy-before", "published-control", "publication-candidate", "current-source-composition", "policy-after"):
    FILES.extend("evidence/" + label + "." + stream for stream in ("stdout", "stderr"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if os.name != "nt" or len(sys.argv) != 1 or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Use the owned exporter without extra arguments")
    receipt = json.loads((ROOT / "evidence/receipt.json").read_bytes())
    if receipt.get("completed") is not True or len(receipt.get("commands", [])) != 5:
        raise RuntimeError("Qualification did not complete")
    for row in receipt["commands"]:
        if row.get("direct_child_waited") is not True or row.get("timed_out") is not False:
            raise RuntimeError("A direct child remains unresolved")
    payload = {}
    for name in FILES:
        path = ROOT / name
        current = ROOT
        for part in (None, *path.relative_to(ROOT).parts):
            if part is not None:
                current /= part
            info = current.lstat()
            if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Unexpected export reparse point")
        payload[name] = path.read_bytes()
    for name, expected in receipt["inputs_after"].items():
        if sha(payload[name]) != expected:
            raise RuntimeError("Qualification input changed before export")
    if sha(payload["qualify_parser.py"]) != receipt["runner_sha256"]:
        raise RuntimeError("Runner changed before export")
    for row in receipt["commands"]:
        for stream in ("stdout", "stderr"):
            data = payload["evidence/" + row["label"] + "." + stream]
            if len(data) != row[stream]["bytes"] or sha(data) != row[stream]["sha256"]:
                raise RuntimeError("Command stream changed before export")
    inventory = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(payload.items())}
    payload["inventory.json"] = (json.dumps(inventory, indent=2) + "\n").encode()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payload.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    raw = buffer.getvalue()
    encoded = base64.b64encode(raw).decode()
    text = "BASE64_START\n" + "\n".join(encoded[i:i+160] for i in range(0, len(encoded), 160)) + "\nBASE64_END\n"
    with (ROOT / "export-base64.txt").open("x", encoding="ascii", newline="\n") as stream:
        stream.write(text)
    metadata = {"archive_bytes": len(raw), "archive_sha256": sha(raw),
                "indexed_files": len(inventory), "archive_files": len(payload),
                "base64_chars": len(encoded), "exporter_sha256": sha(Path(__file__).read_bytes())}
    with (ROOT / "export-metadata.json").open("x", encoding="ascii", newline="\n") as stream:
        json.dump(metadata, stream, indent=2)
        stream.write("\n")
    print(json.dumps(metadata), flush=True)


if __name__ == "__main__":
    main()
