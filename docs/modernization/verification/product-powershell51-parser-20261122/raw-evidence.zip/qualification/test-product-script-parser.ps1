#Requires -Version 5.1
param(
    [Parameter(Mandatory = $true)][string]$BuildScript,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-f]{64}$')][string]$ExpectedSHA256
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)

function Get-BytesSHA256([byte[]]$Bytes) {
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($hasher.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
    }
}

if ($PSVersionTable.PSEdition -ne 'Desktop' -or
    $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'This qualification requires native Windows PowerShell 5.1.'
}
$path = [IO.Path]::GetFullPath($BuildScript)
$before = [IO.File]::ReadAllBytes($path)
$sourceSHA256 = Get-BytesSHA256 $before
if ($sourceSHA256 -cne $ExpectedSHA256) { throw 'Source SHA-256 differs from the admitted input.' }

# ParseFile chooses the native file encoding. Never decode or invoke the source.
$tokens = $null
$parseErrors = $null
$null = [System.Management.Automation.Language.Parser]::ParseFile(
    $path, [ref]$tokens, [ref]$parseErrors)
$errorRows = @($parseErrors | ForEach-Object {
    [pscustomobject][ordered]@{
        id = $_.ErrorId
        message = $_.Message
        start_line = $_.Extent.StartLineNumber
        start_column = $_.Extent.StartColumnNumber
        end_line = $_.Extent.EndLineNumber
        end_column = $_.Extent.EndColumnNumber
    }
})
$sourceAfter = Get-BytesSHA256 ([IO.File]::ReadAllBytes($path))
if ($sourceAfter -cne $sourceSHA256) { throw 'Source changed while parsed.' }

[pscustomobject][ordered]@{
    schema = 'product-native-parser-qualification-v1'
    parser = 'System.Management.Automation.Language.Parser.ParseFile'
    source_path = $path
    source_sha256 = $sourceSHA256
    source_sha256_after = $sourceAfter
    source_bytes = $before.Length
    utf8_bom = ($before.Length -ge 3 -and $before[0] -eq 239 -and $before[1] -eq 187 -and $before[2] -eq 191)
    powershell_version = $PSVersionTable.PSVersion.ToString()
    powershell_edition = $PSVersionTable.PSEdition
    default_code_page = [Text.Encoding]::Default.CodePage
    culture = [Globalization.CultureInfo]::CurrentCulture.Name
    culture_ansi_code_page = [Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage
    parser_error_count = $errorRows.Count
    parser_error_ids = @($errorRows | ForEach-Object { $_.id })
    parser_errors = $errorRows
    source_executed = $false
} | ConvertTo-Json -Compress -Depth 5

if ($errorRows.Count -ne 0) { exit 1 }
exit 0
