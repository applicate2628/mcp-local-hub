"""Run only the approved native file parser cases in a fresh owned D root."""
import sys
sys.dont_write_bytecode = True
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-product-encoding-20261122-e51f")
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
PS_SHA = "95ce2acbc6cd9d7f4a22759d39a8d40fc2a53ceeecf068ef856849f0d2076961"
BUNDLE_SHA = "4299f749b53c2b21b087cf2e34ddfbbde28d60eff75652248c12e0d901870245"
HARNESS = "qualification/test-product-script-parser.ps1"
FILES = {
    "inputs/published-477f/build.ps1": "bc55dd0815e95c6dc5a19513f07e6a8b5eab636382a16e9940e28b209dd1b8f2",
    "inputs/candidate/build.ps1": "b52b2676ce02d61d6549091c224dfb65c7bbf747ee1698094a3e1a266c474d90",
    "inputs/composition/build.ps1": "e811e4549672ec4cc3ea72e59b3fa6f0235191137e41007a3600edf0f6354fa8",
    HARNESS: "5312338621f991d12adb56ba0dcfca6bd5fd7ca479358a034fb4a84b30ba5def",
}
CASES = (
    ("published-control", "inputs/published-477f/build.ps1", 1),
    ("publication-candidate", "inputs/candidate/build.ps1", 0),
    ("current-source-composition", "inputs/composition/build.ps1", 0),
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe(path):
    path.relative_to(ROOT)
    current = Path(r"D:\dev")
    for part in (None, "ChatGPT", ROOT.name, *path.relative_to(ROOT).parts):
        if part is not None:
            current = current / part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if current.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse point in owned path: " + str(current))
    return path


def input_hashes():
    result = {}
    for name, expected in FILES.items():
        path = safe(ROOT / name)
        if not stat.S_ISREG(path.lstat().st_mode):
            raise RuntimeError("Input is not a regular file: " + name)
        actual = sha(path.read_bytes())
        if actual != expected:
            raise RuntimeError("Input differs: " + name)
        result[name] = actual
    return result


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 1 or Path(__file__).resolve().parent != ROOT:
        raise RuntimeError("Use the owned Windows runner without extra arguments")
    safe(ROOT)
    if set(p.name for p in ROOT.iterdir()) != {"qualify_parser.py", "transport-inputs.json.zlib.b64"}:
        raise RuntimeError("The prepared root is not fresh")
    raw = safe(ROOT / "transport-inputs.json.zlib.b64").read_bytes()
    if sha(raw) != BUNDLE_SHA:
        raise RuntimeError("Input transport differs")
    payload = json.loads(zlib.decompress(base64.b64decode(raw, validate=True)))
    if payload.get("schema") != 1 or set(payload.get("files", {})) != set(FILES):
        raise RuntimeError("Unexpected transport members")
    admitted = {}
    for name, expected in FILES.items():
        row = payload["files"][name]
        data = base64.b64decode(row["content_b64"], validate=True)
        if row["sha256"] != expected or len(data) != row["bytes"] or sha(data) != expected:
            raise RuntimeError("Transport member differs: " + name)
        admitted[name] = data
    for name, data in admitted.items():
        path = safe(ROOT / name)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(data)
    evidence = safe(ROOT / "evidence")
    evidence.mkdir(exist_ok=False)
    runtime = safe(ROOT / "runtime")
    runtime.mkdir(exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata"):
        (runtime / name).mkdir()
    env = {k.upper(): v for k, v in os.environ.items()
           if not k.upper().startswith(("MCPHUB_", "GIT_"))}
    env.update({
        "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
        "LOCALAPPDATA": str(runtime / "localappdata"), "PYTHONDONTWRITEBYTECODE": "1",
        "PSMODULEPATH": str(PS.parent / "Modules"),
        "PSMODULEANALYSISCACHEPATH": str(runtime / "localappdata/module-analysis.cache"),
    })
    receipt = {
        "schema": 1, "phase": "native-product-script-parser", "started_utc": now(),
        "source_parent": "477f6e3f66eca482e2267351af3535c62db8ebb2",
        "runner_sha256": sha(Path(__file__).read_bytes()), "input_transport_sha256": BUNDLE_SHA,
        "python_version": sys.version, "commands": [], "cases": {}, "completed": False,
        "environment": {k: env[k] for k in ("TEMP", "TMP", "TMPDIR", "USERPROFILE", "APPDATA",
                         "LOCALAPPDATA", "PSMODULEPATH", "PSMODULEANALYSISCACHEPATH", "PYTHONDONTWRITEBYTECODE")},
        "boundary": "Native Parser.ParseFile only; no builder, Go, Node, Product, installation, or Scheduler execution",
        "whole_process_tree_settlement_observed": False,
    }

    def save():
        (evidence / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")

    def run(label, arguments, expected):
        row = {"label": label, "argv": list(map(str, arguments)), "expected_exit": expected,
               "started_utc": now(), "timeout_seconds": 30, "direct_child_waited": False, "timed_out": False}
        receipt["commands"].append(row)
        save()
        child = None
        started = time.monotonic()
        stdout_path, stderr_path = evidence / (label + ".stdout"), evidence / (label + ".stderr")
        try:
            with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
                child = subprocess.Popen(row["argv"], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                         stdout=stdout, stderr=stderr)
                row["pid"] = child.pid
                try:
                    row["exit_code"] = child.wait(timeout=30)
                    row["direct_child_waited"] = True
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    raise
        finally:
            if child is not None and not row["direct_child_waited"]:
                row.update(process_tree_unresolved=True, retain_runtime_and_logs=True)
                try:
                    child.terminate()
                    row["exit_code"] = child.wait(timeout=10)
                    row["direct_child_waited"] = True
                except BaseException as error:
                    row["termination_error"] = type(error).__name__ + ": " + str(error)
            row.update(seconds=round(time.monotonic() - started, 3), finished_utc=now())
            for name, path in (("stdout", stdout_path), ("stderr", stderr_path)):
                if path.exists():
                    data = path.read_bytes()
                    row[name] = {"bytes": len(data), "sha256": sha(data)}
            save()
        if row.get("exit_code") != expected or row["timed_out"] or stderr_path.stat().st_size:
            raise RuntimeError("Unexpected process result: " + label)
        rows = [json.loads(line) for line in stdout_path.read_bytes().decode("utf-8-sig").splitlines() if line.strip()]
        if len(rows) != 1:
            raise RuntimeError("Expected exactly one structured result: " + label)
        print(json.dumps({"label": label, "exit_code": row["exit_code"]}), flush=True)
        return rows[0]

    policy = "$ErrorActionPreference='Stop'; [pscustomobject]@{version=$PSVersionTable.PSVersion.ToString(); edition=$PSVersionTable.PSEdition; code_page=[Text.Encoding]::Default.CodePage; effective=(Get-ExecutionPolicy).ToString(); scopes=@(Get-ExecutionPolicy -List | ForEach-Object {[pscustomobject]@{scope=$_.Scope.ToString(); policy=$_.ExecutionPolicy.ToString()}})} | ConvertTo-Json -Compress -Depth 4"
    try:
        receipt["inputs_before"] = input_hashes()
        receipt["powershell_sha256_before"] = sha(PS.read_bytes())
        if receipt["powershell_sha256_before"] != PS_SHA:
            raise RuntimeError("Installed PowerShell differs")
        receipt["policy_before"] = run("policy-before", [PS, "-NoProfile", "-NonInteractive", "-Command", policy], 0)
        initial = receipt["policy_before"]
        if initial["effective"] != "Unrestricted" or initial["edition"] != "Desktop" or not initial["version"].startswith("5.1.") or initial["code_page"] != 1251:
            raise RuntimeError("Native PowerShell policy/version/code page differs from the admitted host")
        for label, path, expected in CASES:
            row = run(label, [PS, "-NoProfile", "-NonInteractive", "-File", ROOT / HARNESS,
                             "-BuildScript", ROOT / path, "-ExpectedSHA256", FILES[path]], expected)
            count = row.get("parser_error_count")
            if row.get("schema") != "product-native-parser-qualification-v1" or row.get("parser") != "System.Management.Automation.Language.Parser.ParseFile":
                raise RuntimeError("Unexpected parser result schema: " + label)
            if row.get("source_sha256") != FILES[path] or row.get("source_sha256_after") != FILES[path] or row.get("source_bytes") != len(admitted[path]):
                raise RuntimeError("Parsed source identity differs: " + label)
            if row.get("source_executed") is not False or row.get("utf8_bom") is not False or row.get("powershell_edition") != "Desktop" or row.get("powershell_version") != initial["version"] or row.get("default_code_page") != 1251:
                raise RuntimeError("Parser environment/boundary differs: " + label)
            if type(count) is not int or count != len(row.get("parser_errors", [])) or count != len(row.get("parser_error_ids", [])) or ((count > 0) != (expected == 1)):
                raise RuntimeError("Parser regression oracle differs: " + label)
            if [error["id"] for error in row["parser_errors"]] != row["parser_error_ids"]:
                raise RuntimeError("Parser error identifiers differ: " + label)
            receipt["cases"][label] = row
        receipt["policy_after"] = run("policy-after", [PS, "-NoProfile", "-NonInteractive", "-Command", policy], 0)
        if receipt["policy_after"] != receipt["policy_before"]:
            raise RuntimeError("Execution policy or native parser environment changed")
        receipt["powershell_sha256_after"] = sha(PS.read_bytes())
        if receipt["powershell_sha256_after"] != PS_SHA:
            raise RuntimeError("PowerShell image changed")
        receipt["inputs_after"] = input_hashes()
        if sha(Path(__file__).read_bytes()) != receipt["runner_sha256"]:
            raise RuntimeError("Qualification runner changed")
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        if "inputs_after" not in receipt:
            try:
                receipt["inputs_after"] = input_hashes()
            except BaseException as error:
                receipt["inputs_after_error"] = type(error).__name__ + ": " + str(error)
        receipt["finished_utc"] = now()
        save()
        print(json.dumps({"completed": receipt["completed"], "error": receipt.get("error"),
                          "case_error_counts": {k: v["parser_error_count"] for k, v in receipt["cases"].items()}}), flush=True)


if __name__ == "__main__":
    main()
