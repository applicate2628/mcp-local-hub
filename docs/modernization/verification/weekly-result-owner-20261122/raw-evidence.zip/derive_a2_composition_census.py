"""Bind the qualification-only 30-owner census to the exact 3309-file composition."""
from pathlib import Path, PureWindowsPath
import hashlib,json
ROOT=Path(__file__).resolve().parent
REMOTE=PureWindowsPath(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
def sha(x):return hashlib.sha256(x).hexdigest()
def write(rel,raw):
    with (ROOT/rel).open('xb') as f:f.write(raw)
    print(json.dumps({'path':rel,'bytes':len(raw),'sha256':sha(raw)}))
old=ROOT/'plans/a2-owner-census-formatted.json'
assert sha(old.read_bytes())=='a39aca0b450262f853da76e3c92d880df915a447d274872ebe297593b193c8a2'
p=json.loads(old.read_bytes())
census='inputs/a2-composition/internal/api/supervisor_intent_lock_ownership_test.go'
assert sha((ROOT/census).read_bytes())=='d5b22597fc78a9304ac9c630adb759932cd430afae7568e241a5812eff853e47'
ov=json.loads((ROOT/'inputs/a2-v3-green-overlay.json').read_bytes())
target=str(REMOTE/'candidate-source/internal/api/supervisor_intent_lock_ownership_test.go')
assert ov['Replace'][target]==str(REMOTE/'inputs/a2-v3/internal/api/supervisor_intent_lock_ownership_test.go')
ov['Replace'][target]=str(REMOTE/census)
overlay='inputs/a2-composition-green-overlay.json'
write(overlay,(json.dumps(ov,indent=2)+'\n').encode())
inputs=list(p['input_files'])
for rel in [census,overlay]:
    raw=(ROOT/rel).read_bytes()
    inputs.append({'path':rel[len('inputs/'):],'bytes':len(raw),'sha256':sha(raw)})
commands=p['commands']
commands[0]['label']='a2-composition-owner-census'
for c in commands:
    i=c['args'].index('-overlay')+1
    assert c['args'][i]==str(REMOTE/'inputs/a2-v3-green-overlay.json')
    c['args'][i]=str(REMOTE/overlay)
p.update(phase='a2-composition-census',input_files=inputs,commands=commands)
write('plans/a2-composition-census.json',(json.dumps(p,indent=2)+'\n').encode())
