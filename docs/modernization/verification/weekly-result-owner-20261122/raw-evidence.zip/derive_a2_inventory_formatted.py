"""Derive the exact owner-census plan from immutable earlier input inventories."""
from pathlib import Path, PureWindowsPath
import hashlib
import json
ROOT=Path(__file__).resolve().parent
REMOTE=PureWindowsPath(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
assert ROOT==Path(str(REMOTE))
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):
 data=(json.dumps(value,indent=2)+'\n').encode()
 assert sha(data)=='a39aca0b450262f853da76e3c92d880df915a447d274872ebe297593b193c8a2'
 with (ROOT/path).open('xb') as f:f.write(data)
 print(json.dumps({'created':path,'sha256':sha(data)}))
path='inputs/a2-v3/internal/api/supervisor_intent_lock_ownership_test.go'
assert sha((ROOT/path).read_bytes())=='9a418e22322e1cdd1d0f6b5f0e111efcf2067c18a3f47f214a859f8eb3b9fad8'
assert sha((ROOT/'plans/a2-route-fixture.json').read_bytes())=='cf496f002fee18190cb6319edf4971a139a7d302a9daa5e550ac7107bfc289c4'
previous=json.loads((ROOT/'plans/a2-route-fixture.json').read_bytes())
inputs=list(previous['input_files'])
for rel in [path,'inputs/a2-v3-green-overlay.json']:
 raw=(ROOT/rel).read_bytes();inputs.append({'path':rel[len('inputs/'):],'bytes':len(raw),'sha256':sha(raw)})
roots=['TestSupervisorIntentLockOwnershipProductionInventory','TestSupervisorIntentLockOwnershipFixtureMatrix','TestAppliedReleaseClassifierFixtureRejectsSibling','TestWeeklyRefreshReleaseSettlementMatrix','TestWeeklyScheduleSettingsReleaseSettlementMatrix','TestReleaseAndJoinAppliedSettlementMatrix']
overlay=str(REMOTE/'inputs/a2-v3-green-overlay.json')
commands=[{'label':'a2-owner-census-and-adjacent','tool':'go','args':['test','-tags=test_state_path_env','-race','-count=1','-timeout=180s','-json','-overlay',overlay,'-run','^('+'|'.join(roots)+')$','./internal/api'],'timeout_seconds':240,'expected_exit_code':0,'required_tests':{'pass':roots+['PACKAGE:mcp-local-hub/internal/api']}}]
for verb in ['build','vet']:
 commands.append({'label':'a2-full-'+verb,'tool':'go','args':[verb,'-overlay',overlay,'./...'],'timeout_seconds':600,'expected_exit_code':0})
save('plans/a2-owner-census-formatted.json',{**previous,'phase':'a2-owner-census','input_files':inputs,'commands':commands})
