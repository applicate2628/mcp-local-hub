"""Derive a new plan from frozen inputs; never change the earlier receipt."""
from pathlib import Path, PureWindowsPath
import hashlib
import json
ROOT=Path(__file__).resolve().parent
REMOTE=PureWindowsPath(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
assert ROOT==Path(str(REMOTE))
def sha(data): return hashlib.sha256(data).hexdigest()
raw=(ROOT/'plans/a2-applied-result.json').read_bytes()
assert sha(raw)=='8d72c4162b65701a711bc481383452820ffac83e325b04a8be35491fdf9c2648'
previous=json.loads(raw)
inputs=list(previous['input_files'])
for rel in ['inputs/a2-v2/internal/gui/weekly_schedule_applied_result_test.go','inputs/a2-v2-green-overlay.json','inputs/a2-v2-red-overlay.json']:
    data=(ROOT/rel).read_bytes();inputs.append({'path':rel[len('inputs/'):],'bytes':len(data),'sha256':sha(data)})
commands=[]
for old,label,overlay in [(previous['commands'][1],'a2-gui-corrected-old-owner','a2-v2-red'),(previous['commands'][3],'a2-gui-corrected-result','a2-v2-green')]:
    cmd=json.loads(json.dumps(old));cmd['label']=label;args=cmd['args']
    if '-overlay' in args:
        index=args.index('-overlay');args[index+1]=str(REMOTE/'inputs'/f'{overlay}-overlay.json')
    else:
        index=args.index('-run');args[index:index]=['-overlay',str(REMOTE/'inputs'/f'{overlay}-overlay.json')]
    commands.append(cmd)
commands.append(previous['commands'][4])
plan={**previous,'phase':'a2-route-fixture','input_files':inputs,'commands':commands}
data=(json.dumps(plan,indent=2)+'\n').encode()
assert sha(data)=='cf496f002fee18190cb6319edf4971a139a7d302a9daa5e550ac7107bfc289c4'
with (ROOT/'plans/a2-route-fixture.json').open('xb') as f:f.write(data)
print(json.dumps({'created':'plans/a2-route-fixture.json','sha256':sha(data)}))
