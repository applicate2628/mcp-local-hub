"""Recover reviewed manifest inputs from the verified preceding archive."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import json
from pathlib import Path
import zipfile
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
assert Path(__file__).resolve().parent == ROOT
archive = ROOT / "previous-archive.zip"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == "858912769a69d45fd6fdd8e422ed169fd7bbc69c9a125e7fab8c2a0fe584bd29"
with zipfile.ZipFile(archive) as z:
    entries = {
        "previous-materialization.json": "plans/materialize-weekly.json",
        "baseline/internal/api/weekly_refresh_atomic_test.go": "inputs/weekly-candidate/internal/api/weekly_refresh_atomic_test.go",
        "baseline/internal/api/weekly_refresh.go": "inputs/weekly-candidate/internal/api/weekly_refresh.go",
    }
    for target, source in entries.items():
        path = ROOT / target
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(z.read(source))
for group, digest in {
    "a1": "74e65a1e1f5bb6c76975c2c904360b2505c56633002dcacb0295856327784e76",
    "a2": "0363f4f2ec8e2935f291eeab8684e55c5f2ce5953aaa5f06fdfc51a1a7fd7f27",
}.items():
    payload = (ROOT / ("format-" + group + "-formatted.b64")).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == digest
    rows = json.loads(zlib.decompress(base64.b64decode(payload, validate=True)))
    records = [{k: v for k, v in row.items() if k != "base64"} for row in rows]
    with (ROOT / (group + "-inputs-formatted.json")).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(records, stream, indent=2)
        stream.write("\n")
print(json.dumps({"archive_inputs_prepared": True, "formatted_groups": 2}), flush=True)
