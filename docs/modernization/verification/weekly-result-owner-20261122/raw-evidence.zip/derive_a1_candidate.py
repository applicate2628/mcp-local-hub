import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib
root=Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
raw=(root/'plans/a1-origin-proof.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='5771058018c43ca43d66b765ef1ef5840f2565b897c568ac132da0cb965fd5c9'
p=json.loads(raw);p['phase']='a1-candidate-proof';p['commands']=p['commands'][1:]
raw=(json.dumps(p,indent=2)+'\n').encode()
with (root/'plans/a1-candidate-proof.json').open('xb') as f:f.write(raw)
print(hashlib.sha256(raw).hexdigest(),flush=True)
