"""Build exact A1/A2 physical-source and test-input inventories locally."""
from pathlib import Path, PureWindowsPath
import base64
import hashlib
import json
import zlib

ROOT = Path(__file__).resolve().parent
REMOTE = PureWindowsPath(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
RUNNER_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(relative, value):
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")

base = json.loads((ROOT / "previous-materialization.json").read_text())["source_files"]
source = {row["path"]: row for row in base}
replacements = []
input_paths = []
for group in ("a1", "a2"):
    for row in json.loads((ROOT / (group + "-inputs-formatted.json")).read_text()):
        relative = row["path"][len("inputs/" + group + "/"):]
        assert row["path"] == "inputs/" + group + "/" + relative
        raw = (ROOT / row["path"]).read_bytes()
        assert sha(raw) == row["sha256"] and len(raw) == row["bytes"]
        source[relative] = {"path": relative, "bytes": len(raw), "sha256": sha(raw)}
        replacements.append({"path": relative, "from": row["path"][len("inputs/"):]})
        input_paths.append(row["path"])

controls = {
    "inputs/control/weekly_refresh_atomic_test.go": (ROOT / "baseline/internal/api/weekly_refresh_atomic_test.go").read_bytes(),
    "inputs/control/weekly_refresh_call_graph_origins_test.go": b"package api\n",
    "inputs/control/weekly_refresh.go": (ROOT / "baseline/internal/api/weekly_refresh.go").read_bytes(),
}
for relative, raw in controls.items():
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)
    input_paths.append(relative)
for label, paths in {
    "a1-red": ["weekly_refresh_atomic_test.go", "weekly_refresh_call_graph_origins_test.go"],
    "a2-red": ["weekly_refresh.go"],
}.items():
    mapping = {str(REMOTE / "candidate-source/internal/api" / path): str(REMOTE / "inputs/control" / path) for path in paths}
    relative = "inputs/" + label + "-overlay.json"
    save(relative, {"Replace": mapping})
    input_paths.append(relative)

inputs = []
for relative in sorted(input_paths):
    raw = (ROOT / relative).read_bytes()
    inputs.append({"path": relative[len("inputs/"):], "bytes": len(raw), "sha256": sha(raw)})
source_files = [source[name] for name in sorted(source)]
assert len(source_files) == 3309 and len(replacements) == 7
save("plans/materialize-a1-a2.json", {"schema": 1, "source_directory": "candidate-source",
     "receipt": "materialize-a1-a2-receipt.json", "base_files": base,
     "source_files": source_files, "input_files": inputs, "replacements": replacements})

def command(label, roots, package="api", expected=0, overlay=None, output=None):
    args = ["test", "-tags=test_state_path_env", "-race", "-count=1", "-timeout=180s", "-json"]
    if overlay:
        args += ["-overlay", str(REMOTE / "inputs" / (overlay + "-overlay.json"))]
    args += ["-run", "^(" + "|".join(roots) + ")$", "./internal/" + package]
    return {"label": label, "tool": "go", "args": args, "timeout_seconds": 240,
            "expected_exit_code": expected, "required_output": output or [],
            "required_tests": {"pass" if expected == 0 else "fail": roots + ["PACKAGE:mcp-local-hub/internal/" + package]}}

common = {"schema": 1, "runner_sha256": RUNNER_SHA,
          "source_head": "858812988833a84368c60fba1540ae601155fa71",
          "source_tree": "dba685c090952a93a80a1e82403c4646ad8aaed1",
          "source_note": "Base identity only; exact materialized source is the complete source_files inventory.",
          "inputs_directory": "inputs", "native_scheduler_operations": False,
          "source_directory": "candidate-source", "source_files": source_files, "input_files": inputs}
a1_roots = ["TestWeeklyTypedLocalLiteralOrigins", "TestWeeklyTypedContextOrigins",
            "TestWeeklyTypedCallGraphResolution", "TestWeeklyTypedExportXMLBoundary"]
gate = ["TestWeeklyRefreshLockOrderInventory"]
save("plans/a1-origin-proof.json", {**common, "phase": "a1-origin-proof", "commands": [
    command("a1-old-analyzer", gate, expected=1, overlay="a1-red", output=["secureCreateClientConfigIfMissingImpl", "cleanup"]),
    command("a1-origin-fixtures", a1_roots),
    command("a1-lock-order", gate),
]})
api_roots = ["TestWeeklyRefreshTransaction_AppliedReleaseDisposition", "TestApplyWeeklyRefreshSchedule_AppliedReleaseDisposition"]
gui_roots = ["TestWeeklyScheduleHandler_RealApplyReleaseSettlement"]
save("plans/a2-applied-result.json", {**common, "phase": "a2-applied-result", "commands": [
    command("a2-api-old-owner", api_roots, expected=1, overlay="a2-red", output=["applied disposition"]),
    command("a2-gui-old-owner", gui_roots, package="gui", expected=1, overlay="a2-red", output=["want 200"]),
    command("a2-api-result", api_roots),
    command("a2-gui-result", gui_roots, package="gui"),
    command("a2-adjacent", ["TestSupervisorIntentLockOwnershipProductionInventory", "TestAppliedReleaseClassifierFixtureRejectsSibling",
                            "TestWeeklyRefreshReleaseSettlementMatrix", "TestWeeklyScheduleSettingsReleaseSettlementMatrix",
                            "TestReleaseAndJoinAppliedSettlementMatrix"]),
]})
transfer_paths = [*controls, "inputs/a1-red-overlay.json", "inputs/a2-red-overlay.json",
                  "plans/materialize-a1-a2.json", "plans/a1-origin-proof.json", "plans/a2-applied-result.json"]
rows = []
for relative in transfer_paths:
    raw = (ROOT / relative).read_bytes()
    rows.append({"path": relative, "bytes": len(raw), "sha256": sha(raw), "base64": base64.b64encode(raw).decode()})
payload = base64.b64encode(zlib.compress(json.dumps(rows).encode(), 9))
(ROOT / "qualification-plans-payload.b64").write_bytes(payload)
print(json.dumps({"source_files": len(source_files), "replacements": len(replacements), "input_files": len(inputs),
                  "payload_bytes": len(payload), "payload_sha256": sha(payload),
                  "plans": {p: sha((ROOT / p).read_bytes()) for p in transfer_paths if p.startswith("plans/")}}, indent=2))
