"""Receive hash-pinned data files without executing any payload."""
import sys
sys.dont_write_bytecode = True
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
assert Path(__file__).resolve().parent == ROOT and len(sys.argv) == 3
assert hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() == "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
raw = q.own(sys.argv[1]).read_bytes()
assert q.sha(raw) == sys.argv[2]
rows = json.loads(zlib.decompress(base64.b64decode(raw, validate=True)))
assert 0 < len(rows) < 500
assert len({row["path"] for row in rows}) == len(rows)
for row in rows:
    target = q.own(row["path"])
    assert not target.exists(), row["path"]
    data = base64.b64decode(row["base64"], validate=True)
    assert len(data) == row["bytes"] and q.sha(data) == row["sha256"]
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(data)
print(json.dumps({"received": len(rows), "payload_sha256": q.sha(raw), "verified": True}), flush=True)
