"""Package closed A1/A2 evidence and exact inputs without changing project sources."""
from pathlib import Path
import base64,hashlib,json,stat,zipfile
ROOT=Path(r'D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba')
assert Path(__file__).resolve().parent==ROOT
def sha(x):return hashlib.sha256(x).hexdigest()
def read(rel):
    p=ROOT/rel
    for x in (p,*p.parents):
        info=x.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&0x400
    assert p.is_file()
    return p.read_bytes()
phases=['a1-origin-proof','a1-candidate-proof','a2-applied-result','a2-route-fixture','a2-owner-census','a2-composition-census','format-a1','format-a2','format-a2-v2','format-a2-v3','format-a2-composition','prepare']
assert json.loads(read('evidence/a2-composition-census/receipt.json'))['completed'] is True
paths=set()
for phase in phases:
    assert (ROOT/'evidence'/phase/'receipt.json').is_file()
    for p in (ROOT/'evidence'/phase).rglob('*'):
        if p.is_file():paths.add(p.relative_to(ROOT).as_posix())
for p in (ROOT/'plans').glob('*.json'):
    if p.name.startswith(('a1-','a2-','format-a1','format-a2','materialize-a1-a2')):paths.add(p.relative_to(ROOT).as_posix())
for p in (ROOT/'inputs').rglob('*'):
    if p.is_file():
        rel=p.relative_to(ROOT/'inputs').as_posix()
        if rel.startswith(('a1/','a2/','a2-v2/','a2-v3/','a2-composition/','control/')) or '/' not in rel and rel.startswith(('a1-','a2-')):paths.add('inputs/'+rel)
for rel in ['qualify_go.py','prepare.py','prepare_plan_inputs.py','receive_payload.py','format_inputs.py','make_plans.py','materialize.py','derive_a1_candidate.py','derive_a2_route_retry.py','derive_a2_inventory_retry.py','derive_a2_inventory_formatted.py','derive_a2_composition_census.py','baseline-manifest.json','previous-materialization.json','materialize-a1-a2-receipt.json','a1-inputs-formatted.json','a2-inputs-formatted.json','pack_a1_a2.py']:
    paths.add(rel)
records=[];data={}
for rel in sorted(paths):
    raw=read(rel);data[rel]=raw;records.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
metadata={'schema':1,'file_count':len(records),'files':records,'previous_archive':{'url':'https://raw.githubusercontent.com/applicate2628/mcp-local-hub/203c7bacef98c0445549512a2b6cab61eca6dcd1/docs/modernization/verification/scheduler-upgrade-recovery-20261122/raw-evidence.zip','bytes':1695231,'sha256':'858912769a69d45fd6fdd8e422ed169fd7bbc69c9a125e7fab8c2a0fe584bd29'},'project_execution':False}
data['PACKAGE_FILES.json']=(json.dumps(metadata,indent=2)+'\n').encode()
out=ROOT/'exports';out.mkdir(exist_ok=True)
archive=out/'a1-a2-raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for rel,raw in sorted(data.items()):
        info=zipfile.ZipInfo(rel,date_time=(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,raw,compresslevel=9)
for rel,raw in data.items():assert read(rel)==raw if rel!='PACKAGE_FILES.json' else True
raw=archive.read_bytes()
with (out/'a1-a2-raw-evidence.b64').open('xb') as f:f.write(base64.b64encode(raw))
receipt={'archive':archive.name,'bytes':len(raw),'sha256':sha(raw),'members':len(data),'sources_mutated':False}
with (out/'a1-a2-export.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
