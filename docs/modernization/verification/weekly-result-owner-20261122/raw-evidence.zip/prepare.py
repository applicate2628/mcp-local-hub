"""Materialize the previously qualified source; execute no project program."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import urllib.request
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
PRESERVED = Path(r"D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5\preserved-input\source-preserved")
ARCHIVE_SHA = "858912769a69d45fd6fdd8e422ed169fd7bbc69c9a125e7fab8c2a0fe584bd29"
RUNNER_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
assert os.name == "nt" and Path(__file__).resolve().parent == ROOT
assert hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() == RUNNER_SHA
spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def reject_reparse(path):
    for node in (path, *path.parents):
        info = node.lstat()
        if node.is_symlink() or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse point in preserved input")

reject_reparse(ROOT)
reject_reparse(PRESERVED)
out = q.own("evidence/prepare")
out.mkdir(parents=True, exist_ok=False)
receipt = {"started_utc": q.now(), "completed": False, "project_execution": False,
           "native_scheduler_operations": False, "product_operations": False,
           "dependency_downloads": False, "archive_sha256": ARCHIVE_SHA}
try:
    archive = q.own("previous-archive.zip")
    url = "https://raw.githubusercontent.com/applicate2628/mcp-local-hub/203c7bacef98c0445549512a2b6cab61eca6dcd1/docs/modernization/verification/scheduler-upgrade-recovery-20261122/raw-evidence.zip"
    with urllib.request.urlopen(url, timeout=60) as response, archive.open("xb") as target:
        while block := response.read(1024 * 1024):
            target.write(block)
    assert q.sha(archive.read_bytes()) == ARCHIVE_SHA
    with zipfile.ZipFile(archive) as z:
        plan = json.loads(z.read("plans/materialize-weekly.json"))
        for row in plan["base_files"]:
            source = PRESERVED / row["path"]
            reject_reparse(source)
            data = source.read_bytes()
            assert len(data) == row["bytes"] and q.sha(data) == row["sha256"], row["path"]
        replacements = {row["path"]: row["from"] for row in plan["replacements"]}
        assert len(replacements) == 52
        for row in plan["source_files"]:
            relative = row["path"]
            data = z.read("inputs/" + replacements[relative]) if relative in replacements else (PRESERVED / relative).read_bytes()
            assert len(data) == row["bytes"] and q.sha(data) == row["sha256"], relative
            target = q.own("source/" + relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(data)
        q.save(q.own("baseline-manifest.json"), {"source_head": "858812988833a84368c60fba1540ae601155fa71",
               "source_tree": "dba685c090952a93a80a1e82403c4646ad8aaed1", "source_files": plan["source_files"]})
    receipt["source"] = q.check_files("source", plan["source_files"], True)
    assert receipt["source"]["inventory_sha256"] == "ecc139439ca1c3b1185cdd0c6fea9861c9ed3e989d89c09421a2584156645715"
    receipt["completed"] = True
except BaseException as error:
    receipt.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    receipt["finished_utc"] = q.now()
    q.save(out / "receipt.json", receipt)
    print(json.dumps(receipt), flush=True)
