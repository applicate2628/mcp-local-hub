"""Copy exact source and candidate inputs into a fresh physical test source."""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
assert Path(__file__).resolve().parent == ROOT and len(sys.argv) == 3
assert hashlib.sha256((ROOT / "qualify_go.py").read_bytes()).hexdigest() == "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
spec = importlib.util.spec_from_file_location("qualification", ROOT / "qualify_go.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
raw = q.own(sys.argv[1]).read_bytes()
assert q.sha(raw) == sys.argv[2]
plan = json.loads(raw)
receipt = {"started_utc": q.now(), "manifest_sha256": q.sha(raw), "completed": False, "project_execution": False}
try:
    receipt["base_before"] = q.check_files("source", plan["base_files"], True)
    receipt["inputs_before"] = q.check_files("inputs", plan["input_files"])
    target_directory = plan["source_directory"]
    q.own(target_directory).mkdir(exist_ok=False)
    replacements = {row["path"]: row["from"] for row in plan["replacements"]}
    assert len(replacements) == len(plan["replacements"])
    for row in plan["source_files"]:
        relative = row["path"]
        source = q.own("inputs/" + replacements[relative]) if relative in replacements else q.own("source/" + relative)
        data = source.read_bytes()
        assert len(data) == row["bytes"] and q.sha(data) == row["sha256"], relative
        target = q.own(target_directory + "/" + relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
    receipt["source"] = q.check_files(target_directory, plan["source_files"], True)
    receipt["base_after"] = q.check_files("source", plan["base_files"], True)
    receipt["inputs_after"] = q.check_files("inputs", plan["input_files"])
    assert receipt["base_before"] == receipt["base_after"] and receipt["inputs_before"] == receipt["inputs_after"]
    receipt["completed"] = True
finally:
    receipt["finished_utc"] = q.now()
    q.save(q.own(plan["receipt"]), receipt)
print(json.dumps(receipt), flush=True)
