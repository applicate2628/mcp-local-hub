# Serena/Product: воспроизводимый состав и подготовка Source

Этот компактный комплект сохраняет **109 выбранных дельт** и полные
описания **3323 исходных файлов**. Основание — master
`75dbc6406123e22468f168b861d5e0622c9d5769`; итоговое дерево Git —
`8928e54342bc700b07f977a1d8f22bbaf986ad04`.

В комплект входят проверяемое восстановление из точного master ZIP,
происхождение каждой дельты и фактическая штатная подготовка Source на
Comet. **Версия 3 завершилась успешно:** создан исходный коммит
`4c3eb47d002ea729fe80370a75506a1d0c9650ac`, выдан Source для 3323 файлов,
а повторное native чтение совпало с результатом выдающего helper.
Product и Serena не запускались.

Полный каталог из 50 823 826 байт, полный архив исходников и первоначальный
payload размером 2,19 МБ здесь повторно не хранятся. Их идентичности
сохранены, первоначальный payload воспроизводится из файлов комплекта.
Небольшой control v3 сохранён вместе с его исходным кодом и точным планом.
Первичные raw receipts, snapshot и commit перенесены без изменения байтов.

Два прежних отказа сохраняются отдельно. Исторические `NOT_RUN` в исходном
manifest, старых отчётах и планах относятся к моменту их создания;
фактический результат продолжения приведён в разделе 5.

## Содержание

1. [Состав и границы](#1-состав-и-границы)
2. [Восстановление полного каталога](#2-восстановление-полного-каталога)
3. [Происхождение и воспроизведение композиции](#3-происхождение-и-воспроизведение-композиции)
4. [Зафиксированная процедура на Comet](#4-зафиксированная-процедура-на-comet)
5. [Проверки и фактические результаты](#5-проверки-и-фактические-результаты)
6. [Сохранение и последующие действия](#6-сохранение-и-последующие-действия)
7. [Точные входы следующих издателей](#7-точные-входы-следующих-издателей)

## 1. Состав и границы

**Таблица 1. Полный состав относительно master.**

| Показатель | Значение |
|---|---:|
| Файлов в master | 3270 |
| Сохранённых файлов прежней композиции | 74 |
| Собственных дополнительных путей #664 / #665 / #666 | 22 / 5 / 8 |
| Всего дельт | 109 |
| Добавлений / изменений / удалений | 53 / 56 / 0 |
| Неизменённых файлов master | 3214 |
| Полный результат | 3323 файла, 50 823 826 байт |
| Git-режим всех файлов | `100644` |

Сохранены пять прежних согласований пересекающихся изменений, включая
версию master **0.4.65** в `build.ps1`. Собственные 22 пути взяты из #664
`8fc6780873e8d2580ea889c572535c5fb8a430dd`, пять из #665
`b5cd530969b7089e7d7cbaf5308543be8c443f8c`, восемь из #666
`09de8e98d1aa6f122215dbe869bc6f7d0ce083f5`.
Полные ревизии прежних десяти источников, все входные объекты и правило
выбора находятся в [manifest](candidate/manifest.json) и в историческом
[описании композиции](SOURCE_COMPOSITION_HISTORY.md#2-точные-ревизии-и-правило-выбора).

Состав исключает новые изменения #660 A1/A2, все изменения #663, включая
`GUIOwnerLifecycle` и A3 preferences, а также невыбранные документальные
и иные дельты исходных запросов. Получение Source для этого состава не
проверяет изменения этих отдельных ветвей.

Git blob — объект байтов одного файла. Git tree — объект состава
каталога, связывающий имена, режимы и объекты потомков. Коммит добавляет
к дереву родителей и метаданные. SHA-256 — 256-битная криптографическая
контрольная сумма. `source_epoch` — идентификатор исходного состава,
выдаваемый штатным владельцем проверки Source; он не выводится из
названия архива и не заменяется нашим вычислением Git tree.

## 2. Восстановление полного каталога

Исходный master ZIP получен по точному адресу:

<https://codeload.github.com/applicate2628/mcp-local-hub/zip/75dbc6406123e22468f168b861d5e0622c9d5769>

**Таблица 2. Закреплённые идентичности.**

| Объект | Значение |
|---|---|
| master commit | `75dbc6406123e22468f168b861d5e0622c9d5769` |
| master tree | `cb3eec77c23f9400be962d91c9f23834b84f7643` |
| master ZIP | 17 461 518 байт |
| master ZIP SHA-256 | `2e688e6e1e84cc062b3213a50f59f8cad61fac730a2afe44ecaba7f2937d09ac` |
| Итоговый tree | `8928e54342bc700b07f977a1d8f22bbaf986ad04` |
| manifest SHA-256 | `f9ee3a4110c24112cd1c5b125598a56bb5b5276c7289c10222eb077351f7897b` |
| Полная inventory SHA-256 | `d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235` |

Inventory — полная таблица файлов с длиной, режимом, Git blob и SHA-256.
[Таблица master](next-step/base-files.json) содержит 3270 строк,
[итоговая таблица](candidate/source-files.json) — 3323 строки.

После получения именно закреплённого ZIP выполнить обычным Python из
этого каталога:

```text
python restore_source.py --master-zip <retained-master.zip> --output <fresh-source-directory> --report <fresh-report.json>
```

Родители обоих выходов должны уже существовать. Сам каталог исходников
и файл отчёта должны быть новыми, раздельными и находиться вне комплекта.
Восстановитель выполняет только операции с файлами: проверяет SHA-256
архива, все имена и наблюдённые DOS-атрибуты ZIP, каждый master blob,
109 дельт, оба дерева и все записанные файлы. Он не вызывает сеть, Git,
Go, сборку или код проекта, не создаёт коммит и не выдаёт `source_epoch`.
При ошибке уже созданные результаты сохраняются для разбирательства.

В удерживаемом ZIP ровно 187 каталогов с `create_system=0`,
`external_attr=16` и 3270 файлов с `create_system=0`, `external_attr=0`.
Нулевые старшие атрибуты этого DOS-архива не являются Unix-режимами.
`100644` подтверждается таблицей и полным tree. Восстановитель читает
проверенные байты ZIP из памяти и не использует `extractall`.

Если сервер в будущем перепакует ZIP и его SHA-256 изменится, этот
восстановитель откажет. Исходный удерживаемый ZIP и отдельный полный
архив остаются сохранёнными; контрольные суммы ослаблять не требуется.
Альтернативное воспроизведение из исходных Git-объектов описано в разделе 3.

## 3. Происхождение и воспроизведение композиции

**Таблица 3. Основные файлы компактного комплекта.**

| Путь | Назначение |
|---|---|
| `candidate/deltas/` | Ровно 109 итоговых файлов с исходными путями |
| [candidate/manifest.json](candidate/manifest.json) | Входные ревизии, объекты и согласования для каждой дельты |
| [candidate/source-files.json](candidate/source-files.json) | Все 3323 итоговых файла |
| [next-step/base-files.json](next-step/base-files.json) | Все 3270 файлов master |
| `provenance/` | Неизменённые прежние manifest/generator/README и 22 дополнительных объекта |
| [compose.py](compose.py) | Первоначальный генератор из точных Git-объектов |
| [verify.py](verify.py) | Независимая проверка файлов и tree через read-only Git hash-object |
| [restore_source.py](restore_source.py) | Переносимое восстановление из сохранённого master ZIP и дельт |
| [pack_execution.py](pack_execution.py) | Воспроизведение точных байтов переданного payload |
| [SOURCE_COMPOSITION_HISTORY.md](SOURCE_COMPOSITION_HISTORY.md) | Неизменённый отчёт первоначальной подготовки полного состава |
| [verification.json](verification.json) | Историческая независимая проверка полного каталога |
| [archive.json](archive.json) | Идентичность отдельного полного архива, не вложенного в этот комплект |
| `next-step/` | Контракт, frozen runner, план, metadata входов и независимое ревью |

Первоначальную композицию можно воспроизвести при наличии локального
репозитория с закреплёнными Git-объектами:

```text
python compose.py --repository <repository-with-pinned-objects> --output <fresh-candidate>
python verify.py --repository <repository-with-pinned-objects> --candidate <fresh-candidate> --report <fresh-verification.json>
```

Генератор не получает недостающие объекты из сети; 22 ранее недостающих
blob сохранены в `provenance/blobs/`. Первоначальный проверяющий алгоритм
независимо обходит деревья снизу вверх и использует `git hash-object`
без записи объектов. Содержимое [verification.json](verification.json)
фиксирует реально выполненную проверку, включая все 74 сохранённых
результата и пять согласований. Исторический `pack.py` относится к
упаковке полного материализованного `candidate/source/`, который в
компактный комплект не включён; он не используется для данной публикации.

## 4. Зафиксированная процедура на Comet

Первоначальные [run_source.py](next-step/run_source.py) и
[prepare-plan.json](next-step/prepare-plan.json) сохранены неизменно.
Первый запуск выполнил только `git --version` с exit 0, затем обнаружил
отсутствующий `mingw64/share/git-core/templates`. Коммит, сборка helper
и выдача Source не выполнялись. Read-only осмотр установленного Git
подтвердил `ucrt64/share/git-core/templates` с двумя служебными файлами и
14 sample-hooks. Реальные hooks и дополнительная конфигурация отсутствуют.

Версия 2 — [run_source_v2.py](next-step/run_source_v2.py) и
[prepare-plan-v2.json](next-step/prepare-plan-v2.json). В ней исправлен
только путь шаблонов и введены свежие имена runner/plan/work/phase.
[Полный diff](next-step/runner-v2.diff) и
[объяснение версии 2](next-step/RUNNER_V2.md) сохранены. Source inputs,
tools, argv и проверки результата не менялись.

Версия 2 остановилась на 60-секундном сроке импорта 3270 master blobs.
Прямой launcher завершён, но его worker продолжил работу; позднее root
наблюдал его самостоятельное завершение и рост stdout до всех 3270
идентификаторов. Failed receipt v2 сохраняет `process_tree_unresolved=true`.
Текущий log и его исходный префикс с подтверждённым SHA-256 сохранены
отдельно; позднее окончание не превращает исходную попытку в успех.

Успешная фактическая процедура — [run_source_v3.py](next-step/run_source_v3.py)
и [prepare-plan-v3.json](next-step/prepare-plan-v3.json). Она увеличивает
только срок точного base import до 300 секунд и использует свежие имена.
Остальные Git-команды сохраняют 60 секунд, helper preparation — 600,
readback — 300. [Diff v3](next-step/runner-v3.diff),
[история исправления](next-step/RUNNER_V3.md) и
[независимое узкое ревью](next-step/a5-v3-independent-review.md) прилагаются.

Исходный план связывает 121 файл. Вместе с runner и самим планом они
образуют 123 первоначально переданных файла. Control версии 2 содержит
только два новых файла и использует те же 121 входов. Повторно сохранять
base64 payload в Git не нужно: команды ниже восстановят обе передачи и
потребуют совпадения контрольных сумм с фактически переданными байтами.

```text
python pack_execution.py --output <fresh-transfer.b64>
python pack_execution.py --v2-control --output <fresh-v2-control.b64>
```

Небольшой [v3-control.b64](next-step/v3-control.b64), 31 836 байт и два
новых файла, сохранён прямо в комплекте. `pack_execution.py` относится
только к первоначальному payload и control v2.

**Таблица 4. Frozen execution inputs.**

| Объект | SHA-256 |
|---|---|
| Исходный runner | `d9190906266880964ec171b99c1ba6d25988067bb63006d70c93216fc06b921a` |
| Исходный plan | `864fcab7c3e4090172dadf827a2bde05b568bcdfd75b0ff975ae8802042e986e` |
| Исходный transfer payload | `5f758e275c3e60c67d555450aca9b9a7e29ab7c2988dd2c1c38a9fd171340cf5` |
| Runner версии 2 | `92a51464012c9d58adb3e6e670a2baf04afa1dbcce6c067c78b5aa9100d2bf39` |
| Plan версии 2 | `7fd1ca879c303b747775837f667fafb93d281b3f630363245533c96558f2cda6` |
| Control payload версии 2 | `a54583d1b5ccd1036dcfe5d938fec316af8e981740b6d4bb3df421782ff711e5` |
| Runner версии 3 | `87fbadc69f3d0974f8204b0b693860ddd1ac7834401623fad986b70ba77c211e` |
| Plan версии 3 | `66860c29629d649f1c07022f97e1209edf9b01d247c6ded97938c23f36e36cef` |
| Control payload версии 3 | `8bd47471c1a9d56ebe6f5e5a343e82d74e995905b51ef10b3159229da2760d94` |

Точный корень Windows:

```text
D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba
```

Runner использует уже допущенный и закреплённый `qualify_go.py` для
окружения и Go-сборки. Его неизменённая копия сохранена для ревью в
[next-step/environment-owner/qualify_go.py](next-step/environment-owner/qualify_go.py),
SHA-256 `a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e`.
Копия фиксирует существующего владельца окружения и его область допуска.
Source runner создаёт отдельный Git-каталог с полным набором
объектов обоих деревьев и исходным master-коммитом как явно обозначенной
shallow-границей истории. Затем создаётся реальный новый коммит с одним
родителем master. Автор и коммитер берутся из проверенных фактических
metadata прежней публикации; время устанавливает текущий запуск.

После проверки полного tree, индекса, чистоты и object closure выполняется
только сборка `./tools/windows-product-validate`, затем две точные ветви
этого helper: `--prepare-source` и `--source-snapshot`. Ограничения,
точные argv и проверяемые выходы описаны в
[RUNNER_README](next-step/RUNNER_README.md),
[контракте подготовки](next-step/PREPARE_SOURCE_CONTRACT.md) и
[процедуре](next-step/CLEAN_SOURCE_PROCEDURE.md).

Исходный код helper вызывает Git через штатный Windows Job owner.
Внешний Python runner ограничивает ожидание собственного прямого дочернего
процесса; его receipt не заявляет универсальное ограничение всех потомков.
При тайм-ауте он сохраняет неопределённость дерева процессов и рабочие
каталоги. Эта граница явно отражена в независимом ревью.

## 5. Проверки и фактические результаты

Первоначальная проверка исходников, собственное ревью runner и независимое
ревью не заменяют фактического результата Source preparation. Для успешного
итога нужны одновременно `completed=true` и `source_issuance=PASS`, а
также сохранённые stdout/stderr, exit codes, реальные commit/tree,
неизменность инструментов и полное readback-сопоставление.

Первичные результаты находятся в `evidence/native-source/`.
[V3 receipt](evidence/native-source/records/evidence/a5-source-preparation-v3/receipt.json)
фиксирует `completed=true`, `source_issuance=PASS`, чистый исходный состав
и точное равенство повторного Source readback. Все 27 команд получили
ожидаемый результат без timeout; три `git config --get` вернули ожидаемый
код 1 для отсутствующих настроек. Остальные команды завершились с кодом 0.

**Таблица 5. Фактически выданный Source.**

| Поле | Значение |
|---|---|
| Выполнение v3, UTC | 2026-11-22 21:08:33.407360 — 21:15:58.699311 |
| Реальный исходный commit | `4c3eb47d002ea729fe80370a75506a1d0c9650ac` |
| Единственный parent | `75dbc6406123e22468f168b861d5e0622c9d5769` |
| Полный tree | `8928e54342bc700b07f977a1d8f22bbaf986ad04` |
| `dirty_selected_source` | `false` |
| File count | 3323 |
| Snapshot SHA-256 | `2bcb3c313dea40ddcb93c5e2d7cd06f69fc23ca98f0ee7fcc08186bff5b6c2a2` |
| Выданный `source_epoch` | `4e07a48c4d77d0cdd086dcda1f704cae8d2ccab8067a65811f414ea6de55482d` |
| Собранный source helper SHA-256 | `23af5b3688704590970bbb4682424ca36c528b1812b851adda3c6f2c6843800c` |

Этот commit является исходным артефактом изолированного checkout,
а не новым HEAD какого-либо PR. Сохранены его
[raw bytes](evidence/native-source/records/source/actual-commit.raw):
1082 байта, SHA-256
`c10b920e17c488e3ef581de679a1a514b438f13d1a6c576c62211b0efae4f11b`.
Из них независимо восстанавливается указанный Git object ID, tree и
parent. [Raw snapshot](evidence/native-source/records/source/source-snapshot.json)
содержит 3323 точных пути и SHA-256, совпадающих с полной inventory.
`source_epoch` взят из реального результата штатного владельца, затем
подтверждён его отдельным native readback; комплект его не выдаёт заново.

Импорт master занял 195,75 секунды при пределе 300; подготовка Source —
188,23 секунды при пределе 600. Это наблюдённые длительности этой попытки,
а не обещание производительности. Сборка одного служебного helper заняла
5,05 секунды. У обоих helper-вызовов пустой stderr, правильные JSON-значения,
exit 0 и неизменный EXE hash. Исходные файлы до сборки, после неё и после
подготовки имеют одну полную inventory; Git status до и после чистый.

**Таблица 6. Первые попытки и сохранение свидетельств.**

| Попытка | Реальный результат | Сохранённые свидетельства |
|---|---|---|
| V1 | Отказ на отсутствующем template path; commit/helper/Source не созданы | Все streams точно соответствуют исходному receipt |
| V2 | Timeout base import; commit/helper/Source не созданы | Failed receipt неизменен; ровно один stdout вырос после timeout; его записанный префикс восстановлен с точным hash |
| V3 | `completed=true`, `source_issuance=PASS` | Все 54 stdout/stderr streams 27 команд соответствуют receipt |

У V2 исходный stdout имел 36 864 байта и SHA-256 `c6d00f8d…`; поздний
log — 134 070 байт и SHA-256 `2ec42413…`. Полные hashes и наблюдения
приведены в [RUNNER_V3](next-step/RUNNER_V3.md), исходный префикс лежит в
`evidence/native-source/records/recorded-stream-prefixes/`.
Ограничение `process_tree_unresolved=true` в старой квитанции сохранено.

Экспорт — отдельное read-only действие: fixed Git cat-file, raw копии и
сверки исходников после чтения. Его [receipt](evidence/native-source/receipt.json)
не заменяет Source receipt. Первичный evidence ZIP имеет 198 членов,
963 852 байта и SHA-256
`f4154b8e666f1cab452fc35d1083444c884413dee86dcdcb140b8d73e50a455b`.
В компактный комплект входят его побайтно сверенные распакованные члены;
сам ZIP повторно внутрь не вложен.

Проверено в рамках подготовки компактного комплекта:

- синтаксис обоих новых вспомогательных Python-скриптов;
- обе inventory и оба tree функции восстановителя;
- все 3323 имеющихся файла по длине, SHA-256 и Git blob;
- воспроизведение payload: 123 файла, 2 190 196 байт и точный SHA-256 из таблицы 4;
- воспроизведение двухфайлового control v2 и неизменность сохранённого control v3;
- исправление и проверка запрета report внутри input bundle у offline восстановителя;
- отсутствие полного `candidate/source/`, больших source/archive копий и первоначального 2,19-МБ payload в публикационном каталоге.

Полная команда `restore_source.py` с фактическим retained ZIP локально
не запускалась: этот ZIP удерживается на Comet. Проверки файлов и Python
не являются запусками тестов проекта. Product, Serena, scheduler и
установщики не входят в процедуру Source preparation. Никакая её успешная
квитанция не означает универсальный допуск всех этих исполнений.

## 6. Сохранение и последующие действия

На Comet вне trash сохраняются активные `a5-work-v3/checkout`,
`a5-work-v3/export`, `a5-work-v3/source-snapshot.json`, helper, runtime и все
квитанции. Там же остаются удерживаемый master ZIP и receipt его
получения. Полная история до master намеренно не восстанавливается;
shallow-граница не скрывает отсутствующие предшествующие коммиты.

Отдельный полный архив подготовленного состава:

```text
serena-source-only.tar.gz
15919113 bytes
SHA-256 abb8971dc485872fa816c6c1f163165be870d0b8ccfcf2838f5a8c1734f19901
```

Он не включён повторно в Git и не изменяется при добавлении фактических
результатов. Исторические документы сохраняются как свидетельство своего
этапа. Продолжение допусков Product или Serena должно использовать
конкретный фактически выданный Source и отдельно выполненные относящиеся
к ним проверки; этот комплект их не подменяет.

## 7. Точные входы следующих издателей

[publisher-inputs.json](publisher-inputs.json) содержит реальный Source
из таблицы 5, точные пути сохранённых checkout/export/snapshot/helper,
существующие tool pins и три отдельные ветви следующей работы. Все три
ветви имеют статус **`NOT_RUN`**. Предложенные новые выходные каталоги
не создавались и ещё не проверены на свежесть. Дата будущей Product
сборки намеренно не присвоена: её нужно один раз получить при реальном
новом build; дата подготовки Source не является датой Product.

**Таблица 7. Различия трёх существующих контрактов.**

| Ветка | Настоящая точка входа | Роль / Source epoch | Условие использования Source |
|---|---|---|---|
| Обычный Product | `build.ps1`, Product package `./cmd/mcphub` | `product`, выданный epoch при `-SourceSnapshotPath` | `$PSScriptRoot` — корень Source, output вне него; Source проверяется до и после сборки |
| Serena qualification publisher | `tools/test-serena-publisher`, `go test -c ./internal/cli` с двумя tags | `serena-qualification`, реально полученный epoch | Builder сам заново вызывает PreparePublisherSource из указанного clean checkout |
| #657 test-state-isolated Product | `build.ps1 -TestStateIsolatedProduct`; с `-CanonicalEntryCommandTestProduct` package `./internal/cli` | `product`, пустой epoch в command-test fixture | `SourceSnapshotPath` не принимается для подготовленного Source; output строго под `.scratch` отдельной рабочей копии |

### Обычный Product

Параметры актуального [build.ps1](candidate/deltas/build.ps1):
`WindowsTargetArch`, `OutputDirectory`, `ReleaseVersion`, `ReleaseCommit`,
`ReleaseBuildDate`, `SourceSnapshotPath` и три switches `PrintPlanJson`,
`TestStateIsolatedProduct`, `CanonicalEntryCommandTestProduct`.
Параметра `SourceRoot` у этого PowerShell-скрипта нет. Его корень определяется
расположением скрипта; рабочий каталог также должен быть корнем Source,
поскольку фактические Go package operands относительны.

Для текущего export без `.git` JSON закрепляет `WindowsTargetArch=amd64`,
`ReleaseVersion=0.4.65`, реальный `ReleaseCommit=4c3eb47d…` и существующий
snapshot path. Любое непустое release metadata требует target architecture;
target architecture требует сразу всю тройку release metadata. Коммит —
40 lowercase hex, build date — реальное время в каноническом формате
UTC `YYYY-MM-DDTHH:mm:ssZ`. Без явного commit export не предоставит
Git HEAD и default может стать `unknown`.

`SourceSnapshotPath` включает native Source verifier до сборки, запрещает
test-state режим и output внутри Source. Epoch получается от проверяющего
helper, записывается в linker metadata и VERSIONINFO, затем сверяется
для Product и полного набора из CUI launcher, GUI Product и identity JSON.
CUI означает консольный интерфейс, GUI — графический; в PE, формате
исполняемого файла Windows, их subsystem коды равны 3 и 2 соответственно.
Порядок сборки — launcher, затем Product с фактическим SHA-256 launcher.

`PrintPlanJson` расположен после первоначальных Git и Go проверок.
Его наличие не превращает вызов скрипта в чтение данных без запуска
программ. Код также создаёт временные `.scratch` JSON и `.syso` ресурсы
пакета и использует существующие `Remove-Item` ветви очистки. Эти реальные
эффекты нужно учитывать в следующем ограниченном действии с builder;
текущая подготовка Source их не выполняла. Наличие допуска Go/Git для A5
не проверяет PowerShell executable и полный кэш `goversioninfo@v1.5.0`.

### Serena qualification publisher

Реальные flags [существующего helper](candidate/deltas/tools/test-serena-publisher/main_windows.go):
`--checkout`, `--expected-commit`, `--go`, `--go-root`, `--module-cache`,
`--work-root`, `--timeout`. JSON передаёт настоящий сохранённый Git
checkout и commit, уже использованные пути Go/GOROOT/module cache.
`--work-root` должен быть новым чистым абсолютным путём локального диска,
отдельным от checkout, Go executable, GOROOT и module cache. Общий срок
рабочего context положителен и не больше 10 минут. Существующая очистка
процессов и потоков имеет 15-секундный бюджет и абсолютную границу на
15 секунд позже этого deadline; это не универсальная граница длительности
всех синхронных файловых операций. Реализована native Windows/amd64 ветка.

Flags `--source-snapshot`, `--source-root` и `--source-epoch` у этого
builder отсутствуют. Он повторно подготавливает Source в собственные
`source/` и `source-snapshot.json`, проверяет clean committed bytes,
собирает `bin/serena-qualification.test.exe` с tags
`test_state_path_env,serena_qualification`, перемещает временный resource
в свой trash и снова проверяет весь Source. Go environment использует
`CGO_ENABLED=0` и локальный file proxy существующего module cache без
сетевого fallback. Входное окружение самого helper и его первой Source
подготовки всё равно должно оставаться квалифицированным и писать в D.

Ожидаемая роль — `serena-qualification`, версия —
`0.0.0-serena-qualification`, machine — `0x8664`, subsystem — 2.
Helper отдельно требует, чтобы обычный Product admission отверг этот
образ; `proof/publisher.json` фиксирует `ordinary_product_admission=false`
и `tests_executed=false`. Форма `source_input` различается: в
`proof/source-preparation.json` находятся schema и три поля данных,
а `proof/publisher.json` сериализует `PublisherSourceInput` из трёх полей
`source_snapshot_sha256`, `source_epoch`, `file_count`, без schema.
В JSON сохранены две отдельные точные ожидаемые формы. Подставлять caller-chosen epoch вместо результата
владельца или считать такой publisher installable Product нельзя.

### Test-state Product из #657

`CanonicalEntryCommandTestProduct` требует `TestStateIsolatedProduct`.
Непустые release metadata и SourceSnapshotPath для этого режима
отвергаются; output задаётся явно абсолютным путём строго ниже `.scratch`
его script-root. Используется tag `test_state_path_env`. Без canonical
switch Product строится из `./cmd/mcphub`, с ним — тестовый образ
`go test -c ./internal/cli` в том же месте Product entry set.

Это по-прежнему PE role `product`. Выпускаемый
`windows-canonical-command-test-fixture.json` содержит буквально
`source_epoch=""`, версию, correlation ID, reverse projection и фактические
hashes launcher/Product/identity. Он не заменяет source-issued
`serena-qualification` publisher. Режим нужно выполнять в отдельной
рабочей копии, сохраняя текущие выданные checkout/export без новых тестовых
файлов. Ни создание этих трёх видов образов, ни их тесты, запуск,
установка или публикация в A5 не выполнялись.
