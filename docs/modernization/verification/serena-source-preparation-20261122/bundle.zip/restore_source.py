#!/usr/bin/env python3
"""Restore only the pinned source files from the retained master ZIP and deltas.

Standard-library file operations only: no network, Git, Go, subprocess, commit,
source epoch, build, test, publisher, or Product execution.
"""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile


BASE = "75dbc6406123e22468f168b861d5e0622c9d5769"
BASE_TREE = "cb3eec77c23f9400be962d91c9f23834b84f7643"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
ZIP_SHA = "2e688e6e1e84cc062b3213a50f59f8cad61fac730a2afe44ecaba7f2937d09ac"
ZIP_BYTES = 17461518
PINNED = {
    "candidate/manifest.json": "f9ee3a4110c24112cd1c5b125598a56bb5b5276c7289c10222eb077351f7897b",
    "candidate/source-files.json": "d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235",
    "next-step/base-files.json": "d2158e0b5ad93c538e3188695230463619651bc62c620233bb58ba858a7c864c",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise ValueError("Symlink or reparse point refused: " + str(path))
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise ValueError("Unexpected physical file kind: " + str(path))


def checked(path, directory=False):
    for parent in reversed(path.parents):
        ordinary(parent, True)
    ordinary(path, directory)


def inventory(raw, count):
    rows = json.loads(raw)
    result, folded = {}, set()
    for row in rows:
        name = row["path"]
        path = PurePosixPath(name)
        if (not name or not name.isascii() or path.is_absolute() or path.as_posix() != name or
                any(part in (".", "..") or part.lower() == ".git" or part.endswith((".", " ")) for part in path.parts) or
                any(char in name for char in "\\:\0\r\n") or name in result or name.lower() in folded or
                row["mode"] != "100644" or type(row["bytes"]) is not int or row["bytes"] < 0 or
                re.fullmatch(r"[0-9a-f]{40}", row["blob"]) is None or
                re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) is None):
            raise ValueError("Invalid pinned source inventory")
        result[name] = row
        folded.add(name.lower())
    if len(rows) != count or list(result) != sorted(result):
        raise ValueError("Source inventory count or order differs")
    return result


def tree(rows):
    directories = {"": []}
    for name, row in rows.items():
        path = PurePosixPath(name)
        parent = "" if str(path.parent) == "." else str(path.parent)
        directories.setdefault(parent, []).append((path.name, row["mode"], row["blob"]))
        for ancestor in path.parents:
            directories.setdefault("" if str(ancestor) == "." else str(ancestor), [])
    for name in sorted(directories, key=lambda value: (value.count("/") + bool(value), value), reverse=True):
        entries = sorted(directories[name], key=lambda item: item[0].encode() + (b"/" if item[1] == "40000" else b""))
        raw = b"".join(mode.encode() + b" " + leaf.encode() + b"\0" + bytes.fromhex(blob) for leaf, mode, blob in entries)
        digest = oid("tree", raw)
        if not name:
            return digest
        path = PurePosixPath(name)
        parent = "" if str(path.parent) == "." else str(path.parent)
        directories[parent].append((path.name, "40000", digest))


def verify_bytes(name, raw, expected):
    if (len(raw), sha(raw), oid("blob", raw)) != (expected["bytes"], expected["sha256"], expected["blob"]):
        raise ValueError("Source bytes differ: " + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--master-zip", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="A fresh source directory; its parent must exist.")
    parser.add_argument("--report", required=True, type=Path, help="A fresh JSON file outside the source directory.")
    args = parser.parse_args()
    bundle = Path(__file__).absolute().parent
    archive, output, report = (value.absolute() for value in (args.master_zip, args.output, args.report))
    checked(bundle, True)
    checked(archive)
    checked(output.parent, True)
    checked(report.parent, True)
    if (output.exists() or output.is_symlink() or report.exists() or report.is_symlink() or
            output == report or output in report.parents or report in output.parents or
            output == bundle or bundle in output.parents or output in bundle.parents or
            report == bundle or bundle in report.parents or report in bundle.parents):
        raise ValueError("Output and report must be fresh, separate, and outside the bundle")
    inputs = {}
    for name, digest in PINNED.items():
        path = bundle / name
        checked(path)
        inputs[name] = path.read_bytes()
        if sha(inputs[name]) != digest:
            raise ValueError("Pinned input changed: " + name)
    base = inventory(inputs["next-step/base-files.json"], 3270)
    full = inventory(inputs["candidate/source-files.json"], 3323)
    manifest = json.loads(inputs["candidate/manifest.json"])
    if (manifest["base"]["ref"] != BASE or tree(base) != BASE_TREE or tree(full) != TREE or
            manifest["full_source"]["git_tree"] != TREE or sum(row["bytes"] for row in full.values()) != 50823826):
        raise ValueError("Pinned source identity differs")
    archive_raw = archive.read_bytes()
    if len(archive_raw) != ZIP_BYTES or sha(archive_raw) != ZIP_SHA:
        raise ValueError("Retained exact-master archive differs")
    prefix = "mcp-local-hub-" + BASE + "/"
    expected_dirs = {""}
    for name in base:
        expected_dirs.update(str(parent) for parent in PurePosixPath(name).parents if str(parent) != ".")
    contents, seen, directories = {}, set(), set()
    with zipfile.ZipFile(io.BytesIO(archive_raw)) as zipped:
        for entry in zipped.infolist():
            if entry.filename in seen or not entry.filename.startswith(prefix) or entry.flag_bits & 1:
                raise ValueError("Unexpected master ZIP entry")
            seen.add(entry.filename)
            name = entry.filename[len(prefix):]
            if entry.is_dir():
                if name[:-1] not in expected_dirs or entry.create_system != 0 or entry.external_attr != 16 or entry.file_size != 0:
                    raise ValueError("Unexpected DOS ZIP directory")
                directories.add(name[:-1])
            else:
                if name not in base or entry.create_system != 0 or entry.external_attr != 0 or entry.file_size != base[name]["bytes"]:
                    raise ValueError("Unexpected DOS ZIP file")
                raw = zipped.read(entry)
                verify_bytes(name, raw, base[name])
                contents[name] = raw
    if set(contents) != set(base) or directories != expected_dirs or len(directories) != 187:
        raise ValueError("Master ZIP coverage differs")
    deltas = {row["path"]: row for row in manifest["files"]}
    if len(deltas) != 109 or sorted(deltas) != manifest["selection"]["paths"]:
        raise ValueError("Selected delta path set differs")
    for name, row in deltas.items():
        if name not in full:
            raise ValueError("Delta is absent from the complete source")
        path = bundle / "candidate/deltas" / name
        checked(path)
        raw = path.read_bytes()
        verify_bytes(name, raw, row["output"])
        contents[name] = raw
    changes = {name for name in set(base) | set(full) if base.get(name) != full.get(name)}
    if (set(contents) != set(full) or changes != set(deltas) or len(set(full) - set(base)) != 53 or
            len(set(base) - set(full)) != 0 or len(changes & set(base)) != 56):
        raise ValueError("Complete source changes differ from the selected 109 paths")
    for name, raw in contents.items():
        verify_bytes(name, raw, full[name])
    output.mkdir()
    for name, raw in sorted(contents.items()):
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        checked(target.parent, True)
        with target.open("xb") as stream:
            stream.write(raw)
        target.chmod(0o644)
        checked(target)
        verify_bytes(name, target.read_bytes(), full[name])
    actual = set()
    for path in output.rglob("*"):
        ordinary(path, path.is_dir())
        if path.is_file():
            actual.add(path.relative_to(output).as_posix())
    if actual != set(full):
        raise ValueError("Restored physical file set differs")
    result = {
        "kind": "offline pinned source restoration", "completed": True,
        "base_commit": BASE, "base_tree": BASE_TREE, "source_tree": TREE,
        "master_zip": {"bytes": ZIP_BYTES, "sha256": ZIP_SHA},
        "source_files": 3323, "source_bytes": 50823826, "delta_paths": 109,
        "source_directory": str(output), "restorer_sha256": sha(Path(__file__).read_bytes()),
        "network_or_subprocess_started": False, "git_commit_created": False,
        "go_or_project_executed": False, "source_issuance": "NOT_RUN",
    }
    with report.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
