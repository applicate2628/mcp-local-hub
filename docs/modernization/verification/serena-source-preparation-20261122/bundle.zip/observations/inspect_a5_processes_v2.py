import ctypes,ctypes.wintypes as w,datetime,json
k=ctypes.WinDLL('kernel32',use_last_error=True)
class E(ctypes.Structure):
 _fields_=[('dwSize',w.DWORD),('cntUsage',w.DWORD),('th32ProcessID',w.DWORD),('th32DefaultHeapID',ctypes.c_size_t),('th32ModuleID',w.DWORD),('cntThreads',w.DWORD),('th32ParentProcessID',w.DWORD),('pcPriClassBase',w.LONG),('dwFlags',w.DWORD),('szExeFile',w.WCHAR*260)]
k.CreateToolhelp32Snapshot.restype=w.HANDLE;k.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD]
k.Process32FirstW.argtypes=[w.HANDLE,ctypes.POINTER(E)];k.Process32NextW.argtypes=[w.HANDLE,ctypes.POINTER(E)]
k.OpenProcess.restype=w.HANDLE;k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD]
k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
k.GetProcessTimes.argtypes=[w.HANDLE,ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME)]
k.CloseHandle.argtypes=[w.HANDLE]
s=k.CreateToolhelp32Snapshot(2,0)
if s==ctypes.c_void_p(-1).value: raise ctypes.WinError(ctypes.get_last_error())
e=E();e.dwSize=ctypes.sizeof(E);rows=[]
try:
 ok=k.Process32FirstW(s,ctypes.byref(e))
 while ok:
  if e.szExeFile.lower()=='git.exe' or e.th32ProcessID in (34568,58328) or e.th32ParentProcessID in (34568,58328):
   r={'pid':e.th32ProcessID,'parent_pid':e.th32ParentProcessID,'name':e.szExeFile}
   h=k.OpenProcess(0x1000,False,e.th32ProcessID)
   if h:
    try:
     buf=ctypes.create_unicode_buffer(32768);n=w.DWORD(len(buf))
     if k.QueryFullProcessImageNameW(h,0,buf,ctypes.byref(n)):r['image']=buf.value
     else:r['image_error']=ctypes.get_last_error()
     c,x,a,b=w.FILETIME(),w.FILETIME(),w.FILETIME(),w.FILETIME()
     if k.GetProcessTimes(h,ctypes.byref(c),ctypes.byref(x),ctypes.byref(a),ctypes.byref(b)):
      ft=(c.dwHighDateTime<<32)|c.dwLowDateTime;r['creation_filetime']=ft;r['creation_utc']=(datetime.datetime(1601,1,1,tzinfo=datetime.timezone.utc)+datetime.timedelta(microseconds=ft//10)).isoformat();r['cpu_100ns']=((a.dwHighDateTime<<32)|a.dwLowDateTime)+((b.dwHighDateTime<<32)|b.dwLowDateTime)
    finally:k.CloseHandle(h)
   else:r['open_error']=ctypes.get_last_error()
   rows.append(r)
  ok=k.Process32NextW(s,ctypes.byref(e))
 if ctypes.get_last_error()!=18:raise ctypes.WinError(ctypes.get_last_error())
finally:k.CloseHandle(s)
from pathlib import Path
import hashlib
log=Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba\evidence\a5-source-preparation-v2\git-import-base-blobs.stdout.log")
raw=log.read_bytes();rows.append({'retained_stdout_bytes':len(raw),'retained_stdout_sha256':hashlib.sha256(raw).hexdigest()})
print(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'read-only process inventory; no termination or writes','processes':rows},indent=2))
