#!/usr/bin/env python3
"""Recreate the reviewed transfer bytes; do not transfer or execute anything."""

import argparse
import base64
import hashlib
import json
from pathlib import Path
import stat
import zlib


RUNNER_SHA = "d9190906266880964ec171b99c1ba6d25988067bb63006d70c93216fc06b921a"
PLAN_SHA = "864fcab7c3e4090172dadf827a2bde05b568bcdfd75b0ff975ae8802042e986e"
PAYLOAD_SHA = "5f758e275c3e60c67d555450aca9b9a7e29ab7c2988dd2c1c38a9fd171340cf5"
V2_RUNNER_SHA = "92a51464012c9d58adb3e6e670a2baf04afa1dbcce6c067c78b5aa9100d2bf39"
V2_PLAN_SHA = "7fd1ca879c303b747775837f667fafb93d281b3f630363245533c96558f2cda6"
V2_CONTROL_SHA = "a54583d1b5ccd1036dcfe5d938fec316af8e981740b6d4bb3df421782ff711e5"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--v2-control", action="store_true", help="Recreate only the two v2 control files; original 121 inputs are reused.")
    args = parser.parse_args()
    root = Path(__file__).absolute().parent
    for parent in reversed(args.output.absolute().parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("Payload output parent is not an ordinary directory")
    if args.output.exists() or args.output.is_symlink():
        raise ValueError("Payload output must be fresh")

    def read(name):
        path = root / name
        for item in (*reversed(path.parents), path):
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("Symlink or reparse point refused")
        raw = path.read_bytes()
        return raw

    runner_name = "run_source_v2.py" if args.v2_control else "run_source.py"
    plan_name = "prepare-plan-v2.json" if args.v2_control else "prepare-plan.json"
    runner = read("next-step/" + runner_name)
    plan_raw = read("next-step/" + plan_name)
    if sha(runner) != (V2_RUNNER_SHA if args.v2_control else RUNNER_SHA) or sha(plan_raw) != (V2_PLAN_SHA if args.v2_control else PLAN_SHA):
        raise ValueError("Reviewed runner or execution plan changed")
    plan = json.loads(plan_raw)
    rows = []
    for expected in plan["input_files"]:
        relative = expected["path"].removeprefix("a5-prep/inputs/")
        if relative.startswith("deltas/") or relative in ("manifest.json", "source-files.json"):
            name = "candidate/" + relative
        else:
            name = "next-step/" + relative
        raw = read(name)
        if len(raw) != expected["bytes"] or sha(raw) != expected["sha256"]:
            raise ValueError("Execution input changed: " + name)
        if not args.v2_control:
            rows.append({**expected, "base64": base64.b64encode(raw).decode()})
    for path, raw in (("a5-prep/" + runner_name, runner), ("a5-prep/" + plan_name, plan_raw)):
        rows.append({"path": path, "bytes": len(raw), "sha256": sha(raw), "base64": base64.b64encode(raw).decode()})
    rows.sort(key=lambda row: row["path"])
    payload = base64.b64encode(zlib.compress(json.dumps(rows, separators=(",", ":")).encode(), 9))
    expected = (2, 31872, V2_CONTROL_SHA) if args.v2_control else (123, 2190196, PAYLOAD_SHA)
    if (len(rows), len(payload), sha(payload)) != expected:
        raise ValueError("Reconstructed transfer is not the reviewed payload")
    with args.output.open("xb") as stream:
        stream.write(payload)
    print(json.dumps({"output": str(args.output), "files": len(rows), "bytes": len(payload), "sha256": sha(payload), "payload_transferred_or_executed": False}))


if __name__ == "__main__":
    main()
