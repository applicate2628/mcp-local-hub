#!/usr/bin/env python3
"""Independently verify the materialized source with read-only Git hashing."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    repo, candidate, report = args.repository.resolve(), args.candidate.resolve(), args.report.resolve()
    if report.exists():
        raise SystemExit("verification report must be fresh")
    bundle = Path(__file__).resolve().parent
    manifest_bytes = (candidate / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    inventory_bytes = (candidate / "source-files.json").read_bytes()
    inventory = json.loads(inventory_bytes)
    if sha(inventory_bytes) != manifest["full_source"]["inventory_sha256"]:
        raise SystemExit("inventory hash mismatch")
    if sha((bundle / "compose.py").read_bytes()) != manifest["generator"]["sha256"]:
        raise SystemExit("generator hash mismatch")
    for name, expected in manifest["provenance"].items():
        if sha((bundle / "provenance" / name).read_bytes()) != expected:
            raise SystemExit(f"provenance hash mismatch: {name}")
    environment = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_OPTIONAL_LOCKS="0")

    def git(*argv, stdin=None):
        return subprocess.check_output([
            "git", "--no-replace-objects", "--no-optional-locks",
            "-c", "core.hooksPath=/dev/null", "-c", "protocol.allow=never",
            "-C", str(repo), *argv,
        ], input=stdin, env=environment)

    def inspect(root, expected):
        actual = set()
        for path in root.rglob("*"):
            if path.is_symlink():
                raise SystemExit(f"source symlink refused: {path}")
            if path.is_dir():
                continue
            if not stat.S_ISREG(path.stat().st_mode):
                raise SystemExit(f"non-regular source file: {path}")
            actual.add(path.relative_to(root).as_posix())
        if actual != set(expected):
            raise SystemExit(f"source path set mismatch: {root}")
        for path, entry in expected.items():
            target = root / path
            raw = target.read_bytes()
            mode = "100755" if target.stat().st_mode & 0o111 else "100644"
            if (len(raw), sha(raw), mode) != (entry["bytes"], entry["sha256"], entry["mode"]):
                raise SystemExit(f"source content or mode mismatch: {path}")
        ordered = sorted(expected)
        requests = "\n".join(json.dumps(str(root / path)) for path in ordered) + "\n"
        oids = git("hash-object", "--no-filters", "--stdin-paths", stdin=requests.encode()).decode().splitlines()
        if len(oids) != len(ordered):
            raise SystemExit("Git file hashing returned the wrong count")
        for path, oid in zip(ordered, oids):
            if oid != expected[path]["blob"]:
                raise SystemExit(f"Git source blob mismatch: {path}")
        return {path: (expected[path]["mode"], oid) for path, oid in zip(ordered, oids)}

    # This implementation does not import or reuse compose.py's recursive tree
    # function. It groups paths bottom-up and asks Git to hash every tree node.
    def git_tree(entries):
        directories = {"": []}
        for path, (mode, oid) in entries.items():
            parsed = PurePosixPath(path)
            parent = str(parsed.parent)
            parent = "" if parent == "." else parent
            directories.setdefault(parent, []).append((parsed.name, mode, oid))
            for ancestor in parsed.parents:
                name = "" if str(ancestor) == "." else str(ancestor)
                directories.setdefault(name, [])
        root_hash = None
        for path in sorted(directories, key=lambda item: (item.count("/") + bool(item), item), reverse=True):
            rows = sorted(directories[path], key=lambda item: item[0].encode() + (b"/" if item[1] == "40000" else b""))
            raw = b"".join(mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(oid) for name, mode, oid in rows)
            oid = git("hash-object", "-t", "tree", "--stdin", stdin=raw).decode().strip()
            if path:
                parsed = PurePosixPath(path)
                parent = "" if str(parsed.parent) == "." else str(parsed.parent)
                directories[parent].append((parsed.name, "40000", oid))
            else:
                root_hash = oid
        return root_hash

    expected_source = {entry["path"]: entry for entry in inventory}
    expected_deltas = {entry["path"]: {"mode": entry["mode"], **entry["output"]} for entry in manifest["files"]}
    if len(expected_source) != 3323 or len(expected_deltas) != 109 or sorted(expected_deltas) != manifest["selection"]["paths"]:
        raise SystemExit("manifest source counts or delta path set mismatch")
    source = inspect(candidate / "source", expected_source)
    deltas = inspect(candidate / "deltas", expected_deltas)
    base = {}
    for row in git("ls-tree", "-r", "-z", manifest["base"]["ref"]).split(b"\0"):
        if row:
            metadata, path = row.split(b"\t", 1)
            mode, kind, oid = metadata.decode().split()
            if kind != "blob":
                raise SystemExit("base contains a non-blob leaf")
            base[path.decode()] = (mode, oid)
    base_tree = git_tree(base)
    if base_tree != manifest["base"]["tree"]:
        raise SystemExit("independent base tree differs")
    actual_changes = {path for path in set(base) | set(source) if base.get(path) != source.get(path)}
    if actual_changes != set(deltas):
        raise SystemExit("complete source changes do not equal the selected delta paths")
    source_tree = git_tree(source)
    if source_tree != manifest["full_source"]["git_tree"]:
        raise SystemExit("independent complete source tree differs")
    previous = json.loads((bundle / "provenance/previous_manifest.json").read_bytes())
    retained = []
    for entry in previous["files"]:
        expected = next(item for item in entry["outputs"] if "extended" in item["sets"])
        actual = expected_deltas[entry["path"]]
        if any(actual[key] != expected[key] for key in ("blob", "sha256", "bytes", "resolution")):
            raise SystemExit(f"published extended result changed: {entry['path']}")
        if expected["resolution"] != "copy":
            retained.append({"path": entry["path"], "resolution": expected["resolution"], "sha256": expected["sha256"]})
    if len(retained) != 5:
        raise SystemExit("reviewed overlap resolution count differs")
    result = {
        "kind": "independent source-byte and Git-tree verification",
        "manifest_sha256": sha(manifest_bytes),
        "inventory_sha256": sha(inventory_bytes),
        "generator_sha256": manifest["generator"]["sha256"],
        "verifier_sha256": sha(Path(__file__).read_bytes()),
        "base": {"ref": manifest["base"]["ref"], "file_count": len(base), "git_tree": base_tree},
        "source": {"file_count": len(source), "bytes": sum(item["bytes"] for item in inventory), "git_tree": source_tree, "delta_paths": len(deltas), "additions": len(set(source) - set(base)), "modifications": len(actual_changes & set(base)), "deletions": len(set(base) - set(source)), "unchanged_base_files": len(base) - len(actual_changes & set(base)), "modes": sorted({mode for mode, _ in source.values()})},
        "checks": {"complete_source_path_set": "PASS", "all_source_lengths_sha256_modes": "PASS", "all_source_git_blob_hashes": "PASS", "delta_path_set_and_bytes": "PASS", "all_74_published_extended_outputs": "PASS", "five_reviewed_resolutions": "PASS", "independent_base_tree": "PASS", "independent_composed_tree": "PASS", "hashing_method": "Git hash-object without -w for every file and every bottom-up tree node; SHA-256 read directly from the materialized files."},
        "retained_resolutions": retained,
        "execution": {"project_code_executed": False, "go_or_build_tools_executed": False, "native_or_remote_executed": False, "git_objects_written": False, "git_commit_created": False, "tests": "NOT_RUN", "builds": "NOT_RUN", "source_issuance": "NOT_RUN", "publisher_or_product_issued": False},
    }
    with report.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"independent_tree": source_tree, "source_files": len(source), "delta_paths": len(deltas), "verification": "PASS", "project_code_executed": False}))


if __name__ == "__main__":
    main()
