#!/usr/bin/env python3
"""Pack and byte-verify the complete source-only bundle with stable metadata."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output, report = args.output.resolve(), args.report.resolve()
    if output.exists() or report.exists() or output == report:
        raise SystemExit("archive and report paths must be fresh and distinct")
    names = {"README.md", "compose.py", "verify.py", "pack.py", "verification.json", "candidate/manifest.json", "candidate/source-files.json"}
    for directory in ["candidate/source", "candidate/deltas", "provenance"]:
        for path in (root / directory).rglob("*"):
            if path.is_symlink():
                raise SystemExit(f"archive symlink refused: {path}")
            if path.is_file():
                names.add(path.relative_to(root).as_posix())
    expected = {}
    with output.open("xb") as destination:
        with gzip.GzipFile(filename="", fileobj=destination, mode="wb", mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for relative in sorted(names):
                    path = root / relative
                    if path.is_symlink() or not path.is_file():
                        raise SystemExit(f"archive input is not a regular file: {relative}")
                    raw = path.read_bytes()
                    name = "serena-source-only/" + relative
                    expected[name] = hashlib.sha256(raw).hexdigest()
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    with path.open("rb") as stream:
                        archive.addfile(info, stream)
    seen = set()
    with tarfile.open(output, "r:gz") as archive:
        for member in archive:
            if not member.isfile() or member.name not in expected or member.name in seen or member.mode != 0o644:
                raise SystemExit(f"unexpected archive member: {member.name}")
            with archive.extractfile(member) as stream:
                raw = stream.read()
            if hashlib.sha256(raw).hexdigest() != expected[member.name]:
                raise SystemExit(f"archive bytes mismatch: {member.name}")
            seen.add(member.name)
    if seen != set(expected):
        raise SystemExit("archive member set mismatch")
    manifest = json.loads((root / "candidate/manifest.json").read_bytes())
    result = {
        "kind": "complete source-only archive verification",
        "file": output.name,
        "bytes": output.stat().st_size,
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "member_count": len(seen),
        "all_member_bytes_verified": True,
        "deterministic_metadata": {"mtime": 0, "uid": 0, "gid": 0, "mode": "0644", "gzip_mtime": 0},
        "source_files": manifest["full_source"]["file_count"],
        "delta_files": manifest["selection"]["path_count"],
        "source_tree": manifest["full_source"]["git_tree"],
        "project_code_executed": False,
    }
    with report.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
