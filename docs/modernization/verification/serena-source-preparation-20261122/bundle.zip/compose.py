#!/usr/bin/env python3
"""Compose pinned source bytes only; never run project code or write Git objects."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import runpy
import subprocess


BASE = "75dbc6406123e22468f168b861d5e0622c9d5769"
BASE_TREE = "cb3eec77c23f9400be962d91c9f23834b84f7643"
PREVIOUS_TREE = "d7932bf914b736526d76f97559d17499b88fbfb2"
PROVENANCE = {
    "previous_manifest.json": "44df5301051dae725f3c32ebb62c186c5dfc8205b8c93863f4229a49766e4c32",
    "previous_compose.py": "225f34c1ad448e2ac74fc473f82761957221b642a2f6879cd3f5fce71e7729f2",
    "previous_README.md": "ea9c3600f0fb4cc2574cfe354568d5c1749ceb1b488ed89c1a9f48ea2346e0d3",
    "supplemental-blobs.json": "b310d4744635fc22af23e88cacd75679994c4531e0be21430c8c9b5dd41a851e",
}
ADMISSION = {
    "664": {
        "ref": "8fc6780873e8d2580ea889c572535c5fb8a430dd",
        "paths": [
            "cmd/mcphub/main_test.go",
            "internal/api/hub_mcp_state_read_inode_windows.go",
            "internal/api/hub_mcp_state_read_policy_windows_test.go",
            "internal/api/lsp_routing/main_test.go",
            "internal/api/lsp_routing/resolver_benchmark_test.go",
            "internal/api/lsp_routing/resolver_test.go",
            "internal/api/serena_routing/main_test.go",
            "internal/api/serena_routing/resolver_test.go",
            "internal/api/serena_routing/shared_observer_public_test.go",
            "internal/cli/gui_force_test.go",
            "internal/cli/supervise_reconcile_ipc_test.go",
            "internal/daemon/host_original_windows_test.go",
            "internal/daemon/lazy_proxy_readiness_test.go",
            "internal/daemon/lazy_proxy_test.go",
            "internal/daemon/main_dispatch_test.go",
            "internal/daemon/main_test.go",
            "internal/gui/test_seams.go",
            "internal/oneapirun/async_owner_test.go",
            "internal/oneapirun/async_test.go",
            "internal/oneapirun/main_test.go",
            "tools/testshards/main.go",
            "tools/testshards/main_test.go",
        ],
    },
    "665": {
        "ref": "b5cd530969b7089e7d7cbaf5308543be8c443f8c",
        "paths": [
            "internal/api/intent_audit_caller_oracle_test.go",
            "internal/api/main_helper_dispatch_test.go",
            "internal/api/main_helper_dispatch_validation_test.go",
            "internal/api/main_test.go",
            "internal/api/secrets_test.go",
        ],
    },
    "666": {
        "ref": "09de8e98d1aa6f122215dbe869bc6f7d0ce083f5",
        "paths": [
            "internal/cli/daemon_mcpcompat_test.go",
            "internal/cli/secrets_audit_test.go",
            "internal/cli/secrets_helper_dispatch_test.go",
            "internal/cli/settings_registry_test.go",
            "internal/cli/testmain_dispatch_test.go",
            "internal/cli/testmain_helpers_test.go",
            "internal/cli/testmain_paths_other_test.go",
            "internal/cli/testmain_paths_windows_test.go",
        ],
    },
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def safe_path(path):
    parsed = PurePosixPath(path)
    if parsed.is_absolute() or not parsed.parts or any(part in {"..", ".git"} for part in parsed.parts):
        raise ValueError(f"unsafe source path: {path}")
    return parsed


def full_tree(entries):
    root = {}
    for path, (mode, oid) in entries.items():
        parts = safe_path(path).parts
        directory = root
        for part in parts[:-1]:
            directory = directory.setdefault(part, {})
        if parts[-1] in directory:
            raise ValueError(f"duplicate path: {path}")
        directory[parts[-1]] = (mode, oid)

    def visit(directory):
        rows = []
        for name, child in directory.items():
            if isinstance(child, dict):
                mode, oid, sort_name = "40000", visit(child), name.encode() + b"/"
            else:
                mode, oid = child
                sort_name = name.encode()
            rows.append((sort_name, mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(oid)))
        return git_oid("tree", b"".join(raw for _, raw in sorted(rows)))

    return visit(root)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--previous-archive", type=Path, help="Optionally verify and reuse the published extended bytes.")
    args = parser.parse_args()
    repo, output = args.repository.resolve(), args.output.resolve()
    if output.exists() or repo == output or repo in output.parents or output in repo.parents:
        raise SystemExit("output must be a fresh directory separate from the repository")
    provenance = Path(__file__).resolve().parent / "provenance"
    for name, expected in PROVENANCE.items():
        if sha((provenance / name).read_bytes()) != expected:
            raise SystemExit(f"provenance hash mismatch: {name}")
    previous = json.loads((provenance / "previous_manifest.json").read_bytes())
    supplemental = {}
    for entry in json.loads((provenance / "supplemental-blobs.json").read_bytes()):
        raw = (provenance / "blobs" / entry["blob"]).read_bytes()
        if (len(raw), sha(raw), git_oid("blob", raw)) != (entry["bytes"], entry["sha256"], entry["blob"]):
            raise SystemExit(f"supplemental blob mismatch: {entry['blob']}")
        supplemental[entry["blob"]] = raw
    old = runpy.run_path(str(provenance / "previous_compose.py"))
    if previous["base"] != {"ref": BASE, "tree": BASE_TREE} or previous["blocked_files"]:
        raise SystemExit("published composition does not match the reviewed base")
    environment = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_OPTIONAL_LOCKS="0")

    def git(*argv, stdin=None):
        return subprocess.check_output([
            "git", "--no-replace-objects", "--no-optional-locks",
            "-c", "core.hooksPath=/dev/null", "-c", "protocol.allow=never",
            "-C", str(repo), *argv,
        ], input=stdin, env=environment)

    trees = {}

    def tree(ref):
        if ref not in trees:
            entries = {}
            for row in git("ls-tree", "-r", "-z", ref).split(b"\0"):
                if not row:
                    continue
                metadata, name = row.split(b"\t", 1)
                mode, kind, oid = metadata.decode().split()
                path = name.decode()
                safe_path(path)
                if mode != "100644" or kind != "blob":
                    raise SystemExit(f"unreviewed source mode: {ref} {path} {mode} {kind}")
                entries[path] = (mode, oid)
            trees[ref] = entries
        return trees[ref]

    base = tree(BASE)
    if len(base) != 3270 or full_tree(base) != BASE_TREE or git("rev-parse", BASE + "^{tree}").decode().strip() != BASE_TREE:
        raise SystemExit("base tree mismatch")
    sources = dict(previous["source_refs"])
    for source, metadata in sources.items():
        if git("merge-base", BASE, metadata["ref"]).decode().strip() != metadata["merge_base"]:
            raise SystemExit(f"source ancestry changed: {source}")
        tree(metadata["ref"])
    selected = set(previous["sets"]["extended"]["paths"])
    if len(selected) != 74:
        raise SystemExit("published extended path count changed")
    for source, metadata in ADMISSION.items():
        ref, paths = metadata["ref"], metadata["paths"]
        ancestor = git("merge-base", BASE, ref).decode().strip()
        if ancestor != BASE or selected.intersection(paths):
            raise SystemExit(f"admission overlap or ancestry changed: {source}")
        target = tree(ref)
        if any(not path.endswith(".go") or path not in target or target[path] == base.get(path) for path in paths):
            raise SystemExit(f"selected admission delta changed: {source}")
        selected.update(paths)
        sources[source] = {"ref": ref, "merge_base": ancestor, "path_count": len(paths), "selected_paths": paths}
    if len(selected) != 109:
        raise SystemExit("combined path count changed")
    builder_ancestor = sources["657"]["merge_base"]
    tree(builder_ancestor)
    needed = {oid for _, oid in base.values()}
    for entry in previous["files"]:
        for item in entry["inputs"]:
            expected = tree(sources[item["source"]]["ref"])[entry["path"]][1]
            if expected != item["blob"]:
                raise SystemExit(f"published source blob mismatch: {entry['path']}")
            needed.add(expected)
    needed.add(tree(builder_ancestor)["build.ps1"][1])
    for metadata in ADMISSION.values():
        needed.update(tree(metadata["ref"])[path][1] for path in metadata["paths"])
    ordered = sorted(needed)
    batch = git("cat-file", "--batch", stdin=("\n".join(ordered) + "\n").encode())
    blobs, offset = {}, 0
    for oid in ordered:
        end = batch.index(b"\n", offset)
        header = batch[offset:end].decode().split()
        if header == [oid, "missing"] and oid in supplemental:
            blobs[oid] = supplemental[oid]
            offset = end + 1
            continue
        if len(header) != 3 or header[:2] != [oid, "blob"]:
            raise SystemExit(f"required local Git blob unavailable: {header}")
        length = int(header[2])
        raw = batch[end + 1:end + 1 + length]
        if len(raw) != length or git_oid("blob", raw) != oid or batch[end + 1 + length:end + 2 + length] != b"\n":
            raise SystemExit(f"Git blob mismatch: {oid}")
        blobs[oid] = raw
        offset = end + length + 2
    if offset != len(batch):
        raise SystemExit("unexpected trailing Git batch output")

    def content(ref, path):
        entry = tree(ref).get(path)
        return blobs[entry[1]] if entry else b""

    deltas, files = {}, []
    previous_archive = args.previous_archive.resolve() if args.previous_archive else None
    if previous_archive:
        if sha((previous_archive / "manifest.json").read_bytes()) != PROVENANCE["previous_manifest.json"]:
            raise SystemExit("previous archive manifest differs")
        if sha((previous_archive / "compose.py").read_bytes()) != PROVENANCE["previous_compose.py"]:
            raise SystemExit("previous archive generator differs")
        actual = {path.relative_to(previous_archive / "extended").as_posix() for path in (previous_archive / "extended").rglob("*") if path.is_file()}
        if actual != set(previous["sets"]["extended"]["paths"]):
            raise SystemExit("previous extended archive path set differs")
    for entry in previous["files"]:
        path = entry["path"]
        original = content(BASE, path)
        expected_base = {"blob": base[path][1], "sha256": sha(original)} if path in base else None
        if entry["base"] != expected_base:
            raise SystemExit(f"published base preimage mismatch: {path}")
        variants = []
        for item in entry["inputs"]:
            raw = content(sources[item["source"]]["ref"], path)
            if sha(raw) != item["sha256"]:
                raise SystemExit(f"published input SHA-256 mismatch: {path}")
            variants.append((item["source"], raw))
        if path == "build.ps1":
            raw = old["compose"](content(builder_ancestor, path), [("master", original), ("657", variants[0][1])], path)
        elif len(variants) == 1:
            raw = variants[0][1]
        else:
            raw = old["compose"](original, variants, path)
        expected = next(item for item in entry["outputs"] if "extended" in item["sets"])
        if (len(raw), git_oid("blob", raw), sha(raw)) != (expected["bytes"], expected["blob"], expected["sha256"]):
            raise SystemExit(f"published extended composition changed: {path}")
        if previous_archive:
            archived = (previous_archive / "extended" / path).read_bytes()
            if archived != raw:
                raise SystemExit(f"published extended bytes differ: {path}")
            raw = archived
        deltas[path] = raw
        files.append({"path": path, "mode": "100644", "base": expected_base, "inputs": entry["inputs"], "output": {key: expected[key] for key in ("bytes", "blob", "sha256", "resolution")}, "selection": "published extended"})
    old_full = dict(base)
    old_full.update({path: ("100644", git_oid("blob", raw)) for path, raw in deltas.items()})
    if full_tree(old_full) != PREVIOUS_TREE:
        raise SystemExit("previous full tree did not reproduce")
    for source, metadata in ADMISSION.items():
        for path in metadata["paths"]:
            raw = content(metadata["ref"], path)
            deltas[path] = raw
            files.append({"path": path, "mode": "100644", "base": {"blob": base[path][1], "sha256": sha(content(BASE, path))} if path in base else None, "inputs": [{"source": source, "blob": tree(metadata["ref"])[path][1], "sha256": sha(raw)}], "output": {"bytes": len(raw), "blob": git_oid("blob", raw), "sha256": sha(raw), "resolution": "copy"}, "selection": "owned test-admission delta"})
    full = dict(base)
    full.update({path: ("100644", git_oid("blob", raw)) for path, raw in deltas.items()})
    additions = sum(path not in base for path in deltas)
    modifications = sum(path in base and full[path] != base[path] for path in deltas)
    if (len(full), additions, modifications) != (3323, 53, 56):
        raise SystemExit("composed full source counts changed")
    tree_hash = full_tree(full)
    inventory = []
    output.mkdir(parents=True)
    for path, (mode, oid) in sorted(full.items()):
        raw = deltas[path] if path in deltas else blobs[oid]
        inventory.append({"path": path, "mode": mode, "bytes": len(raw), "blob": oid, "sha256": sha(raw)})
        roots = ["source", "deltas"] if path in deltas else ["source"]
        for root in roots:
            target = output / root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(raw)
            target.chmod(0o644)
            if target.read_bytes() != raw:
                raise SystemExit(f"persisted source bytes mismatch: {root}/{path}")
    inventory_bytes = (json.dumps(inventory, ensure_ascii=False, indent=2) + "\n").encode()
    manifest = {
        "kind": "Serena/Product plus test-admission source-only composition",
        "repository": previous["repository"],
        "base": {"ref": BASE, "tree": BASE_TREE, "file_count": len(base)},
        "generator": {"file": "compose.py", "sha256": sha(Path(__file__).read_bytes())},
        "provenance": PROVENANCE,
        "source_refs": sources,
        "selection": {"published_extended_paths": 74, "test_admission_paths": {source: len(metadata["paths"]) for source, metadata in ADMISSION.items()}, "path_count": 109, "go_path_count": 107, "paths": sorted(deltas), "note": "Select only the 5 API-owned paths from #665 and 8 CLI-owned paths from #666; their inherited older #664 paths are excluded."},
        "resolution_notes": previous["resolution_notes"],
        "files": sorted(files, key=lambda item: item["path"]),
        "full_source": {"root": "source", "inventory": "source-files.json", "inventory_sha256": sha(inventory_bytes), "file_count": len(full), "bytes": sum(item["bytes"] for item in inventory), "additions": additions, "modifications": modifications, "deletions": 0, "unchanged_base_files": len(base) - modifications, "git_tree": tree_hash, "previous_extended_git_tree": PREVIOUS_TREE, "git_objects_written": False, "commit_created": False},
        "qualification": {"project_code_executed": False, "tests": "NOT_RUN", "builds": "NOT_RUN", "native_or_remote": "NOT_RUN", "source_issuance": "NOT_RUN", "publisher_or_product_issued": False, "scope_limit": "Full source bytes only, without a composed commit or source_epoch. This is not a qualified publisher Source, Product, or installation admission.", "excluded": ["New #660 A1/A2 weekly-scheduler changes", "#663 GUIOwnerLifecycle and A3 client-install preference ownership changes", "Documentation/evidence deltas from the selected PRs", "Every other unselected PR delta"]},
    }
    (output / "source-files.json").write_bytes(inventory_bytes)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    (output / "manifest.json").write_bytes(manifest_bytes)
    print(json.dumps({"delta_paths": len(deltas), "source_files": len(full), "source_tree": tree_hash, "source_bytes": manifest["full_source"]["bytes"], "manifest_sha256": sha(manifest_bytes), "project_code_executed": False}))


if __name__ == "__main__":
    main()
