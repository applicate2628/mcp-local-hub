"""Export exact A5 evidence without changing its source or qualification claims.

Only one optional native operation is allowed: read the actual v3 commit with
the admitted Git's fixed cat-file argv. No Go, project helper, Product, network,
installation, source mutation, deletion, or process-tree settlement inference.
"""
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import zipfile


ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GIT_SHA = "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48"
QUALIFIER_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
BASE = "75dbc6406123e22468f168b861d5e0622c9d5769"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
INPUT_SHA = "d8272702c1ec161ff70ea39934e91872c8972b2703c615808da0d8168fa0b235"
PHASES = {
    "a5-source-preparation": ("d9190906266880964ec171b99c1ba6d25988067bb63006d70c93216fc06b921a", "864fcab7c3e4090172dadf827a2bde05b568bcdfd75b0ff975ae8802042e986e"),
    "a5-source-preparation-v2": ("92a51464012c9d58adb3e6e670a2baf04afa1dbcce6c067c78b5aa9100d2bf39", "7fd1ca879c303b747775837f667fafb93d281b3f630363245533c96558f2cda6"),
    "a5-source-preparation-v3": ("87fbadc69f3d0974f8204b0b693860ddd1ac7834401623fad986b70ba77c211e", "66860c29629d649f1c07022f97e1209edf9b01d247c6ded97938c23f36e36cef"),
}
PHASE = "a5-source-preparation-v3"
SOURCE = "a5-work-v3/checkout"
OUTPUT = "exports/a5-source-evidence-v3"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise ValueError("Reparse point refused: " + str(path))
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise ValueError("Unexpected file kind: " + str(path))


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 2:
        raise ValueError("Use normal Python on Comet with the reviewed exporter SHA-256")
    for path in (*reversed(ROOT.parents), ROOT):
        ordinary(path, True)
    self_raw = Path(__file__).read_bytes()
    if sha(self_raw) != sys.argv[1]:
        raise ValueError("Exporter differs from the caller's reviewed bytes")
    qualifier = ROOT / "qualify_go.py"
    ordinary(qualifier)
    if sha(qualifier.read_bytes()) != QUALIFIER_SHA:
        raise ValueError("Existing environment owner changed")
    spec = importlib.util.spec_from_file_location("a5_export_qualification_owner", qualifier)
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    if Path(__file__).resolve() != q.own("a5-prep/export_source_v3.py"):
        raise ValueError("Unexpected exporter location")
    tools = {**q.PINS, str(GIT): GIT_SHA}
    for path, digest in tools.items():
        if sha(Path(path).read_bytes()) != digest:
            raise ValueError("Admitted tool changed: " + path)
    attempts, observed = {}, {}

    def read(relative):
        path = q.own(relative)
        ordinary(path)
        raw = path.read_bytes()
        if relative in observed and observed[relative] != raw:
            raise ValueError("Evidence changed while being captured: " + relative)
        observed[relative] = raw
        return raw

    for phase, pins in PHASES.items():
        value = json.loads(read("evidence/" + phase + "/receipt.json"))
        if (value.get("phase") != phase or not value.get("finished_utc") or
                (value.get("runner_sha256"), value.get("plan_sha256")) != pins or
                value.get("base_commit") != BASE or value.get("source_tree") != TREE):
            raise ValueError("Attempt receipt identity differs: " + phase)
        attempts[phase] = value
    latest = attempts[PHASE]
    raw_plan = read("a5-prep/prepare-plan-v3.json")
    if sha(raw_plan) != PHASES[PHASE][1] or sha(read("a5-prep/run_source_v3.py")) != PHASES[PHASE][0]:
        raise ValueError("Latest frozen execution inputs changed")
    plan = json.loads(raw_plan)
    if "tools_sha256" in latest and latest["tools_sha256"] != tools:
        raise ValueError("Latest receipt does not bind the admitted tools")
    for row in plan["input_files"]:
        raw = read(row["path"])
        if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
            raise ValueError("Frozen source input changed")
    full_raw = read("a5-prep/inputs/source-files.json")
    if sha(full_raw) != INPUT_SHA:
        raise ValueError("Complete source inventory changed")
    expected_source = None
    if "composed_physical_before_commit" in latest:
        expected_source = json.loads(full_raw)
    elif "base_physical" in latest:
        expected_source = json.loads(read("a5-prep/inputs/base-files.json"))
    physical_before = q.check_files(SOURCE, expected_source, True) if expected_source is not None else None
    out = q.own(OUTPUT)
    if out.exists():
        raise ValueError("Export destination already exists; preserve it")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir()
    records = out / "records"
    records.mkdir()
    result = {"kind": "exact A5 source evidence export", "started_utc": q.now(), "completed": False,
              "exporter_sha256": sha(self_raw), "latest_phase": PHASE, "attempts": {},
              "native_operations": [], "go_or_project_executed": False, "network_started": False,
              "source_modified": False, "prior_receipts_modified": False,
              "source_qualification_reissued": False, "source_before": physical_before}
    q.save(out / "receipt-initial.json", result)
    try:
        saved = {}

        def preserve(name, raw):
            target = records / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(raw)
            if target.read_bytes() != raw:
                raise ValueError("Export readback differs")
            saved[name] = {"path": name, "bytes": len(raw), "sha256": sha(raw)}

        evidence_names = set()
        for phase in PHASES:
            parent = q.own("evidence/" + phase)
            for path in sorted(parent.rglob("*")):
                relative = path.relative_to(ROOT).as_posix()
                q.own(relative)
                ordinary(path, path.is_dir())
                if path.is_file():
                    evidence_names.add(relative)
                    preserve(relative, read(relative))
        fetch_name = "a5-prep/master-download/receipt.json"
        preserve(fetch_name, read(fetch_name))
        for phase, receipt in attempts.items():
            streams = []
            for command in receipt.get("commands", []):
                label = command["label"]
                if re.fullmatch(r"[a-z][a-z0-9-]+", label) is None:
                    raise ValueError("Unexpected recorded command label")
                for stream in ("stdout", "stderr"):
                    expected = command.get(stream)
                    if expected is None:
                        continue
                    name = "evidence/" + phase + "/" + label + "." + stream + ".log"
                    raw = observed[name]
                    exact = {"bytes": len(raw), "sha256": sha(raw)} == expected
                    prefix = len(raw) >= expected["bytes"] and sha(raw[:expected["bytes"]]) == expected["sha256"]
                    entry = {"path": name, "recorded": expected, "captured": {"bytes": len(raw), "sha256": sha(raw)},
                             "exact_match": exact, "recorded_prefix_matches": prefix}
                    if not exact and prefix:
                        prefix_name = "recorded-stream-prefixes/" + phase + "/" + label + "." + stream + ".bin"
                        preserve(prefix_name, raw[:expected["bytes"]])
                        entry["recorded_prefix_file"] = prefix_name
                    streams.append(entry)
            result["attempts"][phase] = {"recorded_completed": receipt.get("completed"),
                                         "recorded_source_issuance": receipt.get("source_issuance"),
                                         "recorded_source_commit_created": receipt.get("source_commit_created"),
                                         "recorded_process_tree_unresolved": any(row.get("process_tree_unresolved") for row in receipt.get("commands", [])),
                                         "streams": streams}

        snapshot_name = "a5-work-v3/source-snapshot.json"
        snapshot = q.own(snapshot_name)
        if snapshot.exists():
            raw = read(snapshot_name)
            preserve("source/source-snapshot.json", raw)
            expected = latest.get("source_preparation", {}).get("source_input", {}).get("source_snapshot_sha256")
            result["snapshot"] = {"bytes": len(raw), "sha256": sha(raw), "matches_issued_hash": expected is not None and expected == sha(raw)}
        else:
            result["snapshot"] = {"present": False}

        if latest.get("source_commit_created"):
            commit = latest.get("source_commit", "")
            if re.fullmatch(r"[0-9a-f]{40}", commit) is None:
                raise ValueError("Actual commit is not a full object identity")
            runtime = q.own("runtime/" + PHASE)
            env = {key.upper(): value for key, value in os.environ.items() if key.upper() in {"SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "SYSTEMDRIVE", "OS"}}
            env.update(latest["environment"])
            expected_env = {"USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
                            "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"),
                            "GIT_CONFIG_GLOBAL": str(runtime / "absent-global-config"), "GIT_CONFIG_NOSYSTEM": "1",
                            "GIT_NO_LAZY_FETCH": "1", "GIT_TERMINAL_PROMPT": "0", "GIT_ASKPASS": ""}
            if any(env.get(key) != value for key, value in expected_env.items()):
                raise ValueError("The private v3 Git environment differs")
            for name in ("profile", "appdata", "localappdata", "tmp"):
                ordinary(runtime / name, True)
            env.update(GCM_INTERACTIVE="never", PYTHONDONTWRITEBYTECODE="1", TMPDIR=env["TEMP"])
            argv = [str(GIT), "--no-pager", "--no-optional-locks", "--no-replace-objects", "--literal-pathspecs",
                    "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", "-c", "protocol.allow=never",
                    "-C", str(q.own(SOURCE)), "cat-file", "commit", commit]
            row = {"argv": argv, "cwd": str(q.own(SOURCE)), "started_utc": q.now(), "direct_timeout_seconds": 60,
                   "settled": False, "timed_out": False, "whole_process_tree_deadline_enforced": False,
                   "executable_sha256": GIT_SHA}
            child = None
            stdout_path, stderr_path = out / "actual-commit.raw", out / "git-cat-file.stderr.log"
            started = time.monotonic()
            try:
                with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
                    child = subprocess.Popen(argv, cwd=q.own(SOURCE), env=env, stdin=subprocess.DEVNULL,
                                             stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                    row["pid"] = child.pid
                    q.save(out / "git-cat-file.launched.json", row)
                    row["exit_code"] = child.wait(timeout=60)
                    row["settled"] = True
            except BaseException as error:
                row.update(error_type=type(error).__name__, error=str(error), timed_out=isinstance(error, subprocess.TimeoutExpired))
                raise
            finally:
                if child is not None and not row["settled"]:
                    row.update(process_tree_unresolved=True, termination_method="Retained original direct-child handle only")
                    try:
                        child.terminate()
                        row["exit_code"] = child.wait(timeout=10)
                        row["settled"] = True
                    except BaseException as error:
                        row["termination_error"] = str(error)
                for label, path in (("stdout", stdout_path), ("stderr", stderr_path)):
                    if path.exists():
                        raw = path.read_bytes()
                        row[label] = {"bytes": len(raw), "sha256": sha(raw)}
                row.update(finished_utc=q.now(), seconds=time.monotonic() - started, executable_hash_after=sha(GIT.read_bytes()))
                row["oracle_pass"] = bool(row["settled"] and not row["timed_out"] and not row.get("error_type") and
                                          row.get("exit_code") == 0 and row.get("stderr", {}).get("bytes") == 0 and row["executable_hash_after"] == GIT_SHA)
                q.save(out / "git-cat-file.receipt.json", row)
                result["native_operations"].append(row)
            if not row["oracle_pass"]:
                raise ValueError("Read-only commit export failed")
            raw = stdout_path.read_bytes()
            digest = hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            headers = raw.split(b"\n\n", 1)[0].splitlines()
            if digest != commit or [line for line in headers if line.startswith(b"tree ")] != [("tree " + TREE).encode()] or [line for line in headers if line.startswith(b"parent ")] != [("parent " + BASE).encode()]:
                raise ValueError("Exported actual commit identity or parent/tree differs")
            preserve("source/actual-commit.raw", raw)
            result["actual_commit"] = {"oid": digest, "bytes": len(raw), "sha256": sha(raw), "tree": TREE, "parent": BASE}
        else:
            result["actual_commit"] = {"present": False}

        result["source_after"] = q.check_files(SOURCE, expected_source, True) if expected_source is not None else None
        if result["source_after"] != physical_before:
            raise ValueError("Original physical source changed during export")
        current_names = set()
        for phase in PHASES:
            for path in q.own("evidence/" + phase).rglob("*"):
                q.own(path.relative_to(ROOT).as_posix())
                ordinary(path, path.is_dir())
                if path.is_file():
                    current_names.add(path.relative_to(ROOT).as_posix())
        if current_names != evidence_names:
            raise ValueError("Original evidence file set changed during export")
        for relative, raw in observed.items():
            if q.own(relative).read_bytes() != raw:
                raise ValueError("Original input or evidence changed during export: " + relative)
        for path, digest in tools.items():
            if sha(Path(path).read_bytes()) != digest:
                raise ValueError("Tool changed during export")
        if Path(__file__).read_bytes() != self_raw or sha(qualifier.read_bytes()) != QUALIFIER_SHA:
            raise ValueError("Exporter or environment owner changed")
        result["files"] = [saved[name] for name in sorted(saved)]
        result["completed"] = True
    except BaseException as error:
        result.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        result["finished_utc"] = q.now()
        q.save(out / "receipt.json", result)
        print(json.dumps({key: result.get(key) for key in ("completed", "actual_commit", "snapshot", "error")}), flush=True)
    archive = out / "a5-source-evidence-v3.zip"
    expected = {}
    for path in sorted(out.rglob("*")):
        ordinary(path, path.is_dir())
        if path.is_file():
            expected[path.relative_to(out).as_posix()] = path.read_bytes()
    with archive.open("xb") as destination:
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
            for name, raw in expected.items():
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                zipped.writestr(info, raw, compresslevel=9)
    with zipfile.ZipFile(archive) as zipped:
        if set(zipped.namelist()) != set(expected) or any(zipped.read(name) != raw for name, raw in expected.items()):
            raise ValueError("Evidence ZIP readback differs")
    report = {"file": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive.read_bytes()), "members": len(expected), "all_member_bytes_verified": True}
    q.save(out / "archive.json", report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
