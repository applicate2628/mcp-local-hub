# Source runner v2: путь установленного Git

Первый фактический запуск исходного `run_source.py` остановился после
успешного `git --version` и до материализации исходников: каталог
`C:\Program Files\Git\mingw64\share\git-core\templates` отсутствует.
У установленного Git 2.56.1.windows.1 шаблоны находятся в
`C:\Program Files\Git\ucrt64\share\git-core\templates`.
Read-only осмотр root подтвердил `description`, `info/exclude` и 14
файлов `*.sample`; настоящие hooks и добавочный config не обнаружены.

Исходные runner, plan, payload и квитанции сохраняются без изменений.
Первый `a5-work` пуст; исходный коммит, helper и Source не создавались.
Фактическая первая квитанция имеет `completed=false`,
`source_commit_created=false`, `source_issuance=NOT_RUN`.

**Таблица 1. Единственные изменения версии 2.**

| Элемент | Исходная версия | Версия 2 |
|---|---|---|
| Установленные шаблоны Git | `mingw64/share/git-core/templates` | `ucrt64/share/git-core/templates` |
| Runner | `a5-prep/run_source.py` | `a5-prep/run_source_v2.py` |
| Plan | `a5-prep/prepare-plan.json` | `a5-prep/prepare-plan-v2.json` |
| Новый рабочий каталог | `a5-work` | `a5-work-v2` |
| Новая фаза evidence/runtime | `a5-source-preparation` | `a5-source-preparation-v2` |

Полный [diff](runner-v2.diff) содержит только эти строки. Plan меняет
только `runner_sha256`. Все 121 входной файл, retained master ZIP,
исходное дерево, Git/Go pins, команды, stderr/exit/hash oracles,
владельцы процессов и поведение при ошибках сохранены.

**Таблица 2. Контрольные суммы версии 2.**

| Файл | Байты | SHA-256 |
|---|---:|---|
| `run_source_v2.py` | 29686 | `92a51464012c9d58adb3e6e670a2baf04afa1dbcce6c067c78b5aa9100d2bf39` |
| `prepare-plan-v2.json` | 25177 | `7fd1ca879c303b747775837f667fafb93d281b3f630363245533c96558f2cda6` |
| `v2-control.b64` | 31872 | `a54583d1b5ccd1036dcfe5d938fec316af8e981740b6d4bb3df421782ff711e5` |

Контрольный payload содержит только два новых файла. Первоначальные
121 входов и ZIP повторно не передаются. Точный вызов из фиксированного
корня `D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba`:

```text
a5-prep/run_source_v2.py a5-prep/prepare-plan-v2.json 7fd1ca879c303b747775837f667fafb93d281b3f630363245533c96558f2cda6
```

При успешном исполнении активные checkout/export/snapshot/helper,
runtime и evidence версии 2 остаются вне trash. Оба конечных признака
успеха обязательны: `completed=true` и `source_issuance=PASS`.
Этот документ фиксирует исправление причины первого отказа и сам по
себе не является квитанцией исполнения версии 2.
