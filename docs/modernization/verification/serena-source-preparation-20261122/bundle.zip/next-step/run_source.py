"""Create the exact isolated Git source and run only its Source preparation helper.

Windows-only, hash-bound plan, fixed tools and fixed operation sequence. This
runner never starts Product, Serena, tests, an installer, or an arbitrary command.
The existing qualification environment owner is imported unchanged.
"""
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import time
import zipfile


ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
GIT_SHA = "177bc8a9af84fa3a400c694c975fda731d048279c074e1a93947ce8b067ebb48"
GO_SHA = "0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113"
QUALIFIER_SHA = "a483536d689df8c5713fddbdfd221b85953cf0ce4f9d578a31c4cdbfc6b9a26e"
BASE = "75dbc6406123e22468f168b861d5e0622c9d5769"
BASE_TREE = "cb3eec77c23f9400be962d91c9f23834b84f7643"
TREE = "8928e54342bc700b07f977a1d8f22bbaf986ad04"
IDENTITY_SOURCE = "8fc6780873e8d2580ea889c572535c5fb8a430dd"
URL = "https://codeload.github.com/applicate2628/mcp-local-hub/zip/" + BASE
PREFIX = "mcp-local-hub-" + BASE + "/"
ARCHIVE_PATH = "a5-prep/master-download/master.zip"
ARCHIVE_SHA = "2e688e6e1e84cc062b3213a50f59f8cad61fac730a2afe44ecaba7f2937d09ac"
ARCHIVE_BYTES = 17461518
FETCH_SHA = "4e8dcc0b69479946f494ce3001de7930c2d4ddb78baf54b3e794809a97684f37"
INPUTS = "a5-prep/inputs"
WORK = "a5-work"
SOURCE = WORK + "/checkout"
PHASE = "a5-source-preparation"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise RuntimeError("Reparse point refused: " + str(path))
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise RuntimeError("Unexpected physical file kind: " + str(path))
    return info


def inventory(raw, count):
    rows = json.loads(raw)
    seen, folded = set(), set()
    for row in rows:
        name = row["path"]
        path = PurePosixPath(name)
        if (not name or not name.isascii() or path.is_absolute() or path.as_posix() != name or
                any(part in (".", "..") or part.lower() == ".git" or part.endswith((".", " ")) for part in path.parts) or
                any(char in name for char in "\\:\0\r\n") or name in seen or name.lower() in folded or
                row["mode"] != "100644" or type(row["bytes"]) is not int or row["bytes"] < 0 or
                re.fullmatch(r"[0-9a-f]{40}", row["blob"]) is None or re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) is None):
            raise RuntimeError("Invalid pinned inventory row")
        seen.add(name)
        folded.add(name.lower())
    if len(rows) != count or rows != sorted(rows, key=lambda row: row["path"]):
        raise RuntimeError("Pinned inventory count/order differs")
    return rows


def index_bytes(rows):
    return b"".join((row["mode"] + " " + row["blob"] + "\t" + row["path"]).encode() + b"\0" for row in rows)


def path_bytes(names):
    return "".join(json.dumps(name, ensure_ascii=False) + "\n" for name in names).encode()


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 3:
        raise RuntimeError("Use normal Python on Comet with the exact reviewed plan SHA-256")
    for ancestor in (*reversed(ROOT.parents), ROOT):
        ordinary(ancestor, True)
    qualifier = ROOT / "qualify_go.py"
    if sha(qualifier.read_bytes()) != QUALIFIER_SHA:
        raise RuntimeError("Existing qualification environment owner changed")
    spec = importlib.util.spec_from_file_location("a5_existing_qualification", qualifier)
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    if Path(__file__).resolve() != q.own("a5-prep/run_source.py") or sys.argv[1] != "a5-prep/prepare-plan.json":
        raise RuntimeError("Unexpected runner or plan location")
    raw_plan = q.own(sys.argv[1]).read_bytes()
    if sha(raw_plan) != sys.argv[2]:
        raise RuntimeError("Plan differs from caller's reviewed hash")
    plan = json.loads(raw_plan)
    if (plan.get("schema") != "serena-source-preparation-plan-v1" or
            plan.get("runner_sha256") != sha(Path(__file__).read_bytes()) or
            plan.get("qualification_owner_sha256") != QUALIFIER_SHA or
            plan.get("base_commit") != BASE or plan.get("base_tree") != BASE_TREE or
            plan.get("composed_tree") != TREE or plan.get("source_url") != URL or
            plan.get("master_archive") != {"path": ARCHIVE_PATH, "bytes": ARCHIVE_BYTES, "sha256": ARCHIVE_SHA} or
            plan.get("product_or_serena_execution") is not False or plan.get("installs") is not False):
        raise RuntimeError("Unadmitted source-preparation scope")

    def pinned_inputs():
        for row in plan["input_files"]:
            target = q.own(row["path"])
            ordinary(target)
            raw = target.read_bytes()
            if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
                raise RuntimeError("Input changed: " + row["path"])

    def input_raw(name):
        return q.own(INPUTS + "/" + name).read_bytes()

    pinned_inputs()
    archive = q.own(ARCHIVE_PATH)
    ordinary(archive)
    if archive.stat().st_size != ARCHIVE_BYTES or sha(archive.read_bytes()) != ARCHIVE_SHA:
        raise RuntimeError("Retained master archive differs from the actual fetch receipt")
    fetch_receipt_path = q.own("a5-prep/master-download/receipt.json")
    fetch_receipt_raw = fetch_receipt_path.read_bytes()
    fetched = json.loads(fetch_receipt_raw)
    expected_zip_metadata = [
        {"kind": "directory", "create_system": 0, "external_attr": 16, "upper_mode": 0, "count": 187},
        {"kind": "file", "create_system": 0, "external_attr": 0, "upper_mode": 0, "count": 3270},
    ]
    if (fetched.get("completed") is not True or fetched.get("source_commit") != BASE or fetched.get("url") != URL or
            fetched.get("script_sha256") != FETCH_SHA or fetched.get("archive") != plan["master_archive"] or
            fetched.get("zip_metadata") != expected_zip_metadata or fetched.get("archive_extracted") is not False or
            fetched.get("subprocesses_started") is not False or fetched.get("installs") is not False):
        raise RuntimeError("Retained fetch receipt differs from the reviewed source acquisition")
    manifest = json.loads(input_raw("manifest.json"))
    base = inventory(input_raw("base-files.json"), 3270)
    full = inventory(input_raw("source-files.json"), 3323)
    if (manifest["base"]["ref"] != BASE or manifest["base"]["tree"] != BASE_TREE or
            manifest["full_source"]["git_tree"] != TREE or manifest["full_source"]["file_count"] != 3323 or
            sha(input_raw("source-files.json")) != manifest["full_source"]["inventory_sha256"] or
            sum(row["bytes"] for row in full) != 50823826):
        raise RuntimeError("Composed source identity changed")
    deltas = {row["path"]: row for row in manifest["files"]}
    if len(deltas) != 109 or sorted(deltas) != manifest["selection"]["paths"]:
        raise RuntimeError("Delta path set changed")
    required = {INPUTS + "/" + name for name in (
        "manifest.json", "base-files.json", "source-files.json", "base-index.bin", "composed-index.bin",
        "base-paths.txt", "delta-paths.txt", "base-shallow.txt", "base-commit.raw",
        "identity-source-commit.raw", "identity.json", "COMMIT_MESSAGE.txt",
    )} | {INPUTS + "/deltas/" + name for name in deltas}
    if {row["path"] for row in plan["input_files"]} != required or len(plan["input_files"]) != len(required):
        raise RuntimeError("Execution plan does not bind the complete exact input set")
    if (input_raw("base-index.bin") != index_bytes(base) or input_raw("composed-index.bin") != index_bytes(full) or
            input_raw("base-paths.txt") != path_bytes(row["path"] for row in base) or
            input_raw("delta-paths.txt") != path_bytes(sorted(deltas)) or
            input_raw("base-shallow.txt") != (BASE + "\n").encode() or
            git_oid("commit", input_raw("base-commit.raw")) != BASE):
        raise RuntimeError("Git metadata input differs")
    identity_raw = input_raw("identity-source-commit.raw")
    identity = json.loads(input_raw("identity.json"))
    if (git_oid("commit", identity_raw) != IDENTITY_SOURCE or identity["source_commit"] != IDENTITY_SOURCE or
            identity["source_raw_sha256"] != sha(identity_raw)):
        raise RuntimeError("Publication identity source changed")
    for role in ("author", "committer"):
        match = re.search(rb"(?m)^" + role.encode() + rb" (.+) <([^<>\r\n]+)> (\d+) ([+-]\d{4})$", identity_raw.split(b"\n\n", 1)[0])
        if not match or (match[1].decode(), match[2].decode()) != (identity[role]["name"], identity[role]["email"]):
            raise RuntimeError("Identity is not the existing publication's actual metadata")

    for name in (WORK, "evidence/" + PHASE, "runtime/" + PHASE):
        if q.own(name).exists():
            raise RuntimeError("Fresh destination already exists; preserve it: " + name)
    work = q.own(WORK); work.mkdir()
    out = q.own("evidence/" + PHASE); out.mkdir(parents=True)
    runtime = q.own("runtime/" + PHASE); runtime.mkdir(parents=True)
    source = q.own(SOURCE)
    helper = q.own(WORK + "/bin/source-prepare-helper.exe")
    export = q.own(WORK + "/export")
    snapshot = q.own(WORK + "/source-snapshot.json")
    receipt = {"schema": 1, "phase": PHASE, "started_utc": q.now(), "plan_sha256": sha(raw_plan),
               "runner_sha256": plan["runner_sha256"], "base_commit": BASE, "base_tree": BASE_TREE,
               "source_tree": TREE, "commands": [], "completed": False, "source_commit_created": False,
               "source_issuance": "NOT_RUN", "tests": "NOT_RUN", "product_or_serena_execution": False,
               "installs": False, "native_scheduler_operations": False, "active_work_retained_outside_trash": True}
    q.save(out / "receipt-initial.json", receipt)
    env = None
    try:
        env = q.environment(runtime, {})
        env["PATH"] = str(GIT.parent) + os.pathsep + env["PATH"]
        env.update(GIT_NO_LAZY_FETCH="1", GIT_ASKPASS="", GCM_INTERACTIVE="never")
        receipt["environment"] = {key: env[key] for key in sorted(env) if key.startswith(("GO", "GIT_", "MCPHUB_", "XDG_")) or key in ("PATH", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "CC")}
        tools = {**q.PINS, str(GIT): GIT_SHA}
        if q.PINS[str(q.GO)] != GO_SHA:
            raise RuntimeError("Go pin changed")
        for path, digest in tools.items():
            if sha(Path(path).read_bytes()) != digest:
                raise RuntimeError("Admitted tool changed: " + path)
        if Path(shutil.which("git", path=env["PATH"]) or "").resolve() != GIT.resolve():
            raise RuntimeError("Helper's Git resolution is not the admitted executable")
        receipt["tools_sha256"] = tools

        def native(label, executable, args, cwd, stdin=None, expected=(0,), timeout=60, extra_env=None):
            if executable not in (GIT, helper) or not re.fullmatch(r"[a-z][a-z0-9-]+", label):
                raise RuntimeError("Unadmitted native tool or label")
            if executable == helper and label not in ("prepare-source", "verify-source-readback"):
                raise RuntimeError("Helper has no general execution mode")
            if executable == helper:
                exact = (["--prepare-source", str(export), "--source-checkout", str(source),
                          "--source-snapshot-output", str(snapshot), "--expected-commit", receipt["source_commit"]]
                         if label == "prepare-source" else ["--source-snapshot", str(snapshot), "--source-root", str(export)])
                if args != exact:
                    raise RuntimeError("Helper argv differs from its two exact source-only operations")
            digest = GIT_SHA if executable == GIT else receipt["helper_sha256"]
            if sha(executable.read_bytes()) != digest:
                raise RuntimeError("Native executable changed")
            row = {"label": label, "argv": [str(executable), *args], "cwd": str(cwd), "started_utc": q.now(),
                   "executable_sha256": digest, "direct_timeout_seconds": timeout, "settled": False,
                   "timed_out": False, "whole_process_tree_deadline_enforced": False}
            input_path = out / (label + ".stdin.bin")
            if stdin is not None:
                with input_path.open("xb") as stream: stream.write(stdin)
                row["stdin"] = {"bytes": len(stdin), "sha256": sha(stdin)}
            q.save(out / (label + ".started.json"), row)
            child = None
            input_stream = None
            started = time.monotonic()
            try:
                input_stream = input_path.open("rb") if stdin is not None else None
                with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
                    child_env = dict(env)
                    if extra_env:
                        if set(extra_env) != {"GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_AUTHOR_DATE", "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL", "GIT_COMMITTER_DATE"}:
                            raise RuntimeError("Unadmitted commit metadata environment")
                        child_env.update(extra_env)
                    child = subprocess.Popen(row["argv"], cwd=cwd, env=child_env,
                                             stdin=input_stream if input_stream is not None else subprocess.DEVNULL,
                                             stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
                    row["pid"] = child.pid
                    q.save(out / (label + ".launched.json"), row)
                    row["exit_code"] = child.wait(timeout=timeout)
                    row["settled"] = True
            except BaseException as error:
                row.update(error_type=type(error).__name__, error=str(error))
                row["timed_out"] = isinstance(error, subprocess.TimeoutExpired)
                raise
            finally:
                if child is not None and not row["settled"]:
                    row.update(process_tree_unresolved=True, retain_runtime_and_logs=True,
                               termination_method="Popen.terminate on the retained original direct-child handle")
                    try:
                        child.terminate(); row["exit_code"] = child.wait(timeout=10); row["settled"] = True
                    except BaseException as error:
                        row["termination_error"] = type(error).__name__ + ": " + str(error)
                if input_stream is not None: input_stream.close()
                for name in ("stdout", "stderr"):
                    target = out / (label + "." + name + ".log")
                    if target.exists():
                        raw = target.read_bytes(); row[name] = {"bytes": len(raw), "sha256": sha(raw)}
                row.update(seconds=time.monotonic() - started, finished_utc=q.now(), executable_hash_after=sha(executable.read_bytes()))
                row["oracle_pass"] = row["settled"] and not row["timed_out"] and not row.get("error_type") and row.get("exit_code") in expected and row["executable_hash_after"] == digest
                if executable == helper:
                    row["oracle_pass"] = row["oracle_pass"] and row.get("stderr", {}).get("bytes") == 0
                q.save(out / (label + ".receipt.json"), row)
                receipt["commands"].append(row)
                print(json.dumps({"label": label, "exit_code": row.get("exit_code"), "oracle_pass": row["oracle_pass"]}), flush=True)
            if not row["oracle_pass"]:
                raise RuntimeError("Native command failed its declared result: " + label)
            return (out / (label + ".stdout.log")).read_bytes()

        prefix = ["--no-pager", "--no-optional-locks", "--no-replace-objects", "--literal-pathspecs",
                  "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", "-c", "protocol.allow=never"]

        def git(label, args, stdin=None, expected=(0,), extra_env=None):
            if args[0] not in {"config", "hash-object", "update-index", "write-tree", "commit-tree", "update-ref",
                               "symbolic-ref", "rev-parse", "rev-list", "ls-files", "ls-tree", "status", "fsck"}:
                raise RuntimeError("Unadmitted Git operation")
            return native(label, GIT, [*prefix, "-C", str(source), *args], source, stdin, expected, extra_env=extra_env)

        version = native("git-version", GIT, ["--version"], ROOT)
        if version.strip() != b"git version 2.56.1.windows.1":
            raise RuntimeError("Git version differs from the admitted receipt")
        # Preserve the installed template unchanged. Real hooks or configuration
        # additions require investigation; this runner never disables them.
        template = GIT.parent.parent / "mingw64/share/git-core/templates"
        ordinary(template, True)
        template_rows = []
        for path in sorted(template.rglob("*")):
            info = path.lstat()
            ordinary(path, stat.S_ISDIR(info.st_mode))
            if path.is_dir(): continue
            name = path.relative_to(template).as_posix()
            if name not in ("description", "info/exclude") and not (name.startswith("hooks/") and name.endswith(".sample") and name.count("/") == 1):
                raise RuntimeError("Installed Git template has an unreviewed file or real hook: " + name)
            raw = path.read_bytes(); template_rows.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
        receipt["installed_git_template"] = {"path": str(template), "files": template_rows}

        receipt["master_archive"] = {"url": URL, "path": ARCHIVE_PATH, "bytes": ARCHIVE_BYTES, "sha256": ARCHIVE_SHA,
                                     "retained_outside_trash": True, "zip_metadata": expected_zip_metadata,
                                     "fetch_receipt_sha256": sha(fetch_receipt_raw)}
        wanted = {row["path"]: row for row in base}
        expected_dirs = {""}
        for name in wanted:
            expected_dirs.update(str(parent) for parent in PurePosixPath(name).parents if str(parent) != ".")
        contents, seen = {}, set()
        directory_count = 0
        with zipfile.ZipFile(archive) as zipped:
            for entry in zipped.infolist():
                if entry.filename in seen or not entry.filename.startswith(PREFIX) or entry.flag_bits & 1:
                    raise RuntimeError("Unadmitted master ZIP entry")
                seen.add(entry.filename)
                name = entry.filename[len(PREFIX):]
                # The retained codeload has DOS metadata, not Unix mode bits.
                # Admit exactly the observed attributes; Git mode is pinned by
                # the independent inventory and both actual write-tree results.
                if entry.is_dir():
                    if name[:-1] not in expected_dirs or entry.create_system != 0 or entry.external_attr != 0x10 or entry.file_size != 0:
                        raise RuntimeError("Unadmitted DOS source directory")
                    directory_count += 1
                    continue
                if name not in wanted or entry.create_system != 0 or entry.external_attr != 0 or entry.file_size != wanted[name]["bytes"]:
                    raise RuntimeError("Master ZIP path, mode, or size differs")
                raw = zipped.read(entry)
                if sha(raw) != wanted[name]["sha256"] or git_oid("blob", raw) != wanted[name]["blob"]:
                    raise RuntimeError("Master ZIP content differs: " + name)
                contents[name] = raw
        if set(contents) != set(wanted) or directory_count != 187:
            raise RuntimeError("Master ZIP file set differs")
        source.mkdir()
        for name, raw in sorted(contents.items()):
            target = q.own(SOURCE + "/" + name); target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream: stream.write(raw)
        receipt["base_physical"] = q.check_files(SOURCE, base, True)
        native("git-init", GIT, [*prefix, "init", "--initial-branch=serena-source-only", "--template=" + str(template), str(source)], ROOT)
        metadata = source / ".git"; ordinary(metadata, True)
        for setting in ("core.hooksPath", "commit.gpgSign", "init.templateDir"):
            value = git("git-config-" + setting.replace(".", "-").lower(), ["config", "--get", setting], expected=(0, 1))
            if value.strip():
                raise RuntimeError("Unexpected configured Git hook, signing, or template policy: " + setting)
        git("git-config-crlf", ["config", "--local", "core.autocrlf", "false"])
        if git("git-import-base-blobs", ["hash-object", "-w", "--no-filters", "--stdin-paths"], input_raw("base-paths.txt")).decode().splitlines() != [row["blob"] for row in base]:
            raise RuntimeError("Imported base blobs differ")
        git("git-index-base", ["update-index", "-z", "--index-info"], input_raw("base-index.bin"))
        if git("git-tree-base", ["write-tree"]).strip().decode() != BASE_TREE:
            raise RuntimeError("Actual Git base tree differs")
        if git("git-import-base-commit", ["hash-object", "-w", "-t", "commit", "--stdin"], input_raw("base-commit.raw")).strip().decode() != BASE:
            raise RuntimeError("Actual base commit differs")
        # This is the only direct metadata-file write. The new standalone repo
        # retains the exact original base commit at an explicit shallow boundary.
        with (metadata / "shallow").open("xb") as stream: stream.write(input_raw("base-shallow.txt"))
        for name, entry in sorted(deltas.items()):
            raw = input_raw("deltas/" + name)
            if len(raw) != entry["output"]["bytes"] or sha(raw) != entry["output"]["sha256"] or git_oid("blob", raw) != entry["output"]["blob"]:
                raise RuntimeError("Delta bytes differ: " + name)
            target = q.own(SOURCE + "/" + name); target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("wb" if name in wanted else "xb") as stream: stream.write(raw)
        receipt["composed_physical_before_commit"] = q.check_files(SOURCE, full, True)
        if git("git-import-delta-blobs", ["hash-object", "-w", "--no-filters", "--stdin-paths"], input_raw("delta-paths.txt")).decode().splitlines() != [deltas[name]["output"]["blob"] for name in sorted(deltas)]:
            raise RuntimeError("Imported delta blobs differ")
        git("git-index-composed", ["update-index", "-z", "--index-info"], input_raw("composed-index.bin"))
        if git("git-tree-composed", ["write-tree"]).strip().decode() != TREE:
            raise RuntimeError("Actual composed Git tree differs")
        commit_date = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        commit_env = {"GIT_AUTHOR_NAME": identity["author"]["name"], "GIT_AUTHOR_EMAIL": identity["author"]["email"], "GIT_AUTHOR_DATE": commit_date,
                      "GIT_COMMITTER_NAME": identity["committer"]["name"], "GIT_COMMITTER_EMAIL": identity["committer"]["email"], "GIT_COMMITTER_DATE": commit_date}
        commit = git("git-create-source-commit", ["commit-tree", TREE, "-p", BASE, "-F", str(q.own(INPUTS + "/COMMIT_MESSAGE.txt"))], extra_env=commit_env).strip().decode()
        if re.fullmatch(r"[0-9a-f]{40}", commit) is None:
            raise RuntimeError("Git did not return a commit identity")
        receipt.update(source_commit_created=True, source_commit=commit, commit_metadata=commit_env, identity_source_commit=IDENTITY_SOURCE, history_boundary=BASE)
        q.save(out / "source-commit-created.json", {key: receipt[key] for key in ("source_commit", "source_tree", "commit_metadata", "identity_source_commit", "history_boundary")})
        git("git-bind-source-ref", ["update-ref", "refs/heads/serena-source-only", commit, "0" * 40])
        git("git-bind-head", ["symbolic-ref", "HEAD", "refs/heads/serena-source-only"])
        if git("git-read-head", ["rev-parse", "--verify", "HEAD"]).strip().decode() != commit:
            raise RuntimeError("HEAD differs from the new source commit")
        if git("git-read-tree", ["rev-parse", "--verify", commit + "^{tree}"]).strip().decode() != TREE:
            raise RuntimeError("Committed tree differs")
        if git("git-read-parent", ["rev-list", "--parents", "-n", "1", "HEAD"]).decode().split() != [commit, BASE]:
            raise RuntimeError("Source commit parent differs")
        expected_index = b"".join((row["mode"] + " " + row["blob"] + " 0\t" + row["path"]).encode() + b"\0" for row in full)
        if git("git-read-index", ["ls-files", "--stage", "-z", "--cached"]) != expected_index:
            raise RuntimeError("Committed index differs")
        expected_tree = b"".join((row["mode"] + " blob " + row["blob"] + "\t" + row["path"]).encode() + b"\0" for row in full)
        if git("git-read-leaves", ["ls-tree", "-r", "-z", "--full-tree", "HEAD"]) != expected_tree:
            raise RuntimeError("Committed leaves differ")
        if git("git-clean-status", ["status", "--porcelain=v1", "--untracked-files=all"]):
            raise RuntimeError("Source checkout is not clean")
        git("git-object-closure", ["fsck", "--strict", "--no-reflogs"])
        receipt["source_before_helper"] = q.check_files(SOURCE, full, True)
        helper.parent.mkdir()
        build = q.execute(out, env, {"label": "build-source-helper", "tool": "go",
                                    "args": ["build", "-mod=readonly", "-buildvcs=false", "-o", str(helper), "./tools/windows-product-validate"],
                                    "timeout_seconds": 900, "expected_exit_code": 0}, source)
        receipt["commands"].append(build)
        if not build["oracle_pass"]:
            raise RuntimeError("Source helper build failed")
        ordinary(helper)
        receipt["helper_sha256"] = sha(helper.read_bytes())
        receipt["source_after_helper_build"] = q.check_files(SOURCE, full, True)
        prepared_raw = native("prepare-source", helper,
                              ["--prepare-source", str(export), "--source-checkout", str(source),
                               "--source-snapshot-output", str(snapshot), "--expected-commit", commit], source, timeout=600)
        prepared = json.loads(prepared_raw)
        value = prepared.get("source_input", {})
        if (prepared.get("schema") != "windows-publisher-source-preparation-v1" or prepared.get("git_commit") != commit or
                prepared.get("git_tree") != TREE or prepared.get("dirty_selected_source") is not False or
                value.get("schema") != "windows-publisher-source-input-v1" or value.get("file_count") != 3323 or
                re.fullmatch(r"[0-9a-f]{64}", value.get("source_epoch", "")) is None or
                value.get("source_snapshot_sha256") != sha(snapshot.read_bytes())):
            raise RuntimeError("PreparePublisherSource result failed the exact source contract")
        receipt["source_preparation"] = prepared
        receipt["export"] = q.check_files(WORK + "/export", full, True)
        readback = json.loads(native("verify-source-readback", helper,
                                    ["--source-snapshot", str(snapshot), "--source-root", str(export)], source, timeout=300))
        if readback != value:
            raise RuntimeError("Native source readback differs from the original issuer result")
        receipt.update(source_issuance="PASS", source_input_readback=readback)
        if git("git-clean-after-preparation", ["status", "--porcelain=v1", "--untracked-files=all"]):
            raise RuntimeError("Checkout changed during helper work")
        receipt["source_after"] = q.check_files(SOURCE, full, True)
        pinned_inputs()
        if archive.stat().st_size != ARCHIVE_BYTES or sha(archive.read_bytes()) != ARCHIVE_SHA:
            raise RuntimeError("Retained master archive changed during execution")
        if fetch_receipt_path.read_bytes() != fetch_receipt_raw:
            raise RuntimeError("Retained source acquisition receipt changed during execution")
        if sha(Path(__file__).read_bytes()) != plan["runner_sha256"] or q.own(sys.argv[1]).read_bytes() != raw_plan:
            raise RuntimeError("Runner or plan changed during execution")
        for path, digest in tools.items():
            if sha(Path(path).read_bytes()) != digest:
                raise RuntimeError("Tool changed during execution: " + path)
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = q.now()
        receipt["preserved_paths"] = {"checkout": str(source), "export": str(export), "snapshot": str(snapshot), "helper": str(helper), "runtime": str(runtime), "evidence": str(out)}
        q.save(out / "receipt.json", receipt)
        print(json.dumps({key: receipt.get(key) for key in ("phase", "completed", "source_commit_created", "source_commit", "source_issuance", "error")}), flush=True)


if __name__ == "__main__":
    main()
