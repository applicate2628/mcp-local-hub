"""Fetch one exact source archive and report its bytes/ZIP metadata; no execution."""
import sys
sys.dont_write_bytecode = True
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import time
import urllib.request
import zipfile

ROOT = Path(r"D:\dev\ChatGPT\mcp-residual-next-20261122-dcb40fba")
BASE = "75dbc6406123e22468f168b861d5e0622c9d5769"
URL = "https://codeload.github.com/applicate2628/mcp-local-hub/zip/" + BASE


def main():
    if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 2:
        raise RuntimeError("Use normal Windows Python with the reviewed script SHA-256")
    script = Path(__file__)
    if script.resolve() != ROOT / "a5-prep/fetch_master.py" or hashlib.sha256(script.read_bytes()).hexdigest() != sys.argv[1]:
        raise RuntimeError("Unreviewed fetch script or location")
    for path in (*reversed(ROOT.parents), ROOT, ROOT / "a5-prep"):
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Source-input parent is not an ordinary directory")
    out = ROOT / "a5-prep/master-download"
    out.mkdir(exist_ok=False)
    receipt = {"schema": 1, "source_commit": BASE, "url": URL, "script_sha256": sys.argv[1],
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "completed": False, "project_code_executed": False, "subprocesses_started": False,
               "installs": False, "archive_extracted": False}
    try:
        archive = out / "master.zip"
        request = urllib.request.Request(URL, headers={"User-Agent": "mcphub-source-preparation", "Accept-Encoding": "identity"})
        started = time.monotonic()
        with urllib.request.urlopen(request, timeout=30) as response, archive.open("xb") as stream:
            if response.status != 200 or response.geturl() != URL:
                raise RuntimeError("Pinned source response changed URL or status")
            total = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk: break
                total += len(chunk)
                if total > 128 * 1024 * 1024 or time.monotonic() - started > 300:
                    raise RuntimeError("Source download exceeded byte/time bound")
                stream.write(chunk)
        receipt["archive"] = {"path": "a5-prep/master-download/master.zip", "bytes": archive.stat().st_size,
                              "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
        metadata = Counter()
        with zipfile.ZipFile(archive) as zipped:
            for entry in zipped.infolist():
                metadata[("directory" if entry.is_dir() else "file", entry.create_system, entry.external_attr, entry.external_attr >> 16)] += 1
        receipt["zip_metadata"] = [{"kind": kind, "create_system": creator, "external_attr": attrs, "upper_mode": mode, "count": count}
                                   for (kind, creator, attrs, mode), count in sorted(metadata.items())]
        receipt["completed"] = True
    except BaseException as error:
        receipt.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (out / "receipt.json").open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(receipt, stream, indent=2); stream.write("\n")
        print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
