#!/usr/bin/env python3
"""Verify this local candidate's bytes and scope; does not run Go or processes."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def verify():
    if sys.flags.optimize:
        raise RuntimeError("Run without Python optimization; assertion checks must stay enabled")
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    expected_paths = {"internal/cli/gui_force_test.go", "internal/gui/test_seams.go"}
    actual_paths = {p.relative_to(root).as_posix() for p in (root / "internal").rglob("*") if p.is_file()}
    assert actual_paths == expected_paths, (actual_paths, expected_paths)
    patch = []
    for row in manifest["files"]:
        path = row["path"]
        before = (root / "base" / path).read_bytes()
        after = (root / path).read_bytes()
        for data, key in ((before, "base"), (after, "candidate")):
            assert len(data) == row[key]["bytes"], (path, key, "length")
            assert sha256(data) == row[key]["sha256"], (path, key, "sha256")
            assert git_blob(data) == row[key]["git_blob"], (path, key, "blob")
        patch.extend(difflib.unified_diff(before.decode("utf-8").splitlines(True), after.decode("utf-8").splitlines(True), fromfile="a/" + path, tofile="b/" + path))
    assert (root / "candidate.patch").read_bytes() == "".join(patch).encode("utf-8")

    original = (root / "base/internal/cli/gui_force_test.go").read_bytes().decode("utf-8")
    candidate = (root / "internal/cli/gui_force_test.go").read_bytes().decode("utf-8")
    recovered = candidate.replace('\t"sync"\n', "", 1)
    start = recovered.index("// startForceKillTestSleeper")
    end = recovered.index("// ---------------------------------------------------------------", start)
    recovered = recovered[:start] + recovered[end:]
    for name in manifest["scope"]["changed_existing_tests"]:
        pattern = r"(?ms)^func " + re.escape(name) + r"\(.*?^}"
        body = re.search(pattern, original).group()
        recovered = re.sub(pattern, lambda _: body, recovered, count=1)
    assert recovered == original, "Non-target test file bytes changed"
    assert sha256(recovered.encode("utf-8")) == manifest["scope"]["recovered_base_sha256"]

    for row in manifest["artifacts"]:
        data = (root / row["path"]).read_bytes()
        assert len(data) == row["bytes"], row["path"]
        assert sha256(data) == row["sha256"], row["path"]
    plan = json.loads((root / "test-plan.json").read_text(encoding="utf-8"))
    assert not plan["execution_performed"]
    assert plan["actual_native_powershell_pin"]["sha256"] is None
    print(json.dumps({"status": "STATIC_BYTES_AND_SCOPE_VERIFIED", "source_files": len(expected_paths), "base_commit": manifest["base_commit"], "go_executed": False, "native_executed": False}, indent=2))


if __name__ == "__main__":
    verify()
