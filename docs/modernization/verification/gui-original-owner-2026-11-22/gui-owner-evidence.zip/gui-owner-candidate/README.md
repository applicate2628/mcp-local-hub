# GUI force-kill: локальный кандидат владения тестовым процессом

**Статус: локальный кандидат для review; Go, gofmt, тесты и native-команды не запускались.** Основание — canonical commit [`97ff6da0c428a8c30f1952da470e3ff033a740e4`](https://github.com/applicate2628/mcp-local-hub/commit/97ff6da0c428a8c30f1952da470e3ff033a740e4), tree `3a0973ee5242f5248908bf7a16954de6cea9600f`. Публикаций и изменений refs нет. Текущий head PR #664 — `9ca27f6734ec3587ad0bd155d81d22b1a4960b84`; по квалифицированному сообщению root после этой codebase изменились только документы. Кандидат сохраняет точное основание исходников `97ff6da0`.

## Оглавление

1. [Изменение и сохранённые проверки](#изменение-и-сохранённые-проверки)
2. [Проверенный граф вызовов и эффекты](#проверенный-граф-вызовов-и-эффекты)
3. [План проверки](#план-проверки)
4. [Пределы выводов и собственное review](#пределы-выводов-и-собственное-review)
5. [Артефакты](#артефакты)

## Изменение и сохранённые проверки

Изменены только `internal/cli/gui_force_test.go` и `internal/gui/test_seams.go`. Первый файл содержит две исправленные постановки теста, один общий для них владелец sleep-процесса, небольшой классификатор ожидаемой отмены команды и семь чистых отрицательных/положительных проверок классификатора. Второй добавляет один setter с возвратом restore-функции над **существующим** `killProcessOverride`; новых глобальных переменных нет. Это accessor в production-компилируемом файле test seams, а не изолированный build tag.

`startForceKillTestSleeper` сохраняет исходные `*exec.Cmd` и `Cmd.Process`. После успешного `Start` ровно одна горутина вызывает `Cmd.Wait` и закрывает `holderDone`. Kill seam проверяет числовой PID, но действие выполняет только через сохранённый `Cmd.Process.Kill`; поиск процесса по PID не используется. `sync.Once` объединяет основной stop и аварийный cleanup; оба получают один результат Wait. Срабатывание 30-секундного watchdog, ранний выход helper, ошибка Kill или неожиданный результат Wait проваливают тест. Watchdog тоже принадлежит этому `Cmd`; он не даёт гарантию ограниченного времени всего дерева процессов.

**Таблица 1. Оракулы — проверяемые условия успешности.**

| Тест | Сохранённое условие | Новые обязательные свидетельства |
|---|---|---|
| `TestForce_KillRewritesPidportWithCurrentPID` | Пока GUI активен, pidport содержит текущий PID и заранее выбранный явный `freePort`; исходный holder имел другой PID и port=1. Сохраняется ветвь actualPort==requestedPort. | Kill seam вызван ровно один раз; `Cmd.Wait` завершён до завершения takeover; исходный родительский flock отпускается только после Wait; `ExecuteContext` присоединён до восстановления seam и очистки fixture. |
| `TestForce_KillRaceLost` | Типизированный код завершения 3 после проигранного повторного захвата flock. | Kill seam вызван ровно один раз; Wait уже завершён при входе в post-kill hook; hook вызван ровно один раз; исходный flock успешно отпущен и конкурент действительно захватил свой flock. Ранний DeadPID либо ошибка постановки не проходят. |

Оба теста устанавливают существующие `MCPHUB_E2E_SUPERVISOR=none`, `MCPHUB_E2E_SCHEDULER=none`, очищают `selfRestartHandoffEnv` и сохраняют `--no-browser --no-tray`. В Rewrite предыдущий post-kill hook временно очищается, в RaceLost устанавливается собственный. Restore выполняется после присоединения команды и дочернего процесса. Ordinary `TestMain`, остальные тесты и production алгоритм `KillRecordedHolder` не изменены.

Ожидаемая отмена GUI допускается только если **все** конечные причины ошибки равны `context.Canceled`. Простое `errors.Is(err, context.Canceled)` скрывало бы соседнюю ошибку cleanup в `errors.Join`; чистый тест отдельно проверяет эти сочетания. Дедлайн не считается обычной отменой.

## Проверенный граф вызовов и эффекты

Прочитаны достигаемые application-ветви двух точных селекторов, исходный ordinary `TestMain`, GUI startup/termination, подмена kill, платформенные probe, файловые блокировки и ближайшие владельцы состояния. Установленные, но не вызываемые HTTP handlers не считаются выполненными действиями. Точные Git blob и immutable ссылки всех прочитанных файлов находятся в [source-receipt.json](source-receipt.json).

**Таблица 2. Эффекты, которые будущий native-запуск должен учитывать.**

| Этап | Фактическая цепочка и граница |
|---|---|
| Вход в тестовый бинарник | Canonical `settings_registry_test.go:292–510`: при отсутствии helper markers проходит ordinary `TestMain`, создаёт отдельный временный root, защищает его DACL, устанавливает in-memory `SetDaemonStateRootForTest`, client-config sandbox, тестовую изоляцию IPC, browser suppression и audit путей. После `m.Run` восстанавливает окружение и удаляет **свой точный root**. Это существующая очистка теста; кандидат её не меняет. |
| Создание fixture | `apitest.HardenedTempDir`: отдельный `t.TempDir()/hardened-parent`, защищённый DACL Windows либо 0700 POSIX. PowerShell/sleep разрешается через Go `exec.LookPath`, приводится к абсолютному пути и один раз запускается через `exec.CommandContext`. На Windows argv остаётся `-NoProfile -NonInteractive -NoExit -Command "Start-Sleep -Seconds 60"`. Профиль, временные файлы и module cache должны быть направлены в выделенную D-область родительским runner. |
| Cobra/initial acquire | `newGuiCmdRealForTest → newGuiCmdReal.RunE → newGUIExitSignalContext → PidportPath/SettingsGet → acquireSingleInstanceWithHandoff`. До тестового pidport override возможен `PidportPath()` в ordinary sandbox. Сигнальный observer снимается и присоединяется через `defer stop()`. Нет запуска root CLI main или bare-launch сценария. |
| Probe и kill | `runForceKill → gui.Probe → KillRecordedHolder` читает fixture pidport, делает loopback HTTP probe port=1 и нативные запросы идентичности записанного процесса. Подменённый identity gate допускает только PID своего ребёнка. Подменённый kill вызывает original `Cmd.Process.Kill` и получает завершение единственного `Cmd.Wait`. Реальные `killProcessImpl(pid)` не вызываются этой положительной ветвью. |
| RaceLost | После owned Wait hook отпускает исходный flock и удерживает competitor flock до результата `ExecuteContext`. Production acquire-петля исчерпывает свой бюджет и возвращает 3. При корректной постановке до `startGuiServer` не доходит. Если постановка сломалась, общий 10-секундный контекст проваливает тест; запрещённые supervisor/scheduler ветви всё равно отключены. |
| Rewrite startup | После reacquire публикуется запись владельца с прежним port=1; реальный GUI server bind на loopback выбранного `freePort` и `GUIOwnerLifecycle.UpdatePort` создают требуемую активную запись. `NewServer` создаёт API/обработчики, а `Server.Start` захватывает occurrence store и пишет его поколение в sandbox. Есть реальные файловые блокировки, event logs, фоновые ticker/poller и loopback listener. |
| Работа до supervisor seam | `gui.go:1216` вызывает `RuntimeMcphubExecutable` **до** проверки `MCPHUB_E2E_SUPERVISOR`. Читаются собственный executable, sandbox supervisor state/owner; Windows PE admission проверяет файл и hash, не выполняя image. `Server.Start` также читает настоящий `HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\SeparateProcess` с `QUERY_VALUE`; возможен advisory log в sandbox. Перенаправление USERPROFILE не перенаправляет HKCU. |
| Отключённые ветви | `gui.go:1456–1462` при supervisor=none и успешной инициализации пустого manager возвращается через исходный `errCh` до запуска supervisor, browser, tray и auto-cleanup ticker. `scheduler.New` при none возвращает noop: List пуст, изменения отвергаются. В свежем ordinary sandbox нет settings, `hub_endpoint_enabled` имеет default=false, поэтому hub listener/tokens не создаются. Тестовый IPC address имеет discriminator от отдельного state root. |
| Shutdown | Нормальный activated server прекращает admission, закрывает GUI listener, завершает recovery/event owners; Cobra завершает manager и signal observer, затем `GUIOwnerLifecycle.TerminalSettle` пишет tombstone port=0 перед освобождением lease. Тест ждёт original child и `ExecuteContext`. Существующие исключения из полного join описаны ниже; они не скрыты новой проверкой. |

Основные исходные точки: [GUI CLI](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/cli/gui.go), [server](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/gui/server.go), [identity/kill](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/gui/single_instance.go), [ordinary TestMain](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/cli/settings_registry_test.go), [PE admission](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/binaryadmission/windows_pe.go), [HKCU read](https://github.com/applicate2628/mcp-local-hub/blob/97ff6da0c428a8c30f1952da470e3ff033a740e4/internal/gui/separate_process_detect_windows.go).

## План проверки

Это подготовленный план для root, **не выполненный запуск и не разрешение обходить review**. Machine-readable selectors и незаполненные native pins — в [test-plan.json](test-plan.json).

1. Проверить base commit/tree и два base Git blob; применить только два файла кандидата к exact canonical. Для Go overlay зафиксировать полную карту Replace; для physical tree — полный tree receipt. Не описывать master или `858812` как совпадающий canonical без его отдельных сохранённых изменений. Readback Go-файлов должен совпасть с [manifest.json](manifest.json).
2. Выполнить собственное review, затем gofmt и compilation только уже квалифицированным `C:\msys64\ucrt64\bin\go.exe` — Go 1.27.4 windows/amd64, SHA-256 `0176dbac02ff27ef54c6bc5b316c7c2a2a89f7c8cf5fd314a0e03d6d2b924113` — и toolchain и имеющимися зависимостями. Никаких установок/скачиваний. Windows compile обязателен перед Windows тестами; Linux compile проверяет общий helper/POSIX ветвь без запуска Linux процессов. После gofmt обновить hashes до native-запуска. Здесь compilation/gofmt ещё не выполнены.
3. **До запуска определить фактический PowerShell image.** Недостаточно собрать строку `%SystemRoot%/System32/WindowsPowerShell/v1.0/powershell.exe`: Go `LookPath` использует PATH/PATHEXT/cwd. Нужны абсолютный разрешённый путь, конечный путь после reparse/symlink resolution, размер, SHA-256 и конкретный PATH/PATHEXT; убедиться, что более ранний каталог не подменяет image. Сопоставить путь с `force-kill fixture started` и зафиксировать actual image при native наблюдении, если runner это поддерживает. Значения в плане пока `null`: данный аудит ПК не читает и их не выдумывает.
4. Новый принадлежащий этой попытке root только под `D:\dev\ChatGPT`, с проверенными родителями/отсутствием перенаправления наружу. Временные, profile, AppData, Go output/cache и PowerShell module cache — в разрешённых D-путях; инструменты из уже проверенных установок читаются без изменений. Удалить наследуемые helper-role markers и MCPHUB/GIT overrides из окружения дочернего тестового бинарника; добавить только рассмотренные значения. Ordinary TestMain обязателен. Реальный HKCU-read, loopback port=1 и test IPC должны быть явно учтены в review разрешённых эффектов.
5. Сначала `^TestGUIForceCancellationOnly$` (7 cases), затем **каждый** из двух точных GUI-селекторов в отдельном свежем тестовом процессе, count=1, без Parallel и без широкой regex/full-suite. Родитель runner сохраняет исходный объект каждого запущенного процесса и единственный Wait; дедлайн наблюдения не заменяет доказательство завершения. В [test-plan.json](test-plan.json) приведены аргументы непосредственно тестового бинарника; они не включают его неизвестный до сборки путь.
6. Положительный результат требует фактического выполнения нужного selector, отсутствия SKIP/FAIL и выхода 0, ровно одной пары started/settled для helper, пустой ошибки owned Kill и ожидаемого ненулевого child exit через `*exec.ExitError`, а также всех проверок таблицы 1. Nonzero exit ребёнка здесь ожидаем только вследствие собственного kill; watchdog и ранний самостоятельный exit не принимаются. Нельзя превращать wrapper failure в PASS по отдельным Go-событиям.
7. Узкий отрицательный контроль при необходимости: в отдельной безопасной копии заменить test kill callback на возврат nil без вызова `stopHolder`, оставив сохранённый original cleanup и Wait. Требуется FAIL по незавершённому Wait/недоказанному hook; original child затем получает обычный owned cleanup. **Не запускать исходный master как native negative control:** он снова включает kill-by-PID и отсутствие корректного Wait. Безопасный контроль отсутствия fixture — LookPath failure в отдельном пустом PATH/cwd, ожидаемый FAIL до Start; не подменять PowerShell произвольным executable.

## Пределы выводов и собственное review

Проверено статически: оба изменения адресуют только original `Cmd.Process`; один lexical `Cmd.Wait` вызывается для каждого успешно стартовавшего fixture; `holderDone` закрывается только после Wait; post-kill hook RaceLost требует этот факт до переключения flock; блокировки имеют cleanup независимо от hook; команда присоединяется до возврата/restore; ранний DeadPID не удовлетворяет новым утверждениям. В vendored `third_party/gofrs-flock` повторный Unlock уже отпущенного fixture возвращает nil; ошибки реального освобождения остаются ошибками теста. Совпадение всех нетронутых байтов исходного тестового файла проверено восстановлением exact base после удаления только добавленных helper/test/import и замены двух целевых тел.

**Открытые прежние production-ограничения не исправлены и не объявлены PASS:**

- Identity probe и production `killProcessImpl(pid)` не передают одно удержанное полномочие на процесс; Windows заново открывает handle по PID, Linux посылает сигнал по PID. Test seam это обходит для собственного fixture, не квалифицирует production-ветвь.
- `gui.go:1345` запускает `s.Start` в отдельной горутине, а ветви `ctx.Done` на 1419–1427 могут вернуть Cobra до получения `errCh`, если отмена пришла до Activated. Следовательно, join `ExecuteContext` сам по себе не доказывает join всей внутренней server-горутии. В нормальной activated ветви supervisor=none возврат идёт через `errCh`; тест не превращает эту нормальную ветвь в доказательство для всех interleavings.
- `StatusPoller.poll` вызывает status через background context; `detectSeparateProcessOnce` — отдельная горутина; `Broadcaster.Close` имеет ограниченное ожидание. Здесь не доказано полное settlement всех GUI workers либо всего дерева процессов. Это часть ранее остававшегося production lifecycle, отдельная от child-fixture исправления.
- Наличие таймаута `CommandContext` не доказывает, что native Kill/Wait всегда уложится в него. Незавершённый владелец остаётся незавершённым и не допускает успешную квалификацию.
- Нативный PowerShell path/image ещё не получен; Windows/Linux compilation, gofmt, race и обе реальные постановки не выполнялись. Производительность не измерялась. Изменений baseline, deadline/cap исключений и принятия архитектурного долга нет; новый test accessor необходимо учитывать в фактическом archcheck, если он требуется gate.

## Артефакты

- [manifest.json](manifest.json) — lineage, размеры, SHA-256/Git blob и статическая проверка сохранения нетронутых байтов.
- [candidate.patch](candidate.patch) — только два source-файла относительно exact canonical.
- [source-receipt.json](source-receipt.json) — immutable источники рассмотренного графа вызовов.
- [test-plan.json](test-plan.json) — точные selectors, ожидаемые исходы и пока отсутствующий native PowerShell pin.
- [verify_static.py](verify_static.py) — локальная проверка байтов, diff и области изменений: `python -B verify_static.py`; Go и subprocess не запускает.
- [Предшествующий аудит](../gui-owner-audit.md) — условия и последствия исходных дефектов.

`base/` хранит две неизменённые исходные копии для локального воспроизведения diff. Содержимое `internal/` — кандидат; никакие другие исходники проекта этим каталогом не заменяются.
