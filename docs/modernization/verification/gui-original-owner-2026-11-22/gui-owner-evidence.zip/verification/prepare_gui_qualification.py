"""Build fixed local GUI qualification inputs; never executes Go or remote actions."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
P0 = HERE.parent
def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

source = (HERE / "p0_serena_runner.py").read_text()
assert sha(source.encode()) == "c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1"
body = source[source.index('import sys\n'):]
body = body.replace('SOURCE = ROOT / "source-master"', 'SOURCE = ROOT / "preserved-input/source-preserved"')
body = body.replace('75dbc6406123e22468f168b861d5e0622c9d5769', '858812988833a84368c60fba1540ae601155fa71')
body = body.replace('cb3eec77c23f9400be962d91c9f23834b84f7643', 'dba685c090952a93a80a1e82403c4646ad8aaed1')
body = body.replace('UPSTREAM_OWNER_SHA256 = "b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641"', 'UPSTREAM_OWNER_SHA256 = "c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1"')
start = body.index('PHASES = {')
end = body.index('\n}\n', start) + 3
body = body[:start] + '''PHASES = {
    "gui-format", "gui-compile", "gui-pure", "gui-race-lost", "gui-rewrite", "gui-build", "gui-vet",
}
''' + body[end:]
body = body.replace('len(files) != 25', 'len(files) != 4').replace('"serena-format"', '"gui-format"').replace('p0_serena_runner.py <phase>', 'p0_gui_runner.py <phase>')
old_path = 'env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))'
new_path = '''env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent)))
        env["PATHEXT"] = ".COM;.EXE;.BAT;.CMD"
        env["NODEFAULTCURRENTDIRECTORYINEXEPATH"] = "1"
        env["MCPHUB_E2E_SUPERVISOR"] = "none"
        self.receipt["native_fixture"] = qualify_fixture_image(env, self.plan["native_fixture"])
        self.receipt["fixture_environment"] = {key: env[key] for key in ("PATH", "PATHEXT", "NODEFAULTCURRENTDIRECTORYINEXEPATH", "MCPHUB_E2E_SUPERVISOR", "PSModuleAnalysisCachePath")}'''
assert body.count(old_path) == 1
body = body.replace(old_path, new_path)
body = body.replace('tools_sha256={str(p): sha(p.read_bytes()) for p in (GO, GOFMT, GIT, Path(env["CC"]))}', 'tools_sha256={str(p): sha(p.read_bytes()) for p in (GO, GOFMT, GIT, Path(env["CC"]), Path(self.receipt["native_fixture"]["lookup_path"]))}')
fixture = '''def qualify_fixture_image(env, expected):
    """Match the installed Go Windows LookPath algorithm under fixed PATH/PATHEXT.

    Current-directory search is disabled explicitly. This observes an image;
    the test retains the original Cmd.Process for termination authority.
    """
    attempts = []
    found = None
    for directory in env["PATH"].split(os.pathsep):
        for extension in env["PATHEXT"].lower().split(";"):
            candidate = Path(directory) / ("powershell" + extension)
            present = candidate.is_file()
            attempts.append({"path": str(candidate), "present": present})
            if present:
                found = candidate
                break
        if found is not None:
            break
    if found is None:
        raise RuntimeError("Qualified PowerShell fixture is unavailable")
    final = found.resolve(strict=True)
    raw = found.read_bytes()
    if final != Path(expected["final_path"]) or len(raw) != expected["bytes"] or sha(raw) != expected["sha256"]:
        raise RuntimeError("PowerShell lookup/image differs from the reviewed read-only observation")
    return {"lookup_path": str(found), "final_path": str(final), "bytes": len(raw),
            "sha256": sha(raw), "lookup_attempts": attempts,
            "method": "Fixed absolute PATH/PATHEXT; current-directory lookup disabled; matched installed Go lp_windows.go"}


'''
body = body.replace('def validate_command(command):\n', fixture + 'def validate_command(command):\n')
needle = '    if any(marker not in rendered + stderr.decode("utf-8") for marker in command.get("required_output", [])):\n'
addition = '''    if runner.phase in {"gui-race-lost", "gui-rewrite"} and command["kind"] == "test":
        image = "image=" + json.dumps(runner.receipt["native_fixture"]["lookup_path"])
        if rendered.count("force-kill fixture started: " + image) != 1 or rendered.count("force-kill fixture settled: " + image) != 1:
            raise RuntimeError("Original fixture start/settlement or resolved image oracle differs")
        qualify_fixture_image(runner.env, runner.manifest["native_fixture"])
'''
assert body.count(needle) == 1
body = body.replace(needle, addition + needle)
description = '''"""Qualify only four exact overlays: canonical daemon entry plus GUI owned fixtures.

This derivative preserves the original retained-Popen/source/environment capture.
Only fixed phases are admitted. GUI native selections use a separately observed
PowerShell image and fixed PATH/PATHEXT; no installed Hub or scheduler changes.
Rewrite reaches a real loopback GUI server and HKCU QUERY_VALUE. Its result does
not prove all GUI workers or the whole process tree joined. Full suites are absent.
"""\n'''
runner = description + body
ast.parse(runner)
(HERE / "p0_gui_runner.py").write_text(runner)
runner_sha = sha(runner.encode())

old_ast, new_ast = ast.parse(source), ast.parse(runner)
def methods(tree):
    c = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "Runner")
    return {n.name: ast.dump(n, include_attributes=False) for n in c.body if isinstance(n, ast.FunctionDef)}
old_methods, new_methods = methods(old_ast), methods(new_ast)
changed = [name for name in old_methods if old_methods[name] != new_methods[name]]
assert changed == ["begin"], changed

native = json.loads((HERE / "gui-powershell-input.json").read_text())
composed = json.loads((HERE / "preserved-manifests/composed/manifest.json").read_text())
by_path = {x['path']: x for x in composed['files']}
candidate = P0 / 'gui-owner-candidate'
gui = json.loads((candidate / 'manifest.json').read_text())
stage = HERE / 'gui-manifests/gui-staged'
files = []
for path in ('internal/daemon/main_test.go', 'internal/daemon/main_dispatch_test.go', 'internal/cli/gui_force_test.go', 'internal/gui/test_seams.go'):
    src = (candidate / path) if '/gui/' in path or '/cli/' in path else (P0 / 'publication/canonical/candidate' / path)
    raw = src.read_bytes()
    destination = stage / 'candidate' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    if path in by_path:
        row = {k: v for k, v in by_path[path].items() if k.startswith('source_')}
    else:
        base = next(x for x in gui['files'] if x['path'] == path)['base']
        row = {'source_sha256': base['sha256'], 'source_git_blob': base['git_blob']}
    files.append({'path': path, **row, 'candidate_sha256': sha(raw), 'candidate_git_blob': blob(raw)})
paths = [x['path'] for x in files]
def command(label, kind, args, seconds=300, **extra):
    return {'label': label, 'kind': kind, 'args': args, 'timeout_seconds': seconds, 'expected_exit_code': 0, **extra}
def phase(commands):
    return {'overlay_paths': paths, 'commands': commands}
phases = {
 'gui-format': phase([command('go-version','version',['version'],30), command('gofmt-check','format',['-l','{candidate_files}'],30)]),
 'gui-compile': phase([command('cli-race-compile','compile',['test','-overlay','{overlay}','-mod=readonly','-tags=test_state_path_env','-race','-c','-o','{binary}','./internal/cli'],600)]),
 'gui-build': phase([command('full-build','build',['build','-overlay','{overlay}','-mod=readonly','./...'],600)]),
 'gui-vet': phase([command('full-vet','vet',['vet','-overlay','{overlay}','-mod=readonly','./...'],600)]),
}
for name, selector in [('gui-pure','TestGUIForceCancellationOnly'),('gui-race-lost','TestForce_KillRaceLost'),('gui-rewrite','TestForce_KillRewritesPidportWithCurrentPID')]:
    phases[name] = phase([command(name,'test',['test','-overlay','{overlay}','-mod=readonly','-tags=test_state_path_env','-race','-json','-count=1','-timeout=90s','-parallel=1','-run','^'+selector+'$','./internal/cli'],180,required_root_pass_counts={selector:1})])
manifest = {'schema':1,'runner_sha256':runner_sha,'source_head':'858812988833a84368c60fba1540ae601155fa71','source_tree':'dba685c090952a93a80a1e82403c4646ad8aaed1','native_scheduler_operations':False,'command_timeouts':{'git':180,'termination':15},'files':files,'phases':phases,'candidate_stage':'unformatted','native_fixture':{key:native[key] for key in ('image','final_path','bytes','sha256')}}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
formatter = (HERE/'format_serena_staged.py').read_text()
formatter = formatter.replace('25 new','4 new').replace('len(candidates) != 25','len(candidates) != 4').replace('reviewed 25 Go files','reviewed 4 Go files').replace('Serena','GUI').replace('serena','gui').replace('c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1',runner_sha).replace('owner.SOURCE != ROOT / "source-master"','owner.SOURCE != ROOT / "preserved-input/source-preserved"')
ast.parse(formatter)
(HERE/'format_gui_staged.py').write_text(formatter)
proof = {'upstream_runner_sha256':sha(source.encode()),'new_runner_sha256':runner_sha,'runner_methods_changed':changed,'unchanged_methods':[name for name in old_methods if name not in changed],'formatter_sha256':sha(formatter.encode()),'manifest_sha256':sha((stage/'manifest.json').read_bytes()),'native_image_sha256':native['sha256'],'source_files':4,'qualification':'Source-only generation. No execution performed by this script.'}
(HERE/'gui-runner-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
