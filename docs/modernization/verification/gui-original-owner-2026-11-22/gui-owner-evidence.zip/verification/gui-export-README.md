# GUI evidence export v1

## Оглавление

1. [Готовые входы](#1-готовые-входы)
2. [Область и допуск](#2-область-и-допуск)
3. [Порядок для root](#3-порядок-для-root)
4. [Что проверено локально](#4-что-проверено-локально)
5. [Пределы результата](#5-пределы-результата)

## 1. Готовые входы

Экспортёр заморожен локально. Native-экспорт и передача файлов **не выполнялись**.

**Таблица 1. Неизменяемые входы для переноса root.** SHA-256 — Secure Hash Algorithm с результатом 256 бит.

| Файл | Байты | SHA-256 |
|---|---:|---|
| `export_gui_evidence.py` | 37517 | `66c8d23242bffecff898d88c0beb28fa9a2fb4bfdb874e475c3e08d1c8b7d9c0` |
| `gui-export-inputs/manifest.json` | 2706 | `02a809934ce381e98de3e72cb7eae90f7b9e3c216540b63227b7c62b11b4162d` |

В packet находятся ровно четыре original candidate Go-файла и три JSON-доказательства: `gui-runner-source-proof.json`, `gui-negative-control-source.json`, `gui-source-composition-proof.json`. Manifest перечисляет каждый путь, размер и hash. Original и formatted Go-байты совпадают по обоим исходным manifests; для control подтверждается единственная согласованная замена `return stopHolder()` внутри RaceLost owned kill callback на `return nil`. Cleanup с исходным `Cmd.Process.Kill` и одним `Cmd.Wait` сохраняется.

Экспортёр — derivative уже выполненного `export_serena_evidence.py` (SHA-256 `8d8fe721789117b807779ddf93ef2dcee31e26f5e6fc0d8e9ae90edff66d8843`). Четырнадцать общих функций сохранены побайтно. Изменены шесть функций выбора/проверки входов и общей композиции, добавлены две узкие проверки native fixture metadata и command oracle. Полная разность — [gui-export.patch](gui-export.patch).

## 2. Область и допуск

Физический source: `ROOT/preserved-input/source-preserved`, commit `858812988833a84368c60fba1540ae601155fa71`, tree `dba685c090952a93a80a1e82403c4646ad8aaed1`. Четыре overlay — два canonical daemon и два GUI. Source-master не используется.

**Таблица 2. Ровно девять обязательных terminal phases.**

| № | Phase | Manifest/runner |
|---:|---|---|
| 1 | gui-stage-format | original / normal |
| 2 | gui-format | formatted / normal |
| 3 | gui-compile | formatted / normal |
| 4 | gui-pure | formatted / normal |
| 5 | gui-race-lost | formatted / normal |
| 6 | gui-rewrite | formatted / normal |
| 7 | gui-build | formatted / normal |
| 8 | gui-vet | formatted / normal |
| 9 | gui-race-lost-control | control / control |

До создания destination проверяются все девять terminal receipts; точный argv и owner; начальные/launch/final command records; все stdout/stderr и raw Go terminal events; source/tool before-after pins; overlays; formatter provenance; четыре original/formatted/control candidate; явное отсутствие нового daemon source-файла в физической базе. Затем все прочитанные входы и отсутствие повторно проверяются.

Отрицательный control хранит исходный `exit 1` и два `FAIL`. Отдельное `oracle_matched=true` означает совпадение с ожидаемым отрицательным исходом, а не превращение тестов в PASS. Для matched control обязательны обе Wait/hook diagnostics и ровно по одному marker запуска/завершения исходного helper.

Сохранённые PowerShell observation bytes закреплены SHA-256 `777dfef4e084ec46a79d8cd476d2f0baf31194ba90c96aaa80250ad07274ef18`; root подтвердил их совпадение с первоначальными native байтами. Проверяются hash исходника observer, image identity `450560 B / 3247bcfd60f6dd25f34cb74b5889ab10ef1b3ec72b4d4b3d95b5b25b534560b8`, зафиксированные PATH/PATHEXT, lookup prefix, module-cache path и tool map всех фаз.

Экспортёр читает **только явные входы в ROOT**: scripts, manifests/candidates/proofs, три физические source-preimage и выбранные файлы девяти evidence directories. PowerShell executable и прочие C: executable не перечитываются. Observation и observer включаются как сохранённые данные. Runtime/cache/profile trees, исполнимые бинарники и private C: audit/traceback исключены. Неизвестный process artifact не молча пропускается.

## 3. Порядок для root

ROOT фиксирован: `D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5`.

1. Прочитать exporter и разность; перенести точные script bytes в `ROOT/export_gui_evidence.py`.
2. Перенести packet без изменений в `ROOT/manifests/gui-export-inputs/`, проверить manifest SHA и все семь его членов.
3. Убедиться, что последняя control phase завершилась и её окончательный receipt существует. Running phase или отсутствующий terminal record будут отвергнуты до создания export destination.
4. Существующим Python выполнить из ROOT следующий фиксированный argv — только после собственного ревью root:

```text
python -B export_gui_evidence.py 66c8d23242bffecff898d88c0beb28fa9a2fb4bfdb874e475c3e08d1c8b7d9c0
```

Новая область записи: `ROOT/evidence/gui-export-v1`. При существующей destination exporter отказывает; overwrite/resume/удаления нет. В ней создаются `gui-evidence.zip`, transfer metadata/text, отдельный archive receipt и общий receipt. ZIP сортируется по именам, имеет постоянные timestamps/mode и MANIFEST с длиной/SHA каждого исходного члена. Raw test streams не переписываются.

До этого root уже должен иметь в ROOT исполненные `p0_gui_runner.py`, `p0_gui_control_runner.py`, `format_gui_staged.py`, `p0_serena_runner.py`, `observe_gui_powershell.py`, исходные normal/control manifests и `evidence/gui-powershell-input.json`. Их hashes зафиксированы в exporter; исполнять их при экспорте он не будет.

## 4. Что проверено локально

[gui-export-review.json](gui-export-review.json) содержит **16 успешных проверок** только данных/исходников: сохранение отрицательного exit/FAIL, отказы при пропавшем terminal/start/launch record либо stdout, неверном runner/manifest, скрытом raw FAIL, неверном control exit, пропавшей diagnostic/settlement marker, неправильной физической базе, drift native-image metadata и незавершённой phase; также повторяемость ZIP и чтение каждого члена.

Проверены синтаксис Python, hashes всех переносимых packet-входов, source/script pins и побайтная неизменность 14 общих функций. С реально предоставленным `gui-vet-receipt.json` совпали fixture/environment, physical source и tool guards. Последняя проверка читала aggregate, а не отсутствующие локально raw streams; полное сопоставление всех потоков делает будущий native exporter.

Локальные проверки не запускали exporter main, runners, observer, Go, PowerShell, CMake или remote actions. Полная коллекция девяти фактических фаз здесь **NOT_RUN**.

## 5. Пределы результата

Успешное создание архива подтверждает сохранение и согласованность выбранных свидетельств; оно не означает успех всех Go-тестов. Наблюдаемое завершение собственного helper через original `Cmd.Process` и один `Cmd.Wait` отделено от завершения всех GUI workers, всего дерева процессов и production PID-owner correctness. Соответствующие ограничения остаются явными в MANIFEST.

Rewrite достигает настоящего loopback GUI server и выполняет read-only HKCU QUERY_VALUE. Архив не заявляет installed Hub lifecycle, Task Scheduler mutation, закрытие полных Go-наборов или доказательство production original-owner рефакторинга. Эти границы не изменяются при matched negative control.
