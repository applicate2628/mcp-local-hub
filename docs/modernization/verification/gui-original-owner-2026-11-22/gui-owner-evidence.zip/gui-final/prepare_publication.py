"""Build GUI publication from immutable source and verified Windows evidence."""
from pathlib import Path
import hashlib
import io
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
P0 = HERE.parent
DEST = HERE / 'publication'
DEST.mkdir(exist_ok=True)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

checkpoint = json.loads((HERE / 'code-checkpoint.json').read_text())
assert checkpoint['commit'] == '8f6a89b491c3dca11830688b8b158bf973b19363'
verification = json.loads((HERE / 'received/local-verification.json').read_text())
assert verification['all_members_crc_length_sha256_verified']
inner = (HERE / 'received/gui-evidence.zip').read_bytes()
assert sha(inner) == '52879c23549f17d6aeaa622f702bc61c7417131441b1e3c3b7eb3b261101a335'
with zipfile.ZipFile(io.BytesIO(inner)) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('MANIFEST.json'))
    for f in manifest['files']:
        raw = z.read(f['path'])
        assert len(raw) == f['bytes'] and sha(raw) == f['sha256']
        assert re.search(rb'C:(?:\\+|/)Users(?:\\+|/)', raw, re.I) is None
    source_proof = json.loads(z.read('proof/gui-source-composition-proof.json'))
    for row in checkpoint['files']:
        raw = z.read('inputs/gui-formatted/candidate/' + row['path'])
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['sha']
        assert raw == (P0 / 'gui-owner-candidate' / row['path']).read_bytes()
    summary = {
        'schema': 1, 'source_head': manifest['source_head'], 'source_tree': manifest['source_tree'],
        'code_commit': checkpoint['commit'], 'code_tree': checkpoint['tree'], 'overlay_count': 4,
        'normal_manifest_sha256': manifest['formatted_manifest_sha256'],
        'control_manifest_sha256': manifest['control_manifest_sha256'],
        'phases': verification['phases'], 'positive_root_tests': 3,
        'positive_test_and_subtest_pass': 10, 'positive_package_pass': 3,
        'positive_fail': 0, 'positive_skip': 0,
        'negative_control': {'go_exit': 1, 'test_fail': 1, 'package_fail': 1, 'pass': 0, 'skip': 0,
                             'oracle_matched': True, 'failure_preserved': True},
        'whole_process_tree_settlement_observed': False, 'all_gui_workers_joined': False,
        'production_pid_owner_qualified': False, 'full_go_suites': 'NOT_RUN',
        'installed_product': 'NOT_RUN', 'posix_execution': 'NOT_RUN',
    }
dump(DEST / 'qualification.json', summary)
dump(DEST / 'source-composition-proof.json', {'qualified_overlay': source_proof,
     'canonical_parent': json.loads((HERE / 'canonical-parent-proof.json').read_text())})

entries = {}
for p in sorted((P0 / 'gui-owner-candidate').rglob('*')):
    if p.is_file():
        assert not p.is_symlink() and p.suffix not in {'.exe', '.b64', '.pyc'}
        entries['gui-owner-candidate/' + p.relative_to(P0 / 'gui-owner-candidate').as_posix()] = p.read_bytes()
for name in ('root-review.md', 'code-checkpoint.json', 'canonical-parent-proof.json', 'prepare_publication.py'):
    entries['gui-final/' + name] = (HERE / name).read_bytes()
for name in ('gui-evidence.zip', 'transfer.json', 'export-receipt.json', 'local-verification.json', 'base64-trash-receipt.json'):
    entries['gui-final/received/' + name] = (HERE / 'received' / name).read_bytes()
for name in ('gui-export-README.md', 'gui-export-review.json', 'gui-export-freeze.json',
             'gui-export-upload-list.json', 'gui-export.patch', 'prepare_gui_qualification.py',
             'gui-unused-formatter-v0.json'):
    entries['verification/' + name] = (P0 / 'verification' / name).read_bytes()
outer_manifest = {'schema': 1, 'code_commit': checkpoint['commit'], 'code_tree': checkpoint['tree'],
    'inner_archive_sha256': sha(inner), 'scope': 'Three targeted Windows GUI roots, expected failing control, compile/build/vet; no full Go/product claim',
    'historical_source_documents': 'gui-owner-candidate records original pre-execution state; current qualification is in the sibling publication report and raw captured evidence',
    'files': [{'path': p, 'bytes': len(raw), 'sha256': sha(raw)} for p, raw in sorted(entries.items())]}
entries['MANIFEST.json'] = (json.dumps(outer_manifest, ensure_ascii=False, indent=2) + '\n').encode()
out = io.BytesIO()
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
raw = out.getvalue()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for f in outer_manifest['files']:
        data = z.read(f['path'])
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
archive_name = 'gui-owner-evidence.zip'
with (DEST / archive_name).open('xb') as stream:
    stream.write(raw)
meta = {'schema': 1, 'archive': archive_name, 'bytes': len(raw), 'sha256': sha(raw),
    'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
    'entries': len(entries), 'payload_entries': len(entries)-1, 'all_members_crc_length_sha256_verified': True,
    'inner_archive': {'bytes': len(inner), 'sha256': sha(inner), 'entries': 1346},
    'remote_binary_readback': 'Upload blob SHA and published Git tree must match; no second binary download is claimed'}
dump(DEST / 'archive.json', meta)
print(json.dumps(meta, indent=2))
