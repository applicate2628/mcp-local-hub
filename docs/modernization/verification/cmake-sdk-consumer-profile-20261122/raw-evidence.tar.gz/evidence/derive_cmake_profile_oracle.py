"""Independently derive the public, redacted R22 fixture's semantic oracle.

This is offline JSON analysis, not a CMake/Go execution or a production parser.
The historical original trace has different bytes and is not admitted here.
"""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = root / "qualification/cmake-input/trace.jsonl"
output = root / "cmake-profile/internal/vcpkgmcp/vcpkgserver/testdata/cmake_trace_sdk_profile_oracle.json"
raw = source.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
assert len(raw) == 11302778
assert sha == "a79b7793b5f384f885afb60fb513402d4523bcc0779546aa1e199e15a80fd286"
records, headers, includes, lines = [], [], [], {}
for encoded in raw.splitlines():
    item = json.loads(encoded)
    if "version" in item:
        headers.append(item["version"])
        continue
    record = {key: item[key] for key in ("file", "line", "cmd", "args")}
    for key in ("time", "frame", "global_frame"):
        if item.get(key, 0):
            record[key] = item[key]
    if item.get("defer") is not None:
        record["defer"] = True
    records.append(record)
    lines.setdefault(record["file"], set()).add(record["line"])
    if record["cmd"].lower() in ("include", "add_subdirectory"):
        includes.append({"kind": record["cmd"].lower(), "file": record["file"],
                         "line": record["line"],
                         "argument": record["args"][0] if record["args"] else ""})
assert headers == [{"major": 1, "minor": 2}]
assert len(records) == 16671 and len(includes) == 8 and len(lines) == 12
payload = [record for record in records
           if record["file"].endswith("/payload.cmake") and record["cmd"] == "set"]
assert len(payload) == 16384
for index, record in enumerate(payload, 1):
    assert record["args"] == ["R22_PAYLOAD", f"r22:{index}:" + "0123456789abcdef" * 32]
common = {"status": "ok", "malformed_line_count": 0, "input_incomplete": False,
          "version_header_present": True, "truncated": True, "evidence": {}}
full = {**common, "include_chain": includes, "records": records[:8],
        "executed_lines": [{"file": file, "lines": sorted(lines[file])}
                           for file in sorted(lines)], "files_in_trace": sorted(lines)}
projected = {**common, "result_projection": {"complete": False, "omissions": [
    {"field": field, "reason": "internal_projection_limit", "retained": 0, "omitted": count}
    for field, count in (("include_chain", 8), ("records", 1000),
                         ("executed_lines", 12), ("files_in_trace", 12))]}}
oracle = {"schema": 1, "input_sha256": sha, "input_bytes": len(raw),
          "json_lines": len(raw.splitlines()), "command_records": len(records),
          "max_line_bytes_excluding_newline": max(map(len, raw.splitlines())),
          "generated_payload_iterations": 16384, "generated_payload_bytes": 512,
          "provenance": {"kind": "published_redacted_cmake_generated_fixture",
                         "commit": "b1d932ea8925ef3324d539e5de006daeae65ba2a",
                         "archive_git_blob": "e57310ea91223f43c09fe7233feb796176a52f1a",
                         "production_workload": False},
          "full_max_records_8": full, "projected_default_records_1000": projected}
encoded = (json.dumps(oracle, ensure_ascii=True, indent=2) + "\n").encode()
output.parent.mkdir(parents=True, exist_ok=True)
output.write_bytes(encoded)
print(json.dumps({"output": str(output), "bytes": len(encoded),
                  "sha256": hashlib.sha256(encoded).hexdigest(),
                  "full_body_without_native_evidence_bytes": len(json.dumps(full, indent=2)),
                  "command_records": len(records), "include_records": len(includes),
                  "files": len(lines), "unique_file_line_pairs": sum(map(len, lines.values()))}))
