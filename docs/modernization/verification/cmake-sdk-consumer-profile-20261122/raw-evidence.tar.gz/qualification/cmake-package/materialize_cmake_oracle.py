"""Add only the fixed CMake embed fixture to the owned qualification source.

Root must serialize this action after every user of source has settled. This
helper does not detect process quiescence and starts no process. It never
overwrites, deletes, formats or changes Git. On failure retain all evidence.
"""
import sys
sys.dont_write_bytecode = True

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat

ROOT = Path(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
SOURCE = ROOT / "source"
SCOPE = "inputs/cmake-sdk-profile"
FIXTURE = "internal/vcpkgmcp/vcpkgserver/testdata/cmake_trace_sdk_profile_oracle.json"
FIXTURE_BYTES = 12055
FIXTURE_SHA = "66edc3230924cb22f31235ebdc0a607e4a1e227db117209f56c24b7d49139ace"
STAGE = ROOT / "staging/cmake-sdk-profile-source/receipt.json"
STAGE_SHA = "103f4a3f84e20344b59e57c799e29dfedf2b95242ea82181f0c8ef91266fb297"
RUNNER_SHA = "893c3281026e988c200f61fb2b4459b3385d427b7b39e0eec38d27b9c03949e5"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def relative(text):
    p = PurePosixPath(text)
    if (not text or str(p) != text or p.is_absolute() or "\\" in text or ":" in text
            or any(part in (".", "..", ".git") for part in p.parts)):
        raise RuntimeError("Invalid fixed-input relative path")
    return Path(*p.parts)


def ordinary_chain(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse/symlink refused: " + str(item))


def pin(path, owned=False):
    ordinary_chain(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or (owned and before.st_nlink != 1):
        raise RuntimeError("Expected ordinary unshared file: " + str(path))
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        if stamp(os.fstat(stream.fileno())) != stamp(before):
            raise RuntimeError("File changed at open: " + str(path))
        while data := stream.read(1024 * 1024):
            digest.update(data)
        if stamp(os.fstat(stream.fileno())) != stamp(before):
            raise RuntimeError("File changed during read: " + str(path))
    ordinary_chain(path)
    if stamp(path.lstat()) != stamp(before):
        raise RuntimeError("File changed after read: " + str(path))
    return {"bytes": before.st_size, "sha256": digest.hexdigest()}


def inventory():
    ordinary_chain(SOURCE)
    files, directories = [], ["."]
    def walk_error(error):
        raise error
    for parent, dirs, names in os.walk(SOURCE, followlinks=False, onerror=walk_error):
        if ".git" in dirs:
            dirs.remove(".git")
        for name in dirs:
            path = Path(parent) / name
            ordinary_chain(path)
            if not stat.S_ISDIR(path.lstat().st_mode):
                raise RuntimeError("Unexpected source directory type")
            directories.append(path.relative_to(SOURCE).as_posix())
        for name in names:
            if name == ".git":
                continue
            path = Path(parent) / name
            files.append({"path": path.relative_to(SOURCE).as_posix(), **pin(path)})
    files.sort(key=lambda row: row["path"])
    directories.sort()
    return {"files": files, "directories": directories,
            "inventory_sha256": sha(json.dumps(files, separators=(",", ":"), ensure_ascii=True).encode())}


def make_owned_directory(path, exclusive=False):
    if not path.is_relative_to(ROOT):
        raise RuntimeError("Directory escaped owned root")
    ordinary_chain(ROOT)
    current = ROOT
    for part in path.relative_to(ROOT).parts:
        current /= part
        if os.path.lexists(current):
            ordinary_chain(current)
            if not stat.S_ISDIR(current.lstat().st_mode) or (exclusive and current == path):
                raise RuntimeError("Output already exists or is not a directory")
        else:
            current.mkdir()
            ordinary_chain(current)


def save(path, value):
    ordinary_chain(path.parent)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def input_snapshot(rows):
    result = []
    for row in rows:
        if not row["path"].startswith(SCOPE + "/"):
            raise RuntimeError("Input escaped the fixed scope")
        actual = pin(ROOT / relative(row["path"]), owned=True)
        if actual != {key: row[key] for key in ("bytes", "sha256")}:
            raise RuntimeError("Staged input differs: " + row["path"])
        result.append({"path": row["path"], **actual})
    return result


def main():
    if (os.name != "nt" or not sys.flags.isolated or not sys.flags.no_site or sys.flags.optimize
            or Path(__file__) != ROOT / "materialize_cmake_oracle.py" or len(sys.argv) != 4):
        raise RuntimeError("Use exact owned Python -I -S -B helper manifestSHA stageReceiptSHA run-id")
    manifest_sha, stage_sha, run_id = sys.argv[1:]
    if (not re.fullmatch(r"[a-z][a-z0-9-]{0,31}", run_id)
            or any(not re.fullmatch(r"[0-9a-f]{64}", v) for v in (manifest_sha, stage_sha))):
        raise RuntimeError("Invalid exact input pins/run id")
    path = ROOT / SCOPE / "materialization.json"
    if pin(path, True)["sha256"] != manifest_sha or pin(STAGE, True)["sha256"] != stage_sha:
        raise RuntimeError("Caller-reviewed input changed")
    raw, stage_raw = path.read_bytes(), STAGE.read_bytes()
    if sha(raw) != manifest_sha or sha(stage_raw) != stage_sha:
        raise RuntimeError("JSON changed during load")
    plan, staged = json.loads(raw), json.loads(stage_raw)
    helper_sha = pin(Path(__file__), True)["sha256"]
    if (plan["schema"] != "cmake-oracle-materialization-v1" or plan["helper_sha256"] != helper_sha
            or plan["root"] != str(ROOT) or plan["fixture"] != FIXTURE
            or plan["source_head"] != "858812988833a84368c60fba1540ae601155fa71"
            or plan["source_tree"] != "dba685c090952a93a80a1e82403c4646ad8aaed1"):
        raise RuntimeError("Unreviewed helper/source scope")
    before_rows = plan["staged_before"] + [{"path": SCOPE + "/materialization.json", "bytes": len(raw), "sha256": manifest_sha}]
    by_path = lambda rows: {r["path"]: r for r in rows}
    before, after = by_path(staged["before"]), by_path(staged["after"])
    if (staged.get("completed") is not True or staged.get("script_sha256") != STAGE_SHA
            or staged.get("runner_sha256") != RUNNER_SHA or before != by_path(before_rows)
            or len(before) != len(staged["before"]) or set(after) != set(before)
            or len(after) != len(staged["after"])):
        raise RuntimeError("Staging did not admit exactly the fixed six inputs")
    fmt = staged.get("format", {})
    if (fmt.get("exit_code") != 0 or fmt.get("settled") is not True or fmt.get("timed_out") is not False
            or fmt.get("process_tree_unresolved") or fmt.get("termination_error")):
        raise RuntimeError("Formatter did not settle successfully")
    for name, row in after.items():
        if not name.endswith(".go") and row != before[name]:
            raise RuntimeError("Non-Go input changed during formatting")
    expected_source = sorted(plan["source_files"], key=lambda row: row["path"])
    expected_dirs = sorted(plan["source_directories"])
    addition = {"path": FIXTURE, "bytes": FIXTURE_BYTES, "sha256": FIXTURE_SHA}
    if len(expected_source) != 3281 or any(r["path"] == FIXTURE for r in expected_source):
        raise RuntimeError("Unexpected baseline source inventory")
    expected_after = sorted([*expected_source, addition], key=lambda row: row["path"])
    new_dir = PurePosixPath(FIXTURE).parent.as_posix()
    if new_dir in expected_dirs:
        raise RuntimeError("Fixture directory must be new")
    out = ROOT / "evidence" / ("cmake-oracle-materialize-" + run_id)
    make_owned_directory(out, exclusive=True)
    record = {"schema": 1, "started_utc": now(), "completed": False, "errors": [],
              "helper_sha256": helper_sha, "manifest_sha256": manifest_sha, "stage_receipt_sha256": stage_sha,
              "source_head": plan["source_head"], "source_tree": plan["source_tree"], "addition": addition,
              "source_quiescence": "Caller must serialize; this helper performs no process detection",
              "destination_created": False, "fixture_directory_created": False}
    save(out / "receipt.initial.json", record)
    with (out / "admission.json").open("xb") as stream:
        stream.write(raw)
    with (out / "stage.receipt.json").open("xb") as stream:
        stream.write(stage_raw)
    try:
        record["inputs_before"] = input_snapshot([after[name] for name in sorted(after)])
        observed = inventory()
        save(out / "source-before.json", observed)
        if observed["files"] != expected_source or observed["directories"] != expected_dirs:
            raise RuntimeError("Complete baseline source differs")
        record["source_before"] = {"files": len(observed["files"]), "inventory_sha256": observed["inventory_sha256"]}
        destination = SOURCE / relative(FIXTURE)
        if os.path.lexists(destination.parent) or os.path.lexists(destination):
            raise RuntimeError("Refuse existing fixture or testdata directory")
        source = ROOT / SCOPE / relative(FIXTURE)
        data = source.read_bytes()
        if len(data) != FIXTURE_BYTES or sha(data) != FIXTURE_SHA:
            raise RuntimeError("Oracle differs before exclusive materialization")
        ordinary_chain(destination.parent.parent)
        destination.parent.mkdir()
        record["fixture_directory_created"] = True
        ordinary_chain(destination.parent)
        with destination.open("xb") as stream:
            record["destination_created"] = True
            if stream.write(data) != len(data):
                raise RuntimeError("Short fixture write")
            stream.flush()
            os.fsync(stream.fileno())
        if pin(destination, True) != {"bytes": FIXTURE_BYTES, "sha256": FIXTURE_SHA}:
            raise RuntimeError("Created oracle differs")
    except BaseException as error:
        record["errors"].append({"stage": "materialize", "type": type(error).__name__, "error": str(error)})
    finally:
        try:
            observed = inventory()
            save(out / "source-after.json", observed)
            record["source_after"] = {"files": len(observed["files"]), "inventory_sha256": observed["inventory_sha256"]}
            if observed["files"] != expected_after or observed["directories"] != sorted([*expected_dirs, new_dir]):
                raise RuntimeError("Source is not exactly baseline plus the one oracle")
        except BaseException as error:
            record["errors"].append({"stage": "source_after", "type": type(error).__name__, "error": str(error)})
        try:
            record["inputs_after"] = input_snapshot([after[name] for name in sorted(after)])
            for frozen, digest in ((path, manifest_sha), (STAGE, stage_sha), (Path(__file__), helper_sha)):
                if pin(frozen, True)["sha256"] != digest:
                    raise RuntimeError("Frozen input changed: " + frozen.name)
        except BaseException as error:
            record["errors"].append({"stage": "inputs_after", "type": type(error).__name__, "error": str(error)})
        record.update(completed=not record["errors"], finished_utc=now())
        save(out / "receipt.json", record)
        print(json.dumps({key: record[key] for key in ("completed", "errors", "destination_created")}), flush=True)
    if not record["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
