"""Local-only final plan freezer; requires exact formatted/input readback.

No remote or Go tool invocation. Place format-receipt.json, materialization/
{receipt,source-before,source-after}.json, and formatted/inputs/... beside this
file after root review. Their absence deliberately prevents a final plan.
"""
from pathlib import Path, PureWindowsPath
import base64
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
D = PureWindowsPath(r"D:\dev\ChatGPT\mcp-final-20261122-e21a1792")
SCOPE = "cmake-sdk-profile"
FIXTURE = "internal/vcpkgmcp/vcpkgserver/testdata/cmake_trace_sdk_profile_oracle.json"
PACKAGE = "mcp-local-hub/internal/vcpkgmcp/vcpkgserver"
RUNNER = "893c3281026e988c200f61fb2b4459b3385d427b7b39e0eec38d27b9c03949e5"
STAGER = "103f4a3f84e20344b59e57c799e29dfedf2b95242ea82181f0c8ef91266fb297"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def pin(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def write_new(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)


def main():
    frozen = json.loads((HERE / "source-bundle-manifest.json").read_bytes())
    admission_path = HERE / "raw/inputs" / SCOPE / "materialization.json"
    admission = json.loads(admission_path.read_bytes())
    materialization = json.loads((HERE / "materialization/receipt.json").read_bytes())
    stage = json.loads((HERE / "format-receipt.json").read_bytes())
    if pin(admission_path) != frozen["materialization_manifest"]:
        raise RuntimeError("Frozen source admission differs")
    expected = {row["path"]: row for row in frozen["bundle_files"]}
    before = {row["path"]: row for row in stage["before"]}
    after = {row["path"]: row for row in stage["after"]}
    if (stage.get("completed") is not True or stage.get("script_sha256") != STAGER
            or stage.get("runner_sha256") != RUNNER or stage.get("archive_sha256") != frozen["bundle"]["sha256"]
            or before != expected or set(after) != set(before)
            or len(before) != len(stage["before"]) or len(after) != len(stage["after"])):
        raise RuntimeError("Exact six-file staging did not complete")
    fmt = stage.get("format", {})
    if (fmt.get("exit_code") != 0 or fmt.get("settled") is not True or fmt.get("timed_out") is not False
            or fmt.get("process_tree_unresolved") or fmt.get("termination_error")):
        raise RuntimeError("Formatter did not settle successfully")
    for name, row in after.items():
        if not name.endswith(".go") and row != before[name]:
            raise RuntimeError("Non-Go input changed")
        if pin(HERE / "formatted" / name) != {key: row[key] for key in ("bytes", "sha256")}:
            raise RuntimeError("Exact after-format bytes must be read back: " + name)
    if (materialization.get("completed") is not True or materialization.get("errors")
            or materialization.get("helper_sha256") != admission["helper_sha256"]
            or materialization.get("manifest_sha256") != pin(admission_path)["sha256"]
            or materialization.get("stage_receipt_sha256") != pin(HERE / "format-receipt.json")["sha256"]
            or materialization.get("destination_created") is not True
            or materialization.get("fixture_directory_created") is not True
            or materialization.get("inputs_before") != [after[n] for n in sorted(after)]
            or materialization.get("inputs_after") != materialization["inputs_before"]):
        raise RuntimeError("Successful exact materialization readback is required")
    addition = {"path": FIXTURE, "bytes": 12055, "sha256": "66edc3230924cb22f31235ebdc0a607e4a1e227db117209f56c24b7d49139ace"}
    source_rows = sorted(admission["source_files"], key=lambda row: row["path"])
    desired = sorted([*source_rows, addition], key=lambda row: row["path"])
    for name, rows, dirs in (
            ("before", source_rows, sorted(admission["source_directories"])),
            ("after", desired, sorted([*admission["source_directories"], str(PureWindowsPath(FIXTURE).parent).replace("\\", "/")]))):
        inventory = json.loads((HERE / "materialization" / ("source-" + name + ".json")).read_bytes())
        digest = sha(json.dumps(rows, separators=(",", ":"), ensure_ascii=True).encode())
        if (inventory["files"] != rows or inventory["directories"] != dirs or inventory["inventory_sha256"] != digest
                or materialization["source_" + name] != {"files": len(rows), "inventory_sha256": digest}):
            raise RuntimeError("Physical source is not exact 858 plus one embedded fixture")
    trace = frozen["trace"]
    if pin(HERE.parent / "inputs" / trace["path"]) != {key: trace[key] for key in ("bytes", "sha256")}:
        raise RuntimeError("Existing local trace readback differs")
    inputs = [{**row, "path": row["path"].removeprefix("inputs/")} for row in after.values()]
    inputs.append(trace)
    inputs.sort(key=lambda row: row["path"])
    plan = {
        "schema": 1, "phase": "cmake-sdk-profile", "runner_sha256": RUNNER, "native_scheduler_operations": False,
        "source_directory": "source", "source_head": admission["source_head"], "source_tree": admission["source_tree"],
        "source_files": desired, "source_materialization": {"addition": addition,
            "receipt_sha256": pin(HERE / "materialization/receipt.json")["sha256"],
            "note": "Physical preserved858 source plus exactly one untracked embed fixture; Git HEAD/tree describe the baseline, not this augmented file inventory."},
        "inputs_directory": "inputs", "input_files": inputs,
        "environment": {"MCPHUB_CMAKE_SDK_PROFILE_TRACE": str(D / "inputs" / trace["path"]),
                        "MCPHUB_CMAKE_SDK_PROFILE_SHA256": trace["sha256"]},
        "commands": [{"label": "sdk-profile", "tool": "go", "timeout_seconds": 300, "expected_exit_code": 0,
            "args": ["test", "-buildvcs=false", "-mod=readonly", "-overlay", str(D / "inputs" / SCOPE / "overlay.json"),
                     "-p=2", "-json", "-run", "^$", "-bench", "^BenchmarkCMakeTraceSDKConsumer$",
                     "-benchtime=1x", "-count=1", "-timeout=240s", "./internal/vcpkgmcp/vcpkgserver"],
            "required_output": ["CMAKE_TRACE_SDK_PROFILE_V1"], "required_tests": {"pass": ["PACKAGE:" + PACKAGE]}}],
        "additional_runtime_review_required": frozen["runtime_oracle"],
    }
    raw = encoded(plan)
    write_new(HERE / "cmake-sdk-profile-plan.json", raw)
    bundle = HERE / "cmake-sdk-profile-plan.zip"
    with zipfile.ZipFile(bundle, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr("inputs/plans/cmake-sdk-profile.json", raw)
    write_new(HERE / "cmake-sdk-profile-plan.b64", base64.b64encode(bundle.read_bytes()))
    result = {"status": "PLAN_FROZEN_NOT_RUN", "plan": pin(HERE / "cmake-sdk-profile-plan.json"),
              "bundle": pin(bundle), "source_files": len(desired), "input_files": len(inputs),
              "format_receipt": pin(HERE / "format-receipt.json"),
              "materialization_receipt": pin(HERE / "materialization/receipt.json")}
    write_new(HERE / "final-plan-index.json", encoded(result))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
