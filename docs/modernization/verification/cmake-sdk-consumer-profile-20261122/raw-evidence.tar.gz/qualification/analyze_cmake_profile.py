"""Verify the frozen post-run CMake consumer oracle against primary JSON."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'qualification/results/cmake'

def pin(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

receipt = json.loads((DATA / 'receipt.json').read_bytes())
assert receipt['completed'] and receipt['source_before'] == receipt['source_after']
assert receipt['inputs_before'] == receipt['inputs_after']
assert len(receipt['commands']) == 1
command = receipt['commands'][0]
assert command['settled'] and not command['timed_out'] and command['exit_code'] == 0
for stream in ('stdout', 'stderr'):
    assert pin(DATA / ('sdk-profile.' + stream + '.log')) == command[stream]
assert command['stderr']['bytes'] == 0
events = [json.loads(line) for line in (DATA / 'sdk-profile.stdout.log').read_bytes().splitlines()]
terminals = [(e['Action'], e.get('Test'), e['Package']) for e in events if e['Action'] in ('pass', 'fail', 'skip')]
assert terminals == [('pass', None, 'mcp-local-hub/internal/vcpkgmcp/vcpkgserver')]
output = ''.join(e.get('Output', '') for e in events)
marker = 'CMAKE_TRACE_SDK_PROFILE_V1 '
assert output.count(marker) == 1
profile, _ = json.JSONDecoder().raw_decode(output.split(marker, 1)[1])
oracle = json.loads((ROOT / 'qualification/cmake-package/source-bundle-manifest.json').read_bytes())['runtime_oracle']
for key, expected in oracle['profile'].items():
    if key == 'cases':
        continue
    if key == 'sdk_module_replace':
        assert key not in profile
    else:
        assert profile[key] == expected, key
assert len(profile['cases']) == len(oracle['profile']['cases']) == 3
summary = []
for case, expected in zip(profile['cases'], oracle['profile']['cases']):
    assert all(case[key] == value for key, value in expected.items())
    assert case['state'] == 'complete' and case['error'] == case['close_error'] == ''
    assert not case['close_forced'] and case['unsettled_workers'] == 0 and case['sampler_settled']
    count = case['workers'] * case['calls_per_worker']
    calls = case['calls']
    assert len(calls) == count + 2
    assert Counter(row['id'] for row in calls) == Counter(['warm-full', 'warm-projected', *['call-' + str(i) for i in range(count)]])
    warm = [row for row in calls if row['stage'] == 'warmup']
    measured = [row for row in calls if row['stage'] == 'measured']
    assert len(warm) == 2 and len(measured) == count
    for call in calls:
        assert call['received'] == call['completed'] == 1
        assert call['outcome'] in ('delivered', 'cancelled') and not call.get('error')
        assert not call['handler_tool_error']
        if call['outcome'] == 'delivered':
            assert call['handler_result_status'] == 'ok'
            assert call['response_bytes'] > 0 and len(call['response_sha256']) == 64
        else:
            assert call['client_error'] == 'context canceled'
    assert all(row['outcome'] == 'delivered' for row in warm)
    counts = case['counts']
    for key in ('planned', 'submitted', 'received', 'completed', 'client_returned'):
        assert counts[key] == count, key
    for key in ('active_handlers', 'unrecognized', 'unaccounted', 'unreturned', 'error', 'handler_errors', 'handler_observation_errors'):
        assert counts[key] == 0, key
    assert counts['max_active_handlers'] <= case['workers']
    outcomes = Counter(row['outcome'] for row in measured)
    assert counts['delivered'] == outcomes['delivered'] and counts['cancelled'] == outcomes['cancelled']
    assert counts['server_canceled'] == sum(row.get('handler_context_error') == 'context canceled' for row in measured)
    assert counts['server_canceled_result'] == sum(row.get('handler_result_reason') == 'canceled' for row in measured)
    if case['cancel_on_handler_entry']:
        assert counts['cancel_requested'] == count
        assert counts['cancelled'] > 0 and counts['server_canceled'] > 0 and counts['server_canceled_result'] > 0
    else:
        assert counts['delivered'] == count and counts['cancelled'] == counts['cancel_requested'] == 0
    latency = sorted(row['client_latency_ns'] for row in measured)
    assert min(latency) >= 0
    summary.append({
        'workers': case['workers'], 'cancel_on_handler_entry': case['cancel_on_handler_entry'],
        'counts': counts, 'warmup_calls': 2, 'raw_calls': len(calls),
        'client_latency_ns_nearest_rank': {'min': latency[0], 'p50': latency[math.ceil(.5 * count) - 1],
                                         'p95': latency[math.ceil(.95 * count) - 1], 'max': latency[-1],
                                         'zero_observations': latency.count(0)},
        'sampled_peak_lower_bounds': case['sampled_peak_lower_bounds'],
        'held_after_gc': case['responses_held_open_session_after_gc'],
        'released_closed_after_gc': case['responses_released_closed_session_after_gc'],
        'allocated_bytes_whole_process': case['allocated_bytes_whole_process'],
        'cancel_to_handler_return_ns': [row['cancel_to_handler_return_ns'] for row in measured] if case['cancel_on_handler_entry'] else [],
    })
result = {
    'schema': 1, 'status': 'QUALIFIED_FIXED_CAMPAIGN', 'reviewer': 'root',
    'receipt': pin(DATA / 'receipt.json'), 'stdout': command['stdout'], 'stderr': command['stderr'],
    'source': {'head': receipt['source_head'], 'tree': receipt['source_tree'],
               'scope': 'preserved858 + physical oracle JSON + exactly three Go overlays',
               'source_inventory': receipt['source_after'], 'input_inventory': receipt['inputs_after']},
    'profile_root': {key: value for key, value in profile.items() if key != 'cases'},
    'cases': summary,
    'totals': {'measured': sum(c['counts']['planned'] for c in summary), 'warmup': 6,
               'delivered_measured': sum(c['counts']['delivered'] for c in summary),
               'cancelled_measured': sum(c['counts']['cancelled'] for c in summary),
               'raw_calls': sum(c['raw_calls'] for c in summary)},
    'review_notes': [
        'Every call is accounted exactly once; all 24 measured normal responses and six warmups were delivered.',
        'All eight cancellation calls reached the server, returned canceled to the client and produced a canceled server context/result.',
        'Cancellation window produced one memory sample, which is the baseline. It is not a useful estimate of that window peak.',
        'Zero duration observations remain zero measurements at the host clock resolution; they do not mean instantaneous execution.',
        'Three cases share one process and warmed file cache; no production SLO, isolated-parser memory, leak proof or before/after improvement is inferred.',
    ],
}
(ROOT / 'evidence/cmake-sdk-profile-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'totals': result['totals'],
                  'case_latency': [c['client_latency_ns_nearest_rank'] for c in summary]}))
