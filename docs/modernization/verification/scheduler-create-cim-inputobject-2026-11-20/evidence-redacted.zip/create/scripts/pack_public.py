"""Package only retained public-safe evidence; never inspect caches or private XML."""
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(r"<WORK_ROOT>\mcp-r17-create-conflict-20261120")
FAILED = Path(r"<WORK_ROOT>\mcp-r17-cim-inputobject-20261120")
HASHES = Path(r"<WORK_ROOT>\mcp-r17-cim-inputobject-hashes-20261120")
SHAPE = Path(r"<WORK_ROOT>\mcp-r17-cim-structure-20261120")
OUT = ROOT / "public-evidence"
OUT.mkdir(exist_ok=False)
digest = lambda b: hashlib.sha256(b).hexdigest()
jsonbytes = lambda v: (json.dumps(v, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
phases = ("prepare", "recover-prepare", "focused", "build-vet", "published-checkout", "published")
items = []
for name in ("check_create.initial.py", "check_create.py", "checkout_published.py", "pack_public.py"):
    items.append(("create/scripts/" + name, ROOT / name))
for phase in phases:
    folder = ROOT / "evidence" / phase
    for path in sorted(folder.iterdir()):
        if path.suffix not in {".json", ".log"} or not path.is_file():
            raise RuntimeError("Unexpected evidence member")
        items.append(("create/" + phase + "/" + path.name, path))
for label, root, names in (
    ("native-initial", FAILED, ("probe_inputobject.py", "receipt.json", "evidence/stdout.log", "evidence/stderr.log", "diagnose_acl.py", "acl-diagnostic.stdout.json", "acl-diagnostic.stderr.log")),
    ("native-hashes", HASHES, ("probe_inputobject_hashes.py", "receipt.json")),
    ("native-structure", SHAPE, ("probe_export_structure.py", "receipt.json", "parse_structure.py", "parser-receipt.json")),
):
    if list((root / "evidence").glob("*.xml.private")):
        raise RuntimeError("Unexpected retained private definition")
    items.extend((label + "/" + name, root / name) for name in names)

originals = {path: path.read_bytes() for _, path in items}
receipts = {p: json.loads(originals[ROOT / "evidence" / p / "receipt.json"]) for p in phases}
if receipts["prepare"]["completed"] or not all(receipts[p]["completed"] for p in phases[1:]):
    raise RuntimeError("Unexpected phase completion")
published = receipts["published"]
if published["source_head"] != "b7831aabdb7162b3a39c78e73c3ab67558236d1d" or published["source_tree"] != "b55002a0255e8cd226c84afa00499c12c2906c0e" or published["working_status"]:
    raise RuntimeError("Published source is not qualified")

command_summary = []
raw_streams_verified = 0
for phase, receipt in receipts.items():
    for command in receipt["commands"]:
        if not command.get("settled", command.get("direct_child_settled", False)):
            raise RuntimeError("Unsettled command")
        for stream in ("stdout", "stderr"):
            raw = originals[ROOT / "evidence" / phase / (command["label"] + "." + stream + ".log")]
            if {"bytes": len(raw), "sha256": digest(raw)} != command[stream]:
                raise RuntimeError("Original stream digest mismatch")
            raw_streams_verified += 1
        tests = command.get("tests")
        if tests is not None:
            events = [json.loads(line) for line in originals[ROOT / "evidence" / phase / (command["label"] + ".stdout.log")].decode("utf-8").splitlines()]
            actual = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
            if actual != tests:
                raise RuntimeError("Event receipt mismatch")
        row = {k: command[k] for k in ("label", "args", "exit_code", "seconds", "stdout", "stderr")}
        row["phase"] = phase
        if tests is not None:
            row["events"] = {a: {"test": sum(not n.startswith("PACKAGE:") for n in tests[a]), "package": sum(n.startswith("PACKAGE:") for n in tests[a])} for a in tests}
            row["skips"] = tests["skip"]
        command_summary.append(row)

native = {label: json.loads(originals[root / "receipt.json"]) for label, root in (("initial_protection_failure", FAILED), ("inputobject", HASHES), ("structure", SHAPE))}
for stream in ("stdout", "stderr"):
    raw = originals[FAILED / "evidence" / (stream + ".log")]
    if {"bytes": len(raw), "sha256": digest(raw)} != native["initial_protection_failure"][stream]:
        raise RuntimeError("Original native failure stream mismatch")
    raw_streams_verified += 1
if native["inputobject"]["passed"] or native["inputobject"]["result"]["outcome"] != "MISMATCH" or native["structure"]["result"]["outcome"] != "COMPARISON_COMPLETE":
    raise RuntimeError("Unexpected native result")

summary = {"schema": 1, "code_commit": published["source_head"], "code_tree": published["source_tree"],
           "parent": published["base"], "candidate_identity": "parent tree plus two exact source hashes; candidate HEAD alone is not the changed tree",
           "source_sha256": published["source_sha256"], "commands": command_summary, "native": native,
           "recovered_control_rerun": False, "raw_command_streams_verified": raw_streams_verified,
           "full_gates": {"untagged": {"status": "NOT_RUN", "reason": "D-only state isolation not qualified on this branch; four TestMain fences belong to separate PR658"},
                          "tagged_api_cli": {"status": "NOT_RUN", "reason": "Has state isolation; unchanged unqualified Product/entrypoint inputs and historical blockers; no new discriminating hypothesis"}},
           "historical_full_97216816": {"untagged_status": "FAIL", "untagged_seconds": 400.641, "tagged_api_cli_status": "FAIL", "tagged_api_cli_seconds": 322.436},
           "whole_process_tree_deadline_enforced": False, "native_task_mutations": [],
           "raw_native_xml_retained": False, "raw_hashes_probe_streams_retained": False,
           "semantic_equivalence_claimed": False, "product_export_changed": False,
           "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat()}

private_tokens = [os.environ.get(k, "") for k in ("USERNAME", "USERDOMAIN", "COMPUTERNAME")]
private_tokens = sorted({t for t in private_tokens if len(t) >= 3 and t.lower() not in {"system", "user", "windows", "builtin"}}, key=len, reverse=True)
def redact(raw):
    s = raw.decode("utf-8")
    s = re.sub(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT", "<WORK_ROOT>", s)
    s = re.sub(r"(?i)C:[\\/]{1,4}Users[\\/]{1,4}[^\\/\s\"]+", "<USER_PROFILE>", s)
    s = re.sub(r"(?i)S-1-5-21-(?:\d+-){2,}\d+", "<USER_SID>", s)
    s = re.sub("<SELECTED_TASK>", "<SELECTED_TASK>", s, flags=re.I)
    for token in private_tokens:
        s = re.sub(re.escape(token), "<LOCAL_IDENTITY>", s, flags=re.I)
    if re.search(r"(?i)D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT|C:[\\/]{1,4}Users[\\/]{1,4}|S-1-5-21-(?:\d+-){2,}\d+|<SELECTED_TASK>", s):
        raise RuntimeError("Unredacted private marker")
    return s.encode("utf-8")

members = {}
manifest = {"schema": 1, "redaction": "Fixed work root, user profile, local identity, personal Windows SID and selected native task name replaced; original and saved hashes are separate. Redacted observer scripts are audit records, not directly runnable inputs.", "files": []}
for label, path in items:
    raw = originals[path]
    saved = redact(raw)
    if path.read_bytes() != raw:
        raise RuntimeError("Source changed during packaging")
    if label in members:
        raise RuntimeError("Duplicate archive member")
    members[label] = saved
    manifest["files"].append({"path": label, "source_bytes": len(raw), "source_sha256": digest(raw), "saved_bytes": len(saved), "saved_sha256": digest(saved), "redacted": saved != raw})
for label, raw in (("execution-summary.json", redact(jsonbytes(summary))), ("source-identities.json", jsonbytes({"commit": published["source_head"], "tree": published["source_tree"], "files_sha256": published["source_sha256"]}))):
    members[label] = raw
    manifest["files"].append({"path": label, "source_bytes": len(raw), "source_sha256": digest(raw), "saved_bytes": len(raw), "saved_sha256": digest(raw), "redacted": False, "generated_public_record": True})
members["MANIFEST.json"] = jsonbytes(manifest)
archive = OUT / "evidence-redacted.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026, 11, 20, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o600 << 16
        z.writestr(entry, data)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or set(z.namelist()) != set(members):
        raise RuntimeError("Archive integrity mismatch")
    for row in manifest["files"]:
        raw = z.read(row["path"])
        if digest(raw) != row["saved_sha256"] or len(raw) != row["saved_bytes"]:
            raise RuntimeError("Saved manifest mismatch")
archive_data = archive.read_bytes()
metadata = {"schema": 1, "archive": archive.name, "bytes": len(archive_data), "sha256": digest(archive_data),
            "entries": len(members), "manifest_files": len(manifest["files"]), "raw_command_streams_verified": raw_streams_verified,
            "original_hashes_distinct_from_saved_hashes": True, "crc_and_manifest_verified": True}
for name, raw in (("execution-summary.json", members["execution-summary.json"]), ("archive-metadata.json", jsonbytes(metadata)), ("MANIFEST.json", members["MANIFEST.json"])):
    with (OUT / name).open("xb") as f:
        f.write(raw)
print(json.dumps(metadata), flush=True)
