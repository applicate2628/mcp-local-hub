"""Offline checks for a two-file Scheduler change in an isolated local clone."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(r"<WORK_ROOT>\mcp-r17-create-conflict-20261120")
SOURCE = ROOT / "source"
OLD = Path(r"<WORK_ROOT>\mcp-r17-last-result-20261120\source")
BASE = "9721681633440d3593d37ffb8f580e5d98440da2"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
TEST = "internal/scheduler/scheduler_create_conflict_windows_test.go"
PRODUCT = "internal/scheduler/scheduler_windows.go"
NAME = "TestSchedulerCreateConflictPreservesDefinitionAndImportReplaces"
phase = sys.argv[1]
if os.name != "nt" or sys.flags.optimize or phase not in {"prepare", "focused", "build-vet", "tagged-gate", "published"}:
    raise SystemExit("Unsupported invocation")
out = ROOT / "evidence" / phase
out.mkdir(parents=True, exist_ok=False)
runtime = ROOT / "runtime" / phase
for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks"):
    (runtime / name).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("MCPHUB_")}
system = Path(env.get("SYSTEMROOT") or env["SystemRoot"])
ps = system / "System32/WindowsPowerShell/v1.0/powershell.exe"
env.update({
    "GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly",
    "GOCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gocache",
    "GOMODCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache",
    "GOPATH": str(runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
    "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
    "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"),
    "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
    "PSModuleAnalysisCachePath": str(runtime / "localappdata/module-cache"), "PYTHONDONTWRITEBYTECODE": "1",
    "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"),
})
env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))
for path in (GO, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    if not path.exists():
        raise SystemExit("Missing pre-existing tool/cache: " + str(path))
files = json.loads((ROOT / "source-files.json").read_text(encoding="utf-8"))
if {f["path"] for f in files} != {TEST, PRODUCT} or len(files) != 2:
    raise SystemExit("Unexpected candidate file list")
sha = lambda data: hashlib.sha256(data).hexdigest()
for item in files:
    if sha(item["content"].encode()) != item["sha256"]:
        raise SystemExit("Candidate digest mismatch")
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
receipt = {"schema": 1, "phase": phase, "base": BASE, "started_utc": utc(),
           "runner_sha256": sha(Path(__file__).read_bytes()), "commands": [], "completed": False,
           "native_task_operations": False, "whole_process_tree_deadline_enforced": False,
           "environment": {k: env[k] for k in ("GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB", "GOVCS", "GOWORK", "GOFLAGS", "GOTELEMETRY", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")}}

def git_at(path, *args):
    return subprocess.check_output([str(GIT), "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), "-C", str(path), *args], env=env, timeout=60).decode("utf-8").strip()

def run(label, executable, args, cwd=SOURCE):
    row = {"label": label, "executable": executable.name, "args": args, "started_utc": utc(), "settled": False}
    receipt["commands"].append(row)
    print("START " + label, flush=True)
    started = time.monotonic()
    with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
        with subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr) as child:
            row["pid"] = child.pid
            row["exit_code"] = child.wait()
            row["settled"] = True
    row.update(seconds=time.monotonic()-started, finished_utc=utc())
    for stream in ("stdout", "stderr"):
        raw = (out / (label + "." + stream + ".log")).read_bytes()
        row[stream] = {"bytes": len(raw), "sha256": sha(raw)}
    if args and args[0] == "test" and "-json" in args:
        events = []
        for line in (out / (label + ".stdout.log")).read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                continue
        row["tests"] = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
    with (out / (label + ".receipt.json")).open("x", encoding="utf-8") as stream:
        json.dump(row, stream, indent=2)
    print(json.dumps({k: row[k] for k in ("label", "exit_code", "seconds", "settled")}), flush=True)
    return row

def require_pass(row):
    if row["exit_code"] != 0:
        raise RuntimeError(row["label"] + " failed")

def admit_candidate(expected):
    if git_at(SOURCE, "rev-parse", "HEAD") != expected:
        raise RuntimeError("Unexpected source head")
    expected_status = "" if phase == "published" else " M " + PRODUCT + "\n?? " + TEST
    actual_lines = git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching").splitlines()
    if sorted(line.strip() for line in actual_lines) != sorted(line.strip() for line in expected_status.splitlines()):
        raise RuntimeError("Unexpected tracked, staged, untracked or ignored source state: " + repr(actual_lines))
    if git_at(SOURCE, "diff", "--cached", "--name-only"):
        raise RuntimeError("Unexpected staged changes")
    hashes = {item["path"]: sha((SOURCE / item["path"]).read_bytes()) for item in files}
    if any(hashes[item["path"]] != item["sha256"] for item in files):
        raise RuntimeError("Candidate source changed")
    return hashes

try:
    if phase == "prepare":
        if SOURCE.exists() or git_at(OLD, "rev-parse", "HEAD") != BASE or git_at(OLD, "status", "--porcelain=v1", "--untracked-files=all"):
            raise RuntimeError("Source not admitted or destination exists")
        require_pass(run("clone", GIT, ["-c", "core.autocrlf=false", "clone", "--local", "--no-hardlinks", "--no-checkout", str(OLD), str(SOURCE)], ROOT))
        git_at(SOURCE, "config", "core.autocrlf", "false")
        git_at(SOURCE, "checkout", "--detach", BASE)
        if git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"):
            raise RuntimeError("Fresh clone is not clean")
        for item in files:
            if item["path"] == TEST:
                (SOURCE / TEST).write_bytes(item["content"].encode())
        require_pass(run("go-version", GO, ["version"]))
        require_pass(run("format-test", GO.with_name("gofmt.exe"), ["-w", TEST]))
        control = run("original-create-control", GO, ["test", "-json", "-count=1", "-timeout=60s", "-run", "^"+NAME+"$", "./internal/scheduler"])
        text = (out / "original-create-control.stdout.log").read_text(encoding="utf-8")
        if control["exit_code"] != 1 or NAME not in control["tests"]["fail"] or "duplicate Create error=<nil>" not in text:
            raise RuntimeError("Original control did not fail for the intended conflict")
        receipt["negative_control_confirmed"] = True
        if git_at(SOURCE, "diff", "--name-only"):
            raise RuntimeError("Control changed tracked source")
        for item in files:
            if item["path"] == PRODUCT:
                (SOURCE / PRODUCT).write_bytes(item["content"].encode())
        require_pass(run("format-candidate", GO.with_name("gofmt.exe"), ["-w", PRODUCT, TEST]))
        receipt["source_sha256_after"] = admit_candidate(BASE)
    else:
        expected = sys.argv[2] if phase == "published" else BASE
        receipt["source_sha256_before"] = admit_candidate(expected)
        if phase in {"focused", "published"}:
            require_pass(run("create-conflict-race", GO, ["test", "-json", "-race", "-count=2", "-timeout=120s", "-run", "^"+NAME+"$", "./internal/scheduler"]))
            require_pass(run("scheduler-race", GO, ["test", "-json", "-race", "-count=2", "-timeout=180s", "./internal/scheduler"]))
        elif phase == "build-vet":
            require_pass(run("build", GO, ["build", "./..."]))
            require_pass(run("vet", GO, ["vet", "./..."]))
        elif phase == "tagged-gate":
            run("tagged-api-cli", GO, ["test", "-json", "-tags=test_state_path_env", "-count=1", "-timeout=5m", "./internal/api/", "./internal/cli/"])
        receipt["source_sha256_after"] = admit_candidate(expected)
    require_pass(run("diff-check", GIT, ["diff", "--check"]))
    receipt["source_head"] = git_at(SOURCE, "rev-parse", "HEAD")
    receipt["source_tree"] = git_at(SOURCE, "rev-parse", "HEAD^{tree}")
    receipt["working_status"] = git_at(SOURCE, "status", "--porcelain=v1", "--untracked-files=all")
    receipt["source_sha256"] = {item["path"]: sha((SOURCE / item["path"]).read_bytes()) for item in files}
    receipt["completed"] = True
finally:
    receipt["finished_utc"] = utc()
    with (out / "receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt), flush=True)
