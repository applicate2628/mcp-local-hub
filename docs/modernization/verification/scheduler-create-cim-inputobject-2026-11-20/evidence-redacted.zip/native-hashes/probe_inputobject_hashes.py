"""One new read-only CIM InputObject export experiment; never changes tasks.

Raw definitions and exception messages never leave process memory.
The retained direct child has a 45-second deadline, not a process-tree guarantee.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

if os.name != "nt" or sys.flags.optimize:
    raise SystemExit("Windows without Python optimization is required")

ROOT = Path(r"<WORK_ROOT>\mcp-r17-cim-inputobject-hashes-20261120")
OUT = ROOT / "evidence"
if ROOT.resolve(strict=True) != ROOT or OUT.exists():
    raise SystemExit("Expected a fresh evidence directory under the fixed work root")
OUT.mkdir()
env = os.environ.copy()
for key in ("TEMP", "TMP", "TMPDIR", "USERPROFILE", "APPDATA", "LOCALAPPDATA"):
    folder = ROOT / "runtime" / key.lower()
    folder.mkdir(parents=True, exist_ok=False)
    env[key] = str(folder)
env["PSModuleAnalysisCachePath"] = str(ROOT / "runtime" / "ps-module-cache")
env["PYTHONDONTWRITEBYTECODE"] = "1"
ps = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
env["PSModulePath"] = str(ps.parent / "Modules")

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$utf8 = [Text.UTF8Encoding]::new($false, $true)
[Console]::OutputEncoding = $utf8
$receipt = [ordered]@{schema=1; outcome='INCOMPLETE'; phase='module'; task_mutations=@(); atomicity_claim=$false; product_changed=$false}
$service = $null
$folder = $null
$before = $null
$after = $null
function Hash-Bytes([byte[]]$bytes) {
  $algorithm = [Security.Cryptography.SHA256]::Create()
  try { return [BitConverter]::ToString($algorithm.ComputeHash($bytes)).Replace('-', '').ToLowerInvariant() }
  finally { $algorithm.Dispose() }
}
function XML-Digest([string]$xml) {
  $bytes = $utf8.GetBytes($xml)
  return [ordered]@{bytes=$bytes.Length; sha256=(Hash-Bytes $bytes); non_ascii_code_units=@($xml.ToCharArray() | Where-Object { [int]$_ -gt 127 }).Count}
}
try {
  $receipt.phase = 'module'
  $modulePath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\Modules\ScheduledTasks\ScheduledTasks.psd1'
  $module = @(Import-Module -Name $modulePath -PassThru -ErrorAction Stop)
  $get = @(Get-Command -Name Get-ScheduledTask -Module ScheduledTasks -ErrorAction Stop)
  $export = @(Get-Command -Name Export-ScheduledTask -Module ScheduledTasks -ErrorAction Stop)
  if ($get.Count -ne 1 -or $export.Count -ne 1) { throw 'Ambiguous command' }
  $receipt.module_versions = @($module | ForEach-Object { [ordered]@{name=$_.Name; version=$_.Version.ToString()} })
  $receipt.powershell_version = $PSVersionTable.PSVersion.ToString()
  $receipt.phase = 'com-before'
  $service = New-Object -ComObject Schedule.Service
  $service.Connect()
  $folder = $service.GetFolder('\')
  $before = $folder.GetTask('<SELECTED_TASK>')
  $beforeXML = [string]$before.Xml
  if ([string]::IsNullOrEmpty($beforeXML)) { throw 'Empty COM definition' }
  $receipt.com_before = XML-Digest $beforeXML
  $receipt.hidden = [bool]$before.Definition.Settings.Hidden
  $receipt.phase = 'select-cim'
  # The earlier name-based export changed the XML URI when query case differed.
  $tasks = @(& $get[0] -TaskName '<SELECTED_TASK>' -TaskPath '\' -ErrorAction Stop)
  if ($tasks.Count -ne 1) { throw 'CIM selection was not unique' }
  $task = $tasks[0]
  if (-not [string]::Equals([string]$task.TaskName, '<SELECTED_TASK>', [StringComparison]::OrdinalIgnoreCase) -or [string]$task.TaskPath -cne '\') { throw 'CIM returned a different task' }
  $receipt.cim_type = $task.GetType().FullName
  $receipt.cim_class = [string]$task.CimClass.CimClassName
  $receipt.selector_case_variant = $true
  $receipt.cim_name_matches_com_ordinal = [string]::Equals([string]$task.TaskName, [string]$before.Name, [StringComparison]::Ordinal)
  $receipt.exact_selection = $true
  $receipt.phase = 'export-inputobject'
  $timer = [Diagnostics.Stopwatch]::StartNew()
  $values = @(& $export[0] -InputObject $task -ErrorAction Stop)
  $timer.Stop()
  if ($values.Count -ne 1 -or $values[0] -isnot [string]) { throw 'Export did not return one XML string' }
  $cimXML = [string]$values[0]
  $receipt.cim_export = XML-Digest $cimXML
  $receipt.export_seconds = $timer.Elapsed.TotalSeconds
  $receipt.output_count = $values.Count
  $receipt.phase = 'com-after'
  $after = $folder.GetTask('<SELECTED_TASK>')
  $afterXML = [string]$after.Xml
  $receipt.com_after = XML-Digest $afterXML
  $receipt.definition_stable = [string]::Equals($beforeXML, $afterXML, [StringComparison]::Ordinal)
  $receipt.equal_to_com_before = [string]::Equals($cimXML, $beforeXML, [StringComparison]::Ordinal)
  $receipt.equal_to_com_after = [string]::Equals($cimXML, $afterXML, [StringComparison]::Ordinal)
  $receipt.phase = 'consumer'
  $document = [Xml.XmlDocument]::new()
  $document.XmlResolver = $null
  $document.LoadXml($cimXML)
  $receipt.task_xml_namespace = $document.DocumentElement.NamespaceURI
  $receipt.xml_parse_passed = $document.DocumentElement.LocalName -ceq 'Task' -and $document.DocumentElement.NamespaceURI -ceq 'http://schemas.microsoft.com/windows/2004/02/mit/task'
  $receipt.actual_product_consumer_exercised = $false
  $receipt.completed = $true
  if ($receipt.definition_stable -and $receipt.equal_to_com_before -and $receipt.equal_to_com_after -and $receipt.xml_parse_passed) { $receipt.outcome = 'PASS_EXACT_SINGLE_INPUTOBJECT_EXPORT' }
  else { $receipt.outcome = 'MISMATCH' }
} catch {
  $receipt.completed = $false
  $receipt.error_type = $_.Exception.GetType().FullName
  $receipt.error_hresult = [int64]$_.Exception.HResult
  $receipt.exception_chain = @()
  $exception = $_.Exception
  for ($depth=0; $null -ne $exception -and $depth -lt 8; $depth++) {
    $receipt.exception_chain += [ordered]@{type=$exception.GetType().FullName; hresult=[int64]$exception.HResult}
    $exception = $exception.InnerException
  }
} finally {
  # COM references belong only to this short-lived, waited process.
  [Console]::WriteLine(($receipt | ConvertTo-Json -Depth 8 -Compress))
}
"""

utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
digest = lambda b: hashlib.sha256(b).hexdigest()
receipt = {
    "schema": 1, "started_utc": utc(), "runner_sha256": digest(Path(__file__).read_bytes()),
    "powershell_script_sha256": digest(SCRIPT.encode()), "powershell_sha256": digest(ps.read_bytes()),
    "deadline_seconds": 45, "whole_process_tree_deadline_enforced": False,
    "source_commit": "9721681633440d3593d37ffb8f580e5d98440da2",
    "source_executed": False, "task_mutations": [], "completed": False, "passed": False,
    "raw_definitions_retained": False, "raw_error_streams_retained": False, "filesystem_acl_writes": 0,
}
started = time.monotonic()
child = None
try:
    with subprocess.Popen([str(ps), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", SCRIPT],
                          cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW) as child:
        receipt["pid"] = child.pid
        try:
            stdout, stderr = child.communicate(timeout=45)
        except subprocess.TimeoutExpired:
            receipt["timed_out"] = True
            child.kill()
            stdout, stderr = child.communicate()
        receipt["returncode"] = child.returncode
        receipt["direct_child_settled"] = child.returncode is not None
    for name, data in (("stdout", stdout), ("stderr", stderr)):
        receipt[name] = {"bytes": len(data), "sha256": digest(data)}
    if child.returncode == 0 and not stderr and not receipt.get("timed_out"):
        result = json.loads(stdout.decode("utf-8", errors="strict"))
        allowed = {"schema", "outcome", "phase", "task_mutations", "atomicity_claim", "product_changed", "module_versions", "powershell_version", "com_before", "hidden", "cim_type", "cim_class", "selector_case_variant", "cim_name_matches_com_ordinal", "exact_selection", "cim_export", "export_seconds", "output_count", "com_after", "definition_stable", "equal_to_com_before", "equal_to_com_after", "task_xml_namespace", "xml_parse_passed", "actual_product_consumer_exercised", "completed", "error_type", "error_hresult", "exception_chain"}
        if not isinstance(result, dict) or set(result) - allowed:
            raise ValueError("Unexpected response fields")
        receipt["result"] = result
        receipt["completed"] = bool(receipt["result"].get("completed"))
        receipt["passed"] = receipt["completed"] and receipt["result"].get("outcome") == "PASS_EXACT_SINGLE_INPUTOBJECT_EXPORT"
    else:
        receipt["outcome"] = "PROCESS_OR_PROTOCOL_FAILURE"
finally:
    receipt.update(seconds=time.monotonic()-started, finished_utc=utc())
    with (ROOT / "receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt), flush=True)

raise SystemExit(0 if receipt["passed"] else 1)
