import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
ROOT = Path(r"<WORK_ROOT>\mcp-r17-cim-structure-20261120")
raw = (ROOT / "probe_export_structure.py").read_bytes()
if hashlib.sha256(raw).hexdigest() != "c1f5dfaac5795ca957bd82da195b53d6765da0028adbc5fa6794ae8374c61eb5":
    raise SystemExit("Source mismatch")
tree = ast.parse(raw)
script = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "SCRIPT" for t in n.targets))
env = dict(os.environ)
for key in ("TEMP","TMP","USERPROFILE","APPDATA","LOCALAPPDATA"):
    folder = ROOT / "parser-runtime" / key.lower()
    folder.mkdir(parents=True, exist_ok=False)
    env[key] = str(folder)
env["PSModuleAnalysisCachePath"] = str(ROOT / "parser-runtime/module-cache")
ps = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
cmd = "$tokens=$null; $errors=$null; [void][System.Management.Automation.Language.Parser]::ParseInput([Console]::In.ReadToEnd(),[ref]$tokens,[ref]$errors); [Console]::WriteLine((@($errors | ForEach-Object { $_.ErrorId }) | ConvertTo-Json -Compress)); if($errors.Count){exit 1}"
r = subprocess.run([str(ps),"-NoLogo","-NoProfile","-NonInteractive","-Command",cmd],input=script.encode("utf-8"),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=ROOT,timeout=15)
result = {"script_sha256":hashlib.sha256(raw).hexdigest(),"parser_exit":r.returncode,"stdout_bytes":len(r.stdout),"stderr_bytes":len(r.stderr),"syntax_pass":r.returncode==0 and not r.stderr}
with (ROOT / "parser-receipt.json").open("x",encoding="utf-8") as f:
    json.dump(result,f,indent=2)
    f.write("\n")
print(json.dumps(result))
raise SystemExit(0 if result["syntax_pass"] else 1)
