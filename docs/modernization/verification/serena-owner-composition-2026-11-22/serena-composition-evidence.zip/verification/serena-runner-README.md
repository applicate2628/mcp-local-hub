# Serena: staged formatting and bounded qualification

Status: **source prepared and statically reviewed; no formatter, runner, Go command or remote operation was executed by this author.** Root reviews and performs any native qualification. The original Go candidate remains frozen.

## Contents

1. [Inputs and identity](#1-inputs-and-identity)
2. [Formatting and mandatory readback](#2-formatting-and-mandatory-readback)
3. [Ten fixed phases](#3-ten-fixed-phases)
4. [Admission and evidence](#4-admission-and-evidence)
5. [Limits and publication](#5-limits-and-publication)

## 1. Inputs and identity

The remote task root is `D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5`. Its existing clean `source-master` checkout must have HEAD `75dbc6406123e22468f168b861d5e0622c9d5769` and tree `cb3eec77c23f9400be962d91c9f23834b84f7643`. The runner has no prepare, fetch or checkout operation. Missing tools or dependency cache are a failed prerequisite; no installation or download is attempted.

The package contains 25 explicit Go overlays: 14 paths already present in that master and 11 new paths. They are the exact final composition from [the source manifest](../../serena-next/master-overlay-manifest.json): 18 changed/new files relative to #643 plus seven retained #643 files. The original candidate manifest SHA256 is `6b498cf8526041640a247db1ebf0a940ce862d232531d186253d407be6f05044`.

**Table 1. Input pins and destination paths.** SHA256 is the SHA-256 content digest; it binds the exact file bytes.

| Local input | Destination relative to the remote task root | SHA256 |
|---|---|---|
| [p0_serena_runner.py](p0_serena_runner.py) | `p0_serena_runner.py` | `c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1` |
| [format_serena_staged.py](format_serena_staged.py) | `format_serena_staged.py` | `c9928ed591b963fc5c3853883883402a3ea3ccccaecb6d2439e9bf8131e086f7` |
| [Unformatted manifest](serena-manifests/serena-staged/manifest.json) | `manifests/serena-staged/manifest.json` | `1b734c86790a3b4b2fc8d30d0074a9fa0fa465a2d8deb6bd648097fd6886d49c` |
| [Static comparison record](serena-runner-source-proof.json) | Evidence/reference only | `6e0608021f7edadf4fd8016ba335873afe748f092b0d29a11671b8f42c812b20` |

Copy the 25 files beneath local `serena-manifests/serena-staged/candidate/` to the same relative `candidate/` paths beneath the new remote `manifests/serena-staged/`. Each file has its own SHA256 and Git blob identity in the manifest. Preserve the original `serena-next` files and the physical master checkout. Do not reuse an existing staged destination or existing phase runtime/evidence directory.

## 2. Formatting and mandatory readback

Run the following entry only with the already admitted Python executable and the approved task root as its working directory. The shown `python` denotes that existing executable; it is not a request to install or discover another interpreter.

```text
python format_serena_staged.py 1b734c86790a3b4b2fc8d30d0074a9fa0fa465a2d8deb6bd648097fd6886d49c c9928ed591b963fc5c3853883883402a3ea3ccccaecb6d2439e9bf8131e086f7
```

This creates the distinct `serena-stage-format` evidence/runtime directories and calls the existing pinned `gofmt.exe` exactly once with `-w` and the 25 staged file paths. Its formatter SHA256 is `95368e4aafefa20f962a345ab02f53ffc035ed69349612abbf385b52f4fb25c5`. It uses the same retained-process owner as the subsequent phases. It never writes the source checkout or the original local candidate.

The formatter writes a separate `manifest.formatted.json`, containing the actual resulting SHA256 and Git blob identities, the unformatted-manifest digest and the formatter-entry digest. Its final receipt contains every resulting Go file's content and identities. No following phase starts automatically.

**Root must read back and review** the successful final `evidence/serena-stage-format/receipt.json`, streams, source/tool identities, all changed staged bytes and the new `manifest.formatted.json`. A file named `manifest.formatted.json` can exist even if a later final identity check fails; its mere presence is not success. Require the final receipt's `completed: true` and `state: complete`, matching stream hashes, unchanged physical source and tools, and the expected native temporary path. Then pin the actual new manifest digest. That digest is unknown before formatting and is not fabricated here.

Only after this readback use the runner interface:

```text
python p0_serena_runner.py serena-format manifests/serena-staged/manifest.formatted.json REVIEWED_FORMATTED_MANIFEST_SHA256
```

Replace the final placeholder with the exact reviewed 64-character digest. Repeat the same interface with one of the fixed phases in Table 2, one phase at a time. This document does not authorize an automatic loop or retry; a failed prerequisite is retained for review. The runner rejects unformatted manifests for all phases except its read-only format check.

## 3. Ten fixed phases

All ten phases use the same 25 explicit overlays. The preliminary staged-format operation from §2 is a separate preparation receipt, not an eleventh qualification gate. Exact argument arrays, anchored test selectors and required root-test pass counts are frozen in the manifest. The six test phases use `-tags=test_state_path_env -race -json -count=1 -timeout=180s -parallel=1`; the retained direct-child deadline is 300 seconds. `-race` enables the Go data-race detector. Tests with skip events cannot qualify.

**Table 2. Fixed phase boundaries.** Root-test counts exclude subtests and the package-level event.

| Phase | Scope | Actual selected effects |
|---|---|---|
| `serena-format` | Existing Go version and `gofmt -l` on all 25 files | Read-only tool/version and formatting checks. |
| `serena-compile` | Tagged race-enabled `go test -c ./internal/api` | Compiles one retained API test executable; does not run its test bodies. |
| `serena-logic` | 11 exact root tests | Data-only predicates and early refusals; ordinary API TestMain still creates its owned temporary state. |
| `serena-temp-refusal` | 3 exact root tests | Temporary fixture paths; qualification/invocation refusal before file opens or contained execution. |
| `serena-native-temp-files` | 4 exact root tests | Temporary file/directory handles, named streams, sharing, byte hashes and a protected-handle close refusal. No fixture executable launch. |
| `serena-native-readonly-link` | `TestSerenaOwnedTreeReadonlyHardlinkDeletion` | Two fixture hardlinks and readonly/archive attributes; removes one nominated link through its original handle. Retains the surviving fixture as evidence. |
| `serena-native-no-child` | `TestPreparedSerenaBuildConstraintPinSettlementNative` | Real empty Windows Job, anonymous pipes and NUL handle. Empty executable path rejects before the contained runner's CreateProcess call. This is not a pure test. |
| `serena-bootstrap-readonly` | `TestSerenaBuildEnvironmentWindowsBuildConstraintPolicy` | Reads embedded manifest and existing Windows/PATH directories; hashes COMSPEC. It can read existing system paths on C, but does not write or execute them. |
| `serena-build` | `go build ./...` | Compiles packages with the exact overlay, existing toolchain and offline cache. Does not run application/test bodies. |
| `serena-vet` | `go vet ./...` | Analyses packages with the exact overlay, existing toolchain and offline cache. Does not run application/test bodies. |

The detailed call-chain review and test-by-test exclusions are in [qualification-plan.json](../../serena-next/qualification-plan.json) and [the Serena source report](../../serena-next/README.md). The plan's current SHA256 is `88f20abd6d489bc64403348d3b14a199c8fb214d79445462ca48e4209c4e1728`.

## 4. Admission and evidence

The runner preserves the original `p0_preserved_runner_v2.py` process owner, capture, source admission, command waits and finalization. That upstream file's SHA256 is `b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641`. All `Runner` methods remain abstract-syntax-tree (AST) identical except the single added admission/receipt assignment in `begin`.

After creating its owned temporary directory and assembling the explicit child environment, each phase calls `GetTempPath2W` when available, otherwise `GetTempPathW`, inside the Python process. It temporarily presents that phase's `TMP`/`TEMP`, requires the returned path to equal the admitted owned directory, records `native_temporary_path: {api, requested, resolved}`, and restores both original environment variables in `finally`. This happens before any child process and before the manifest field that enables final Git observations. A refusal therefore cannot launch a child through `finish`. The staged formatter uses the same `begin`, so it has the same admission. No executable probe is used.

The native path check establishes which location the installed Windows API resolves under the intended temporary environment. It does not prove discretionary-access ownership or eliminate ancestor races. The operation still requires the already admitted, parent-created, non-reparse task subtree on D. Environment redirection is not a sandbox.

The inherited environment disables Go proxy/sum database/VCS fetching, automatic toolchain selection, module edits and telemetry; it uses existing caches on D and `GOFLAGS=-mod=readonly`. Source snapshots require the exact master HEAD/tree, clean physical status and the 25 pinned existing/absent source paths. Candidate bytes and overlay bytes are checked around commands. Receipts retain tool and source identities before/after, raw stdout/stderr with byte counts and hashes, the exact arguments, direct-child status and test events. The test oracle requires every selected root exactly once and no skips; build/compile success is recorded separately from executed tests.

Only the original direct-child wait and termination wait are bounded. Descendant settlement is not inferred after a timeout. Runtime/evidence directories and the explicit readonly hardlink survivor are retained for review; subsequently confirmed disposable artifacts must move to the approved trash, without automatic trash deletion. The runner itself performs no cleanup of these retained trees.

## 5. Limits and publication

This preparation establishes source identity, concrete test entry points and a bounded execution plan. It does not claim successful native execution. Real UV/Python/PyYAML installation/build, package downloads, installed Serena, helper-process execution, original publisher-image qualification, full Ready/finalization/Product behavior and the full Go test suite remain untested. Full build/vet are not a full test-suite result. The no-child pin test cannot establish child-process settlement; synthetic original-owner fixtures cannot establish a real acquired generation's complete authority.

The publication target remains existing PR #643 with exact parent `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60`. Root must bind any later publication to the actual formatted bytes and qualified receipts. This runner's master-plus-25 overlay qualification does not merge master into that older branch. It does not include unrelated #650/#654 or full-file #655 changes; the source report contains the exact #655 nonoverlap/commutation proof. No Git reference or PR action is performed here.
