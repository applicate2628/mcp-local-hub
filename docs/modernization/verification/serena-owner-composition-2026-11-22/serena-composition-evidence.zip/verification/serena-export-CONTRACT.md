# Serena evidence exporter: contract and own review

Status: **source frozen; exporter not imported or executed by this author.** Root reviews and runs it after placing the immutable input packet. There is one fixed evidence family and eleven named phase directories. The mutable `serena-next/publication/qualification.json` is not an exporter input.

## Contents

1. [Upload and exact invocation](#1-upload-and-exact-invocation)
2. [Included evidence and source identity](#2-included-evidence-and-source-identity)
3. [Terminal admission and failures](#3-terminal-admission-and-failures)
4. [Exclusions and output](#4-exclusions-and-output)
5. [Own review and limits](#5-own-review-and-limits)

## 1. Upload and exact invocation

The fixed Windows root is `D:\dev\ChatGPT\mcp-p0-gates-20261121-247107d5`. The output destination is the **new**, previously absent `evidence\serena-export-v1` beneath that root.

**Table 1. Complete new upload selection.** The ZIP expands to exactly 33 regular data/source files; its manifest lists all 32 payload paths and identities.

| Local file | Remote placement/action | Bytes; SHA256 |
|---|---|---|
| [export_serena_evidence.py](export_serena_evidence.py) | Place directly at `ROOT\export_serena_evidence.py` | 27 378; `8d8fe721789117b807779ddf93ef2dcee31e26f5e6fc0d8e9ae90edff66d8843` |
| [serena-export-inputs.zip](serena-export-inputs.zip) | Transfer as data, then admit and extract its fixed `manifests/serena-export-inputs/` prefix beneath ROOT into a new directory | 99 482; `76609221f014ae8afdd76b4edea4d4af8a3a1bb233bf1afaa162447ef1d52ec7` |

[serena-export-inputs-transfer.json](serena-export-inputs-transfer.json) records the archive and packet-manifest identities. The extracted `manifests/serena-export-inputs/manifest.json` is 12 349 bytes, SHA256 `9137a375367336ea7d001981ce4ef8ad1f456e9b89e80f512b846e612d38fbf9`. The ZIP contains no executable, symlink, runtime directory or installation payload. Its Go files are source bytes only. No existing input directory should be overwritten.

The following inputs already exist and must retain their recorded bytes:

- `ROOT\p0_serena_runner.py`: `c3d746649232b088a403f88d0d42d6ac50f169ee100668d94eafed49a4e551c1`.
- `ROOT\format_serena_staged.py`: `c9928ed591b963fc5c3853883883402a3ea3ccccaecb6d2439e9bf8131e086f7`.
- `ROOT\preserved-input\p0_preserved_runner_v2.py`: `b7ed7f7445440a51c7dc56f998d1bb7a11ff1e82c51e4a4d348e3aafa8927641`.
- `ROOT\manifests\serena-staged\manifest.json`: `1b734c86790a3b4b2fc8d30d0074a9fa0fa465a2d8deb6bd648097fd6886d49c`.
- `ROOT\manifests\serena-staged\manifest.formatted.json`: `6be3cd0aa6a35b586ba623be051acb6e4bed4799bf25e92127efcf6191456ebf`, plus all 25 current formatted candidate files.

With ROOT as cwd, use the already admitted Python interpreter:

```text
python export_serena_evidence.py 8d8fe721789117b807779ddf93ef2dcee31e26f5e6fc0d8e9ae90edff66d8843
```

Here `python` denotes that existing interpreter. The exporter does not search for, install or launch another tool. No subprocess, network, Git, Go or native Windows API call is made.

## 2. Included evidence and source identity

**Table 2. Fixed phase scopes.** The exporter requires every final `receipt.json`; no phase is inferred from a summary or omitted because it is absent.

| Preparation / checks | Fixed directory names under `ROOT\evidence` |
|---|---|
| Staged formatting | `serena-stage-format` |
| Format/version and compilation | `serena-format`, `serena-compile` |
| Logic and early refusal | `serena-logic`, `serena-temp-refusal` |
| Temporary native objects | `serena-native-temp-files`, `serena-native-readonly-link`, `serena-native-no-child` |
| Read-only bootstrap | `serena-bootstrap-readonly` |
| Build and static analysis | `serena-build`, `serena-vet` |

The archive copies the exact runner, formatter, prior retained-process owner and exporter; both pinned manifests; the original 25 Go files and the formatted 25 Go files in separate namespaces; and seven source-only proof JSON (JavaScript Object Notation) files. The full immutable packet inventory is [serena-export-inputs/manifest.json](serena-export-inputs/manifest.json).

Original source bytes are necessary because staged formatting changed two files in place. They are copied from the original frozen local candidate and checked against the original manifest; they are not reconstructed from a diff. The archive uses `inputs/serena-original/` and `inputs/serena-formatted/` so those bytes cannot overwrite or masquerade as one another.

For each phase, selected evidence includes aggregate/final/initial command records, launch records, exact argument arrays, overlays, stdout/stderr logs and oracle files. The command selection is the exact manifest prefix; a completed phase must have every planned command. Git observation records use the runner's `observation-NNNN` labels. The archive also preserves native temporary-path admission, source/tool hashes before and after, and raw Go JSON events.

The readonly-hardlink test records native identity, attributes, link counts and content hashes before/after in its Go output. Those bytes are preserved verbatim. The exporter does not newly inspect the retained runtime fixture or create a stronger native observation than the test recorded.

Every included phase belongs to physical source/master `75dbc6406123e22468f168b861d5e0622c9d5769`, tree `cb3eec77c23f9400be962d91c9f23834b84f7643`, with the 25 explicit overlays. This is not a standalone #643 run or qualification of real UV/PyYAML installation, installed Serena, publisher image, full Product lifecycle or the full test suite.

## 3. Terminal admission and failures

The exporter reads final phase receipts, not `.started` or `receipt-initial` records, to decide whether a stage is terminal. Initial records are preserved as evidence but never interpreted as unfinished final processes. Each selected command must have a matching final command receipt and initial identity; a launched process additionally requires a matching launch record, original process identifier (PID), settled direct-child outcome and integer exit code.

Nonzero exit codes are admitted and copied. If a Go command produced FAIL or SKIP events, those lists remain in its raw stream, command receipt and export manifest. The exporter does not replace them with success or require their count to be zero. It checks a recorded event list against the raw JSON events without dropping package, root or subtest outcomes. A terminal phase with `completed=false/state=failed` remains failed in the archive even if the export itself succeeds.

An absent final phase, dangling launch, unresolved/timed-out capture, missing stream/hash, changed source/tool/runner/input identity or mismatched argv stops admission **before** the destination is created. A terminal launch failure with no PID may be retained as such; it is not treated as an executed command. A terminal preflight refusal before any observation is separately marked `source_observed=false`. Successful stages must retain exact clean source snapshots and native TMP admission. The formatting stage must be successful because it establishes the pinned formatted outputs.

Raw final receipts are not rewritten. Aggregate command records may contain the later oracle field; verification compares their other fields with the earlier command receipt and checks the oracle file separately. This matches the actual runner's save order.

## 4. Exclusions and output

Only direct leaves of the eleven fixed evidence directories are considered; no directory recursion is performed. Process labels are restricted to the manifest commands and declared Git observations. The exporter never reads executables, runtime/temp/profile/cache trees, private audit/traceback files or unselected leaves into the archive. Excluded direct basenames and reasons are listed. An unreferenced process-start/launch/receipt artifact is a refusal rather than a silently discarded process result.

No C-profile audit content is read. Existing qualification tool hashes are copied from their receipts; the exporter does not read tool executables on C. Standard path checks reject lexical escapes and existing reparse points within the approved task root. They do not prove ancestor ownership or eliminate concurrent replacement; the already admitted, parent-created cooperative subtree on D remains a prerequisite.

All selected files are bounded, held as admitted bytes in memory and rehashed before creating the new destination. Limits are 32 MiB per source file, 128 MiB payload and 10 000 payload files. The inherited ZIP/transfer writer uses a fixed timestamp/order and SHA256 readback. It creates:

- `serena-evidence.zip` with `MANIFEST.json` listing payload lengths and SHA256;
- `serena-evidence.transfer.json` and `.transfer.txt` with ZIP/manifest identities and fixed base64 chunks;
- `serena-evidence.receipt.json` and aggregate `receipt.json`.

The internal manifest cannot contain its own final hash; its length/SHA256 are recorded in the sibling transfer metadata and export receipts. Existing or partial output destinations are never overwritten, resumed or deleted. Export completion means an admitted evidence copy was written; it is not a new test result. Confirmed disposable files remain subject to the user's trash-first policy outside this exporter.

## 5. Own review and limits

The existing `export_p0_evidence.py` was read completely. Eleven utility/capture-transfer functions have identical abstract syntax trees (AST), including path admission, bounded reads, payload pinning, stream verification and deterministic ZIP/transfer writing. Its SHA256 is `0e93d060dfd7468df679ce9cd7744a37fed5608811291775d843ec6bcf0f80de`. The new code narrows inputs to one source and eleven phases, adds original/formatted separation and enforces the exact known command/overlay contract.

Own review checked the raw runner save order, final-versus-initial process handling, treatment of nonzero exits and event lists, inherited path/exclusion boundaries, all script and input pins, and the native-before/after observation locations. Static checks parsed the exporter without importing it, compared reused function AST, verified all packet lengths/SHA/Git blobs, read every ZIP entry and CRC, and confirmed mutable `qualification.json` is absent. The record is [serena-export-source-review.json](serena-export-source-review.json).

No confirmed source defect remains in this freeze. This author has not run/imported the exporter and has not enumerated the real remote phase directories. Root's execution must check their actual full final receipts and raw streams. No new process-tree settlement, standalone-head, installer or full-suite qualification is inferred from preparing or exporting these artifacts.
