#!/usr/bin/env python3
"""Verify pinned local source artifacts; no Go, Git, process launch, or network."""

import difflib
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
lineage = json.loads((ROOT / "source/lineage.json").read_text(encoding="utf-8"))
manifest = json.loads((ROOT / "candidate-manifest.json").read_text(encoding="utf-8"))


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


for source in lineage["sources"]:
    raw = (ROOT / "source" / source["label"] / source["path"]).read_bytes()
    if blob(raw) != source["blob"]:
        raise ValueError(f"source changed: {source['label']}/{source['path']}")

comparisons = {x["path"]: x for x in lineage["pathComparisons"]}
if len(comparisons) != 25 or len(manifest) != 25:
    raise ValueError("composition must retain exactly the reviewed 25 paths")
overlays = []
for entry in manifest:
    path = entry["path"]
    comparison = comparisons[path]
    if comparison["base"] != comparison["master"]:
        raise ValueError(f"unresolved intervening master change: {path}")
    if comparison["pr643"] != entry["target_blob"]:
        raise ValueError(f"target source differs: {path}")
    location = ("candidate/" if entry["change"] != "unchanged" else "source/pr643/") + path
    raw = (ROOT / location).read_bytes()
    if blob(raw) != entry["candidate_blob"] or sha(raw) != entry["sha256"] or len(raw) != entry["bytes"]:
        raise ValueError(f"candidate changed: {path}")
    overlays.append({
        "path": path,
        "source_path": location,
        "base_blob": comparison["base"],
        "master_blob": comparison["master"],
        "target643_blob": comparison["pr643"],
        "candidate_blob": entry["candidate_blob"],
        "sha256": entry["sha256"],
        "bytes": entry["bytes"],
        "publication_change": entry["change"],
    })

candidate_paths = {p.relative_to(ROOT / "candidate").as_posix() for p in (ROOT / "candidate").rglob("*.go")}
expected_paths = {x["path"] for x in manifest if x["change"] != "unchanged"}
if candidate_paths != expected_paths or len(candidate_paths) != 18:
    raise ValueError("candidate contains missing or unexpected source paths")


def exact_hunks(base, donor, target):
    """Apply only this donor's context-qualified changes, without Git merging."""
    before = base.splitlines(True)
    after = donor.splitlines(True)
    for group in difflib.SequenceMatcher(a=before, b=after, autojunk=False).get_grouped_opcodes(3):
        old = "".join(before[group[0][1]:group[-1][2]])
        new = "".join(after[group[0][3]:group[-1][4]])
        if target.count(old) != 1:
            raise ValueError("a runtime hunk no longer has exactly one unchanged context")
        target = target.replace(old, new, 1)
    return target


runtime = "internal/api/serena_prepared_runtime.go"
base = (ROOT / "source/master" / runtime).read_text(encoding="utf-8")
reader = (ROOT / "candidate" / runtime).read_text(encoding="utf-8")
finalizer = (ROOT / "source/pr655" / runtime).read_text(encoding="utf-8")
field = "\t// Transient original custody; never part of the Ready file identity.\n\tgeneration       *SerenaOwnedTree\n"
if reader.count(field) != 1 or reader.replace(field, "", 1) != base:
    raise ValueError("candidate runtime changed more than the private generation field")
reader_then_finalizer = exact_hunks(base, finalizer, reader)
finalizer_then_reader = exact_hunks(base, reader, finalizer)
if reader_then_finalizer != finalizer_then_reader:
    raise ValueError("reader and #655 finalization order do not commute")
for marker in ("var workCancel context.CancelFunc", "workCancel = cancel", "\tgeneration       *SerenaOwnedTree"):
    if reader_then_finalizer.count(marker) != 1:
        raise ValueError(f"combined projection lost or duplicated marker: {marker}")

neighbor_paths = {label: [x["filename"] for x in files] for label, files in lineage["neighborChanges"].items()}
for label in ("pr650", "pr654"):
    if set(neighbor_paths[label]) & set(comparisons):
        raise ValueError(f"unexpected adjacent responsibility overlap: {label}")
if set(neighbor_paths["pr655"]) & set(comparisons) != {runtime}:
    raise ValueError("#655 overlap changed")

overlay_manifest = {
    "base_master": lineage["refs"]["master"],
    "publication_parent": lineage["refs"]["pr643"],
    "common_ancestor": lineage["base"],
    "scope": "25 explicitly pinned source overlays on master; 18 publication changes on #643",
    "warning": "Do not replace a runtime file that already includes #655. Apply its two-line reader field hunk and retain the existing finalizer changes.",
    "files": overlays,
}
proof = {
    "verification": "static source bytes and context-hunk composition only",
    "source_snapshots_verified": len(lineage["sources"]),
    "paths_compared": 25,
    "master_equals_common_ancestor_for_all_25_paths": True,
    "existing_master_paths": sum(x["master_blob"] is not None for x in overlays),
    "new_master_paths": sum(x["master_blob"] is None for x in overlays),
    "publication_changes": 18,
    "preserved643_paths": 7,
    "adjacent_overlaps": {k: sorted(set(v) & set(comparisons)) for k, v in neighbor_paths.items()},
    "runtime_commutation": {
        "base_blob": blob(base.encode()),
        "reader_only_blob": blob(reader.encode()),
        "finalizer_only_blob": blob(finalizer.encode()),
        "both_orders_match": True,
        "combined_projection_blob": blob(reader_then_finalizer.encode()),
        "combined_projection_sha256": sha(reader_then_finalizer.encode()),
        "projection_written_or_published": False,
        "candidate_contains655_change": False,
    },
    "Go_format_compile_tests_native_and_installation": "NOT_RUN",
}
(ROOT / "master-overlay-manifest.json").write_text(json.dumps(overlay_manifest, indent=2) + "\n", encoding="utf-8")
(ROOT / "source-composition-proof.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(json.dumps(proof, indent=2))
