# Serena: независимое ревью композиции #643 + #648 + #652

Статус: **подтверждённых дефектов в проверенных шести integration files не найдено**. Ревью статическое, привязано к байтам из таблицы 1. Компиляция, форматирование, Go tests и нативные процессы не выполнялись. Это не утверждение о пройденной Windows qualification, полном Go gate или готовности установки Serena.

## Содержание

1. [Проверенные байты и область](#1-проверенные-байты-и-область)
2. [Результат проверки контрактов](#2-результат-проверки-контрактов)
3. [Тестовые controls](#3-тестовые-controls)
4. [Точные selectors и действия](#4-точные-selectors-и-действия)
5. [Ограничения и передача](#5-ограничения-и-передача)

## 1. Проверенные байты и область

Основа требований: [review-lifetime.md](review-lifetime.md). Donor snapshots: master `75dbc6406123e22468f168b861d5e0622c9d5769`, #643 `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60`, #648 `184104c186108b150d1183318c3f6791f2a4ba5f`, #652 `b079e4c9503f080d8ab09742270c89a3bf88d7d5`.

Проверены длина, SHA-256 и Git blob SHA-1 всех 25 путей [candidate-manifest.json](candidate-manifest.json): 18 файлов из `candidate/` и 7 неизменённых файлов из `source/pr643/`. Все значения совпали. SHA-256 manifest: `6b498cf8526041640a247db1ebf0a940ce862d232531d186253d407be6f05044`.

Содержательное ревью этого этапа ограничено шестью файлами ниже, их donor diffs и связанными test selectors. Проверка хешей остальных 19 путей не объявляется новым полным code review этих файлов. #655 не импортировался и не редактировался; непересечение runtime-правки с ним остаётся отдельной проверкой родительского агента.

Таблица 1. Проверенные integration files; все пути относительны `candidate/internal/api/`.

| Файл | Байты | SHA-256 |
| --- | ---: | --- |
| `serena_owned_tree_windows.go` | 28 545 | `03c4c9f9ef58313497c64fe3befe9e9bbf5d18677fbda76fbf2e08007debaa7f` |
| `serena_prepared_acquisition.go` | 8 372 | `c980cfe6ef77da0fcb282c5e7a76e64807f96f2f228f05b02e2ca2eac3455eaa` |
| `serena_prepared_execution.go` | 5 005 | `a6d084dffb06ee8377fd03fc47009f0c2c45ffbea41ea7a2ca0a1e84267735d0` |
| `serena_prepared_install_effects.go` | 9 332 | `32b94d9dafb6d70cc2c07575f19745439b1ff86b066b3fd0fad08801188191aa` |
| `serena_prepared_owned_file_windows.go` | 12 212 | `889295f050febcd3bcc366f04fd5f40021f1333d125a781e78dee16c69079480` |
| `serena_prepared_owned_file_windows_test.go` | 20 319 | `75bf17a755c13f2eeb3059fa9288f13dfdf0b42afe1a86d39735ee33edc07920` |

## 2. Результат проверки контрактов

### 2.1. Два владельца передаются раздельно

В [acquisition](candidate/internal/api/serena_prepared_acquisition.go), строка 118, фактический вызов имеет вид `installPreparedSerena(ctx, a.inputs, roots, a.generation, a.buildConstraint)`. Определение в [install effects](candidate/internal/api/serena_prepared_install_effects.go), строка 37, принимает `generation *SerenaOwnedTree` и `constraint *preparedSerenaBuildConstraint`. Типы и порядок совпадают; общий options-контейнер, registry или новое публичное API не вводятся.

Прежде чем запускать установку, строки 68–71 проверяют исходный generation owner и сохраняют его в закрытом поле результата. `uv` в строке 82 получает `executableTree=nil`, поскольку его executable находится вне установленного поколения. Metadata Python в строке 124 получает исходный `generation`; его executable повторно проверяется через тот же владелец. Receipt, Python, metadata members и exports читаются через исходное поколение. Независимый launcher сохраняет общий строгий reader.

### 2.2. Build-constraint сохраняет исходный lifecycle

В install effects сохранены guards из #648: Windows policy, обязательный constraint, запрет caller-controlled `UV_BUILD_CONSTRAINT` и override arguments. Импорт `strings` присутствует и используется этими guards. Копия `inputs.InstallArgs` создаётся до добавления фиксированного `--build-constraint`; исходный slice не изменяется.

`beginPreparedSerenaBuildConstraintUse` вызывается непосредственно перед `uv`, `finishPreparedSerenaBuildConstraintUse` — после возврата исходного invocation. Его ошибка присоединяется к исходной ошибке установки, а retained command/receipt и closure сохраняются. Receipt validator остаётся после разбора `uv-receipt.toml` и до следующего executable.

В [execution](candidate/internal/api/serena_prepared_execution.go), `containedAttempted` устанавливается в строке 63, непосредственно перед единственным `RunContainedStreamObserved`. Отказы проверки invocation, generation или executable возвращаются раньше с `false`. Значение отмечает вход во владельца нативного исполнения; оно не выдаётся за доказательство создания или завершения дочернего процесса.

В acquisition, строки 133–138, cleanup сначала проверяет освобождение constraint, затем вызывает `RemoveOwned` у исходного attempt. В [Windows owner](candidate/internal/api/serena_owned_tree_windows.go), строки 727–731, `closeBuildConstraint` идёт перед закрытием root/parent, а `constraintErr` объединяется с `inventoryCloseError` и `cleanupParentErr`. Поэтому неполное завершение invocation не становится разрешением освободить pin или объявить дерево закрытым. Код pin receiver из #648 сохранён по manifest без изменений.

### 2.3. Cleanup из #643 не заменён старым donor-файлом

Windows owner отличается от #643 только добавлением constraint fields и вызова/результата `closeBuildConstraint`. Исходные функции свежего cleanup-наблюдения, проверки deadline и namespace binding, sticky errors, native stream EOF, readonly unlink и отсутствие deletion authority у опубликованного читателя сохранены.

Generation и attempt acquisitions в строках 53 и 66 передают `r.AbsoluteCleanupDeadline`. В qualification в строке 180 используется `inventorySerenaOwnedTreeForCleanup`, а не обычный `Inventory` с истёкшей рабочей policy. Неизменённые probe и qualification-resource files #643 тоже присутствуют в 25-путевом manifest; их хеши проверены.

### 2.4. Новый deadline включён в существующую привязку читателя

В [owned file reader](candidate/internal/api/serena_prepared_owned_file_windows.go), строки 41, 68, 113 и 145, `AbsoluteCleanupDeadline.Equal(...)` дополняет прежние сравнения tree↔owner, tree↔request, captured owner после batch и captured owner перед отдельным чтением. Сохраняется существующая структура проверки; отдельный owner или параллельная reader-реализация не добавлены.

Новый срок не используется для продления work context. Обычный reader продолжает идти через исходную `WorkingDirectory`; cleanup остаётся отдельной обязанностью. Синтетическая подмена закрытых полей не объявляется доказанной внешней атакой: рассматриваемая правка делает существующую привязку полной после появления нового поля request.

## 3. Тестовые controls

В [owned file tests](candidate/internal/api/serena_prepared_owned_file_windows_test.go) сохранена первоначальная цель отрицательных случаев, а новые controls различают именно добавленный контракт:

- `TestPreparedSerenaOwnedFileRejectsUnissuedOwners`: исходный request получает deadline; отдельный `cleanup-deadline-drift` меняет срок owner. Согласованные случаи `closed`, `missing-handles` и `close-debt` доходят до своих прежних guards.
- `TestPreparedSerenaOwnedGenerationRejectsBindings`: `base` копирует cleanup deadline из request. Прежние шесть мутаций больше не могут случайно проходить из-за пустого нового поля. Добавлен самостоятельный `cleanup-deadline`.
- `matching-request-reaches-owner` подтверждает положительную сторону binding: согласованный запрос доходит до `ORIGINAL_GENERATION_REQUIRED`. Проверка не создаёт мнимый нативный owner.
- `TestPreparedSerenaInvocationRejectsForeignGeneration` дополнительно требует `result.containedAttempted == false`; прежние проверки отсутствия native evidence, receipt hash и stdout/stderr сохраняются.

Нативные primitives #652 по-прежнему не выдают namespace authority. Retained-root test сравнивает реальную идентичность/байты с обычным reader до удержания exclusive root, затем проверяет refusal общего reader, чтение через retained root и закрытие descendant/leaf handles. Batch fixture отдельно доказывает, что его внешняя квалификация отвергается без issued acquisition observation. Эти границы сохранены, поэтому успех primitive не подменяет квалификацию настоящего publisher.

## 4. Точные selectors и действия

Ниже **21 точное имя корневого теста**, разделённое по действиям тела теста. Сам `TestMain`, toolchain и общий process owner требуют отдельного входного допуска; ни один selector не делает их автоматически безопасными. Все записи — план будущей проверки, не результаты исполнения и не самостоятельное разрешение.

### 4.1. Логика и отказы до нативного открытия: 11 roots

```text
^(TestSerenaOwnedTreeCleanupDeadline|TestSerenaOwnedTreeCleanupParentBinding|TestSerenaOwnedTreeCleanupBorrowedNamespaceKeepsOriginalIssuer|TestSerenaOwnedTreeCleanupRefusesBeforeParentObservation|TestSerenaOwnedTreeCleanupRejectsPublishedReader|TestSerenaOwnedTreeCleanupClosedOwnerDoesNotReopen|TestSerenaOwnedTreeCleanupStickyCloseFailurePreventsNewObservation|TestSerenaOwnedTreeRemovalOpenRejectsPublishedReader|TestPreparedSerenaBuildConstraintReceipt|TestPreparedSerenaBuildConstraintRequiresOriginalAttempt|TestPreparedSerenaInvocationPreflightPreservesMissingClosure)$
```

Тела используют данные, контексты, timestamps, TOML parsing и заведомо невыданные capabilities. Cleanup close fixtures не имеют нативных handles. `RemovalOpenRejectsPublishedReader` передаёт invalid handle, но обязуется отказать по `readExisting` до открытия. Invocation preflight передаёт пустой request и не входит в contained factory. Никаких `uv`, Python, Serena или дочерних executable в этих телах нет.

### 4.2. Отказы с `t.TempDir`: 3 roots

```text
^(TestPreparedSerenaOwnedFileRejectsUnissuedOwners|TestPreparedSerenaOwnedGenerationRejectsBindings|TestPreparedSerenaInvocationRejectsForeignGeneration)$
```

Создаются временные каталоги и pathname fixtures. Они не превращаются в право доступа к существующему Serena tree. Guards отказывают до native reader/contained runner. Это не чистые вычисления из-за `t.TempDir`; temp parent должен быть действительно создан и удержан процессом владельца в разрешённой области.

### 4.3. Реальные временные файлы и handles: 4 roots

```text
^(TestSerenaOwnedTreeObserveStreamsNative|TestPreparedSerenaOwnedFileRetainedDirectoryPrimitive|TestPreparedSerenaOwnedFileBatchPrimitive|TestPreparedSerenaBuildConstraintPinCloseFailureNative)$
```

Таблица 2. Фактические действия и ограничения этой группы.

| Root | Фактические действия | Ограничение доказательства |
| --- | --- | --- |
| `TestSerenaOwnedTreeObserveStreamsNative` | Создание обычных файлов, каталогов и named streams, открытие native handles, чтение stream metadata, checked close | Только stream query/decoder; нет Serena acquisition |
| `TestPreparedSerenaOwnedFileRetainedDirectoryPrimitive` | Временное дерево, retained root с DELETE access, чтение/хеширование через borrowed handle, access probes и close | Не выдано namespace/publisher authority |
| `TestPreparedSerenaOwnedFileBatchPrimitive` | Временные файлы с обычным и Unicode-именем, borrowed root/parent, batch reads, лимиты/ошибки/close probes | Внешний qualifier обязан отвергнуть synthetic observation |
| `TestPreparedSerenaBuildConstraintPinCloseFailureNative` | Настоящий read pin; `HANDLE_FLAG_PROTECT_FROM_CLOSE` только на собственном handle; проверка sticky CloseHandle error; fixture cleanup снимает защиту и закрывает handle | Не выполняется `begin-use`, install или настоящий `uv`; machine policy не меняется |

Последний тест вызывает `runPreparedSerenaInvocation` с пустым request для локального preflight-отказа. Он не вызывает contained factory. Остальные три также не запускают executable.

### 4.4. Удаление одной собственной readonly hardlink: 1 root

```text
^TestSerenaOwnedTreeReadonlyHardlinkDeletion$
```

Создаётся отдельный каталог `serena-readonly-unlink-*`, файл и его вторая hardlink. У собственного файла устанавливаются readonly/archive attributes. Legacy disposition должен отказать; новый адресный disposition удаляет только nominated link. Проверяются отсутствие удалённого имени, неизменные identity/content/attributes survivor и уменьшение link count с двух до одной.

Fixture намеренно остаётся после теста для проверки и последующего trash-first перемещения владельцем запуска. Его нельзя путать с утечкой неизвестного происхождения либо удалять автоматически. Без подтверждённого parent-created temp root в D этот selector не допускается.

### 4.5. Пустой Job, pipes и NUL без дочернего executable: 1 root

```text
^TestPreparedSerenaBuildConstraintPinSettlementNative$
```

Этот тест вызывает существующий `RunContainedStreamObserved` с `&exec.Cmd{}`. Независимо прочитан exact master process-код через GitHub:

- `internal/process/contained_stream_observed.go`, blob `3a416c8abf2dc235bbfc11dd0488806333f23c2f`, строки 113–115: вход в общий core с default dependencies.
- `internal/process/contained_stream.go`, blob `6f8594dfd4cc0ab0a2750246800fcf6f19aa49c7`, строки 338, 384, 395, 406, 419: создание child owner, двух pipes, null stdin и вызов `child.start`.
- `internal/process/contained_stream_windows.go`, blob `da415bddb0ff0ae730abb22fcdb74e51a04729ba`, строки 48–53: создание нового Job; строки 89–90: пустой `cmd.Path` отвергается до `CreateProcess` в строке 171. `openContainedNull` открывает устройство `NUL`.

Следовательно, здесь есть настоящие нативные Job/pipe/NUL ресурсы и временные pin files. Это отдельная группа, а не pure test. По исходному управлению потоком executable не запускается. Реальный запуск должен всё равно проверить оригинальный no-child receipt, закрытие ресурсов и nested test result; ожидаемый отказ до CreateProcess нельзя заменить выдуманным receipt.

Источники: [observed](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/process/contained_stream_observed.go), [core](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/process/contained_stream.go), [Windows](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/internal/process/contained_stream_windows.go).

### 4.6. Отдельное чтение существующего Windows bootstrap: 1 root

```text
^TestSerenaBuildEnvironmentWindowsBuildConstraintPolicy$
```

Этот selector **не относится к pure или temp-only группе**. `CatalogManifestGet` читает embedded manifest, а environment-source construction квалифицирует реальные `SYSTEMROOT`, `WINDIR`, `COMSPEC` и единственный PATH directory, принудительно равный `Dir(COMSPEC)`. Обычно это чтение каталогов Windows и `cmd.exe` на C. Исполнение COMSPEC, `uv`, Python или Serena в этой цепочке не выполняется; установленные Serena данные не нужны.

Цепочка API/environment-source дополнительно сверена родительским агентом на exact master; здесь независимо прочитаны соответствующие фрагменты сохранённых [api.go](source/master/internal/api/api.go), [manifest.go](source/master/internal/api/manifest.go) и [serena_build_environment_source.go](source/master/internal/api/serena_build_environment_source.go). Конструктор получает `secrets.NewResolver(nil, nil)` с пустыми либо literal declarations, а не vault/file reference.

Родитель запуска должен отдельно учесть эти реальные bootstrap reads. Подмена `TMP` не означает, что этот тест обращается только к D. Этот selector следует допускать отдельно от предыдущих 20 roots, с явным знанием фактических bootstrap paths.

## 5. Ограничения и передача

Подтверждённых новых дефектов или утраченных donor obligations в проверенном diff нет. Расхождение четвёртого аргумента разрешено передачей двух конкретных владельцев; pin lifetime, cleanup lifetime и исходный tree reader сохранены. Исправленный `strings` import входит в зафиксированные байты.

Не выполнены форматтер, компиляция, race detector, тесты, настоящий Windows parent admission, UV installation, Serena invocation и полный Go gate. Historical PASS отдельных donor PR не переносится на композицию. Даже успешные будущие 21 root не докажут совместимую реальную сборку PyYAML или полную cold-package qualification: эти selectors специально не выполняют установку.

Фактический план parent-root — exact master плюс 25 перечисленных source overlays в offline owned D — не проверялся исполнением в этом ревью. Допуск toolchain, process custody, временных корней и cleanup evidence остаётся у владельца запуска. Проверка и публикация Git refs в рамках этой работы не выполнялись.
