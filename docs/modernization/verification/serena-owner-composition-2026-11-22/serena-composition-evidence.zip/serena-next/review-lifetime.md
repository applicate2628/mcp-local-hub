# Serena: сохранение cleanup lifetime при композиции #643, #648 и #652

Статус: независимое статическое ревью исходных snapshots; 21 ноября 2026 года. Код, Git refs и кандидаты не изменялись. Go, форматтер, тесты, нативные или удалённые процессы, установки и CI не запускались. Это проверка требований к композиции, не одобрение ещё не прочитанного итогового кандидата.

## Содержание

1. [Источники и границы](#1-источники-и-границы)
2. [Обязательное поведение #643](#2-обязательное-поведение-643)
3. [Места композиции с #648 и #652](#3-места-композиции-с-648-и-652)
4. [Сохранность тестовых fixtures](#4-сохранность-тестовых-fixtures)
5. [Различающие проверки](#5-различающие-проверки)
6. [Вывод и ограничения](#6-вывод-и-ограничения)

## 1. Источники и границы

Таблица 1. Точные версии, использованные для сравнения.

| Источник | Commit | Локальный snapshot |
| --- | --- | --- |
| master | `75dbc6406123e22468f168b861d5e0622c9d5769` | `source/master/` |
| #643 | `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60` | `source/pr643/` |
| #648 | `184104c186108b150d1183318c3f6791f2a4ba5f` | `source/pr648/` |
| #652 | `b079e4c9503f080d8ab09742270c89a3bf88d7d5` | `source/pr652/` |

Прочитаны канонические инструкции `next-arch-audit/replacement658/preserved/AGENTS.md` и навык Go Concurrency Lifecycle. Сравнение ограничено сохранёнными файлами Serena и указанными вызывающими функциями. SHA-1 формата Git blob для 28 относящихся к этому обзору snapshots независимо пересчитаны и совпали с `source/source-manifest.json`. Это подтверждает сохранность прочитанных байтов относительно manifest, а не исполнение кода.

Ниже номера строк относятся к указанному donor snapshot. Ссылки на исходники ведут на сохранённые файлы; изменённый кандидат получит собственную нумерацию.

## 2. Обязательное поведение #643

### 2.1. Исходное окно очистки записывается при приобретении дерева

В [serena_owned_tree.go](source/pr643/internal/api/serena_owned_tree.go), строки 27–37, `SerenaOwnedTreeRequest` получает `AbsoluteCleanupDeadline`. `AcquireSerenaOwnedTree`, строки 105–112, вызывает `validateSerenaTreeCleanupContext` до платформенного приобретения. Проверка, строки 114–126, требует заданный предел, живой контекст и конечный срок контекста, не превышающий записанный предел. Истёкший либо отменённый контекст не становится разрешением на очистку.

Четыре реальные точки приобретения в сохранённых production sources передают исходный предел:

- Generation и attempt: [serena_prepared_acquisition.go](source/pr643/internal/api/serena_prepared_acquisition.go), строки 52 и 65, получают `r.AbsoluteCleanupDeadline`.
- Probe attempt: [serena_prepared_inputs.go](source/pr643/internal/api/serena_prepared_inputs.go), строка 164, получает `result.CleanupDeadline`.
- Qualification tree: [serena_qualification_resources.go](source/pr643/internal/api/serena_qualification_resources.go), строка 84, получает `r.AbsoluteCleanupDeadline`.

Замена этих файлов вариантами #648 или #652 без сохранения аргументов перестанет передавать обязательный предел и остановит приобретение дерева до его создания. Присваивать новый срок относительно текущего времени нельзя: это изменит разрешённую длительность операции.

### 2.2. Очистка получает новое наблюдение, сохраняя первоначальную привязку

В [serena_owned_tree_windows.go](source/pr643/internal/api/serena_owned_tree_windows.go), `observeCleanupParent`, строки 215–240, новое наблюдение выполняется с `createMissing=false`, после проверки срока, прежних ошибок закрытия и живости исходного владельца. Исходный `parentPolicy` не заменяется. Новое наблюдение используется только в отдельной ветви cleanup.

`validateSerenaCleanupParentBinding`, строки 246–289, связывает новое наблюдение с исходным: завершённые владельцы ресурсов, тот же путь и полная нативная идентичность каталога, тот же state root, идентичность среды, источник, principal и тип освобождения. Ослабление strict policy или использование relaxed gate у текущего родителя отвергается. Изменение содержания intent при сохранённой защите само по себе не запрещается; это явно проверяет donor test.

Для `borrowed-retained-directory` требуется тот же непрозрачный issuer. Совпадение сериализованных фактов после Close/reopen не воскрешает первоначальное право. Для `CoTaskMemFree-void` допускаются разные issuers отдельных завершённых наблюдений при остальных совпавших привязках. Эти два случая не следует сливать в общий тест на равенство указателей.

`WorkingDirectory` и обычный `Inventory` продолжают проверять исходную рабочую policy. Нельзя переводить их на cleanup policy ради успешного чтения после истечения рабочего времени. `inventorySerenaOwnedTreeForCleanup`, строки 292–305, является отдельным внутренним входом, требующим реального Windows owner и ограниченного cleanup-наблюдения. В [unsupported-файле](source/pr643/internal/api/serena_owned_tree_unsupported.go) сохранён явный отказ на другой платформе.

### 2.3. Закрытие и отказ остаются окончательными

В `serena_owned_tree_windows.go`:

- `serenaTreeHandle.closeOnce`, строки 28–37, записывает единственную попытку закрытия, включая ошибку. Повторный вызов возвращает то же свидетельство.
- `directoryNames`, строки 318–328, записывает ошибку закрытия дублированного enumeration handle в `inventoryCloseError` на обеих ветвях.
- `inventoryWithParentPolicy`, строки 527–530, сохраняет ошибку закрытия каждого leaf handle для любого owner, не только опубликованного читателя.
- `observeCleanupParent`, строки 219–231, отвергает старый долг по закрытию до нового наблюдения; ошибка уже начатого cleanup-наблюдения сохраняется в `cleanupParentErr`.
- `remove`, строки 568–582, записывает единственную попытку удаления и её результат; на выходе закрывает исходные root/parent handles с проверкой результата. Повторное удаление не начинает новую попытку.
- `close`, строки 719–734, возвращает сохранённый результат повторного вызова и учитывает ошибки root, parent, inventory, cleanup-parent и незавершённых observations.

Опубликованный читатель отвергается до cleanup- или deletion-admission (`readExisting`). Повторное открытие пути либо получение новой policy не должно стирать долги или выдавать ему право удаления.

### 2.4. Нативный EOF означает отсутствие потоков только в конкретной ветви

`observeStreams`, строки 383–411, обрабатывает `ERROR_HANDLE_EOF` как пустой список и возвращает текущее `ctx.Err()`. Проверки лимита буфера, отмены, остальных Win32 ошибок и декодирования настоящего результата сохраняются. Нулевой неиспользованный буфер не интерпретируется как запись потока.

Это влияет и на #648: `buildConstraintHash` требует ровно один поток у непустого файла с ограничением сборки. Возврат пустого списка для неожиданного EOF такого файла по-прежнему не удовлетворяет проверке; #643 не ослабляет проверку байтов constraint.

### 2.5. Read-only hardlinks удаляются без изменения атрибутов survivor

`openEntry`, строки 353–371, добавляет `FILE_WRITE_ATTRIBUTES` только для `forRemoval=true`. У опубликованного читателя этот режим отвергается до открытия. У обычной инвентаризации и последующей проверки отсутствия режим остаётся `false`.

`setSerenaOwnedTreeEntryDeleteOnClose`, строки 377–380, использует `FileDispositionInformationEx` с `FILE_DISPOSITION_DELETE | FILE_DISPOSITION_IGNORE_READONLY_ATTRIBUTE`. Он не очищает общие файловые атрибуты, не добавляет POSIX- или ON_CLOSE-модификатор и не заменяет обычные проверки закрытия и отсутствия.

`remove` сначала сверяет полный набор hardlinks исходного attempt и оригинальных generation-survivors, затем проверяет идентичность каждого удаляемого объекта, закрытие и отсутствие конкретного имени. Счётчик уже удалённых ссылок остаётся обязательным. Финальное удаление исходного root продолжает использовать прежний `setFileDeleteOnClose`; адресная правка не расширяется на root без отдельного основания.

## 3. Места композиции с #648 и #652

Таблица 2. Обязанности, которые нельзя выбрать по принципу «одна сторона конфликта».

| Место | Сохранить из #643 | Добавить/сохранить из соседнего PR | Последствие ошибочного разрешения |
| --- | --- | --- | --- |
| `windowsSerenaOwnedTree` | `cleanupParentErr`, исходный request и весь cleanup owner | Поля владельца build-constraint из #648 | Потеря cleanup debt либо невозможность удерживать файл ограничения сборки |
| `windowsSerenaOwnedTree.close` | Root/parent, inventory и cleanup-parent errors; окончательный результат | `constraintErr := w.closeBuildConstraint()` до закрытия root/parent и включение `constraintErr` в `errors.Join` | Ложное «закрыто» при оставшемся pin или забытая ошибка cleanup |
| `preparedSerenaAcquisition.cleanupAttempt` | `RemoveOwned` на исходном attempt; generation-survivor | Проверка `closePreparedSerenaBuildConstraint` до удаления из #648 | Попытка инвентаризации/удаления при живом либо неуспешно закрытом pin |
| `preparedSerenaAcquisition.qualify` | `inventorySerenaOwnedTreeForCleanup` на cleanup-контексте | Чтение установленных файлов исходным generation owner из #652 | Возврат к истёкшей рабочей policy или конфликт переоткрытия retained root |
| Generation-owner comparisons в #652 | Новое поле `AbsoluteCleanupDeadline` | Сравнения tree↔owner, tree↔request и captured owner.request | Новый компонент request binding останется вне существующей проверки |

Удержание build-constraint в [serena_prepared_build_constraint_windows.go](source/pr648/internal/api/serena_prepared_build_constraint_windows.go) имеет отдельную обязанность. `finishPreparedSerenaBuildConstraintUse`, строки 141–155, сохраняет read hold, если первоначальный contained-run был начат и нативное либо потоковое завершение не подтверждено. Ошибка команды сама по себе не определяет, можно ли освободить pin. Локальный отказ до входа в contained runner освобождает неиспользованный pin, но не выдумывает свидетельство «дочернего процесса не было» для разрешения удаления всего attempt.

`closeBuildConstraint`, строки 169–185, не закрывает reader, пока `buildConstraintInUse=true`. Внешний `owner.Close` остаётся окончательным и отражает такой долг в `Closed=false`; изменение cleanup policy не должно превратить его в повторяемый механизм восстановления. Повторное native close после ранее сохранённой ошибки также запрещено `closeOnce`.

#652 не вызывает старые сигнатуры `checkRoot` или `openEntry` напрямую: его внешний путь идёт через `tree.WorkingDirectory`, а native traversal использует собственный строго ограниченный leaf reader. Для него не нужны адаптеры к этим двум функциям.

Расширение существующих binding-проверок #652 новым deadline является интеграционной полнотой, а не доказанным внешне эксплуатируемым обходом: `SerenaOwnedTree` содержит закрытые поля, а нормальный производитель копирует исходный request. В [serena_prepared_owned_file_windows.go](source/pr652/internal/api/serena_prepared_owned_file_windows.go) затронуты сравнения в строках 41, 68, 113 и 145. Их смысл — сохранить всю привязку исходного владельца; framework или новый публичный интерфейс не требуется.

## 4. Сохранность тестовых fixtures

Все сохранённые donor tests #648 и #652 проверены поиском вызовов и чтением соответствующих функций. Они не вызывают `AcquireSerenaOwnedTree`, поэтому новое требование ненулевого `AbsoluteCleanupDeadline` в acquisition само по себе их не ломает.

При этом есть необходимая адаптация исходной базы теста #652. В [serena_prepared_owned_file_windows_test.go](source/pr652/internal/api/serena_prepared_owned_file_windows_test.go), `TestPreparedSerenaOwnedGenerationRejectsBindings`, строка 187, `base` не копирует cleanup deadline из `request` (request получает его в строке 182). После включения поля в production binding все шесть прежних отрицательных случаев смогут получать тот же `GENERATION_BINDING_DRIFT` из-за пустого deadline независимо от своей мутации. Тесты не обязаны упасть, но потеряют различающую силу.

Минимальная адаптация: добавить `AbsoluteCleanupDeadline: request.AbsoluteCleanupDeadline` в этот `base`; добавить отдельную мутацию срока. Полезный контроль без нативного доступа: согласованный request с отсутствующим platform должен пройти binding и получить `ORIGINAL_GENERATION_REQUIRED`, а изменённый срок — остановиться на `GENERATION_BINDING_DRIFT` до native admission. Это не требует выдавать synthetic fixture право на реальные файлы.

Остальные donor fixtures сохраняют прежний смысл:

- #648 pin fixture имеет настоящие file handles, но синтетический внешний tree owner; он проверяет finish/close receiver, не `begin-use`, namespace или acquisition.
- #652 batch fixture вызывает внутреннее чтение с настоящими borrowed handles. Внешний qualifier намеренно отвергает его из-за отсутствующего acquisition observation. Его успех не является правом publisher на дерево.
- #643 cleanup predicate fixtures содержат только данные и не проходят настоящую `Validate` для выдачи filesystem authority.
- #643 readonly-unlink fixture намеренно остаётся в temp-каталоге для последующей проверки и переноса в trash владельцем запуска. Автоматического удаления нового остатка в рамках этого обзора нет.

## 5. Различающие проверки

Таблица 3. Существующие selectors и предел доказательства. Здесь перечислен план проверок; команды не выполнялись и этот список не выдаёт разрешения на запуск.

| Selector | Что различает | Что не доказывает |
| --- | --- | --- |
| `^TestSerenaOwnedTreeCleanupDeadline$` | Тот же/сокращённый срок принимается; продлённый, отсутствующий, бесконечный, истёкший, отменённый — отвергается | Нативное приобретение или удаление |
| `^TestSerenaOwnedTreeCleanupParentBinding$` | Идентичность, source/principal/environment, protection, отсутствие создания компонентов; исходный срок не меняется | Реальная Windows parent-policy qualification |
| `^TestSerenaOwnedTreeCleanupBorrowedNamespaceKeepsOriginalIssuer$` | Закрытие и переоткрытие не воспроизводит исходный issuer | Нативное переоткрытие scope |
| `^TestSerenaOwnedTreeCleanup(RefusesBeforeParentObservation|RejectsPublishedReader|ClosedOwnerDoesNotReopen|StickyCloseFailurePreventsNewObservation)$` | Отказ до наблюдения, отсутствие deletion authority, окончательность close и sticky errors | Успешная полная cleanup-транзакция |
| `^TestSerenaOwnedTreeObserveStreamsNative$` | Реальные пустые каталоги, обычные файлы, named streams, отмена, invalid handle и лимит буфера | Получение Serena owner или полная инвентаризация пакета |
| `^TestSerenaOwnedTree(ReadonlyHardlinkDeletion|RemovalOpenRejectsPublishedReader)$` | Legacy disposition отказывает, новый удаляет только названную ссылку; survivor сохраняет identity/content/attributes; published reader отвергается | Полная политика ownership acquisition |
| `^TestPreparedSerenaBuildConstraintPin(Settlement|CloseFailure)Native$` | Read hold запрещает write/delete access, сохраняется при неполном завершении; настоящая CloseHandle failure остаётся видимой | Установка PyYAML или квалификация реального `uv` |
| `^TestPreparedSerenaOwnedGenerationRejectsBindings$` после адаптации base | Новый cleanup deadline связывается с тем же request; прежние мутации остаются самостоятельными | Нативный admitted owner |

Дополнительный компактный composition test имеет смысл только для общей точки `close`: после сохранённой cleanup-parent ошибки и pending constraint pin внешний close должен вернуть оба долга, `Closed=false`, не вызвать close reader и сохранить точный повторный результат. Такой тест может использовать тот же ограниченный receiver fixture и не должен выдумывать успешную namespace qualification. Он не заменяет нативные pin selectors из таблицы 3.

Нативные selectors требуют отдельного допуска фактического владельца процесса и temp-root в разрешённой области D. Перенаправление `TMP` или абсолютный путь сами по себе не доказывают владение. `TestPreparedSerenaBuildConstraintPinSettlementNative` создаёт настоящие Job/pipe ресурсы через existing runner с пустым command path; executable не запускается, однако этот тест всё равно не является чистым вычислением. Запуск всего `internal/api` из перечисления не следует.

## 6. Вывод и ограничения

У #643 нет заменимого «варианта четвёртого аргумента»: он добавляет обязательный срок и сохраняет первоначальную authority при очистке. Композиция с #648 должна расширить существующего владельца попытки удерживаемым constraint, а #652 должна использовать исходного владельца поколения для чтения. В общем Windows owner достаточно сохранить #643 и адресно добавить поля и close-вызов #648; целиком заменять этот файл старым donor #648 нельзя.

Подтверждены источниками две необходимые интеграционные правки сверх механического объединения: объединить обе группы close errors и дополнить request binding новым cleanup deadline, одновременно исправив baseline отрицательного теста. Это замечания к способу композиции; новый итоговый diff в этом обзоре ещё не был предоставлен.

Исторические PASS для отдельных PR не перенесены на новую композицию. Компиляция, форматирование, гонки, полный Go gate, Windows namespace observation, настоящая подготовка/установка Serena и будущий Product требуют собственных проверок. В этом обзоре выполнены только чтение, сравнение и проверка 28 Git blobs.
