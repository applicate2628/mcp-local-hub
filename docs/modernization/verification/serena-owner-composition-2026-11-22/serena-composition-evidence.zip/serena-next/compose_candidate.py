#!/usr/bin/env python3
"""Compose pinned Serena source bytes locally; never executes the product or Git."""

import difflib
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
PREFIX = "internal/api/"


def read(label, name):
    return (SOURCE / label / PREFIX / name).read_text(encoding="utf-8")


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"expected one source anchor, found {text.count(old)}: {old!r}")
    return text.replace(old, new, 1)


def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


lineage = json.loads((SOURCE / "lineage.json").read_text(encoding="utf-8"))
for item in lineage["sources"]:
    path = SOURCE / item["label"] / item["path"]
    if git_blob(path.read_bytes()) != item["blob"]:
        raise ValueError(f"source blob changed: {path}")

changed_by = {}
for label in ("pr643", "pr648", "pr652"):
    for item in lineage["changed"][label]:
        changed_by.setdefault(item["filename"], []).append(label)

composed = {}
origins = {}
for path, labels in changed_by.items():
    label = labels[-1]
    composed[path] = (SOURCE / label / path).read_text(encoding="utf-8")
    origins[path] = {"source": label, "responsibilities": labels}

# The existing acquisition owner retains both independent capabilities. Its
# cleanup path keeps #643's original deadline and cleanup-only inventory.
name = "serena_prepared_acquisition.go"
text = read("pr648", name)
text = replace_once(text, 'Kind: "generation", Limits: r.OwnedTreeLimits}',
                    'Kind: "generation", Limits: r.OwnedTreeLimits, AbsoluteCleanupDeadline: r.AbsoluteCleanupDeadline}')
text = replace_once(text, 'Kind: "attempt", Limits: r.OwnedTreeLimits, survivors:',
                    'Kind: "attempt", Limits: r.OwnedTreeLimits, AbsoluteCleanupDeadline: r.AbsoluteCleanupDeadline, survivors:')
text = replace_once(text, "installPreparedSerena(ctx, a.inputs, roots, a.buildConstraint)",
                    "installPreparedSerena(ctx, a.inputs, roots, a.generation, a.buildConstraint)")
text = replace_once(text, "a.generation.Inventory(cleanupCtx)",
                    "inventorySerenaOwnedTreeForCleanup(cleanupCtx, a.generation)")
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr648 + pr643 deadline/cleanup + pr652 generation argument"

# The install scenario receives the generation read owner and the separate
# attempt-owned constraint. UV is an external input; installed Python is not.
name = "serena_prepared_install_effects.go"
text = read("pr652", name)
text = replace_once(text, '\t"path/filepath"\n', '\t"path/filepath"\n\t"runtime"\n\t"strings"\n')
text = replace_once(text, "generation *SerenaOwnedTree) (installed",
                    "generation *SerenaOwnedTree, constraint *preparedSerenaBuildConstraint) (installed")
guard_start = '\tif err = inputs.execution.networkPolicy.validateExecution(inputs.Environment, inputs.InstallArgs); err != nil {'
guard_end = '\tr := inputs.Request\n'
constraint_source = read("pr648", name)
original_guard = text[text.index(guard_start):text.index(guard_end)]
constraint_guard = constraint_source[constraint_source.index(guard_start):constraint_source.index(guard_end)]
text = replace_once(text, original_guard, constraint_guard)
install_start = '\tinstallArgs := append([]string(nil), inputs.InstallArgs...)\n'
install_end = '\tinstalled.Closure = uv.Closure\n'
constraint_install = constraint_source[constraint_source.index(install_start):constraint_source.index(install_end)]
constraint_install = replace_once(constraint_install, 'invoke(r.UV, installArgs)', 'invoke(r.UV, installArgs, nil)')
text = replace_once(text, '\tuv, installErr := invoke(r.UV, inputs.InstallArgs, nil)\n', constraint_install)
receipt_guard = '''\tif inputs.execution.buildConstraint {
\t\tif err = validatePreparedSerenaBuildConstraintReceipt(receipt); err != nil {
\t\t\treturn installed, err
\t\t}
\t}
'''
receipt_end = '\tenvironmentPython, _, err := qualifyPreparedSerenaOwnedFile'
text = replace_once(text, receipt_end, receipt_guard + receipt_end)
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr652 + pr648 constraint guards/use/receipt"

# Preserve the private distinction between local refusal and entry into the
# original contained runner. The pin may be released only by that result.
name = "serena_prepared_execution.go"
text = read("pr652", name)
text = replace_once(text, '\tStdout, Stderr []byte\n', '''\tStdout, Stderr []byte
\t// Only the original invocation records entry to the contained factory.
\t// This is local resource custody, not a child-settlement receipt.
\tcontainedAttempted bool
''')
text = replace_once(text, '\tvar stdout, stderr bytes.Buffer\n',
                    '\tvar stdout, stderr bytes.Buffer\n\tresult.containedAttempted = true\n')
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr652 + pr648 contained-entry custody"

# #643's cleanup policy, stream EOF and read-only deletion stay intact. Only
# the attempt's constraint state and its original close result are added.
name = "serena_owned_tree_windows.go"
text = read("pr643", name)
constraint_source = read("pr648", name)
fields_start = '\tbuildConstraint                                *preparedSerenaBuildConstraint\n'
fields_end = '\n}\n\nfunc serenaTreeHandleIdentity'
constraint_fields = constraint_source[constraint_source.index(fields_start):constraint_source.index(fields_end)]
text = replace_once(text, '\tcreation                     *StateFileReadObservation\n',
                    '\tcreation                     *StateFileReadObservation\n' + constraint_fields + '\n')
text = replace_once(text, '\tw.closeResult.Attempted = true\n',
                    '\tw.closeResult.Attempted = true\n\tconstraintErr := w.closeBuildConstraint()\n')
text = replace_once(text, 'errors.Join(a, b, w.inventoryCloseError, w.cleanupParentErr)',
                    'errors.Join(a, b, w.inventoryCloseError, w.cleanupParentErr, constraintErr)')
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr643 + pr648 constraint fields/close"

# #643 added an acquisition field. Include that same captured bound wherever
# #652 compares or snapshots the original generation request.
name = "serena_prepared_owned_file_windows.go"
text = read("pr652", name)
text = replace_once(text, 'owner.request.Limits != tree.request.Limits {',
                    'owner.request.Limits != tree.request.Limits || !owner.request.AbsoluteCleanupDeadline.Equal(tree.request.AbsoluteCleanupDeadline) {')
text = replace_once(text, 'tree.request.Limits != request.OwnedTreeLimits {',
                    'tree.request.Limits != request.OwnedTreeLimits || !tree.request.AbsoluteCleanupDeadline.Equal(request.AbsoluteCleanupDeadline) {')
old = 'owner.request.Limits != request.Limits {'
if text.count(old) != 2:
    raise ValueError("expected the original batch entry/exit request checks")
text = text.replace(old, 'owner.request.Limits != request.Limits || !owner.request.AbsoluteCleanupDeadline.Equal(request.AbsoluteCleanupDeadline) {')
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr652 + captured cleanup deadline binding from pr643"

name = "serena_prepared_owned_file_windows_test.go"
text = read("pr652", name)
text = replace_once(text, '\trequest := SerenaOwnedTreeRequest{Kind: "generation"}\n',
                    '\tdeadline, _ := ctx.Deadline()\n\trequest := SerenaOwnedTreeRequest{Kind: "generation", AbsoluteCleanupDeadline: deadline}\n\tdrifted := request\n\tdrifted.AbsoluteCleanupDeadline = deadline.Add(time.Second)\n')
anchor = '\t\t{"closed", &SerenaOwnedTree{request: request, platform: &windowsSerenaOwnedTree{request: request, closeResult: SerenaTreeClose{Attempted: true, Closed: true}}}, "ROOT_UNAVAILABLE"},\n'
text = replace_once(text, anchor,
                    '\t\t{"cleanup-deadline-drift", &SerenaOwnedTree{request: request, platform: &windowsSerenaOwnedTree{request: drifted}}, "GENERATION_BINDING_DRIFT"},\n' + anchor)
text = replace_once(text, 'Kind: "generation", Limits: request.OwnedTreeLimits}\n',
                    'Kind: "generation", Limits: request.OwnedTreeLimits, AbsoluteCleanupDeadline: request.AbsoluteCleanupDeadline}\n')
anchor = '\t\t{"limits", func(r *SerenaOwnedTreeRequest) { r.Limits.Depth++ }},\n'
text = replace_once(text, anchor, anchor + '\t\t{"cleanup-deadline", func(r *SerenaOwnedTreeRequest) { r.AbsoluteCleanupDeadline = r.AbsoluteCleanupDeadline.Add(time.Second) }},\n')
anchor = '\tt.Run("no-deadline", func(t *testing.T) {\n'
positive = '''\tt.Run("matching-request-reaches-owner", func(t *testing.T) {
\t\tif err := validatePreparedSerenaGeneration(ctx, &SerenaOwnedTree{request: base}, request, PreparedSerenaFile{}); err == nil || err.Error() != "SERENA_PREPARED_ORIGINAL_GENERATION_REQUIRED" {
\t\t\tt.Fatalf("matching request did not reach the original-owner guard: %v", err)
\t\t}
\t})
'''
text = replace_once(text, anchor, positive + anchor)
# The combined command result must continue to refuse native entry on every
# generation preflight error; this assertion uses the real invocation entry.
text = replace_once(text, 'if err == nil || result.Closure.nativeEvidence != nil',
                    'if err == nil || result.containedAttempted || result.Closure.nativeEvidence != nil')
composed[PREFIX + name] = text
origins[PREFIX + name]["source"] = "pr652 + cleanup-binding controls and pr648 no-entry assertion"

manifest = []
patches = []
for path in sorted(composed):
    raw = composed[path].encode("utf-8")
    prior = SOURCE / "pr643" / path
    before = prior.read_bytes() if prior.exists() else None
    changed = before != raw
    record = {
        "path": path,
        **origins[path],
        "target": lineage["refs"]["pr643"],
        "target_blob": git_blob(before) if before is not None else None,
        "candidate_blob": git_blob(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "change": "modified" if changed and before is not None else "added" if changed else "unchanged",
    }
    manifest.append(record)
    if changed:
        output = ROOT / "candidate" / path
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists() and output.read_bytes() != raw:
            raise ValueError(f"candidate already differs; review before replacing: {path}")
        output.write_bytes(raw)
        patches.extend(difflib.unified_diff(
            before.decode("utf-8").splitlines(True) if before is not None else [],
            composed[path].splitlines(True),
            fromfile="a/" + path if before is not None else "/dev/null",
            tofile="b/" + path,
        ))

(ROOT / "candidate-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
(ROOT / "candidate.patch").write_text("".join(patches), encoding="utf-8")
print(json.dumps({"composed_paths": len(manifest), "candidate_paths": sum(x["change"] != "unchanged" for x in manifest), "preserved_target_paths": sum(x["change"] == "unchanged" for x in manifest)}))
