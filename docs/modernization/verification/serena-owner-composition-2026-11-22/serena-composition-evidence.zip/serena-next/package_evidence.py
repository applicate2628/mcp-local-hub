"""Package exact local source proofs and already captured Windows evidence."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
DEST = ROOT / "final-publication"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

entries = {}
for name in ("candidate", "formatted", "source", "publication"):
    for path in sorted((ROOT / name).rglob("*")):
        if path.is_file():
            assert not path.is_symlink()
            entries["serena-next/" + path.relative_to(ROOT).as_posix()] = path.read_bytes()
for path in sorted(ROOT.iterdir()):
    if path.is_file() and path.suffix in {".py", ".json", ".md", ".patch"}:
        entries["serena-next/" + path.name] = path.read_bytes()
for name in ("serena-evidence.zip", "transfer.json", "export-receipt.json", "local-verification.json"):
    entries["serena-next/received/" + name] = (ROOT / "received" / name).read_bytes()
for name in ("serena-export-CONTRACT.md", "serena-export-source-review.json", "serena-runner-README.md", "serena-runner-source-proof.json"):
    entries["verification/" + name] = (WORK / "mcphub-p0/verification" / name).read_bytes()
assert all(not p.endswith((".exe", ".b64")) and not p.startswith("/") and ".." not in Path(p).parts for p in entries)
inner = entries["serena-next/received/serena-evidence.zip"]
assert sha(inner) == "0fcbed980fbba1cccfe0b3debe567e2d4344a1de5271a0a1f900a223cd136a28"
manifest = {"schema": 1, "source_head": "75dbc6406123e22468f168b861d5e0622c9d5769", "overlay_count": 25,
            "code_commit": "4ce944d291663f117b2df6d5b2042f543a9c04ba", "code_tree": "d0493719ec58b8b737d25a95316bbf65122b0d2c",
            "scope": "Source preservation and exact Windows qualification; no full Go or installed product acceptance",
            "inner_archive_sha256": sha(inner),
            "files": [{"path": p, "bytes": len(raw), "sha256": sha(raw)} for p, raw in sorted(entries.items())]}
entries["MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
out = io.BytesIO()
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(entries.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
raw = out.getvalue()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for row in manifest["files"]:
        data = z.read(row["path"])
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
path = DEST / "serena-composition-evidence.zip"
with path.open("xb") as stream:
    stream.write(raw)
meta = {"schema": 1, "archive": path.name, "bytes": len(raw), "sha256": sha(raw),
        "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
        "entries": len(entries), "payload_entries": len(entries)-1, "crc_and_all_member_size_sha256_verified": True,
        "inner_archive": {"bytes": len(inner), "sha256": sha(inner), "entries": 1593},
        "remote_archive_readback": "Uploaded bytes and published Git tree blob identity must match this git_blob; no second binary download is claimed"}
(DEST / "archive.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(meta, indent=2))
