# Serena: согласование исходного дерева, build constraint и cleanup lifetime

**Статус: подготовлен и рассмотрен локальный кандидат; исполнение Go и нативная квалификация в этом комплекте — NOT_RUN.** Пакет продолжает существующий #643. Он объединяет обязанности #643, #648 и #652 без слияния веток, переноса всего master, новой зависимости или второго владельца файловых операций.

## Оглавление

1. [Три проверяемых результата](#1-три-проверяемых-результата)
2. [Точные источники и происхождение файлов](#2-точные-источники-и-происхождение-файлов)
3. [Реальный контракт и выполненная композиция](#3-реальный-контракт-и-выполненная-композиция)
4. [Почему ограничение PyYAML ещё нужно](#4-почему-ограничение-pyyaml-ещё-нужно)
5. [Сохранение соседних обязанностей](#5-сохранение-соседних-обязанностей)
6. [Допустимые адресные проверки](#6-допустимые-адресные-проверки)
7. [Собственное и независимое ревью](#7-собственное-и-независимое-ревью)
8. [План продолжения существующего PR](#8-план-продолжения-существующего-pr)
9. [Границы выводов и источники](#9-границы-выводов-и-источники)

## 1. Три проверяемых результата

1. **Привязки остаются исходными.** Предел очистки захватывается при приобретении дерева, входит в его последующие сравнения и не продлевается. Байты `setuptools<84\n` и происхождение политики входят в идентичность подготовки; квитанция `uv` обязана содержать ровно это ограничение. Согласованный запрос без нативного владельца доходит до `ORIGINAL_GENERATION_REQUIRED`; изменённый cleanup deadline останавливается раньше на `GENERATION_BINDING_DRIFT`.
2. **Чтение сохраняет исходного владельца поколения.** Receipt, установленный Python, metadata-файлы и entrypoint читаются через удерживаемое дерево. Общий независимый reader сохраняет свой запрет ослабления защиты ancestors. Нативные fixtures могут подтвердить чтение, identity, budgets и закрытие дескрипторов; они не выдают namespace или publisher authority.
3. **Constraint живёт до исходного результата работы.** Неизвестное завершение native/IO оставляет read pin удержанным. Настоящий результат «дочерний процесс не создан» либо локальный отказ до входа в runner позволяют закрыть pin. Ошибка настоящего `CloseHandle` остаётся в исходном результате. Общий tree close сохраняет одновременно cleanup, inventory, root/parent и constraint ошибки.

Эти три результата соответствуют адресным выборам в [qualification-plan.json](qualification-plan.json). Критерии и ограничения указаны в §6 и §9; успешной установки из них не следует.

## 2. Точные источники и происхождение файлов

**Таблица 1 — закреплённые источники.** Содержимое получено GitHub read tools по указанным refs; скачивание зависимостей и network shell не использовались.

| Источник | Точный commit | Роль |
|---|---|---|
| master | `75dbc6406123e22468f168b861d5e0622c9d5769` | База будущей адресной квалификации |
| #643 | `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60` | Единственный родитель будущего commit в существующем PR |
| #648 | `184104c186108b150d1183318c3f6791f2a4ba5f` | Policy, constraint custody, receipt и сохранённые проверки |
| #652 | `b079e4c9503f080d8ab09742270c89a3bf88d7d5` | Чтение через исходный generation owner и bounded batch |
| Общий предок | `17bc78fc602efa204a74596409c939a3bf1ddc42` | Основа сравнения донорских изменений |

Все **25 путей** объединения сопоставлены между общим предком и master. Для 14 существовавших путей Git blobs равны; ещё 11 путей отсутствуют в обоих деревьях. Поэтому 49 intervening commits master не нужны для разрешения этого конфликта и в старую ветку не переносятся. Для каждого пути также закреплён исходный blob #643 либо его отсутствие. [Данные сравнения](source/lineage.json), [проверяемый результат](source-composition-proof.json).

В `candidate/` лежат только **18 публикационных изменений: десять модификаций и восемь новых файлов**. Семь путей #643 остаются исходными. Для адресного исполнения на master нужен весь явно перечисленный набор из 25 подмен, а не только каталог `candidate/`.

**Таблица 2 — состав и источник.** Все пути таблицы находятся в `internal/api/`; полные Git blobs, SHA-256 и размеры даны в manifests.

| Файлы | Источник и обязанность | Относительно #643 |
|---|---|---|
| `serena_owned_tree.go`, `serena_owned_tree_unsupported.go` | #643: захваченный cleanup deadline, admission и платформенный отказ | Без изменения |
| `serena_owned_tree_cleanup_windows_test.go`, `serena_owned_tree_delete_windows_test.go`, `serena_owned_tree_streams_windows_test.go` | #643, включая полезный остаток закрытых #645/#651 | Побайтно сохранены |
| `serena_prepared_inputs.go`, `serena_qualification_resources.go` | #643: исходный cleanup deadline на probe/qualification acquisition | Без изменения |
| `serena_owned_tree_windows.go` | Основа #643; добавлены только constraint-поля и его close из #648 | Композиция |
| `serena_prepared_acquisition.go` | #648 constraint + #643 сроки/cleanup inventory + #652 generation | Композиция |
| `serena_prepared_install_effects.go` | #652 reads + #648 policy/use/receipt | Композиция |
| `serena_prepared_execution.go` | #652 executable tree + #648 факт входа в contained runner | Композиция |
| `serena_build_environment.go`, `serena_build_constraint_policy_windows_test.go` | #648: идентичность fixed policy до создания package identity | Побайтный импорт |
| `serena_prepared_build_constraint.go`, `_windows.go`, `_unsupported.go` | #648: создание и удержание constraint относительно исходного attempt | Побайтный импорт |
| `serena_prepared_build_constraint_test.go`, `serena_prepared_build_constraint_pin_windows_test.go` | #648: receipt, отказ до factory, удержание pin и настоящий отказ закрытия | Побайтный импорт |
| `serena_prepared_effects.go`, `serena_prepared_file_windows.go`, `serena_prepared_file_unsupported.go`, `serena_prepared_qualification.go`, `serena_prepared_runtime.go` | #652: actual readers и private transient generation | Побайтный импорт |
| `serena_prepared_owned_file_windows.go` | #652 плюс сравнение нового поля #643 во всех четырёх binding-проверках | Адресное согласование |
| `serena_prepared_owned_file_windows_test.go` | #652 плюс nonzero baseline, отдельные deadline mutations, положительный следующий guard и `containedAttempted=false` | Адресные regressions |

Для чтения состава используются [candidate-manifest.json](candidate-manifest.json) и [master-overlay-manifest.json](master-overlay-manifest.json). [candidate.patch](candidate.patch) — ровно delta к точному #643. [compose_candidate.py](compose_candidate.py) воспроизводит адресную композицию известных bytes; [verify_source_composition.py](verify_source_composition.py) проверяет hashes, набор путей и совместимость с #655. Эти Python-скрипты не запускают Go, Git, приложения или сеть.

## 3. Реальный контракт и выполненная композиция

### 3.1 Конфликт четвёртого аргумента

В master и #643 `installPreparedSerena` имеет три аргумента. В #648 четвёртый — `*preparedSerenaBuildConstraint`, в #652 — `*SerenaOwnedTree`. Это разные полномочия. Выбор одной версии целиком теряет другую обязанность.

У функции найден **один production caller**: `preparedSerenaAcquisition.install` в `serena_prepared_acquisition.go`. В кандидате обе стороны согласованы:

```go
installPreparedSerena(ctx, a.inputs, roots, a.generation, a.buildConstraint)
```

Новый объект options, реестр owners, reflection и публичный API не вводятся. `generation` даёт исходный контекст чтения установленного поколения; `constraint` принадлежит исходному attempt и удерживает конкретный leaf. Поиск фактических consumers и совпадение найденных blobs с точным master сохранены в `source/lineage.json`.

### 3.2 Policy → acquisition → invocation → cleanup

`BuildSerenaBuildEnvironmentProjection` на Windows включает digest фиксированных bytes и rule в projection до расчёта идентичности запроса. Ambient `UV_BUILD_CONSTRAINT`, дополнительный build-constraint argv и произвольный caller build artifact не подменяют этот вход.

`preparedSerenaAcquisition.acquireRoots` сохраняет исходные generation/attempt capabilities и один абсолютный cleanup deadline. После получения attempt создаётся его constraint. Native writer закрывается, а read-only handle удерживает тот же file identity и запрещает write/delete sharing во время использования `uv`.

`installPreparedSerena` сначала проверяет generation. Только команда `uv tool install` получает `--build-constraint <owned-path>`. Вызов `uv` оставляет `executableTree=nil`, потому что `uv` — внешний исходный input, не файл установленного поколения. Metadata Python получает `executableTree=generation`; invocation перепроверяет этот executable через исходного владельца. Существующие UV/version и interpreter ABI probes в `serena_prepared_inputs.go` сохраняют независимый reader.

`containedAttempted` записывается непосредственно перед `RunContainedStreamObserved`. При предварительном отказе он остаётся ложным; такой отказ разрешает освободить неиспользованный pin, но не создаёт фиктивную квитанцию отсутствия дочернего процесса. После входа в factory pin освобождается только по оригинальным завершённым native и IO observations. Неполное наблюдение остаётся долгом.

`cleanupAttempt` требует исходную полную closure, затем закрывает constraint и только после этого вызывает `RemoveOwned`. Windows tree close сначала получает результат constraint close, затем закрывает root/parent и объединяет все исходные ошибки. Старое terminal close состояние не переписывается повторной попыткой.

### 3.3 Один владелец tree reads

Установленные `uv-receipt.toml`, Python, distribution members, exports и entrypoint читаются через исходный generation. `qualifyPreparedSerenaFileBeneath` заимствует root; только созданные им descendant handles закрываются в обратном порядке. Native leaf reader переиспользуется без ослабления share-delete у общего reader.

Batch получает полный namespace/source допуск до чтения и повторно после него. На каждом leaf сохраняются конечный контекст, environment binding, исходные handles/identities, containment, лимиты уникальных entries, UTF-16 component bytes, logical bytes и sticky close errors. При ошибке частичная map не возвращается. Reader capability или кеш из transaction не выносится.

В `ValidateRecord` текущая незавершённая generation использует retained owner. После finish либо для прежней опубликованной generation остаётся независимый строгий reader. `PreparedSerenaInstallation.generation` — private transient pointer; четыре сериализуемых поля `PreparedSerenaFile` не меняются.

Добавленное #643 поле `AbsoluteCleanupDeadline` теперь сравнивается между tree и native owner, между tree и preparation request, при batch exit и перед каждым leaf. Это полнота объединённого контракта; внешне эксплуатируемая подмена private owner не заявляется.

### 3.4 Отдельный cleanup lifetime

Все четыре production acquisitions — input probe, generation, attempt и qualification — получают первоначальный абсолютный срок. Cleanup может получить новое наблюдение родителя с `createMissing=false` в пределах этого срока. Оно не заменяет исходную working policy и не выдаёт новому reader полномочия удаления.

Сохраняются native identity, namespace/source/principal/environment/protection и исходный issuer заимствованного namespace. Ошибки cleanup/inventory close остаются sticky. Сохраняется особая обработка только `ERROR_HANDLE_EOF` как пустого inventory с проверкой отмены; прочие ошибки не превращаются в успех. Readonly link removal сохраняет attributes оставшегося hardlink, original link accounting и отсутствие удалённого имени после checked close. Подробности: [ревью исходных обязанностей](review-lifetime.md).

## 4. Почему ограничение PyYAML ещё нужно

Точный master закрепляет Serena **2.1.0**, commit `5e4f5cd173c7ff3eed37ee3f1de6c266b937c5dc`. Его исходный `pyproject.toml` требует `pyyaml==6.0.2` и `mcp==2.2.0`; обновление Serena не устранило условие #648. [Первичные источники 2–3](#9-границы-выводов-и-источники).

PyYAML 6.0.2 оставляет build dependency `setuptools` без верхнего предела. В `build_ext.run` его optional-extension fallback ловит `DistutilsPlatformError`. В setuptools 83 MSVC выдаёт этот тип; в 84 выдаёт новый `compilers.errors.PlatformError`, который наследует другой base exception. Поэтому при соответствующем Windows compiler failure прежний fallback не совпадает с новым исключением. Это конкретное несовпадение source contracts, а не утверждение, что всякая сборка с setuptools 84 всегда падает. [Первичные источники 4–8](#9-границы-выводов-и-источники).

Сохраняется существующая фиксированная политика `setuptools<84\n`, её provenance и проверка receipt. Новая версия dependency, новый lower bound или новый способ установки не добавлены. Возможность реальной установки этой комбинации на данном host здесь не проверялась; исторические install receipts относятся к своим исходным версиям и среде.

## 5. Сохранение соседних обязанностей

#650 изменяет daemon relay qualification, #654 — Ready readback. Их пути с этим набором не пересекаются. #655 пересекается только с `serena_prepared_runtime.go`: его порядок finalizer → work cancel → cleanup cancel расположен отдельно от private поля `PreparedSerenaInstallation.generation`.

**Таблица 3 — source proof для #655.**

| Вариант runtime-файла | Git blob |
|---|---|
| master / исходный #643 | `da74b9d3a183204d64a420ef4c57a8bbbe625702` |
| Только #652 private field, текущий кандидат | `a68d7b9ff101a120d7a5737d76fd3b4aa0bb5977` |
| Только исходный #655 | `4e769176af22799653f0463d63a36c1177754f8d` |
| Обе правки, оба порядка применения | `c55ae677533eb88e8fbce388ff5a42596f9f8bbd` |

Два context-qualified hunks #655 и двухстрочная правка #652 применены в памяти в обоих порядках. Bytes равны; SHA-256 объединённой projection — `0ea18f0a12369ee77853dfa768e0bce60e13f483fd94c91de497047ad0696980`. Объединённый файл не записан как кандидат и не опубликован. Данные и повторяемая проверка — [source-composition-proof.json](source-composition-proof.json).

**Нельзя заменять весь runtime-файл текущим кандидатом поверх источника, где уже есть #655.** В таком источнике применяется только private-field hunk с сохранением существующего finalizer. На явно выбранном чистом master +25 overlays #655 отсутствует; поэтому эта композиция не допускается как доказательство Ready/finalization/Product acceptance.

## 6. Допустимые адресные проверки

Точные anchored selectors и argv сохранены в [qualification-plan.json](qualification-plan.json). Выборки перечисляют все 21 root из объединённых donor tests; широкий `TestSerena.*` и весь API пакет не входят в этот допуск.

**Таблица 4 — действия выбранных тестов.**

| Группа в JSON | Roots | Фактические действия до и внутри проверок |
|---|---:|---|
| `logic` | 11 | Predicate/receipt/context checks; не открывают нативные файлы в телах. Обычный API TestMain всё равно создаёт свой temp root |
| `temp_refusal` | 3 | `t.TempDir`, вызов настоящих qualifier/invocation entries, отказ до leaf open и contained factory |
| `native_temp_files` | 4 | Собственные файлы/каталоги, именованные NTFS streams, sharing/identity/bytes, retained traversal, настоящий отказ `CloseHandle` на test-owned handle |
| `native_readonly_link` | 1 | Два hardlink одного fixture-файла; удаление только nominated link; survivor остаётся для проверки и последующего trash-first переноса |
| `native_no_child` | 1 | Настоящий пустой Windows Job, два anonymous pipe и NUL; `exec.Cmd{}` отказывает до `CreateProcess`; затем четыре случая pin settlement |
| `bootstrap_readonly` | 1 | Embedded manifest, literal/empty declarations; чтение SYSTEMROOT/WINDIR/PATH directories и bytes COMSPEC, обычно на C; без запуска COMSPEC |

### 6.1 Вход до первого эффекта

Exact master API TestMain имеет blob `0aebe605b377efd27cbcf8b57d4c417b151ce298`; тот же обычный tail уже был в #658. При отсутствии oracle sentinel он устанавливает IPC isolation, создаёт `MkdirTemp("", "mcphub-api-test-state-*")`, назначает in-memory state override, создаёт client-config каталоги под этим root и только затем вызывает `m.Run`. Process/supervisor/autostart seams остаются его исходными stubs. Нормальная ветвь делает явный cleanup после `m.Run`.

До старта binary runner обязан предъявить собственный существующий D subtree и допустимые TMP/TEMP/cache/profile inputs. Настройка переменных сама по себе не доказывает владельца, отсутствие reparse ancestors или защиту от TOCTOU. Не наследуются helper-role sentinels. В выбранных 21 tests нет запуска helper test binary, поэтому новый API helper dispatch не является их зависимостью.

Для bootstrap группы `NewAPI` только создаёт структуры; `newEventBus` возвращает пустую структуру. `CatalogManifestGet` читает `servers.Manifests` из embed и не переходит к disk override. `secrets.NewResolver(nil,nil)` не открывает vault; actual declarations пустые либо literal. `acquireSerenaBuildBootstrap` действительно читает OS paths — это отдельная read-only область, не temp-only тест.

Для no-child группы exact master `runContainedStreamCore` приобретает Job/pipes/NUL до `child.start`. Windows `start` проверяет пустой `cmd.Path` до `CreateProcess`; поэтому fixture запускает native resource lifecycle, но не executable. Исходный master process-код отличается от старого #648 source, что и требует новой source-bound квалификации. [Независимый разбор](review-candidate.md).

### 6.2 Признаки результата и отрицательные контроли

Для каждого указанного root нужны завершённый PASS, фактический Go exit 0 и отсутствие FAIL/SKIP/незавершённых/дублированных событий. Недоступный native input остаётся отказом квалификации; тест или критерий для зелёного результата не ослабляется.

Встроенные различающие пары включают: matching request против изменённого cleanup deadline; общий reader с ожидаемым sharing refusal против чтения через retained root; default stream против named stream и ошибочного handle; обычный readonly disposition с ожидаемым отказом против нового owned unlink; удержанный pin при missing native/IO против original no-child release. Они сохраняют реальные refusal outcomes внутри теста и не подменяют полный install regression.

При отдельном старом-source контроле обновлённые deadline-binding tests можно соединить с исходным #652 owned-file implementation в той же остальной композиции. Тогда изменённый срок должен ошибочно пройти binding и дойти до следующего guard; кандидат должен остановить его на binding. Такой контроль здесь не исполнялся.

`TestSerenaOriginalInputCommandOutcomes` сознательно не выбран: он запускает настоящий COMSPEC. `PrepareSerenaInputs`, `installPreparedSerena`, metadata Python, `uv tool install`, pip/venv, installed Serena, MCP qualification и publisher/Ready/migration execution не разрешаются этим списком. Все зависимости используются только из уже существующего cache; при отсутствии input — остановка без установки или скачивания.

## 7. Собственное и независимое ревью

Собственное чтение выполнено по требованиям, корректности, resource lifetime, безопасности, совместимости и сложности. Проверены реальные callers, Windows/non-Windows declarations, обе ветви executable reader, сохранность combined closure и private custody, cleanup deadline propagation, отсутствие изменения сериализуемого file DTO и непересечение #655.

**Таблица 5 — конкретные замечания и состояние.**

| Место / условие | Последствие | Решение |
|---|---|---|
| Shared `installPreparedSerena`: два разных четвёртых аргумента | Выбор одного donor теряет constraint либо original generation reads | Два явных typed arguments и единственный обновлённый caller |
| Shared Windows owner close | Подстановка версии #648 теряет cleanupParentErr; подстановка #643 теряет pin close | Основа #643, адресное добавление constraint close и объединение всех причин |
| #652 request comparisons после добавления поля #643 | Новая часть captured lifetime не сравнивается | Четыре существующих сравнения дополнены |
| Старый отрицательный fixture после новой binding-проверки | Пустой deadline даёт тот же refusal независимо от выбранной mutation | Baseline заполнен; добавлены отдельный deadline control и matching-request следующий guard |
| Первый локальный install composition до freeze | Policy guards использовали `strings` без import; компиляция дала бы undefined identifier | Найдено собственным review и исправлено до freeze; Go тогда не запускался |

Независимое [review-candidate.md](review-candidate.md) проверило шесть содержательных integration files и hashes всех 25 путей: подтверждённых дефектов не найдено. Это дополняет собственное ревью и не заменяет выполнение проверок либо требуемое репозиторием внешнее ревью будущего HEAD.

Статически проверены **91 source snapshot**, Git blob каждого, 25 source path comparisons, точный состав 18+7 и коммутативность с #655. Форматирование Go, компиляция, `go vet`, race tests, реальные native fixtures, полный Go набор и установка — **NOT_RUN в этом комплекте**. Исторические результаты donor PR здесь не переименованы в новые PASS.

## 8. План продолжения существующего PR

1. Перепроверить, что существующая ветка #643 всё ещё указывает на `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60`. При изменении прочитать новый delta; не переписывать историю и не заменять чужие bytes.
2. На текущем точном master с 25 pinned overlays root выполняет только допущенные адресные проверки §6 на собственном D, существующим toolchain/cache. Любое изменение от formatter отдельно фиксируется в manifests и проходит review перед исполнением.
3. Подготовить **один обычный следующий commit** на #643 с его точным HEAD как единственным родителем: десять изменённых и восемь новых code files плюс компактные свидетельства. Не переносить 49 master commits, не создавать merge commit и не публиковать runtime с чужим #655 rollback.
4. Обновить scope существующего #643 так, чтобы он явно владел согласованным acquisition/read/constraint/cleanup пакетом. В описании указать точные donor refs, сохранённые #645/#651 и результаты с их source boundaries. #650/#654/#655 остаются самостоятельными обязанностями.
5. Только после проверки опубликованных bytes/root receipts можно пометить #648/#652 как замещённые этим пакетом; исходные ветки и история сохраняются. Новый дублирующий PR, force-push, merge и удаление веток не нужны. Эти публикационные действия здесь не выполнялись и не делегированы этим артефактом.

Будущая полная source-issued qualification должна отдельно включить сохранённые #650/#654/#655 и допустимый publisher/Product. Текущий набор не обходит эту последовательность канонического плана §3.

## 9. Границы выводов и источники

Ни один выбранный root не вызывает реальный `acquireRoots` или `installPreparedSerena`. Constraint pin fixtures имеют настоящие handles, но не выдают acquisition/namespace/begin-use authority. Batch fixture выполняет native traversal и отдельно подтверждает, что outer qualifier отказывает без исходного observation. Cleanup predicates не доказывают успешное последующее SecureConfigLockParentPolicyObserved. Установка PyYAML, новый publisher, полная native/tree cancellation, Ready и installed Product acceptance остаются открытыми.

**Источники:**

1. [Канонический план §3](../next-arch-audit/replacement658/preserved/.plans/2026-11/open-pr-integration-20261117.md), [исходные инструкции](../next-arch-audit/replacement658/preserved/AGENTS.md).
2. [master Serena release](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/servers/serena/release.yaml), [manifest](https://github.com/applicate2628/mcp-local-hub/blob/75dbc6406123e22468f168b861d5e0622c9d5769/servers/serena/manifest.yaml).
3. [Serena 2.1.0 pyproject на точном pin](https://github.com/oraios/serena/blob/5e4f5cd173c7ff3eed37ee3f1de6c266b937c5dc/pyproject.toml).
4. [PyYAML 6.0.2 build requirements](https://github.com/yaml/pyyaml/blob/6.0.2/pyproject.toml).
5. [PyYAML 6.0.2 optional extension fallback](https://github.com/yaml/pyyaml/blob/6.0.2/setup.py).
6. [setuptools 83 MSVC](https://github.com/pypa/setuptools/blob/v83.0.0/setuptools/_distutils/compilers/C/msvc.py).
7. [setuptools 84 MSVC](https://github.com/pypa/setuptools/blob/v84.0.0/setuptools/_distutils/compilers/C/msvc.py).
8. [setuptools 84 compiler exceptions](https://github.com/pypa/setuptools/blob/v84.0.0/setuptools/_distutils/compilers/errors.py), [framework exceptions](https://github.com/pypa/setuptools/blob/v84.0.0/setuptools/_distutils/errors.py).
9. [Exact source lineage и file hashes](source/lineage.json), [полный manifest sources](source/source-manifest.json), [publication candidate](candidate-manifest.json), [master overlays](master-overlay-manifest.json).
10. [Исходный lifetime review](review-lifetime.md), [независимый candidate review](review-candidate.md), [план проверки](qualification-plan.json), [статический proof](source-composition-proof.json).

**Обозначения:** PR — запрос на включение изменений; HEAD — вершина ветки; Git blob — идентификатор точных bytes файла; SHA-256 — контрольная сумма; overlay — адресная подмена перечисленных файлов; API — программный интерфейс; IO — ввод/вывод; MCP — Model Context Protocol; ABI — двоичный интерфейс; MSVC — Microsoft C/C++ compiler; DACL — список разрешений доступа Windows; NTFS — файловая система Windows; Job — объект Windows для владения группой процессов; DTO — передаваемое представление данных; TOCTOU — подмена между проверкой и использованием; `-race` — детектор гонок Go; PASS/FAIL/SKIP/NOT_RUN — успех/отказ/пропуск/не запускалось. `uv` — менеджер Python packages/environments. «Исходный owner» означает удерживаемый объект, выдавший наблюдение или capability; один путь или digest его не заменяет.
