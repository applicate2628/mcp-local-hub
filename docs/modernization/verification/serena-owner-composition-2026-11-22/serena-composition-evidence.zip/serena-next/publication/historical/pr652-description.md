<!-- mcphub-current-audit:2026-11-21:start -->
## Актуальное состояние после #662 — 21 ноября 2026 года

**Статус:** Draft. Полное поглощение полезного остатка текущим master не доказано; условия готовности остаются открытыми.

**Вершина PR:** `b079e4c9503f080d8ab09742270c89a3bf88d7d5`. **Базовая ветка:** `master`, её текущая вершина — `75dbc6406123e22468f168b861d5e0622c9d5769`. Здесь указана фактическая текущая вершина ветки, а не историческое поле `base.sha` ответа GitHub.

**Технический владелец:** internal/api: чтение через исходный generation owner. Автор PR — `applicate2628`; назначенных исполнителей и запрошенных ревьюеров в GitHub на момент сверки нет. Технический владелец обозначает компонент, а не назначение человека.

**Контракт:** Receipt, Python и entrypoint текущего поколения читаются через тот же удерживаемый generation owner; независимые прежние записи используют отдельный строгий reader.

**Текущее состояние относительно master `75dbc640`:** Исправление не поглощено master. Его аргумент generation в installPreparedSerena конфликтует по смыслу с constraint pin из #648; эти полномочия нельзя взаимозаменять.

**Следующий необходимый результат:** Передать и сохранить оба исходных владельца вместе с deadline #643. Проверить наружную установочную связку и реальные read/close; не расширять sharing или допуск ради обхода удерживаемого исходного дерева.

**Внешнее ревью:** Есть внешний результат кодового ревью **без замечаний на этой неизменной голове**; квитанция и итог проверены в [аудите PR](https://github.com/applicate2628/mcp-local-hub/blob/cc7b33a9e69028165cbab7042c536f846e6f901f/docs/modernization/verification/pr-state-audit-2026-11-21/README.md#pr-652). Он не заменяет полные и нативные проверки.

**Предел проверок этого аудита:** статический разбор исходников, владельцев, контрактов между источниками данных и потребителями, деревьев Git и существующих квитанций. Новые сборки, проверки Go/Rust, нативные и продуктовые проверки, а также `go vet`, не выполнялись (**NOT_RUN**); прежние результаты относятся только к указанным в них источникам и входам.

[Подробный аудит этого PR](https://github.com/applicate2628/mcp-local-hub/blob/cc7b33a9e69028165cbab7042c536f846e6f901f/docs/modernization/verification/pr-state-audit-2026-11-21/README.md#pr-652) · [Единый актуальный план и критерии приёмки](https://github.com/applicate2628/mcp-local-hub/blob/4c262ba522a2fbe8e040e4bb270f2b47bd579345/.plans/2026-11/open-pr-integration-20261117.md#3-порядок-выполнения).
<!-- mcphub-current-audit:2026-11-21:end -->

<details>
<summary>Предыдущее описание и исторические результаты — сохранены без изменения</summary>

## Problem

The original source-qualified Windows migration on `4b8fad863496c10605376ae03ddc0dbeb7191859` stopped after UV installation with incompatible share-access flags. Its original generation directory retains DELETE access without share-delete; the generic file qualifier explicitly reopens absolute ancestors and conflicts with that retained handle.

A native regression reproduced this on unchanged production code. Source order located the first reachable conflict at the installed `uv-receipt.toml` read; the original smoke did not capture the individual failed native call.

The first original-owner implementation advanced the combined migration to metadata-file verification, but that loop requalified the complete publisher EXE for every member and exhausted the existing work deadline. The follow-up in this same PR removes that repeated work while keeping the original ownership checks.

## Change

Read installed generation files relative to the same retained original owner.

- Bind the generation to the exact request, issued tree kind/state, root path and full native identity.
- Borrow its root and hold descendant directory handles until leaf identity/hash checks and checked close complete; close descendants in reverse order.
- Keep receipt/Python/single-file qualification and current-generation validation on the original owner.
- Qualify metadata members and exports in one bounded batch: full original namespace/source validation on entry and again before returning results; per-file fixed context, owner/handle/policy binding, strict environment, native parent/root identity, containment, byte/depth/handle limits and sticky close failures.
- Return only a completed map of file identities; any failure discards partial results. No reader capability, callback or authority cache escapes the batch.
- Retain the independent path for finished/prior/published generations. `PreparedSerenaFile` remains the same four-field serialized identity.

No global share-delete relaxation, closed-owner reopening fallback, Ready schema change, deadline increase, owner minting or new dependency is introduced.

Base: `17bc78fc602efa204a74596409c939a3bf1ddc42`.
Current head: `b079e4c9503f080d8ab09742270c89a3bf88d7d5`.

## Validation

### Original ancestor-sharing regression

Actual Windows RED failed on unchanged production code with incompatible share-access flags while a real DELETE/no-share-delete directory handle was held.

Initial frozen snapshot, committed as `a083c97815d7427b9cc8d0ab8388ba331bc1806c`: four new roots / 34 leaves and eight affected existing roots / 52 leaves passed; no FAIL/SKIP/incomplete; API vet exited 0. Own and independent review found no blocker.

### Actual combined migration before the batch follow-up

Combined `1267d69f0cc1cc61410c4da84b3c49fa62b0e882` passed 34 roots / 172 leaves, vet and all four same-image namespace lifetime subcases. Its original migration then failed with actual exit 1 after 314.56 seconds at `context deadline exceeded / SERENA_PREPARED_METADATA_FILE_DRIFT`.

The protected operation recorded `install-refused-cleaned`; the actual owned attempt directory is absent, the generation is retained and Ready is absent. Thus the former sharing failure was passed and actual attempt cleanup completed. No full migration/MCP success is claimed. Full image/source/command evidence: https://github.com/applicate2628/mcp-local-hub/pull/652#issuecomment-6885896339 .

Source tracing confirms one whole publisher-EXE reread and SHA-256 per metadata member through the original namespace validation chain. No CPU profile or per-call timing measurement was captured.

### Batch follow-up committed unchanged as current head

Windows GREEN, 2026-11-14 23:35:11–23:35:31 UTC:
- Five owned-file roots / 50 leaf scenarios / 55 terminal PASS events.
- Eight affected existing roots / 52 leaf scenarios / 55 terminal PASS events.
- Zero FAIL/SKIP/incomplete/duplicate tests; API vet exited 0; all seven stages exited 0.
- Four source-file hashes matched before/after. Own and independent review found no blocker.
- The new real-handle batch primitive checks multiple files, duplicate paths, UTF-16/entry/logical-byte bounds, partial-result discard, identity/environment drift, fixed deadline and borrowed-root lifetime. Its deliberately unissued fixture is rejected by the outer namespace qualifier.

Raw SHA-256:
- Batch contracts: `d993e70de4a584eb4a1520a67c90c40ab7fc49867d203b0a386ce82369af0ca7`
- Affected family: `588258ffbcf6231d960b0b0594fd51213201c1a55273fe1c60d729bb93634040`
- Before/after source record: `52ca2c2dc3290f76e06a658bf4efe4b78e33f9cf68ffc08458ac2a8eaa7dbd8c`

Evidence, full diff, receipts and verification summary: `D:\dev\ChatGPT\mcp-pr616-qualification-20261114\serena-owned-file-batch-green-20261114`. Earlier RED/GREEN and both failed original migration cases remain preserved.

## Dependencies and remaining acceptance

This PR covers original-generation file reads; readonly cache unlink (#651) and protocol lifecycle (#650) remain separate. A compatible source must preserve both the generation and build-constraint arguments from #648, UV's nil executable-tree argument, metadata Python's generation argument, and the cleanup-deadline contract from #643. These are compatibility requirements, not instructions to integrate branches or patches.

The later [2026-11-15 source-issued checkpoint](https://github.com/applicate2628/mcp-local-hub/pull/652#issuecomment-6893225526) used combined source `fc875f68d341c663b6322f9cce0983b05ce1c23e`. Installation/member reads and actual attempt cleanup completed; qualification then failed at the separate fractional-millisecond TCP query budget issue tracked by #653. The test exited 1 after 71.47 seconds without a wrapper timeout. The attempt was absent, the generation/UV receipt and qualification directory were retained, and Ready and intent were absent. At that checkpoint, full host-component settlement was not persisted and the remaining 14 migration scenarios were not started. The later historical integrated result is recorded below.

That later checkpoint advances the earlier metadata-timeout boundary but establishes neither complete migration/Model Context Protocol acceptance nor a controlled speedup. Historical combined-source checks apply only to their recorded sources. Any future acceptance run requires an independently supplied, exactly identified compatible source; this review does not construct one. The PR remains draft and full-suite acceptance remains open.

## Scoped review — 2026-11-18

Source review found no concrete introduced defect after tracing native ownership, batch failure/close handling and actual work/cleanup/published-generation callers. The [2026-11-17 exact-head receipt](https://github.com/applicate2628/mcp-local-hub/pull/652#issuecomment-6956960866) records five roots / 50 leaf cases and API vet passing. Positive batch tests use the inner primitive with a fabricated owner that the outer qualifier refuses. Actual close failure and intermediate reparse/replacement races are not established by those tests. No performance measurement or new execution was performed.

[Full own review and independent audit boundaries](https://github.com/applicate2628/mcp-local-hub/pull/652#pullrequestreview-5959531154). The source HEAD is unchanged.

## Historical integrated acceptance — source-bound result

The [15 November final report](https://github.com/applicate2628/mcp-local-hub/pull/653#issuecomment-6896966516) records successful validation on clean combined source `4c600ef464769e0766edf276408a5f89464f3433`: **9 native invocations, 10 fresh retained leaf cases and 11 terminal test PASS results**, including one parent result. The cases perform real pinned Serena installation, MCP (Model Context Protocol) qualification and protected Ready/intent checks; Supervisor start, reap and reconciliation are stubbed. The [16 November readback](https://github.com/applicate2628/mcp-local-hub/pull/653#issuecomment-6923787383) verified the retained evidence without rerunning installation.

Five earlier accepted continuation leaves remain bound to `72f4e9e`; its failed stage06 remains **FAIL / original settlement NOT_ESTABLISHED**. These are not fifteen fresh cases on one source. The results belong to the recorded combined source and publisher image; they do not become standalone-head or later-source run receipts. Full-suite success, current continuous-integration status, real Supervisor lifecycle and deployed Product acceptance are not established by that series.


</details>
