<!-- mcphub-current-audit:2026-11-21:start -->
## Актуальное состояние после #662 — 21 ноября 2026 года

**Статус:** Draft. Полное поглощение полезного остатка текущим master не доказано; условия готовности остаются открытыми.

**Вершина PR:** `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60`. **Базовая ветка:** `master`, её текущая вершина — `75dbc6406123e22468f168b861d5e0622c9d5769`. Здесь указана фактическая текущая вершина ветки, а не историческое поле `base.sha` ответа GitHub.

**Технический владелец:** internal/api/serena_owned_tree: очистка исходного дерева. Автор PR — `applicate2628`; назначенных исполнителей и запрошенных ревьюеров в GitHub на момент сверки нет. Технический владелец обозначает компонент, а не назначение человека.

**Контракт:** Новая проверка родителя для очистки остаётся в исходном AbsoluteCleanupDeadline и не обновляет рабочие полномочия. Ошибки закрытия и неизвестный результат остаются незавершённостью.

**Текущее состояние относительно master `75dbc640`:** Изменения закрытых #645/#651 уже включены: пустое перечисление потоков и удаление собственных readonly-элементов. Общие acquisition-файлы пересекаются с #648/#652 по разным обязанностям.

**Следующий необходимый результат:** Сохранить исходное дерево, сроки очистки и запрет подмены полномочий при согласовании acquisition. Нужна отдельная квалификация поздней очистки исходного пространства и нативных ошибок, а не повтор прежних проверок ради даты.

**Внешнее ревью:** **REVIEW_PENDING:** подтверждения внешнего кодового ревью без замечаний на текущем SHA нет. Исторические отзывы сохранены и учтены отдельно.

**Предел проверок этого аудита:** статический разбор исходников, владельцев, контрактов между источниками данных и потребителями, деревьев Git и существующих квитанций. Новые сборки, проверки Go/Rust, нативные и продуктовые проверки, а также `go vet`, не выполнялись (**NOT_RUN**); прежние результаты относятся только к указанным в них источникам и входам.

[Подробный аудит этого PR](https://github.com/applicate2628/mcp-local-hub/blob/cc7b33a9e69028165cbab7042c536f846e6f901f/docs/modernization/verification/pr-state-audit-2026-11-21/README.md#pr-643) · [Единый актуальный план и критерии приёмки](https://github.com/applicate2628/mcp-local-hub/blob/4c262ba522a2fbe8e040e4bb270f2b47bd579345/.plans/2026-11/open-pr-integration-20261117.md#3-порядок-выполнения).
<!-- mcphub-current-audit:2026-11-21:end -->

<details>
<summary>Предыдущее описание и исторические результаты — сохранены без изменения</summary>

## Problem and owner

Serena acquires owned trees under the work deadline, then must inventory/remove them under the separately captured cleanup deadline. Reusing the earlier parent-policy observation rejects that later context. The retained owner now obtains a fresh native parent observation without creating missing components and binds it to the original directory identity, namespace issuer, principal, source, environment and protection.

The original work observation stays immutable. Terminal owners and sticky close failures remain terminal; published readers gain no deletion authority. Policy evaluation can emit audit events, so the operation is not described as wholly read-only.

## Published R24 imports

- #645 source `98511ab9ea633b7e47e825396f002dc783c51d9f`: native stream-query end-of-file becomes an empty inventory; cancellation and other errors remain refusals. The original native test is retained.
- #651 source `01c08819cb0d3fc4fe2b9e11833e40de3c28c3d6`: remove nominated readonly links using extended disposition and removal-only write-attribute access. Preserve hardlink accounting, survivor attributes, checked close/absence and native deletion/refusal tests.

Published head `44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60` has sole parent `527574928335142d95bc073c6ca4459fef9f9f90`, tree `b658184e7c7a421f973acf71f6309abb19f1b775`: **3 files / +286/-6 lines**. Both donor test files and existing cleanup tests remain byte-identical. #645 and #651 are closed with `merged:false`; source branches remain. Donor commits are provenance, not new ancestors; no PR merge occurred.

## R24 executed qualification

All three phases completed: prepare, focused qualification and build/vet. Tests ran on clean `527574928335142d95bc073c6ca4459fef9f9f90` plus its exact hashed file overlay, whose bytes match the published tree. This is not a whole-published-head test run.

Every selected `go test` command used `-overlay {overlay} -race -json -count=1 -timeout=180s -parallel=4` and the exact anchored root selector from its manifest. Each command exited 0 with no FAIL/SKIP.

- `./internal/api`: default and `-tags=test_state_path_env`; 10 required roots per command, **20 required root PASS executions**. Roots: `TestSerenaOwnedTreeCleanupDeadline`, `TestSerenaOwnedTreeCleanupParentBinding`, `TestSerenaOwnedTreeCleanupBorrowedNamespaceKeepsOriginalIssuer`, `TestSerenaOwnedTreeCleanupRefusesBeforeParentObservation`, `TestSerenaOwnedTreeCleanupRejectsPublishedReader`, `TestSerenaOwnedTreeCleanupClosedOwnerDoesNotReopen`, `TestSerenaOwnedTreeCleanupStickyCloseFailurePreventsNewObservation`, `TestSerenaOwnedTreeObserveStreamsNative`, `TestSerenaOwnedTreeReadonlyHardlinkDeletion`, `TestSerenaOwnedTreeRemovalOpenRejectsPublishedReader`.

`go build -overlay {overlay} ./...` and `go vet -overlay {overlay} ./...` both exited 0. These compile/analyze packages; they do not execute the application or the full test suite. Command deadlines bound direct-child waiting, not settlement of the whole descendant tree.

The selection combines 7 existing cleanup roots, 1 native stream root and 2 native deletion/refusal roots. Private native primitives do not establish the full later-context cleanup, survivor, namespace-reopen or native-close-failure matrix. #648's installation constraint and #652's retained-generation reader remain independent. Keep Draft.

## Evidence and acceptance limits

[R24 audit, source/selection manifests and receipts](https://github.com/applicate2628/mcp-local-hub/blob/b21402535ac4df032408d7bf06200ddd0557abf1/docs/modernization/verification/completion-r24-2026-11-21/README.md) · [Original descriptions, preserved verbatim](https://github.com/applicate2628/mcp-local-hub/blob/b21402535ac4df032408d7bf06200ddd0557abf1/docs/modernization/verification/completion-r24-2026-11-21/original-pr-descriptions.zip). Historical outcomes retain their original source identities. Previous full-test FAIL/NOT_RUN gates are unchanged; no full `go test ./...`, installed-product acceptance or formal external approval is inferred.


</details>
