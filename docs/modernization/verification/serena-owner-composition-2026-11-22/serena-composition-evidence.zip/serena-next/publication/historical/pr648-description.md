<!-- mcphub-current-audit:2026-11-21:start -->
## Актуальное состояние после #662 — 21 ноября 2026 года

**Статус:** Draft. Полное поглощение полезного остатка текущим master не доказано; условия готовности остаются открытыми.

**Вершина PR:** `184104c186108b150d1183318c3f6791f2a4ba5f`. **Базовая ветка:** `master`, её текущая вершина — `75dbc6406123e22468f168b861d5e0622c9d5769`. Здесь указана фактическая текущая вершина ветки, а не историческое поле `base.sha` ответа GitHub.

**Технический владелец:** internal/api: исходный build-constraint и удерживаемый pin. Автор PR — `applicate2628`; назначенных исполнителей и запрошенных ревьюеров в GitHub на момент сверки нет. Технический владелец обозначает компонент, а не назначение человека.

**Контракт:** setuptools<84 задаётся одним исходным проверенным файлом; pin остаётся жив до завершения native/IO-работ UV и сохраняет неизвестность закрытия.

**Текущее состояние относительно master `75dbc640`:** В Serena 2.1.0@5e4f5cd по-прежнему указан PyYAML 6.0.2, поэтому исправление не доказано устаревшим. #648 и #652 независимо добавляют разные четвёртые аргументы installPreparedSerena.

**Следующий необходимый результат:** Сохранить одновременно constraint pin и generation owner из #652, а также cleanup deadline из #643. Квалифицировать полное приобретение и установку на новом графе зависимостей; прежние pin-тесты не являются полным install PASS.

**Внешнее ревью:** **REVIEW_PENDING:** подтверждения внешнего кодового ревью без замечаний на текущем SHA нет. Исторические отзывы сохранены и учтены отдельно.

**Предел проверок этого аудита:** статический разбор исходников, владельцев, контрактов между источниками данных и потребителями, деревьев Git и существующих квитанций. Новые сборки, проверки Go/Rust, нативные и продуктовые проверки, а также `go vet`, не выполнялись (**NOT_RUN**); прежние результаты относятся только к указанным в них источникам и входам.

[Подробный аудит этого PR](https://github.com/applicate2628/mcp-local-hub/blob/cc7b33a9e69028165cbab7042c536f846e6f901f/docs/modernization/verification/pr-state-audit-2026-11-21/README.md#pr-648) · [Единый актуальный план и критерии приёмки](https://github.com/applicate2628/mcp-local-hub/blob/4c262ba522a2fbe8e040e4bb270f2b47bd579345/.plans/2026-11/open-pr-integration-20261117.md#3-порядок-выполнения).
<!-- mcphub-current-audit:2026-11-21:end -->

<details>
<summary>Предыдущее описание и исторические результаты — сохранены без изменения</summary>

## Problem

The pinned Serena revision `949a27ef1e5fda1a6e7b561e777bcece345c6ffd` uses PyYAML 6.0.2. On the existing Windows Python 3.14 interpreter, UV builds it from source; setuptools 84 changed the compiler-error contract that PyYAML's optional-extension fallback handles.

## Change

Own the fixed Windows constraint `setuptools<84\n` through the existing preparation and attempt owners. Bind its bytes and policy provenance before package identity is calculated, create and verify it relative to the original retained attempt directory, and retain a read-only handle excluding write/delete access while UV uses it. Incomplete original settlement retains the pin; native close failures remain visible. Only the install invocation receives `--build-constraint`, and its UV receipt must contain exactly the fixed constraint.

The new follow-up adds one Windows test file for that pin's finish/close receiver. It covers local preflight, missing native settlement, incomplete input/output settlement, an original no-child outcome, and a real protected-handle close refusal. Synthetic fixture ownership is explicit; a complete native receipt is obtained from the original contained runner.

Current head: [`184104c186108b150d1183318c3f6791f2a4ba5f`](https://github.com/applicate2628/mcp-local-hub/commit/184104c186108b150d1183318c3f6791f2a4ba5f), one parent `fc4dc5c7145e4f4d709b91654ab4bc1fd7abe259`. The follow-up adds 200 test lines and changes no production file or dependency.

## R25 verification — 21 November 2026

The exact clean parent plus the one published, byte-identical overlay passed on Windows:

- Selected tests with the race detector, default and `test_state_path_env`: **12 test/subtest PASS, 4 root executions, 10 leaf executions and 2 package PASS; zero FAIL or SKIP**.
- `go build -overlay ... ./...` and `go vet -overlay ... ./...`: both exit 0.
- Source and overlay checks before/after matched. GitHub readback confirmed the exact new file, tree and single parent.

Candidate SHA-256: `d75864f7d0f8517249ae7a68317f94735cf4589327e1398a757ea120ef997f68`. Scope manifest: `c1bf5533cf6b94879c18ac9c70ccd006e0ea564c36ab59f46495fe94fdb06996`.

Own review covered requirements, correctness, native resource lifetime, compatibility and complexity; independent source review was supplementary. An earlier assertion was rejected before execution, and revision 2 failed compilation on a missing pinned-package constant. Those failures are retained separately. The published revision uses the documented test-local Windows SDK value and passed the checks above.

These are parent-plus-overlay results with exact publication readback, not a separately executed published-head run.

## Earlier evidence and remaining boundaries

The original focused implementation run recorded 12 roots, 52 leaf cases and API vet. A separate 14 November installation diagnostic with the fixed constraint installed 74 packages and three entrypoints, with setuptools 83.0.0 recorded by PyYAML. Those historical results remain bound to their recorded source and environment.

The [15 November integrated report](https://github.com/applicate2628/mcp-local-hub/pull/653#issuecomment-6896966516) and [16 November readback](https://github.com/applicate2628/mcp-local-hub/pull/653#issuecomment-6923787383) concern combined source `4c600ef464769e0766edf276408a5f89464f3433`, not this standalone head. Earlier failed stage06 remains FAIL with original settlement not established.

The new tests exercise the native finish/close receiver with real test-owned handles and an original empty Job. Complete acquisition, begin-use admission, publisher/namespace authority, successful child and installed Product lifecycle are still unqualified here. Full default/tagged Go suites and formal external approval are not established. The capture wrapper observes direct-child exit without proving a deadline or settlement for the entire process tree. Keep this PR in Draft.

References: [PyYAML 6.0.2 setup](https://github.com/yaml/pyyaml/blob/6.0.2/setup.py), [setuptools 84 compiler contract](https://github.com/pypa/setuptools/blob/v84.0.0/setuptools/_distutils/compilers/C/msvc.py), [setuptools 83](https://github.com/pypa/setuptools/blob/v83.0.0/setuptools/_distutils/compilers/C/msvc.py). Reassess the fixed constraint when the pinned dependency supports the newer contract.

Published R25 evidence: [publication receipt](https://github.com/applicate2628/mcp-local-hub/blob/a4c6de78d867d9e99ee596c15251ac7d4a522737/docs/modernization/verification/completion-r25-2026-11-21/publication648.json) · [R25 source and review audit](https://github.com/applicate2628/mcp-local-hub/blob/a4c6de78d867d9e99ee596c15251ac7d4a522737/docs/modernization/verification/completion-r25-2026-11-21/AUDIT.md).


</details>
