"""Derive the exact #643 code delta and full-tree donor preservation record.

Local standard-library file/hash work only. No Git, Go, network, import of the
qualification runner, subprocess or reference mutation is performed.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = HERE / "source"
BASE = "17bc78fc602efa204a74596409c939a3bf1ddc42"
PARENT = "44f9a3a9332c716fcd5dba5c7098df5cbf1d3c60"
FORMATTED_MANIFEST_SHA256 = "6be3cd0aa6a35b586ba623be051acb6e4bed4799bf25e92127efcf6191456ebf"
ORIGINAL_MANIFEST_SHA256 = "6b498cf8526041640a247db1ebf0a940ce862d232531d186253d407be6f05044"
REFS = {
    "base": BASE,
    "pr643": PARENT,
    "pr648": "184104c186108b150d1183318c3f6791f2a4ba5f",
    "pr652": "b079e4c9503f080d8ab09742270c89a3bf88d7d5",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_exact(path, raw):
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Refusing to overwrite a different artifact: " + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def write_json(path, value):
    write_exact(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def tree_id(leaves):
    root = {}
    for path, item in leaves.items():
        node = root
        parts = path.split("/")
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        if parts[-1] in node:
            raise ValueError("Conflicting tree path: " + path)
        node[parts[-1]] = item

    def digest(node):
        body = b""
        for name, value in sorted(node.items(), key=lambda kv: kv[0].encode() + (b"/" if isinstance(kv[1], dict) else b"")):
            if isinstance(value, dict):
                mode, identity = "40000", digest(value)
            else:
                mode, _, identity = value
            body += mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(identity)
        return hashlib.sha1(b"tree " + str(len(body)).encode() + b"\0" + body).hexdigest()

    return digest(root)


def changed_paths(left, right):
    return [p for p in sorted(left.keys() | right.keys()) if left.get(p) != right.get(p)]


def main():
    original_path = ROOT / "candidate-manifest.json"
    formatted_path = ROOT / "manifest.formatted.json"
    if sha(original_path.read_bytes()) != ORIGINAL_MANIFEST_SHA256 or sha(formatted_path.read_bytes()) != FORMATTED_MANIFEST_SHA256:
        raise ValueError("Source candidate or formatted manifest changed")
    original = {item["path"]: item for item in read_json(original_path)}
    formatted = read_json(formatted_path)
    receipt_path = ROOT / "formatted-source-receipt.json"
    receipt = read_json(receipt_path)
    if not receipt["completed"] or receipt["state"] != "complete" or receipt["formatted_manifest_sha256"] != FORMATTED_MANIFEST_SHA256:
        raise ValueError("Formatting receipt is not successful or has another manifest")
    if receipt["source_before"] != receipt["source_after"] or receipt["source_after"] != receipt["source_final"] or receipt["tools_sha256"] != receipt["tools_sha256_after"]:
        raise ValueError("Formatting changed physical source or tool identity")
    if receipt["base"] != "75dbc6406123e22468f168b861d5e0622c9d5769":
        raise ValueError("Formatting used a different physical source")
    post = {item["path"]: item for item in receipt["candidate_after"]}
    if len(original) != 25 or len(formatted["files"]) != 25 or len(post) != 25:
        raise ValueError("Expected all 25 source/formatted entries")

    trees, tree_records, comparisons = {}, {}, {}
    for label in REFS:
        tree_path = SOURCE / ("tree-" + label + ".json")
        tree = read_json(tree_path)
        if tree.get("truncated") is not False:
            raise ValueError("Full recursive tree is required: " + label)
        leaves = {item["path"]: (item["mode"], item["type"], item["sha"]) for item in tree["tree"] if item["type"] != "tree"}
        if label == "base":
            expected = read_json(SOURCE / "compare-base-pr643.json")["base_commit"]["commit"]["tree"]["sha"]
        else:
            commit = read_json(SOURCE / ("commit-" + label + ".json"))
            if commit["sha"] != REFS[label]:
                raise ValueError("Wrong commit record: " + label)
            expected = commit["tree"]["sha"]
            comparison = read_json(SOURCE / ("compare-base-" + label + ".json"))
            if comparison["base_commit"]["sha"] != BASE or comparison["merge_base_commit"]["sha"] != BASE:
                raise ValueError("Unexpected comparison ancestor: " + label)
            comparisons[label] = comparison
        observed = tree_id(leaves)
        if observed != expected:
            raise ValueError("Recursive leaves do not reconstruct the original tree: " + label)
        trees[label] = leaves
        tree_records[label] = {"commit": REFS[label], "tree": observed, "leaf_count": len(leaves), "recursive_tree_sha256": sha(tree_path.read_bytes()), "truncated": False, "reconstructed_tree_matches_commit": True}

    snapshot_index = {}
    for item in read_json(ROOT / "source/source-manifest.json"):
        path = ROOT / "source" / item["label"] / item["path"]
        if path.exists():
            raw = path.read_bytes()
            if blob(raw) != item["blob"]:
                raise ValueError("Changed source snapshot: " + str(path))
            snapshot_index.setdefault((item["path"], item["blob"]), (path, raw))

    projected = dict(trees["pr643"])
    files, retained, all_formatted, formatting_changed = [], [], {}, []
    publication_patch = []
    for item in formatted["files"]:
        path = item["path"]
        if path not in original or not path.endswith(".go"):
            raise ValueError("Unexpected formatted path: " + path)
        raw = (ROOT / "formatted" / path).read_bytes()
        identity, digest = blob(raw), sha(raw)
        if identity != item["candidate_git_blob"] or digest != item["candidate_sha256"] or identity != post[path]["git_blob"] or digest != post[path]["sha256"] or len(raw) != post[path]["bytes"]:
            raise ValueError("Formatted byte identity mismatch: " + path)
        old = original[path]
        if old["target"] != PARENT:
            raise ValueError("Candidate has another publication parent")
        parent_entry = trees["pr643"].get(path)
        parent_blob = parent_entry[2] if parent_entry else None
        if old["target_blob"] != parent_blob:
            raise ValueError("Candidate target blob differs from full #643 tree: " + path)
        all_formatted[path] = {"bytes": len(raw), "sha256": digest, "git_blob": identity}
        if digest != old["sha256"]:
            formatting_changed.append(path)
        if identity == parent_blob:
            if old["change"] != "unchanged":
                raise ValueError("Unexpected disappearance of a candidate change")
            retained.append({"path": path, "git_blob": identity, "sha256": digest})
            continue
        if old["change"] not in {"added", "modified"}:
            raise ValueError("Unexpected new candidate change")
        mode = parent_entry[0] if parent_entry else "100644"
        if mode != "100644":
            raise ValueError("Unexpected Go file mode")
        before = b""
        before_path = None
        if parent_blob is not None:
            before_path, before = snapshot_index[(path, parent_blob)]
        output_path = HERE / "candidate" / path
        write_exact(output_path, raw)
        files.append({"path": path, "mode": mode, "type": "blob", "change": "added" if parent_blob is None else "modified", "parent_blob": parent_blob, "parent_sha256": sha(before) if parent_blob else None, "parent_snapshot": str(before_path.relative_to(ROOT)) if before_path else None, "candidate_blob": identity, "sha256": digest, "bytes": len(raw), "source_path": "candidate/" + path, "responsibilities": old["responsibilities"], "unformatted_candidate_blob": old["candidate_blob"], "formatting_changed": digest != old["sha256"]})
        projected[path] = (mode, "blob", identity)
        publication_patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile="a/" + path if parent_blob else "/dev/null", tofile="b/" + path))
    if len(files) != 18 or len(retained) != 7 or set(all_formatted) != set(original):
        raise ValueError("Expected exactly 18 changed and seven retained paths")
    if formatting_changed != ["internal/api/serena_owned_tree_windows.go", "internal/api/serena_prepared_owned_file_windows_test.go"]:
        raise ValueError("Unexpected formatting delta")
    if changed_paths(trees["pr643"], projected) != sorted(item["path"] for item in files):
        raise ValueError("Projected publication changes another tree path")

    manifest = {
        "schema": "serena-pr643-publication-v1",
        "status": "LOCAL_CANDIDATE_NO_REFERENCE_MUTATION",
        "repository": "applicate2628/mcp-local-hub",
        "target_pr": 643,
        "target_branch": read_json(SOURCE / "pr643-snapshot.json")["head"]["ref"],
        "required_parent": PARENT,
        "required_parent_tree": tree_records["pr643"]["tree"],
        "expected_code_only_tree": tree_id(projected),
        "parent_count": 1,
        "format_source": {"physical_master": receipt["base"], "formatted_manifest_sha256": FORMATTED_MANIFEST_SHA256, "local_readback_receipt_sha256": sha(receipt_path.read_bytes()), "original_candidate_manifest_sha256": ORIGINAL_MANIFEST_SHA256, "formatting_changed_paths": formatting_changed},
        "runtime_qualification": "No Go/native qualification results are included in this manifest; root owns and records those phases separately.",
        "files": files,
        "retained_pr643_files": retained,
        "no_deleted_paths": True,
        "no_master_merge": True,
        "docs_from_donor_heads_to_transfer": [],
    }
    write_json(HERE / "manifest18.json", manifest)
    write_exact(HERE / "publication.patch", "".join(publication_patch).encode())

    donor_records, donor_residual_patch = {}, []
    donor_paths = set()
    for label in ("pr643", "pr648", "pr652"):
        changed = changed_paths(trees["base"], trees[label])
        api_paths = sorted(item["filename"] for item in comparisons[label]["files"])
        if changed != api_paths:
            raise ValueError("Compare and full-tree change sets differ: " + label)
        records = []
        for path in changed:
            if not path.endswith(".go") or path not in all_formatted:
                raise ValueError("Unclassified donor change: " + path)
            donor = trees[label][path]
            final = projected[path]
            disposition = "exact_donor_blob_retained" if donor == final else "composed_with_other_owner_contracts"
            records.append({"path": path, "base_blob": trees["base"].get(path, (None, None, None))[2], "donor_blob": donor[2], "final_blob": final[2], "disposition": disposition})
            if donor != final:
                _, before = snapshot_index[(path, donor[2])]
                after = (ROOT / "formatted" / path).read_bytes()
                donor_residual_patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=label + "/" + path, tofile="composed/" + path))
            if label != "pr643":
                donor_paths.add(path)
        non_go = [p for p in changed if not p.endswith(".go")]
        versus_target = changed_paths(trees["pr643"], trees[label])
        donor_records[label] = {"changed_paths_from_common_base": len(changed), "compare_matches_full_tree": True, "non_go_delta_from_common_base": non_go, "non_go_delta_from_pr643": [p for p in versus_target if not p.endswith(".go")], "exact_donor_blob_count": sum(r["disposition"] == "exact_donor_blob_retained" for r in records), "composed_count": sum(r["disposition"] != "exact_donor_blob_retained" for r in records), "files": records}
    if donor_paths != {item["path"] for item in files}:
        raise ValueError("Publication path set is not the donor path union")
    non_go = {label: {p: item for p, item in leaves.items() if not p.endswith(".go")} for label, leaves in trees.items()}
    if any(non_go[label] != non_go["base"] for label in non_go):
        raise ValueError("A non-Go delta needs explicit preservation")
    docs = [p for p in trees["base"] if p.startswith(("docs/", ".plans/"))]
    archives = {label: [p for p in leaves if p.lower().endswith((".zip", ".tar", ".gz", ".tgz", ".7z", ".rar"))] for label, leaves in trees.items()}
    references = []
    for label in ("pr643", "pr648", "pr652"):
        snapshot = read_json(SOURCE / (label + "-snapshot.json"))
        if snapshot["head"]["sha"] != REFS[label]:
            raise ValueError("PR snapshot no longer names the reviewed head")
        body = snapshot["body"]
        write_exact(HERE / "historical" / (label + "-description.md"), body.encode())
        urls = sorted(set(re.findall(r"https://github\.com/applicate2628/mcp-local-hub/[^\s)]+", body)))
        references.append({"pr": int(label[2:]), "head": REFS[label], "snapshot_updated_at": snapshot.get("updated_at"), "description_path": "historical/" + label + "-description.md", "description_sha256": sha(body.encode()), "urls": urls})
    proof = {
        "schema": "serena-full-donor-subtraction-v1",
        "scope": "All leaves, modes and identities of the exact common base and three PR heads; no extension or directory filter was applied before computing deltas.",
        "tree_records": tree_records,
        "non_go_leaf_count": len(non_go["base"]),
        "all_non_go_leaves_identical": True,
        "docs_and_plans_leaf_count": len(docs),
        "all_docs_and_plans_identical": True,
        "archive_paths": archives,
        "donors": donor_records,
        "publication": {"manifest18_sha256": sha((HERE / "manifest18.json").read_bytes()), "code_only_tree": tree_id(projected), "changed_paths": 18, "added": sum(f["change"] == "added" for f in files), "modified": sum(f["change"] == "modified" for f in files), "retained_pr643_paths": 7, "deleted_paths": [], "uncovered_donor_paths": [], "non_go_paths_to_transfer": []},
        "semantic_preservation_basis": "Exact blob equality covers 12 donor files. The six composed files are covered by the original own/full-diff and independent candidate reviews plus the retained donor-to-composed patch; path coverage alone is not a semantic or runtime proof.",
        "related_source_reviews": ["../review-candidate.md", "../review-lifetime.md", "../source-composition-proof.json"],
        "neighbor_655": "The existing exact hunk commutation proof remains applicable: formatting did not change serena_prepared_runtime.go. No #655 full-file import is made.",
        "historical_evidence": {"references": references, "classification": "PR descriptions link to evidence on separate immutable commits and to historical comments. These are not unique files in donor branch deltas and are not new runtime receipts for the composition.", "transfer_proposal": "Carry a concise provenance/limits summary and immutable links in the new #643 description/README; do not copy the unrelated R25 evidence bundle or retag historical outcomes as current qualification.", "r25_publication648": {"path": "source/historical-r25-publication648.json", "source_commit": "a4c6de78d867d9e99ee596c15251ac7d4a522737", "git_blob": "88ecb747033e535042806e92f76e1106aa0476a1", "sha256": sha((SOURCE / "historical-r25-publication648.json").read_bytes())}},
        "not_performed": ["Go or native execution", "remote PC actions", "Git reference/PR actions", "dependency download or installation", "revalidation of all historical runtime archives"],
    }
    historical_raw = (SOURCE / "historical-r25-publication648.json").read_bytes()
    if blob(historical_raw) != proof["historical_evidence"]["r25_publication648"]["git_blob"]:
        raise ValueError("Historical publication receipt bytes changed")
    write_json(HERE / "source-subtraction-proof.json", proof)
    write_exact(HERE / "donor-to-composed.patch", "".join(donor_residual_patch).encode())
    print(json.dumps({"files": len(files), "retained": len(retained), "code_only_tree": tree_id(projected), "manifest18_sha256": sha((HERE / "manifest18.json").read_bytes()), "non_go_delta": 0, "docs_equal": len(docs), "archives": archives, "runtime_executed": False}))


if __name__ == "__main__":
    main()
