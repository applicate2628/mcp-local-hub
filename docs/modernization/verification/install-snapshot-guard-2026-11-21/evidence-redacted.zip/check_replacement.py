"""Offline qualification of one install snapshot candidate; direct-child waits are unbounded."""
import sys
sys.dont_write_bytecode = True
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
from collections import Counter

ROOT = Path(r"<INSTALL_SNAPSHOT_ROOT>")
SOURCE = ROOT / "source"
OLD = Path(r"<CANCELLATION_ROOT>\source")
BASE = "11c286fb634cc63d2c6019a790ff376a1d834af9"
BASE_TREE = "ba769a5cbed3e05d3071a0cfb846127019500b49"
GO = Path(r"C:\msys64\ucrt64\bin\go.exe")
GOFMT = GO.with_name("gofmt.exe")
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
PRODUCT, TEST = "internal/api/install.go", "internal/api/install_scheduler_snapshot_test.go"
PATHS = [PRODUCT, TEST]
PACKAGE = "mcp-local-hub/internal/api"
GROUPS = {
    "TestExecuteInstallToSnapshotFailurePreservesTask": ["unavailable", "partial_permission_error", "unsupported", "nil_success", "empty_success", "conflicting_absence"],
    "TestExecuteInstallToAbsentSnapshotCreatesWithoutDelete": ["direct", "wrapped"],
    "TestExecuteInstallToAbsentSnapshotCreateConflictPreservesTask": [],
    "TestExecuteInstallToDeleteFailurePreservesTask": [],
    "TestExecuteInstallToSnapshotRefusalRollsBackEarlierTask": ["export", "delete"],
}
ADJACENT = {"TestExecuteInstallTo_PassAPassB_Separation": ["startTasks_false_skips_pass_b", "startTasks_true_runs_only_logon_tasks", "pass_b_run_failure_does_not_roll_back"]}
MESSAGES = ["snapshot refusal =", "fresh task not created without deletion:", "create conflict erased external task:", "delete refusal =", "blocked replacement ="]
phase = sys.argv[1] if len(sys.argv) > 1 else ""
if os.name != "nt" or sys.flags.optimize or phase not in {"control", "candidate", "adjacent", "build-vet", "published"}:
    raise SystemExit("Unsupported invocation")
if len(sys.argv) != (3 if phase == "published" else 2) or (phase == "published" and not re.fullmatch(r"[0-9a-f]{40}", sys.argv[2])):
    raise SystemExit("Expected phase, and one exact commit only for published")
sha = lambda data: hashlib.sha256(data).hexdigest()
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
out, runtime = ROOT / "evidence" / phase, ROOT / "runtime" / phase
out.mkdir(parents=True, exist_ok=False)
receipt = {"schema": 1, "phase": phase, "base": BASE, "started_utc": utc(), "state": "preflight", "completed": False,
           "runner_sha256": sha(Path(__file__).read_bytes()), "commands": [], "native_task_operations": False,
           "whole_process_tree_deadline_enforced": False, "direct_child_wait_bounded": False}


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def git_at(path, *args):
    command = [str(GIT), "-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), "-C", str(path), *args]
    return subprocess.check_output(command, env=env, stdin=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=60).decode("utf-8").rstrip("\r\n")


def snapshot(path=SOURCE):
    result = {"exists": path.exists(), "sha256": {p: sha((path / p).read_bytes()) if (path / p).is_file() else None for p in PATHS}}
    if (path / ".git").exists():
        result.update(head=git_at(path, "rev-parse", "HEAD"), tree=git_at(path, "rev-parse", "HEAD^{tree}"))
        result["materialized"] = (path / PRODUCT).is_file()
        if result["materialized"]:
            result.update(staged=git_at(path, "diff", "--cached", "--name-only"), status=git_at(path, "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"))
    return result


def admit(state, expected=BASE, path=SOURCE):
    value = snapshot(path)
    statuses = {"base": set(), "control": {"?? " + TEST}, "candidate": {" M " + PRODUCT, "?? " + TEST}, "published": set()}
    if value.get("head") != expected or value.get("staged") != "" or set(value.get("status", "").splitlines()) != statuses[state]:
        raise RuntimeError("Unexpected head, index, tracked, untracked or ignored source state")
    if expected == BASE and value["tree"] != BASE_TREE:
        raise RuntimeError("Unexpected base tree")
    for item in files:
        candidate = state in {"candidate", "published"} or (state == "control" and item["path"] == TEST)
        if value["sha256"][item["path"]] != item["candidate_sha256" if candidate else "base_sha256"]:
            raise RuntimeError("Source byte mismatch: " + item["path"])
    return value


def run(label, executable, args, cwd=SOURCE):
    if executable == GIT:
        args = ["-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(runtime / "empty-hooks"), *args]
    row = {"label": label, "executable": str(executable), "args": args, "cwd": str(cwd), "started_utc": utc(), "settled": False, "source_before": snapshot(),
           "runner_sha256": receipt["runner_sha256"], "manifest_sha256": receipt["manifest_sha256"]}
    receipt["commands"].append(row)
    save(out / (label + ".started.json"), row)
    print("START " + label, flush=True)
    started = time.monotonic()
    try:
        with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
            with subprocess.Popen([str(executable), *args], cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr) as child:
                row["pid"] = child.pid
                row["exit_code"] = child.wait()
                row["settled"] = True
        row.update(seconds=time.monotonic() - started, finished_utc=utc())
        if executable == GO and args and args[0] == "test":
            events = [json.loads(line) for line in (out / (label + ".stdout.log")).read_text(encoding="utf-8").splitlines()]
            row["tests"] = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
    except Exception as error:
        row.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        row.setdefault("seconds", time.monotonic() - started)
        row.setdefault("finished_utc", utc())
        for stream in ("stdout", "stderr"):
            path = out / (label + "." + stream + ".log")
            if path.exists():
                raw = path.read_bytes()
                row[stream] = {"bytes": len(raw), "sha256": sha(raw)}
        try:
            row["source_after"] = snapshot()
        except Exception as error:
            row["source_after_error"] = type(error).__name__ + ": " + str(error)
        save(out / (label + ".receipt.json"), row)
        print(json.dumps({k: row.get(k) for k in ("label", "exit_code", "seconds", "settled")}), flush=True)
    return row


def require_pass(row):
    if not row["settled"] or row.get("exit_code") != 0 or row.get("tests", {}).get("fail") or "source_after_error" in row:
        raise RuntimeError(row["label"] + " failed")


def confirm_tests(row, groups, count, negative=False, directory=out):
    events = [json.loads(line) for line in (directory / (row["label"] + ".stdout.log")).read_text(encoding="utf-8").splitlines()]
    observed = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
    if row.get("tests") != observed or "source_after_error" in row:
        raise RuntimeError("Test receipt differs from raw events or source capture failed")
    names = [name for root, children in groups.items() for name in [root, *(root + "/" + c for c in children)]]
    expected = Counter({name: count for name in names})
    expected["PACKAGE:" + PACKAGE] = 1
    action, opposite = ("fail", "pass") if negative else ("pass", "fail")
    tests = row.get("tests", {})
    if not row["settled"] or row.get("exit_code") != int(negative) or Counter(tests.get(action, [])) != expected or tests.get(opposite) or tests.get("skip"):
        raise RuntimeError("Unexpected test exit, selection or event counts")
    if negative:
        for (root, children), message in zip(GROUPS.items(), MESSAGES):
            for name in [root + "/" + c for c in children] or [root]:
                if message not in "".join(e.get("Output", "") for e in events if e.get("Test") == name):
                    raise RuntimeError("Negative control failed for a different cause: " + name)


def format_check():
    row = run("gofmt-check", GOFMT, ["-l", *PATHS])
    require_pass(row)
    if (out / "gofmt-check.stdout.log").read_text(encoding="utf-8").strip():
        raise RuntimeError("Source needs gofmt; no formatting mutation performed")


def test_run(label, groups, count, negative=False):
    args = ["test", "-json", "-tags=test_state_path_env", *([] if negative else ["-race"]), "-count=" + str(count), "-timeout=180s", "-run", "^(" + "|".join(groups) + ")$", "./internal/api"]
    row = run(label, GO, args)
    confirm_tests(row, groups, count, negative)
    return row


try:
    runtime.mkdir(parents=True, exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "empty-hooks"):
        (runtime / name).mkdir(exist_ok=False)
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_")) and k.upper() != "SSH_ASKPASS"}
    system = Path(next(v for k, v in env.items() if k.upper() == "SYSTEMROOT"))
    ps = system / "System32/WindowsPowerShell/v1.0/powershell.exe"
    env.update({"GOROOT": r"C:\msys64\ucrt64\lib\go", "GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly",
                "GOCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gocache", "GOMODCACHE": r"<WORK_ROOT>\mcp-pr616-qualification-20261114\gomodcache",
                "GOPATH": str(runtime / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1", "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none",
                "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata"), "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"), "GOTMPDIR": str(runtime / "tmp"),
                "PSModuleAnalysisCachePath": str(runtime / "localappdata/module-cache"), "PYTHONDONTWRITEBYTECODE": "1", "GIT_OPTIONAL_LOCKS": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(runtime / "no-global-config"), "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never"})
    env["PATH"] = os.pathsep.join((str(GO.parent), str(ps.parent), str(system / "System32"), str(GIT.parent), env.get("PATH", "")))
    for path in (GO, GOFMT, GIT, Path(env["GOROOT"]), Path(env["CC"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
        if not path.exists():
            raise RuntimeError("Missing pre-existing tool/cache: " + str(path))
    manifest_raw = (ROOT / "source-manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    files = manifest["files"]
    if manifest["base_commit"] != BASE or len(files) != 2 or {x["path"] for x in files} != set(PATHS):
        raise RuntimeError("Unexpected source manifest")
    receipt.update(manifest_sha256=sha(manifest_raw), patch_sha256={name: sha((ROOT / name).read_bytes()) for name in ("control.patch", "product.patch", "candidate.patch")}, environment={k: env[k] for k in ("GOENV", "GOTOOLCHAIN", "GOPROXY", "GOSUMDB", "GOVCS", "GOWORK", "GOFLAGS", "GOTELEMETRY", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "GOCACHE", "GOMODCACHE")})
    if any(value != manifest[name] for name, value in receipt["patch_sha256"].items()):
        raise RuntimeError("Patch bytes differ from manifest")
    save(out / "receipt-initial.json", receipt)
    receipt["state"] = "running"
    if phase == "control":
        if SOURCE.exists():
            raise RuntimeError("Destination already exists")
        receipt["clone_source"] = admit("base", path=OLD)
        require_pass(run("clone", GIT, ["clone", "--single-branch", "--local", "--no-hardlinks", "--no-checkout", str(OLD), str(SOURCE)], ROOT))
        require_pass(run("checkout-base", GIT, ["checkout", "--detach", BASE]))
        receipt["source_before"] = admit("base")
        require_pass(run("check-control", GIT, ["apply", "--check", str(ROOT / "control.patch")]))
        require_pass(run("apply-control", GIT, ["apply", str(ROOT / "control.patch")]))
        receipt["control_source"] = admit("control")
        if set(re.findall(r"^func (Test\w+)\(t \*testing.T\)", (SOURCE / TEST).read_text(encoding="utf-8"), re.M)) != set(GROUPS):
            raise RuntimeError("Test root names differ from the reviewed selection")
        format_check()
        require_pass(run("go-version", GO, ["version"]))
        test_run("original-snapshot-control", GROUPS, 1, True)
        receipt["negative_control_confirmed"] = True
        receipt["source_after"] = admit("control")
    else:
        expected, state = (sys.argv[2], "published") if phase == "published" else (BASE, "control" if phase == "candidate" else "candidate")
        receipt["source_before"] = admit(state, expected)
        if phase == "candidate":
            prior_path = ROOT / "evidence/control/receipt.json"
            prior_raw = prior_path.read_bytes()
            prior = json.loads(prior_raw)
            control = next(r for r in prior["commands"] if r["label"] == "original-snapshot-control")
            if prior["base"] != BASE or not prior["completed"] or not prior.get("negative_control_confirmed") or prior["manifest_sha256"] != receipt["manifest_sha256"]:
                raise RuntimeError("Prior control not admitted")
            for stream in ("stdout", "stderr"):
                raw = (prior_path.parent / (control["label"] + "." + stream + ".log")).read_bytes()
                if sha(raw) != control[stream]["sha256"] or len(raw) != control[stream]["bytes"]:
                    raise RuntimeError("Retained control stream changed")
            confirm_tests(control, GROUPS, 1, True, prior_path.parent)
            receipt.update(retained_control_receipt_sha256=sha(prior_raw), control_rerun=False)
            require_pass(run("check-product", GIT, ["apply", "--check", str(ROOT / "product.patch")]))
            require_pass(run("apply-product", GIT, ["apply", str(ROOT / "product.patch")]))
            receipt["candidate_source"] = admit("candidate")
        if phase == "published" and (git_at(SOURCE, "show", "-s", "--format=%P", "HEAD") != BASE or set(git_at(SOURCE, "diff", "--name-only", BASE, "HEAD").splitlines()) != set(PATHS)):
            raise RuntimeError("Published commit is not the standalone two-file change")
        format_check()
        if phase in {"candidate", "published"}:
            test_run("snapshot-contract-race", GROUPS, 2)
        elif phase == "adjacent":
            test_run("pass-a-pass-b-race", ADJACENT, 2)
        elif phase == "build-vet":
            require_pass(run("build", GO, ["build", "./..."]))
            require_pass(run("vet", GO, ["vet", "./..."]))
        receipt["source_after"] = admit("published" if phase == "published" else "candidate", expected)
    require_pass(run("diff-check", GIT, ["diff", "--check"]))
    receipt["source_after"] = admit("control" if phase == "control" else "published" if phase == "published" else "candidate", sys.argv[2] if phase == "published" else BASE)
    receipt.update(source_head=receipt["source_after"]["head"], source_tree=receipt["source_after"]["tree"], working_status=receipt["source_after"]["status"], completed=True, state="complete")
except Exception as error:
    receipt.update(state="failed", error_type=type(error).__name__, error=str(error))
    raise
finally:
    receipt["finished_utc"] = utc()
    receipt.update(source_sha256_before=receipt.get("source_before", {}).get("sha256"), source_sha256_after=receipt.get("source_after", {}).get("sha256"))
    save(out / "receipt.json", receipt)
    print(json.dumps({k: receipt.get(k) for k in ("phase", "state", "completed", "error", "negative_control_confirmed", "source_head")}), flush=True)
