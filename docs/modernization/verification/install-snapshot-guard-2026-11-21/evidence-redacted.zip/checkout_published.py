"""Select exactly the published two-file child commit, without integrating branches."""
import sys
sys.dont_write_bytecode = True
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(r"<INSTALL_SNAPSHOT_ROOT>")
SOURCE = ROOT / "source"
BASE = "11c286fb634cc63d2c6019a790ff376a1d834af9"
BASE_TREE = "ba769a5cbed3e05d3071a0cfb846127019500b49"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
PATHS = ["internal/api/install.go", "internal/api/install_scheduler_snapshot_test.go"]
if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 1:
    raise SystemExit("Unsupported invocation")
digest = lambda b: hashlib.sha256(b).hexdigest()
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
runtime = ROOT / "runtime/published-checkout"
out = ROOT / "evidence/published-checkout"
out.mkdir(parents=True, exist_ok=False)
receipt = {"schema": 1, "phase": "published-checkout", "base": BASE,
           "started_utc": utc(), "runner_sha256": digest(Path(__file__).read_bytes()),
           "completed": False, "commands": [], "whole_process_tree_deadline_enforced": False,
           "direct_child_wait_bounded": False, "native_task_operations": False}


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def git(*args):
    return subprocess.check_output(prefix + list(args), env=env, cwd=SOURCE,
                                   stdin=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                   timeout=60).decode("utf-8").rstrip("\r\n")


def snapshot():
    return {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "parents": git("show", "-s", "--format=%P", "HEAD").split(),
            "status": git("status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"),
            "staged": git("diff", "--cached", "--name-only"),
            "sha256": {p: digest((SOURCE / p).read_bytes()) for p in PATHS}}


def run(label, args):
    row = {"label": label, "executable": str(GIT), "args": args, "cwd": str(SOURCE),
           "started_utc": utc(), "settled": False, "source_before": snapshot(),
           "runner_sha256": receipt["runner_sha256"], "manifest_sha256": receipt["manifest_sha256"]}
    receipt["commands"].append(row)
    save(out / (label + ".started.json"), row)
    print("START " + label, flush=True)
    started = time.monotonic()
    try:
        with (out / (label + ".stdout.log")).open("xb") as fo, (out / (label + ".stderr.log")).open("xb") as fe:
            with subprocess.Popen(prefix + args, cwd=SOURCE, env=env, stdin=subprocess.DEVNULL, stdout=fo, stderr=fe) as child:
                row["pid"] = child.pid
                row["exit_code"] = child.wait()
                row["settled"] = True
        if row["exit_code"] != 0:
            raise RuntimeError(label + " failed")
    except Exception as error:
        row.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        row.update(seconds=time.monotonic() - started, finished_utc=utc())
        for stream in ("stdout", "stderr"):
            path = out / (label + "." + stream + ".log")
            if path.exists():
                raw = path.read_bytes()
                row[stream] = {"bytes": len(raw), "sha256": digest(raw)}
        try:
            row["source_after"] = snapshot()
        except Exception as error:
            row["source_after_error"] = type(error).__name__ + ": " + str(error)
        save(out / (label + ".receipt.json"), row)
        print(json.dumps({k: row.get(k) for k in ("label", "exit_code", "seconds", "settled")}), flush=True)
    if "source_after_error" in row:
        raise RuntimeError("Source observation failed after " + label)


try:
    runtime.mkdir(parents=True, exist_ok=False)
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_") and k.upper() != "SSH_ASKPASS"}
    for key in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
        folder = runtime / key.lower()
        folder.mkdir(exist_ok=False)
        env[key] = str(folder)
    hooks = runtime / "empty-hooks"
    hooks.mkdir()
    env.update(GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never", GIT_CONFIG_NOSYSTEM="1",
               GIT_CONFIG_GLOBAL=str(runtime / "no-global-config"), GIT_OPTIONAL_LOCKS="0",
               PYTHONDONTWRITEBYTECODE="1")
    prefix = [str(GIT), "-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(hooks),
              "-c", "credential.helper=", "-c", "core.askPass=", "-C", str(SOURCE)]
    manifest_raw = (ROOT / "source-manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    publication_raw = (ROOT / "publication-input.json").read_bytes()
    publication = json.loads(publication_raw)
    expected, tree = publication["commit"], publication["tree"]
    if publication["schema"] != 1 or publication["base"] != BASE or publication["parents"] != [BASE] or not all(re.fullmatch(r"[0-9a-f]{40}", v) for v in (expected, tree)):
        raise RuntimeError("Unexpected publication input")
    if publication["checkout_runner_sha256"] != receipt["runner_sha256"] or publication["source_manifest_sha256"] != digest(manifest_raw):
        raise RuntimeError("Publication source or checkout runner pin mismatch")
    if manifest["base_commit"] != BASE or len(manifest["files"]) != 2 or {f["path"] for f in manifest["files"]} != set(PATHS):
        raise RuntimeError("Unexpected source manifest")
    expected_hashes = {f["path"]: f["candidate_sha256"] for f in manifest["files"]}
    receipt.update(manifest_sha256=digest(manifest_raw), publication_input_sha256=digest(publication_raw),
                   expected_commit=expected, expected_tree=tree)
    before = snapshot()
    receipt["source_before"] = before
    receipt["source_sha256_before"] = before["sha256"]
    if before["head"] != BASE or before["tree"] != BASE_TREE or before["staged"] or before["sha256"] != expected_hashes or set(before["status"].splitlines()) != {" M " + PATHS[0], "?? " + PATHS[1]}:
        raise RuntimeError("Candidate changed before publication checkout")
    save(out / "receipt-initial.json", receipt)
    run("stage-exact-files", ["add", "--", *PATHS])
    if git("write-tree") != tree:
        raise RuntimeError("Staged tree differs from published candidate")
    run("fetch-exact-commit", ["fetch", "--no-tags", "https://github.com/applicate2628/mcp-local-hub.git", expected])
    if git("show", "-s", "--format=%P", expected).split() != [BASE] or git("rev-parse", expected + "^{tree}") != tree:
        raise RuntimeError("Published ancestry or tree differs")
    if set(git("diff", "--name-only", BASE, expected).splitlines()) != set(PATHS):
        raise RuntimeError("Published commit changes unexpected paths")
    run("checkout-detached", ["checkout", "--detach", expected])
    after = snapshot()
    receipt.update(source_after=after, source_sha256_after=after["sha256"], head=after["head"], tree=after["tree"], parents=after["parents"], status=after["status"])
    if after["head"] != expected or after["tree"] != tree or after["parents"] != [BASE] or after["status"] or after["staged"] or after["sha256"] != expected_hashes:
        raise RuntimeError("Published checkout is not exact and clean")
    receipt["completed"] = True
except Exception as error:
    receipt.update(error_type=type(error).__name__, error=str(error))
    raise
finally:
    receipt["finished_utc"] = utc()
    save(out / "receipt.json", receipt)
    print(json.dumps({k: receipt.get(k) for k in ("phase", "completed", "error", "head", "tree")}), flush=True)
