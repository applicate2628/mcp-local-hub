import ctypes as c
from ctypes import wintypes as w
import datetime as dt
import json
from pathlib import Path
k=c.WinDLL("kernel32",use_last_error=True)
class PE(c.Structure):
    _fields_=[("size",w.DWORD),("usage",w.DWORD),("pid",w.DWORD),("heap",c.c_size_t),("module",w.DWORD),("threads",w.DWORD),("ppid",w.DWORD),("priority",w.LONG),("flags",w.DWORD),("name",w.WCHAR*260)]
k.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];k.CreateToolhelp32Snapshot.restype=w.HANDLE
k.Process32FirstW.argtypes=[w.HANDLE,c.POINTER(PE)];k.Process32FirstW.restype=w.BOOL
k.Process32NextW.argtypes=[w.HANDLE,c.POINTER(PE)];k.Process32NextW.restype=w.BOOL
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
k.GetProcessTimes.argtypes=[w.HANDLE,*([c.POINTER(w.FILETIME)]*4)];k.GetProcessTimes.restype=w.BOOL
k.GetExitCodeProcess.argtypes=[w.HANDLE,c.POINTER(w.DWORD)];k.GetExitCodeProcess.restype=w.BOOL
h=k.CreateToolhelp32Snapshot(2,0)
if h == c.c_void_p(-1).value: raise c.WinError(c.get_last_error())
rows=[];entry=PE();entry.size=c.sizeof(PE)
try:
    ok=k.Process32FirstW(h,c.byref(entry))
    while ok:
        rows.append(dict(pid=entry.pid,ppid=entry.ppid,name=entry.name,threads=entry.threads))
        ok=k.Process32NextW(h,c.byref(entry))
finally:k.CloseHandle(h)
owned={6288}
while True:
    next_set=owned|{r["pid"] for r in rows if r["ppid"] in owned}
    if next_set==owned:break
    owned=next_set
selected=[r for r in rows if r["pid"] in owned]
ft=lambda f:(f.dwHighDateTime<<32)|f.dwLowDateTime
for row in selected:
    ph=k.OpenProcess(0x1000,False,row["pid"])
    if not ph:
        row["query_error"]=c.get_last_error();continue
    try:
        fields=[w.FILETIME() for _ in range(4)];code=w.DWORD()
        if k.GetProcessTimes(ph,*[c.byref(f) for f in fields]):
            row.update(created_filetime=ft(fields[0]),kernel_seconds=ft(fields[2])/1e7,user_seconds=ft(fields[3])/1e7)
        if k.GetExitCodeProcess(ph,c.byref(code)):row["exit_code"]=code.value
    finally:k.CloseHandle(ph)
result={"observed_utc":dt.datetime.now(dt.timezone.utc).isoformat(),"root_pid":6288,"root_present":any(r["pid"]==6288 for r in rows),"observed_descendants":selected,"read_only":True}
dest=Path(r"<INSTALL_SNAPSHOT_ROOT>")/"control-process-observation.json"
with dest.open("x",encoding="utf-8") as f:json.dump(result,f,indent=2);f.write("\n")
print(json.dumps(result))
