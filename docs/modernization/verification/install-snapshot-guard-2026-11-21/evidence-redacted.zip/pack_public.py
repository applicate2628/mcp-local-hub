"""Verify six settled evidence phases and build one redacted archive, without execution.

publication-input.json: schema, base, commit, tree, parents=[base], and SHA-256
pins checkout_runner_sha256, execution_runner_sha256, source_manifest_sha256.
No subprocess, Git, network, product call, deletion, or overwrite is performed.
All source bytes and an in-memory ZIP are verified before exclusive output writes.
Redacted scripts are audit records, not executable copies.
References: https://docs.python.org/3/library/zipfile.html#zipfile.ZipFile.testzip
https://docs.python.org/3/library/base64.html#base64.b64decode
"""
import sys
sys.dont_write_bytecode = True
import base64
from collections import Counter
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

ROOT = Path(r"<INSTALL_SNAPSHOT_ROOT>")
OLD = r"<CANCELLATION_ROOT>\source"
OUT = ROOT / "public-evidence"
BASE, BASE_TREE = "11c286fb634cc63d2c6019a790ff376a1d834af9", "ba769a5cbed3e05d3071a0cfb846127019500b49"
RUNNER_PIN = "3711efc6b06b3922ea6086ea589091672eb77f25402a8a5c6c146b18defb17f3"
MANIFEST_PIN = "a58de0aa4504e09f414b2ec5ae38068bec0ffdaec78caaa7178746ed4cbec0ee"
PATHS = ["internal/api/install.go", "internal/api/install_scheduler_snapshot_test.go"]
PACKAGE = "mcp-local-hub/internal/api"
GROUPS = {
    "TestExecuteInstallToSnapshotFailurePreservesTask": ["unavailable", "partial_permission_error", "unsupported", "nil_success", "empty_success", "conflicting_absence"],
    "TestExecuteInstallToAbsentSnapshotCreatesWithoutDelete": ["direct", "wrapped"],
    "TestExecuteInstallToAbsentSnapshotCreateConflictPreservesTask": [],
    "TestExecuteInstallToDeleteFailurePreservesTask": [],
    "TestExecuteInstallToSnapshotRefusalRollsBackEarlierTask": ["export", "delete"],
}
ADJACENT = {"TestExecuteInstallTo_PassAPassB_Separation": ["startTasks_false_skips_pass_b", "startTasks_true_runs_only_logon_tasks", "pass_b_run_failure_does_not_roll_back"]}
MESSAGES = ["snapshot refusal =", "fresh task not created without deletion:", "create conflict erased external task:", "delete refusal =", "blocked replacement ="]
PHASES = {
    "control": ["clone", "checkout-base", "check-control", "apply-control", "gofmt-check", "go-version", "original-snapshot-control", "diff-check"],
    "candidate": ["check-product", "apply-product", "gofmt-check", "snapshot-contract-race", "diff-check"],
    "adjacent": ["gofmt-check", "pass-a-pass-b-race", "diff-check"],
    "build-vet": ["gofmt-check", "build", "vet", "diff-check"],
    "published-checkout": ["stage-exact-files", "fetch-exact-commit", "checkout-detached"],
    "published": ["gofmt-check", "snapshot-contract-race", "diff-check"],
}
ENVIRONMENT = {"GOENV": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "-mod=readonly", "GOTELEMETRY": "off", "GOMAXPROCS": "4", "CGO_ENABLED": "1", "MCPHUB_NO_AUTO_GUI": "1", "MCPHUB_E2E_SCHEDULER": "none"}
inputs, inventories = {}, {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON")))


def read(name):
    parts = PurePosixPath(name).parts
    require(parts and not PurePosixPath(name).is_absolute() and ".." not in parts and "\\" not in name and ":" not in name, "Unsafe evidence path")
    path = ROOT / name
    for entry in (path, *path.parents):
        info = entry.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "Evidence link or reparse point")
        if entry == ROOT:
            break
    require(path.is_file() and path.stat().st_size <= 16 * 1024**2, "Missing or oversized evidence file")
    with path.open("rb") as stream:
        raw = stream.read(16 * 1024**2 + 1)
    require(len(raw) <= 16 * 1024**2, "Evidence grew beyond bound")
    if name in inputs:
        require(inputs[name] == raw, "Input changed while packaging: " + name)
    else:
        inputs[name] = raw
    require(len(inputs) <= 256 and sum(map(len, inputs.values())) <= 96 * 1024**2, "Evidence inventory exceeds bound")
    return raw


def inventory(name, expected):
    actual = {path.name for path in (ROOT / name).iterdir()}
    require(actual == expected, "Missing or extra evidence members: " + name)
    inventories[name] = expected


def source(value, state, publication, hashes):
    if state == "absent":
        require(value == {"exists": False, "sha256": dict.fromkeys(PATHS)}, "Clone destination was not absent")
        return
    wanted = dict.fromkeys(PATHS) if state == "unmaterialized" else hashes[state]
    published = state == "published"
    require(value.get("sha256") == wanted and value.get("head") == (publication["commit"] if published else BASE)
            and value.get("tree") == (publication["tree"] if published else BASE_TREE), "Source identity differs: " + state)
    if state == "unmaterialized":
        require(value.get("materialized") is False and value.get("exists") is True, "Unexpected clone checkout")
        return
    expected_status = {"base": set(), "control": {"?? " + PATHS[1]}, "candidate": {" M " + PATHS[0], "?? " + PATHS[1]}, "staged": {"M  " + PATHS[0], "A  " + PATHS[1]}, "published": set()}[state]
    require(isinstance(value.get("status"), str) and set(value["status"].splitlines()) == expected_status and value.get("staged") == ("\n".join(PATHS) if state == "staged" else ""), "Source index or worktree differs: " + state)
    if "parents" in value and published:
        require(value["parents"] == [BASE], "Published snapshot ancestry differs")


def test_events(raw, command, groups, count, negative):
    args = ["test", "-json", "-tags=test_state_path_env", *([] if negative else ["-race"]), "-count=" + str(count), "-timeout=180s", "-run", "^(" + "|".join(groups) + ")$", "./internal/api"]
    require(command["args"] == args and command["executable"] == r"C:\msys64\ucrt64\bin\go.exe", "Test command scope differs")
    lines = raw.decode("utf-8").splitlines()
    require(0 < len(lines) <= 100000 and all(len(line) <= 256 * 1024 for line in lines), "Test event bounds exceeded")
    events = [parse(line) for line in lines]
    require(all(isinstance(e, dict) and e.get("Package") == PACKAGE and isinstance(e.get("Action"), str) for e in events), "Unexpected test package or event shape")
    observed = {a: [e.get("Test", "PACKAGE:" + e["Package"]) for e in events if e["Action"] == a] for a in ("pass", "fail", "skip")}
    expected = Counter({name: count for root, children in groups.items() for name in [root, *(root + "/" + c for c in children)]})
    expected["PACKAGE:" + PACKAGE] = 1
    action, opposite = ("fail", "pass") if negative else ("pass", "fail")
    require(observed == command.get("tests") and Counter(observed[action]) == expected and not observed[opposite] and not observed["skip"], "Raw test events or recorded inventory differs")
    if negative:
        for (root, children), message in zip(GROUPS.items(), MESSAGES):
            for name in [root + "/" + c for c in children] or [root]:
                require(message in "".join(e.get("Output", "") for e in events if e.get("Test") == name), "Control failed for another cause")
    return {action: {"test": sum(not name.startswith("PACKAGE:") for name in names), "package": sum(name.startswith("PACKAGE:") for name in names)} for action, names in observed.items()}


def expected_args(label, phase, publication):
    commands = {"clone": ["clone", "--single-branch", "--local", "--no-hardlinks", "--no-checkout", OLD, str(ROOT / "source")],
                "checkout-base": ["checkout", "--detach", BASE], "gofmt-check": ["-l", *PATHS], "go-version": ["version"],
                "build": ["build", "./..."], "vet": ["vet", "./..."], "diff-check": ["diff", "--check"],
                "stage-exact-files": ["add", "--", *PATHS], "fetch-exact-commit": ["fetch", "--no-tags", "https://github.com/applicate2628/mcp-local-hub.git", publication["commit"]],
                "checkout-detached": ["checkout", "--detach", publication["commit"]]}
    for name in ("control", "product"):
        commands["check-" + name] = ["apply", "--check", str(ROOT / (name + ".patch"))]
        commands["apply-" + name] = ["apply", str(ROOT / (name + ".patch"))]
    exe = r"C:\msys64\ucrt64\bin\gofmt.exe" if label == "gofmt-check" else r"C:\msys64\ucrt64\bin\go.exe" if label in {"go-version", "build", "vet"} else r"C:\Program Files\Git\cmd\git.exe"
    prefix = ["-c", "core.autocrlf=false", "-c", "core.hooksPath=" + str(ROOT / "runtime" / phase / "empty-hooks")] if exe.endswith("git.exe") and phase != "published-checkout" else []
    return exe, prefix + commands[label]


def redact(raw):
    text = raw.decode("utf-8")
    replacements = [(str(ROOT), "<INSTALL_SNAPSHOT_ROOT>"), (OLD.rsplit("\\", 1)[0], "<CANCELLATION_ROOT>"), (r"<WORK_ROOT>", "<WORK_ROOT>")]
    profile = os.environ.get("USERPROFILE", "")
    if profile and re.match(r"(?i)[A-Z]:[\\/]Users[\\/]", profile):
        replacements.append((profile, "<USER_PROFILE>"))
    for old, replacement in sorted(replacements, key=lambda item: len(item[0]), reverse=True):
        pattern = r"[\\/]{1,4}".join(re.escape(part) for part in re.split(r"[\\/]", old))
        text = re.sub(pattern + r"(?=$|[\\/\s\"'`),:])", lambda _: replacement, text, flags=re.I)
    require(not re.search(r"(?i)[A-Z]:[\\/]{1,4}Users[\\/]|D:[\\/]{1,4}dev[\\/]{1,4}ChatGPT|\bS-\d-\d+(?:-\d+){2,}\b|\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b", text), "Private profile, work root, SID or device identifier remains")
    require(not re.search(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{24,}|AKIA[A-Z0-9]{16})\b|-----BEGIN [A-Z ]*PRIVATE KEY-----", text), "Potential credential marker")
    for key in ("USERNAME", "USERDOMAIN", "COMPUTERNAME"):
        token = os.environ.get(key, "")
        if len(token) >= 3 and token.lower() not in {"system", "user", "windows", "builtin"}:
            require(not re.search(r"(?<!\w)" + re.escape(token) + r"(?!\w)", text, re.I), "Unredacted local identity")
    return text.encode("utf-8")


def main():
    require(os.name == "nt" and not sys.flags.optimize and len(sys.argv) == 1, "Unsupported invocation")
    require(not OUT.exists(), "Output exists; nothing will be overwritten")
    manifest_raw = read("source-manifest.json")
    manifest = parse(manifest_raw)
    publication_raw = read("publication-input.json")
    publication = parse(publication_raw)
    required = {"schema", "base", "commit", "tree", "parents", "checkout_runner_sha256", "execution_runner_sha256", "source_manifest_sha256"}
    require(set(publication) == required and publication["schema"] == 1 and publication["base"] == BASE and publication["parents"] == [BASE], "Publication schema or ancestry differs")
    require(all(re.fullmatch(r"[0-9a-f]{40}", publication[k]) for k in ("commit", "tree")) and publication["commit"] != BASE, "Invalid published identity")
    require(publication["source_manifest_sha256"] == digest(manifest_raw) == MANIFEST_PIN and publication["execution_runner_sha256"] == digest(read("check_replacement.py")) == RUNNER_PIN, "Frozen manifest or execution runner pin differs")
    require(digest(read("checkout_published.py")) == publication["checkout_runner_sha256"], "Checkout runner pin differs")
    require(manifest["base_commit"] == BASE and len(manifest["files"]) == 2 and {f["path"] for f in manifest["files"]} == set(PATHS), "Source manifest scope differs")
    hashes = {state: {f["path"]: f[state + "_sha256"] for f in manifest["files"]} for state in ("base", "candidate")}
    hashes["control"] = {**hashes["base"], PATHS[1]: hashes["candidate"][PATHS[1]]}
    hashes["published"] = hashes["staged"] = hashes["candidate"]
    for name in ("control.patch", "product.patch", "candidate.patch"):
        require(digest(read(name)) == manifest[name], "Patch differs from execution manifest")
    read("ACCEPTANCE.md")
    observation = {"included": False}
    observer_names = ("observe_control.py", "control-process-observation.json")
    present = [(ROOT / name).exists() for name in observer_names]
    if any(present):
        require(all(present), "Observer source and observation must be retained together")
        observer_raw, observed_raw = (read(name) for name in observer_names)
        observed = parse(observed_raw)
        require(set(observed) == {"observed_utc", "root_pid", "root_present", "observed_descendants", "read_only"} and observed["read_only"] is True and isinstance(observed["observed_descendants"], list), "Unexpected read-only observation schema")
        observation = {"included": True, "observer_source_sha256": digest(observer_raw), "observation_source_sha256": digest(observed_raw), "observed_utc": observed["observed_utc"], "observation_contains_runner_self_attestation": False,
                       "scope": "Limited read-only process snapshot. Pair hashes identify retained bytes; the original observation does not bind its runner. It does not establish delay cause or whole-tree settlement."}
    require(Path(__file__).resolve() == (ROOT / "pack_public.py").resolve(), "Unexpected packer location")
    read("pack_public.py")
    for item in manifest["files"]:
        raw = read("source/" + item["path"])
        require(digest(raw) == item["candidate_sha256"] and hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == item["candidate_blob"], "Published source bytes differ")
    inventory("evidence", set(PHASES))
    phases, commands, receipts = {}, [], {}
    transitions = {"clone": ("absent", "unmaterialized"), "checkout-base": ("unmaterialized", "base"), "check-control": ("base", "base"), "apply-control": ("base", "control"), "check-product": ("control", "control"), "apply-product": ("control", "candidate"), "stage-exact-files": ("candidate", "staged"), "fetch-exact-commit": ("staged", "staged"), "checkout-detached": ("staged", "published")}
    for phase, labels in PHASES.items():
        folder = "evidence/" + phase + "/"
        raw = read(folder + "receipt.json")
        receipt = receipts[phase] = parse(raw)
        runner_pin = publication["checkout_runner_sha256"] if phase == "published-checkout" else RUNNER_PIN
        require(receipt.get("schema") == 1 and receipt.get("phase") == phase and receipt.get("base") == BASE and receipt.get("completed") is True and "error" not in receipt, "Incomplete or failed phase: " + phase)
        require(receipt.get("runner_sha256") == runner_pin and receipt.get("manifest_sha256") == MANIFEST_PIN and all(receipt.get(k) is False for k in ("whole_process_tree_deadline_enforced", "direct_child_wait_bounded", "native_task_operations")), "Phase pins or limits differ")
        before = "base" if phase == "control" else "control" if phase == "candidate" else "published" if phase == "published" else "candidate"
        after = "control" if phase == "control" else "published" if phase in {"published", "published-checkout"} else "candidate"
        source(receipt.get("source_before", {}), before, publication, hashes)
        source(receipt.get("source_after", {}), after, publication, hashes)
        require(receipt.get("source_sha256_before") == hashes[before] and receipt.get("source_sha256_after") == hashes[after], "Phase source hash aliases differ")
        if phase == "published-checkout":
            require(receipt.get("publication_input_sha256") == digest(publication_raw) and all(receipt.get(k) == publication[v] for k, v in {"expected_commit": "commit", "expected_tree": "tree", "head": "commit", "tree": "tree"}.items()) and receipt.get("parents") == [BASE] and receipt.get("status") == "", "Published checkout identity differs")
        else:
            require(receipt.get("state") == "complete" and all(receipt.get("environment", {}).get(k) == v for k, v in ENVIRONMENT.items()) and receipt.get("patch_sha256") == {k: manifest[k] for k in ("control.patch", "product.patch", "candidate.patch")}, "Execution phase environment or patch pins differ")
            require((receipt.get("source_head"), receipt.get("source_tree"), receipt.get("working_status")) == tuple(receipt["source_after"][k] for k in ("head", "tree", "status")), "Final source identity aliases differ")
            require(all(str(receipt["environment"].get(k, "")).startswith(str(ROOT / "runtime" / phase)) for k in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP")), "Execution profile or temp paths differ")
        initial = parse(read(folder + "receipt-initial.json"))
        require({"schema", "phase", "base", "runner_sha256", "manifest_sha256"} <= set(initial), "Initial phase identity is incomplete")
        require(initial.get("completed") is False and initial.get("commands") == [] and all(receipt.get(k) == v for k, v in initial.items() if k not in {"completed", "commands", "state"}), "Initial phase receipt differs")
        require([c.get("label") for c in receipt.get("commands", [])] == labels, "Command inventory differs")
        expected_files = {"receipt.json", "receipt-initial.json"}
        for command in receipt["commands"]:
            label = command["label"]
            negative = label == "original-snapshot-control"
            require(command.get("settled") is True and type(command.get("exit_code")) is int and command["exit_code"] == int(negative) and not any(k in command for k in ("error", "source_after_error")), "Unexpected or unsettled command outcome")
            require(command.get("cwd") == str(ROOT if label == "clone" else ROOT / "source"), "Command working directory differs")
            require(type(command.get("seconds")) in (int, float) and math.isfinite(command["seconds"]) and command["seconds"] >= 0 and command.get("runner_sha256") == runner_pin and command.get("manifest_sha256") == MANIFEST_PIN, "Command duration or pins differ")
            files = {suffix: read(folder + label + suffix) for suffix in (".started.json", ".receipt.json", ".stdout.log", ".stderr.log")}
            expected_files.update(label + suffix for suffix in files)
            require(parse(files[".receipt.json"]) == command, "Command and phase receipts differ")
            started = parse(files[".started.json"])
            require(set(started) == {"label", "executable", "args", "cwd", "started_utc", "settled", "source_before", "runner_sha256", "manifest_sha256"}, "Initial command identity is incomplete")
            require(started.get("settled") is False and "exit_code" not in started and all(command.get(k) == v for k, v in started.items() if k != "settled"), "Initial command receipt differs")
            for stream in ("stdout", "stderr"):
                data = files["." + stream + ".log"]
                require(command.get(stream) == {"bytes": len(data), "sha256": digest(data)}, "Original stream hash or size differs")
                require(b"WARNING: DATA RACE" not in data, "Unexpected race detector finding")
            default = "control" if phase == "control" else "published" if phase == "published" else "candidate"
            states = transitions.get(label, (default, default))
            for key, state in zip(("source_before", "source_after"), states):
                source(command.get(key, {}), state, publication, hashes)
            summary = {k: command[k] for k in ("label", "args", "exit_code", "seconds", "stdout", "stderr")}
            summary.update(phase=phase, outcome="expected FAIL retained" if negative else "PASS")
            if label in {"original-snapshot-control", "snapshot-contract-race", "pass-a-pass-b-race"}:
                summary["events"] = test_events(files[".stdout.log"], command, ADJACENT if label == "pass-a-pass-b-race" else GROUPS, 1 if negative else 2, negative)
            else:
                require((command.get("executable"), command.get("args")) == expected_args(label, phase, publication) and "tests" not in command, "Non-test command scope differs")
                if label == "gofmt-check":
                    require(not files[".stdout.log"].decode("utf-8").strip(), "Unformatted source reported")
            commands.append(summary)
        inventory(folder.rstrip("/"), expected_files)
        phases[phase] = {"completed": True, "receipt_source_sha256": digest(raw), "runner_sha256": runner_pin, "source_before": receipt["source_before"], "source_after": receipt["source_after"]}
    require(receipts["control"].get("negative_control_confirmed") is True and receipts["candidate"].get("control_rerun") is False and receipts["candidate"].get("retained_control_receipt_sha256") == digest(inputs["evidence/control/receipt.json"]), "Retained negative-control link differs")
    source(receipts["control"].get("clone_source", {}), "base", publication, hashes)
    summary = {"schema": 1, "publication": publication, "phases": phases, "commands": commands, "raw_command_streams_verified": 2 * len(commands), "expected_failures_retained": True, "negative_control_rerun": False, "control_process_observation": observation,
               "limits": {"whole_process_tree_deadline_enforced": False, "direct_child_wait_bounded": False, "native_task_operations": False, "full_test_suites_run": False, "native_concurrent_replacement_qualified": False}, "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    members, rows = {}, []
    for name, raw in [*(item for item in inputs.items() if not item[0].startswith("source/")), ("execution-summary.json", encode(summary))]:
        saved = redact(raw)
        if name.endswith(".json"):
            parse(saved)
        members[name] = saved
        rows.append({"path": name, "source_bytes": len(raw), "source_sha256": digest(raw), "saved_bytes": len(saved), "saved_sha256": digest(saved), "redacted": saved != raw, "generated_in_memory": name == "execution-summary.json"})
    catalog = {"schema": 1, "files": rows, "redacted_files": [r["path"] for r in rows if r["redacted"]], "verified_source_files_not_archived": hashes["candidate"], "redaction": "Only concrete known local roots/profile paths replaced; unexpected identity, SID, GUID or credential markers reject publication. Original hashes bind retained inputs; saved hashes bind public bytes. Redacted scripts are audit records. MANIFEST.json is hashed outside the ZIP to avoid self-reference."}
    members["MANIFEST.json"] = encode(catalog)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 21, 0, 0, 0))
            info.compress_type, info.external_attr = zipfile.ZIP_DEFLATED, 0o600 << 16
            archive.writestr(info, raw)
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as archive:
        require(archive.testzip() is None and len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members), "ZIP CRC or inventory mismatch")
        for name, raw in members.items():
            require(archive.read(name) == raw, "ZIP member differs from verified bytes")
        for row in rows:
            require(digest(archive.read(row["path"])) == row["saved_sha256"], "ZIP manifest hash differs")
    outputs = {"evidence-redacted.zip": zipped, "MANIFEST.json": members["MANIFEST.json"], "execution-summary.json": members["execution-summary.json"], "evidence-transfer.b64": base64.b64encode(zipped)}
    require(base64.b64decode(outputs["evidence-transfer.b64"], validate=True) == zipped, "Transfer encoding differs")
    metadata = {"schema": 1, "archive": "evidence-redacted.zip", "bytes": len(zipped), "sha256": digest(zipped), "entries": len(members), "manifest_files": len(rows), "raw_command_streams_verified": 2 * len(commands), "crc_and_manifest_verified": True, "original_hashes_distinct_from_saved_hashes": True, "saved_files": {name: {"bytes": len(raw), "sha256": digest(raw)} for name, raw in outputs.items()}, "metadata_self_hash_omitted_to_avoid_self_reference": True}
    outputs["archive-metadata.json"] = encode(metadata)
    for name in tuple(inputs):
        read(name)
    for name, names in tuple(inventories.items()):
        inventory(name, names)
    OUT.mkdir(exist_ok=False)
    for name, raw in outputs.items():
        with (OUT / name).open("xb") as stream:
            stream.write(raw)
        require((OUT / name).read_bytes() == raw, "Saved output differs from verified memory")
    print(json.dumps(metadata), flush=True)


if __name__ == "__main__":
    main()
