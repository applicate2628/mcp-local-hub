"""Read-only location of a rejected redacted member; no paths or contents emitted."""
from pathlib import Path
import hashlib
import json
import re

root = Path(r'<WORK_ROOT>')
path = root / 'package_evidence.py'
source = path.read_bytes()
if hashlib.sha256(source).hexdigest() != 'c5f5cd64198d422a1117ab03d67c7a2c2e02d57a685040d0ab3ec21536d90012':
    raise SystemExit('Packager version mismatch')
namespace = {'__name__': 'diagnostic_only', '__file__': str(path)}
exec(compile(source, str(path), 'exec'), namespace)
_, _, inputs = namespace['validate']()
saved, scan = namespace['redactor']()
findings = []
for name, original in inputs.items():
    data = saved(name, namespace['read'](original))
    try:
        scan(data, name)
    except namespace['EvidenceError'] as error:
        text = data.decode('utf-8', errors='surrogateescape')
        findings.append({'member': name, 'category': str(error),
                         'drive_markers': [{'marker': match.group(),
                                            'line': text.count('\n', 0, match.start()) + 1,
                                            'column': match.start() - text.rfind('\n', 0, match.start())}
                                           for match in re.finditer(r'\b[A-Za-z]:[\\/]+', text)]})
print(json.dumps({'mode': 'saved_inputs_only', 'mutations': False, 'findings': findings}), flush=True)
