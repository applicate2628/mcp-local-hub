"""Select the exact published commit after completed checks, preserving red gates."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
ROOT = Path(r'<WORK_ROOT>')
SOURCE = ROOT / 'source'
BASE = '92f2d4350bfc22a5fa8099fd1b4ec199f9a19c22'
BASE_TREE = '52c4919ab291021b80e19b6550808ce8a0d93f23'
TREE = '75e9b00a936a639172d08e4ccf1fde947d6899dd'
EXPECTED = '2cb467aac31259ed4fb665ed0a4f277a8f9c31a2'
MANIFEST_SHA = '1e3344169c730ec3ca893db86153209c499fb0fb90e1e998e4c5f402444e2428'
GIT = r'<GIT_EXECUTABLE>'
out = ROOT / 'evidence/published-checkout'
out.mkdir(exist_ok=False)
runtime = ROOT / 'runtime/published-checkout'
for part in ('tmp', 'profile', 'appdata', 'localappdata', 'empty-hooks'):
    (runtime / part).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items()
       if not k.upper().startswith(('GIT_', 'MCPHUB_'))}
env.update({'GIT_TERMINAL_PROMPT': '0', 'GIT_CONFIG_NOSYSTEM': '1',
            'GIT_CONFIG_GLOBAL': str(runtime / 'no-global-git-config'),
            'TEMP': str(runtime / 'tmp'), 'TMP': str(runtime / 'tmp'),
            'TMPDIR': str(runtime / 'tmp'), 'USERPROFILE': str(runtime / 'profile'),
            'APPDATA': str(runtime / 'appdata'), 'LOCALAPPDATA': str(runtime / 'localappdata')})
receipt = {'phase': 'published-checkout', 'previous_head': BASE,
           'expected_head': EXPECTED, 'expected_tree': TREE, 'commands': [],
           'started_utc': datetime.now(timezone.utc).isoformat(),
           'whole_process_tree_deadline_enforced': False}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


def command(args):
    return [GIT, '-c', 'core.hooksPath=' + str(runtime / 'empty-hooks'),
            '-C', str(SOURCE), *args]


def git(*args):
    return subprocess.check_output(command(args), env=env, cwd=SOURCE,
                                   timeout=90).decode('utf-8').strip()


def ensure_root():
    if Path(git('rev-parse', '--show-toplevel')).resolve() != SOURCE.resolve():
        raise RuntimeError('Repository root mismatch')


def run(name, args):
    record = {'name': name, 'arguments': args, 'settled': False,
              'direct_child_deadline_seconds': 90,
              'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(record)
    save()
    start = time.monotonic()
    with (out / (name + '.stdout.log')).open('xb') as fo, \
         (out / (name + '.stderr.log')).open('xb') as fe:
        child = subprocess.Popen(command(args), env=env, cwd=SOURCE,
                                 stdin=subprocess.DEVNULL, stdout=fo, stderr=fe,
                                 creationflags=0x08000000)
        try:
            record['pid'] = child.pid
            save()
            child.wait(timeout=max(0, 90 - (time.monotonic() - start)))
        finally:
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, 90 - (time.monotonic() - start)))
                except subprocess.TimeoutExpired:
                    record['direct_child_deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            record['exit_code'] = child.returncode
            record['settled'] = child.returncode is not None
            save()
    record['seconds'] = round(time.monotonic() - start, 3)
    for stream in ('stdout', 'stderr'):
        path = out / (name + '.' + stream + '.log')
        record[stream + '_bytes'] = path.stat().st_size
        record[stream + '_sha256'] = digest(path)
    save()
    if record['exit_code'] != 0 or record.get('direct_child_deadline_hit'):
        raise RuntimeError(name + ' failed or exceeded its direct-child deadline')


try:
    receipt['script_sha256'] = digest(Path(__file__))
    manifest_data = (ROOT / 'candidate-manifest-v2.json').read_bytes()
    if hashlib.sha256(manifest_data).hexdigest() != MANIFEST_SHA:
        raise RuntimeError('Manifest identity mismatch')
    files = json.loads(manifest_data)['files']
    gates = json.loads((ROOT / 'evidence/gates/receipt.json').read_text())
    if (not gates.get('completed') or gates['candidate_tree'] != TREE
            or gates['manifest_sha256'] != MANIFEST_SHA
            or [c['name'] for c in gates['commands']] != ['build', 'vet', 'full-test', 'tagged-api-cli']
            or not all(c.get('settled') is True and not c.get('direct_child_deadline_hit')
                       for c in gates['commands'])):
        raise RuntimeError('Gate evidence incomplete')
    ensure_root()
    status = sorted(('M  ' if f['base_blob'] else 'A  ') + f['path'] for f in files)
    if (git('rev-parse', 'HEAD') != BASE or git('rev-parse', 'HEAD^{tree}') != BASE_TREE
            or sorted(git('status', '--porcelain=v1', '--untracked-files=all').splitlines()) != status
            or git('diff', '--name-only') or git('write-tree') != TREE):
        raise RuntimeError('Prepared source/index mismatch')
    for item in files:
        if digest(SOURCE / item['path']) != item['sha256']:
            raise RuntimeError('Prepared file changed: ' + item['path'])
    receipt['prepared_tree'] = TREE
    run('fetch', ['fetch', '--no-tags', 'https://github.com/applicate2628/mcp-local-hub.git', EXPECTED])
    if (git('show', '-s', '--format=%P', EXPECTED) != BASE
            or git('rev-parse', EXPECTED + '^{tree}') != TREE):
        raise RuntimeError('Published parent/tree mismatch')
    run('checkout', ['checkout', '--detach', EXPECTED])
    ensure_root()
    receipt.update({'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                    'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
                    'status': git('status', '--porcelain=v1', '--untracked-files=all')})
    if (receipt['head'] != EXPECTED or receipt['tree'] != TREE
            or receipt['parents'] != [BASE] or receipt['status']):
        raise RuntimeError('Published checkout identity mismatch')
    for item in files:
        if digest(SOURCE / item['path']) != item['sha256']:
            raise RuntimeError('Published file changed: ' + item['path'])
    receipt['completed'] = True
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps({'head': receipt['head'], 'tree': receipt['tree'],
                  'clean': True, 'completed': True}), flush=True)
