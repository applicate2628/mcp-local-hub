"""Compare path-marker scans on JSON text and decoded values; emit counts only."""
from pathlib import Path
import hashlib
import json
import re

root = Path(r'<WORK_ROOT>')
path = root / 'package_evidence.py'
source = path.read_bytes()
if hashlib.sha256(source).hexdigest() != 'c5f5cd64198d422a1117ab03d67c7a2c2e02d57a685040d0ab3ec21536d90012':
    raise SystemExit('Packager version mismatch')
namespace = {'__name__': 'diagnostic_only', '__file__': str(path)}
exec(compile(source, str(path), 'exec'), namespace)
namespace['validate']()
saved, _ = namespace['redactor']()
name = 'evidence/candidate/packages-race.stdout.log'
data = saved(name, namespace['read'](name))
values = []


def visit(value):
    if isinstance(value, str):
        values.append(value)
    elif isinstance(value, list):
        for item in value:
            visit(item)
    elif isinstance(value, dict):
        for key, item in value.items():
            visit(key)
            visit(item)


for line in data.splitlines():
    visit(namespace['parse'](line))
patterns = {'drive': r'\b[A-Za-z]:[\\/]+',
            'unc': r'(?<!\\)\\\\+[A-Za-z0-9_.-]+[\\/][^\s"\'<>]*'}
text = data.decode('utf-8')
print(json.dumps({'member': name, 'decoded_strings': len(values),
                  'counts': {key: {'serialized': len(re.findall(pattern, text)),
                                   'decoded_values': sum(len(re.findall(pattern, value)) for value in values)}
                             for key, pattern in patterns.items()},
                  'mutations': False}), flush=True)
