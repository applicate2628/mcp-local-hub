"""Validate saved Go state-isolation evidence and package sanitized review copies.

Usage: python package_evidence.py <exact-published-commit> [--wait-seconds N]
Waits read-only for published.completed (default 900 s, maximum 3600 s), then
requires the completed post-verify snapshot. No Git, tests, CIM, or native calls.
All outputs are exclusive. Existing/partial outputs and prior attempts remain.
Native candidate files, task identities/XML/arguments, runtime and source caches
are never enumerated or included. Native public evidence is a separate archive.
"""
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import time
import zipfile

ROOT = Path(r'<WORK_ROOT>')
BASE = '92f2d4350bfc22a5fa8099fd1b4ec199f9a19c22'
BASE_TREE = '52c4919ab291021b80e19b6550808ce8a0d93f23'
TREE = '75e9b00a936a639172d08e4ccf1fde947d6899dd'
HEAD = '2cb467aac31259ed4fb665ed0a4f277a8f9c31a2'
REPOSITORY = 'https://github.com/applicate2628/mcp-local-hub.git'
OLD = r'<PREVIOUS_SOURCE>'
SERENA_TEST = 'internal/api/serena_routing/resolver_test.go'
PRODUCT = 'internal/api/serena_routing/resolver.go'
ORIGINAL_PRODUCT = 'c05c5ebb9e00fd4fca6cd8158843001f6703ab48c8e1418994bbd12b003180b1'
MUTANT = 'f4c9f345b6edaf7e9f86ea4950f33c4b70bac5ef6b13ff68cf6e4afae2c5fb7f'
SOURCE_PINS = {
    'run_checks.py': 'b2ea765ba2a0ce3d5c24c7aa150d3e7203437c253ef277ea1444caeab7a075a3',
    'history/run_checks-bootstrap.py': '5bce29eeeb4888c8e23087de360dafa13874690108e21e953be3cc4ad28df154',
    'history/run_checks-candidate.py': 'ded5f3e2f839653996a4887b5eef8cbd32fa9fa9fb212c4639cd1ade461cb9c4',
    'checkout_published.py': 'f0bdbb9579e5cdb3c9e64c8feb416f4eaaa874817dbf3af709c0ff6464e79ff7',
    'candidate-manifest.json': '9b4e00789a9f1bd59610f483088f3186e43394fbe4bc84b462a741e411ebb872',
    'candidate-manifest-v2.json': '1e3344169c730ec3ca893db86153209c499fb0fb90e1e998e4c5f402444e2428',
}
EXPECTED_FILES = {
    'internal/api/lsp_routing/main_test.go', 'internal/api/lsp_routing/resolver_test.go',
    'internal/api/serena_routing/main_test.go', SERENA_TEST,
    'internal/api/serena_routing/shared_observer_public_test.go',
    'internal/daemon/host_original_windows_test.go', 'internal/daemon/lazy_proxy_readiness_test.go',
    'internal/daemon/lazy_proxy_test.go', 'internal/daemon/main_test.go',
    'internal/oneapirun/async_owner_test.go', 'internal/oneapirun/async_test.go',
    'internal/oneapirun/main_test.go',
}
PACKAGES = ['./internal/api/lsp_routing', './internal/api/serena_routing',
            './internal/daemon', './internal/oneapirun']
TESTS = [
    'TestResolveByPath_SameMtimeRegistryReplacementObservedWithin32Lookups',
    'TestResolveByPath_AbsoluteMatch', 'TestLazyProxy_InitializeSyntheticNoMaterialize',
    'TestAsyncRun_PersistsAndReloadsCappedNonUTF8Output',
    'TestAsyncRun_LoadsLegacyExpandedTextIntoSamePathBase64',
    'TestAsyncRun_CloseConcurrentCallersWaitForDeferredWorkerAndRetryLeaseUnlock',
    'TestAsyncRun_CloseWaitsForEvictedTerminalWorker',
    'TestRunInOneAPIEnvTool_StartReturnsAcceptedReceipt',
]
FOCUSED = '^(' + '|'.join(TESTS) + ')$'
TARGETS = [(PACKAGES[0], TESTS[0]), (PACKAGES[1], TESTS[1]),
           (PACKAGES[2], TESTS[2])] + [(PACKAGES[3], test) for test in TESTS[3:]]
ALLOCATION_TEST = 'TestResolveByPath_DoesNotCloneUnrelatedNestedRows'
SERENA_PACKAGE = 'mcp-local-hub/internal/api/serena_routing'
STRICT = {'MCPHUB_REQUIRE_SINGLE_USER_HOME': '1'}
ENVIRONMENT = {
    'GOENV': 'off', 'GOTOOLCHAIN': 'local', 'GOPROXY': 'off', 'GOSUMDB': 'off',
    'GOVCS': '*:off', 'GOWORK': 'off', 'GOFLAGS': '-mod=readonly', 'GOTELEMETRY': 'off',
    'GOMAXPROCS': '4', 'CGO_ENABLED': '1', 'MCPHUB_NO_AUTO_GUI': '1', 'MCPHUB_E2E_SCHEDULER': 'none',
}
PHASES = ('bootstrap', 'candidate', 'measurement', 'gates', 'published-checkout', 'published')
PROCESS_SCOPE = 'exact owned-root marker in executable path or command line; no ancestry closure'
PROCESS_ROOT_LABELS = ['go-state-isolation', 'native-exec-diagnostic',
                       'native-existing-candidates', 'native-negative-read']
OUTPUTS = ('execution-summary.json', 'evidence-redacted.zip', 'archive-metadata.json',
           'evidence-redacted.base64.txt')
raw_files = {}
stream_checks = {}
go_analysis = {}
json_line_logs = set()


class EvidenceError(Exception):
    pass


def need(condition, label):
    if not condition:
        raise EvidenceError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def integer(value, expected=None):
    return type(value) is int and (expected is None or value == expected)


def ordinary(path, directory=False):
    info = path.lstat()
    predicate = stat.S_ISDIR if directory else stat.S_ISREG
    need(predicate(info.st_mode) and not info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT,
         'nonordinary_input_path')


def read_uncached(name):
    relative = PurePosixPath(name)
    need(not relative.is_absolute() and relative.as_posix() == name and '..' not in relative.parts
         and not any(char in name for char in ('\\', ':', '\x00')), 'invalid_relative_input')
    path = ROOT
    ordinary(path, True)
    for index, part in enumerate(relative.parts):
        path /= part
        ordinary(path, index < len(relative.parts) - 1)
    return path.read_bytes()


def read(name):
    if name not in raw_files:
        raw_files[name] = read_uncached(name)
    return raw_files[name]


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def reject_constant(_):
    raise EvidenceError('nonfinite_json_number')


def parse(data):
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def load(name):
    value = parse(read(name))
    need(type(value) is dict, 'json_object_required: ' + name)
    return value


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def instant(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.utcoffset() is not None, 'timestamp_without_timezone')
    return result


def wait_for_published(seconds):
    deadline = time.monotonic() + seconds
    announced = False
    while True:
        try:
            value = parse(read_uncached('evidence/published/receipt.json'))
            if type(value) is dict and value.get('completed') is True:
                need(value.get('phase') == 'published' and value.get('expected_head') == HEAD
                     and value.get('head_after') == HEAD, 'published_identity_mismatch')
                return
        except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
            pass  # A live receipt may be absent or between complete writes.
        need(time.monotonic() < deadline, 'published_not_completed_within_wait')
        if not announced:
            print(json.dumps({'packaged': False, 'state': 'waiting_for_completed_published'}), flush=True)
            announced = True
        time.sleep(min(2, max(0, deadline - time.monotonic())))


def check_stream(name, record, stream):
    data = read(name)
    need(record[stream + '_sha256'] == sha(data), 'stream_hash: ' + name)
    need(integer(record[stream + '_bytes'], len(data)), 'stream_size: ' + name)
    stream_checks[name] = {'source_sha256': sha(data), 'source_bytes': len(data)}
    return data


def check_commands(phase, receipt, specs):
    commands = receipt['commands']
    need(type(commands) is list and [item['name'] for item in commands] == [spec[0] for spec in specs],
         'command_order: ' + phase)
    start, finish = instant(receipt['started_utc']), instant(receipt['finished_utc'])
    need(start <= finish, 'phase_time: ' + phase)
    previous = start
    expected_logs = set()
    for record, (name, executable, arguments, delta, expected_exit) in zip(commands, specs):
        need(record['arguments'] == arguments, 'command_arguments: ' + phase + '/' + name)
        if executable is not None:
            need(record['executable'] == executable and record['environment_delta'] == delta,
                 'command_executable_or_environment: ' + phase + '/' + name)
        need(record['settled'] is True and integer(record['exit_code'])
             and not record.get('direct_child_deadline_hit')
             and (expected_exit is None or record['exit_code'] == expected_exit),
             'command_settlement_or_exit: ' + phase + '/' + name)
        need(integer(record['pid']) and record['pid'] > 0, 'command_pid')
        need(type(record['seconds']) in (int, float) and math.isfinite(record['seconds'])
             and record['seconds'] >= 0, 'command_duration')
        command_start = instant(record['started_utc'])
        need(previous <= command_start <= finish, 'command_time')
        previous = command_start
        deadline = 90 if phase == 'published-checkout' else 900 if arguments[0] == 'test' else 180
        need(integer(record['direct_child_deadline_seconds'], deadline), 'command_deadline')
        for stream in ('stdout', 'stderr'):
            filename = name + '.' + stream + '.log'
            expected_logs.add(filename)
            check_stream('evidence/' + phase + '/' + filename, record, stream)
        if arguments[0] == 'test':
            check_go(phase, record)
    actual = {path.name for path in (ROOT / 'evidence' / phase).glob('*.log')}
    need(actual == expected_logs, 'unexpected_or_missing_phase_log: ' + phase)


def check_go(phase, record):
    label = phase + '/' + record['name']
    raw = read('evidence/' + phase + '/' + record['name'] + '.stdout.log')
    text = raw.decode('utf-8', errors='replace')
    timeouts = re.findall(r'panic: test timed out after ([^\r\n]+)', text)
    need(record['timeouts'] == timeouts, 'timeout_diagnostics_differ: ' + label)
    if '-json' not in record['arguments']:
        diagnostics = {
            'failed_packages': re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)', text, re.M),
            'failed_tests': re.findall(r'^--- FAIL: ([^ (]+)', text, re.M),
            'timeouts': timeouts,
        }
        need(all(record[key] == value for key, value in diagnostics.items()), 'gate_diagnostics_differ: ' + label)
        go_analysis[label] = diagnostics
        return
    json_line_logs.add('evidence/' + phase + '/' + record['name'] + '.stdout.log')
    events = [parse(line) for line in raw.splitlines()]
    need(all(type(event) is dict for event in events), 'go_event_object')
    tests = {action: [event.get('Test', 'PACKAGE:' + event.get('Package', ''))
                      for event in events if event.get('Action') == action]
             for action in ('pass', 'fail', 'skip')}
    pairs = [[event.get('Package'), event.get('Test')] for event in events
             if event.get('Action') == 'pass' and event.get('Test')]
    need(tests == record['tests'] and pairs == record['package_test_passes'], 'go_receipt_lists_differ: ' + label)
    active, runs, terminals = set(), Counter(), Counter()
    for event in events:
        key = (event.get('Package'), event.get('Test'))
        action = event.get('Action')
        if not key[1]:
            continue
        if action == 'run':
            need(key not in active, 'duplicate_active_go_test')
            active.add(key)
            runs[key] += 1
        elif action in tests:
            need(key in active, 'go_terminal_without_run')
            active.remove(key)
            terminals[key] += 1
    diagnostics = ''.join(event.get('Output', '') for event in events)
    go_analysis[label] = {
        'test_pass': sum(not item.startswith('PACKAGE:') for item in tests['pass']),
        'test_fail': sum(not item.startswith('PACKAGE:') for item in tests['fail']),
        'test_skip': sum(not item.startswith('PACKAGE:') for item in tests['skip']),
        'package_pass': [item[8:] for item in tests['pass'] if item.startswith('PACKAGE:')],
        'package_fail': [item[8:] for item in tests['fail'] if item.startswith('PACKAGE:')],
        'package_skip': [item[8:] for item in tests['skip'] if item.startswith('PACKAGE:')],
        'all_test_runs_have_terminal_events': not active and runs == terminals,
        'active_tests': sorted([list(key) for key in active]),
        'panic_or_race': any(marker in diagnostics for marker in
                             ('panic:', 'fatal error:', 'WARNING: DATA RACE', 'race detected during execution of test')),
    }
    if label == 'measurement/clone-all-negative-control':
        need(record['exit_code'] == 1 and integer(record.get('expected_exit_code'), 1)
             and record.get('semantic_expected_failure_pass') is True
             and Counter(tests['fail']) == Counter([ALLOCATION_TEST, 'PACKAGE:' + SERENA_PACKAGE])
             and not tests['skip'] and not timeouts and not record['stderr_bytes']
             and not go_analysis[label]['panic_or_race']
             and go_analysis[label]['all_test_runs_have_terminal_events']
             and any(event.get('Test') == ALLOCATION_TEST
                     and 'single-row lookup allocations grew from ' in event.get('Output', '') for event in events),
             'negative_control_not_the_allocation_assertion')
    else:
        need('expected_exit_code' not in record and 'semantic_expected_failure_pass' not in record,
             'unexpected_semantic_failure_override')


def require_positive(phase, record, targets, packages, allow_skips=False):
    analysis = go_analysis[phase + '/' + record['name']]
    need(record['exit_code'] == 0 and not record['tests']['fail'] and not record['timeouts']
         and (allow_skips or not record['tests']['skip']) and not record['stderr_bytes']
         and analysis['all_test_runs_have_terminal_events'] and not analysis['panic_or_race'],
         'positive_test_result: ' + phase + '/' + record['name'])
    need(all(record['package_test_passes'].count([package, test]) == count
             for package, test, count in targets), 'positive_test_count')
    need(Counter(analysis['package_pass']) == Counter(packages), 'positive_package_count')


def check_manifest(name):
    manifest = load(name)
    need(manifest['base'] == BASE and type(manifest['files']) is list, 'manifest_base_or_files')
    files = manifest['files']
    need(len(files) == len(EXPECTED_FILES) and {item['path'] for item in files} == EXPECTED_FILES,
         'manifest_exact_twelve_test_files')
    for item in files:
        need(set(item) == {'path', 'base_blob', 'sha256', 'bytes'}
             and re.fullmatch('[0-9a-f]{64}', item['sha256']) is not None
             and integer(item['bytes']) and item['bytes'] >= 0
             and (item['base_blob'] is None or re.fullmatch('[0-9a-f]{40}', item['base_blob']) is not None),
             'manifest_file_record')
    return files


def check_phase(phase, specs, files=None):
    value = load('evidence/' + phase + '/receipt.json')
    expected = HEAD if phase == 'published' else BASE
    need(value['phase'] == phase and value.get('completed') is True
         and value['base'] == BASE and value['expected_head'] == expected
         and value['head_after'] == expected, 'phase_completion_or_head: ' + phase)
    need(value['tree_after'] == (TREE if phase == 'published' else BASE_TREE), 'phase_tree: ' + phase)
    if phase in ('bootstrap', 'published'):
        need(value['status_after'] == '', 'phase_not_clean: ' + phase)
    else:
        expected_status = sorted(('M  ' if item['base_blob'] else 'A  ') + item['path'] for item in files)
        need(sorted(value['status_after'].splitlines()) == expected_status, 'phase_staged_scope: ' + phase)
        need(re.fullmatch('[0-9a-f]{40}', value['candidate_tree']) is not None, 'candidate_tree_id')
        if phase in ('measurement', 'gates'):
            need(value['candidate_tree'] == TREE, 'revised_candidate_tree')
    runner = ('history/run_checks-bootstrap.py' if phase == 'bootstrap' else
              'history/run_checks-candidate.py' if phase == 'candidate' else 'run_checks.py')
    need(value['runner_sha256'] == SOURCE_PINS[runner] and value['environment'] == ENVIRONMENT
         and value['native_lifecycle_opt_in_present'] is False
         and value['whole_process_tree_deadline_enforced'] is False, 'phase_runner_or_environment: ' + phase)
    if phase != 'bootstrap':
        manifest = 'candidate-manifest.json' if phase == 'candidate' else 'candidate-manifest-v2.json'
        need(value['manifest_sha256'] == SOURCE_PINS[manifest], 'phase_manifest: ' + phase)
    check_commands(phase, value, specs)
    passed = all(command['exit_code'] == (1 if command['name'] == 'clone-all-negative-control' else 0)
                 for command in value['commands'])
    need(value['checks_passed'] is passed and value['overall'] == ('PASS' if passed else 'FAIL'),
         'completed_is_not_passed: ' + phase)
    return value


def validate():
    for name, expected in SOURCE_PINS.items():
        need(sha(read(name)) == expected, 'source_pin: ' + name)
    original = check_manifest('candidate-manifest.json')
    revised = check_manifest('candidate-manifest-v2.json')
    original_by_path = {item['path']: item for item in original}
    need([item['path'] for item in revised if item != original_by_path[item['path']]] == [SERENA_TEST]
         and all(item['base_blob'] == original_by_path[item['path']]['base_blob'] for item in revised),
         'measurement_revision_scope')
    archive_inputs = {name: name for name in SOURCE_PINS}
    archive_inputs.update({name: name for name in ('package_evidence.py', 'observe_owned_processes.py')})
    for item in revised:
        source = 'source/' + item['path']
        data = read(source)
        need(sha(data) == item['sha256'] and len(data) == item['bytes'], 'current_test_source: ' + item['path'])
        archive_inputs['candidate-current/' + item['path']] = source
    old_source = 'candidate/' + SERENA_TEST
    old = read(old_source)
    need(sha(old) == original_by_path[SERENA_TEST]['sha256']
         and len(old) == original_by_path[SERENA_TEST]['bytes'], 'original_candidate_serena_source')
    archive_inputs['history/candidate-serena-v1_test.go'] = old_source
    need(sha(read('mutation/resolver.go')) == MUTANT, 'mutant_source')
    archive_inputs['mutation/resolver.go'] = 'mutation/resolver.go'
    need(sha(read('source/' + PRODUCT)) == ORIGINAL_PRODUCT, 'published_product_restoration')
    source_path = str(ROOT / 'source')
    focused = ['test', '-json', '-race', '-count=2', '-timeout=180s', '-run', FOCUSED, *PACKAGES]
    allocation = ['test', '-json', '-race', '-count=2', '-timeout=180s',
                  '-run', '^' + ALLOCATION_TEST + '$', './internal/api/serena_routing']
    bootstrap = check_phase('bootstrap', [
        ('clone', 'git.exe', ['-c', 'core.autocrlf=false', 'clone', '--local', '--no-hardlinks',
                             '--no-checkout', OLD, source_path], {}, 0),
        ('fetch', 'git.exe', ['-C', source_path, 'fetch', '--no-tags', REPOSITORY, BASE], {}, 0),
        ('go-version', 'go.exe', ['version'], {}, 0),
    ])
    need(re.fullmatch(rb'go version go[0-9][^\r\n]* windows/amd64\r?\n',
                      read('evidence/bootstrap/go-version.stdout.log')) is not None, 'go_version_platform')
    candidate = check_phase('candidate', [
        ('gofmt-check', 'gofmt.exe', ['-l', *[item['path'] for item in original]], {}, 0),
        ('focused-race', 'go.exe', focused, {}, 0),
        ('focused-strict-race', 'go.exe', focused, STRICT, 0),
        ('packages-race', 'go.exe', ['test', '-json', '-race', '-count=1', '-timeout=180s', *PACKAGES], {}, None),
    ], original)
    need(candidate['applied_paths'] == [item['path'] for item in original], 'candidate_applied_paths')
    measurement = check_phase('measurement', [
        ('gofmt-measurement', 'gofmt.exe', ['-l', SERENA_TEST], {}, 0),
        ('paired-allocation-race', 'go.exe', allocation, STRICT, 0),
        ('clone-all-negative-control', 'go.exe',
         ['test', '-json', '-race', '-count=1', '-timeout=180s', '-run', '^' + ALLOCATION_TEST + '$',
          './internal/api/serena_routing'], STRICT, 1),
        ('restored-serena-strict-race', 'go.exe',
         ['test', '-json', '-race', '-count=1', '-timeout=180s', './internal/api/serena_routing'], STRICT, 0),
    ], revised)
    need(measurement['applied_paths'] == [SERENA_TEST]
         and measurement['previous_candidate_tree'] == candidate['candidate_tree']
         and measurement['mutation'] == {'path': PRODUCT, 'original_sha256': ORIGINAL_PRODUCT,
                                         'mutant_sha256': MUTANT, 'restored': True, 'oracle_sensitive': True},
         'measurement_mutation_or_restoration_binding')
    gates = check_phase('gates', [
        ('build', 'go.exe', ['build', './...'], {}, None),
        ('vet', 'go.exe', ['vet', './...'], {}, None),
        ('full-test', 'go.exe', ['test', '-count=1', '-timeout', '5m', './...'], {}, None),
        ('tagged-api-cli', 'go.exe', ['test', '-tags=test_state_path_env', '-count=1', '-timeout', '5m',
                                    './internal/api/', './internal/cli/'], {}, None),
    ], revised)
    checkout = load('evidence/published-checkout/receipt.json')
    need(checkout['phase'] == 'published-checkout' and checkout.get('completed') is True
         and checkout['previous_head'] == BASE and checkout['expected_head'] == checkout['head'] == HEAD
         and checkout['expected_tree'] == checkout['prepared_tree'] == checkout['tree'] == TREE
         and checkout['parents'] == [BASE] and checkout['status'] == ''
         and checkout['whole_process_tree_deadline_enforced'] is False
         and checkout['script_sha256'] == SOURCE_PINS['checkout_published.py'], 'published_checkout_binding')
    check_commands('published-checkout', checkout, [
        ('fetch', None, ['fetch', '--no-tags', REPOSITORY, HEAD], None, 0),
        ('checkout', None, ['checkout', '--detach', HEAD], None, 0),
    ])
    published = check_phase('published', [
        ('published-focused-strict-race', 'go.exe', focused, STRICT, 0),
        ('published-paired-allocation-strict-race', 'go.exe', allocation, STRICT, 0),
    ], revised)
    for phase, name in (('candidate', 'gofmt-check'), ('measurement', 'gofmt-measurement')):
        need(read('evidence/' + phase + '/' + name + '.stdout.log') ==
             read('evidence/' + phase + '/' + name + '.stderr.log') == b'', 'formatting_output')
    target_counts = [('mcp-local-hub/' + package[2:], test, 2) for package, test in TARGETS]
    package_names = ['mcp-local-hub/' + package[2:] for package in PACKAGES]
    for record in candidate['commands'][1:3]:
        require_positive('candidate', record, target_counts, package_names)
    require_positive('published', published['commands'][0], target_counts, package_names)
    require_positive('measurement', measurement['commands'][1], [(SERENA_PACKAGE, ALLOCATION_TEST, 2)], [SERENA_PACKAGE])
    require_positive('measurement', measurement['commands'][3], [(SERENA_PACKAGE, ALLOCATION_TEST, 1)],
                     [SERENA_PACKAGE], allow_skips=True)
    require_positive('published', published['commands'][1], [(SERENA_PACKAGE, ALLOCATION_TEST, 2)], [SERENA_PACKAGE])
    phases = [bootstrap, candidate, measurement, gates, checkout, published]
    post = load('post-verify/receipt.json')
    need(post['phase'] == 'post-verify' and post.get('completed') is True and post['expected_head'] == HEAD
         and post['script_sha256'] == sha(read('observe_owned_processes.py'))
         and post['settled'] is True and integer(post['exit_code'], 0)
         and not post.get('direct_child_deadline_hit') and integer(post['direct_child_deadline_seconds'], 30)
         and post['whole_process_tree_proven'] is False and post['observed_processes_modified'] is False,
         'post_verify_receipt')
    observation = parse(check_stream('post-verify/stdout.log', post, 'stdout'))
    json_line_logs.add('post-verify/stdout.log')
    need(check_stream('post-verify/stderr.log', post, 'stderr') == b'' and observation == post['observation'],
         'post_verify_stream_binding')
    need(set(observation) == {'observed_utc', 'observer_pid', 'excluded_pids', 'remaining', 'root_labels',
                             'scope', 'command_lines_or_images_emitted', 'whole_process_tree_proven'}
         and observation['scope'] == PROCESS_SCOPE and observation['root_labels'] == PROCESS_ROOT_LABELS
         and observation['command_lines_or_images_emitted'] is False
         and observation['whole_process_tree_proven'] is False
         and integer(observation['observer_pid'], post['pid']) and integer(post['pid']) and post['pid'] > 0,
         'post_verify_scope')
    excluded, remaining = observation['excluded_pids'], observation['remaining']
    need(type(excluded) is list and len(excluded) == len(set(excluded)) == 3 and excluded[0] == post['pid']
         and all(integer(pid) and pid > 0 for pid in excluded) and type(remaining) is list, 'post_verify_exclusions')
    for process in remaining:
        need(set(process) == {'pid', 'parent_pid', 'root_labels', 'created_utc'}
             and integer(process['pid']) and process['pid'] > 0 and process['pid'] not in excluded
             and integer(process['parent_pid']) and process['parent_pid'] >= 0
             and type(process['root_labels']) is list and bool(process['root_labels'])
             and set(process['root_labels']) <= set(PROCESS_ROOT_LABELS), 'post_verify_process_shape')
        if process['created_utc'] is not None:
            instant(process['created_utc'])
    need(len({process['pid'] for process in remaining}) == len(remaining), 'duplicate_remaining_pid')
    absence = not remaining
    need(post['scoped_absence_observed'] is absence
         and post['overall'] == ('ABSENCE_OBSERVED' if absence else 'MATCHES_OBSERVED'), 'post_verify_outcome')
    for previous, following in zip(phases, phases[1:] + [post]):
        need(instant(previous['finished_utc']) <= instant(following['started_utc']), 'phase_chronology')
    need(instant(post['started_utc']) <= instant(observation['observed_utc']) <= instant(post['finished_utc']),
         'post_verify_time')
    for phase in PHASES:
        name = 'evidence/' + phase + '/receipt.json'
        archive_inputs[name] = name
    archive_inputs.update({name: name for name in stream_checks})
    archive_inputs['post-verify/receipt.json'] = 'post-verify/receipt.json'
    return phases, post, archive_inputs


def invalid_bytes(data):
    return bytes(ord(char) - 0xDC00 for char in data.decode('utf-8', errors='surrogateescape')
                 if 0xDC80 <= ord(char) <= 0xDCFF)


def redactor():
    replacements = [
        (str(ROOT), '<WORK_ROOT>'), (OLD, '<PREVIOUS_SOURCE>'),
        (r'<NATIVE_EXEC_DIAGNOSTIC_ROOT>', '<NATIVE_EXEC_DIAGNOSTIC_ROOT>'),
        (r'<NATIVE_OBSERVATION_ROOT>', '<NATIVE_OBSERVATION_ROOT>'),
        (r'<NATIVE_NEGATIVE_READ_ROOT>', '<NATIVE_NEGATIVE_READ_ROOT>'),
        (r'<GO_CACHE_ROOT>', '<GO_CACHE_ROOT>'),
        (r'<GO_ROOT>', '<GO_ROOT>'), (r'<GO_BIN>', '<GO_BIN>'),
        (r'<GIT_EXECUTABLE>', '<GIT_EXECUTABLE>'),
        (r'<OWNED_WORK_ROOT>', '<OWNED_WORK_ROOT>'), (r'<LOCAL_PIPE>', '<LOCAL_PIPE>'),
    ]
    replacements.extend((value, '<MACHINE_DIRECTORY>') for key in ('USERPROFILE', 'SYSTEMROOT', 'WINDIR')
                        if (value := os.environ.get(key)))
    identities = {value for key in ('USERNAME', 'USERDOMAIN', 'COMPUTERNAME') if (value := os.environ.get(key))}

    def variants(value):
        return {value, value.replace('\\', '/'), value.replace('\\', '\\\\'),
                json.dumps(value, ensure_ascii=True)[1:-1]}

    identity_patterns = [r'(?<!\w)' + re.escape(value) + r'(?!\w)'
                         for old in sorted(identities, key=len, reverse=True)
                         for value in sorted(variants(old), key=len, reverse=True)]
    placeholder, number = '<REDACTED_0>', 0
    while any(re.search(pattern, placeholder, re.I) for pattern in identity_patterns):
        number += 1
        placeholder = '<REDACTED_' + str(number) + '>'
    absolute_path = r'\b[A-Za-z]:[\\/]+[^\s"\'<>]*'
    unc_path = r'(?<!\\)\\\\+[A-Za-z0-9_.-]+[\\/][^\s"\'<>]*'

    def text(value):
        for old, replacement in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
            for spelling in sorted(variants(old), key=len, reverse=True):
                value = re.sub(re.escape(spelling), lambda _: replacement, value, flags=re.I)
        # A path may itself contain undecodable bytes. Remove its readable
        # spelling while retaining those bytes in order for the encoding audit.
        def redact_path(match, replacement):
            return replacement + ''.join(char for char in match.group() if 0xDC80 <= ord(char) <= 0xDCFF)
        value = re.sub(absolute_path, lambda match: redact_path(match, '<ABSOLUTE_PATH>'), value)
        value = re.sub(unc_path, lambda match: redact_path(match, '<UNC_PATH>'), value)
        for pattern in identity_patterns:
            value = re.sub(pattern, lambda _: placeholder, value, flags=re.I)
        return re.sub(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', '<USER_SID>', value)

    def obj(value):
        if isinstance(value, str):
            return text(value)
        if isinstance(value, list):
            return [obj(item) for item in value]
        if isinstance(value, dict):
            changed = {text(key): obj(item) for key, item in value.items()}
            need(len(changed) == len(value), 'json_redaction_key_collision')
            return changed
        return value

    def saved(name, data):
        if name.endswith('.json'):
            return json_bytes(obj(parse(data)))
        if name in json_line_logs:
            # Redact JSON values, not their escape syntax: Go JSON log lines
            # must remain independently parseable after path replacement.
            return b''.join((json.dumps(obj(parse(line)), ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')
                            for line in data.splitlines())
        if name.endswith('.log'):
            result = text(data.decode('utf-8', errors='surrogateescape')).encode('utf-8', errors='surrogateescape')
            need(invalid_bytes(result) == invalid_bytes(data), 'invalid_bytes_changed_by_redaction: ' + name)
            return result
        return text(data.decode('utf-8-sig')).encode('utf-8')

    def scan(data, name):
        value = data.decode('utf-8', errors='surrogateescape' if name.endswith('.log') else 'strict')
        need(not any(re.search(pattern, value, re.I) for pattern in identity_patterns), 'private_identity_remains')
        need(not re.search(r'\b[A-Za-z]:[\\/]+', value) and not re.search(unc_path, value), 'absolute_path_remains')
        need(not re.search(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', value), 'user_sid_remains')
        for pattern in (
            rb'\bgh[pousr]_[A-Za-z0-9]{16,}', rb'\bgithub_pat_[A-Za-z0-9_]{16,}',
            rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}', rb'\bxox[baprs]-[A-Za-z0-9-]{16,}',
            rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}', rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
            rb'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
        ):
            need(re.search(pattern, data) is None, 'credential_shaped_content')
    return saved, scan


def main():
    need(not sys.flags.optimize and os.name == 'nt', 'nonoptimized_windows_required')
    args = sys.argv[1:]
    need(len(args) in (1, 3) and args[0] == HEAD, 'exact_published_commit_required')
    wait_seconds = 900
    if len(args) == 3:
        need(args[1] == '--wait-seconds' and args[2].isdigit(), 'invalid_wait_argument')
        wait_seconds = int(args[2])
    need(0 <= wait_seconds <= 3600, 'wait_out_of_range')
    ordinary(ROOT, True)
    need(not any(os.path.lexists(ROOT / name) for name in OUTPUTS), 'output_already_exists')
    wait_for_published(wait_seconds)
    phases, post, inputs = validate()
    gates = next(phase for phase in phases if phase['phase'] == 'gates')
    summary = {
        'schema': 1, 'evidence_validation': 'PASS', 'mode': 'saved_files_only',
        'base': BASE, 'base_tree': BASE_TREE, 'candidate_tree': TREE, 'head': HEAD,
        'verified_utc': datetime.now(timezone.utc).isoformat(), 'changed_test_files': sorted(EXPECTED_FILES),
        'published_product_source_sha256': ORIGINAL_PRODUCT,
        'product_code_changed_in_published_candidate': False,
        'temporary_mutation_restored': True, 'mutation_expected_assertion_observed': True,
        'all_mandatory_commands_passed': all(command['exit_code'] == 0 for command in gates['commands']),
        'phases': {phase['phase']: phase for phase in phases}, 'go_analysis': go_analysis,
        'post_verify': post, 'stream_checks': stream_checks,
        'source_sha256': {name: sha(read(name)) for name in inputs.values() if not name.endswith('.log')},
        'all_recorded_direct_children_settled': True,
        'whole_process_tree_proven': False, 'whole_process_tree_deadline_enforced': False,
        'packager_process_or_git_calls': False, 'native_private_evidence_included': False,
        'limitations': [
            'Evidence integrity PASS does not mean mandatory gates or every phase passed; all original failures remain.',
            'The initial candidate package failure is retained separately from the revised measurement and published checks.',
            'The allocation mutation is an expected failing assertion, not a successful product test.',
            'Commit/tree/index checks come from saved runner receipts; this packager does not invoke Git.',
            'The twelve final test files and restored production resolver are additionally checked against exact raw hashes.',
            'Process absence is a later snapshot of accessible exact-root markers, not an ancestry-complete process-tree proof.',
            'Native private candidates, identities, XML, and arguments are excluded; native public evidence is packaged separately.',
            'Archive sources are sanitized review copies; source hashes identify original bytes, saved hashes identify archive bytes.',
            'Unstructured logs preserve undecodable UTF-8 bytes through surrogateescape; their origin is not established.',
            'Identity/path redaction and credential-shape scans are bounded checks, not a proof that arbitrary secrets cannot exist.',
        ],
    }
    originals = {name: read(source) for name, source in inputs.items()}
    originals['execution-summary.json'] = json_bytes(summary)
    saved, scan = redactor()
    members = {}
    manifest = {'schema': 1, 'base': BASE, 'head': HEAD, 'candidate_tree': TREE, 'files': [],
                'redaction': 'source_sha256/source_bytes describe raw inputs; saved_sha256/saved_bytes describe sanitized members'}
    for name in sorted(originals):
        raw = originals[name]
        sanitized = saved(name, raw)
        scan(sanitized, name)
        members[name] = sanitized
        entry = {'path': name, 'origin': 'generated' if name == 'execution-summary.json' else 'saved_evidence',
                 'source_path': inputs.get(name), 'source_sha256': sha(raw), 'source_bytes': len(raw),
                 'saved_sha256': sha(sanitized), 'saved_bytes': len(sanitized)}
        if name.endswith('.log') and invalid_bytes(raw):
            entry['encoding'] = {'decode_encode': 'utf-8 with surrogateescape',
                                 'source_invalid_byte_count': len(invalid_bytes(raw)),
                                 'saved_invalid_byte_count': len(invalid_bytes(sanitized)),
                                 'invalid_byte_sequence_preserved': True,
                                 'invalid_byte_sequence_sha256': sha(invalid_bytes(raw))}
        manifest['files'].append(entry)
    members['MANIFEST.json'] = json_bytes(manifest)
    scan(members['MANIFEST.json'], 'MANIFEST.json')
    for name, original in raw_files.items():
        need(read_uncached(name) == original, 'input_changed_during_packaging: ' + name)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    archive_data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
        need(archive.namelist() == list(members), 'archive_member_mismatch')
        need(all(archive.read(name) == data for name, data in members.items()), 'archive_byte_mismatch')
    encoded = base64.b64encode(archive_data).decode('ascii')
    base64_data = ('\n'.join(encoded[index:index + 4096] for index in range(0, len(encoded), 4096)) + '\n').encode('ascii')
    metadata = {
        'base': BASE, 'head': HEAD, 'candidate_tree': TREE, 'archive_file': 'evidence-redacted.zip',
        'archive_sha256': sha(archive_data), 'archive_bytes': len(archive_data), 'archive_members': len(members),
        'manifest_files': len(manifest['files']), 'manifest_sha256': sha(members['MANIFEST.json']),
        'summary_sha256': sha(members['execution-summary.json']), 'base64_file': 'evidence-redacted.base64.txt',
        'base64_sha256': sha(base64_data), 'base64_bytes': len(base64_data), 'base64_lines': len(base64_data.splitlines()),
        'base64_chunk_characters': 4096, 'credential_shape_scan': 'PASS',
        'all_mandatory_commands_passed': summary['all_mandatory_commands_passed'],
        'scoped_absence_observed': post['scoped_absence_observed'],
    }
    scan(json_bytes(metadata), 'archive-metadata.json')
    outputs = {'execution-summary.json': members['execution-summary.json'], 'evidence-redacted.zip': archive_data,
               'archive-metadata.json': json_bytes(metadata), 'evidence-redacted.base64.txt': base64_data}
    need(not any(os.path.lexists(ROOT / name) for name in OUTPUTS), 'output_created_during_validation')
    for name, data in outputs.items():
        with (ROOT / name).open('xb') as output:
            output.write(data)
    print(json.dumps(metadata), flush=True)


if __name__ == '__main__':
    try:
        main()
    except EvidenceError as error:
        print(json.dumps({'packaged': False, 'error_category': 'evidence_validation', 'detail': str(error)}), flush=True)
        raise SystemExit(1)
    except Exception as error:
        print(json.dumps({'packaged': False, 'error_category': type(error).__name__}), flush=True)
        raise SystemExit(1)
