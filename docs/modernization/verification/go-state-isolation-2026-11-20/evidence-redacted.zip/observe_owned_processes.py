"""Observe exact owned-root process markers after the published Go checks.

Usage: python observe_owned_processes.py post-verify
Reads CIM only. It never stops a matched process. On a deadline it may terminate
only the diagnostic child retained by this invocation; that is INCOMPLETE.
Raw command lines and image paths are used for matching but are never emitted.
Outputs are exclusive; an earlier attempt is never overwritten or removed.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

ROOT = Path(r'<WORK_ROOT>')
EXPECTED_HEAD = '2cb467aac31259ed4fb665ed0a4f277a8f9c31a2'
OWNED_ROOTS = {
    'go-state-isolation': str(ROOT),
    'native-exec-diagnostic': r'<NATIVE_EXEC_DIAGNOSTIC_ROOT>',
    'native-existing-candidates': r'<NATIVE_OBSERVATION_ROOT>',
    'native-negative-read': r'<NATIVE_NEGATIVE_READ_ROOT>',
}
SCOPE = 'exact owned-root marker in executable path or command line; no ancestry closure'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    expected = stat.S_ISDIR if directory else stat.S_ISREG
    if not expected(info.st_mode) or info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError('Expected an ordinary task-owned path')


def main():
    if sys.flags.optimize or os.name != 'nt':
        raise RuntimeError('Nonoptimized Windows Python is required')
    if sys.argv[1:] != ['post-verify']:
        raise RuntimeError('Expected the post-verify phase')
    ordinary(ROOT, True)
    ordinary(ROOT / 'evidence', True)
    ordinary(ROOT / 'evidence/published', True)
    ordinary(ROOT / 'evidence/published/receipt.json')
    published = json.loads((ROOT / 'evidence/published/receipt.json').read_text(encoding='utf-8-sig'))
    if (published.get('phase') != 'published' or published.get('completed') is not True
            or published.get('expected_head') != EXPECTED_HEAD
            or published.get('head_after') != EXPECTED_HEAD):
        raise RuntimeError('Published checks must be completed before this snapshot')
    out = ROOT / 'post-verify'
    out.mkdir(exist_ok=False)
    ordinary(ROOT / 'runtime', True)
    runtime = ROOT / 'runtime/post-verify'
    runtime.mkdir(exist_ok=False)
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith(('MCPHUB_', 'GIT_'))}
    for name in ('tmp', 'profile', 'appdata', 'localappdata'):
        (runtime / name).mkdir(exist_ok=False)
    for key, name in (('USERPROFILE', 'profile'), ('APPDATA', 'appdata'),
                      ('LOCALAPPDATA', 'localappdata'), ('TEMP', 'tmp'),
                      ('TMP', 'tmp'), ('TMPDIR', 'tmp')):
        env[key] = str(runtime / name)
    env['PSModuleAnalysisCachePath'] = str(runtime / 'localappdata/module-analysis-cache')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
    ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    env['PATH'] = os.pathsep.join((str(ps.parent), str(system / 'System32')))

    def literal(value):
        return "'" + value.replace("'", "''") + "'"

    root_table = '; '.join(literal(key) + '=' + literal(value) for key, value in OWNED_ROOTS.items())
    code = r"""$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
try {
    $roots = @{__ROOTS__}
    $ignore = @($PID, __PYTHON_PID__, __PARENT_PID__)
    $filterParts = @()
    foreach ($marker in $roots.Values) {
        $leaf = [IO.Path]::GetFileName($marker)
        $filterParts += "CommandLine LIKE '%$leaf%' OR ExecutablePath LIKE '%$leaf%'"
    }
    $matched = @()
    $processes = @(Get-CimInstance -ClassName Win32_Process -Filter ($filterParts -join ' OR ') -OperationTimeoutSec 20)
    foreach ($process in $processes) {
        if ([int]$process.ProcessId -in $ignore) { continue }
        $image = ([string]$process.ExecutablePath).Replace('/', '\')
        $line = ([string]$process.CommandLine).Replace('/', '\')
        $labels = @()
        foreach ($label in $roots.Keys) {
            $marker = [string]$roots[$label]
            $imageMatch = $image.Equals($marker, [StringComparison]::OrdinalIgnoreCase) -or
                $image.StartsWith($marker + '\', [StringComparison]::OrdinalIgnoreCase)
            $pattern = '(?<![A-Za-z0-9_])' + [regex]::Escape($marker) + '(?=$|[\\/\s"'';])'
            $lineMatch = [regex]::IsMatch($line, $pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if ($imageMatch -or $lineMatch) { $labels += $label }
        }
        if ($labels.Count -eq 0) { continue }
        $created = $null
        if ($null -ne $process.CreationDate) { $created = $process.CreationDate.ToUniversalTime().ToString('o') }
        $matched += [pscustomobject]@{
            pid = [int]$process.ProcessId; parent_pid = [int]$process.ParentProcessId
            root_labels = @($labels | Sort-Object); created_utc = $created
        }
    }
    [pscustomobject]@{
        observed_utc = [DateTime]::UtcNow.ToString('o'); observer_pid = $PID
        excluded_pids = $ignore; remaining = @($matched | Sort-Object pid)
        root_labels = @($roots.Keys | Sort-Object)
        scope = 'exact owned-root marker in executable path or command line; no ancestry closure'
        command_lines_or_images_emitted = $false; whole_process_tree_proven = $false
    } | ConvertTo-Json -Compress -Depth 5
    exit 0
} catch {
    [Console]::Error.WriteLine('Scoped process observation failed')
    exit 1
}
""".replace('__ROOTS__', root_table).replace('__PYTHON_PID__', str(os.getpid())).replace('__PARENT_PID__', str(os.getppid()))
    receipt = {
        'phase': 'post-verify', 'started_utc': datetime.now(timezone.utc).isoformat(),
        'script_sha256': sha(Path(__file__).read_bytes()), 'query_sha256': sha(code.encode('utf-8')),
        'expected_head': EXPECTED_HEAD, 'direct_child_deadline_seconds': 30,
        'settled': False, 'completed': False, 'scoped_absence_observed': False,
        'whole_process_tree_proven': False, 'observed_processes_modified': False,
    }

    def save():
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

    # The directory itself was exclusively created above. These are new files
    # belonging to this attempt, not replacements for a prior observation.
    with (out / 'receipt.json').open('x', encoding='utf-8') as output:
        output.write(json.dumps(receipt, indent=2) + '\n')
    start = time.monotonic()
    try:
        with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
            child = subprocess.Popen([str(ps), '-NoProfile', '-NonInteractive', '-Command', code],
                                     env=env, cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, creationflags=0x08000000)
            try:
                receipt['pid'] = child.pid
                save()
                child.wait(timeout=max(0, 30 - (time.monotonic() - start)))
            except subprocess.TimeoutExpired:
                receipt['direct_child_deadline_hit'] = True
            finally:
                if child.poll() is None:
                    try:
                        child.wait(timeout=max(0, 30 - (time.monotonic() - start)))
                    except subprocess.TimeoutExpired:
                        receipt['direct_child_deadline_hit'] = True
                        child.kill()  # Only this retained diagnostic child.
                        child.wait(timeout=15)
                receipt['exit_code'] = child.returncode
                receipt['settled'] = child.returncode is not None
                save()
        for stream in ('stdout', 'stderr'):
            data = (out / (stream + '.log')).read_bytes()
            receipt[stream + '_bytes'] = len(data)
            receipt[stream + '_sha256'] = sha(data)
        if (receipt['exit_code'] == 0 and receipt['stderr_bytes'] == 0
                and not receipt.get('direct_child_deadline_hit')):
            observation = json.loads((out / 'stdout.log').read_bytes().decode('utf-8-sig'))
            if (observation.get('observer_pid') != receipt['pid']
                    or observation.get('scope') != SCOPE
                    or observation.get('root_labels') != sorted(OWNED_ROOTS)
                    or observation.get('excluded_pids') != [receipt['pid'], os.getpid(), os.getppid()]
                    or type(observation.get('remaining')) is not list
                    or observation.get('command_lines_or_images_emitted') is not False
                    or observation.get('whole_process_tree_proven') is not False):
                raise RuntimeError('Process observation binding failed')
            receipt['observation'] = observation
            receipt['scoped_absence_observed'] = not observation['remaining']
            receipt['completed'] = True
    finally:
        receipt['seconds'] = round(time.monotonic() - start, 6)
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        receipt['overall'] = ('ABSENCE_OBSERVED' if receipt['scoped_absence_observed'] else
                              'MATCHES_OBSERVED' if receipt['completed'] else 'INCOMPLETE')
        save()
    print(json.dumps({key: receipt[key] for key in (
        'phase', 'completed', 'overall', 'settled', 'scoped_absence_observed',
        'whole_process_tree_proven', 'observed_processes_modified')}), flush=True)
    return 0 if receipt['scoped_absence_observed'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({'phase': 'post-verify', 'completed': False,
                          'error_category': type(error).__name__}), flush=True)
        raise SystemExit(1)
