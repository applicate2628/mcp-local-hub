"""Exact-tree test-state validation; Go dependencies stay offline after Git fetch."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import subprocess
import sys
import time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')

BASE = '92f2d4350bfc22a5fa8099fd1b4ec199f9a19c22'
BASE_TREE = '52c4919ab291021b80e19b6550808ce8a0d93f23'
OLD_HEAD = '95f2c6df8d8883f009025d2196480cc54c8101af'
ROOT = Path(r'<WORK_ROOT>')
OLD = Path(r'<PREVIOUS_SOURCE>')
SOURCE = ROOT / 'source'
GO = Path(r'<GO_BIN>\go.exe')
GIT = Path(r'<GIT_EXECUTABLE>')
PACKAGES = ['./internal/api/lsp_routing', './internal/api/serena_routing',
            './internal/daemon', './internal/oneapirun']
EXPECTED_FILES = {
    'internal/api/lsp_routing/main_test.go',
    'internal/api/lsp_routing/resolver_test.go',
    'internal/api/serena_routing/main_test.go',
    'internal/api/serena_routing/resolver_test.go',
    'internal/api/serena_routing/shared_observer_public_test.go',
    'internal/daemon/host_original_windows_test.go',
    'internal/daemon/lazy_proxy_readiness_test.go',
    'internal/daemon/lazy_proxy_test.go',
    'internal/daemon/main_test.go',
    'internal/oneapirun/async_owner_test.go',
    'internal/oneapirun/async_test.go',
    'internal/oneapirun/main_test.go',
}
TESTS = [
    'TestResolveByPath_SameMtimeRegistryReplacementObservedWithin32Lookups',
    'TestResolveByPath_AbsoluteMatch',
    'TestLazyProxy_InitializeSyntheticNoMaterialize',
    'TestAsyncRun_PersistsAndReloadsCappedNonUTF8Output',
    'TestAsyncRun_LoadsLegacyExpandedTextIntoSamePathBase64',
    'TestAsyncRun_CloseConcurrentCallersWaitForDeferredWorkerAndRetryLeaseUnlock',
    'TestAsyncRun_CloseWaitsForEvictedTerminalWorker',
    'TestRunInOneAPIEnvTool_StartReturnsAcceptedReceipt',
]
FOCUSED = '^(' + '|'.join(TESTS) + ')$'
TARGETS = [(PACKAGES[0], TESTS[0]), (PACKAGES[1], TESTS[1]),
           (PACKAGES[2], TESTS[2])] + [(PACKAGES[3], t) for t in TESTS[3:]]
phase = sys.argv[1]
if phase not in {'bootstrap', 'candidate', 'measurement', 'gates', 'published'}:
    raise SystemExit('Unknown phase')
expected = sys.argv[2] if phase == 'published' else BASE
out = ROOT / 'evidence' / phase
out.mkdir(parents=True, exist_ok=False)
runtime = ROOT / 'runtime' / phase
for name in ('tmp', 'profile', 'appdata', 'localappdata', 'gopath', 'empty-hooks'):
    (runtime / name).mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items()
       if not k.upper().startswith(('MCPHUB_', 'GIT_'))}
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env.update({
    'GOROOT': r'<GO_ROOT>', 'GOENV': 'off',
    'GOTOOLCHAIN': 'local', 'GOPROXY': 'off', 'GOSUMDB': 'off',
    'GOVCS': '*:off', 'GOWORK': 'off', 'GOFLAGS': '-mod=readonly',
    'GOTELEMETRY': 'off', 'GOMAXPROCS': '4', 'CGO_ENABLED': '1',
    'CC': str(GO.with_name('gcc.exe')),
    'GOCACHE': r'<GO_CACHE_ROOT>\gocache',
    'GOMODCACHE': r'<GO_CACHE_ROOT>\gomodcache',
    'GOPATH': str(runtime / 'gopath'), 'MCPHUB_NO_AUTO_GUI': '1',
    'MCPHUB_E2E_SCHEDULER': 'none', 'USERPROFILE': str(runtime / 'profile'),
    'APPDATA': str(runtime / 'appdata'), 'LOCALAPPDATA': str(runtime / 'localappdata'),
    'TEMP': str(runtime / 'tmp'), 'TMP': str(runtime / 'tmp'),
    'TMPDIR': str(runtime / 'tmp'), 'GOTMPDIR': str(runtime / 'tmp'),
    'PSModuleAnalysisCachePath': str(runtime / 'localappdata/module-analysis-cache'),
    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(runtime / 'no-global-git-config'),
    'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = os.pathsep.join((str(GO.parent), str(ps.parent),
                            str(system / 'System32'), str(GIT.parent)))
receipt = {
    'phase': phase, 'base': BASE, 'expected_head': expected,
    'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
    'environment': {k: env[k] for k in (
        'GOENV', 'GOTOOLCHAIN', 'GOPROXY', 'GOSUMDB', 'GOVCS', 'GOWORK',
        'GOFLAGS', 'GOTELEMETRY', 'GOMAXPROCS', 'CGO_ENABLED',
        'MCPHUB_NO_AUTO_GUI', 'MCPHUB_E2E_SCHEDULER')},
    'native_lifecycle_opt_in_present': False,
    'whole_process_tree_deadline_enforced': False,
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def git_at(directory, *args):
    return subprocess.check_output([
        str(GIT), '-c', 'core.hooksPath=' + str(runtime / 'empty-hooks'),
        '-C', str(directory), *args,
    ], env=env, timeout=90).decode('utf-8').strip()


def git(*args):
    return git_at(SOURCE, *args)


def verify_root(directory):
    if Path(git_at(directory, 'rev-parse', '--show-toplevel')).resolve() != directory.resolve():
        raise RuntimeError('Repository root mismatch')


def run(name, args, exe=GO, cwd=SOURCE, extra_env=None):
    child_env = dict(env)
    child_env.update(extra_env or {})
    deadline = 900 if args and args[0] == 'test' else 180
    rec = {'name': name, 'executable': exe.name, 'arguments': args,
           'environment_delta': extra_env or {}, 'settled': False,
           'direct_child_deadline_seconds': deadline,
           'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(rec)
    save()
    print('START ' + name, flush=True)
    start = time.monotonic()
    with (out / (name + '.stdout.log')).open('xb') as stdout, \
         (out / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen([str(exe), *args], cwd=cwd, env=child_env,
                                 stdin=subprocess.DEVNULL, stdout=stdout,
                                 stderr=stderr, creationflags=0x08000000)
        try:
            rec['pid'] = child.pid
            save()
            child.wait(timeout=max(0, deadline - (time.monotonic() - start)))
        finally:
            # Reap the retained direct child even when recording its PID fails.
            # An exception from the try body is preserved after this cleanup.
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, deadline - (time.monotonic() - start)))
                except subprocess.TimeoutExpired:
                    rec['direct_child_deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            rec['exit_code'] = child.returncode
            rec['settled'] = child.returncode is not None
            save()
    rec['seconds'] = round(time.monotonic() - start, 3)
    for stream in ('stdout', 'stderr'):
        path = out / (name + '.' + stream + '.log')
        rec[stream + '_bytes'] = path.stat().st_size
        rec[stream + '_sha256'] = digest(path)
    if args and args[0] == 'test':
        output = (out / (name + '.stdout.log')).read_text(encoding='utf-8', errors='replace')
        if '-json' in args:
            events = [json.loads(line) for line in output.splitlines()]
            rec['tests'] = {action: [e.get('Test', 'PACKAGE:' + e.get('Package', ''))
                for e in events if e.get('Action') == action]
                for action in ('pass', 'fail', 'skip')}
            rec['package_test_passes'] = [
                [e.get('Package'), e.get('Test')] for e in events
                if e.get('Action') == 'pass' and e.get('Test')]
        else:
            rec['failed_packages'] = re.findall(r'^FAIL[ \t]+(mcp-local-hub[^ \t\r\n]*)', output, re.M)
            rec['failed_tests'] = re.findall(r'^--- FAIL: ([^ (]+)', output, re.M)
        rec['timeouts'] = re.findall(r'panic: test timed out after ([^\r\n]+)', output)
    save()
    print(json.dumps({k: rec[k] for k in
                     ('name', 'exit_code', 'seconds', 'settled', 'stdout_bytes', 'stderr_bytes')}), flush=True)
    if rec.get('direct_child_deadline_hit'):
        raise RuntimeError('Direct-child deadline exceeded; descendant settlement is unverified')
    return rec


def require_focused(rec):
    passes = rec['tests']['pass']
    expected_packages = ['PACKAGE:mcp-local-hub/' + p[2:] for p in PACKAGES]
    if (rec['exit_code'] != 0 or rec['tests']['fail'] or rec['tests']['skip']
            or rec['timeouts'] or any(
                rec['package_test_passes'].count(['mcp-local-hub/' + p[2:], t]) != 2
                for p, t in TARGETS)
            or any(passes.count(p) != 1 for p in expected_packages)):
        raise RuntimeError('Focused positive check incomplete or unsuccessful')


def verify_candidate(files, tree):
    paths = [item['path'] for item in files]
    expected_status = sorted(('M  ' if item.get('base_blob') else 'A  ') + item['path']
                             for item in files)
    if (git('rev-parse', 'HEAD') != BASE or git('diff', '--name-only')
            or sorted(git('status', '--porcelain=v1', '--untracked-files=all').splitlines()) != expected_status
            or sorted(git('diff', '--cached', '--name-only').splitlines()) != sorted(paths)
            or git('write-tree') != tree):
        raise RuntimeError('Candidate source/index binding failed')
    for item in files:
        if digest(SOURCE / item['path']) != item['sha256']:
            raise RuntimeError('Candidate working bytes changed: ' + item['path'])


try:
    receipt['runner_sha256'] = digest(Path(__file__))
    if phase == 'bootstrap':
        verify_root(OLD)
        if (SOURCE.exists() or git_at(OLD, 'rev-parse', 'HEAD') != OLD_HEAD
                or git_at(OLD, 'status', '--porcelain=v1', '--untracked-files=all')):
            raise RuntimeError('Unexpected original checkout')
        if run('clone', ['-c', 'core.autocrlf=false', 'clone', '--local', '--no-hardlinks',
                         '--no-checkout', str(OLD), str(SOURCE)], GIT, ROOT)['exit_code']:
            raise RuntimeError('Clone failed')
        git('config', 'core.autocrlf', 'false')
        git('config', 'core.hooksPath', str(runtime / 'empty-hooks'))
        if run('fetch', ['-C', str(SOURCE), 'fetch', '--no-tags',
                         'https://github.com/applicate2628/mcp-local-hub.git', BASE], GIT, ROOT)['exit_code']:
            raise RuntimeError('Fetch failed')
        if git('rev-parse', BASE + '^{tree}') != BASE_TREE:
            raise RuntimeError('Base tree mismatch')
        git('checkout', '--detach', BASE)
        if run('go-version', ['version'])['exit_code']:
            raise RuntimeError('Go version failed')
    else:
        verify_root(SOURCE)
        if git('rev-parse', 'HEAD') != expected:
            raise RuntimeError('Unexpected source head')
        manifest_name = 'candidate-manifest-v2.json' if phase in {'measurement', 'gates', 'published'} else 'candidate-manifest.json'
        manifest_data = (ROOT / manifest_name).read_bytes()
        receipt['manifest_sha256'] = hashlib.sha256(manifest_data).hexdigest()
        manifest = json.loads(manifest_data)
        if manifest['base'] != BASE:
            raise RuntimeError('Manifest base mismatch')
        files = manifest['files']
        paths = [f['path'] for f in files]
        if len(paths) != len({p.lower() for p in paths}) or set(paths) != EXPECTED_FILES:
            raise RuntimeError('Invalid candidate paths')
        for item in files:
            p = PurePosixPath(item['path'])
            if (p.is_absolute() or '..' in p.parts or p.as_posix() != item['path']
                    or any(c in item['path'] for c in ('\\', ':', '\x00'))
                    or not p.as_posix().endswith('_test.go')
                    or not any(item['path'].startswith(package[2:] + '/') for package in PACKAGES)):
                raise RuntimeError('Candidate must contain only relative test source files')
        if phase == 'candidate':
            if git('status', '--porcelain=v1', '--untracked-files=all'):
                raise RuntimeError('Dirty base')
            payloads = []
            for item in files:
                path = item['path']
                data = (ROOT / 'candidate' / path).read_bytes()
                if hashlib.sha256(data).hexdigest() != item['sha256']:
                    raise RuntimeError('Candidate bytes mismatch: ' + path)
                original = git('ls-tree', 'HEAD', '--', path)
                if item.get('base_blob'):
                    if original.split()[2] != item['base_blob']:
                        raise RuntimeError('Base blob mismatch: ' + path)
                elif original or (SOURCE / path).exists():
                    raise RuntimeError('New test file already exists')
                payloads.append((path, data))
            receipt['applied_paths'] = []
            save()
            for path, data in payloads:
                (SOURCE / path).write_bytes(data)
                receipt['applied_paths'].append(path)
                save()
            fmt = run('gofmt-check', ['-l', *paths], GO.with_name('gofmt.exe'))
            if fmt['exit_code'] or fmt['stdout_bytes']:
                raise RuntimeError('Candidate formatting differs')
            git('add', '--', *paths)
            receipt['candidate_tree'] = git('write-tree')
            receipt['diff_stat'] = git('diff', '--cached', '--stat')
            verify_candidate(files, receipt['candidate_tree'])
            for label, delta in [('focused-race', {}), ('focused-strict-race', {'MCPHUB_REQUIRE_SINGLE_USER_HOME': '1'})]:
                rec = run(label, ['test', '-json', '-race', '-count=2', '-timeout=180s',
                                  '-run', FOCUSED, *PACKAGES], extra_env=delta)
                require_focused(rec)
            run('packages-race', ['test', '-json', '-race', '-count=1', '-timeout=180s', *PACKAGES])
        elif phase == 'measurement':
            previous = json.loads((ROOT / 'evidence/candidate/receipt.json').read_text())
            old_manifest_data = (ROOT / 'candidate-manifest.json').read_bytes()
            old_files = json.loads(old_manifest_data)['files']
            if not previous.get('completed') or hashlib.sha256(old_manifest_data).hexdigest() != previous['manifest_sha256']:
                raise RuntimeError('First candidate evidence binding failed')
            verify_candidate(old_files, previous['candidate_tree'])
            test_path = 'internal/api/serena_routing/resolver_test.go'
            old_by_path = {item['path']: item for item in old_files}
            changed = [item['path'] for item in files if item != old_by_path.get(item['path'])]
            if changed != [test_path] or any(item['base_blob'] != old_by_path[item['path']]['base_blob'] for item in files):
                raise RuntimeError('Measurement revision must change only the existing Serena test')
            item = next(item for item in files if item['path'] == test_path)
            revised = (ROOT / 'candidate-v2' / test_path).read_bytes()
            if hashlib.sha256(revised).hexdigest() != item['sha256']:
                raise RuntimeError('Measurement test bytes mismatch')
            receipt['previous_candidate_tree'] = previous['candidate_tree']
            (SOURCE / test_path).write_bytes(revised)
            receipt['applied_paths'] = [test_path]
            save()
            fmt = run('gofmt-measurement', ['-l', test_path], GO.with_name('gofmt.exe'))
            if fmt['exit_code'] or fmt['stdout_bytes']:
                raise RuntimeError('Measurement test formatting differs')
            git('add', '--', test_path)
            receipt['candidate_tree'] = git('write-tree')
            receipt['diff_stat'] = git('diff', '--cached', '--stat')
            verify_candidate(files, receipt['candidate_tree'])
            package = './internal/api/serena_routing'
            test_name = 'TestResolveByPath_DoesNotCloneUnrelatedNestedRows'
            test_args = ['test', '-json', '-race', '-count=2', '-timeout=180s', '-run', '^' + test_name + '$', package]
            strict = {'MCPHUB_REQUIRE_SINGLE_USER_HOME': '1'}
            positive = run('paired-allocation-race', test_args, extra_env=strict)
            if (positive['exit_code'] or positive['tests']['fail'] or positive['tests']['skip']
                    or positive['tests']['pass'].count(test_name) != 2
                    or positive['tests']['pass'].count('PACKAGE:mcp-local-hub/internal/api/serena_routing') != 1):
                raise RuntimeError('Paired allocation check failed')

            product_path = 'internal/api/serena_routing/resolver.go'
            product = SOURCE / product_path
            original = product.read_bytes()
            mutant = (ROOT / 'mutation' / 'resolver.go').read_bytes()
            original_hash = 'c05c5ebb9e00fd4fca6cd8158843001f6703ab48c8e1418994bbd12b003180b1'
            mutant_hash = 'f4c9f345b6edaf7e9f86ea4950f33c4b70bac5ef6b13ff68cf6e4afae2c5fb7f'
            if (hashlib.sha256(original).hexdigest() != original_hash
                    or hashlib.sha256(mutant).hexdigest() != mutant_hash
                    or git('hash-object', '--no-filters', product_path) != '7da1df09fe5e4e95413b63dc6c1b32c76a9a5214'):
                raise RuntimeError('Mutation source binding failed')
            receipt['mutation'] = {'path': product_path, 'original_sha256': original_hash,
                                   'mutant_sha256': mutant_hash, 'restored': False}
            save()
            try:
                product.write_bytes(mutant)
                if (digest(product) != mutant_hash or git('diff', '--name-only') != product_path
                        or git('write-tree') != receipt['candidate_tree']):
                    raise RuntimeError('Mutation working-tree scope mismatch')
                negative = run('clone-all-negative-control',
                               ['test', '-json', '-race', '-count=1', '-timeout=180s',
                                '-run', '^' + test_name + '$', package], extra_env=strict)
                expected_failures = sorted([test_name, 'PACKAGE:mcp-local-hub/internal/api/serena_routing'])
                output_events = [json.loads(line) for line in
                    (out / 'clone-all-negative-control.stdout.log').read_text(encoding='utf-8').splitlines()]
                assertion_seen = any(event.get('Test') == test_name and
                                     'single-row lookup allocations grew from ' in event.get('Output', '')
                                     for event in output_events)
                diagnostics = ''.join(event.get('Output', '') for event in output_events)
                unexpected_failure = any(marker in diagnostics for marker in (
                    'WARNING: DATA RACE', 'race detected during execution of test',
                    'panic:', 'fatal error:'))
                if (negative['exit_code'] != 1 or sorted(negative['tests']['fail']) != expected_failures
                        or negative['tests']['skip'] or negative['timeouts'] or not assertion_seen
                        or negative['stderr_bytes'] or unexpected_failure):
                    raise RuntimeError('Mutation did not fail at the intended allocation-growth assertion')
                negative['expected_exit_code'] = 1
                negative['semantic_expected_failure_pass'] = True
                receipt['mutation']['oracle_sensitive'] = True
                save()
            finally:
                if digest(product) != mutant_hash:
                    raise RuntimeError('Mutant source changed; refusing to overwrite unknown bytes')
                product.write_bytes(original)
                receipt['mutation']['restored'] = digest(product) == original_hash
                save()
            verify_candidate(files, receipt['candidate_tree'])
            if not receipt['mutation']['restored'] or git('hash-object', '--no-filters', product_path) != '7da1df09fe5e4e95413b63dc6c1b32c76a9a5214':
                raise RuntimeError('Original product restoration failed')
            full = run('restored-serena-strict-race',
                       ['test', '-json', '-race', '-count=1', '-timeout=180s', package], extra_env=strict)
            if (full['exit_code'] or full['tests']['fail'] or full['timeouts']
                    or full['tests']['pass'].count(test_name) != 1
                    or full['tests']['pass'].count('PACKAGE:mcp-local-hub/internal/api/serena_routing') != 1):
                raise RuntimeError('Restored Serena package failed')
        elif phase == 'gates':
            previous = json.loads((ROOT / 'evidence/measurement/receipt.json').read_text())
            if (not previous.get('completed') or not previous.get('checks_passed')
                    or git('write-tree') != previous['candidate_tree']):
                raise RuntimeError('Candidate tree binding failed')
            receipt['candidate_tree'] = previous['candidate_tree']
            if previous['manifest_sha256'] != receipt['manifest_sha256']:
                raise RuntimeError('Candidate manifest changed')
            verify_candidate(files, receipt['candidate_tree'])
            run('build', ['build', './...'])
            run('vet', ['vet', './...'])
            run('full-test', ['test', '-count=1', '-timeout', '5m', './...'])
            run('tagged-api-cli', ['test', '-tags=test_state_path_env', '-count=1', '-timeout', '5m',
                                   './internal/api/', './internal/cli/'])
        else:
            previous = json.loads((ROOT / 'evidence/gates/receipt.json').read_text())
            if (not previous.get('completed') or git('rev-parse', 'HEAD^{tree}') != previous['candidate_tree']
                    or git('rev-list', '--parents', '-n', '1', 'HEAD').split() != [expected, BASE]
                    or git('status', '--porcelain=v1', '--untracked-files=all')):
                raise RuntimeError('Published ancestry/tree mismatch')
            if previous['manifest_sha256'] != receipt['manifest_sha256']:
                raise RuntimeError('Published manifest changed')
            for item in files:
                if digest(SOURCE / item['path']) != item['sha256']:
                    raise RuntimeError('Published working bytes changed')
            rec = run('published-focused-strict-race', ['test', '-json', '-race', '-count=2',
                      '-timeout=180s', '-run', FOCUSED, *PACKAGES],
                      extra_env={'MCPHUB_REQUIRE_SINGLE_USER_HOME': '1'})
            require_focused(rec)
            test_name = 'TestResolveByPath_DoesNotCloneUnrelatedNestedRows'
            rec = run('published-paired-allocation-strict-race',
                      ['test', '-json', '-race', '-count=2', '-timeout=180s',
                       '-run', '^' + test_name + '$', './internal/api/serena_routing'],
                      extra_env={'MCPHUB_REQUIRE_SINGLE_USER_HOME': '1'})
            if (rec['exit_code'] or rec['tests']['fail'] or rec['tests']['skip']
                    or rec['timeouts'] or rec['tests']['pass'].count(test_name) != 2
                    or rec['tests']['pass'].count('PACKAGE:mcp-local-hub/internal/api/serena_routing') != 1):
                raise RuntimeError('Published paired allocation check failed')
        for item in files:
            if digest(SOURCE / item['path']) != item['sha256']:
                raise RuntimeError('Source changed: ' + item['path'])
        if phase in {'candidate', 'measurement', 'gates'}:
            verify_candidate(files, receipt['candidate_tree'])
    receipt['head_after'] = git('rev-parse', 'HEAD')
    receipt['tree_after'] = git('rev-parse', 'HEAD^{tree}')
    receipt['status_after'] = git('status', '--porcelain=v1', '--untracked-files=all')
    if receipt['head_after'] != expected:
        raise RuntimeError('Source head changed')
    if phase in {'bootstrap', 'published'} and receipt['status_after']:
        raise RuntimeError('Expected clean source')
    receipt['completed'] = True
finally:
    receipt['checks_passed'] = bool(receipt.get('completed')) and all(
        rec.get('settled') and rec.get('exit_code') == rec.get('expected_exit_code', 0) and not rec.get('direct_child_deadline_hit')
        for rec in receipt['commands'])
    receipt['overall'] = ('PASS' if receipt['checks_passed'] else
                          'FAIL' if receipt.get('completed') else 'INCOMPLETE')
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps({'phase': phase, 'completed': receipt.get('completed', False),
                  'overall': receipt['overall'], 'checks_passed': receipt['checks_passed'],
                  'commands': len(receipt['commands']), 'candidate_tree': receipt.get('candidate_tree')}), flush=True)
