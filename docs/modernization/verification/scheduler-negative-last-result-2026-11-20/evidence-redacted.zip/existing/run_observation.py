"""Bounded Scheduler observation; prepares only its fresh output directory."""
from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

if sys.flags.optimize:
    raise SystemExit('Optimized execution is unsupported')
if os.name != 'nt':
    raise SystemExit('Windows is required')
ROOT = Path(r'<EXISTING_ROOT>')
SOURCE = ROOT / 'Observe-ExistingLastResultCandidates.ps1'
EXPECTED_SOURCE = '486a7c138f3d9fa12a43b8d6d0480d227741a3b16f30b9d3a5efc52c68882acb'
# The caller creates this task-only directory exclusively before uploading the
# scripts. Reject redirection before any runtime, receipt, or log is created.
root_info = ROOT.lstat()
source_info = SOURCE.lstat()
if not stat.S_ISDIR(root_info.st_mode) or root_info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
    raise SystemExit('Output root must be an ordinary directory')
if not stat.S_ISREG(source_info.st_mode) or source_info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
    raise SystemExit('Observer source must be an ordinary file')
data = SOURCE.read_bytes()
if hashlib.sha256(data).hexdigest() != EXPECTED_SOURCE:
    raise SystemExit('Observer source mismatch')
source = data.decode('utf-8', errors='strict')
runtime = ROOT / 'runtime'
runtime.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith('MCPHUB_')}
for key, name in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('USERPROFILE', 'profile'),
                  ('APPDATA', 'appdata'), ('LOCALAPPDATA', 'localappdata')]:
    directory = runtime / name
    directory.mkdir(exist_ok=True)
    env[key] = str(directory)
env['PSModuleAnalysisCachePath'] = str(runtime / 'localappdata/module-analysis-cache')
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env['PATH'] = os.pathsep.join((str(ps.parent), str(system / 'System32')))
receipt = {
    'run_id': 'r17-lastresult-existing-candidates-20261120-01',
    'source_sha256': EXPECTED_SOURCE,
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
    'scheduler_changes': False, 'public_go_calls': 0,
    'whole_process_tree_qualification': False,
    'output_acl_verified': False,
}


def save():
    (ROOT / 'observation-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(name, command):
    record = {'name': name, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'settled': False, 'direct_child_deadline_seconds': 60}
    receipt['commands'].append(record)
    save()
    start = time.monotonic()
    with (ROOT / (name + '.stdout.log')).open('xb') as stdout, \
         (ROOT / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen([str(ps), '-NoProfile', '-NonInteractive', '-Command', command],
                                 env=env, cwd=ROOT, stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, creationflags=0x08000000)
        try:
            record['pid'] = child.pid
            save()
            child.wait(timeout=max(0, 60 - (time.monotonic() - start)))
        finally:
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, 60 - (time.monotonic() - start)))
                except subprocess.TimeoutExpired:
                    record['direct_child_deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            record['exit_code'] = child.returncode
            record['settled'] = child.returncode is not None
            save()
    record['seconds'] = round(time.monotonic() - start, 6)
    for stream in ('stdout', 'stderr'):
        content = (ROOT / (name + '.' + stream + '.log')).read_bytes()
        record[stream + '_bytes'] = len(content)
        record[stream + '_sha256'] = hashlib.sha256(content).hexdigest()
    save()
    return record


try:
    # Parse the captured bytes without executing them. The observation below
    # consumes the same captured source, not a second read of the mutable file.
    encoded = base64.b64encode(data).decode('ascii')
    parse_command = (
        "$ErrorActionPreference='Stop'; $tokens=$null; $parseErrors=$null; "
        "$source=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "')); "
        "$null=[Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$parseErrors); "
        "if($parseErrors.Count -ne 0){[Console]::Error.WriteLine('PowerShell syntax errors: '+$parseErrors.Count); exit 1}; "
        "[Console]::WriteLine('SYNTAX_PASS'); exit 0"
    )
    parsed = run('syntax', parse_command)
    if parsed['exit_code'] != 0 or parsed['stderr_bytes'] != 0:
        raise RuntimeError('PowerShell syntax check failed; observation was not executed')
    # This changes only the fresh task root's discretionary access control list
    # (DACL). The three allowed identities inherit access to new files and child
    # directories. No owner names or security identifiers enter the logs.
    prepare_command = "$ErrorActionPreference='Stop'; $root='" + str(ROOT).replace("'", "''") + "';\n" + r"""
try {
    $attributes = [IO.File]::GetAttributes($root)
    if (($attributes -band [IO.FileAttributes]::ReparsePoint) -or
        !($attributes -band [IO.FileAttributes]::Directory)) {
        throw 'Output root is not an ordinary directory'
    }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $userSid = $identity.User
        if ($null -eq $userSid) { throw 'Current token has no user' }
        $allowed = @{}
        foreach ($sid in @($userSid.Value, 'S-1-5-18', 'S-1-5-32-544')) {
            $allowed[$sid] = $true
        }
    } finally {
        $identity.Dispose()
    }
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
               [Security.AccessControl.InheritanceFlags]::ObjectInherit
    $rights = [Security.AccessControl.FileSystemRights]::FullControl
    $propagation = [Security.AccessControl.PropagationFlags]::None
    $allow = [Security.AccessControl.AccessControlType]::Allow
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in $allowed.Keys) {
        $principal = [Security.Principal.SecurityIdentifier]::new($sid)
        $rule = [Security.AccessControl.FileSystemAccessRule]::new(
            $principal, $rights, $inherit, $propagation, $allow)
        $acl.AddAccessRule($rule)
    }
    [IO.Directory]::SetAccessControl($root, $acl)
    $actual = [IO.Directory]::GetAccessControl($root, [Security.AccessControl.AccessControlSections]::Access)
    if (!$actual.AreAccessRulesProtected) { throw 'Output access rules are not protected' }
    $rules = $actual.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])
    if ($rules.Count -ne $allowed.Count) { throw 'Unexpected output access rule count' }
    $seen = @{}
    foreach ($rule in $rules) {
        $sid = $rule.IdentityReference.Value
        if (!$allowed.ContainsKey($sid) -or $seen.ContainsKey($sid) -or
            $rule.IsInherited -or $rule.AccessControlType -ne $allow -or
            $rule.FileSystemRights -ne $rights -or $rule.InheritanceFlags -ne $inherit -or
            $rule.PropagationFlags -ne $propagation) {
            throw 'Unexpected output access rule'
        }
        $seen[$sid] = $true
    }
    $attributes = [IO.File]::GetAttributes($root)
    if (($attributes -band [IO.FileAttributes]::ReparsePoint) -or
        !($attributes -band [IO.FileAttributes]::Directory)) {
        throw 'Output root changed type'
    }
    [Console]::WriteLine('OUTPUT_ACL_VERIFIED')
    exit 0
} catch {
    [Console]::Error.WriteLine('Output directory access preparation failed')
    exit 1
}
"""
    prepared = run('prepare-output', prepare_command)
    if prepared['exit_code'] != 0 or prepared['stderr_bytes'] != 0 or \
       (ROOT / 'prepare-output.stdout.log').read_bytes().decode('utf-8-sig').strip() != 'OUTPUT_ACL_VERIFIED':
        raise RuntimeError('Output directory access was not verified; observation was not executed')
    receipt['output_acl_verified'] = True
    save()
    observed = run('observation', source)
    if observed['stderr_bytes'] != 0 or observed['exit_code'] not in (0, 2, 3):
        raise RuntimeError('Observation execution failed')
    summary = json.loads((ROOT / 'observation.stdout.log').read_bytes().decode('utf-8-sig'))
    saved_summary = json.loads((ROOT / 'summary.json').read_text(encoding='utf-8-sig'))
    if summary != saved_summary or summary['run_id'] != receipt['run_id']:
        raise RuntimeError('Observation summary binding failed')
    expected_exit = 2 if not summary['enumeration_complete'] else 0 if summary['candidate_count'] else 3
    if observed['exit_code'] != expected_exit or summary['scheduler_changes'] or summary['public_go_calls'] != 0:
        raise RuntimeError('Observation status mismatch')
    receipt['summary'] = summary
    receipt['outcome'] = {0: 'CANDIDATES_OBSERVED', 2: 'INCOMPLETE_OBSERVATION', 3: 'NO_ELIGIBLE_CANDIDATE'}[expected_exit]
    receipt['completed'] = True
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(receipt), flush=True)
raise SystemExit(observed['exit_code'])
