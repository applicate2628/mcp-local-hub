# Read-only discovery of a new native result boundary on existing tasks.
# The RunId identifies evidence; it is not a reusable execution grant.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$runId = 'r17-lastresult-existing-candidates-20261120-01'
$root = '<EXISTING_ROOT>'
$head = '9721681633440d3593d37ffb8f580e5d98440da2'
$maximumTasks = 128
# Deliberately conservative eligibility floor, not a universal Windows sentinel.
# It excludes the retained never-run value 1999-11-30 and older zero-date forms.
$minimumLastRun = [datetime]::new(2000, 1, 1)
$started = [datetime]::UtcNow
$failureCategory = 'preflight'
$privateOutputAllowed = $false
$count = [ordered]@{
    visible_root_tasks = 0
    same_account_tasks = 0
    other_account_tasks = 0
    identity_unknown = 0
    query_failures = 0
    non_idle = 0
    zero_result = 0
    scheduler_status_range = 0
    negative_nonstatus_observed = 0
    positive_nonstatus_observed = 0
    invalid_or_sentinel_last_run = 0
    unsupported_action_shape = 0
    changed_during_read = 0
}

function Write-NewJson([string]$Path, $Value) {
    $bytes = $utf8.GetBytes(($Value | ConvertTo-Json -Depth 8) + "`n")
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($bytes, 0, $bytes.Length) } finally { $stream.Dispose() }
}

function Require-Int32($Value) {
    if ($null -eq $Value -or $Value.GetType().FullName -cne 'System.Int32') {
        throw 'Expected exact native Int32'
    }
    return $Value
}

function Resolve-OwnerSid([string]$Owner) {
    if ([string]::IsNullOrWhiteSpace($Owner)) { throw 'Unknown principal' }
    if ($Owner.StartsWith('S-1-', [StringComparison]::OrdinalIgnoreCase)) {
        return ([Security.Principal.SecurityIdentifier]::new($Owner)).Value
    }
    return ([Security.Principal.NTAccount]::new($Owner)).Translate([Security.Principal.SecurityIdentifier]).Value
}

try {
    # The external launcher must first create this distinct ordinary directory
    # with all writable runtime/profile/cache paths beneath the same D: root.
    $directory = Get-Item -LiteralPath $root
    if (!$directory.PSIsContainer -or ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Output directory must be ordinary'
    }
    foreach ($name in @('claim.json', 'candidates-private.json', 'summary.json', 'error-private.json')) {
        if (Test-Path -LiteralPath (Join-Path $root $name)) { throw 'RunId already used' }
    }
    Write-NewJson (Join-Path $root 'claim.json') ([ordered]@{
        run_id = $runId
        mode = 'READ_ONLY_EXISTING_CANDIDATE_OBSERVATION'
        started_utc = $started.ToString('o')
        scheduler_changes = $false
    })
    $privateOutputAllowed = $true
    $failureCategory = 'identity'
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity.User -or [string]::IsNullOrWhiteSpace($identity.Name)) { throw 'Current identity unavailable' }
    $currentSid = $identity.User.Value
    $currentName = $identity.Name
    $currentShortName = ($currentName -split '\\')[-1]
    $failureCategory = 'enumeration'
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $folder = $service.GetFolder('\')
    $visible = @($folder.GetTasks(0))
    $count.visible_root_tasks = $visible.Count
    if ($visible.Count -gt $maximumTasks) { throw 'Task-count budget exceeded' }
    $names = @($visible | ForEach-Object {
        $nativeName = $_.Name
        if ($null -eq $nativeName -or $nativeName -isnot [string] -or
            [string]::IsNullOrWhiteSpace($nativeName) -or $nativeName.IndexOfAny([char[]]'\/') -ge 0) {
            throw 'Root task name unavailable'
        }
        $nativeName
    })
    $candidates = @()
    $nonstatusObservations = @()
    $redacted = @()
    $failureCategory = 'task_read'
    foreach ($task in $visible) {
        try {
            $definition = $task.Definition
            $owner = $definition.Principal.UserId
            if ($null -eq $owner -or $owner -isnot [string]) { throw 'Principal value unavailable' }
            $ownerSid = Resolve-OwnerSid $owner
        } catch {
            $count.identity_unknown++
            continue
        }
        if ($ownerSid -cne $currentSid) { $count.other_account_tasks++; continue }
        $count.same_account_tasks++
        $observation = $null
        try {
            $xml = $task.Xml
            $name = $task.Name
            if ($xml -isnot [string] -or [string]::IsNullOrWhiteSpace($xml) -or
                $xml.Length -gt 262144 -or $name -isnot [string]) {
                throw 'Task identity or bounded definition unavailable'
            }
            $definition = $task.Definition
            if ([string]$definition.Principal.UserId -cne $owner) { throw 'Principal changed during read' }
            $state = Require-Int32 $task.State
            $instances = Require-Int32 ($task.GetInstances(0)).Count
            if ($state -notin @(1, 3) -or $instances -ne 0) { $count.non_idle++; continue }
            $value = Require-Int32 $task.LastTaskResult
            if ($value -eq 0) { $count.zero_result++; continue }
            if ($value -ge 0x41300 -and $value -le 0x413FF) { $count.scheduler_status_range++; continue }
            if ($value -lt 0) { $count.negative_nonstatus_observed++ } else { $count.positive_nonstatus_observed++ }
            $observation = [ordered]@{
                observation_id = 'observation-{0:D3}' -f ($nonstatusObservations.Count + 1)
                name = '\' + $name
                owner = $owner
                state = $state
                last_result = $value
                result_runtime_type = 'System.Int32'
                outcome = 'reading'
                last_run_time = $null
                last_run_kind = $null
                action_count = $null
                action_type = $null
                candidate_id = $null
            }
            $nonstatusObservations += $observation
            $lastRun = $task.LastRunTime
            if ($null -eq $lastRun -or $lastRun.GetType().FullName -cne 'System.DateTime') {
                throw 'Native last-run type unavailable'
            }
            $observation.last_run_time = $lastRun.ToString('o')
            $observation.last_run_kind = $lastRun.Kind.ToString()
            # Scheduler DATE is retained with its observed Kind. No invented UTC conversion.
            if ($lastRun -lt $minimumLastRun -or $lastRun -gt [datetime]::Now.AddMinutes(5)) {
                $count.invalid_or_sentinel_last_run++
                $observation.outcome = 'invalid_or_sentinel_last_run'
                continue
            }
            $hidden = $definition.Settings.Hidden
            if ($null -eq $hidden -or $hidden -isnot [bool] -or $hidden) { throw 'Visible scope changed or unavailable' }
            $actions = $definition.Actions
            $actionCount = Require-Int32 $actions.Count
            $observation.action_count = $actionCount
            if ($actionCount -ne 1) {
                $count.unsupported_action_shape++
                $observation.outcome = 'unsupported_action_count'
                continue
            }
            $action = $actions.Item(1)
            $actionType = Require-Int32 $action.Type
            $observation.action_type = $actionType
            if ($actionType -ne 0) {
                $count.unsupported_action_shape++
                $observation.outcome = 'unsupported_action_type'
                continue
            }
            $actionPath = $action.Path
            $actionArguments = $action.Arguments
            $actionWorkingDirectory = $action.WorkingDirectory
            if ($actionPath -isnot [string] -or [string]::IsNullOrWhiteSpace($actionPath) -or
                $actionArguments -isnot [string] -or $actionWorkingDirectory -isnot [string]) {
                throw 'Exec action metadata unavailable'
            }
            # Re-read the same object at the end; equality is stability evidence,
            # not atomic isolation, proof of historical completion, or a future grant.
            $lastRunAfter = $task.LastRunTime
            if ($null -eq $lastRunAfter -or $lastRunAfter.GetType().FullName -cne 'System.DateTime') {
                throw 'Native last-run type unavailable on repeated read'
            }
            if ((Require-Int32 $task.State) -ne $state -or
                (Require-Int32 $task.LastTaskResult) -ne $value -or
                $lastRunAfter -ne $lastRun -or $lastRunAfter.Kind -ne $lastRun.Kind -or
                (Require-Int32 ($task.GetInstances(0)).Count) -ne 0 -or
                [string]$task.Definition.Principal.UserId -cne $owner -or
                [string]$task.Xml -cne $xml -or [string]$task.Name -cne $name) {
                $count.changed_during_read++
                $observation.outcome = 'changed_during_read'
                continue
            }
            $prefixCount = @($names | Where-Object { $_.StartsWith($name) }).Count
            $ownerShortName = ($owner.Trim() -split '\\')[-1]
            $ownerCompatible = [StringComparer]::OrdinalIgnoreCase.Equals($ownerShortName, $currentShortName.Trim())
            $candidateId = 'candidate-{0:D3}' -f ($candidates.Count + 1)
            $observation.candidate_id = $candidateId
            $observation.outcome = 'candidate'
            $classification = if ($value -lt 0) { 'negative_native_int32' } else { 'positive_nonstatus_candidate' }
            $dualReadCandidate = $prefixCount -eq 1 -and $ownerCompatible
            $candidate = [ordered]@{
                candidate_id = $candidateId
                head = $head
                name = '\' + $name
                prefix = $name
                owner = $owner
                owner_sid = $ownerSid
                state = $state
                last_result = $value
                result_runtime_type = $value.GetType().FullName
                last_run_ticks = $lastRun.Ticks
                last_run_time = $lastRun.ToString('o')
                last_run_kind = $lastRun.Kind.ToString()
                hidden = $hidden
                instance_count = $instances
                action_count = $actionCount
                action_type = $actionType
                action_path = $actionPath
                action_arguments = $actionArguments
                action_working_directory = $actionWorkingDirectory
                xml = $xml
                class = $classification
                dual_read_candidate = $dualReadCandidate
                completed_action_exit_qualified = $false
            }
            $candidates += [pscustomobject]$candidate
            $redacted += [pscustomobject][ordered]@{
                candidate_id = $candidateId
                class = $classification
                state = $state
                last_result = $value
                result_runtime_type = 'System.Int32'
                last_run_time = $lastRun.ToString('o')
                last_run_kind = $lastRun.Kind.ToString()
                visible_instances = 0
                action_count = 1
                action_type = 0
                action_path_nonempty = $true
                dual_read_candidate = $dualReadCandidate
                completed_action_exit_qualified = $false
            }
        } catch {
            $count.query_failures++
            if ($null -ne $observation) { $observation.outcome = 'query_failure' }
        }
    }
    $complete = $count.identity_unknown -eq 0 -and $count.query_failures -eq 0 -and $count.changed_during_read -eq 0
    $summary = [ordered]@{
        run_id = $runId
        mode = 'READ_ONLY_EXISTING_CANDIDATE_OBSERVATION'
        counts = $count
        enumeration_complete = $complete
        candidate_count = $candidates.Count
        nonstatus_observation_count = $nonstatusObservations.Count
        candidates = $redacted
        eligible_for_contract_review = $complete -and $candidates.Count -gt 0
        execution_authorized = $false
        minimum_last_run_policy = '2000-01-01 local/observed DATE; reject future by over 5 minutes'
        action_admission_policy = 'one registered Exec action with nonempty Path; other nonstatus values retained privately'
        maximum_visible_tasks = $maximumTasks
        scheduler_changes = $false
        public_go_calls = 0
        completed_action_exit_qualified = $false
        full_native_qualification = $false
        atomic_snapshot_claimed = $false
        in_process_deadline_enforced = $false
        started_utc = $started.ToString('o')
        finished_utc = [datetime]::UtcNow.ToString('o')
    }
    Write-NewJson (Join-Path $root 'candidates-private.json') ([ordered]@{
        run_id = $runId
        summary = $summary
        nonstatus_observations = $nonstatusObservations
        candidates = $candidates
    })
    Write-NewJson (Join-Path $root 'summary.json') $summary
    $summary | ConvertTo-Json -Depth 8 -Compress
    if (!$complete) { exit 2 }
    if ($candidates.Count -eq 0) { exit 3 }
    exit 0
} catch {
    if ($privateOutputAllowed) {
        try {
            Write-NewJson (Join-Path $root 'error-private.json') ([ordered]@{
                category = $failureCategory
                error = ($_ | Out-String)
            })
        } catch { }
    }
    [pscustomobject]@{
        run_id = $runId
        mode = 'READ_ONLY_EXISTING_CANDIDATE_OBSERVATION'
        observation_failed = $true
        error_category = $failureCategory
        eligible_for_contract_review = $false
        execution_authorized = $false
        scheduler_changes = $false
        public_go_calls = 0
        completed_action_exit_qualified = $false
    } | ConvertTo-Json -Compress
    exit 1
}
