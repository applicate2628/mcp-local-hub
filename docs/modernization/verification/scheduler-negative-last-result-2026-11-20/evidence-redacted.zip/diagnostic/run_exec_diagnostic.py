"""Read the exact five retained subjects; publish field types and categories only."""
from datetime import datetime, timezone
from pathlib import Path
import base64
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

if sys.flags.optimize or os.name != 'nt':
    raise SystemExit('Unoptimized Windows execution is required')
ROOT = Path(r'<DIAGNOSTIC_ROOT>')
SCRIPT = ROOT / 'Diagnose-RetainedExecFields.ps1'
PRIVATE = Path(r'<EXISTING_ROOT>\candidates-private.json')
SCRIPT_SHA = '2b6050ac622945d818b799c10ceb1be5940723fed890751f75d768331a675709'
for path, directory in ((ROOT, True), (SCRIPT, False), (PRIVATE, False)):
    info = path.lstat()
    if (info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT
            or not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode))):
        raise SystemExit('Input or output has an unexpected type')
source = SCRIPT.read_bytes()
if hashlib.sha256(source).hexdigest() != SCRIPT_SHA:
    raise SystemExit('Diagnostic source mismatch')
private_bytes = PRIVATE.read_bytes()
if len(private_bytes) > 65536:
    raise SystemExit('Private input exceeds its bound')
input_sha = hashlib.sha256(private_bytes).hexdigest()
del private_bytes
runtime = ROOT / 'runtime'
runtime.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith('MCPHUB_')}
for key, name in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('USERPROFILE', 'profile'),
                  ('APPDATA', 'appdata'), ('LOCALAPPDATA', 'localappdata')]:
    directory = runtime / name
    directory.mkdir(exist_ok=True)
    env[key] = str(directory)
env['PSModuleAnalysisCachePath'] = str(runtime / 'localappdata/module-analysis-cache')
env['R17_DIAGNOSTIC_INPUT_SHA256'] = input_sha
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env['PATH'] = os.pathsep.join((str(ps.parent), str(system / 'System32')))
receipt = {'run_id': 'r17-lastresult-exec-fields-diagnostic-20261120-01',
           'source_sha256': SCRIPT_SHA, 'input_sha256': input_sha,
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'scheduler_changes': False, 'public_go_calls': 0,
           'whole_process_tree_qualification': False}


def save():
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


def run(name, command):
    rec = {'name': name, 'settled': False, 'direct_child_deadline_seconds': 60}
    receipt['commands'].append(rec)
    save()
    started = time.monotonic()
    with (ROOT / (name + '.stdout.log')).open('xb') as fo, \
         (ROOT / (name + '.stderr.log')).open('xb') as fe:
        child = subprocess.Popen([str(ps), '-NoProfile', '-NonInteractive', '-Command', command],
                                 env=env, cwd=ROOT, stdin=subprocess.DEVNULL,
                                 stdout=fo, stderr=fe, creationflags=0x08000000)
        try:
            rec['pid'] = child.pid
            save()
            child.wait(timeout=max(0, 60 - (time.monotonic() - started)))
        finally:
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, 60 - (time.monotonic() - started)))
                except subprocess.TimeoutExpired:
                    rec['direct_child_deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            rec['exit_code'] = child.returncode
            rec['settled'] = child.returncode is not None
            save()
    rec['seconds'] = round(time.monotonic() - started, 6)
    for stream in ('stdout', 'stderr'):
        data = (ROOT / (name + '.' + stream + '.log')).read_bytes()
        rec[stream + '_sha256'] = hashlib.sha256(data).hexdigest()
        rec[stream + '_bytes'] = len(data)
    save()
    if rec['exit_code'] or rec['stderr_bytes'] or rec.get('direct_child_deadline_hit'):
        raise RuntimeError('Diagnostic command failed or exceeded its direct-child deadline')
    return rec


try:
    encoded = base64.b64encode(source).decode('ascii')
    parse = ("$ErrorActionPreference='Stop'; $tokens=$null; $errors=$null; "
             "$source=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "')); "
             "$null=[Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors); "
             "if($errors.Count -ne 0){exit 1}; [Console]::WriteLine('SYNTAX_PASS'); exit 0")
    run('syntax', parse)
    run('diagnostic', source.decode('utf-8'))
    summary = json.loads((ROOT / 'diagnostic.stdout.log').read_bytes().decode('utf-8-sig'))
    if (summary['run_id'] != receipt['run_id'] or summary['input_sha256'] != input_sha
            or summary['requested_subject_count'] != 5 or len(summary['diagnostic_records']) != 5
            or summary['scheduler_changes'] or summary['public_go_calls'] != 0
            or summary['native_qualification']):
        raise RuntimeError('Diagnostic summary binding failed')
    receipt['summary'] = summary
    receipt['completed'] = True
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(receipt), flush=True)
