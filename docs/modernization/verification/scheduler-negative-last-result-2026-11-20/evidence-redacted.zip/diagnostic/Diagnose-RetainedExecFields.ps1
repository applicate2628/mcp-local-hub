# Prepared diagnostic only; execution requires its own separately bounded run.
# Reads the five retained subjects by exact name. Does not enumerate other tasks.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$runId = 'r17-lastresult-exec-fields-diagnostic-20261120-01'
$sourceRunId = 'r17-lastresult-existing-candidates-20261120-01'
$privatePath = '<EXISTING_ROOT>\candidates-private.json'
$inputHash = $env:R17_DIAGNOSTIC_INPUT_SHA256
$stage = 'input'
$results = @()

function Describe-Value($Value) {
    if ($null -eq $Value) {
        return [pscustomobject]@{runtime_type='null';category='null'}
    }
    $category = 'other_type'
    if ($Value -is [string]) {
        $category = if ([string]::IsNullOrWhiteSpace($Value)) { 'empty_or_whitespace_string' } else { 'nonempty_string' }
    }
    return [pscustomobject]@{runtime_type=$Value.GetType().FullName;category=$category}
}

function Describe-Error($ErrorRecord) {
    # Deliberately omit message, target, invocation text, stack and native values.
    return [pscustomobject]@{
        exception_type = $ErrorRecord.Exception.GetType().FullName
        category = $ErrorRecord.CategoryInfo.Category.ToString()
    }
}

function Require-NativeInt32($Value) {
    if ($null -eq $Value -or $Value.GetType().FullName -cne 'System.Int32') {
        throw 'Expected native Int32'
    }
    return $Value
}

function Resolve-OwnerSid([string]$Owner) {
    if ([string]::IsNullOrWhiteSpace($Owner)) { throw 'Unknown principal' }
    if ($Owner.StartsWith('S-1-', [StringComparison]::OrdinalIgnoreCase)) {
        return ([Security.Principal.SecurityIdentifier]::new($Owner)).Value
    }
    return ([Security.Principal.NTAccount]::new($Owner)).Translate([Security.Principal.SecurityIdentifier]).Value
}

try {
    if ($inputHash -cnotmatch '^[0-9a-f]{64}$') { throw 'Expected input hash is required' }
    $inputInfo = Get-Item -LiteralPath $privatePath
    if ($inputInfo.PSIsContainer -or ($inputInfo.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        $inputInfo.Length -gt 65536) { throw 'Input must be an ordinary bounded file' }
    $inputBytes = [IO.File]::ReadAllBytes($privatePath)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $actualHash = ([BitConverter]::ToString($sha.ComputeHash($inputBytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
    if ($actualHash -cne $inputHash) { throw 'Retained input changed' }
    $saved = ([Text.UTF8Encoding]::new($false, $true)).GetString($inputBytes) | ConvertFrom-Json
    $subjects = @($saved.nonstatus_observations)
    if ($saved.run_id -cne $sourceRunId -or $subjects.Count -ne 5 -or
        $saved.summary.counts.query_failures -ne 5 -or $saved.summary.candidate_count -ne 0) {
        throw 'Retained scope differs'
    }
    $names = @{}
    $ids = @{}
    foreach ($subject in $subjects) {
        if ($subject.name -isnot [string] -or $subject.name -cnotmatch '^\\[^\\/]+$' -or
            $subject.owner -isnot [string] -or [string]::IsNullOrWhiteSpace($subject.owner) -or
            $subject.observation_id -cnotmatch '^observation-00[1-5]$' -or
            $subject.outcome -cne 'query_failure' -or $subject.state -ne 3 -or
            $subject.result_runtime_type -cne 'System.Int32' -or
            $subject.action_count -ne 1 -or $subject.action_type -ne 0 -or
            $subject.last_run_time -isnot [string] -or $subject.last_run_kind -cne 'Unspecified') {
            throw 'Retained subject metadata differs'
        }
        if ($names.ContainsKey($subject.name) -or $ids.ContainsKey($subject.observation_id)) {
            throw 'Duplicate retained subject'
        }
        $names[$subject.name] = $true
        $ids[$subject.observation_id] = $true
    }
    $stage = 'identity'
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if ($null -eq $identity.User -or [string]::IsNullOrWhiteSpace($identity.Name)) { throw 'Current identity unavailable' }
        $currentSid = $identity.User.Value
        $currentShortName = ($identity.Name -split '\\')[-1]
    } finally { $identity.Dispose() }
    $stage = 'connection'
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $folder = $service.GetFolder('\')

    foreach ($subject in $subjects) {
        $record = [ordered]@{
            observation_id = $subject.observation_id
            subject_match = 'not_checked'
            exec_fields = @()
            existing_exec_predicate = 'not_evaluated'
            final_snapshot = 'not_checked'
            owner_expression = 'not_checked'
            prefix_enumeration = 'not_in_scope'
            failure_stage = $null
            failure = $null
        }
        $results += $record
        $stage = 'exact_subject'
        try {
            $task = $folder.GetTask($subject.name.TrimStart('\'))
            $definition = $task.Definition
            $owner = $definition.Principal.UserId
            $name = $task.Name
            $state = Require-NativeInt32 $task.State
            $result = Require-NativeInt32 $task.LastTaskResult
            $instances = Require-NativeInt32 ($task.GetInstances(0)).Count
            $lastRun = $task.LastRunTime
            if ($lastRun -isnot [datetime]) { throw 'Current last-run type differs' }
            if ($owner -isnot [string] -or $owner -cne $subject.owner -or
                (Resolve-OwnerSid $owner) -cne $currentSid -or
                ('\' + [string]$name) -cne $subject.name -or $state -ne $subject.state -or
                $result -ne $subject.last_result -or $instances -ne 0 -or
                $lastRun.ToString('o') -cne $subject.last_run_time -or
                $lastRun.Kind.ToString() -cne $subject.last_run_kind) {
                $record.subject_match = 'changed'
                continue
            }
            $record.subject_match = 'matched_retained_metadata'
            $stage = 'exec_shape'
            $xmlBefore = $task.Xml
            if ($xmlBefore -isnot [string] -or $xmlBefore.Length -gt 262144) { throw 'Definition snapshot unavailable' }
            $actions = $definition.Actions
            if ((Require-NativeInt32 $actions.Count) -ne 1) { throw 'Action count changed' }
            $action = $actions.Item(1)
            if ((Require-NativeInt32 $action.Type) -ne 0) { throw 'Action type changed' }

            $rawExec = @{}
            foreach ($field in @('Path', 'Arguments', 'WorkingDirectory')) {
                try {
                    $value = $action.$field
                    $rawExec[$field] = $value
                    $description = Describe-Value $value
                    $record.exec_fields += [pscustomobject]@{
                        field = $field
                        outcome = 'read_returned'
                        runtime_type = $description.runtime_type
                        category = $description.category
                    }
                } catch {
                    $record.exec_fields += [pscustomobject]@{
                        field = $field
                        outcome = 'read_exception'
                        failure = (Describe-Error $_)
                    }
                }
            }
            if ($rawExec.Count -eq 3) {
                $admitted = $rawExec['Path'] -is [string] -and
                    ![string]::IsNullOrWhiteSpace($rawExec['Path']) -and
                    $rawExec['Arguments'] -is [string] -and $rawExec['WorkingDirectory'] -is [string]
                $record.existing_exec_predicate = if ($admitted) { 'would_accept' } else { 'would_reject' }
            } else { $record.existing_exec_predicate = 'getter_exception' }

            $stage = 'final_snapshot'
            $lastRunAfter = $task.LastRunTime
            if ($lastRunAfter -isnot [datetime]) { throw 'Repeated last-run type differs' }
            $changed = (Require-NativeInt32 $task.State) -ne $state -or
                (Require-NativeInt32 $task.LastTaskResult) -ne $result -or
                $lastRunAfter -ne $lastRun -or $lastRunAfter.Kind -ne $lastRun.Kind -or
                (Require-NativeInt32 ($task.GetInstances(0)).Count) -ne 0 -or
                [string]$task.Definition.Principal.UserId -cne $owner -or
                [string]$task.Xml -cne $xmlBefore -or [string]$task.Name -cne $name
            $record.final_snapshot = if ($changed) { 'changed' } else { 'stable_observed_fields' }
            $stage = 'owner_expression'
            $ownerShortName = ($owner.Trim() -split '\\')[-1]
            $compatible = [StringComparer]::OrdinalIgnoreCase.Equals($ownerShortName, $currentShortName.Trim())
            $record.owner_expression = if ($compatible) { 'compatible' } else { 'incompatible' }
        } catch {
            $record.failure_stage = $stage
            $record.failure = Describe-Error $_
        }
    }
    [pscustomobject]@{
        run_id = $runId
        mode = 'EXACT_RETAINED_EXEC_FIELD_DIAGNOSTIC'
        input_run_id = $sourceRunId
        input_sha256 = $actualHash
        requested_subject_count = 5
        diagnostic_records = $results
        scheduler_changes = $false
        public_go_calls = 0
        prior_definition_identity_available = $false
        historical_failure_cause_proven = $false
        native_qualification = $false
        execution_authorized = $false
    } | ConvertTo-Json -Depth 8 -Compress
} catch {
    [pscustomobject]@{
        run_id = $runId
        mode = 'EXACT_RETAINED_EXEC_FIELD_DIAGNOSTIC'
        diagnostic_failed = $true
        failure_stage = $stage
        failure = (Describe-Error $_)
        scheduler_changes = $false
        public_go_calls = 0
        execution_authorized = $false
    } | ConvertTo-Json -Depth 5 -Compress
    exit 1
}
