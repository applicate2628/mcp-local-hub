"""Verify one existing negative LastResult through the already bound public reader."""
from datetime import datetime, timezone
from pathlib import Path
import base64
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

if sys.flags.optimize or os.name != 'nt':
    raise SystemExit('Unoptimized Windows execution is required')
ROOT = Path(r'<NEGATIVE_ROOT>')
OLD_ROOT = Path(r'<REUSED_READER_ROOT>')
SOURCE = Path(r'<SOURCE_ROOT>')
HEAD = '9721681633440d3593d37ffb8f580e5d98440da2'
TREE = '016c9faa5aaedb3ed7db2e6b23066913824a4f09'
BINARY = OLD_ROOT / 'last-result-readonly.exe'
BINARY_SHA = '25d0d47edfda212512c36df614729eb81b49ef27bf8b2d4bbd21aaa021a66576'
PROBE_SHA = '951b34ef26eb98238efd2589bca29a36c074f4c0424984aa7ecd56f87a1410f1'
SNAPSHOT = ROOT / 'Snapshot-RetainedNegativeResult.ps1'
SNAPSHOT_SHA = 'a8016c27cd274ae14054acf99d21d601e3e511c203b1c4b0dd328ab0d9483498'
VALUE = -2147024894
GIT = r'<GIT_EXECUTABLE>'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    predicate = stat.S_ISDIR if directory else stat.S_ISREG
    if not predicate(info.st_mode) or info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise RuntimeError('Unexpected input/output type')


for path, is_dir in ((ROOT, True), (SOURCE, True), (SNAPSHOT, False),
                     (BINARY, False), (OLD_ROOT / 'probe.go', False)):
    ordinary(path, is_dir)
snapshot_bytes = SNAPSHOT.read_bytes()
if (hashlib.sha256(snapshot_bytes).hexdigest() != SNAPSHOT_SHA
        or digest(BINARY) != BINARY_SHA or digest(OLD_ROOT / 'probe.go') != PROBE_SHA):
    raise SystemExit('Pinned source/binary mismatch')
prep = json.loads((OLD_ROOT / 'prepare-v2/receipt.json').read_text())
if (prep.get('success') is not True or prep.get('negative_admission_control') is not True
        or prep.get('head') != HEAD or prep.get('tree') != TREE
        or prep.get('binary_sha256') != BINARY_SHA or prep.get('probe_source_sha256') != PROBE_SHA):
    raise SystemExit('Original reader preparation identity mismatch')
runtime = ROOT / 'runtime'
runtime.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith(('MCPHUB_', 'GIT_'))}
for name in ('tmp', 'profile', 'appdata', 'localappdata', 'empty-hooks'):
    (runtime / name).mkdir(exist_ok=False)
for key, name in [('TEMP', 'tmp'), ('TMP', 'tmp'), ('TMPDIR', 'tmp'),
                  ('USERPROFILE', 'profile'), ('APPDATA', 'appdata'), ('LOCALAPPDATA', 'localappdata')]:
    env[key] = str(runtime / name)
env.update({'PSModuleAnalysisCachePath': str(runtime / 'localappdata/module-analysis-cache'),
            'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': str(runtime / 'no-global-git-config'),
            'GIT_OPTIONAL_LOCKS': '0', 'GIT_TERMINAL_PROMPT': '0', 'MCPHUB_NO_AUTO_GUI': '1'})
system = Path(env.get('SYSTEMROOT') or env['SystemRoot'])
ps = system / 'System32/WindowsPowerShell/v1.0/powershell.exe'
env['PATH'] = os.pathsep.join((str(ps.parent), str(system / 'System32')))
receipt = {'run_id': 'r17-lastresult-negative-read-20261120-01', 'head': HEAD, 'tree': TREE,
           'runner_sha256': digest(Path(__file__)), 'snapshot_sha256': SNAPSHOT_SHA,
           'probe_source_sha256': PROBE_SHA, 'binary_sha256': BINARY_SHA,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
           'scheduler_changes': False, 'public_go_calls': 0, 'binary_rebuilt': False,
           'output_acl_verified': False, 'completed_action_exit_qualified': False,
           'full_native_qualification': False, 'atomic_snapshot_claimed': False,
           'whole_process_tree_deadline_enforced': False, 'global_enumeration_complete_claimed': False}


def save():
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


def source_state():
    def git(*args):
        return subprocess.check_output([GIT, '-c', 'core.hooksPath=' + str(runtime / 'empty-hooks'),
                                        '-C', str(SOURCE), *args], env=env, timeout=90).decode('utf-8').strip()
    if Path(git('rev-parse', '--show-toplevel')).resolve() != SOURCE.resolve():
        raise RuntimeError('Source root mismatch')
    result = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'status': git('status', '--porcelain=v1', '--untracked-files=all')}
    if result != {'head': HEAD, 'tree': TREE, 'status': ''}:
        raise RuntimeError('Original reader source is not the bound clean tree')
    return result


def saved_snapshot(phase):
    path = ROOT / (phase + '-private.json')
    ordinary(path)
    raw = path.read_bytes()
    public = json.loads((ROOT / ('snapshot-' + phase + '.stdout.log')).read_bytes().decode('utf-8-sig'))
    if (public.get('run_id') != receipt['run_id'] or public.get('phase') != phase
            or public.get('pass') is not True or public.get('retained_subject_matched') is not True
            or public.get('stable_within_phase') is not True or public.get('visible_prefix_matches') != 1
            or public.get('negative_native_int32') is not True or public.get('scheduler_changes') is not False
            or public.get('ownership_census_complete') is not False
            or public.get('completed_action_exit_qualified') is not False
            or public.get('private_snapshot_sha256') != hashlib.sha256(raw).hexdigest()
            or (phase == 'after' and public.get('before_snapshot_identical') is not True)):
        raise RuntimeError('Saved snapshot summary binding failed')
    receipt.setdefault('snapshots', {})[phase] = public
    save()
    return json.loads(raw.decode('utf-8-sig'))


def run(name, executable, args, input_bytes=None, phase=None):
    child_env = dict(env)
    if phase is not None:
        child_env['R17_NEGATIVE_SNAPSHOT_PHASE'] = phase
    rec = {'name': name, 'executable': executable.name, 'settled': False,
           'direct_child_deadline_seconds': 60, 'started_utc': datetime.now(timezone.utc).isoformat()}
    receipt['commands'].append(rec)
    save()
    started = time.monotonic()
    with (ROOT / (name + '.stdout.log')).open('xb') as fo, \
         (ROOT / (name + '.stderr.log')).open('xb') as fe:
        child = subprocess.Popen([str(executable), *args], cwd=ROOT, env=child_env,
                                 stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,
                                 stdout=fo, stderr=fe, creationflags=0x08000000)
        try:
            rec['pid'] = child.pid
            if name == 'public-go-reads':
                receipt['public_reader_started'] = True
                receipt['public_go_calls'] = None
            save()
            child.communicate(input=input_bytes, timeout=max(0, 60 - (time.monotonic() - started)))
        finally:
            if child.poll() is None:
                try:
                    child.wait(timeout=max(0, 60 - (time.monotonic() - started)))
                except subprocess.TimeoutExpired:
                    rec['direct_child_deadline_hit'] = True
                    child.kill()
                    child.wait(timeout=15)
            if child.stdin is not None and not child.stdin.closed:
                child.stdin.close()
            rec['exit_code'] = child.returncode
            rec['settled'] = child.returncode is not None
            save()
    rec['seconds'] = round(time.monotonic() - started, 6)
    for stream in ('stdout', 'stderr'):
        data = (ROOT / (name + '.' + stream + '.log')).read_bytes()
        rec[stream + '_bytes'] = len(data)
        rec[stream + '_sha256'] = hashlib.sha256(data).hexdigest()
    if name == 'public-go-reads':
        try:
            events = [json.loads(line) for line in
                      (ROOT / (name + '.stdout.log')).read_text(encoding='utf-8').splitlines()]
            receipt['public_go_begin_events'] = sum(event.get('event') == 'begin' for event in events)
        except (ValueError, UnicodeError):
            receipt['public_go_begin_events'] = None
    save()
    if rec['exit_code'] or rec['stderr_bytes'] or rec.get('direct_child_deadline_hit'):
        raise RuntimeError('Read-only command failed or exceeded its direct-child deadline: ' + name)
    return rec


try:
    receipt['source_before'] = source_state()
    encoded = base64.b64encode(snapshot_bytes).decode('ascii')
    syntax = ("$ErrorActionPreference='Stop'; $tokens=$null; $errors=$null; "
              "$source=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "')); "
              "$null=[Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors); "
              "if($errors.Count -ne 0){exit 1}; [Console]::WriteLine('SYNTAX_PASS'); exit 0")
    run('syntax', ps, ['-NoProfile', '-NonInteractive', '-Command', syntax])
    protect = "$ErrorActionPreference='Stop'; $root='" + str(ROOT) + "';\n" + r"""
try {
    $attributes = [IO.File]::GetAttributes($root)
    if (($attributes -band [IO.FileAttributes]::ReparsePoint) -or
        !($attributes -band [IO.FileAttributes]::Directory)) { throw 'Unexpected root type' }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if ($null -eq $identity.User) { throw 'No current user' }
        $allowed = @{}
        foreach ($sid in @($identity.User.Value,'S-1-5-18','S-1-5-32-544')) { $allowed[$sid]=$true }
    } finally { $identity.Dispose() }
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
               [Security.AccessControl.InheritanceFlags]::ObjectInherit
    $rights = [Security.AccessControl.FileSystemRights]::FullControl
    $propagation = [Security.AccessControl.PropagationFlags]::None
    $allow = [Security.AccessControl.AccessControlType]::Allow
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true,$false)
    foreach ($sid in $allowed.Keys) {
        $principal = [Security.Principal.SecurityIdentifier]::new($sid)
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $principal,$rights,$inherit,$propagation,$allow))
    }
    [IO.Directory]::SetAccessControl($root,$acl)
    $actual = [IO.Directory]::GetAccessControl($root,[Security.AccessControl.AccessControlSections]::Access)
    $rules = $actual.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])
    if (!$actual.AreAccessRulesProtected -or $rules.Count -ne $allowed.Count) { throw 'Unexpected ACL' }
    $seen = @{}
    foreach ($rule in $rules) {
        $sid=$rule.IdentityReference.Value
        if (!$allowed.ContainsKey($sid) -or $seen.ContainsKey($sid) -or $rule.IsInherited -or
            $rule.AccessControlType -ne $allow -or $rule.FileSystemRights -ne $rights -or
            $rule.InheritanceFlags -ne $inherit -or $rule.PropagationFlags -ne $propagation) {
            throw 'Unexpected access rule'
        }
        $seen[$sid]=$true
    }
    [Console]::WriteLine('OUTPUT_ACL_VERIFIED'); exit 0
} catch { [Console]::Error.WriteLine('Output access preparation failed'); exit 1 }
"""
    run('prepare-output', ps, ['-NoProfile', '-NonInteractive', '-Command', protect])
    if (ROOT / 'prepare-output.stdout.log').read_bytes().decode('utf-8-sig').strip() != 'OUTPUT_ACL_VERIFIED':
        raise RuntimeError('Output ACL acknowledgement mismatch')
    receipt['output_acl_verified'] = True
    save()
    run('snapshot-before', ps, ['-NoProfile', '-NonInteractive', '-Command', snapshot_bytes.decode('utf-8')], phase='before')
    before = saved_snapshot('before')
    if before['head'] != HEAD or before['last_result'] != VALUE or before['result_runtime_type'] != 'System.Int32':
        raise RuntimeError('Negative input identity mismatch')
    manifest = {key: before[key] for key in ('head', 'name', 'prefix', 'owner', 'state', 'last_result')}
    payload = json.dumps(manifest, ensure_ascii=False).encode('utf-8')
    with (ROOT / 'manifest-private.json').open('xb') as output:
        output.write(payload)
    run('public-go-reads', BINARY, [], input_bytes=payload)
    run('snapshot-after', ps, ['-NoProfile', '-NonInteractive', '-Command', snapshot_bytes.decode('utf-8')], phase='after')
    after = saved_snapshot('after')
    receipt['stable_private_snapshots'] = before == after
    events = [json.loads(line) for line in (ROOT / 'public-go-reads.stdout.log').read_text(encoding='utf-8').splitlines()]
    results = [event for event in events if event.get('event') == 'result']
    passed = (len(events) == 5 and [e.get('check') for e in results] == ['status', 'list']
              and all(e.get('pass') is True and e.get('observed_last_result') == VALUE
                      and e.get('observed_last_result_type') == 'int' for e in results)
              and events[-1].get('event') == 'overall' and events[-1].get('pass') is True
              and events[-1].get('backend_type') == '*scheduler.windowsScheduler'
              and events[-1].get('completed_task_exit_qualified') is False
              and events[-1].get('full_native_qualification') is False)
    if not passed or not receipt['stable_private_snapshots']:
        raise RuntimeError('Public reads or snapshot equality failed')
    receipt['public_go_calls'] = 2
    receipt['public_reads_passed'] = True
    receipt['last_result_observed'] = VALUE
    receipt['binary_sha256_after'] = digest(BINARY)
    if receipt['binary_sha256_after'] != BINARY_SHA or digest(OLD_ROOT / 'probe.go') != PROBE_SHA:
        raise RuntimeError('Reader changed during verification')
    receipt['source_after'] = source_state()
    receipt['completed'] = True
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(receipt), flush=True)
