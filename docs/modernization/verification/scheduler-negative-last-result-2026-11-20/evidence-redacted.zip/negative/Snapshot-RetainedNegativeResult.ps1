# Prepared source only. The controller owns the fresh protected D: root,
# captured source, bounded child lifecycle and the two public reader calls.
# This script performs only Task Scheduler reads and exclusive evidence writes.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$utf8 = [Text.UTF8Encoding]::new($false, $true)
[Console]::OutputEncoding = $utf8
$runId = 'r17-lastresult-negative-read-20261120-01'
$root = '<NEGATIVE_ROOT>'
$head = '9721681633440d3593d37ffb8f580e5d98440da2'
$inputRunId = 'r17-lastresult-existing-candidates-20261120-01'
$inputPath = '<EXISTING_ROOT>\candidates-private.json'
$inputHash = '405118b749e50fb1f30de62c93e24f1ad72d040291ef40d7cab1e2eb831bc43d'
$observationId = 'observation-004'
$expectedResult = [int32]-2147024894
$maximumTasks = 128
$phase = $env:R17_NEGATIVE_SNAPSHOT_PHASE
$stage = 'phase'

function Read-OrdinaryBytes([string]$Path, [long]$MaximumBytes) {
    $info = Get-Item -LiteralPath $Path
    if ($info.PSIsContainer -or ($info.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        $info.Length -gt $MaximumBytes) { throw 'Expected ordinary bounded input' }
    $bytes = [IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -gt $MaximumBytes) { throw 'Input grew beyond its bound' }
    return ,$bytes
}

function Get-BytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Convert-JsonBytes($Value) {
    $bytes = $utf8.GetBytes(($Value | ConvertTo-Json -Depth 5) + "`n")
    if ($bytes.Length -gt 4194304) { throw 'Evidence exceeds its bound' }
    return ,$bytes
}

function Write-NewBytes([string]$Path, [byte[]]$Bytes) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($Bytes, 0, $Bytes.Length) } finally { $stream.Dispose() }
}

function Require-Int32($Value) {
    if ($null -eq $Value -or $Value.GetType().FullName -cne 'System.Int32') {
        throw 'Expected exact native Int32'
    }
    return $Value
}

function Resolve-OwnerSid([string]$Owner) {
    if ([string]::IsNullOrWhiteSpace($Owner)) { throw 'Unknown principal' }
    if ($Owner.StartsWith('S-1-', [StringComparison]::OrdinalIgnoreCase)) {
        return ([Security.Principal.SecurityIdentifier]::new($Owner)).Value
    }
    return ([Security.Principal.NTAccount]::new($Owner)).Translate([Security.Principal.SecurityIdentifier]).Value
}

function Read-TargetSnapshot {
    $task = $folder.GetTask($prefix)
    $name = $task.Name
    $xml = $task.Xml
    $definition = $task.Definition
    $owner = $definition.Principal.UserId
    if ($name -isnot [string] -or $name -cne $prefix -or
        $owner -isnot [string] -or $owner -cne $expected.owner -or
        $xml -isnot [string] -or [string]::IsNullOrWhiteSpace($xml) -or $xml.Length -gt 262144) {
        throw 'Target identity or definition differs'
    }
    $ownerSid = Resolve-OwnerSid $owner
    if ($ownerSid -cne $currentSid) { throw 'Target principal is not the current identity' }
    $ownerShortName = ($owner.Trim() -split '\\')[-1]
    if (![StringComparer]::OrdinalIgnoreCase.Equals($ownerShortName, $currentShortName.Trim())) {
        throw 'Target principal is incompatible with the public List owner filter'
    }
    $state = Require-Int32 $task.State
    $instances = Require-Int32 ($task.GetInstances(0)).Count
    $value = Require-Int32 $task.LastTaskResult
    if ($state -ne 3 -or $instances -ne 0 -or $value -ne $expectedResult -or $value -ge 0) {
        throw 'Target is not the retained idle negative result'
    }
    $lastRun = $task.LastRunTime
    if ($null -eq $lastRun -or $lastRun.GetType().FullName -cne 'System.DateTime' -or
        $lastRun.Kind.ToString() -cne $expected.last_run_kind -or
        $lastRun.Ticks -ne $expectedLastRun.Ticks -or
        $lastRun.ToString('o') -cne $expected.last_run_time) {
        throw 'Last-run type, Kind or retained value differs'
    }
    $hidden = $definition.Settings.Hidden
    if ($hidden -isnot [bool] -or $hidden) { throw 'Target is not visibly registered' }
    $actions = $definition.Actions
    $actionCount = Require-Int32 $actions.Count
    if ($actionCount -ne 1) { throw 'Expected exactly one registered action' }
    $action = $actions.Item(1)
    $actionType = Require-Int32 $action.Type
    $actionPath = $action.Path
    if ($actionType -ne 0 -or $actionPath -isnot [string] -or [string]::IsNullOrWhiteSpace($actionPath)) {
        throw 'Expected one Exec action with a nonempty Path'
    }
    # Arguments and WorkingDirectory are deliberately not read or coerced.
    # XML preserves the registered definition; no action execution is inferred.
    return [pscustomobject][ordered]@{
        run_id = $runId
        input_run_id = $inputRunId
        input_sha256 = $inputHash
        observation_id = $observationId
        head = $head
        name = '\' + $name
        prefix = $name
        prefix_comparison_culture = [Globalization.CultureInfo]::CurrentCulture.Name
        owner = $owner
        owner_sid = $ownerSid
        current_identity_name = $currentName
        current_identity_sid = $currentSid
        state = $state
        last_result = $value
        result_runtime_type = $value.GetType().FullName
        last_run_runtime_type = $lastRun.GetType().FullName
        last_run_ticks = $lastRun.Ticks
        last_run_time = $lastRun.ToString('o')
        last_run_kind = $lastRun.Kind.ToString()
        hidden = $hidden
        instance_count = $instances
        action_count = $actionCount
        action_type = $actionType
        action_path = $actionPath
        xml = $xml
    }
}

try {
    if ($phase -cnotin @('before', 'after')) { throw 'Invalid snapshot phase' }
    $stage = 'output_root'
    $directory = Get-Item -LiteralPath $root
    if (!$directory.PSIsContainer -or ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Output root must be an ordinary protected directory'
    }
    $privatePath = Join-Path $root ($phase + '-private.json')
    $claimPath = Join-Path $root ($phase + '-claim.json')
    if ((Test-Path -LiteralPath $privatePath) -or (Test-Path -LiteralPath $claimPath)) {
        throw 'This snapshot phase has already been attempted'
    }
    $beforeBytes = $null
    if ($phase -ceq 'before') {
        if ((Test-Path -LiteralPath (Join-Path $root 'after-private.json')) -or
            (Test-Path -LiteralPath (Join-Path $root 'after-claim.json'))) { throw 'Phase order differs' }
    } else {
        $beforeBytes = Read-OrdinaryBytes (Join-Path $root 'before-private.json') 4194304
    }
    Write-NewBytes $claimPath (Convert-JsonBytes ([ordered]@{
        run_id = $runId; phase = $phase; input_sha256 = $inputHash
        started_utc = [datetime]::UtcNow.ToString('o'); scheduler_changes = $false
    }))
    $stage = 'retained_input'
    $inputBytes = Read-OrdinaryBytes $inputPath 65536
    if ((Get-BytesHash $inputBytes) -cne $inputHash) { throw 'Retained input hash differs' }
    $saved = $utf8.GetString($inputBytes) | ConvertFrom-Json
    if ($saved.run_id -cne $inputRunId) { throw 'Retained input run differs' }
    $subjects = @($saved.nonstatus_observations | Where-Object { $_.observation_id -ceq $observationId })
    if ($subjects.Count -ne 1) { throw 'Expected one retained subject' }
    $expected = $subjects[0]
    if ($expected.name -isnot [string] -or $expected.name -cnotmatch '^\\[^\\/]+$' -or
        $expected.owner -isnot [string] -or [string]::IsNullOrWhiteSpace($expected.owner) -or
        $expected.state -ne 3 -or $expected.last_result -ne $expectedResult -or
        $expected.result_runtime_type -cne 'System.Int32' -or $expected.outcome -cne 'query_failure' -or
        $expected.action_count -ne 1 -or $expected.action_type -ne 0 -or
        $expected.last_run_time -isnot [string] -or $expected.last_run_kind -cne 'Unspecified') {
        throw 'Retained subject metadata differs'
    }
    $prefix = $expected.name.Substring(1)
    if ([string]::IsNullOrWhiteSpace($prefix)) { throw 'Empty retained prefix' }
    $expectedLastRun = [datetime]::ParseExact($expected.last_run_time, 'o',
        [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind)
    if ($expectedLastRun.Kind.ToString() -cne 'Unspecified' -or
        $expectedLastRun -lt [datetime]::new(2000, 1, 1) -or
        $expectedLastRun -gt [datetime]::Now.AddMinutes(5)) { throw 'Retained date is outside the admission bound' }
    $stage = 'identity'
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if ($null -eq $identity.User -or [string]::IsNullOrWhiteSpace($identity.Name)) {
            throw 'Current identity unavailable'
        }
        $currentSid = $identity.User.Value
        $currentName = $identity.Name
        $currentShortName = ($currentName -split '\\')[-1]
    } finally { $identity.Dispose() }
    $stage = 'connection'
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $folder = $service.GetFolder('\')
    $stage = 'target_first_read'
    $firstBytes = Convert-JsonBytes (Read-TargetSnapshot)
    $stage = 'visible_prefix_names'
    $visible = $folder.GetTasks(0)
    $visibleCount = Require-Int32 $visible.Count
    if ($visibleCount -lt 1 -or $visibleCount -gt $maximumTasks) { throw 'Visible name-count budget differs' }
    $prefixMatches = 0
    $exactMatches = 0
    for ($index = 1; $index -le $visibleCount; $index++) {
        # Read names only for other tasks. Do not query or interpret their owners.
        $visibleName = ($visible.Item($index)).Name
        if ($visibleName -isnot [string] -or [string]::IsNullOrWhiteSpace($visibleName) -or
            $visibleName.IndexOfAny([char[]]'\/') -ge 0) { throw 'Visible root name unavailable' }
        # Match pinned production List's current-culture StartsWith overload.
        if ($visibleName.StartsWith($prefix)) { $prefixMatches++ }
        if ($visibleName -ceq $prefix) { $exactMatches++ }
    }
    if ((Require-Int32 $visible.Count) -ne $visibleCount -or $prefixMatches -ne 1 -or $exactMatches -ne 1) {
        throw 'Visible prefix is not uniquely the retained target'
    }
    $stage = 'target_repeated_read'
    $snapshotBytes = Convert-JsonBytes (Read-TargetSnapshot)
    $snapshotHash = Get-BytesHash $snapshotBytes
    if ($snapshotHash -cne (Get-BytesHash $firstBytes)) { throw 'Target fields changed during this snapshot' }
    $stage = 'private_snapshot'
    Write-NewBytes $privatePath $snapshotBytes
    $matchesBefore = if ($phase -ceq 'after') { (Get-BytesHash $beforeBytes) -ceq $snapshotHash } else { $null }
    $pass = $phase -ceq 'before' -or $matchesBefore
    [pscustomobject][ordered]@{
        run_id = $runId
        phase = $phase
        pass = $pass
        observation_id = $observationId
        input_sha256 = $inputHash
        private_snapshot_sha256 = $snapshotHash
        retained_subject_matched = $true
        stable_within_phase = $true
        before_snapshot_identical = $matchesBefore
        visible_root_names_counted = $visibleCount
        visible_prefix_matches = $prefixMatches
        negative_native_int32 = $true
        ownership_census_complete = $false
        unrelated_principals_interpreted = $false
        scheduler_changes = $false
        public_go_calls = 0
        completed_action_exit_qualified = $false
        full_native_qualification = $false
        atomic_snapshot_claimed = $false
        whole_process_tree_qualification = $false
    } | ConvertTo-Json -Depth 4 -Compress
    if (!$pass) { exit 2 }
} catch {
    [pscustomobject]@{
        run_id = $runId
        phase = if ($phase -cin @('before', 'after')) { $phase } else { 'invalid' }
        pass = $false
        failure_stage = $stage
        exception_type = $_.Exception.GetType().FullName
        error_category = $_.CategoryInfo.Category.ToString()
        ownership_census_complete = $false
        scheduler_changes = $false
        public_go_calls = 0
        completed_action_exit_qualified = $false
        full_native_qualification = $false
        atomic_snapshot_claimed = $false
        whole_process_tree_qualification = $false
    } | ConvertTo-Json -Depth 4 -Compress
    exit 1
}
