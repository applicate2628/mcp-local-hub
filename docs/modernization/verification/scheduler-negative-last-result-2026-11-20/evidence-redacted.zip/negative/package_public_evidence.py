"""Package three completed series of public native-read evidence, saved files only.

Run after the negative controller completes, from its fresh task-owned root.
No subprocess, Git, Scheduler, binary, private JSON, source-cache, or process
snapshot access. Only the fixed public allowlist below may be opened. Existing
outputs/attempts are preserved; all four output files are created exclusively.
"""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import zipfile

IDS = {
    'existing': 'r17-lastresult-existing-candidates-20261120-01',
    'diagnostic': 'r17-lastresult-exec-fields-diagnostic-20261120-01',
    'negative': 'r17-lastresult-negative-read-20261120-01',
}
ROOTS = {kind: Path('<OWNED_WORK_ROOT>/mcp-' + run_id) for kind, run_id in IDS.items()}
ROOT = ROOTS['negative']
HEAD = '9721681633440d3593d37ffb8f580e5d98440da2'
TREE = '016c9faa5aaedb3ed7db2e6b23066913824a4f09'
VALUE = -2147024894
CLAIM = 'observed_native_last_result_transfer_only'
BINARY_SHA = '25d0d47edfda212512c36df614729eb81b49ef27bf8b2d4bbd21aaa021a66576'
PROBE_SHA = '951b34ef26eb98238efd2589bca29a36c074f4c0424984aa7ecd56f87a1410f1'
INPUT_SHA = '405118b749e50fb1f30de62c93e24f1ad72d040291ef40d7cab1e2eb831bc43d'
SNAPSHOT_SHA = '119928aada217c0c86e2e559ca6e6b02979e5bd1e47960474201ad92a5b86d70'
SCRIPTS = {
    ('existing', 'Observe-ExistingLastResultCandidates.ps1'): '486a7c138f3d9fa12a43b8d6d0480d227741a3b16f30b9d3a5efc52c68882acb',
    ('existing', 'run_observation.py'): '8adb3fc9896e59afb9baf6835dbeb76143e3ccc97ec317d542b343ddce313ae1',
    ('diagnostic', 'Diagnose-RetainedExecFields.ps1'): '2b6050ac622945d818b799c10ceb1be5940723fed890751f75d768331a675709',
    ('diagnostic', 'run_exec_diagnostic.py'): '2dbfcad179b1a799312644104f1a6d1d78d14aeb569178a0eb18c083155df3c2',
    ('negative', 'Snapshot-RetainedNegativeResult.ps1'): 'a8016c27cd274ae14054acf99d21d601e3e511c203b1c4b0dd328ab0d9483498',
    ('negative', 'run_negative_read.py'): '33d393d4becbf40fcb7657418df3298a5ff8dde179ba93ff7e5161160d67870d',
}
COMMANDS = {
    'existing': [('syntax', 0), ('prepare-output', 0), ('observation', 2)],
    'diagnostic': [('syntax', 0), ('diagnostic', 0)],
    'negative': [('syntax', 0), ('prepare-output', 0), ('snapshot-before', 0),
                 ('public-go-reads', 0), ('snapshot-after', 0)],
}
RECEIPTS = {'existing': 'observation-receipt.json', 'diagnostic': 'receipt.json', 'negative': 'receipt.json'}
ALLOWLIST = set(SCRIPTS) | {(kind, name) for kind, name in RECEIPTS.items()} | {
    ('existing', 'summary.json'), ('negative', 'package_public_evidence.py'),
} | {(kind, name + '.' + stream + '.log') for kind, specs in COMMANDS.items()
     for name, _ in specs for stream in ('stdout', 'stderr')}
JSON_LOGS = {
    ('existing', 'observation.stdout.log'), ('diagnostic', 'diagnostic.stdout.log'),
    ('negative', 'snapshot-before.stdout.log'), ('negative', 'snapshot-after.stdout.log'),
    ('negative', 'public-go-reads.stdout.log'),
}
OUTPUTS = ('execution-summary.json', 'archive-metadata.json', 'evidence-redacted.zip', 'evidence-redacted.base64.txt')
raw_files, stream_checks = {}, {}


class EvidenceError(Exception):
    pass


def need(condition, label):
    if not condition:
        raise EvidenceError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path, directory=False):
    info = path.lstat()
    predicate = stat.S_ISDIR if directory else stat.S_ISREG
    need(predicate(info.st_mode) and not info.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT,
         'nonordinary_public_input')
    return info


def read_uncached(key):
    # Check before inspecting the filesystem, including during the final reread.
    need(key in ALLOWLIST, 'input_not_on_public_allowlist')
    kind, name = key
    ordinary(ROOTS[kind], True)
    path = ROOTS[kind] / name
    need(ordinary(path).st_size <= 4 * 1024 * 1024, 'public_input_size_bound')
    data = path.read_bytes()
    need(len(data) <= 4 * 1024 * 1024, 'public_input_grew_beyond_bound')
    return data


def read(kind, name):
    key = (kind, name)
    if key not in raw_files:
        raw_files[key] = read_uncached(key)
    return raw_files[key]


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'duplicate_json_key')
        value[key] = item
    return value


def reject_constant(_):
    raise EvidenceError('nonfinite_json_number')


def parse(data):
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=unique_object, parse_constant=reject_constant)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def integer(value, expected=None):
    return type(value) is int and (expected is None or value == expected)


def instant(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.utcoffset() is not None, 'timestamp_without_timezone')
    return result


def expect(value, fixed, extra=()):
    """Closed public schema: extra keys may not smuggle identity/definition data."""
    need(type(value) is dict and set(value) == set(fixed) | set(extra), 'unexpected_public_schema')
    need(all(type(value[key]) is type(item) and value[key] == item for key, item in fixed.items()),
         'unexpected_public_value')


def public_json(kind, name):
    return parse(read(kind, name))


def check_commands(kind, receipt):
    commands = receipt['commands']
    need(type(commands) is list and [item['name'] for item in commands] == [name for name, _ in COMMANDS[kind]],
         'command_order: ' + kind)
    start, finish = instant(receipt['started_utc']), instant(receipt['finished_utc'])
    need(start <= finish, 'series_time: ' + kind)
    previous = start
    for record, (name, code) in zip(commands, COMMANDS[kind]):
        fixed = {'name': name, 'settled': True, 'direct_child_deadline_seconds': 60, 'exit_code': code}
        if kind == 'negative':
            fixed['executable'] = 'last-result-readonly.exe' if name == 'public-go-reads' else 'powershell.exe'
        extra = {'pid', 'seconds', 'stdout_bytes', 'stdout_sha256', 'stderr_bytes', 'stderr_sha256'}
        if kind != 'diagnostic':
            extra.add('started_utc')
        expect(record, fixed, extra)
        need(integer(record['pid']) and record['pid'] > 0 and type(record['seconds']) in (int, float)
             and math.isfinite(record['seconds']) and record['seconds'] >= 0, 'command_identity_or_duration')
        if kind != 'diagnostic':
            started = instant(record['started_utc'])
            need(previous <= started <= finish, 'command_time')
            previous = started
        for stream in ('stdout', 'stderr'):
            filename = name + '.' + stream + '.log'
            raw = read(kind, filename)
            need(integer(record[stream + '_bytes'], len(raw)) and record[stream + '_sha256'] == sha(raw),
                 'stream_binding: ' + kind + '/' + filename)
            if stream == 'stderr':
                need(raw == b'', 'nonempty_public_stderr')
            stream_checks[kind + '/' + filename] = {'source_bytes': len(raw), 'source_sha256': sha(raw)}
        if name in ('syntax', 'prepare-output'):
            token = 'SYNTAX_PASS' if name == 'syntax' else 'OUTPUT_ACL_VERIFIED'
            need(read(kind, name + '.stdout.log').decode('utf-8-sig').strip() == token, 'command_acknowledgement')


def validate():
    for (kind, name), expected in SCRIPTS.items():
        need(sha(read(kind, name)) == expected, 'script_pin: ' + kind + '/' + name)
    receipts = {kind: public_json(kind, name) for kind, name in RECEIPTS.items()}
    existing, diagnostic, negative = (receipts[kind] for kind in ('existing', 'diagnostic', 'negative'))
    common = {'completed': True, 'scheduler_changes': False}
    times = {'commands', 'started_utc', 'finished_utc'}
    expect(existing, {**common, 'run_id': IDS['existing'], 'public_go_calls': 0,
                     'source_sha256': SCRIPTS['existing', 'Observe-ExistingLastResultCandidates.ps1'],
                     'runner_sha256': SCRIPTS['existing', 'run_observation.py'],
                     'whole_process_tree_qualification': False, 'output_acl_verified': True,
                     'outcome': 'INCOMPLETE_OBSERVATION'}, times | {'summary'})
    expect(diagnostic, {**common, 'run_id': IDS['diagnostic'], 'public_go_calls': 0, 'input_sha256': INPUT_SHA,
                       'source_sha256': SCRIPTS['diagnostic', 'Diagnose-RetainedExecFields.ps1'],
                       'runner_sha256': SCRIPTS['diagnostic', 'run_exec_diagnostic.py'],
                       'whole_process_tree_qualification': False}, times | {'summary'})
    expect(negative, {**common, 'run_id': IDS['negative'], 'head': HEAD, 'tree': TREE,
                     'runner_sha256': SCRIPTS['negative', 'run_negative_read.py'],
                     'snapshot_sha256': SCRIPTS['negative', 'Snapshot-RetainedNegativeResult.ps1'],
                     'probe_source_sha256': PROBE_SHA, 'binary_sha256': BINARY_SHA, 'binary_sha256_after': BINARY_SHA,
                     'binary_rebuilt': False, 'output_acl_verified': True, 'public_go_calls': 2,
                     'public_go_begin_events': 2, 'public_reader_started': True, 'public_reads_passed': True,
                     'last_result_observed': VALUE, 'stable_private_snapshots': True,
                     'completed_action_exit_qualified': False, 'full_native_qualification': False,
                     'atomic_snapshot_claimed': False, 'whole_process_tree_deadline_enforced': False,
                     'global_enumeration_complete_claimed': False}, times | {'source_before', 'source_after', 'snapshots'})
    for kind, receipt in receipts.items():
        check_commands(kind, receipt)
    need(instant(existing['finished_utc']) <= instant(diagnostic['started_utc'])
         and instant(diagnostic['finished_utc']) <= instant(negative['started_utc']), 'series_chronology')

    observed = public_json('existing', 'observation.stdout.log')
    need(observed == existing['summary'] == public_json('existing', 'summary.json'), 'initial_summary_binding')
    expect(observed, {
        'run_id': IDS['existing'], 'mode': 'READ_ONLY_EXISTING_CANDIDATE_OBSERVATION',
        'enumeration_complete': False, 'candidate_count': 0, 'nonstatus_observation_count': 5, 'candidates': [],
        'eligible_for_contract_review': False, 'execution_authorized': False,
        'minimum_last_run_policy': '2000-01-01 local/observed DATE; reject future by over 5 minutes',
        'action_admission_policy': 'one registered Exec action with nonempty Path; other nonstatus values retained privately',
        'maximum_visible_tasks': 128, 'scheduler_changes': False, 'public_go_calls': 0,
        'completed_action_exit_qualified': False, 'full_native_qualification': False,
        'atomic_snapshot_claimed': False, 'in_process_deadline_enforced': False,
    }, {'counts', 'started_utc', 'finished_utc'})
    counts = observed['counts']
    count_names = {'visible_root_tasks', 'same_account_tasks', 'other_account_tasks', 'identity_unknown',
                   'query_failures', 'non_idle', 'zero_result', 'scheduler_status_range',
                   'negative_nonstatus_observed', 'positive_nonstatus_observed',
                   'invalid_or_sentinel_last_run', 'unsupported_action_shape', 'changed_during_read'}
    need(type(counts) is dict and set(counts) == count_names
         and all(integer(value) and value >= 0 for value in counts.values())
         and counts['query_failures'] == 5 and counts['visible_root_tasks'] <= 128, 'initial_counts')
    need(instant(existing['started_utc']) <= instant(observed['started_utc']) <= instant(observed['finished_utc'])
         <= instant(existing['finished_utc']), 'initial_summary_time')

    diagnosis = public_json('diagnostic', 'diagnostic.stdout.log')
    need(diagnosis == diagnostic['summary'], 'diagnostic_summary_binding')
    expect(diagnosis, {
        'run_id': IDS['diagnostic'], 'mode': 'EXACT_RETAINED_EXEC_FIELD_DIAGNOSTIC',
        'input_run_id': IDS['existing'], 'input_sha256': INPUT_SHA, 'requested_subject_count': 5,
        'scheduler_changes': False, 'public_go_calls': 0, 'prior_definition_identity_available': False,
        'historical_failure_cause_proven': False, 'native_qualification': False, 'execution_authorized': False,
    }, {'diagnostic_records'})
    records = diagnosis['diagnostic_records']
    need(type(records) is list and len(records) == 5, 'diagnostic_record_count')
    for number, record in enumerate(records, 1):
        expect(record, {'observation_id': 'observation-' + format(number, '03d'),
                        'subject_match': 'matched_retained_metadata', 'existing_exec_predicate': 'would_reject',
                        'final_snapshot': 'stable_observed_fields', 'owner_expression': 'compatible',
                        'prefix_enumeration': 'not_in_scope', 'failure_stage': None, 'failure': None}, {'exec_fields'})
        fields = record['exec_fields']
        need(type(fields) is list and len(fields) == 3, 'diagnostic_exec_field_count')
        for field, name in zip(fields, ('Path', 'Arguments', 'WorkingDirectory')):
            expect(field, {'field': name, 'outcome': 'read_returned',
                           'runtime_type': 'null' if name == 'WorkingDirectory' else 'System.String',
                           'category': 'null' if name == 'WorkingDirectory' else 'nonempty_string'})

    state = {'head': HEAD, 'tree': TREE, 'status': ''}
    expect(negative['source_before'], state)
    expect(negative['source_after'], state)
    need(type(negative['snapshots']) is dict and set(negative['snapshots']) == {'before', 'after'}, 'snapshot_phases')
    for phase in ('before', 'after'):
        snapshot = public_json('negative', 'snapshot-' + phase + '.stdout.log')
        need(snapshot == negative['snapshots'][phase], 'snapshot_stdout_binding')
        expect(snapshot, {
            'run_id': IDS['negative'], 'phase': phase, 'pass': True, 'observation_id': 'observation-004',
            'input_sha256': INPUT_SHA, 'private_snapshot_sha256': SNAPSHOT_SHA,
            'retained_subject_matched': True, 'stable_within_phase': True,
            'before_snapshot_identical': True if phase == 'after' else None,
            'visible_prefix_matches': 1, 'negative_native_int32': True, 'ownership_census_complete': False,
            'unrelated_principals_interpreted': False, 'scheduler_changes': False, 'public_go_calls': 0,
            'completed_action_exit_qualified': False, 'full_native_qualification': False,
            'atomic_snapshot_claimed': False, 'whole_process_tree_qualification': False,
        }, {'visible_root_names_counted'})
        need(integer(snapshot['visible_root_names_counted']) and 1 <= snapshot['visible_root_names_counted'] <= 128,
             'snapshot_visible_name_count')
    lines = read('negative', 'public-go-reads.stdout.log').splitlines()
    need(len(lines) == 5 and all(line.strip() for line in lines), 'public_event_count')
    events = [parse(line) for line in lines]
    for offset, check in ((0, 'status'), (2, 'list')):
        expect(events[offset], {'event': 'begin', 'check': check})
        result = events[offset + 1]
        expect(result, {'event': 'result', 'check': check, 'pass': True, 'error_category': 'none',
                        'observed_last_result': VALUE, 'observed_last_result_type': 'int'}, {'duration_ns'})
        need(integer(result['duration_ns']) and result['duration_ns'] >= 0, 'public_duration')
    expect(events[-1], {'event': 'overall', 'status': 'PASS', 'pass': True,
                        'backend_type': '*scheduler.windowsScheduler', 'error_category': 'none',
                        'panic_recovered': False, 'claim': CLAIM,
                        'completed_task_exit_qualified': False, 'full_native_qualification': False}, {'duration_ns'})
    need(integer(events[-1]['duration_ns']) and events[-1]['duration_ns'] >= 0, 'overall_duration')
    return receipts, events


def redactor():
    replacements = [(str(root), '<' + kind.upper() + '_ROOT>') for kind, root in ROOTS.items()]
    replacements += [(r'<SOURCE_ROOT>', '<SOURCE_ROOT>'),
                     (r'<REUSED_READER_ROOT>', '<REUSED_READER_ROOT>'),
                     (r'<GIT_EXECUTABLE>', '<GIT_EXECUTABLE>'),
                     (r'<OWNED_WORK_ROOT>', '<OWNED_WORK_ROOT>')]
    replacements += [(value, '<MACHINE_DIRECTORY>') for key in ('USERPROFILE', 'SYSTEMROOT', 'WINDIR')
                     if (value := os.environ.get(key))]
    identities = {value for key in ('USERNAME', 'USERDOMAIN', 'COMPUTERNAME') if (value := os.environ.get(key))}

    def variants(value):
        return {value, value.replace('\\', '/'), value.replace('\\', '\\\\'), json.dumps(value)[1:-1]}

    identity_patterns = [r'(?<!\w)' + re.escape(value) + r'(?!\w)' for identity in identities for value in variants(identity)]
    placeholder, number = '<REDACTED_0>', 0
    while any(re.search(pattern, placeholder, re.I) for pattern in identity_patterns):
        number += 1
        placeholder = '<REDACTED_' + str(number) + '>'
    absolute = r'\b[A-Za-z]:[\\/]+[^\s"\'<>]*'
    unc = r'(?<!\\)\\\\+[A-Za-z0-9_.-]+[\\/][^\s"\'<>]*'

    def text(value):
        for old, replacement in sorted(replacements, key=lambda pair: len(pair[0]), reverse=True):
            for spelling in sorted(variants(old), key=len, reverse=True):
                value = re.sub(re.escape(spelling), lambda _: replacement, value, flags=re.I)
        value = re.sub(absolute, '<ABSOLUTE_PATH>', value)
        value = re.sub(unc, '<UNC_PATH>', value)
        for pattern in identity_patterns:
            value = re.sub(pattern, lambda _: placeholder, value, flags=re.I)
        return re.sub(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', '<USER_SID>', value)

    def obj(value):
        if isinstance(value, str):
            return text(value)
        if isinstance(value, list):
            return [obj(item) for item in value]
        if isinstance(value, dict):
            result = {text(key): obj(item) for key, item in value.items()}
            need(len(result) == len(value), 'redacted_key_collision')
            return result
        return value

    def saved(key, data):
        if key[1].endswith('.json'):
            return json_bytes(obj(parse(data)))
        if key in JSON_LOGS:
            # Parse and re-encode values; never rewrite JSON escape syntax.
            return b''.join((json.dumps(obj(parse(line)), ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')
                            for line in data.splitlines())
        return text(data.decode('utf-8-sig')).encode('utf-8')

    def scan(data, key):
        def check(value, encoded):
            need(not any(re.search(pattern, value, re.I) for pattern in identity_patterns), 'machine_identity_remains')
            need(not re.search(r'\b[A-Za-z]:[\\/]+', value) and not re.search(unc, value), 'absolute_path_remains')
            need(not re.search(r'\bS-1-5-21-(?:[0-9]+-){3}[0-9]+\b', value), 'user_sid_remains')
            need(not re.search(r'<(?:\?xml\b|Task\b|RegistrationInfo\b|Principals\b|Actions\b)', value, re.I), 'xml_content_remains')
            for pattern in (
                rb'\bgh[pousr]_[A-Za-z0-9]{16,}', rb'\bgithub_pat_[A-Za-z0-9_]{16,}',
                rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}', rb'\bxox[baprs]-[A-Za-z0-9-]{16,}',
                rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}', rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
                rb'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{20,}',
                rb'(?i)\b(?:password|api[_-]?key|access[_-]?token|client[_-]?secret)[\"\']?\s*[:=]\s*[\"\'][^\"\'\s]{12,}[\"\']',
            ):
                need(re.search(pattern, encoded) is None, 'credential_shaped_content')

        def visit(value):
            if isinstance(value, str):
                check(value, value.encode('utf-8'))
            elif isinstance(value, list):
                for item in value:
                    visit(item)
            elif isinstance(value, dict):
                for field, item in value.items():
                    visit(field)
                    visit(item)

        if key[1].endswith('.json'):
            visit(parse(data))
        elif key in JSON_LOGS:
            for line in data.splitlines():
                visit(parse(line))
        else:
            check(data.decode('utf-8'), data)
    return saved, scan


def main():
    need(not sys.flags.optimize and os.name == 'nt' and len(sys.argv) == 1, 'unoptimized_windows_no_arguments_required')
    ordinary(ROOT, True)
    need(not any(os.path.lexists(ROOT / name) for name in OUTPUTS), 'output_already_exists')
    receipts, events = validate()
    summary = {
        'schema': 1, 'evidence_validation': 'PASS', 'mode': 'saved_public_files_only',
        'verified_utc': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'tree': TREE,
        'initial_observation_outcome': 'INCOMPLETE_OBSERVATION', 'initial_query_failures': 5,
        'diagnostic_capture': 'PASS', 'diagnostic_working_directory_null_count': 5,
        'historical_failure_cause_proven': False, 'negative_public_value_transfer': 'PASS',
        'observed_last_result': VALUE, 'claim': CLAIM, 'public_go_calls': 2, 'public_events': events,
        'source_before_after_clean_reported': True, 'reused_binary_sha256_reported': BINARY_SHA,
        'binary_rebuilt': False, 'private_snapshot_equality_reported': True,
        'snapshot_hash_equality_verified_in_public_evidence': True, 'snapshot_sha256_reported': SNAPSHOT_SHA,
        'receipts': receipts, 'stream_checks': stream_checks,
        'scheduler_changes': False, 'completed_action_exit_qualified': False, 'full_native_qualification': False,
        'atomic_snapshot_claimed': False, 'global_enumeration_complete_claimed': False,
        'whole_process_tree_proven': False, 'post_verify_dependency': False,
        'packager_native_or_git_calls': False, 'private_files_or_binary_opened': False,
        'limitations': [
            'Initial enumeration remains incomplete with five query failures; later focused reads do not repair that historical result.',
            'The diagnostic captured five null WorkingDirectory values but does not prove the cause of the earlier failures.',
            'The two public PASS results establish transfer of one observed signed value through Status and List only.',
            'This packager verifies public hash/equality claims and controller identities; it never opens private snapshots, manifests, or the binary.',
            'Clean source and unchanged reused binary are bound through the pinned controller receipt, not re-probed here.',
            'Equal snapshots are not atomic isolation; no completed-action exit or full native qualification is claimed.',
            'Process settlement here covers recorded direct children; a separate process snapshot may be cited later.',
            'Scripts are sanitized review copies. Raw and saved hashes identify original and archived bytes separately.',
            'Closed public schemas, identity/path redaction, XML and credential-shape scans are bounded disclosure checks.',
        ],
    }
    saved, scan = redactor()
    members, manifest = {}, {'schema': 1, 'head': HEAD, 'tree': TREE, 'files': [],
                             'redaction': 'source hashes/sizes identify raw allowlisted bytes; saved hashes/sizes identify sanitized members'}
    originals = {kind + '/' + name: ((kind, name), read(kind, name)) for kind, name in sorted(ALLOWLIST)}
    originals['execution-summary.json'] = (('generated', 'execution-summary.json'), json_bytes(summary))
    for name, (key, raw) in originals.items():
        sanitized = saved(key, raw)
        scan(sanitized, key)
        members[name] = sanitized
        manifest['files'].append({'path': name, 'origin': 'generated' if key[0] == 'generated' else 'saved_public_evidence',
                                  'source_sha256': sha(raw), 'source_bytes': len(raw),
                                  'saved_sha256': sha(sanitized), 'saved_bytes': len(sanitized)})
    members['MANIFEST.json'] = json_bytes(manifest)
    scan(members['MANIFEST.json'], ('generated', 'MANIFEST.json'))
    for key, original in raw_files.items():
        need(read_uncached(key) == original, 'input_changed_during_packaging: ' + key[0] + '/' + key[1])
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    archive_data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(archive_data)) as archive:
        need(archive.namelist() == list(members) and all(archive.read(name) == data for name, data in members.items()),
             'archive_verification_failed')
    encoded = base64.b64encode(archive_data).decode('ascii')
    transfer = ('\n'.join(encoded[index:index + 4096] for index in range(0, len(encoded), 4096)) + '\n').encode('ascii')
    metadata = {'head': HEAD, 'tree': TREE, 'archive_file': 'evidence-redacted.zip',
                'archive_sha256': sha(archive_data), 'archive_bytes': len(archive_data), 'archive_members': len(members),
                'manifest_files': len(manifest['files']), 'manifest_sha256': sha(members['MANIFEST.json']),
                'summary_sha256': sha(members['execution-summary.json']), 'base64_file': 'evidence-redacted.base64.txt',
                'base64_sha256': sha(transfer), 'base64_bytes': len(transfer), 'base64_lines': len(transfer.splitlines()),
                'base64_chunk_characters': 4096, 'initial_observation_outcome': 'INCOMPLETE_OBSERVATION',
                'negative_public_value_transfer': 'PASS', 'full_native_qualification': False, 'credential_shape_scan': 'PASS'}
    scan(json_bytes(metadata), ('generated', 'archive-metadata.json'))
    outputs = {'execution-summary.json': members['execution-summary.json'], 'archive-metadata.json': json_bytes(metadata),
               'evidence-redacted.zip': archive_data, 'evidence-redacted.base64.txt': transfer}
    need(not any(os.path.lexists(ROOT / name) for name in OUTPUTS), 'output_created_during_validation')
    for name, data in outputs.items():
        with (ROOT / name).open('xb') as output:
            output.write(data)
    print(json.dumps(metadata), flush=True)


if __name__ == '__main__':
    try:
        main()
    except EvidenceError as error:
        print(json.dumps({'packaged': False, 'error_category': 'evidence_validation', 'detail': str(error)}), flush=True)
        raise SystemExit(1)
    except Exception as error:
        print(json.dumps({'packaged': False, 'error_category': type(error).__name__}), flush=True)
        raise SystemExit(1)
