"""Bounded hidden-task lookup checks, using existing offline Windows tools."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

SOURCE = Path(r"<SOURCE>")
WORK = Path(r"<WORK>")
GO = Path(r"<GO_BIN>\go.exe")
GIT = Path(r"<GIT>")
BASE = "a7d92d2852c4f6eb8afb0569ef76a545e38aacf7"
phase = sys.argv[1]
out = WORK / phase
out.mkdir(exist_ok=False)
runtime_dir = WORK / "runtime" / phase
for name in ("tmp", "profile", "appdata", "localappdata", "gopath", "cross"):
    (runtime_dir / name).mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("MCPHUB_")}
env.update({
    "GOROOT": r"<GO_ROOT>", "GOENV": "off", "GOTOOLCHAIN": "local",
    "GOPROXY": "off", "GOSUMDB": "off", "GOVCS": "*:off", "GOWORK": "off", "GOFLAGS": "",
    "GOCACHE": r"<GO_CACHE_ROOT>\gocache",
    "GOMODCACHE": r"<GO_CACHE_ROOT>\gomodcache",
    "GOPATH": str(runtime_dir / "gopath"), "CC": str(GO.with_name("gcc.exe")), "CGO_ENABLED": "1",
    "GOMAXPROCS": "4", "GOTELEMETRY": "off", "MCPHUB_NO_AUTO_GUI": "1",
    "MCPHUB_E2E_SCHEDULER": "none", "USERPROFILE": str(runtime_dir / "profile"),
    "APPDATA": str(runtime_dir / "appdata"), "LOCALAPPDATA": str(runtime_dir / "localappdata"),
    "TEMP": str(runtime_dir / "tmp"), "TMP": str(runtime_dir / "tmp"),
    "TMPDIR": str(runtime_dir / "tmp"), "GOTMPDIR": str(runtime_dir / "tmp"),
    "PYTHONDONTWRITEBYTECODE": "1",
})
env["PATH"] = str(GO.parent) + os.pathsep + env.get("PATH", "")
for p in (GO, GO.with_name("gofmt.exe"), Path(env["CC"]), Path(env["GOROOT"]), Path(env["GOCACHE"]), Path(env["GOMODCACHE"])):
    assert p.exists(), p
spec = json.loads((WORK / "files.json").read_text(encoding="utf-8"))
paths = [f["path"] for f in spec]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output([str(GIT), "-C", str(SOURCE), *args], env=env, text=True).strip()

receipt = {"phase": phase, "base": BASE, "head": git("rev-parse", "HEAD"),
           "go_version": subprocess.check_output([str(GO), "version"], env=env, text=True).strip(),
           "windows": list(sys.getwindowsversion()[:3]), "runner_sha256": digest(Path(__file__)),
           "environment": {k: env[k] for k in ("GOPROXY", "GOSUMDB", "GOVCS", "GOTOOLCHAIN", "GOMAXPROCS", "CGO_ENABLED", "MCPHUB_NO_AUTO_GUI", "MCPHUB_E2E_SCHEDULER")},
           "source_sha256_before": {p: digest(SOURCE / p) for p in paths}, "commands": []}
assert receipt["head"] == BASE or phase.startswith("published"), receipt["head"]

def save():
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")

def run(name, args, executable=GO, overrides=None):
    command_env = dict(env)
    command_env.update(overrides or {})
    stdout, stderr = out / (name + ".stdout.log"), out / (name + ".stderr.log")
    record = {"name": name, "executable": executable.name, "arguments": args,
              "environment_overrides": overrides or {}, "started_utc": datetime.now(timezone.utc).isoformat()}
    print("START", name, flush=True)
    start = time.monotonic()
    with stdout.open("wb") as fo, stderr.open("wb") as fe:
        done = subprocess.run([str(executable), *args], cwd=SOURCE, env=command_env, stdout=fo, stderr=fe)
    record.update({"exit_code": done.returncode, "seconds": round(time.monotonic() - start, 3),
                   "finished_utc": datetime.now(timezone.utc).isoformat(),
                   "stdout_sha256": digest(stdout), "stderr_sha256": digest(stderr), "stderr_bytes": stderr.stat().st_size})
    if "-json" in args and args[0] == "test":
        events = []
        for line in stdout.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except ValueError:
                continue
        record["tests"] = {a: [e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a]
                           for a in ("pass", "fail", "skip")}
    receipt["commands"].append(record)
    save()
    print(json.dumps({k: record[k] for k in ("name", "exit_code", "seconds", "stderr_bytes")}), flush=True)
    return record

contract = "^(TestSchedulerCOMHiddenTaskLookup|TestSchedulerCOMGuardedRunDefinition|TestSchedulerCOMTypedOutcomesIgnoreHostileLocalizedText|TestSchedulerCOMMapsTypedAccessCorruptAndUnavailable|TestSchedulerCOMScriptSerializesNegativeHRESULT|TestSchedulerCOMScriptUTF8ConsoleRoundTripsUnicodeTaskJSON|TestSchedulerRunOwnedAdmissionAndPositiveReply|TestTaskStatusFromCOMUsesNumericStateOnly)$"
if phase.startswith("format"):
    if phase == "format":
        assert all(digest(SOURCE / f["path"]) == f["sha256"] for f in spec), "source transfer mismatch"
    assert run("gofmt", ["-w", *paths], GO.with_name("gofmt.exe"))["exit_code"] == 0
    assert run("diff-check", ["diff", "--check"], GIT)["exit_code"] == 0
    files = [{"path": p, "content": (SOURCE / p).read_text(encoding="utf-8"), "sha256": digest(SOURCE / p)} for p in paths]
    (out / "formatted-files.json").write_text(json.dumps(files, ensure_ascii=False), encoding="utf-8")
elif phase.startswith("contract") or phase.startswith("published"):
    run("contract-race", ["test", "-mod=readonly", "-json", "-race", "-count=2", "-timeout=180s", "-run", contract, "./internal/scheduler"])
    run("contract-tagged-race", ["test", "-mod=readonly", "-json", "-race", "-tags=test_state_path_env", "-count=1", "-timeout=180s", "-run", contract, "./internal/scheduler"])
elif phase == "controls":
    target = SOURCE / "internal/scheduler/scheduler_com_windows.go"
    original = target.read_bytes()
    baseline = subprocess.check_output([str(GIT), "-C", str(SOURCE), "show", BASE + ":internal/scheduler/scheduler_com_windows.go"], env=env)
    old = b"$flags=1;if($r.operation -eq 'list'){$flags=0};"
    assert original.count(old) == 1
    broad = original.replace(old, b"$flags=1;")
    (out / "lookup.original.go").write_bytes(original)
    (out / "lookup.baseline.go").write_bytes(baseline)
    (out / "lookup.broad-list.go").write_bytes(broad)
    receipt["controls"] = {}
    try:
        target.write_bytes(baseline)
        record = run("old-hidden-filter", ["test", "-mod=readonly", "-json", "-count=1", "-timeout=180s", "-run", "^(TestSchedulerCOMHiddenTaskLookup|TestSchedulerCOMGuardedRunDefinition)$/^hidden-", "./internal/scheduler"])
        expected = {"TestSchedulerCOMHiddenTaskLookup/" + name for name in ("hidden-status", "hidden-export", "hidden-stop-running", "hidden-stop-ready", "hidden-delete")}
        expected.update({"TestSchedulerCOMHiddenTaskLookup", "TestSchedulerCOMGuardedRunDefinition/hidden-matching", "TestSchedulerCOMGuardedRunDefinition/hidden-wrong-owner", "TestSchedulerCOMGuardedRunDefinition", "PACKAGE:mcp-local-hub/internal/scheduler"})
        receipt["controls"]["old_hidden_filter_detected"] = record["exit_code"] == 1 and set(record["tests"]["fail"]) == expected and not record["tests"]["skip"] and record["stderr_bytes"] == 0
        assert receipt["controls"]["old_hidden_filter_detected"], record
        target.write_bytes(broad)
        record = run("broadened-list", ["test", "-mod=readonly", "-json", "-count=1", "-timeout=180s", "-run", "^TestSchedulerCOMHiddenTaskLookup$/^list-remains-visible-only$", "./internal/scheduler"])
        expected = {"TestSchedulerCOMHiddenTaskLookup/list-remains-visible-only", "TestSchedulerCOMHiddenTaskLookup", "PACKAGE:mcp-local-hub/internal/scheduler"}
        receipt["controls"]["broadened_list_detected"] = record["exit_code"] == 1 and set(record["tests"]["fail"]) == expected and not record["tests"]["skip"] and record["stderr_bytes"] == 0
        assert receipt["controls"]["broadened_list_detected"], record
    finally:
        target.write_bytes(original)
        receipt["control_restored_exact_bytes"] = target.read_bytes() == original
        save()
    assert receipt["control_restored_exact_bytes"]
elif phase == "gates":
    for name, args in (("build", ["build", "./..."]), ("vet", ["vet", "./..."]),
                       ("full-test", ["test", "-count=1", "-timeout", "5m", "./..."]),
                       ("state-tag-full", ["test", "-tags=test_state_path_env", "-count=1", "-timeout", "5m", "./internal/api/", "./internal/cli/"])):
        run(name, args)
else:
    raise ValueError(phase)
receipt["source_sha256_after"] = {p: digest(SOURCE / p) for p in paths}
receipt["source_stable"] = phase.startswith("format") or receipt["source_sha256_after"] == receipt["source_sha256_before"]
receipt["status_after"] = git("status", "--porcelain=v1", "--untracked-files=all")
save()
assert receipt["source_stable"]
print("COMPLETE", phase, flush=True)
