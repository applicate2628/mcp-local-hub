# Текущая очередь и владелец минимальной правки R17

**Репозиторий:** applicate2628/mcp-local-hub. **Срез:** 2026-11-19 03:06:25 UTC. **Предыдущая контрольная точка:** 2026-11-19 00:45:35 UTC.

**Подходящего существующего запроса на включение изменений (PR, pull request) для кода Scheduler/autostart сейчас нет.** #623 владеет документацией R17; #658 — общим остаточным планом. Все 30 списков изменённых файлов прочитаны: ни один открытый PR не меняет `internal/scheduler/`, `internal/autostart/` или файлы `scheduler_*` / `weekly_refresh*`. Единственные имена файлов со словом scheduler — отчёт и манифест в #623. Это вывод о текущих опубликованных дельтах, не об отсутствии локальной параллельной разработки.

## Оглавление

1. [Изменения после контрольной точки](#checkpoint)
2. [Кандидаты и границы ответственности](#candidates)
3. [Практическая рекомендация](#recommendation)
4. [Объём проверки и ограничения](#verification)
5. [Все изменённые пути рассмотренных кандидатов](#paths)
6. [Источники](#sources)

<a id="checkpoint"></a>
## 1. Изменения после контрольной точки

Очередь остаётся **30 открытых PR, все Draft**. Живая ветка `master` равна `a7d92d2852c4f6eb8afb0569ef76a545e38aacf7`. Все четыре контрольные вершины совпадают с `publication.json`.

**Таблица 1 — сравнение точных вершин.**

| PR | Предыдущая вершина | Текущая вершина | Изменение |
|---|---|---|---|
| [#623](https://github.com/applicate2628/mcp-local-hub/pull/623) | `e8268f067a7fbf797b55352ec601ae8d6b5e41f2` | `e8268f067a7fbf797b55352ec601ae8d6b5e41f2` | Нет |
| [#628](https://github.com/applicate2628/mcp-local-hub/pull/628) | `453e856347cabcebb289ec1c9af70f12af3376c0` | `453e856347cabcebb289ec1c9af70f12af3376c0` | Нет |
| [#658](https://github.com/applicate2628/mcp-local-hub/pull/658) | `bafd67045d6b867709087cff95b7806f0f6d279c` | `bafd67045d6b867709087cff95b7806f0f6d279c` | Нет |
| [#659](https://github.com/applicate2628/mcp-local-hub/pull/659) | `a3568dfe3426afaca4176d57a2310097e5214e77` | `a3568dfe3426afaca4176d57a2310097e5214e77` | Нет |

Текущий набор номеров: **623, 624, 625, 626, 627, 628, 629, 631, 632, 635, 636, 637, 639, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659**. Максимальное время создания открытого PR — `2026-11-18T21:08:14Z`; максимальное время обновления — `2026-11-19T00:43:15Z` (#658). Оба предшествуют контрольной точке. Самый недавно обновлённый закрытый PR — #642: закрыт и слит `2026-11-15T09:16:27Z`, обновлён `2026-11-15T09:16:28Z`. Новых открытых, закрытых или слитых PR после контрольной точки не наблюдается; смены Draft или указанных вершин нет. Источники: [1]–[3].

Полный исходный набор из таблицы 1 плана #658 плюс последующие #658/#659 согласуется с текущими 30 номерами. Полные прежние вершины остальных 26 PR в `publication.json` не перечислены; их не выдаём за отдельное побайтовое сравнение с той контрольной точкой. Текущие 30 вершин сохранены в сопроводительном JSON.

<a id="candidates"></a>
## 2. Кандидаты и границы ответственности

**Таблица 2 — существующие документационные владельцы и проверенные смежные PR.** Число файлов — полная дельта PR, не число файлов последнего коммита. В колонке путей показаны определяющие ответственность файлы; все пути приведены в §5. Идентификаторы вершин сокращены только в этой таблице.

| PR | Вершина | Область ответственности | changed_files | Определяющие пути | Пригодность для R17 |
|---|---|---|---:|---|---|
| [#623](https://github.com/applicate2628/mcp-local-hub/pull/623) | `e8268f067a7f` | Документация перехода, измерений, границ COM и отчёт R17; исторические доказательства | 50 | `docs/modernization/plans/scheduler-contracts-2026-11-19.md`; `docs/modernization/plans/scheduler-contracts-2026-11-19.sources.json`; `docs/modernization/plans/rust-independent-execution-plan-2026-11-12.md`. [Полный список](#paths-623) | Документация R17; не текущий владелец продуктового кода Scheduler |
| [#658](https://github.com/applicate2628/mcp-local-hub/pull/658) | `bafd67045d6b` | Канонические инструкции, общий план качества PR и инструмент диагностики Go-тестов | 9 | `.plans/2026-11/open-pr-integration-20261117.md`; `AGENTS.md`; `docs/agent-runbook.md`; `tools/testshards/main.go`; `tools/testshards/main_test.go`. [Полный список](#paths-658) | Только изменение действующего остатка; код Scheduler смешивает обязанности |
| [#628](https://github.com/applicate2628/mcp-local-hub/pull/628) | `453e856347ca` | R16: измерения нативного наблюдения и обычный Windows status через один дескриптор процесса | 17 | `internal/cli/supervise_liveness.go`; `internal/cli/supervise_status.go`; `internal/cli/supervise_status_process_other.go`; `internal/cli/supervise_status_process_windows.go`; `internal/process/pid_status.go`; `internal/process/pid_status_windows.go`; `internal/process/process_rss_windows.go`. [Полный список](#paths-628) | Не подходит: наблюдение процесса не контракт чтения системной задачи |
| [#659](https://github.com/applicate2628/mcp-local-hub/pull/659) | `a3568dfe3426` | R16: сохранение неизвестного результата наблюдения PID порта в stop/API | 23 | `internal/api/install.go`; `internal/api/processes.go`; `internal/api/status_enrich.go`; `internal/api/stop_force_supervisor.go`. [Полный список](#paths-659) | Не подходит: отдельный контракт порта и остановки процесса |
| [#657](https://github.com/applicate2628/mcp-local-hub/pull/657) | `4fa52b60b719` | Источник нативного тестового Windows Product для RunV5 | 2 | `build.ps1`; `scripts/test-windows-product-build.ps1`. [Полный список](#paths-657) | Не подходит: инфраструктура тестовой сборки, самостоятельная зона |

У остальных 25 PR проверены только названия, текущие метаданные и списки изменённых путей. Продуктовых scheduler/autostart-путей среди них нет; повторное содержательное ревью всех PR не проводилось. Полный индекс номеров, вершин и числа путей находится в `current-pr-scope.json`.

<a id="recommendation"></a>
## 3. Практическая рекомендация

1. **Документационный следующий шаг сохранять в #623.** Минимальный уточнённый контракт точечного ExportXML и адресные доказательства естественно продолжают уже опубликованный отчёт R17. Соответствующее изменение остатка принадлежит #658 (§20.4). Завершённую карту восьми операций не строить повторно.
2. **Для кода не выбирать ложного существующего владельца.** #628 относится к наблюдению объекта процесса, #659 — к результату наблюдения порта, #657 — к тестовой сборке Product, #658 — к инструкциям/плану/диагностике. Перенос исправления планировщика в любую из этих веток расширяет самостоятельную ответственность. Документационный #623 также не содержит продуктовой реализации Scheduler, поэтому его автоматически в такой PR не превращать.
3. **Если продолжается реализация, подготовить самостоятельную обозримую минимальную дельту на точном исходнике без объединения чужих веток/патчей.** Для неё требуется собственный владелец PR, отсутствующий в нынешней очереди. В рамках строгого требования «только существующие PR» сейчас доступна публикация контракта/доказательств в #623 и корректировки плана в #658; существующего места для кода без смешения областей нет. Создание или изменение PR в данном проходе не выполнялось.
4. **Не расширять первую ответственность R17.** Канонический §20.4 ставит сначала достоверное точечное чтение/отсутствие, сохранность определения и ошибок; первый кандидат устранения собственного COM (компонентной модели Windows) — ExportXML с доказанными исходами и кодировкой. RunOwned, разрушительные действия, восстановление при внешнем поколении задачи и проекция состояния остаются отдельными обязанностями. Точный минимальный контракт уточняет параллельный исполнитель; этот аудит его не подменяет.
5. **Сохранить локальную параллельную Rust-работу.** Наличие реализации `mh_wait1` / `mh_close1` установлено контекстом задачи. Публичные вершины #625/#644/#631 не использовались как доказательство её отсутствия; локальные ветки и правки не читались и не менялись.

<a id="verification"></a>
## 4. Объём проверки и ограничения

Прочитаны `r17-audit/ACTIVE.md`, `publication.json` и §20.4 окончательного плана. Через GitHub выполнены только операции чтения: вся открытая очередь, живая `master`, пять подробных карточек кандидатов, списки файлов всех 30 PR и пять последних закрытых PR. В открытой очереди 30 элементов при размере страницы 100; самый большой список файлов содержит 60 путей при размере страницы 100. Все прочитанные коллекции исчерпаны, суммарно проверено **331 вхождение изменённого пути**. Содержимое патчей остальных PR повторно не анализировалось.

Собственная проверка результата сопоставила: выбранные головы с контрольной точкой; `changed_files` пяти кандидатов с длиной их полных списков; отсутствие scheduler/autostart-путей во всех текущих дельтах; независимость предложенных документационных и продуктовых обязанностей. Результат — аудит маршрутизации изменений, не заключение о математической, нативной или продуктовой готовности кода.

Тесты, сборки, системные команды планировщика, установка ПО, ручная непрерывная интеграция (CI), платное/квотное ревью, публикации комментариев, изменение веток и интеграция патчей не выполнялись. Результат R16 на Comet выясняет родительская задача; состояние из прежней контрольной точки не переобъявляется здесь текущим. Два полных Go FAIL и прочие остаточные критерии не закрываются этим чтением.

<a id="paths"></a>
## 5. Все изменённые пути рассмотренных кандидатов

<a id="paths-623"></a>
### #623: 50 путей

Ветка: `docs/rust-cross-platform-no-com-20261112`; точная вершина: `e8268f067a7fbf797b55352ec601ae8d6b5e41f2`. Список из [GitHub API](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls/623/files?per_page=100).

- `docs/modernization/plans/measurement-consumers-2026-11-18.md`
- `docs/modernization/plans/rust-creator-receiving-contract-2026-11-15.md`
- `docs/modernization/plans/rust-cross-platform-boundaries.svg`
- `docs/modernization/plans/rust-cross-platform-plan-2026-11-12.md`
- `docs/modernization/plans/rust-independent-execution-plan-2026-11-12.md`
- `docs/modernization/plans/scheduler-contracts-2026-11-19.md`
- `docs/modernization/plans/scheduler-contracts-2026-11-19.sources.json`
- `docs/modernization/verification/branch-audit-2026-11-14/BRANCHES.md`
- `docs/modernization/verification/branch-audit-2026-11-14/PROGRESS.md`
- `docs/modernization/verification/branch-audit-2026-11-14/RESULTS.md`
- `docs/modernization/verification/branch-audit-2026-11-14/SHA256SUMS.txt`
- `docs/modernization/verification/branch-audit-2026-11-14/analyze.mjs`
- `docs/modernization/verification/branch-audit-2026-11-14/branches-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/fetch-history.log`
- `docs/modernization/verification/branch-audit-2026-11-14/ffi-sync-head.txt`
- `docs/modernization/verification/branch-audit-2026-11-14/historical-patch-check.json`
- `docs/modernization/verification/branch-audit-2026-11-14/merge-predictions-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/open-pr-analysis-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/overlaps-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/prepare-sync.mjs`
- `docs/modernization/verification/branch-audit-2026-11-14/prepared-sync.json`
- `docs/modernization/verification/branch-audit-2026-11-14/pulls-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-cache-transfer.json`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-verification/COMPLETED.txt`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-verification/clippy.log`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-verification/fmt.log`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-verification/steps.json`
- `docs/modernization/verification/branch-audit-2026-11-14/reader-verification/test.log`
- `docs/modernization/verification/branch-audit-2026-11-14/refs-before.tsv`
- `docs/modernization/verification/branch-audit-2026-11-14/refs-prepublish.tsv`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merge-prediction.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/COMPLETED.txt`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/affected-vet.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/cli-race.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/commit.txt`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/counts.json`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/daemon-race.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/go-version.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/indexed-tree.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/main-race.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/product-build.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/selected-json.log`
- `docs/modernization/verification/branch-audit-2026-11-14/relay-merged-master/steps.json`
- `docs/modernization/verification/branch-audit-2026-11-14/render-index.mjs`
- `docs/modernization/verification/branch-audit-2026-11-14/resolve-relay.mjs`
- `docs/modernization/verification/branch-audit-2026-11-14/roots-verification/run.log`
- `docs/modernization/verification/branch-audit-2026-11-14/roots-verification/steps.json`
- `docs/modernization/verification/branch-audit-2026-11-14/summary-before.json`
- `docs/modernization/verification/branch-audit-2026-11-14/verify-relay.ps1`
- `docs/modernization/verification/branch-audit-2026-11-14/verify-roots.ps1`

<a id="paths-658"></a>
### #658: 9 путей

Ветка: `docs/agents-canonical-plan-20261117`; точная вершина: `bafd67045d6b867709087cff95b7806f0f6d279c`. Список из [GitHub API](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls/658/files?per_page=100).

- `.plans/2026-11/open-pr-integration-20261117.md`
- `AGENTS.md`
- `CLAUDE.md`
- `CONTRIBUTING.md`
- `docs/agent-runbook.md`
- `docs/frontend-flowbite.md`
- `docs/skills/mcphub-explained/SKILL.md`
- `tools/testshards/main.go`
- `tools/testshards/main_test.go`

<a id="paths-628"></a>
### #628: 17 путей

Ветка: `perf/rx16-native-observation-20261112`; точная вершина: `453e856347cabcebb289ec1c9af70f12af3376c0`. Список из [GitHub API](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls/628/files?per_page=100).

- `docs/modernization/verification/native-observation-2026-11-18/.gitattributes`
- `docs/modernization/verification/native-observation-2026-11-18/RESULTS.md`
- `docs/modernization/verification/native-observation-2026-11-18/SHA256SUMS`
- `docs/modernization/verification/native-observation-2026-11-18/logs.zip`
- `docs/modernization/verification/native-observation-2026-11-18/manifest.json`
- `docs/modernization/verification/status-observation-2026-11-19/RESULTS.md`
- `docs/modernization/verification/status-observation-2026-11-19/evidence-redacted.zip`
- `internal/cli/supervise_liveness.go`
- `internal/cli/supervise_status.go`
- `internal/cli/supervise_status_process_other.go`
- `internal/cli/supervise_status_process_test.go`
- `internal/cli/supervise_status_process_windows.go`
- `internal/process/native_observation_benchmark_windows_test.go`
- `internal/process/pid_status.go`
- `internal/process/pid_status_windows.go`
- `internal/process/pid_status_windows_test.go`
- `internal/process/process_rss_windows.go`

<a id="paths-659"></a>
### #659: 23 путей

Ветка: `fix/api-port-pid-observation-20261118`; точная вершина: `a3568dfe3426afaca4176d57a2310097e5214e77`. Список из [GitHub API](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls/659/files?per_page=100).

- `docs/modernization/verification/port-observation-2026-11-18/RESULTS.md`
- `docs/modernization/verification/port-observation-2026-11-18/evidence-redacted.zip`
- `internal/api/install.go`
- `internal/api/install_hyphen_family_ownership_test.go`
- `internal/api/install_internal_port_probe_timeout_test.go`
- `internal/api/install_own_port_test.go`
- `internal/api/install_parsed_manifest_lane_b_test.go`
- `internal/api/install_parsed_manifest_test.go`
- `internal/api/lane_a_internal_review_test.go`
- `internal/api/main_test.go`
- `internal/api/phase_f_lifecycle_test.go`
- `internal/api/port_pid_outcome_test.go`
- `internal/api/port_pid_probe_test.go`
- `internal/api/processes.go`
- `internal/api/r36_lane_a2_fixes_test.go`
- `internal/api/restart_supervisor_test.go`
- `internal/api/status_enrich.go`
- `internal/api/status_enrich_test.go`
- `internal/api/stop_force_supervisor.go`
- `internal/api/stop_force_supervisor_other_test.go`
- `internal/api/stop_force_supervisor_sentinel_windows_test.go`
- `internal/api/stop_force_supervisor_windows_test.go`
- `internal/api/supervisor_seal_guard_test.go`

<a id="paths-657"></a>
### #657: 2 путей

Ветка: `fix/canonical-command-test-product-20261116`; точная вершина: `4fa52b60b719664ede441be339e196a8b9766c50`. Список из [GitHub API](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls/657/files?per_page=100).

- `build.ps1`
- `scripts/test-windows-product-build.ps1`

<a id="sources"></a>
## 6. Источники

1. [Текущие открытые PR, страница до 100 элементов](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls?state=open&sort=created&direction=desc&per_page=100).
2. [Живая ветка master](https://api.github.com/repos/applicate2628/mcp-local-hub/branches/master).
3. [Последние закрытые PR по времени обновления](https://api.github.com/repos/applicate2628/mcp-local-hub/pulls?state=closed&sort=updated&direction=desc&per_page=5).
4. [Карта R17 на точном опубликованном коммите #623](https://github.com/applicate2628/mcp-local-hub/blob/e8268f067a7fbf797b55352ec601ae8d6b5e41f2/docs/modernization/plans/scheduler-contracts-2026-11-19.md).
5. [Канонический остаток §20.4 на точном опубликованном коммите #658](https://github.com/applicate2628/mcp-local-hub/blob/bafd67045d6b867709087cff95b7806f0f6d279c/.plans/2026-11/open-pr-integration-20261117.md#remaining-after-r17-contracts-20261119).
6. Локальная контрольная точка: `r17-audit/ACTIVE.md`, `r17-audit/publication.json`, `r17-audit/658-plan-final.md`. Машиночитаемый результат: `r17-audit/current-pr-scope.json`.

