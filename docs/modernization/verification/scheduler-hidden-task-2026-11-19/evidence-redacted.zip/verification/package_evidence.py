"""Package completed checks; preserve original receipts outside the public copy."""
from pathlib import Path
import base64
import hashlib
import json
import os
import re
import subprocess
import zipfile

WORK = Path(r"<WORK>")
SOURCE = Path(r"<SOURCE>")
GIT = r"<GIT>"
PHASES = ["format", "controls", "contract", "gates"]
env = dict(os.environ)
env.update({"TEMP":str(WORK/"bootstrap-runtime"/"tmp"),"TMP":str(WORK/"bootstrap-runtime"/"tmp"),"GIT_TERMINAL_PROMPT":"0"})
receipts = {p: json.loads((WORK / p / "receipt.json").read_text(encoding="utf-8")) for p in PHASES}
assert all(r.get("source_stable") for r in receipts.values())
assert len(receipts["gates"]["commands"]) == 4
assert all(receipts["controls"]["controls"].values()) and receipts["controls"]["control_restored_exact_bytes"]
for phase, receipt in receipts.items():
    for c in receipt["commands"]:
        for stream in ("stdout", "stderr"):
            raw = (WORK / phase / (c["name"] + "." + stream + ".log")).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == c[stream + "_sha256"]
            if stream == "stderr": assert len(raw) == c["stderr_bytes"]
        if "tests" in c:
            events = [json.loads(l) for l in (WORK / phase / (c["name"] + ".stdout.log")).read_text(encoding="utf-8").splitlines()]
            counts = {a:[e.get("Test", "PACKAGE:" + e.get("Package", "")) for e in events if e.get("Action") == a] for a in ("pass", "fail", "skip")}
            assert counts == c["tests"]
assert all(c["exit_code"] == 0 and not c["tests"]["fail"] and not c["tests"]["skip"] for c in receipts["contract"]["commands"])
final_hashes = receipts["contract"]["source_sha256_after"]
assert all(r["source_sha256_after"] == final_hashes for r in receipts.values())
assert all(hashlib.sha256((SOURCE / p).read_bytes()).hexdigest() == h for p, h in final_hashes.items())

def sha(data):
    return hashlib.sha256(data).hexdigest()

replacements = [
    (str(SOURCE), "<SOURCE>"), (str(WORK), "<WORK>"),
    (r"<GO_CACHE_ROOT>", "<GO_CACHE_ROOT>"),
    (r"<GO_ROOT>", "<GO_ROOT>"),
    (r"<GO_BIN>", "<GO_BIN>"),
    (r"<GIT>", "<GIT>"),
    (r"<OWNED_ROOT>", "<OWNED_ROOT>"),
]

def redact_string(s):
    for old, new in replacements:
        for pattern in (old, old.replace("\\", "/")):
            s = re.sub(re.escape(pattern), lambda _: new, s, flags=re.IGNORECASE)
    s = re.sub(r"(?i)C:[\\/]Users[\\/][^\\/\s\"']+", "<USER_PROFILE>", s)
    return re.sub(r"S-1-5-21-(?:[0-9]+-){3}[0-9]+", "<USER_SID>", s)

def redact(value):
    if isinstance(value, str):
        return redact_string(value)
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, dict):
        return {redact_string(k): redact(v) for k, v in value.items()}
    return value

def redacted_bytes(path):
    data = path.read_bytes()
    if path.suffix == ".json":
        return (json.dumps(redact(json.loads(data)), indent=2, ensure_ascii=False) + "\n").encode()
    lines = []
    for line in data.decode("utf-8", errors="replace").splitlines(keepends=True):
        try:
            event = json.loads(line)
        except ValueError:
            lines.append(redact_string(line))
        else:
            lines.append(json.dumps(redact(event), ensure_ascii=False) + "\n")
    return "".join(lines).encode()

# Only this isolated branch's reviewed files enter the index. No branch or patch
# from another PR is integrated, and no unrelated paths are staged.
subprocess.run([GIT, "-C", str(SOURCE), "add", "--", *sorted(final_hashes)], check=True, env=env)
subprocess.run([GIT, "-C", str(SOURCE), "diff", "--cached", "--check"], check=True, env=env)
assert subprocess.check_output([GIT, "-C", str(SOURCE), "diff", "--name-only"], env=env, text=True).strip() == "", "unexpected unstaged tracked changes"
assert subprocess.check_output([GIT, "-C", str(SOURCE), "ls-files", "--others", "--exclude-standard"], env=env, text=True).strip() == "", "unexpected untracked files"
assert set(subprocess.check_output([GIT, "-C", str(SOURCE), "diff", "--cached", "--name-only"], env=env, text=True).splitlines()) == set(final_hashes)
code_tree = subprocess.check_output([GIT, "-C", str(SOURCE), "write-tree"], text=True, env=env).strip()
numstat = subprocess.check_output([GIT, "-C", str(SOURCE), "diff", "--cached", "--numstat"], text=True, env=env).strip()
summary = {"base": receipts["gates"]["base"], "code_tree": code_tree, "source_sha256": final_hashes,
           "source_manifest_sha256": sha("".join(f"{h}  {p}\n" for p, h in sorted(final_hashes.items())).encode()),
           "source_diff_numstat": numstat, "phases": {}}
for phase, receipt in receipts.items():
    rows = []
    for command in receipt["commands"]:
        row = {k: command[k] for k in ("name", "arguments", "exit_code", "seconds", "stderr_bytes")}
        if "tests" in command:
            row["counts"] = {k: len(v) for k, v in command["tests"].items()}
            row["failures"], row["skips"] = command["tests"]["fail"], command["tests"]["skip"]
            row["top_level_functions"] = sorted(set(n for n in command["tests"]["pass"] if not n.startswith("PACKAGE:") and "/" not in n))
        else:
            log = (WORK / phase / (command["name"] + ".stdout.log")).read_text(encoding="utf-8", errors="replace")
            row["failure_lines"] = [redact_string(l) for l in log.splitlines() if re.match(r"^(--- FAIL:|FAIL\s|panic: test timed out|\s+Test.*\([0-9].*\))", l)]
        rows.append(row)
    summary["phases"][phase] = {"source_stable": receipt.get("source_stable"), "commands": rows}
(WORK / "evidence-summary.json").write_text(json.dumps(redact(summary), indent=2) + "\n", encoding="utf-8")

archive = WORK / "evidence-redacted.zip"
assert not archive.exists()
manifest = {"redaction": "Machine paths and user-specific SIDs replaced with markers. Receipts retain original log SHA-256; saved file hashes below identify public redacted copies.", "files": []}
files = []
for phase in PHASES:
    files.extend((WORK / phase).glob("*.log"))
    files.append(WORK / phase / "receipt.json")
files.extend((WORK / "controls").glob("*.go"))
files.extend(WORK / n for n in ("run_checks.py", "evidence-summary.json"))
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(files):
        data = redacted_bytes(path)
        assert not re.search(rb"gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{16,}", data), path.name
        name = path.relative_to(WORK).as_posix()
        z.writestr(name, data)
        manifest["files"].append({"path": name, "original_sha256": sha(path.read_bytes()), "saved_sha256": sha(data), "saved_bytes": len(data)})
    z.writestr("MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
encoded = base64.b64encode(archive.read_bytes()).decode()
(WORK / "evidence-redacted.base64.txt").write_text("\n".join(encoded[i:i+4096] for i in range(0, len(encoded), 4096)) + "\n")
print(json.dumps({"code_tree": code_tree, "files": len(final_hashes), "archive_bytes": archive.stat().st_size,
                  "archive_sha256": sha(archive.read_bytes())}), flush=True)
