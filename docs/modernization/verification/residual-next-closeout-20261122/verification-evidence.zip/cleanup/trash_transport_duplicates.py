"""Move only an explicit, verified base64 transport duplicate to private trash."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path):
    for item in [path, *path.parents]:
        metadata = item.lstat()
        if stat.S_ISLNK(metadata.st_mode) or getattr(metadata, "st_file_attributes", 0) & 0x400:
            raise ValueError("Symlink or reparse point: " + str(item))
    if not stat.S_ISREG(path.stat().st_mode):
        raise ValueError("Not an ordinary file: " + str(path))


def safe_output(path, root):
    if not path.is_absolute() or ".." in path.parts or root not in path.parents:
        raise ValueError("Output outside authorized root")
    for item in [path, *path.parents]:
        try:
            metadata = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(metadata.st_mode) or getattr(metadata, "st_file_attributes", 0) & 0x400:
            raise ValueError("Output uses a symlink or reparse point: " + str(item))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    args = parser.parse_args()
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    root = Path(plan["root"])
    trash = Path(plan["trash"])
    receipt = Path(plan["receipt"])
    if not root.is_absolute() or not trash.is_absolute() or not receipt.is_absolute():
        raise ValueError("Absolute paths required")
    if ".." in root.parts or trash == receipt or trash in receipt.parents or receipt in trash.parents:
        raise ValueError("Trash and receipt must be separate paths within the authorized root")
    safe_output(trash, root)
    safe_output(receipt, root)
    if trash.exists() or receipt.exists():
        raise ValueError("Fresh trash and receipt paths required")
    checked = []
    for mapping in plan["files"]:
        if any(Path(mapping[key]).anchor or ".." in Path(mapping[key]).parts for key in ("encoded", "retained")):
            raise ValueError("Only relative input paths without parent traversal are allowed")
        encoded, retained = (root / mapping[key] for key in ("encoded", "retained"))
        if root not in encoded.parents or root not in retained.parents or ".." in encoded.parts or ".." in retained.parts:
            raise ValueError("Input outside authorized root")
        ordinary(encoded)
        ordinary(retained)
        raw = retained.read_bytes()
        transport = encoded.read_bytes()
        decoded = base64.b64decode(b"".join(transport.split()), validate=True)
        if decoded != raw or encoded.suffix != ".b64" or retained.suffix != ".zip":
            raise ValueError("Transport is not the exact retained ZIP: " + str(encoded))
        checked.append({
            "encoded": str(encoded), "retained": str(retained),
            "destination": str(trash / mapping["encoded"]),
            "transport_bytes": len(transport), "transport_sha256": digest(transport),
            "retained_bytes": len(raw), "retained_sha256": digest(raw),
            "decoded_equal_retained": True, "moved": False,
        })
    if len({row["encoded"] for row in checked}) != len(checked):
        raise ValueError("Duplicate transport input")
    trash.mkdir(parents=True, exist_ok=False)
    receipt.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "schema": "verified-transport-trash-v1",
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "purpose": "Completed transport encodings; exact retained ZIPs remain outside trash",
        "root": str(root), "trash": str(trash), "files": checked,
        "deleted": False, "trash_emptied": False, "complete": False,
    }
    def persist():
        temporary = receipt.with_name(receipt.name + ".pending")
        safe_output(receipt, root)
        safe_output(temporary, root)
        with temporary.open("x", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, receipt)
    persist()
    for row in checked:
        source, destination, retained = (Path(row[key]) for key in ("encoded", "destination", "retained"))
        ordinary(source)
        ordinary(retained)
        if digest(source.read_bytes()) != row["transport_sha256"] or digest(retained.read_bytes()) != row["retained_sha256"]:
            raise ValueError("Input changed after preflight")
        safe_output(destination, root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        safe_output(destination, root)
        if destination.exists():
            raise ValueError("Trash destination already exists")
        os.rename(source, destination)
        if source.exists() or digest(destination.read_bytes()) != row["transport_sha256"] or digest(retained.read_bytes()) != row["retained_sha256"]:
            raise ValueError("Post-move verification failed")
        row["moved"] = True
        persist()
    record["complete"] = True
    record["completed_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record["moved_files"] = len(checked)
    record["moved_bytes"] = sum(row["transport_bytes"] for row in checked)
    persist()
    print(json.dumps({key: record[key] for key in ("complete", "moved_files", "moved_bytes", "trash", "deleted", "trash_emptied")}))


if __name__ == "__main__":
    main()
