"""Verify published Git bytes without changing a worktree or running project code."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--staging", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text())
    destination = Path(args.output)
    if destination.exists():
        raise ValueError("Readback receipt already exists")

    def git(*argv):
        return subprocess.check_output([
            "git", "-C", args.repository, "--no-optional-locks",
            "-c", "core.fsmonitor=false", *argv,
        ])

    raw = git("cat-file", "commit", args.commit)
    oid = hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    headers = raw.split(b"\n\n", 1)[0].decode().splitlines()
    if oid != args.commit:
        raise ValueError("Commit identity differs")
    if [s[7:] for s in headers if s.startswith("parent ")] != [manifest["parent"]]:
        raise ValueError("Commit does not have the single expected parent")
    if [s[5:] for s in headers if s.startswith("tree ")] != [manifest["expected_tree"]]:
        raise ValueError("Published tree differs")
    expected_paths = {row["path"] for row in manifest["files"]}
    changed = set(git("diff-tree", "--no-commit-id", "--name-only", "-r",
                      manifest["parent"], args.commit).decode().splitlines())
    if changed != expected_paths:
        raise ValueError("Unexpected or missing changed paths")
    tree = {}
    for entry in git("ls-tree", "-r", "-z", "--full-tree", args.commit).split(b"\0"):
        if entry:
            metadata, name = entry.split(b"\t", 1)
            tree[name.decode()] = metadata.decode().split()
    rows = []
    for row in manifest["files"]:
        if tree[row["path"]] != ["100644", "blob", row["blob"]]:
            raise ValueError("Tree path, mode or blob differs: " + row["path"])
        raw = git("cat-file", "blob", row["blob"])
        local = (Path(args.staging) / row["path"]).read_bytes()
        if (raw != local or len(raw) != row["bytes"] or
                hashlib.sha256(raw).hexdigest() != row["sha256"]):
            raise ValueError("Published bytes differ: " + row["path"])
        rows.append({**row, "bytes_equal": True})
        print(json.dumps({"verified": row["path"], "bytes": len(raw)}), flush=True)
    result = {
        "observed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "commit": args.commit, "parent": manifest["parent"],
        "tree": manifest["expected_tree"], "method": "Fetched Git objects; all path/mode/blob bindings and exact bytes",
        "unexpected_changed_paths": [], "files": rows, "complete": True,
    }
    with destination.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"commit": args.commit, "verified_files": len(rows), "complete": True}), flush=True)


if __name__ == "__main__":
    main()
