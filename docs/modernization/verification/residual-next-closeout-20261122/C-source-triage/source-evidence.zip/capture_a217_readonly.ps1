$ErrorActionPreference = 'Stop'
$PSModuleAutoLoadingPreference = 'None'
$taskRepo = 'D:\dev\ChatGPT\mcp-rust-contained-stream-20261120'
$taskGit = 'C:\Program Files\Git\cmd\git.exe'
[Environment]::CurrentDirectory = $taskRepo
function HashBytes([byte[]] $data) {
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hasher.ComputeHash($data)).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}
$toolBefore = HashBytes ([IO.File]::ReadAllBytes($taskGit))
function GitRead([string] $tail, [string] $inputText) {
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $taskGit
    $info.Arguments = '--no-pager --no-optional-locks --no-replace-objects --literal-pathspecs -c core.fsmonitor=false -c core.untrackedCache=false -c gc.auto=0 -c maintenance.auto=false -c protocol.allow=never ' + $tail
    $info.WorkingDirectory = $taskRepo
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    foreach ($environmentKey in @($info.EnvironmentVariables.Keys)) {
        if ($environmentKey.StartsWith('GIT_', [StringComparison]::OrdinalIgnoreCase)) {
            $info.EnvironmentVariables.Remove($environmentKey)
        }
    }
    $info.EnvironmentVariables['GIT_OPTIONAL_LOCKS'] = '0'
    $info.EnvironmentVariables['GIT_NO_LAZY_FETCH'] = '1'
    $info.EnvironmentVariables['GIT_TERMINAL_PROMPT'] = '0'
    $info.EnvironmentVariables['GIT_CONFIG_NOSYSTEM'] = '1'
    $info.EnvironmentVariables['GIT_CONFIG_GLOBAL'] = 'NUL'
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $info
    $buffer = [IO.MemoryStream]::new()
    $started = $false
    try {
        $started = $process.Start()
        if (-not $started) { throw 'Git did not start' }
        $copy = $process.StandardOutput.BaseStream.CopyToAsync($buffer)
        $errors = $process.StandardError.ReadToEndAsync()
        if ($inputText) { $process.StandardInput.Write($inputText) }
        $process.StandardInput.Close()
        if (-not $process.WaitForExit(30000)) { throw 'Read-only Git direct timeout; descendant state unresolved' }
        if (-not $copy.Wait(10000)) { throw 'Read-only Git output not settled; descendant state unresolved' }
        if (-not $errors.Wait(10000)) { throw 'Read-only Git error stream not settled; descendant state unresolved' }
        if ($process.ExitCode -ne 0 -or $errors.Result.Length -ne 0) { throw ('Read-only Git failed: ' + $process.ExitCode + ' ' + $errors.Result) }
        return ,$buffer.ToArray()
    }
    finally {
        if ($started -and -not $process.HasExited) {
            $process.Kill()
            [void]$process.WaitForExit(10000)
        }
        $buffer.Dispose()
        $process.Dispose()
    }
}
$paths = @(
    'experiments/rust-process-owner/Cargo.lock',
    'experiments/rust-process-owner/Cargo.toml',
    'experiments/rust-process-owner/ffi/Cargo.lock',
    'experiments/rust-process-owner/ffi/Cargo.toml',
    'experiments/rust-process-owner/ffi/go/admission_windows.go',
    'experiments/rust-process-owner/ffi/go/admission_windows_test.go',
    'experiments/rust-process-owner/ffi/go/bridge_windows.go',
    'experiments/rust-process-owner/ffi/go/bridge_windows_test.go',
    'experiments/rust-process-owner/ffi/go/environment_windows.go',
    'experiments/rust-process-owner/ffi/go/environment_windows_test.go',
    'experiments/rust-process-owner/ffi/go/faults_windows_test.go',
    'experiments/rust-process-owner/ffi/go/finish_context_windows.go',
    'experiments/rust-process-owner/ffi/go/finish_context_windows_test.go',
    'experiments/rust-process-owner/ffi/go/go.mod',
    'experiments/rust-process-owner/ffi/go/identity_faults_windows_test.go',
    'experiments/rust-process-owner/ffi/go/identity_legacy_windows_test.go',
    'experiments/rust-process-owner/ffi/go/identity_query_faults_windows_test.go',
    'experiments/rust-process-owner/ffi/go/identity_query_legacy_windows_test.go',
    'experiments/rust-process-owner/ffi/go/identity_query_windows_test.go',
    'experiments/rust-process-owner/ffi/go/identity_windows.go',
    'experiments/rust-process-owner/ffi/go/identity_windows_test.go',
    'experiments/rust-process-owner/ffi/go/io_lifecycle_windows_test.go',
    'experiments/rust-process-owner/ffi/go/loader_windows_test.go',
    'experiments/rust-process-owner/ffi/go/members_faults_windows_test.go',
    'experiments/rust-process-owner/ffi/go/members_legacy_windows_test.go',
    'experiments/rust-process-owner/ffi/go/members_report_windows_test.go',
    'experiments/rust-process-owner/ffi/go/members_windows.go',
    'experiments/rust-process-owner/ffi/go/members_windows_test.go',
    'experiments/rust-process-owner/ffi/go/native_cleanup_windows_test.go',
    'experiments/rust-process-owner/ffi/go/outcome_faults_windows_test.go',
    'experiments/rust-process-owner/ffi/go/outcome_windows.go',
    'experiments/rust-process-owner/ffi/go/outcome_windows_test.go',
    'experiments/rust-process-owner/ffi/go/stdio_windows.go',
    'experiments/rust-process-owner/ffi/go/stdio_windows_test.go',
    'experiments/rust-process-owner/ffi/go/wait_legacy_windows_test.go',
    'experiments/rust-process-owner/ffi/go/wait_windows.go',
    'experiments/rust-process-owner/ffi/go/wait_windows_test.go',
    'experiments/rust-process-owner/ffi/include/identity_v1.h',
    'experiments/rust-process-owner/ffi/include/members_v1.h',
    'experiments/rust-process-owner/ffi/include/owner_v1.h',
    'experiments/rust-process-owner/ffi/src/argv0_tests.rs',
    'experiments/rust-process-owner/ffi/src/identity.rs',
    'experiments/rust-process-owner/ffi/src/lib.rs',
    'experiments/rust-process-owner/ffi/src/members.rs',
    'experiments/rust-process-owner/ffi/src/members_tests.rs',
    'experiments/rust-process-owner/ffi/src/process_borrow.rs',
    'experiments/rust-process-owner/ffi/src/process_borrow_tests.rs',
    'experiments/rust-process-owner/ffi/src/tests.rs',
    'experiments/rust-process-owner/src/argv0_tests.rs',
    'experiments/rust-process-owner/src/bin/owner_child.rs',
    'experiments/rust-process-owner/src/bin/owner_crash_fixture.rs',
    'experiments/rust-process-owner/src/foreground_console_tests.rs',
    'experiments/rust-process-owner/src/job_member_tests.rs',
    'experiments/rust-process-owner/src/job_members.rs',
    'experiments/rust-process-owner/src/launch_context.rs',
    'experiments/rust-process-owner/src/lib.rs',
    'experiments/rust-process-owner/src/native_failure_tests.rs',
    'experiments/rust-process-owner/src/process_borrow_tests.rs',
    'experiments/rust-process-owner/src/token_user.rs',
    'experiments/rust-process-owner/src/windows.rs',
    'experiments/rust-process-owner/tests/launch_context.rs',
    'experiments/rust-process-owner/tests/lifecycle.rs',
    'experiments/rust-process-owner/tests/owner_crash.rs',
    'experiments/rust-process-owner/tests/stdio.rs'
)
$requests = 'a217c7799a0214967bf86211542e508162c680b5' + [char]10
foreach ($sourcePath in $paths) { $requests += 'a217c7799a0214967bf86211542e508162c680b5:' + $sourcePath + [char]10 }
$treeBytes = GitRead 'ls-tree -r -z --long a217c7799a0214967bf86211542e508162c680b5 -- experiments/rust-process-owner' ''
$batchBytes = GitRead 'cat-file --batch' $requests
$toolAfter = HashBytes ([IO.File]::ReadAllBytes($taskGit))
if ($toolBefore -ne $toolAfter) { throw 'Git executable changed during read capture' }
$payload = '{"schema":"a217-source-object-capture-v1","commit":"a217c7799a0214967bf86211542e508162c680b5","source_count":64,"git_sha256":"' + $toolBefore + '","tree_base64":"' + [Convert]::ToBase64String($treeBytes) + '","batch_base64":"' + [Convert]::ToBase64String($batchBytes) + '"}'
$payloadBytes = [Text.Encoding]::UTF8.GetBytes($payload)
$packed = [IO.MemoryStream]::new()
$zip = [IO.Compression.GZipStream]::new($packed, [IO.Compression.CompressionLevel]::Optimal, $true)
try { $zip.Write($payloadBytes, 0, $payloadBytes.Length) }
finally { $zip.Dispose() }
[Console]::Out.WriteLine('A217_SOURCE_GZIP_BASE64 ' + [Convert]::ToBase64String($packed.ToArray()))
$packed.Dispose()
