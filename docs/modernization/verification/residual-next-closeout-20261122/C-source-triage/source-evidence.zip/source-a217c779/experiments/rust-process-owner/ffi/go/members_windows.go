//go:build windows && amd64 && cgo

package caller

/*
#include "../include/members_v1.h"
*/
import "C"

import (
	"errors"
	"fmt"
	"path/filepath"
	"runtime/cgo"
	"slices"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

var ErrMembersUnsupported = errors.New("native library does not support the complete member protocol")
var ErrMemberObservation = errors.New("invalid native member observation")

// MemberOriginalCreation is the original process's historical at-create binding.
// It remains meaningful when the live Job contains only descendants.
type MemberOriginalCreation struct {
	PID               uint32
	CreationTime100ns uint64
}

// MemberCensus separates lifetime assignments from the current live PID set.
type MemberCensus struct {
	TotalProcesses, ActiveProcesses uint32
	PIDs                            []uint32
}

// MemberIdentity owns exact UTF-16 and binary SID copies. It is acquisition
// evidence, not a fresh liveness check or a product authorization capability.
type MemberIdentity struct {
	PID               uint32
	CreationTime100ns uint64
	ImagePathUTF16    []uint16
	TokenUserSID      []byte
}

// MemberResource describes actual retained custody. CloseFailed explicitly
// marks a native close error, including a present error whose code is zero.
type MemberResource struct {
	PID              uint32
	BorrowedOriginal bool
	CloseAttempted   bool
	Closed           bool
	CloseFailed      bool
	CloseError       int32
}

// MemberSnapshot owns all reachable arrays. A nil census means unknown; a
// non-nil census with no PIDs records a known empty Job. Rows may be shorter
// than Resources after a partial acquisition. Close changes resource fields
// only; acquisition completeness and identity rows remain historical.
type MemberSnapshot struct {
	Generation          uint64
	Original            MemberOriginalCreation
	Pre, Post           *MemberCensus
	Rows                []MemberIdentity
	Resources           []MemberResource
	AcquisitionComplete bool
}

// MemberClose distinguishes native finalization from successful cleanup.
// CloseFinalized may be true with an error and no validated resource receipt.
// CleanupComplete is published only from a fully validated native receipt.
type MemberClose struct {
	Generation      uint64
	CloseFinalized  bool
	CleanupComplete bool
	Resources       []MemberResource
}

type MemberErrorSource uint32
type MemberErrorKind uint32

const (
	MemberSourceNone         MemberErrorSource = C.MH_MEMBERS_SOURCE_NONE
	MemberSourceObservation  MemberErrorSource = C.MH_MEMBERS_SOURCE_OBSERVATION
	MemberSourceTokenUser    MemberErrorSource = C.MH_MEMBERS_SOURCE_TOKEN_USER
	MemberSourceCopy         MemberErrorSource = C.MH_MEMBERS_SOURCE_COPY
	MemberSourceTokenCleanup MemberErrorSource = C.MH_MEMBERS_SOURCE_TOKEN_CLEANUP

	MemberNoError      MemberErrorKind = C.MH_MEMBERS_ERROR_NONE
	MemberNativeError  MemberErrorKind = C.MH_MEMBERS_ERROR_NATIVE
	MemberInvalidData  MemberErrorKind = C.MH_MEMBERS_ERROR_INVALID_DATA
	MemberNoMemory     MemberErrorKind = C.MH_MEMBERS_ERROR_NO_MEMORY
	MemberOtherError   MemberErrorKind = C.MH_MEMBERS_ERROR_OTHER
	MemberDeadline     MemberErrorKind = C.MH_MEMBERS_ERROR_DEADLINE
	MemberBusy         MemberErrorKind = C.MH_MEMBERS_ERROR_BUSY
	MemberInvalidState MemberErrorKind = C.MH_MEMBERS_ERROR_INVALID_STATE
)

// MemberError preserves query and temporary-token-close errors independently.
// Kind==MemberNativeError means NativeError is present, even when zero.
// Source==MemberSourceTokenCleanup means TokenCloseError is present, even when
// zero; Kind==MemberNoError then means there was no nested query failure.
type MemberError struct {
	Source          MemberErrorSource
	Kind            MemberErrorKind
	NativeError     int32
	TokenCloseError int32
}

func (e *MemberError) Error() string {
	return fmt.Sprintf("member source=%d kind=%d native=%d token_close=%d",
		e.Source, e.Kind, e.NativeError, e.TokenCloseError)
}

func (e *MemberError) Unwrap() []error {
	var causes []error
	if e.Kind == MemberNativeError {
		causes = append(causes, syscall.Errno(uint32(e.NativeError)))
	}
	if e.Source == MemberSourceTokenCleanup {
		causes = append(causes, syscall.Errno(uint32(e.TokenCloseError)))
	}
	return causes
}

func invalidMember(reason string) error {
	return fmt.Errorf("%w: %s", ErrMemberObservation, reason)
}

func memberErrorResult(source MemberErrorSource, kind MemberErrorKind, native, tokenClose int32) error {
	if source > MemberSourceTokenCleanup || kind > MemberInvalidState ||
		(kind != MemberNativeError && native != 0) ||
		(source != MemberSourceTokenCleanup && tokenClose != 0) {
		return invalidMember("incoherent error fields")
	}
	if source == MemberSourceNone {
		if kind != MemberNoError || native != 0 || tokenClose != 0 {
			return invalidMember("absent error carries failure fields")
		}
		return nil
	}
	if source != MemberSourceTokenCleanup && kind == MemberNoError {
		return invalidMember("error source omitted its failure")
	}
	return &MemberError{Source: source, Kind: kind, NativeError: native, TokenCloseError: tokenClose}
}

func memberReportResult(status C.uint32_t, raw C.mh_members_report) error {
	if raw.size != C.sizeof_mh_members_report || raw.version != C.MH_MEMBERS_VERSION {
		return invalidMember("incompatible member report")
	}
	err := memberErrorResult(MemberErrorSource(raw.error_source), MemberErrorKind(raw.error_kind),
		int32(raw.native_error), int32(raw.token_close_error))
	switch uint32(status) {
	case ok, argument, abiMismatch:
		if err != nil {
			return errors.Join(err, invalidMember("failure report contradicts call status"))
		}
	case invalidState:
		if err == nil {
			return invalidMember("native failure omitted its report")
		}
	default:
		return errors.Join(err, invalidMember("unexpected member call status"))
	}
	return err
}

// Array validity is still a trusted-DLL obligation. Check bounded extents,
// NULL/count pairing and alignment before constructing any borrowed Go view.
func memberArrayStorage(pointer unsafe.Pointer, count C.size_t, size, alignment uintptr) error {
	if uint64(count) > C.MH_MEMBERS_MAX_COUNT ||
		(count == 0) != (pointer == nil) {
		return invalidMember("invalid member array extent")
	}
	if count != 0 {
		start := uintptr(pointer)
		if start%alignment != 0 || start > ^uintptr(0)-uintptr(count)*size {
			return invalidMember("invalid member array storage")
		}
	}
	return nil
}

func copyMemberCensus(raw C.mh_members_census, known bool) (*MemberCensus, error) {
	if !known {
		if raw.total_processes != 0 || raw.active_processes != 0 || raw.pids != nil || raw.count != 0 {
			return nil, invalidMember("absent census contains facts")
		}
		return nil, nil
	}
	if err := memberArrayStorage(unsafe.Pointer(raw.pids), raw.count, 4, unsafe.Alignof(uint32(0))); err != nil {
		return nil, err
	}
	v := &MemberCensus{TotalProcesses: uint32(raw.total_processes), ActiveProcesses: uint32(raw.active_processes)}
	if uint64(raw.count) != uint64(v.ActiveProcesses) || v.ActiveProcesses > v.TotalProcesses {
		return nil, invalidMember("inconsistent census counts")
	}
	v.PIDs = append([]uint32(nil), unsafe.Slice((*uint32)(unsafe.Pointer(raw.pids)), int(raw.count))...)
	for i, pid := range v.PIDs {
		if pid == 0 || (i != 0 && v.PIDs[i-1] >= pid) {
			return nil, invalidMember("census PIDs are not sorted, unique and nonzero")
		}
	}
	return v, nil
}

func copyMemberIdentity(raw C.mh_member_identity) (MemberIdentity, error) {
	if raw.size != C.sizeof_mh_member_identity || raw.version != C.MH_MEMBERS_VERSION ||
		raw.reserved != 0 || raw.pid == 0 || raw.creation_time_100ns == 0 {
		return MemberIdentity{}, invalidMember("incompatible member identity")
	}
	n := int(raw.sid_len)
	if n < 8 || n > C.MH_MEMBERS_SID_CAPACITY {
		return MemberIdentity{}, invalidMember("invalid member SID length")
	}
	sid := unsafe.Slice((*byte)(unsafe.Pointer(&raw.sid[0])), C.MH_MEMBERS_SID_CAPACITY)
	if sid[0] != 1 || sid[1] > 15 || n != 8+4*int(sid[1]) {
		return MemberIdentity{}, invalidMember("invalid member SID structure")
	}
	for _, b := range sid[n:] {
		if b != 0 {
			return MemberIdentity{}, invalidMember("nonzero unused member SID storage")
		}
	}
	image := raw.image
	start := uintptr(unsafe.Pointer(image.data))
	if image.data == nil || image.len == 0 || image.len > C.MH_MEMBERS_MAX_IMAGE_UNITS ||
		start%unsafe.Alignof(uint16(0)) != 0 || start > ^uintptr(0)-uintptr(image.len)*2 {
		return MemberIdentity{}, invalidMember("invalid member image storage")
	}
	units := append([]uint16(nil), unsafe.Slice((*uint16)(unsafe.Pointer(image.data)), int(image.len))...)
	for _, unit := range units {
		if unit == 0 {
			return MemberIdentity{}, invalidMember("embedded member image terminator")
		}
	}
	// Decode only for the absolute-path predicate; retain the original units,
	// including unpaired surrogates, without normalization or UTF-8 conversion.
	if !filepath.IsAbs(string(utf16.Decode(units))) {
		return MemberIdentity{}, invalidMember("relative member image")
	}
	return MemberIdentity{PID: uint32(raw.pid), CreationTime100ns: uint64(raw.creation_time_100ns),
		ImagePathUTF16: units, TokenUserSID: append([]byte(nil), sid[:n]...)}, nil
}

func copyMemberResources(pointer *C.mh_member_resource, count C.size_t) ([]MemberResource, error) {
	if err := memberArrayStorage(unsafe.Pointer(pointer), count, C.sizeof_mh_member_resource, unsafe.Alignof(C.mh_member_resource{})); err != nil {
		return nil, err
	}
	var resources []MemberResource
	if count != 0 {
		resources = make([]MemberResource, int(count))
	}
	borrowed, attempted, open := 0, false, false
	for i, raw := range unsafe.Slice(pointer, int(count)) {
		flags := uint32(raw.flags)
		r := MemberResource{PID: uint32(raw.pid), BorrowedOriginal: flags&C.MH_MEMBER_BORROWED_ORIGINAL != 0,
			CloseAttempted: flags&C.MH_MEMBER_CLOSE_ATTEMPTED != 0, Closed: flags&C.MH_MEMBER_CLOSED != 0,
			CloseFailed: flags&C.MH_MEMBER_CLOSE_FAILED != 0, CloseError: int32(raw.close_error)}
		if raw.reserved != 0 || flags & ^uint32(15) != 0 || r.PID == 0 ||
			(i != 0 && resources[i-1].PID >= r.PID) {
			return nil, invalidMember("invalid resource layout or PID order")
		}
		if r.BorrowedOriginal {
			borrowed++
			if flags != C.MH_MEMBER_BORROWED_ORIGINAL || r.CloseError != 0 || borrowed > 1 {
				return nil, invalidMember("borrowed original resource has close fields")
			}
		} else if r.CloseAttempted {
			attempted = true
			if r.Closed == r.CloseFailed || (!r.CloseFailed && r.CloseError != 0) {
				return nil, invalidMember("close attempt omitted or contradicted its result")
			}
		} else {
			open = true
			if r.Closed || r.CloseFailed || r.CloseError != 0 {
				return nil, invalidMember("unattempted close contains a result")
			}
		}
		resources[i] = r
	}
	if attempted && open {
		return nil, invalidMember("partly published batch close")
	}
	return resources, nil
}

func sameMemberCensus(a, b *MemberCensus) bool {
	return a != nil && b != nil && a.TotalProcesses == b.TotalProcesses &&
		a.ActiveProcesses == b.ActiveProcesses && slices.Equal(a.PIDs, b.PIDs)
}

func copyMemberSnapshot(raw *C.mh_members_snapshot, bytes C.uint32_t, generation uint64) (MemberSnapshot, error) {
	if raw == nil || bytes != C.sizeof_mh_members_snapshot ||
		uintptr(unsafe.Pointer(raw))%unsafe.Alignof(C.mh_members_snapshot{}) != 0 {
		return MemberSnapshot{}, invalidMember("invalid snapshot storage")
	}
	flags := uint32(raw.flags)
	if raw.size != C.sizeof_mh_members_snapshot || raw.version != C.MH_MEMBERS_VERSION ||
		raw.reserved != 0 || flags & ^uint32(7) != 0 || generation == 0 || uint64(raw.generation) != generation ||
		raw.original.reserved != 0 || raw.original.pid == 0 || raw.original.creation_time_100ns == 0 {
		return MemberSnapshot{}, invalidMember("incompatible snapshot layout or generation")
	}
	v := MemberSnapshot{Generation: generation,
		Original:            MemberOriginalCreation{PID: uint32(raw.original.pid), CreationTime100ns: uint64(raw.original.creation_time_100ns)},
		AcquisitionComplete: flags&C.MH_MEMBERS_ACQUISITION_COMPLETE != 0}
	var err error
	v.Pre, err = copyMemberCensus(raw.pre, flags&C.MH_MEMBERS_PRE_KNOWN != 0)
	if err != nil {
		return MemberSnapshot{}, err
	}
	v.Post, err = copyMemberCensus(raw.post, flags&C.MH_MEMBERS_POST_KNOWN != 0)
	if err != nil {
		return MemberSnapshot{}, err
	}
	v.Resources, err = copyMemberResources(raw.resources, raw.resource_count)
	if err != nil {
		return MemberSnapshot{}, err
	}
	if err := memberArrayStorage(unsafe.Pointer(raw.rows), raw.row_count, C.sizeof_mh_member_identity, unsafe.Alignof(C.mh_member_identity{})); err != nil {
		return MemberSnapshot{}, err
	}
	if (v.Pre == nil && (v.Post != nil || len(v.Resources) != 0)) ||
		uint64(raw.row_count) > uint64(len(v.Resources)) ||
		(v.Pre != nil && len(v.Resources) > len(v.Pre.PIDs)) ||
		(v.Post != nil && (len(v.Resources) != len(v.Pre.PIDs) || uint64(raw.row_count) != uint64(len(v.Resources)))) {
		return MemberSnapshot{}, invalidMember("partial snapshot lost its retained prefix")
	}
	for i, resource := range v.Resources {
		if resource.PID != v.Pre.PIDs[i] || resource.BorrowedOriginal != (resource.PID == v.Original.PID) {
			return MemberSnapshot{}, invalidMember("resource is outside the original retained prefix")
		}
	}
	if raw.row_count != 0 {
		v.Rows = make([]MemberIdentity, int(raw.row_count))
	}
	for i, row := range unsafe.Slice(raw.rows, int(raw.row_count)) {
		v.Rows[i], err = copyMemberIdentity(row)
		if err != nil {
			return MemberSnapshot{}, err
		}
		if v.Rows[i].PID != v.Resources[i].PID ||
			(v.Rows[i].PID == v.Original.PID && v.Rows[i].CreationTime100ns != v.Original.CreationTime100ns) {
			return MemberSnapshot{}, invalidMember("identity row contradicts retained custody")
		}
	}
	if v.AcquisitionComplete && (!sameMemberCensus(v.Pre, v.Post) || len(v.Rows) == 0 ||
		len(v.Rows) != len(v.Resources) || len(v.Rows) != len(v.Pre.PIDs)) {
		return MemberSnapshot{}, invalidMember("complete snapshot omitted its full stable census")
	}
	return v, nil
}

func copyMemberClose(raw *C.mh_members_close, bytes C.uint32_t, generation uint64) (MemberClose, error) {
	if raw == nil || bytes != C.sizeof_mh_members_close ||
		uintptr(unsafe.Pointer(raw))%unsafe.Alignof(C.mh_members_close{}) != 0 {
		return MemberClose{}, invalidMember("invalid close receipt storage")
	}
	if raw.size != C.sizeof_mh_members_close || raw.version != C.MH_MEMBERS_VERSION ||
		raw.reserved != 0 || uint32(raw.flags) & ^uint32(C.MH_MEMBERS_CLOSE_COMPLETE) != 0 ||
		generation == 0 || uint64(raw.generation) != generation {
		return MemberClose{}, invalidMember("incompatible close receipt or generation")
	}
	resources, err := copyMemberResources(raw.resources, raw.resource_count)
	if err != nil {
		return MemberClose{}, err
	}
	cleanupComplete := true
	for _, resource := range resources {
		if !resource.BorrowedOriginal && !resource.CloseAttempted {
			return MemberClose{}, invalidMember("final close receipt contains an unattempted resource")
		}
		cleanupComplete = cleanupComplete && !resource.CloseFailed
	}
	if cleanupComplete != (raw.flags&C.MH_MEMBERS_CLOSE_COMPLETE != 0) {
		return MemberClose{}, invalidMember("cleanup completeness contradicts close errors")
	}
	return MemberClose{Generation: generation, CleanupComplete: cleanupComplete, Resources: resources}, nil
}

// This bounded metadata binding stores no native handles, image or SID bytes.
// Acquisition is finished before a snapshot can be copied under the owner lock;
// its held resource set cannot subsequently grow within the same generation.
type memberResourceBinding struct {
	generation uint64
	original   MemberOriginalCreation
	resources  []MemberResource
}

func sameMemberResourceSet(a, b []MemberResource) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i].PID != b[i].PID || a[i].BorrowedOriginal != b[i].BorrowedOriginal {
			return false
		}
	}
	return true
}

// rememberMemberSnapshot requires the same owner mutex as acquisition/close.
func (o *Owner) rememberMemberSnapshot(v MemberSnapshot) error {
	if prior := o.membersObserved; prior != nil && prior.generation == v.Generation {
		if prior.original != v.Original || !sameMemberResourceSet(prior.resources, v.Resources) {
			return invalidMember("historical snapshot changed original binding or retained resources")
		}
	}
	if closed := o.membersClose; closed != nil && closed.Generation == v.Generation &&
		!slices.Equal(closed.Resources, v.Resources) {
		return invalidMember("historical snapshot contradicts validated close receipt")
	}
	if o.membersObserved == nil || o.membersObserved.generation != v.Generation {
		keys := make([]MemberResource, len(v.Resources))
		for i, resource := range v.Resources {
			keys[i] = MemberResource{PID: resource.PID, BorrowedOriginal: resource.BorrowedOriginal}
		}
		o.membersObserved = &memberResourceBinding{generation: v.Generation, original: v.Original, resources: keys}
	}
	return nil
}

func cloneMemberClose(v MemberClose) MemberClose {
	v.Resources = slices.Clone(v.Resources)
	return v
}

func sameMemberClose(a, b MemberClose) bool {
	return a.Generation == b.Generation && a.CloseFinalized == b.CloseFinalized &&
		a.CleanupComplete == b.CleanupComplete && slices.Equal(a.Resources, b.Resources)
}

type memberSnapshotCall struct {
	generation uint64
	value      MemberSnapshot
	calls      int
	err        error
}

//export mh_go_members_snapshot
func mh_go_members_snapshot(raw *C.mh_members_snapshot, bytes C.uint32_t, token C.uintptr_t) {
	var state *memberSnapshotCall
	returned := false
	defer func() {
		if !returned {
			_ = recover()
			if state != nil {
				state.value = MemberSnapshot{}
				state.err = errors.Join(state.err, invalidMember("snapshot receiver panicked"))
			}
		}
	}()
	state = cgo.Handle(token).Value().(*memberSnapshotCall)
	state.calls++
	if state.calls != 1 {
		state.value = MemberSnapshot{}
		state.err = errors.Join(state.err, invalidMember("repeated snapshot receiver"))
		returned = true
		return
	}
	state.value, state.err = copyMemberSnapshot(raw, bytes, state.generation)
	returned = true
}

type memberCloseCall struct {
	generation uint64
	value      MemberClose
	calls      int
	err        error
}

//export mh_go_members_close
func mh_go_members_close(raw *C.mh_members_close, bytes C.uint32_t, token C.uintptr_t) {
	var state *memberCloseCall
	returned := false
	defer func() {
		if !returned {
			_ = recover()
			if state != nil {
				state.value = MemberClose{}
				state.err = errors.Join(state.err, invalidMember("close receiver panicked"))
			}
		}
	}()
	state = cgo.Handle(token).Value().(*memberCloseCall)
	state.calls++
	if state.calls != 1 {
		state.value = MemberClose{}
		state.err = errors.Join(state.err, invalidMember("repeated close receiver"))
		returned = true
		return
	}
	state.value, state.err = copyMemberClose(raw, bytes, state.generation)
	returned = true
}
