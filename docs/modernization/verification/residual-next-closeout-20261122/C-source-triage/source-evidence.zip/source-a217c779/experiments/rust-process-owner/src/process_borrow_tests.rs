//! Original HANDLE borrowing uses only this test's suspended native owner.
use super::native_failure_tests::{stop_and_finish, suspended};
use super::*;
use windows_sys::Win32::System::Threading::SuspendThread;

const WAIT: Duration = Duration::from_secs(3);

#[test]
fn original_borrow_is_exact_synchronous_and_does_not_resume_or_consume_admission() {
    let mut owner = suspended();
    let expected = owner.process.as_ref().unwrap().as_raw_handle();
    let pid = owner.root_pid();
    for accepted in [true, false, true] {
        let observed = owner
            .with_original_process_handle(|handle| {
                assert_eq!(handle.as_raw_handle(), expected);
                // SAFETY: this handle is retained by the owner through the query.
                assert_eq!(unsafe { GetProcessId(handle.as_raw_handle()) }, pid);
                accepted
            })
            .unwrap();
        assert_eq!(observed, accepted);
        assert!(!owner.admission_attempted);
        assert_eq!(owner.root_exit(), None);
    }
    let thread = owner.thread.as_ref().unwrap().as_raw_handle();
    // SAFETY: the fixture owns the original suspended thread. Raising and then
    // restoring its suspend count is only a test observation, not production.
    assert_eq!(unsafe { SuspendThread(thread) }, 1);
    // SAFETY: restore precisely the fixture's added suspension, leaving one.
    assert_eq!(unsafe { ResumeThread(thread) }, 2);
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.finish(WAIT).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
}

#[test]
fn original_borrow_remains_available_after_denial_and_root_exit_without_settlement() {
    let mut denied = suspended();
    assert_eq!(
        denied
            .admit_and_resume(|_| Err(io::ErrorKind::PermissionDenied.into()))
            .unwrap_err()
            .kind(),
        io::ErrorKind::PermissionDenied
    );
    let pid = denied.root_pid();
    assert_eq!(
        denied
            .with_original_process_handle(|handle| {
                // SAFETY: original handle remains owned despite admission denial.
                unsafe { GetProcessId(handle.as_raw_handle()) }
            })
            .unwrap(),
        pid
    );
    stop_and_finish(&mut denied);

    let mut exited = suspended();
    exited.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(exited.wait_root(WAIT).unwrap(), Some(0));
    let original = exited.process.as_ref().unwrap().as_raw_handle();
    exited
        .with_original_process_handle(|handle| assert_eq!(handle.as_raw_handle(), original))
        .unwrap();
    assert!(
        exited.terminal.is_none(),
        "a query must not close the owner"
    );
    assert_eq!(
        exited.finish(WAIT).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
}

#[test]
fn recorded_stop_and_terminal_close_forbid_callback_entry() {
    let mut owner = suspended();
    owner.terminate(83).unwrap();
    let mut calls = 0;
    assert!(owner.with_original_process_handle(|_| calls += 1).is_err());
    assert_eq!(calls, 0);
    assert_eq!(
        owner.finish(WAIT).unwrap(),
        Settlement::Complete { root_exit: 83 }
    );
    assert!(owner.with_original_process_handle(|_| calls += 1).is_err());
    assert_eq!(calls, 0);
}

#[test]
fn incomplete_native_custody_rejects_borrow_without_consuming_admission() {
    let mut owner = suspended();
    let process = owner.process.take();
    let mut calls = 0;
    assert!(owner.with_original_process_handle(|_| calls += 1).is_err());
    assert_eq!(calls, 0);
    assert!(!owner.admission_attempted);
    owner.process = process;
    stop_and_finish(&mut owner);
}
