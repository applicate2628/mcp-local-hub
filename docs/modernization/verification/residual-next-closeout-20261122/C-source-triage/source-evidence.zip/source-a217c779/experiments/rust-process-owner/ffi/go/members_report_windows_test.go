//go:build windows && amd64 && cgo

package caller

import (
	"errors"
	"syscall"
	"testing"
)

func TestMemberErrorPresenceDoesNotDependOnNonzeroCodes(t *testing.T) {
	for _, test := range []struct {
		name       string
		source     MemberErrorSource
		kind       MemberErrorKind
		native     int32
		tokenClose int32
		causes     []syscall.Errno
	}{
		{"zero-native", MemberSourceObservation, MemberNativeError, 0, 0, []syscall.Errno{0}},
		{"zero-cleanup-only", MemberSourceTokenCleanup, MemberNoError, 0, 0, []syscall.Errno{0}},
		{"zero-query-with-close", MemberSourceTokenCleanup, MemberNativeError, 0, 6, []syscall.Errno{0, 6}},
		{"query-with-zero-close", MemberSourceTokenCleanup, MemberNativeError, 5, 0, []syscall.Errno{5, 0}},
		{"high-bit-native", MemberSourceCopy, MemberNativeError, -1, 0, []syscall.Errno{0xffffffff}},
	} {
		t.Run(test.name, func(t *testing.T) {
			err := memberErrorResult(test.source, test.kind, test.native, test.tokenClose)
			var got *MemberError
			if !errors.As(err, &got) || got.Source != test.source || got.Kind != test.kind ||
				got.NativeError != test.native || got.TokenCloseError != test.tokenClose ||
				len(got.Unwrap()) != len(test.causes) {
				t.Fatalf("error presence changed: %+v %v", got, err)
			}
			for _, cause := range test.causes {
				if !errors.Is(err, cause) {
					t.Fatalf("native error bits/presence lost: %v in %v", cause, err)
				}
			}
		})
	}
	if err := memberErrorResult(MemberSourceNone, MemberNoError, 0, 0); err != nil {
		t.Fatalf("canonical absent failure became an error: %v", err)
	}
}

func TestMemberErrorRejectsUnattributedFailureFields(t *testing.T) {
	for _, test := range []struct {
		name       string
		source     MemberErrorSource
		kind       MemberErrorKind
		native     int32
		tokenClose int32
	}{
		{"no-source", MemberSourceNone, MemberNativeError, 0, 0},
		{"missing-observation-failure", MemberSourceObservation, MemberNoError, 0, 0},
		{"query-code-without-native-kind", MemberSourceObservation, MemberInvalidData, 5, 0},
		{"cleanup-without-cleanup-source", MemberSourceTokenUser, MemberNativeError, 5, 6},
		{"close-only-invents-query", MemberSourceTokenCleanup, MemberNoError, 5, 0},
		{"unknown-source", MemberSourceTokenCleanup + 1, MemberOtherError, 0, 0},
		{"unknown-kind", MemberSourceObservation, MemberInvalidState + 1, 0, 0},
	} {
		t.Run(test.name, func(t *testing.T) {
			if err := memberErrorResult(test.source, test.kind, test.native, test.tokenClose); !errors.Is(err, ErrMemberObservation) {
				t.Fatalf("incoherent error report accepted: %v", err)
			}
		})
	}
}
