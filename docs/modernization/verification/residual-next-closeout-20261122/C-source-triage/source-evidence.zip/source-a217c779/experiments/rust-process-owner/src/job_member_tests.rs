use super::super::native_failure_tests::{
    denied, duplicate_with_access, handle_count, restrict, stop_and_finish, suspended,
};
use super::*;
use crate::Settlement;
use std::{
    fs,
    path::Path,
    sync::atomic::{AtomicU64, Ordering},
    thread,
    time::Duration,
};
use windows_sys::Win32::{
    Foundation::{
        GetHandleInformation, SetHandleInformation, FILETIME, HANDLE, HANDLE_FLAG_INHERIT,
        HANDLE_FLAG_PROTECT_FROM_CLOSE,
    },
    System::Threading::{GetProcessId, GetProcessTimes},
};

const WAIT: Duration = Duration::from_secs(3);
static NEXT_FIXTURE: AtomicU64 = AtomicU64::new(1);

fn observation_error(error: JobMemberQueryError) -> io::Error {
    match error {
        JobMemberQueryError::Observation(error) => error,
        JobMemberQueryError::TokenUser(error) => panic!("unexpected token-user failure: {error}"),
    }
}

// These bytes exercise parser bounds only. They are never published as a
// successful native observation or used to construct an owned process handle.
fn pid_bytes(assigned: u32, listed: u32, pids: &[usize]) -> Vec<u8> {
    let mut bytes = vec![0; PID_LIST_HEADER_BYTES];
    bytes[..4].copy_from_slice(&assigned.to_ne_bytes());
    bytes[4..8].copy_from_slice(&listed.to_ne_bytes());
    for pid in pids {
        bytes.extend_from_slice(&pid.to_ne_bytes());
    }
    bytes
}

#[test]
fn job_member_pid_parser_accepts_only_complete_bounded_sets() {
    let bytes = pid_bytes(3, 3, &[41, 7, 23]);
    assert_eq!(
        parse_job_process_ids(&bytes, bytes.len()).unwrap(),
        Some(vec![7, 23, 41])
    );
    let partial = pid_bytes(3, 1, &[41]);
    assert_eq!(
        parse_job_process_ids(&partial, partial.len()).unwrap(),
        None
    );
    let empty = pid_bytes(0, 0, &[]);
    assert_eq!(
        parse_job_process_ids(&empty, empty.len()).unwrap(),
        Some(Vec::new())
    );
}

#[test]
fn job_member_pid_parser_rejects_truncated_inconsistent_and_invalid_entries() {
    let valid = pid_bytes(1, 1, &[7]);
    assert!(parse_job_process_ids(&valid, PID_LIST_HEADER_BYTES - 1).is_err());
    assert!(parse_job_process_ids(&valid, valid.len() + 1).is_err());
    let malformed = vec![
        pid_bytes(1, 2, &[7, 11]),
        pid_bytes(2, 2, &[7]),
        pid_bytes(3, 2, &[7]),
        pid_bytes(u32::MAX, u32::MAX, &[]),
        pid_bytes(1, 1, &[0]),
        pid_bytes(2, 2, &[7, 7]),
    ];
    for bytes in malformed {
        assert!(parse_job_process_ids(&bytes, bytes.len()).is_err());
    }
    #[cfg(target_pointer_width = "64")]
    {
        let wide = pid_bytes(1, 1, &[(u32::MAX as usize) + 1]);
        assert!(parse_job_process_ids(&wide, wide.len()).is_err());
    }
}

#[test]
fn job_member_native_acquisition_errors_keep_partial_state_until_explicit_close() {
    for deny_job_query in [true, false] {
        let mut owner = suspended();
        let original = if deny_job_query {
            restrict(&mut owner.job, 0x0008) // JOB_OBJECT_TERMINATE, without QUERY.
        } else {
            restrict(&mut owner.process, PROCESS_QUERY_LIMITED_INFORMATION)
        };
        let failure = owner
            .observe_job_members(Instant::now() + WAIT)
            .unwrap_err();
        denied(&observation_error(failure));
        let partial = owner.job_member_snapshot().unwrap().clone();
        assert!(!partial.complete);
        assert_ne!(partial.generation, 0);
        assert!(partial.rows.is_empty() && partial.post.is_none());
        if deny_job_query {
            assert!(partial.pre.is_none() && partial.resources.is_empty());
        } else {
            assert_eq!(partial.pre.as_ref().unwrap().pids, vec![owner.root_pid()]);
            assert_eq!(partial.resources.len(), 1);
            assert!(partial.resources[0].borrowed_original);
        }
        assert_eq!(
            owner.terminate(91).unwrap_err().kind(),
            io::ErrorKind::WouldBlock
        );
        assert!(owner.termination.is_none() && !owner.admission_attempted);
        if deny_job_query {
            drop(owner.job.replace(original));
        } else {
            drop(owner.process.replace(original));
        }
        let closed = owner.close_job_members(partial.generation).unwrap().clone();
        assert!(closed.complete);
        assert!(closed
            .resources
            .iter()
            .all(|resource| !resource.close_attempted
                && !resource.closed
                && resource.close_error.is_none()));
        assert!(!owner.job_member_snapshot().unwrap().complete);
        assert_eq!(
            owner.close_job_members(partial.generation).unwrap(),
            &closed
        );
        assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), None);
        stop_and_finish(&mut owner);
    }
}

#[test]
fn job_member_generation_overflow_preserves_prior_closed_observation() {
    let mut owner = suspended();
    let generation = owner.observe_job_members(Instant::now() + WAIT).unwrap();
    let closed = owner.close_job_members(generation).unwrap().clone();
    let baseline = owner.job_member_snapshot().unwrap().clone();
    owner.member_generation = u64::MAX;
    assert!(matches!(
        owner.observe_job_members(Instant::now() + WAIT),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert_eq!(owner.member_generation, u64::MAX);
    assert!(
        owner.job_member_snapshot().unwrap() == &baseline,
        "generation exhaustion replaced the acquired facts"
    );
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    assert!(!owner.admission_attempted && owner.termination.is_none());
    stop_and_finish(&mut owner);
}

// Existing compiled fixture only: the runner must provide the matching-profile
// owner_child.exe path explicitly. Absence is a failure, never a skipped test.
fn member_tree(two_descendants: bool) -> NativeOwner {
    let executable = PathBuf::from(
        std::env::var_os("MCPHUB_RX02_OWNER_CHILD").expect("compiled owner_child fixture path"),
    );
    assert!(
        executable.is_absolute() && executable.is_file(),
        "owner_child fixture is missing"
    );
    let root = PathBuf::from(std::env::var_os("MCPHUB_RX02_FIXTURES").expect("owned fixture root"))
        .join(format!(
            "native-member-faults-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed),
        ));
    fs::create_dir(&root).unwrap();
    let marker = root.join("member marker.txt");
    let mode = if two_descendants { "tree-two" } else { "tree" };
    let mut owner =
        NativeOwner::create_suspended(&executable, &[mode.into(), marker.clone().into_os_string()])
            .unwrap();
    owner.admit_and_resume(|_| Ok(())).unwrap();
    let deadline = Instant::now() + WAIT;
    wait_marker(&marker, deadline);
    if two_descendants {
        wait_marker(&marker.with_extension("grandchild-0"), deadline);
        wait_marker(&marker.with_extension("grandchild-1"), deadline);
    } else {
        wait_marker(&marker.with_extension("grandchild"), deadline);
    }
    let expected = if two_descendants { 3 } else { 2 };
    while owner.active_processes().unwrap() != expected {
        assert!(
            Instant::now() < deadline,
            "owned fixture Job did not reach its member count: expected {expected}, actual {}",
            owner.active_processes().unwrap()
        );
        thread::sleep(Duration::from_millis(2));
    }
    owner
}

// A separate legacy-only control on the qualified Windows host observed a
// first-setup handle-count increase of three, then an exact plateau over two
// further rounds. The precise cause is not established. Warm only that
// old create/wait/close path here, never the member API under test, so each test
// also works in isolation. Its measured round must still return exactly to this
// baseline; per-close deltas and repeated-close checks remain strict.
fn member_handle_baseline() -> u32 {
    let mut owner = member_tree(true);
    stop_and_finish(&mut owner);
    drop(owner);
    handle_count()
}

// Fixture directories are retained for evidence and later trash-first handling.
fn wait_marker(path: &Path, deadline: Instant) {
    while !path.exists() {
        assert!(
            Instant::now() < deadline,
            "owned member fixture did not publish readiness"
        );
        thread::sleep(Duration::from_millis(2));
    }
}

// Advance only the real production acquisition stages and stop immediately
// after an actual descendant OpenProcess has entered the retained owner.
// No synthetic census, row or complete flag is installed by this fixture.
fn retain_first_descendant(owner: &mut NativeOwner, deadline: Instant) -> usize {
    loop {
        let index = owner.retain_next_job_member(deadline).unwrap();
        if matches!(
            &owner.member_observation.as_ref().unwrap().held[index],
            HeldMember::Owned(_)
        ) {
            return index;
        }
        owner.capture_retained_job_member(index, deadline).unwrap();
    }
}

fn descendant_handle(owner: &NativeOwner, index: usize) -> &OwnedHandle {
    match &owner.member_observation.as_ref().unwrap().held[index] {
        HeldMember::Owned(handle) => handle,
        HeldMember::Original => panic!("expected a real descendant handle"),
    }
}

fn replace_descendant_handle(
    owner: &mut NativeOwner,
    index: usize,
    handle: OwnedHandle,
) -> OwnedHandle {
    match &mut owner.member_observation.as_mut().unwrap().held[index] {
        HeldMember::Owned(slot) => std::mem::replace(slot, handle),
        HeldMember::Original => panic!("cannot replace the borrowed original root"),
    }
}

#[test]
fn job_member_partial_owned_capture_failure_keeps_the_real_descendant_until_close() {
    let before = member_handle_baseline();
    let mut owner = member_tree(false);
    let deadline = Instant::now() + WAIT;
    let generation = owner.begin_job_members(deadline).unwrap();
    let index = retain_first_descendant(&mut owner, deadline);
    let pid = owner.job_member_snapshot().unwrap().resources[index].pid;
    let acquired = descendant_handle(&owner, index).as_raw_handle();
    // SAFETY: this is the actual OpenProcess result retained by production.
    assert_eq!(unsafe { GetProcessId(acquired) }, pid);
    let restricted = duplicate_with_access(descendant_handle(&owner, index), PROCESS_SYNCHRONIZE);
    let original = replace_descendant_handle(&mut owner, index, restricted);
    let failure = owner
        .capture_retained_job_member(index, deadline)
        .unwrap_err();
    denied(&observation_error(failure));
    let partial = owner.job_member_snapshot().unwrap().clone();
    assert!(!partial.complete && partial.post.is_none());
    assert_eq!(partial.rows.len(), index);
    assert_eq!(partial.resources.len(), index + 1);
    assert_eq!(
        owner.member_observation.as_ref().unwrap().held.len(),
        index + 1
    );
    let resource = &partial.resources[index];
    assert_eq!(resource.pid, pid);
    assert!(!resource.borrowed_original);
    assert!(!resource.close_attempted && !resource.closed && resource.close_error.is_none());
    let mut flags = 0;
    // SAFETY: failed identity capture must have retained this actual owned slot.
    assert_ne!(
        unsafe {
            GetHandleInformation(descendant_handle(&owner, index).as_raw_handle(), &mut flags)
        },
        0
    );
    assert_eq!(
        owner.terminate(91).unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );

    // Only the fixture restores its own original handle; production never
    // retries acquisition, reopens the PID or repairs the incomplete baseline.
    drop(replace_descendant_handle(&mut owner, index, original));
    let closed = owner.close_job_members(generation).unwrap().clone();
    assert!(closed.complete);
    let resource = closed
        .resources
        .iter()
        .find(|resource| resource.pid == pid)
        .unwrap();
    assert!(!resource.borrowed_original);
    assert!(resource.close_attempted && resource.closed && resource.close_error.is_none());
    assert!(!owner.job_member_snapshot().unwrap().complete);
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    stop_and_finish(&mut owner);
    drop(owner);
    assert_eq!(
        handle_count(),
        before,
        "partial descendant fixture leaked a native handle"
    );
}

#[test]
fn job_member_expired_capture_retains_owned_partial_and_allows_deadline_free_close() {
    let before = member_handle_baseline();
    let mut owner = member_tree(false);
    let deadline = Instant::now() + WAIT;
    let generation = owner.begin_job_members(deadline).unwrap();
    let index = retain_first_descendant(&mut owner, deadline);
    let partial = owner.job_member_snapshot().unwrap().clone();
    let raw = descendant_handle(&owner, index).as_raw_handle();
    // Wait for the same absolute deadline used by begin/retain. This asserts
    // stage refusal after expiry, not an upper bound or cancellation of syscalls.
    while Instant::now() < deadline {
        thread::sleep(deadline.saturating_duration_since(Instant::now()));
    }
    let error = observation_error(
        owner
            .capture_retained_job_member(index, deadline)
            .unwrap_err(),
    );
    assert_eq!(error.kind(), io::ErrorKind::TimedOut);
    assert!(
        owner.job_member_snapshot().unwrap() == &partial,
        "expired capture changed its partial facts"
    );
    assert!(!owner.job_member_snapshot().unwrap().complete);
    assert_eq!(descendant_handle(&owner, index).as_raw_handle(), raw);
    let mut flags = 0;
    // SAFETY: the exact acquired slot must remain owned after stage expiry.
    assert_ne!(unsafe { GetHandleInformation(raw, &mut flags) }, 0);
    let closed = owner.close_job_members(generation).unwrap().clone();
    assert!(closed.complete);
    assert!(closed.resources[index].close_attempted && closed.resources[index].closed);
    assert!(!owner.job_member_snapshot().unwrap().complete);
    stop_and_finish(&mut owner);
    drop(owner);
    assert_eq!(
        handle_count(),
        before,
        "expired capture fixture leaked a native handle"
    );
}

#[test]
fn job_member_revalidation_queries_retained_descendant_and_uses_its_own_creation_time() {
    let before = member_handle_baseline();
    let mut owner = member_tree(false);
    let generation = owner.observe_job_members(Instant::now() + WAIT).unwrap();
    let baseline = owner.job_member_snapshot().unwrap().clone();
    let index = baseline
        .resources
        .iter()
        .position(|resource| !resource.borrowed_original)
        .unwrap();
    let row = &baseline.rows[index];
    let raw = descendant_handle(&owner, index).as_raw_handle();
    let mut flags = 0;
    // SAFETY: observation retains the non-inheritable real descendant handle.
    assert_ne!(unsafe { GetHandleInformation(raw, &mut flags) }, 0);
    assert_eq!(flags & HANDLE_FLAG_INHERIT, 0);
    // Independent direct Windows oracle; never use the production creation-time
    // helper to prove that the descendant row belongs to its own process.
    let mut created = FILETIME {
        dwLowDateTime: 0,
        dwHighDateTime: 0,
    };
    let mut exited = created;
    let mut kernel = created;
    let mut user = created;
    // SAFETY: this live retained handle and four distinct FILETIME outputs are valid.
    assert_ne!(
        unsafe { GetProcessTimes(raw, &mut created, &mut exited, &mut kernel, &mut user) },
        0
    );
    let actual_birth = (u64::from(created.dwHighDateTime) << 32) | u64::from(created.dwLowDateTime);
    assert_ne!(actual_birth, 0);
    assert_eq!(row.creation_time_100ns, actual_birth);
    // SAFETY: independent PID observation on the same live descendant handle.
    assert_eq!(unsafe { GetProcessId(raw) }, row.pid);

    let restricted = duplicate_with_access(descendant_handle(&owner, index), PROCESS_SYNCHRONIZE);
    let restricted_raw = restricted.as_raw_handle();
    let original = replace_descendant_handle(&mut owner, index, restricted);
    let failure = owner
        .revalidate_job_members(generation, Instant::now() + WAIT, Some(row.pid))
        .unwrap_err();
    denied(&observation_error(failure));
    assert!(
        owner.job_member_snapshot().unwrap() == &baseline,
        "failed revalidation replaced the acquired baseline"
    );
    assert_eq!(
        descendant_handle(&owner, index).as_raw_handle(),
        restricted_raw,
        "revalidation replaced the restricted held handle"
    );
    assert_eq!(
        owner.terminate(91).unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    drop(replace_descendant_handle(&mut owner, index, original));
    owner
        .revalidate_job_members(generation, Instant::now() + WAIT, Some(row.pid))
        .unwrap();
    assert!(owner.close_job_members(generation).unwrap().complete);
    stop_and_finish(&mut owner);
    drop(owner);
    assert_eq!(
        handle_count(),
        before,
        "descendant revalidation fixture leaked a native handle"
    );
}

// This guard owns the entire real NativeOwner before setting protection. Every
// assertion/unwind therefore removes the fixture's flag before its owner drops.
// Only an exactly protected, detached handle may be reclaimed numerically;
// no second OwnedHandle alias or production retry is ever introduced.
struct ProtectedMemberOwner {
    owner: NativeOwner,
    raw: HANDLE,
}
impl ProtectedMemberOwner {
    fn new(owner: NativeOwner, index: usize) -> Self {
        let raw = descendant_handle(&owner, index).as_raw_handle();
        let fixture = Self { owner, raw };
        // SAFETY: the fixture owns the real observation and its selected handle.
        assert_ne!(
            unsafe {
                SetHandleInformation(
                    raw,
                    HANDLE_FLAG_PROTECT_FROM_CLOSE,
                    HANDLE_FLAG_PROTECT_FROM_CLOSE,
                )
            },
            0
        );
        fixture
    }
}
impl Drop for ProtectedMemberOwner {
    fn drop(&mut self) {
        let mut flags = 0;
        // SAFETY: protection has remained set since the fixture installed it,
        // so successful close/recycling was impossible.
        if unsafe { GetHandleInformation(self.raw, &mut flags) } == 0
            || flags & HANDLE_FLAG_PROTECT_FROM_CLOSE == 0
        {
            eprintln!("member fixture protection lost; refusing numeric-handle cleanup");
            return;
        }
        let retained = self
            .owner
            .member_observation
            .as_ref()
            .is_some_and(|observation| {
                observation.held.iter().any(|member| match member {
                    HeldMember::Owned(handle) => handle.as_raw_handle() == self.raw,
                    HeldMember::Original => false,
                })
            });
        // SAFETY: still exactly this fixture's protected handle; clear its flag.
        if unsafe { SetHandleInformation(self.raw, HANDLE_FLAG_PROTECT_FROM_CLOSE, 0) } == 0 {
            eprintln!("member fixture could not remove close protection");
            return;
        }
        if !retained {
            // SAFETY: production consumed its sole owner on failed close;
            // protection proves this is still the same fixture-owned handle.
            if unsafe { CloseHandle(self.raw) } == 0 {
                eprintln!("member fixture final close failed");
            }
        }
    }
}

#[test]
fn job_member_close_failure_is_cached_drains_guard_and_closes_other_owned_descendant() {
    let before = member_handle_baseline();
    let mut owner = member_tree(true);
    let generation = owner.observe_job_members(Instant::now() + WAIT).unwrap();
    let acquisition = owner.job_member_snapshot().unwrap().clone();
    assert_eq!(acquisition.rows.len(), 3);
    assert_eq!(
        acquisition
            .resources
            .iter()
            .filter(|resource| !resource.borrowed_original)
            .count(),
        2
    );
    let index = acquisition
        .resources
        .iter()
        .position(|resource| !resource.borrowed_original)
        .unwrap();
    let protected_pid = acquisition.resources[index].pid;
    let mut fixture = ProtectedMemberOwner::new(owner, index);
    let with_observation = handle_count();

    // Fixture-only native error oracle, not an owner retry or a fake syscall.
    // SAFETY: the fixture owns this protected handle; the flag prevents
    // successful closure/recycling throughout this deliberate rejected probe.
    let rejected = unsafe { CloseHandle(fixture.raw) };
    let expected_error = io::Error::last_os_error().raw_os_error().unwrap();
    assert_eq!(rejected, 0);
    let first = fixture.owner.close_job_members(generation).unwrap().clone();
    assert!(!first.complete);
    let protected = first
        .resources
        .iter()
        .find(|resource| resource.pid == protected_pid)
        .unwrap();
    assert!(protected.close_attempted && !protected.closed);
    assert_eq!(
        protected.close_error,
        Some(NativeFailure {
            operation: "CloseJobMemberProcess",
            code: expected_error,
        })
    );
    let others: Vec<_> = first
        .resources
        .iter()
        .filter(|resource| !resource.borrowed_original && resource.pid != protected_pid)
        .collect();
    assert_eq!(others.len(), 1);
    assert!(others[0].close_attempted && others[0].closed && others[0].close_error.is_none());
    let root = first
        .resources
        .iter()
        .find(|resource| resource.borrowed_original)
        .unwrap();
    assert!(!root.close_attempted && !root.closed && root.close_error.is_none());
    assert!(
        fixture
            .owner
            .member_observation
            .as_ref()
            .unwrap()
            .held
            .is_empty(),
        "a consumed failed handle remains available for an implicit retry"
    );
    assert_eq!(
        handle_count(),
        with_observation - 1,
        "close did not release the second real owned descendant after the first failure"
    );
    assert_eq!(fixture.owner.close_job_members(generation).unwrap(), &first);
    assert_eq!(
        handle_count(),
        with_observation - 1,
        "cached close touched native resources"
    );
    let snapshot = fixture.owner.job_member_snapshot().unwrap();
    assert!(
        snapshot.pre == acquisition.pre
            && snapshot.post == acquisition.post
            && snapshot.rows == acquisition.rows
            && snapshot.complete,
        "close rewrote acquisition facts"
    );
    assert_eq!(snapshot.resources, first.resources);
    let mut flags = 0;
    // SAFETY: the fixture still guards its original protected descendant handle.
    assert_ne!(unsafe { GetHandleInformation(fixture.raw, &mut flags) }, 0);
    assert_ne!(flags & HANDLE_FLAG_PROTECT_FROM_CLOSE, 0);

    // Failed cleanup finalizes the observation guard. It must not seal original
    // termination/close forever, and a later replay must retain the first error.
    fixture.owner.terminate(83).unwrap();
    assert_eq!(
        fixture.owner.finish(WAIT).unwrap(),
        Settlement::Complete { root_exit: 83 }
    );
    assert_eq!(fixture.owner.close_job_members(generation).unwrap(), &first);
    drop(fixture);
    assert_eq!(
        handle_count(),
        before,
        "protected member fixture leaked a native handle"
    );
}
