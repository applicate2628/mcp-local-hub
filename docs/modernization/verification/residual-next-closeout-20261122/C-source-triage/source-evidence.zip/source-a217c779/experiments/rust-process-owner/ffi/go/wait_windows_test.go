//go:build windows && amd64 && cgo

package caller

import (
	"errors"
	"path/filepath"
	"testing"
	"time"
)

func TestSplitWaitRetainsOwnerUntilExplicitClose(t *testing.T) {
	lib, child, dir := setup(t)
	marker := filepath.Join(dir, "split-exit")
	owner, initial, err := lib.New(child, dir, []string{"exit", marker, "259", "done"})
	if owner != nil {
		own(t, owner)
	}
	if err != nil {
		t.Fatal(err)
	}
	original := owner.raw
	observed, err := owner.WaitForExit(0)
	if err != nil || observed.State != waitPending || observed.Flags != 0 || observed.PID != initial.PID {
		t.Fatalf("suspended wait: %+v %v", observed, err)
	}
	_, err = owner.WaitForExit(60001)
	requireStatus(t, err, argument)
	out, err := owner.CloseExited()
	requireStatus(t, err, notSettled)
	if out.State != 0 || owner.raw != original {
		t.Fatalf("early close changed ownership: %+v", out)
	}
	absent(t, marker)
	if _, err = owner.Admit(true); err != nil {
		t.Fatal(err)
	}
	observed, err = owner.WaitForExit(3000)
	want := ExitObservation{State: waitExited, Flags: 3, PID: initial.PID, RootExit: 259}
	if err != nil || observed != want {
		t.Fatalf("exit observation: %+v %v; want %+v", observed, err, want)
	}
	requireStatus(t, owner.Release(), notSettled)
	if owner.raw != original || lib.live != 1 || lib.Close() == nil {
		t.Fatal("exit observation released ownership or allowed DLL unload")
	}
	again, err := owner.WaitForExit(0)
	if err != nil || again != observed {
		t.Fatalf("observation consumed original resources: %+v %v", again, err)
	}
	out, err = owner.CloseExited()
	if err != nil || out.State != complete || out.RootExit != 259 || owner.raw != original {
		t.Fatalf("explicit close: %+v %v", out, err)
	}
	cached, err := owner.CloseExited()
	if err != nil || cached != out {
		t.Fatalf("close result changed: %+v %v", cached, err)
	}
	cached, err = owner.Finish(0)
	if err != nil || cached != out {
		t.Fatalf("legacy finish lost shared terminal result: %+v %v", cached, err)
	}
	observed, err = owner.WaitForExit(0)
	requireStatus(t, err, invalidState)
	if observed.State != 0 || observed.Flags != 1 || observed.RootExit != 259 {
		t.Fatalf("closed owner fabricated fresh exit facts: %+v", observed)
	}
	if err = owner.Release(); err != nil {
		t.Fatal(err)
	}
	if _, err = owner.WaitForExit(0); err == nil {
		t.Fatal("released owner used by wait")
	}
	if _, err = owner.CloseExited(); err == nil {
		t.Fatal("released owner used by close")
	}
}

func TestSplitWaitRetainsLiveDescendantAndOriginalRootExit(t *testing.T) {
	lib, child, dir := setup(t)
	owner, _, err := lib.New(child, dir, []string{"detach", filepath.Join(dir, "split-root")})
	if owner != nil {
		own(t, owner)
	}
	if err != nil {
		t.Fatal(err)
	}
	if _, err = owner.Admit(true); err != nil {
		t.Fatal(err)
	}
	var observed ExitObservation
	deadline := time.Now().Add(3 * time.Second)
	for {
		observed, err = owner.WaitForExit(25)
		if err != nil || observed.Flags&1 != 0 || time.Now().After(deadline) {
			break
		}
	}
	if err != nil || observed.State != waitPending || observed.Flags != 3 || observed.RootExit != 7 || observed.Active == 0 {
		t.Fatalf("live descendant lost: %+v %v", observed, err)
	}
	out, err := owner.CloseExited()
	requireStatus(t, err, notSettled)
	if out.State != 0 || out.Flags != 1 || out.RootExit != 7 {
		t.Fatalf("refused close fabricated settlement: %+v", out)
	}
	requireStatus(t, owner.Release(), notSettled)
	if _, err = owner.Stop(81); err != nil {
		t.Fatal(err)
	}
	observed, err = owner.WaitForExit(3000)
	if err != nil || observed.State != waitExited || observed.RootExit != 7 || observed.Active != 0 {
		t.Fatalf("stop overwrote original root result: %+v %v", observed, err)
	}
	out, err = owner.CloseExited()
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("descendant settlement: %+v %v", out, err)
	}
}

func TestSplitCloseRechecksWithoutEarlierWait(t *testing.T) {
	lib, child, dir := setup(t)
	owner, _, err := lib.New(child, dir, []string{"exit", filepath.Join(dir, "close-first"), "7", "done"})
	if owner != nil {
		own(t, owner)
	}
	if err != nil {
		t.Fatal(err)
	}
	if _, err = owner.Admit(true); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(3 * time.Second)
	for {
		out, err := owner.CloseExited()
		if err == nil {
			if out.State != complete || out.RootExit != 7 {
				t.Fatalf("close without wait: %+v", out)
			}
			return
		}
		var callErr *CallError
		if !errors.As(err, &callErr) || callErr.Status != notSettled || time.Now().After(deadline) {
			t.Fatalf("close without wait did not settle: %+v %v", out, err)
		}
		time.Sleep(time.Millisecond)
	}
}

func TestSplitExitDecoderRejectsContradictoryFacts(t *testing.T) {
	valid := ExitObservation{State: waitExited, Flags: 3, PID: 7, RootExit: 259}
	cases := []struct {
		name                  string
		status, size, version uint32
		value                 ExitObservation
	}{
		{"short-layout", ok, 28, 1, valid},
		{"unknown-version", ok, 32, 2, valid},
		{"unknown-status", 99, 32, 1, ExitObservation{}},
		{"unknown-state", ok, 32, 1, ExitObservation{State: 3, PID: 7}},
		{"unknown-flags", ok, 32, 1, ExitObservation{State: waitExited, Flags: 7, PID: 7}},
		{"missing-state", ok, 32, 1, ExitObservation{}},
		{"error-with-exit", invalidState, 32, 1, valid},
		{"missing-native-code", nativeFailure, 32, 1, ExitObservation{}},
		{"unexpected-native-code", ok, 32, 1, ExitObservation{State: waitPending, PID: 7, NativeError: 5}},
		{"unflagged-root", ok, 32, 1, ExitObservation{State: waitPending, PID: 7, RootExit: 259}},
		{"unflagged-active", ok, 32, 1, ExitObservation{State: waitPending, PID: 7, Active: 1}},
		{"missing-pid", ok, 32, 1, ExitObservation{State: waitExited, Flags: 3, RootExit: 259}},
		{"error-active", invalidState, 32, 1, ExitObservation{Flags: 3, PID: 7, Active: 1}},
		{"pending-root-only", ok, 32, 1, ExitObservation{State: waitPending, Flags: 1, PID: 7}},
		{"pending-empty-job", ok, 32, 1, ExitObservation{State: waitPending, Flags: 3, PID: 7}},
		{"exited-live-job", ok, 32, 1, ExitObservation{State: waitExited, Flags: 3, PID: 7, Active: 1}},
		{"exited-unknown-job", ok, 32, 1, ExitObservation{State: waitExited, Flags: 1, PID: 7}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := exitResult(tc.status, tc.size, tc.version, tc.value)
			if got != (ExitObservation{}) || !errors.Is(err, ErrInvalidOutcome) {
				t.Fatalf("contradictory facts escaped: %+v %v", got, err)
			}
			if tc.status != ok {
				requireStatus(t, err, tc.status)
			}
		})
	}
	for _, value := range []ExitObservation{valid, {State: waitPending, PID: 7}, {State: waitPending, Flags: 3, PID: 7, RootExit: 259, Active: 1}} {
		if got, err := exitResult(ok, 32, 1, value); err != nil || got != value {
			t.Fatalf("valid facts rejected: %+v %v", got, err)
		}
	}
	native := ExitObservation{Flags: 1, PID: 7, RootExit: 259, NativeError: 5}
	got, err := exitResult(nativeFailure, 32, 1, native)
	var callErr *CallError
	if got != native || !errors.As(err, &callErr) || callErr.Native != 5 || errors.Is(err, ErrInvalidOutcome) {
		t.Fatalf("original native error lost: %+v %v", got, err)
	}
	got, err = exitResult(nativeFailure, 28, 1, native)
	if got != (ExitObservation{}) || !errors.As(err, &callErr) || callErr.Native != 0 || !errors.Is(err, ErrInvalidOutcome) {
		t.Fatalf("unknown layout was interpreted: %+v %v", got, err)
	}
}
