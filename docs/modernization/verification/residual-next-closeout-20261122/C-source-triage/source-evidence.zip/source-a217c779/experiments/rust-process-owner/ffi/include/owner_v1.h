#ifndef MCPHUB_OWNER_V1_H
#define MCPHUB_OWNER_V1_H
#include <stdint.h>
#include <stddef.h>

/* Experimental Windows x64 C ABI. Not a product API or hostile-memory sandbox.
 * All non-null pointers must be valid/aligned for their stated lengths. Inputs
 * stay immutable through the call and may be released immediately afterwards.
 * Owner calls/release require exclusive access; no stale/copied owner pointer,
 * overlapping buffers or reentrant owner calls. DLL stays loaded until all owners release.
 * Expected errors are values; an unexpected Rust panic/abort terminates host. */
typedef struct mh_owner mh_owner;
typedef struct { const uint16_t *data; size_t len; } mh_u16;
typedef struct { mh_u16 name, value; } mh_env_entry;
typedef struct { const mh_env_entry *entries; size_t count; } mh_environment;
typedef struct {
    uint32_t version, reserved;
    mh_u16 program, cwd;
    const mh_u16 *args;
    size_t argc;
} mh_create;
typedef struct {
    uint32_t size, version, state, flags, pid, root_exit, active;
    int32_t native_error;
    uint32_t cleanup_mask;
    int32_t cleanup_codes[3]; /* thread, process, job; valid iff mask bit set */
} mh_out;
enum { MH_OK=0, MH_ARGUMENT=1, MH_ABI=2, MH_NATIVE=3,
       MH_DENIED=4, MH_STATE=5, MH_NOT_SETTLED=6 };
enum { MH_UNKNOWN=0, MH_PENDING=1, MH_COMPLETE=2, MH_CLEANUP_FAILED=3 };
enum { MH_ROOT_KNOWN=1, MH_ACTIVE_KNOWN=2 };
/* ABI1 outcome values are zero-initialized: inactive fields are zero, known
 * flags are limited to the two bits above, cleanup_mask uses only bits0..2,
 * and a slot is set iff its cleanup code is nonzero. Only MH_NATIVE carries
 * native_error, which must be nonzero. COMPLETE/CLEANUP_FAILED require a known
 * root exit, nonzero diagnostic pid and no active members. Cleanup codes occur
 * only in CLEANUP_FAILED, with at least one failed slot. MH_OK from finish
 * supplies PENDING/COMPLETE/CLEANUP_FAILED, not UNKNOWN. Validate layout even on
 * failure statuses; a bad observation does not revoke transferred ownership. */
/* Version 1: explicit absolute program/cwd, <=64 args, <=32766 UTF-16 units
 * per string and <=32766 aggregate units; embedded NUL rejected. Complete
 * EMPTY environment, no redirected stdio in this first calling-side slice.
 * out_owner must point to a NULL slot; failure never overwrites a live owner.
 * The numeric PID is diagnostic only, never a substitute for owner authority. */
typedef uint32_t (*mh_version_fn)(void);
typedef uint32_t (*mh_create_fn)(const mh_create*, uint32_t, mh_owner**, mh_out*, uint32_t);
/* Additive ABI1 export mh_create_env1. The original mh_create1 still uses a
 * complete EMPTY environment. New callers explicitly supply the whole
 * environment, never an overlay or implicit parent fallback. Empty count is
 * empty, not inherit. <=256 entries; <=32766 UTF16 units INCLUDING '=' and all
 * entry/block terminators; names strictly Windows-ordinal-ignore-case ordered
 * and unique. Ordinary names are nonempty and contain no '='; drive-directory
 * names are accepted only as '=[A-Za-z]:', with values preserved unchanged.
 * All strings copied before create returns; no parent environment is changed
 * or retained. Other creation,
 * admission and release rules are identical. env_bytes is sizeof(mh_environment). */
typedef uint32_t (*mh_create_env_fn)(const mh_create*, uint32_t,
    const mh_environment*, uint32_t, mh_owner**, mh_out*, uint32_t);
/* Additive explicit stdio create, ABI1 request/outcome layouts unchanged.
 * ONLY mh_create_io1 also accepts request.version=2 or 3, reserved=0. V2 args[0]
 * is explicit argv[0], independent of the absolute program image; argc is
 * 1..65 (at most 64 remaining arguments). V1 continues to exclude argv[0].
 * V2 uses Go x/sys/windows ComposeCommandLine first-token quoting and CRT
 * escaping for remaining arguments. Its copied-input aggregate includes
 * program, cwd, argv[0], and all remaining arguments (<=32766 UTF16 units).
 * The encoded command line has a separate <=32766-unit bound before NUL.
 * Environment budgets are unchanged. Legacy exports and older DLLs reject
 * request v2 with MH_ABI; no retry, normalization or implicit fallback.
 * V3 preserves ALL v2 argv[0], argument and environment rules. It additionally
 * requests foreground inheritance of this process's EXISTING console only:
 * one GetConsoleProcessList query before native acquisition; positive count
 * omits CREATE_NO_WINDOW; ERROR_INVALID_HANDLE keeps CREATE_NO_WINDOW; any
 * other query error refuses creation. V1/V2 always keep CREATE_NO_WINDOW.
 * No console is attached/allocated or handle classified by this operation.
 * V3 callers keep the parent's console association stable through return.
 * Explicit NoConsole callers use v2. Non-IO exports and older DLLs reject v3
 * with MH_ABI before creation; no retry, downgrade or fallback is permitted.
 * All unknown versions and nonzero reserved remain MH_ABI.
 * context and nested env are immutable until return. Three REAL, live,
 * inheritable disk/pipe/character handles borrowed from caller; no pseudo handles.
 * Character category is not NUL identification or console/serial qualification.
 * The DLL never changes source flags or closes these values. Caller owns
 * lifetime through synchronous CreateProcess and may close after return.
 * Raw handle validity is a native caller obligation, not a sandbox promise. */
typedef struct { uintptr_t stdin_handle, stdout_handle, stderr_handle; } mh_stdio;
typedef struct { mh_environment environment; mh_stdio streams; } mh_io_context;
typedef uint32_t (*mh_create_io_fn)(const mh_create*,uint32_t,const mh_io_context*,uint32_t,mh_owner**,mh_out*,uint32_t);
#if UINTPTR_MAX == UINT64_MAX
_Static_assert(sizeof(mh_stdio)==24 && sizeof(mh_io_context)==40, "stdio context layout");
_Static_assert(offsetof(mh_io_context,streams)==16, "stdio context offset");
#endif
/* Allow/deny is the caller's decision, not authorization or image validation.
 * A valid deny consumes the same one-shot NativeOwner admission as allow. */
typedef uint32_t (*mh_admit_fn)(mh_owner*, uint32_t, mh_out*, uint32_t);
/* Optional additive export mh_admit_checked1, ABI1 layout unchanged.
 * Called synchronously inside the existing one-shot native admission, BEFORE
 * ResumeThread. pid/image are queried through the ORIGINAL process handle.
 * image is a read-only UTF-16 view valid ONLY until the callback returns.
 * Copy before retention. Return exactly 1=allow or 0=deny; any other value
 * rejects and consumes admission. NULL callback rejects without consuming.
 * The token is an opaque integer, never a pointer the DLL dereferences.
 * Callback MUST return normally: no unwind/longjmp, Goexit, reentry on the
 * same owner, or retained native pointers. No callback is stored after return.
 * PID/image name is evidence, NOT file digest, signature, token or sandbox proof. */
typedef uint32_t (*mh_check_fn)(uint32_t, const uint16_t*, size_t, uintptr_t);
typedef uint32_t (*mh_admit_checked_fn)(mh_owner*, mh_check_fn, uintptr_t, mh_out*, uint32_t);
/* Additive read-only export mh_borrow_process1, ABI1 layouts unchanged.
 * Callback receives the ORIGINAL retained process HANDLE only until it returns.
 * No process is reopened by PID; no handle is duplicated, transferred or closed.
 * One synchronous callback: exactly 1=success, 0=MH_DENIED, other=MH_ARGUMENT.
 * NULL callback is MH_ARGUMENT without entry. Borrow/denial never consumes
 * admission or resumes execution. Available as process_view, until recorded
 * stop/terminal close; then MH_STATE without callback. Outcome state is UNKNOWN,
 * with diagnostic PID/cached root allowed, never active/settlement facts.
 * The callback is a trusted read-only query: no retain/close/duplicate for
 * retention, mutation, owner reentry, unwind/longjmp or Goexit. It must return
 * normally. The opaque token is never dereferenced by the DLL. Caller holds
 * exclusive owner access and keeps the DLL loaded until this call returns.
 * Cancellation can prevent entry or be observed after callback return; it
 * cannot interrupt a callback or native query that has already entered. */
typedef uint32_t (*mh_process_borrow_fn)(uintptr_t, uintptr_t);
typedef uint32_t (*mh_borrow_process_fn)(mh_owner*, mh_process_borrow_fn, uintptr_t, mh_out*, uint32_t);
typedef uint32_t (*mh_stop_fn)(mh_owner*, uint32_t, mh_out*, uint32_t);
/* Timeout 0..60000ms. Pending retains the same pointer. State and native errors
 * are separate: MH_OK does not turn MH_CLEANUP_FAILED into successful cleanup. */
typedef uint32_t (*mh_finish_fn)(mh_owner*, uint32_t, mh_out*, uint32_t);
/* Optional paired exports mh_wait1 / mh_close1. Wait reports exit facts only;
 * EXITED retains every native resource and does NOT permit mh_release1.
 * Timeout 0..60000ms; same exclusive owner contract, no cancellation callback.
 * On success: PENDING has no known facts or a known root plus positive active
 * count; EXITED has both known flags and active=0. On failure: UNKNOWN, with
 * diagnostic pid/cached root allowed, but no active observation. All inactive
 * fields are zero; only MH_NATIVE has a nonzero native_error. Size/version are
 * initialized on every return with a valid full output. Old mh_out is unchanged. */
typedef struct {
    uint32_t size, version, state, flags, pid, root_exit, active;
    int32_t native_error;
} mh_wait_out;
enum { MH_WAIT_UNKNOWN=0, MH_WAIT_PENDING=1, MH_WAIT_EXITED=2 };
typedef uint32_t (*mh_wait_fn)(mh_owner*, uint32_t, mh_wait_out*, uint32_t);
/* Close rechecks the SAME original root/Job; no prior wait is required.
 * MH_NOT_SETTLED means no close, UNKNOWN state, no active observation.
 * MH_OK supplies only COMPLETE/CLEANUP_FAILED, cached on later close/finish.
 * Native errors retain ownership. Caller must obtain its own product terminal
 * permission BEFORE calling close; this ABI supplies no such permission.
 * A wait after terminal close returns MH_STATE, never fresh EXITED facts. */
typedef uint32_t (*mh_close_fn)(mh_owner*, mh_out*, uint32_t);
/* Release only after terminal finish/close; clears caller slot. NULL slot idempotent.
 * No implied stop/retry/finalizer, no free() of Rust-allocated memory by caller. */
typedef uint32_t (*mh_release_fn)(mh_owner**, mh_out*, uint32_t);
#if UINTPTR_MAX == UINT64_MAX
_Static_assert(sizeof(mh_u16)==16, "UTF16 view layout");
_Static_assert(sizeof(mh_env_entry)==32 && offsetof(mh_env_entry,value)==16, "environment entry layout");
_Static_assert(sizeof(mh_environment)==16 && offsetof(mh_environment,count)==8, "environment view layout");
_Static_assert(sizeof(mh_create)==56 && offsetof(mh_create,args)==40, "create layout");
_Static_assert(sizeof(mh_out)==48 && offsetof(mh_out,cleanup_codes)==36, "outcome layout");
_Static_assert(sizeof(mh_wait_out)==32 && offsetof(mh_wait_out,native_error)==28, "exit observation layout");
#endif
#endif
