//go:build windows && amd64 && cgo && members_faults

package caller

import (
	"errors"
	"os"
	"reflect"
	"syscall"
	"testing"
	"time"
)

// Each explicit mode uses a separately recorded foreign-producer control.
// The same real owner reserves/closes its native generation. Only transport
// reports/views are altered; these are not spontaneous Windows failures.
// Malformed close modes affect the first copy only. close-error-zero projects
// the same synthetic failed receipt on every replay.
func TestMemberForeignFaultKeepsReservationAndFinalization(t *testing.T) {
	mode := os.Getenv("MCPHUB_MEMBERS_FAULT")
	fixture := "exit"
	switch mode {
	case "observe-report", "snapshot-missing", "snapshot-repeated", "token-cleanup-zero",
		"close-report", "close-missing", "close-repeated", "close-generation", "close-omitted":
	case "snapshot-original":
		fixture = "detach"
	case "partial-prefix", "close-error-zero":
		fixture = "tree"
	default:
		t.Fatal("explicit member foreign fault mode required")
	}
	var extra []string
	if fixture == "exit" {
		extra = []string{"7", "fault-original"}
	}
	lib, o, initial, marker, keep := memberFixture(t, fixture, extra...)
	if fixture != "exit" {
		if _, err := o.Admit(true); err != nil {
			t.Fatal(err)
		}
		waitMemberMarker(t, marker)
		waitMemberMarker(t, marker+".grandchild")
	}
	if fixture == "detach" {
		deadline := time.Now().Add(3 * time.Second)
		for {
			wait, err := o.WaitForExit(25)
			if err != nil {
				t.Fatal(err)
			}
			if wait.Flags&1 != 0 {
				if wait.RootExit != 7 || wait.Active != 1 {
					t.Fatalf("owned child-only readiness: %+v", wait)
				}
				break
			}
			if !time.Now().Before(deadline) {
				t.Fatal("owned detached root did not exit within readiness budget")
			}
		}
	}
	generation, snapshot, observeErr := o.ObserveJobMembers(3000)
	keep(generation)
	if generation == 0 {
		t.Fatalf("late foreign failure discarded this call's reserved generation: %v", observeErr)
	}
	switch mode {
	case "observe-report", "snapshot-missing", "snapshot-repeated", "snapshot-original":
		if !errors.Is(observeErr, ErrMemberObservation) || !reflect.DeepEqual(snapshot, MemberSnapshot{}) {
			t.Fatalf("malformed member acquisition/copy accepted: generation=%d %v", generation, observeErr)
		}
	case "partial-prefix":
		var receipt *MemberError
		if !errors.As(observeErr, &receipt) || errors.Is(observeErr, ErrMemberObservation) ||
			snapshot.Generation != generation || snapshot.AcquisitionComplete || snapshot.Pre == nil ||
			snapshot.Post != nil || len(snapshot.Rows) >= len(snapshot.Resources) {
			t.Fatalf("valid partial resource prefix was lost: generation=%d rows=%d resources=%d err=%v",
				generation, len(snapshot.Rows), len(snapshot.Resources), observeErr)
		}
		owned := false
		for _, resource := range snapshot.Resources {
			owned = owned || !resource.BorrowedOriginal
		}
		if !owned {
			t.Fatal("partial control did not retain a real owned descendant resource")
		}
	case "token-cleanup-zero":
		var receipt *MemberError
		if !errors.As(observeErr, &receipt) || receipt.Source != MemberSourceTokenCleanup ||
			receipt.Kind != MemberNoError || receipt.NativeError != 0 || receipt.TokenCloseError != 0 ||
			!errors.Is(observeErr, syscall.Errno(0)) || errors.Is(observeErr, ErrMemberObservation) ||
			snapshot.Generation != generation || snapshot.AcquisitionComplete {
			t.Fatalf("present zero-code cleanup failure disappeared: %v", observeErr)
		}
	default:
		if observeErr != nil || !snapshot.AcquisitionComplete || snapshot.Original.PID != initial.PID {
			t.Fatalf("close control damaged initial acquisition: generation=%d err=%v", generation, observeErr)
		}
	}

	requireStatus(t, o.Release(), notSettled)
	if err := lib.Close(); err == nil {
		t.Fatal("foreign copy failure let the active owner unload")
	}
	if _, err := o.Finish(0); err == nil {
		t.Fatal("observation was automatically closed before explicit finalization")
	}

	switch mode {
	case "close-report", "close-missing", "close-repeated", "close-generation", "close-omitted":
		got, err := o.CloseJobMembers(generation)
		if !errors.Is(err, ErrMemberObservation) || got.Generation != generation ||
			!got.CloseFinalized || got.CleanupComplete || len(got.Resources) != 0 {
			t.Fatalf("late close failure discarded finalization or invented cleanup: %+v %v", got, err)
		}
		// The first native close already drained. This explicit reread obtains
		// the cached native receipt, without repeating a numeric-handle close.
		requireMemberClose(t, o, generation)
	case "close-error-zero":
		got, err := o.CloseJobMembers(generation)
		if err != nil || !got.CloseFinalized || got.CleanupComplete {
			t.Fatalf("synthetic zero-code close failure was lost: %+v %v", got, err)
		}
		failures := 0
		for _, resource := range got.Resources {
			if resource.CloseFailed {
				failures++
				if resource.BorrowedOriginal || !resource.CloseAttempted || resource.Closed || resource.CloseError != 0 {
					t.Fatalf("zero-code close failure fields changed: %+v", resource)
				}
			}
		}
		if failures == 0 {
			t.Fatal("zero-code close failure was inferred absent")
		}
		// The control reports FAILED(0), while the real native snapshot has
		// CLOSED. A validated close receipt must not admit that contradiction.
		afterClose, err := o.JobMemberSnapshot(generation)
		if !errors.Is(err, ErrMemberObservation) || !reflect.DeepEqual(afterClose, MemberSnapshot{}) {
			t.Fatalf("snapshot contradicted validated close failure: generation=%d rows=%d resources=%d err=%v",
				afterClose.Generation, len(afterClose.Rows), len(afterClose.Resources), err)
		}
		again, err := o.CloseJobMembers(generation)
		if err != nil || !reflect.DeepEqual(again, got) {
			t.Fatalf("failed receipt was repaired or changed on replay: %+v %v", again, err)
		}
	default:
		closed := requireMemberClose(t, o, generation)
		if mode == "partial-prefix" && len(closed.Resources) != len(snapshot.Resources) {
			t.Fatal("close dropped a retained partial resource")
		}
	}

	if fixture == "exit" {
		absent(t, marker)
		if _, err := o.Admit(true); err != nil {
			t.Fatalf("explicit member close did not restore original admission: %v", err)
		}
	} else if _, err := o.Stop(83); err != nil {
		t.Fatal(err)
	}
	want := uint32(7)
	if fixture == "tree" {
		want = 83
	}
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != want {
		t.Fatalf("same original owner did not settle after fault: %+v %v", out, err)
	}
}
