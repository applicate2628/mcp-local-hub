//! Retained observations of this owner's original Windows Job.
//! The census and per-handle reads are deliberately non-atomic. A complete
//! observation requires matching before/after facts, never just a PID list.

use super::{creation_time_100ns, NativeOwner, ProcessView, RootWait};
use crate::{NativeFailure, TokenUserError};
use std::{
    error::Error,
    fmt, io,
    mem::{offset_of, size_of, zeroed},
    os::windows::io::{
        AsHandle, AsRawHandle, BorrowedHandle, FromRawHandle, IntoRawHandle, OwnedHandle,
    },
    path::PathBuf,
    time::Instant,
};
use windows_sys::Win32::{
    Foundation::{CloseHandle, ERROR_MORE_DATA},
    System::{
        JobObjects::{
            JobObjectBasicAccountingInformation, JobObjectBasicProcessIdList,
            QueryInformationJobObject, JOBOBJECT_BASIC_ACCOUNTING_INFORMATION,
            JOBOBJECT_BASIC_PROCESS_ID_LIST,
        },
        Threading::{OpenProcess, PROCESS_QUERY_LIMITED_INFORMATION, PROCESS_SYNCHRONIZE},
    },
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JobMemberCensus {
    /// All processes assigned during this Job's lifetime, including exited ones.
    pub total_processes: u32,
    pub active_processes: u32,
    /// Complete, sorted, unique, nonzero process identifiers.
    pub pids: Vec<u32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JobMemberIdentity {
    pub pid: u32,
    /// Windows creation FILETIME, in 100-nanosecond ticks since 1601-01-01 UTC.
    pub creation_time_100ns: u64,
    pub image_path: PathBuf,
    /// Copied binary security identifier from the process token's TokenUser.
    pub token_user_sid: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JobMemberResource {
    pub pid: u32,
    /// The original root is borrowed; this observation never closes its handle.
    pub borrowed_original: bool,
    pub close_attempted: bool,
    pub closed: bool,
    pub close_error: Option<NativeFailure>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JobMemberSnapshot {
    /// Monotonic generation scoped to this NativeOwner.
    pub generation: u64,
    pub pre: Option<JobMemberCensus>,
    pub post: Option<JobMemberCensus>,
    pub rows: Vec<JobMemberIdentity>,
    /// Close fields may be updated by explicit close. Census, identities and
    /// acquisition completeness remain the original observation facts.
    pub resources: Vec<JobMemberResource>,
    pub complete: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JobMemberClose {
    pub generation: u64,
    pub resources: Vec<JobMemberResource>,
    /// All observation-owned process handles closed successfully. A borrowed
    /// original root needs no close; this does not certify acquisition success.
    pub complete: bool,
}

#[derive(Debug)]
pub enum JobMemberQueryError {
    Observation(io::Error),
    TokenUser(TokenUserError),
}

impl fmt::Display for JobMemberQueryError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Observation(error) => write!(f, "Job member observation: {error}"),
            Self::TokenUser(error) => write!(f, "Job member token user: {error}"),
        }
    }
}

impl Error for JobMemberQueryError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Observation(error) => Some(error),
            Self::TokenUser(error) => Some(error),
        }
    }
}

impl From<io::Error> for JobMemberQueryError {
    fn from(error: io::Error) -> Self {
        Self::Observation(error)
    }
}

impl From<TokenUserError> for JobMemberQueryError {
    fn from(error: TokenUserError) -> Self {
        Self::TokenUser(error)
    }
}

enum HeldMember {
    Original,
    Owned(OwnedHandle),
}

pub(super) struct JobMemberObservation {
    snapshot: JobMemberSnapshot,
    held: Vec<HeldMember>,
    close: Option<JobMemberClose>,
}

impl NativeOwner {
    /// Acquire one retained observation under a caller-supplied absolute
    /// deadline. Expiry is checked at native query-helper boundaries and before
    /// success. An already-started helper, including temporary-token cleanup,
    /// finishes normally; no syscall cancellation is claimed. An expired entry
    /// changes no state.
    ///
    /// Any error after reservation leaves an incomplete snapshot and every
    /// acquired resource available for explicit close, even if none was opened.
    pub fn observe_job_members(&mut self, deadline: Instant) -> Result<u64, JobMemberQueryError> {
        let generation = self.begin_job_members(deadline)?;
        let count = self
            .member_observation
            .as_ref()
            .expect("observation reserved above")
            .snapshot
            .pre
            .as_ref()
            .expect("complete pre-census captured above")
            .pids
            .len();
        for _ in 0..count {
            let index = self.retain_next_job_member(deadline)?;
            self.capture_retained_job_member(index, deadline)?;
        }

        let post = query_job_member_census(self.process_view()?.job, deadline)?;
        let observation = self
            .member_observation
            .as_mut()
            .expect("active observation");
        observation.snapshot.post = Some(post);
        if observation.snapshot.pre != observation.snapshot.post {
            return Err(invalid_members("Job membership changed during acquisition").into());
        }
        check_deadline(deadline)?;
        observation.snapshot.complete = true;
        Ok(generation)
    }

    /// The last acquisition facts remain available after explicit member close.
    pub fn job_member_snapshot(&self) -> Option<&JobMemberSnapshot> {
        self.member_observation
            .as_ref()
            .map(|observation| &observation.snapshot)
    }

    /// Recheck the complete baseline through the very same retained handles.
    /// None checks the whole set; Some(pid) additionally requires that member.
    /// This never reopens a PID, replaces the baseline, or extends the deadline.
    pub fn revalidate_job_members(
        &self,
        generation: u64,
        deadline: Instant,
        required_pid: Option<u32>,
    ) -> Result<(), JobMemberQueryError> {
        check_deadline(deadline)?;
        let observation = self.member_observation.as_ref().ok_or_else(|| {
            io::Error::new(io::ErrorKind::InvalidInput, "no Job member observation")
        })?;
        if observation.snapshot.generation != generation
            || observation.close.is_some()
            || !observation.snapshot.complete
        {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "Job member generation is stale, closed or incomplete",
            )
            .into());
        }
        let baseline = observation
            .snapshot
            .pre
            .as_ref()
            .expect("complete acquisition");
        if required_pid.is_some_and(|pid| pid == 0 || !baseline.pids.contains(&pid)) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "required PID is absent from the retained Job member set",
            )
            .into());
        }

        // The original owner remains the provenance anchor even when only
        // descendants are active after a natural root exit.
        check_deadline(deadline)?;
        self.process_view()?.creation_time_100ns()?;
        check_deadline(deadline)?;
        let before = query_job_member_census(self.process_view()?.job, deadline)?;
        if &before != baseline {
            return Err(invalid_members("Job membership differs from acquisition").into());
        }
        for (index, expected) in observation.snapshot.rows.iter().enumerate() {
            let observed = self.read_retained_job_member(index, deadline, Some(expected))?;
            if &observed != expected {
                return Err(invalid_members("retained Job member identity changed").into());
            }
        }
        let after = query_job_member_census(self.process_view()?.job, deadline)?;
        if after != before {
            return Err(invalid_members("Job membership changed during revalidation").into());
        }
        check_deadline(deadline)?;
        Ok(())
    }

    /// Finalize exactly this generation's observation-owned process handles.
    /// Every attempted native close consumes its owner, including failures.
    /// A cached failed receipt is returned as Ok and is never retried. This
    /// drains the active-observation guard independently of receipt.complete.
    /// Close remains available after the observation deadline has expired.
    pub fn close_job_members(&mut self, generation: u64) -> io::Result<&JobMemberClose> {
        let observation = self.member_observation.as_mut().ok_or_else(|| {
            io::Error::new(io::ErrorKind::InvalidInput, "no Job member observation")
        })?;
        if observation.snapshot.generation != generation {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "Job member generation is stale",
            ));
        }
        if observation.close.is_none() {
            // Allocate the receipt before consuming native owners.
            let mut receipt = JobMemberClose {
                generation,
                resources: observation.snapshot.resources.clone(),
                complete: true,
            };
            for ((member, resource), recorded) in observation
                .held
                .drain(..)
                .zip(receipt.resources.iter_mut())
                .zip(observation.snapshot.resources.iter_mut())
            {
                if let HeldMember::Owned(handle) = member {
                    let raw = handle.into_raw_handle();
                    resource.close_attempted = true;
                    // SAFETY: the unique owner was consumed above. There is
                    // no OwnedHandle left that could retry this numeric handle.
                    if unsafe { CloseHandle(raw) } == 0 {
                        let code = io::Error::last_os_error().raw_os_error().unwrap_or(0);
                        resource.close_error = Some(NativeFailure {
                            operation: "CloseJobMemberProcess",
                            code,
                        });
                        receipt.complete = false;
                    } else {
                        resource.closed = true;
                    }
                }
                *recorded = resource.clone();
            }
            observation.close = Some(receipt);
        }
        Ok(observation
            .close
            .as_ref()
            .expect("close receipt installed above"))
    }

    pub(super) fn ensure_no_active_job_members(&self) -> io::Result<()> {
        if self
            .member_observation
            .as_ref()
            .is_some_and(|observation| observation.close.is_none())
        {
            return Err(io::Error::new(
                io::ErrorKind::WouldBlock,
                "close the active Job member observation first",
            ));
        }
        Ok(())
    }

    // Reservation, retention and identity publication are separate resource
    // stages. Once reserved, all failures keep this observation in the owner.
    fn begin_job_members(&mut self, deadline: Instant) -> Result<u64, JobMemberQueryError> {
        self.ensure_no_active_job_members()?;
        check_deadline(deadline)?;
        self.process_view()?;
        let generation = self
            .member_generation
            .checked_add(1)
            .ok_or_else(|| io::Error::other("Job member generation exhausted"))?;
        self.member_observation = Some(JobMemberObservation {
            snapshot: JobMemberSnapshot {
                generation,
                pre: None,
                post: None,
                rows: Vec::new(),
                resources: Vec::new(),
                complete: false,
            },
            held: Vec::new(),
            close: None,
        });
        self.member_generation = generation;

        // Never turn a failed or zero initial root binding into fresh authority.
        check_deadline(deadline)?;
        self.process_view()?.creation_time_100ns()?;
        check_deadline(deadline)?;
        let pre = query_job_member_census(self.process_view()?.job, deadline)?;
        let count = pre.pids.len();
        let observation = self.member_observation.as_mut().expect("reserved above");
        observation.snapshot.pre = Some(pre);
        if count == 0 {
            return Err(
                invalid_members("an empty Job is not a complete live member observation").into(),
            );
        }
        // No allocation may intervene between a successful OpenProcess and
        // installing its owner and public resource record in retained state.
        observation.held.try_reserve_exact(count).map_err(|_| {
            io::Error::new(io::ErrorKind::OutOfMemory, "reserve Job member handles")
        })?;
        observation
            .snapshot
            .resources
            .try_reserve_exact(count)
            .map_err(|_| {
                io::Error::new(
                    io::ErrorKind::OutOfMemory,
                    "reserve Job member resource records",
                )
            })?;
        observation
            .snapshot
            .rows
            .try_reserve_exact(count)
            .map_err(|_| {
                io::Error::new(
                    io::ErrorKind::OutOfMemory,
                    "reserve Job member identity rows",
                )
            })?;
        check_deadline(deadline)?;
        Ok(generation)
    }

    fn retain_next_job_member(&mut self, deadline: Instant) -> Result<usize, JobMemberQueryError> {
        check_deadline(deadline)?;
        let observation = self
            .member_observation
            .as_mut()
            .expect("active acquisition");
        let index = observation.held.len();
        let pid = *observation
            .snapshot
            .pre
            .as_ref()
            .and_then(|pre| pre.pids.get(index))
            .ok_or_else(|| invalid_members("no unacquired member in the pre-census"))?;
        let borrowed_original = pid == self.pid;
        let member = if borrowed_original {
            HeldMember::Original
        } else {
            // SAFETY: PID came from the complete original Job census. The new
            // handle is non-inheritable and carries only query and wait rights.
            // Identity, liveness and exact Job membership are checked below.
            let raw = unsafe {
                OpenProcess(
                    PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_SYNCHRONIZE,
                    0,
                    pid,
                )
            };
            if raw.is_null() {
                return Err(io::Error::last_os_error().into());
            }
            // SAFETY: successful OpenProcess transfers one unique real handle.
            HeldMember::Owned(unsafe { OwnedHandle::from_raw_handle(raw) })
        };
        observation.held.push(member);
        observation.snapshot.resources.push(JobMemberResource {
            pid,
            borrowed_original,
            close_attempted: false,
            closed: false,
            close_error: None,
        });
        Ok(index)
    }

    fn capture_retained_job_member(
        &mut self,
        index: usize,
        deadline: Instant,
    ) -> Result<(), JobMemberQueryError> {
        let row = self.read_retained_job_member(index, deadline, None)?;
        self.member_observation
            .as_mut()
            .expect("active acquisition")
            .snapshot
            .rows
            .push(row);
        Ok(())
    }

    fn read_retained_job_member(
        &self,
        index: usize,
        deadline: Instant,
        baseline: Option<&JobMemberIdentity>,
    ) -> Result<JobMemberIdentity, JobMemberQueryError> {
        check_deadline(deadline)?;
        let observation = self
            .member_observation
            .as_ref()
            .expect("active observation");
        let member = observation
            .held
            .get(index)
            .ok_or_else(|| invalid_members("retained Job member handle is missing"))?;
        let resource = observation
            .snapshot
            .resources
            .get(index)
            .ok_or_else(|| invalid_members("retained Job member resource record is missing"))?;
        let (handle, binding) = match member {
            HeldMember::Original => {
                let view = self.process_view()?;
                (view.handle, self.original_creation)
            }
            HeldMember::Owned(handle) => {
                let binding = match baseline {
                    Some(row) => Ok(row.creation_time_100ns),
                    None => {
                        check_deadline(deadline)?;
                        creation_time_100ns(handle.as_handle())
                    }
                };
                (handle.as_handle(), binding)
            }
        };
        binding.map_err(io::Error::from_raw_os_error)?;
        check_deadline(deadline)?;
        let view = ProcessView {
            handle,
            job: self.process_view()?.job,
            original_creation: &binding,
        };
        read_member_identity(&view, resource.pid, deadline)
    }
}

fn read_member_identity(
    view: &ProcessView<'_>,
    expected_pid: u32,
    deadline: Instant,
) -> Result<JobMemberIdentity, JobMemberQueryError> {
    check_deadline(deadline)?;
    if view.wait_state()? != RootWait::NotSignaled {
        return Err(invalid_members("Job member exited before identity observation").into());
    }
    check_deadline(deadline)?;
    let pid = view.process_id()?;
    if pid == 0 || pid != expected_pid {
        return Err(invalid_members("opened process does not match the Job member PID").into());
    }
    check_deadline(deadline)?;
    let creation_time_100ns = view.creation_time_100ns()?;
    check_deadline(deadline)?;
    let image_path = view.image_path()?;
    if !image_path.is_absolute() {
        return Err(invalid_members("Job member image path is not absolute").into());
    }
    check_deadline(deadline)?;
    let token_user_sid = view.token_user_sid()?;
    check_deadline(deadline)?;
    if !view.is_in_original_job()? {
        return Err(invalid_members("opened process is outside the original Job").into());
    }
    check_deadline(deadline)?;
    if view.wait_state()? != RootWait::NotSignaled {
        return Err(invalid_members("Job member exited during identity observation").into());
    }
    check_deadline(deadline)?;
    Ok(JobMemberIdentity {
        pid,
        creation_time_100ns,
        image_path,
        token_user_sid,
    })
}

fn query_job_member_census(
    job: BorrowedHandle<'_>,
    deadline: Instant,
) -> io::Result<JobMemberCensus> {
    check_deadline(deadline)?;
    // SAFETY: this fixed-size C structure contains only integer fields.
    let mut accounting: JOBOBJECT_BASIC_ACCOUNTING_INFORMATION = unsafe { zeroed() };
    let mut returned = 0;
    // SAFETY: exact information class and writable, correctly aligned buffer;
    // the original Job remains borrowed, never a null/current-process shortcut.
    if unsafe {
        QueryInformationJobObject(
            job.as_raw_handle(),
            JobObjectBasicAccountingInformation,
            (&mut accounting as *mut JOBOBJECT_BASIC_ACCOUNTING_INFORMATION).cast(),
            size_of::<JOBOBJECT_BASIC_ACCOUNTING_INFORMATION>() as u32,
            &mut returned,
        )
    } == 0
    {
        return Err(io::Error::last_os_error());
    }
    if returned as usize != size_of::<JOBOBJECT_BASIC_ACCOUNTING_INFORMATION>() {
        return Err(invalid_members("invalid Job accounting result length"));
    }
    check_deadline(deadline)?;
    let pids = query_job_process_ids(job, deadline)?;
    if accounting.ActiveProcesses as usize != pids.len()
        || accounting.TotalProcesses < accounting.ActiveProcesses
    {
        return Err(invalid_members(
            "Job accounting and complete PID list disagree",
        ));
    }
    check_deadline(deadline)?;
    Ok(JobMemberCensus {
        total_processes: accounting.TotalProcesses,
        active_processes: accounting.ActiveProcesses,
        pids,
    })
}

const PID_LIST_HEADER_BYTES: usize = offset_of!(JOBOBJECT_BASIC_PROCESS_ID_LIST, ProcessIdList);
const PID_LIST_QUERY_ATTEMPTS: usize = 8;

fn query_job_process_ids(job: BorrowedHandle<'_>, deadline: Instant) -> io::Result<Vec<u32>> {
    // Same bounded-growth approach as the existing Go Job query: eight native
    // attempts starting at 32 PID slots. At most 4096 slots are allocated.
    // A larger/changing Job fails explicitly; a partial list is never accepted.
    let mut pid_capacity = 32usize;
    for _ in 0..PID_LIST_QUERY_ATTEMPTS {
        check_deadline(deadline)?;
        let byte_capacity = pid_capacity
            .checked_mul(size_of::<usize>())
            .and_then(|bytes| PID_LIST_HEADER_BYTES.checked_add(bytes))
            .ok_or_else(|| invalid_members("Job PID buffer size overflow"))?;
        let native_capacity = u32::try_from(byte_capacity)
            .map_err(|_| invalid_members("Job PID buffer exceeds native length"))?;
        let word_capacity = byte_capacity.div_ceil(size_of::<usize>());
        let mut storage = Vec::<usize>::new();
        storage.try_reserve_exact(word_capacity).map_err(|_| {
            io::Error::new(io::ErrorKind::OutOfMemory, "reserve Job PID query buffer")
        })?;
        storage.resize(word_capacity, 0);
        check_deadline(deadline)?;
        let mut returned = 0;
        // SAFETY: usize storage supplies ULONG_PTR alignment and at least the
        // declared writable byte count. Job and allocation outlive the call.
        let ok = unsafe {
            QueryInformationJobObject(
                job.as_raw_handle(),
                JobObjectBasicProcessIdList,
                storage.as_mut_ptr().cast(),
                native_capacity,
                &mut returned,
            )
        };
        if ok == 0 {
            let error = io::Error::last_os_error();
            if error.raw_os_error() != Some(ERROR_MORE_DATA as i32) {
                return Err(error);
            }
        } else {
            // SAFETY: initialized storage remains live and contains at least
            // byte_capacity bytes. Parsing checks the actual returned extent.
            let bytes =
                unsafe { std::slice::from_raw_parts(storage.as_ptr().cast::<u8>(), byte_capacity) };
            if let Some(pids) = parse_job_process_ids(bytes, returned as usize)? {
                check_deadline(deadline)?;
                return Ok(pids);
            }
        }
        check_deadline(deadline)?;
        pid_capacity = pid_capacity
            .checked_mul(2)
            .ok_or_else(|| invalid_members("Job PID buffer growth overflow"))?;
    }
    Err(invalid_members(
        "complete Job PID list exceeds bounded query capacity",
    ))
}

// The native C header has two DWORD counts followed by ULONG_PTR entries.
// None means a structurally bounded but incomplete list that needs a larger
// query buffer. Synthetic byte tests qualify only this parser, not native facts.
fn parse_job_process_ids(bytes: &[u8], returned: usize) -> io::Result<Option<Vec<u32>>> {
    if returned < PID_LIST_HEADER_BYTES || returned > bytes.len() {
        return Err(invalid_members("invalid Job PID list return length"));
    }
    let assigned = u32::from_ne_bytes(bytes[..4].try_into().expect("checked DWORD header"));
    let listed = u32::from_ne_bytes(bytes[4..8].try_into().expect("checked DWORD header"));
    let extent = (listed as usize)
        .checked_mul(size_of::<usize>())
        .and_then(|size| PID_LIST_HEADER_BYTES.checked_add(size))
        .ok_or_else(|| invalid_members("Job PID list extent overflow"))?;
    if assigned < listed || extent > returned {
        return Err(invalid_members("malformed Job PID list counts or extent"));
    }
    if assigned > listed {
        return Ok(None);
    }
    let mut pids = Vec::new();
    pids.try_reserve_exact(listed as usize)
        .map_err(|_| io::Error::new(io::ErrorKind::OutOfMemory, "reserve Job PID list"))?;
    for entry in bytes[PID_LIST_HEADER_BYTES..extent]
        .as_chunks::<{ size_of::<usize>() }>()
        .0
    {
        let word = usize::from_ne_bytes(*entry);
        let pid = u32::try_from(word)
            .map_err(|_| invalid_members("Job PID exceeds the Windows process-ID range"))?;
        if pid == 0 {
            return Err(invalid_members("Job PID list contains zero"));
        }
        pids.push(pid);
    }
    pids.sort_unstable();
    if pids.windows(2).any(|pair| pair[0] == pair[1]) {
        return Err(invalid_members("Job PID list contains a duplicate"));
    }
    Ok(Some(pids))
}

fn check_deadline(deadline: Instant) -> io::Result<()> {
    if Instant::now() >= deadline {
        return Err(io::Error::new(
            io::ErrorKind::TimedOut,
            "Job member observation deadline expired",
        ));
    }
    Ok(())
}

fn invalid_members(message: &'static str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}

#[cfg(test)]
#[path = "job_member_tests.rs"]
mod tests;
