//go:build windows && amd64 && cgo

package caller

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"sync"
	"testing"
	"time"
)

// Register member cleanup after own: testing runs cleanups in reverse order.
// Record every nonzero generation before checking its observation error.
func memberFixture(t *testing.T, mode string, extra ...string) (*Library, *Owner, Outcome, string, func(uint64)) {
	t.Helper()
	lib, child, dir := setup(t)
	marker := filepath.Join(dir, "member-proof")
	args := append([]string{mode, marker}, extra...)
	o, initial, err := lib.New(child, dir, args)
	var generation uint64
	if o != nil {
		own(t, o)
		t.Cleanup(func() {
			o.mu.Lock()
			released := o.raw == nil
			o.mu.Unlock()
			if generation == 0 || released {
				return
			}
			receipt, e := o.CloseJobMembers(generation)
			if !receipt.CloseFinalized {
				t.Errorf("member generation %d did not finalize before owner cleanup: %+v %v", generation, receipt, e)
			}
		})
	}
	if err != nil {
		t.Fatal(err)
	}
	return lib, o, initial, marker, func(g uint64) {
		if g != 0 {
			generation = g
		}
	}
}

// Keep binary account SID bytes out of test diagnostics.
func memberSummary(v MemberSnapshot) string {
	return fmt.Sprintf("generation=%d original_pid=%d complete=%v rows=%d resources=%d",
		v.Generation, v.Original.PID, v.AcquisitionComplete, len(v.Rows), len(v.Resources))
}

func waitMemberMarker(t *testing.T, marker string) {
	t.Helper()
	deadline := time.Now().Add(3 * time.Second)
	for {
		_, err := os.Stat(marker)
		if err == nil {
			return
		}
		if !os.IsNotExist(err) || !time.Now().Before(deadline) {
			t.Fatalf("owned member marker did not appear: %v", err)
		}
		time.Sleep(time.Millisecond)
	}
}

func requireMemberClose(t *testing.T, o *Owner, generation uint64) MemberClose {
	t.Helper()
	got, err := o.CloseJobMembers(generation)
	if err != nil || got.Generation != generation || !got.CloseFinalized || !got.CleanupComplete {
		t.Fatalf("member close: %+v %v", got, err)
	}
	again, err := o.CloseJobMembers(generation)
	if err != nil || !reflect.DeepEqual(again, got) {
		t.Fatalf("member close replay changed its receipt: %+v %v", again, err)
	}
	return got
}

func TestMemberRootOnlyCopiesRetainOwnerAndHistoricalBinding(t *testing.T) {
	lib, o, initial, marker, keep := memberFixture(t, "exit", "7", "same-original")
	generation, got, err := o.ObserveJobMembers(3000)
	keep(generation)
	if err != nil || generation == 0 || got.Generation != generation || !got.AcquisitionComplete {
		t.Fatalf("root-only acquisition: generation=%d %+v %v", generation, memberSummary(got), err)
	}
	if got.Original.PID != initial.PID || got.Original.CreationTime100ns == 0 ||
		got.Pre == nil || got.Post == nil || got.Pre.TotalProcesses != 1 || got.Pre.ActiveProcesses != 1 ||
		!reflect.DeepEqual(got.Pre, got.Post) || len(got.Rows) != 1 || len(got.Resources) != 1 ||
		got.Rows[0].PID != initial.PID || got.Rows[0].CreationTime100ns != got.Original.CreationTime100ns ||
		!got.Resources[0].BorrowedOriginal || got.Resources[0].CloseAttempted {
		t.Fatalf("root-only facts: %s", memberSummary(got))
	}
	baseline, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(baseline, got) {
		t.Fatalf("historical copy changed: %s %v", memberSummary(baseline), err)
	}
	got.Pre.PIDs[0] = 0
	got.Post.PIDs[0] = 0
	got.Rows[0].ImagePathUTF16[0] = 0
	got.Rows[0].TokenUserSID[0] = 0
	got.Resources[0].PID = 0
	runtime.GC()
	again, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(again, baseline) {
		t.Fatalf("returned arrays alias each other or native storage: %s %v", memberSummary(again), err)
	}
	if err := o.RevalidateJobMembers(generation, 3000, initial.PID); err != nil {
		t.Fatal(err)
	}
	wait, err := o.WaitForExit(0)
	if err != nil || wait.State != waitPending {
		t.Fatalf("pure root/Job wait was blocked by member observation: %+v %v", wait, err)
	}
	for _, operation := range []struct {
		name string
		call func() (Outcome, error)
	}{
		{"admit", func() (Outcome, error) { return o.Admit(true) }},
		{"stop", func() (Outcome, error) { return o.Stop(99) }},
		{"finish", func() (Outcome, error) { return o.Finish(0) }},
		{"close-exited", o.CloseExited},
	} {
		if _, err := operation.call(); err == nil {
			t.Fatalf("%s consumed an active member observation", operation.name)
		}
	}
	absent(t, marker)
	requireStatus(t, o.Release(), notSettled)
	if err := lib.Close(); err == nil {
		t.Fatal("active member owner allowed DLL unload")
	}
	closed := requireMemberClose(t, o, generation)
	if len(closed.Resources) != 1 || !closed.Resources[0].BorrowedOriginal ||
		closed.Resources[0].CloseAttempted || closed.Resources[0].Closed || closed.Resources[0].CloseFailed {
		t.Fatalf("member close consumed borrowed root: %+v", closed)
	}
	closed.Resources[0].PID = 0
	if fresh, err := o.CloseJobMembers(generation); err != nil || len(fresh.Resources) != 1 || fresh.Resources[0].PID != initial.PID {
		t.Fatalf("caller mutation changed cached member close: %+v %v", fresh, err)
	}
	if err := o.RevalidateJobMembers(generation, 3000, 0); err == nil {
		t.Fatal("finalized generation was revalidated")
	}
	if _, err := o.Admit(true); err != nil {
		t.Fatalf("refused terminal operations damaged original admission: %v", err)
	}
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("same original owner did not settle: %+v %v", out, err)
	}
	// mh_out now knows root exit, but the acquisition row is historical.
	historical, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(historical, baseline) {
		t.Fatalf("cached root exit invalidated historical member facts: %s %v", memberSummary(historical), err)
	}
	if err := o.Release(); err != nil {
		t.Fatal(err)
	}
	if err := lib.Close(); err != nil {
		t.Fatal(err)
	}
	runtime.GC()
	if baseline.Rows[0].PID != initial.PID || baseline.Rows[0].TokenUserSID[0] != 1 {
		t.Fatal("Go member copies did not survive release and unload")
	}
	if data, err := os.ReadFile(marker); err != nil || string(data) != "same-original" {
		t.Fatalf("original child effect mismatch: bytes=%d err=%v", len(data), err)
	}
}

func TestMemberLiveTreeRetainsAndRevalidatesSameDescendant(t *testing.T) {
	_, o, initial, marker, keep := memberFixture(t, "tree")
	if _, err := o.Admit(true); err != nil {
		t.Fatal(err)
	}
	waitMemberMarker(t, marker)
	waitMemberMarker(t, marker+".grandchild")
	generation, got, err := o.ObserveJobMembers(3000)
	keep(generation)
	if err != nil || !got.AcquisitionComplete || got.Pre == nil || got.Pre.TotalProcesses != 2 ||
		got.Pre.ActiveProcesses != 2 || len(got.Rows) != 2 || len(got.Resources) != 2 {
		t.Fatalf("live tree acquisition: %s %v", memberSummary(got), err)
	}
	var descendant uint32
	for _, row := range got.Rows {
		if row.PID != initial.PID {
			descendant = row.PID
		}
	}
	if descendant == 0 {
		t.Fatal("real descendant was not acquired")
	}
	for _, pid := range []uint32{0, initial.PID, descendant} {
		if err := o.RevalidateJobMembers(generation, 3000, pid); err != nil {
			t.Fatalf("same retained set required PID %d: %v", pid, err)
		}
	}
	if err := o.RevalidateJobMembers(generation, 3000, uint32(os.Getpid())); err == nil {
		t.Fatal("foreign PID was accepted as a member of the acquisition")
	}
	// All workers join before cleanup; each native budget is finite.
	var wg sync.WaitGroup
	errs := make(chan error, 6)
	for i := 0; i < 6; i++ {
		wg.Add(1)
		go func(query bool) {
			defer wg.Done()
			if query {
				copy, err := o.JobMemberSnapshot(generation)
				if err == nil && !reflect.DeepEqual(copy, got) {
					err = errors.New("concurrent snapshot changed")
				}
				errs <- err
			} else {
				errs <- o.RevalidateJobMembers(generation, 1000, descendant)
			}
		}(i%2 == 0)
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		if err != nil {
			t.Fatal(err)
		}
	}
	closed := requireMemberClose(t, o, generation)
	for _, resource := range closed.Resources {
		if resource.PID == initial.PID {
			if !resource.BorrowedOriginal || resource.CloseAttempted {
				t.Fatalf("root resource was owned by member close: %+v", resource)
			}
		} else if resource.PID != descendant || resource.BorrowedOriginal ||
			!resource.CloseAttempted || !resource.Closed || resource.CloseFailed {
			t.Fatalf("retained descendant was not explicitly closed: %+v", resource)
		}
	}
	historical, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(historical.Rows, got.Rows) || !reflect.DeepEqual(historical.Pre, got.Pre) ||
		!reflect.DeepEqual(historical.Resources, closed.Resources) || !historical.AcquisitionComplete {
		t.Fatalf("member close replaced acquisition history: %s %v", memberSummary(historical), err)
	}
	if _, err := o.Stop(79); err != nil {
		t.Fatal(err)
	}
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 79 {
		t.Fatalf("original tree settlement after member close: %+v %v", out, err)
	}
}

func TestMemberExitedRootKeepsBirthAndRejectsExitedRetainedLeaf(t *testing.T) {
	_, o, initial, marker, keep := memberFixture(t, "detach")
	root, err := o.QueryIdentity()
	if err != nil {
		t.Fatal(err)
	}
	// The existing finite fixture leaf exits naturally after ten seconds.
	// This absolute readiness budget is not extended by pending native waits.
	deadline := time.Now().Add(13 * time.Second)
	if _, err := o.Admit(true); err != nil {
		t.Fatal(err)
	}
	waitMemberMarker(t, marker+".grandchild")
	var wait ExitObservation
	for {
		wait, err = o.WaitForExit(25)
		if err != nil || wait.Flags&1 != 0 || !time.Now().Before(deadline) {
			break
		}
	}
	if err != nil || wait.State != waitPending || wait.RootExit != 7 || wait.Flags != 3 || wait.Active != 1 {
		t.Fatalf("root/leaf readiness: %+v %v", wait, err)
	}
	generation, got, err := o.ObserveJobMembers(3000)
	keep(generation)
	if err != nil || !got.AcquisitionComplete || got.Original.PID != initial.PID ||
		got.Original.CreationTime100ns != root.CreationTime100ns || got.Pre == nil ||
		got.Pre.TotalProcesses != 2 || got.Pre.ActiveProcesses != 1 || len(got.Rows) != 1 ||
		len(got.Resources) != 1 || got.Rows[0].PID == initial.PID || got.Resources[0].BorrowedOriginal {
		t.Fatalf("exited root was reopened, lost, or inserted into live census: %s %v", memberSummary(got), err)
	}
	descendant := got.Rows[0].PID
	if err := o.RevalidateJobMembers(generation, 3000, descendant); err != nil {
		t.Fatal(err)
	}
	for {
		wait, err = o.WaitForExit(25)
		if err != nil || wait.State == waitExited || !time.Now().Before(deadline) {
			break
		}
		time.Sleep(time.Millisecond)
	}
	if err != nil || wait.State != waitExited || wait.RootExit != 7 || wait.Active != 0 {
		t.Fatalf("retained descendant did not exit naturally in budget: %+v %v", wait, err)
	}
	var native *MemberError
	err = o.RevalidateJobMembers(generation, 3000, descendant)
	if !errors.As(err, &native) || native.Kind == MemberDeadline || errors.Is(err, ErrMemberObservation) {
		t.Fatalf("exited retained descendant was accepted, timed out, or failed only transport validation: %v", err)
	}
	historical, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(historical, got) {
		t.Fatalf("failed revalidation rewrote original acquisition: %s %v", memberSummary(historical), err)
	}
	requireMemberClose(t, o, generation)
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("member lifecycle overwrote original root exit: %+v %v", out, err)
	}
}

func TestMemberEmptyJobRetainsZeroResourcePartialGeneration(t *testing.T) {
	_, o, initial, _, keep := memberFixture(t, "exit", "7", "empty")
	if _, err := o.Admit(true); err != nil {
		t.Fatal(err)
	}
	wait, err := o.WaitForExit(3000)
	if err != nil || wait.State != waitExited {
		t.Fatalf("empty Job readiness: %+v %v", wait, err)
	}
	generation, got, err := o.ObserveJobMembers(3000)
	keep(generation)
	var native *MemberError
	if generation == 0 || !errors.As(err, &native) || got.Generation != generation ||
		got.AcquisitionComplete || got.Original.PID != initial.PID || got.Pre == nil ||
		got.Pre.ActiveProcesses != 0 || len(got.Rows) != 0 || len(got.Resources) != 0 {
		t.Fatalf("empty partial generation was discarded: generation=%d %+v %v", generation, memberSummary(got), err)
	}
	again, err := o.JobMemberSnapshot(generation)
	if err != nil || !reflect.DeepEqual(again, got) {
		t.Fatalf("partial snapshot did not remain readable: %s %v", memberSummary(again), err)
	}
	if _, err := o.Finish(0); err == nil {
		t.Fatal("zero-resource generation bypassed explicit finalization")
	}
	closed := requireMemberClose(t, o, generation)
	if len(closed.Resources) != 0 {
		t.Fatalf("empty close invented an owned resource: %+v", closed)
	}
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("empty observation did not release original settlement: %+v %v", out, err)
	}
}

func TestMemberBudgetsBusyAndStaleCallsDoNotAdoptAnotherGeneration(t *testing.T) {
	_, o, _, marker, keep := memberFixture(t, "block")
	for _, ms := range []uint32{60001, ^uint32(0)} {
		generation, got, err := o.ObserveJobMembers(ms)
		keep(generation)
		requireStatus(t, err, argument)
		if generation != 0 || !reflect.DeepEqual(got, MemberSnapshot{}) {
			t.Fatal("invalid budget reserved or adopted a generation")
		}
	}
	generation, got, err := o.ObserveJobMembers(0)
	keep(generation)
	var native *MemberError
	if generation != 0 || !reflect.DeepEqual(got, MemberSnapshot{}) ||
		!errors.As(err, &native) || native.Kind != MemberDeadline {
		t.Fatalf("entry expiry did not preserve the unreserved state: %d %+v %v", generation, memberSummary(got), err)
	}
	first, baseline, err := o.ObserveJobMembers(3000)
	keep(first)
	if err != nil || first == 0 {
		t.Fatal(err)
	}
	busy, partial, err := o.ObserveJobMembers(3000)
	keep(busy)
	if busy != 0 || !reflect.DeepEqual(partial, MemberSnapshot{}) ||
		!errors.As(err, &native) || native.Kind != MemberBusy {
		t.Fatalf("busy observe adopted the existing generation: %d %+v %v", busy, memberSummary(partial), err)
	}
	if err := o.RevalidateJobMembers(first, 60001, 0); err == nil {
		t.Fatal("oversized revalidation budget was accepted")
	}
	if _, err := o.JobMemberSnapshot(first + 1); err == nil {
		t.Fatal("stale snapshot fell back to latest")
	}
	if err := o.RevalidateJobMembers(first+1, 3000, 0); err == nil {
		t.Fatal("stale revalidation fell back to latest")
	}
	if got, err := o.CloseJobMembers(first + 1); err == nil || got.CloseFinalized {
		t.Fatalf("unknown generation finalized the current one: %+v %v", got, err)
	}
	again, err := o.JobMemberSnapshot(first)
	if err != nil || !reflect.DeepEqual(again, baseline) {
		t.Fatalf("refused operation replaced baseline: %s %v", memberSummary(again), err)
	}
	requireMemberClose(t, o, first)
	second, _, err := o.ObserveJobMembers(3000)
	keep(second)
	if err != nil || second != first+1 {
		t.Fatalf("refused operations consumed a generation: %d -> %d, %v", first, second, err)
	}
	if _, err := o.CloseJobMembers(first); err == nil {
		t.Fatal("old generation was silently replaced by the new one")
	}
	requireMemberClose(t, o, second)
	absent(t, marker)
}
