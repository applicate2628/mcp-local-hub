use super::*;
use crate::{mh_admit1, mh_finish1, mh_stop1, ACTIVE_KNOWN, ROOT_KNOWN, STATE};
use mcphub_process_owner_spike::NativeOwner;
use std::{mem::size_of, ptr, time::Duration};

#[derive(Default)]
struct Probe {
    calls: usize,
    raw: usize,
    decision: u32,
}

// A C callback cannot unwind. Record observations and assert only after return.
unsafe extern "C" fn query(handle: usize, token: usize) -> u32 {
    // SAFETY: each test passes its exclusive Probe for this synchronous call.
    let probe = unsafe { &mut *(token as *mut Probe) };
    probe.calls += 1;
    // Diagnostic comparison only: this integer is never used as a handle
    // after callback return and does not establish another resource owner.
    probe.raw = handle;
    probe.decision
}

fn suspended() -> Box<Owner> {
    let inner =
        NativeOwner::create_suspended(&std::env::current_exe().unwrap(), &["--list".into()])
            .unwrap();
    // This test owns the Box; exports borrow it and mh_release1 is never called.
    Box::new(Owner {
        inner,
        terminal: false,
    })
}

fn borrow(owner: &mut Owner, probe: &mut Probe, out: &mut Outcome) -> u32 {
    // SAFETY: exclusive live owner, callback state and disjoint full output.
    unsafe {
        mh_borrow_process1(
            owner,
            Some(query),
            probe as *mut Probe as usize,
            out,
            size_of::<Outcome>() as u32,
        )
    }
}

#[test]
fn callback_decisions_do_not_consume_admission_or_resume_original_process() {
    for (decision, expected) in [(1, OK), (0, DENIED), (2, ARGUMENT)] {
        let mut owner = suspended();
        let pid = owner.inner.root_pid();
        let original = owner
            .inner
            .with_original_process_handle(|handle| handle.as_raw_handle() as usize)
            .unwrap();
        let mut probe = Probe {
            decision,
            ..Probe::default()
        };
        let mut out = Outcome::default();
        for calls in 1..=2 {
            assert_eq!(borrow(&mut owner, &mut probe, &mut out), expected);
            assert_eq!(probe.calls, calls);
            assert_eq!(
                probe.raw, original,
                "callback must receive the creation handle"
            );
            assert_eq!(owner.inner.wait_root(Duration::ZERO).unwrap(), None);
            assert_eq!(out.size, 48);
            assert_eq!(out.version, 1);
            assert_eq!(out.state, 0);
            assert_eq!(out.pid, pid);
            assert_eq!(out.flags, 0);
            assert_eq!(owner.inner.root_exit(), None);
        }
        // SAFETY: the same original owner/output are exclusive and still live.
        assert_eq!(
            unsafe { mh_admit1(&mut *owner, 1, &mut out, 48) },
            OK,
            "a read callback's decision must not consume actual admission"
        );
        // SAFETY: bounded settlement of only this fixture's original process.
        assert_eq!(unsafe { mh_finish1(&mut *owner, 3000, &mut out, 48) }, OK);
        assert_eq!(out.state, 2);
        assert_eq!(out.root_exit, 0);
    }
}

#[test]
fn invalid_metadata_and_null_receiver_reject_without_callback_or_admission() {
    let mut owner = suspended();
    let mut probe = Probe {
        decision: 1,
        ..Probe::default()
    };
    let token = &mut probe as *mut Probe as usize;
    let mut out = Outcome::default();
    // SAFETY: all valid pointers refer to disjoint live storage. NULL and short
    // lengths are deliberate structural inputs, rejected before owner access.
    unsafe {
        assert_eq!(
            mh_borrow_process1(&mut *owner, None, token, &mut out, 48),
            ARGUMENT
        );
        assert_eq!(
            mh_borrow_process1(ptr::null_mut(), Some(query), token, &mut out, 48),
            ARGUMENT
        );
        assert_eq!(
            mh_borrow_process1(&mut *owner, Some(query), token, &mut out, 47),
            ARGUMENT
        );
        assert_eq!(
            mh_borrow_process1(&mut *owner, Some(query), token, ptr::null_mut(), 48),
            ARGUMENT
        );
    }
    assert_eq!(probe.calls, 0);
    assert_eq!(borrow(&mut owner, &mut probe, &mut out), OK);
    assert_eq!(probe.calls, 1);
    // SAFETY: preflight and query left this retained owner available to admit.
    assert_eq!(unsafe { mh_admit1(&mut *owner, 1, &mut out, 48) }, OK);
    // SAFETY: bounded settlement of the fixture only.
    assert_eq!(unsafe { mh_finish1(&mut *owner, 3000, &mut out, 48) }, OK);
    assert_eq!(out.state, 2);
    assert_eq!(out.root_exit, 0);
}

#[test]
fn stop_and_close_refuse_borrow_without_callback_or_settlement_claims() {
    let mut owner = suspended();
    let mut probe = Probe {
        decision: 1,
        ..Probe::default()
    };
    let mut out = Outcome::default();
    // SAFETY: stop only this fixture's original owned Job.
    assert_eq!(unsafe { mh_stop1(&mut *owner, 83, &mut out, 48) }, OK);
    assert_eq!(borrow(&mut owner, &mut probe, &mut out), STATE);
    assert_eq!(probe.calls, 0);
    assert_eq!(out.state, 0);
    assert_eq!(out.flags & ACTIVE_KNOWN, 0);
    // SAFETY: the fixture's retained owner is live through its terminal close.
    assert_eq!(unsafe { mh_finish1(&mut *owner, 3000, &mut out, 48) }, OK);
    assert_eq!(out.state, 2);
    assert_eq!(borrow(&mut owner, &mut probe, &mut out), STATE);
    assert_eq!(probe.calls, 0);
    assert_eq!(out.state, 0);
    assert_eq!(out.flags, ROOT_KNOWN);
    assert_eq!(out.root_exit, 83);
    assert_eq!(out.cleanup_mask, 0);
}
