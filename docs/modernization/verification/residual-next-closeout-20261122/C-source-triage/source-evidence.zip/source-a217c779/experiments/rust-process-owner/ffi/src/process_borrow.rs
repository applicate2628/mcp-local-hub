//! One call-scoped query of the existing original process handle.
use crate::{call, failure, Outcome, Owner, ARGUMENT, DENIED, OK};
use std::os::windows::io::AsRawHandle;

/// Trusted query callback. The token is opaque to Rust; neither value is owned.
pub type ProcessBorrow = unsafe extern "C" fn(usize, usize) -> u32;

/// Borrow the original retained process without admission or lifecycle changes.
/// # Safety
/// Follow owner_v1.h: live exclusive owner and disjoint full output storage.
/// The callback returns normally and neither retains/closes the handle nor
/// reenters the owner. The DLL remains loaded throughout this synchronous call.
#[no_mangle]
pub unsafe extern "C" fn mh_borrow_process1(
    raw: *mut Owner,
    inspect: Option<ProcessBorrow>,
    token: usize,
    out: *mut Outcome,
    bytes: u32,
) -> u32 {
    // SAFETY: the caller supplies the exclusive original owner/output contract.
    unsafe {
        call(raw, out, bytes, |owner, out| {
            let Some(inspect) = inspect else {
                return ARGUMENT;
            };
            let result = owner.inner.with_original_process_handle(|handle| {
                // SAFETY: callback/token are valid through this call by contract.
                // NativeOwner retains this exact original handle for the visit.
                inspect(handle.as_raw_handle() as usize, token)
            });
            match result {
                Ok(1) => OK,
                Ok(0) => DENIED,
                Ok(_) => ARGUMENT,
                Err(error) => failure(out, error),
            }
        })
    }
}

#[cfg(test)]
#[path = "process_borrow_tests.rs"]
mod tests;
