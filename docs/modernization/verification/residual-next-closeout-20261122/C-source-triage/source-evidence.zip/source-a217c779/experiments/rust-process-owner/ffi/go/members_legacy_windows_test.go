//go:build windows && amd64 && cgo && members_legacy

package caller

import (
	"errors"
	"os"
	"reflect"
	"testing"
)

// The runner records either a legacy DLL or one missing exactly one member
// export. No member method may enter a partly available optional protocol.
func TestMemberOptionalGroupUnsupportedPreservesOriginalOwner(t *testing.T) {
	mode := os.Getenv("MCPHUB_MEMBERS_LEGACY_MODE")
	switch mode {
	case "abi1", "missing-observe", "missing-snapshot", "missing-revalidate", "missing-close":
	default:
		t.Fatal("explicit legacy or missing-member-export mode required")
	}
	_, o, _, marker, keep := memberFixture(t, "exit", "7", "legacy-original")
	generation, snapshot, err := o.ObserveJobMembers(3000)
	keep(generation)
	if !errors.Is(err, ErrMembersUnsupported) || generation != 0 || !reflect.DeepEqual(snapshot, MemberSnapshot{}) {
		t.Fatalf("incomplete group reached acquisition: %d %s %v", generation, memberSummary(snapshot), err)
	}
	if got, err := o.JobMemberSnapshot(1); !errors.Is(err, ErrMembersUnsupported) ||
		!reflect.DeepEqual(got, MemberSnapshot{}) {
		t.Fatalf("incomplete group reached snapshot: %s %v", memberSummary(got), err)
	}
	if err := o.RevalidateJobMembers(1, 3000, 0); !errors.Is(err, ErrMembersUnsupported) {
		t.Fatalf("incomplete group reached revalidation: %v", err)
	}
	if got, err := o.CloseJobMembers(1); !errors.Is(err, ErrMembersUnsupported) ||
		got.CloseFinalized || got.CleanupComplete || len(got.Resources) != 0 {
		t.Fatalf("incomplete group reached member close: %+v %v", got, err)
	}
	absent(t, marker)
	requireStatus(t, o.Release(), notSettled)
	if _, err := o.Admit(true); err != nil {
		t.Fatalf("unsupported member call consumed original admission: %v", err)
	}
	out, err := o.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("legacy original did not settle: %+v %v", out, err)
	}
	data, err := os.ReadFile(marker)
	if err != nil || string(data) != "legacy-original" {
		t.Fatalf("legacy original effect mismatch: bytes=%d err=%v", len(data), err)
	}
}
