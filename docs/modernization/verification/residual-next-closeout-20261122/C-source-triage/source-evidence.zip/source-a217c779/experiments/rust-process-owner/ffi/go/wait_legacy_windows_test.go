//go:build windows && amd64 && cgo && wait_close_legacy

package caller

import (
	"errors"
	"path/filepath"
	"testing"
)

// Run only against an explicitly supplied DLL missing one or both new exports.
func TestSplitMissingExportsPreserveLegacyLifecycle(t *testing.T) {
	lib, child, dir := setup(t)
	marker := filepath.Join(dir, "legacy-split")
	owner, _, err := lib.New(child, dir, []string{"exit", marker, "7", "legacy"})
	if owner != nil {
		own(t, owner)
	}
	if err != nil {
		t.Fatal(err)
	}
	original := owner.raw
	got, err := owner.WaitForExit(0)
	if !errors.Is(err, ErrWaitCloseUnsupported) || got != (ExitObservation{}) {
		t.Fatalf("missing wait/close silently substituted: %+v %v", got, err)
	}
	out, err := owner.CloseExited()
	if !errors.Is(err, ErrWaitCloseUnsupported) || out != (Outcome{}) || owner.raw != original {
		t.Fatalf("missing close changed owner: %+v %v", out, err)
	}
	absent(t, marker)
	if _, err = owner.Admit(true); err != nil {
		t.Fatal(err)
	}
	out, err = owner.Finish(3000)
	if err != nil || out.State != complete || out.RootExit != 7 {
		t.Fatalf("legacy lifecycle regressed: %+v %v", out, err)
	}
	if err = owner.Release(); err != nil {
		t.Fatal(err)
	}
}
