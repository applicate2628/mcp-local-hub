//! Versioned copy views over the same retained native member observation.
use super::{call, Outcome, Owner, ABI, ARGUMENT, OK, STATE, U16};
use mcphub_process_owner_spike::{
    JobMemberCensus, JobMemberClose, JobMemberIdentity, JobMemberQueryError, JobMemberResource,
    JobMemberSnapshot, TokenUserError,
};
use std::{
    io,
    mem::size_of,
    os::windows::ffi::OsStrExt,
    ptr,
    time::{Duration, Instant},
};

const VERSION: u32 = 1;
const MAX_COUNT: usize = 4096;
const MAX_IMAGE_UNITS: usize = 32768;
const SID_CAPACITY: usize = 68;
const SOURCE_NONE: u32 = 0;
const SOURCE_OBSERVATION: u32 = 1;
const SOURCE_TOKEN_USER: u32 = 2;
const SOURCE_COPY: u32 = 3;
const SOURCE_TOKEN_CLEANUP: u32 = 4;
const ERROR_NONE: u32 = 0;
const ERROR_NATIVE: u32 = 1;
const ERROR_INVALID_DATA: u32 = 2;
const ERROR_NO_MEMORY: u32 = 3;
const ERROR_OTHER: u32 = 4;
const ERROR_DEADLINE: u32 = 5;
const ERROR_BUSY: u32 = 6;
const ERROR_INVALID_STATE: u32 = 7;
const PRE_KNOWN: u32 = 1;
const POST_KNOWN: u32 = 2;
const ACQUISITION_COMPLETE: u32 = 4;
const BORROWED_ORIGINAL: u32 = 1;
const CLOSE_ATTEMPTED: u32 = 2;
const CLOSED: u32 = 4;
const CLOSE_FAILED: u32 = 8;
const CLOSE_COMPLETE: u32 = 1;

#[repr(C)]
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct OriginalCreation {
    pid: u32,
    reserved: u32,
    creation_time_100ns: u64,
}
#[repr(C)]
pub struct MemberCensus {
    total_processes: u32,
    active_processes: u32,
    pids: *const u32,
    count: usize,
}
#[repr(C)]
pub struct MemberIdentity {
    size: u32,
    version: u32,
    pid: u32,
    sid_len: u32,
    creation_time_100ns: u64,
    image: U16,
    sid: [u8; SID_CAPACITY],
    reserved: u32,
}
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MemberResource {
    pid: u32,
    flags: u32,
    close_error: i32,
    reserved: u32,
}
#[repr(C)]
pub struct MembersSnapshot {
    size: u32,
    version: u32,
    generation: u64,
    flags: u32,
    reserved: u32,
    original: OriginalCreation,
    pre: MemberCensus,
    post: MemberCensus,
    rows: *const MemberIdentity,
    row_count: usize,
    resources: *const MemberResource,
    resource_count: usize,
}
#[repr(C)]
pub struct MembersClose {
    size: u32,
    version: u32,
    generation: u64,
    flags: u32,
    reserved: u32,
    resources: *const MemberResource,
    resource_count: usize,
}
#[repr(C)]
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct MembersReport {
    size: u32,
    version: u32,
    error_source: u32,
    error_kind: u32,
    native_error: i32,
    token_close_error: i32,
}

pub type SnapshotReceiver = unsafe extern "C" fn(*const MembersSnapshot, u32, usize);
pub type CloseReceiver = unsafe extern "C" fn(*const MembersClose, u32, usize);

unsafe fn report_output<'a>(
    raw: *mut MembersReport,
    bytes: u32,
) -> Result<&'a mut MembersReport, u32> {
    if raw.is_null() || !raw.is_aligned() || bytes as usize != size_of::<MembersReport>() {
        return Err(ARGUMENT);
    }
    // SAFETY: caller provides complete exclusive writable output, disjoint
    // from every other argument; exact size and alignment were checked.
    unsafe {
        raw.write(MembersReport {
            size: size_of::<MembersReport>() as u32,
            version: VERSION,
            error_source: SOURCE_NONE,
            error_kind: ERROR_NONE,
            ..MembersReport::default()
        })
    };
    // SAFETY: the complete report was initialized above.
    Ok(unsafe { &mut *raw })
}

fn record_io(report: &mut MembersReport, source: u32, error: &io::Error) {
    report.error_source = source;
    report.native_error = error.raw_os_error().unwrap_or_default();
    report.token_close_error = 0;
    report.error_kind = if error.raw_os_error().is_some() {
        ERROR_NATIVE
    } else {
        match error.kind() {
            io::ErrorKind::InvalidData => ERROR_INVALID_DATA,
            io::ErrorKind::OutOfMemory => ERROR_NO_MEMORY,
            io::ErrorKind::TimedOut => ERROR_DEADLINE,
            io::ErrorKind::WouldBlock => ERROR_BUSY,
            io::ErrorKind::InvalidInput => ERROR_INVALID_STATE,
            _ => ERROR_OTHER,
        }
    };
}
fn record_query(report: &mut MembersReport, error: JobMemberQueryError) {
    match error {
        JobMemberQueryError::Observation(error) => record_io(report, SOURCE_OBSERVATION, &error),
        JobMemberQueryError::TokenUser(TokenUserError::Observation(error)) => {
            record_io(report, SOURCE_TOKEN_USER, &error);
        }
        JobMemberQueryError::TokenUser(TokenUserError::Cleanup {
            observation,
            failure,
        }) => {
            if let Some(error) = observation {
                record_io(report, SOURCE_TOKEN_CLEANUP, &error);
            } else {
                report.error_source = SOURCE_TOKEN_CLEANUP;
                report.error_kind = ERROR_NONE;
                report.native_error = 0;
            }
            // Variant presence and the numeric close code are independent.
            report.token_close_error = failure.code;
        }
    }
}
fn invalid_data() -> io::Error {
    io::ErrorKind::InvalidData.into()
}
fn invalid_state() -> io::Error {
    io::ErrorKind::InvalidInput.into()
}
fn reserve<T>(values: &mut Vec<T>, count: usize) -> io::Result<()> {
    if count > MAX_COUNT {
        return Err(invalid_data());
    }
    values
        .try_reserve_exact(count)
        .map_err(|_| io::ErrorKind::OutOfMemory.into())
}
fn data_or_null<T>(values: &[T]) -> *const T {
    if values.is_empty() {
        ptr::null()
    } else {
        values.as_ptr()
    }
}
fn deadline(budget_ms: u32) -> Option<Instant> {
    if budget_ms > 60000 {
        return None;
    }
    Instant::now().checked_add(Duration::from_millis(u64::from(budget_ms)))
}

fn census(value: Option<&JobMemberCensus>) -> io::Result<MemberCensus> {
    let Some(value) = value else {
        return Ok(MemberCensus {
            total_processes: 0,
            active_processes: 0,
            pids: ptr::null(),
            count: 0,
        });
    };
    if value.pids.len() > MAX_COUNT
        || usize::try_from(value.active_processes).ok() != Some(value.pids.len())
        || value.active_processes > value.total_processes
        || value.pids.contains(&0)
        || value.pids.windows(2).any(|pair| pair[0] >= pair[1])
    {
        return Err(invalid_data());
    }
    Ok(MemberCensus {
        total_processes: value.total_processes,
        active_processes: value.active_processes,
        pids: data_or_null(&value.pids),
        count: value.pids.len(),
    })
}
fn resource(value: &JobMemberResource) -> io::Result<MemberResource> {
    let failed = value.close_error.is_some();
    if value.pid == 0
        || (value.borrowed_original && (value.close_attempted || value.closed || failed))
        || (!value.close_attempted && (value.closed || failed))
        || (value.close_attempted && value.closed == failed)
    {
        return Err(invalid_data());
    }
    Ok(MemberResource {
        pid: value.pid,
        flags: if value.borrowed_original {
            BORROWED_ORIGINAL
        } else {
            0
        } | if value.close_attempted {
            CLOSE_ATTEMPTED
        } else {
            0
        } | if value.closed { CLOSED } else { 0 }
            | if failed { CLOSE_FAILED } else { 0 },
        close_error: value.close_error.as_ref().map_or(0, |failure| failure.code),
        reserved: 0,
    })
}
fn identity(value: &JobMemberIdentity) -> io::Result<(MemberIdentity, Vec<u16>)> {
    let sid = &value.token_user_sid;
    if value.pid == 0
        || value.creation_time_100ns == 0
        || !value.image_path.is_absolute()
        || !(8..=SID_CAPACITY).contains(&sid.len())
        || sid[0] != 1
        || sid[1] > 15
        || sid.len() != 8 + 4 * usize::from(sid[1])
    {
        return Err(invalid_data());
    }
    let count = value.image_path.as_os_str().encode_wide().count();
    if count == 0 || count > MAX_IMAGE_UNITS {
        return Err(invalid_data());
    }
    let mut image = Vec::new();
    image
        .try_reserve_exact(count)
        .map_err(|_| io::ErrorKind::OutOfMemory)?;
    image.extend(value.image_path.as_os_str().encode_wide());
    if image.contains(&0) {
        return Err(invalid_data());
    }
    let mut row = MemberIdentity {
        size: size_of::<MemberIdentity>() as u32,
        version: VERSION,
        pid: value.pid,
        sid_len: sid.len() as u32,
        creation_time_100ns: value.creation_time_100ns,
        image: U16 {
            data: image.as_ptr(),
            len: image.len(),
        },
        sid: [0; SID_CAPACITY],
        reserved: 0,
    };
    row.sid[..sid.len()].copy_from_slice(sid);
    Ok((row, image))
}

// Native census storage stays borrowed under exclusive Owner access. Only
// the C projection and UTF-16 allocations are owned here, through the callback.
struct SnapshotProjection<'a> {
    _source: &'a JobMemberSnapshot,
    value: MembersSnapshot,
    _rows: Vec<MemberIdentity>,
    _resources: Vec<MemberResource>,
    _images: Vec<Vec<u16>>,
}
impl<'a> SnapshotProjection<'a> {
    fn new(value: &'a JobMemberSnapshot, original: OriginalCreation) -> io::Result<Self> {
        if value.generation == 0
            || original.pid == 0
            || original.reserved != 0
            || original.creation_time_100ns == 0
            || value.rows.len() > value.resources.len()
            || value.resources.len() > MAX_COUNT
            || value.pre.is_none() && (value.post.is_some() || !value.resources.is_empty())
        {
            return Err(invalid_data());
        }
        let pre = census(value.pre.as_ref())?;
        let post = census(value.post.as_ref())?;
        if value.resources.len() > pre.count
            || (value.post.is_some()
                && (value.rows.len() != pre.count || value.resources.len() != pre.count))
            || (value.complete && (pre.count == 0 || value.pre != value.post))
            || (value.resources.iter().any(|item| item.close_attempted)
                && value
                    .resources
                    .iter()
                    .any(|item| !item.borrowed_original && !item.close_attempted))
        {
            return Err(invalid_data());
        }
        let mut rows = Vec::new();
        let mut resources = Vec::new();
        let mut images = Vec::new();
        reserve(&mut rows, value.rows.len())?;
        reserve(&mut resources, value.resources.len())?;
        reserve(&mut images, value.rows.len())?;
        for (index, item) in value.resources.iter().enumerate() {
            if value.pre.as_ref().and_then(|pre| pre.pids.get(index)) != Some(&item.pid)
                || item.borrowed_original != (item.pid == original.pid)
            {
                return Err(invalid_data());
            }
            resources.push(resource(item)?);
        }
        for (index, item) in value.rows.iter().enumerate() {
            if item.pid != value.resources[index].pid
                || (item.pid == original.pid
                    && item.creation_time_100ns != original.creation_time_100ns)
            {
                return Err(invalid_data());
            }
            let (row, image) = identity(item)?;
            rows.push(row);
            images.push(image);
        }
        Ok(Self {
            _source: value,
            value: MembersSnapshot {
                size: size_of::<MembersSnapshot>() as u32,
                version: VERSION,
                generation: value.generation,
                flags: if value.pre.is_some() { PRE_KNOWN } else { 0 }
                    | if value.post.is_some() { POST_KNOWN } else { 0 }
                    | if value.complete {
                        ACQUISITION_COMPLETE
                    } else {
                        0
                    },
                reserved: 0,
                original,
                pre,
                post,
                rows: data_or_null(&rows),
                row_count: rows.len(),
                resources: data_or_null(&resources),
                resource_count: resources.len(),
            },
            _rows: rows,
            _resources: resources,
            _images: images,
        })
    }
}

fn close_projection(
    value: &JobMemberClose,
    generation: u64,
    expected_count: usize,
    original_pid: u32,
    resources: &mut Vec<MemberResource>,
) -> io::Result<MembersClose> {
    if value.generation != generation
        || generation == 0
        || value.resources.len() != expected_count
        || expected_count > MAX_COUNT
        || resources.capacity() < expected_count
    {
        return Err(invalid_data());
    }
    let mut failed = false;
    for item in &value.resources {
        if item.borrowed_original != (item.pid == original_pid)
            || (!item.borrowed_original && !item.close_attempted)
        {
            return Err(invalid_data());
        }
        resources.push(resource(item)?);
        failed |= item.close_error.is_some();
    }
    if value.complete == failed {
        return Err(invalid_data());
    }
    Ok(MembersClose {
        size: size_of::<MembersClose>() as u32,
        version: VERSION,
        generation,
        flags: if value.complete { CLOSE_COMPLETE } else { 0 },
        reserved: 0,
        resources: data_or_null(resources),
        resource_count: resources.len(),
    })
}

unsafe fn zero_scalar<'a, T: Default + PartialEq>(raw: *mut T) -> Result<&'a mut T, u32> {
    if raw.is_null() || !raw.is_aligned() {
        return Err(ARGUMENT);
    }
    // SAFETY: caller supplies initialized exclusive scalar storage, disjoint
    // from the owner and other outputs. Null/alignment were checked above.
    let value = unsafe { &mut *raw };
    if *value != T::default() {
        return Err(ARGUMENT);
    }
    Ok(value)
}

/// Acquire a member generation, publishing new reservation before any report.
/// # Safety
/// Follow include/members_v1.h: live exclusive owner; initialized zero scalar
/// and complete aligned outputs, all mutually disjoint. No pointer aliases or
/// concurrent/reentrant owner calls. The DLL remains loaded through release.
#[no_mangle]
pub unsafe extern "C" fn mh_members_observe1(
    raw: *mut Owner,
    version: u32,
    budget_ms: u32,
    new_generation: *mut u64,
    report: *mut MembersReport,
    report_bytes: u32,
    out: *mut Outcome,
    out_bytes: u32,
) -> u32 {
    // SAFETY: the report's exclusive complete storage is a caller obligation.
    let report = unsafe { report_output(report, report_bytes) };
    // SAFETY: shared validation initializes ABI1 output and checks the owner.
    unsafe {
        call(raw, out, out_bytes, |owner, _out| {
            let report = match report {
                Ok(value) => value,
                Err(status) => return status,
            };
            if version != VERSION {
                return ABI;
            }
            let new_generation = match zero_scalar(new_generation) {
                Ok(value) => value,
                Err(status) => return status,
            };
            let Some(deadline) = deadline(budget_ms) else {
                return ARGUMENT;
            };
            let before = owner
                .inner
                .job_member_snapshot()
                .map(|value| value.generation);
            let result = owner.inner.observe_job_members(deadline);
            // Native reservations survive every acquisition failure. Only a
            // changed generation was acquired by this call; a busy old one is
            // never transferred into the caller's initially empty slot.
            if let Some(after) = owner.inner.job_member_snapshot() {
                if Some(after.generation) != before {
                    *new_generation = after.generation;
                }
            }
            match result {
                Ok(generation) if generation != 0 && generation == *new_generation => OK,
                Ok(_) => {
                    record_io(report, SOURCE_COPY, &invalid_data());
                    STATE
                }
                Err(error) => {
                    record_query(report, error);
                    STATE
                }
            }
        })
    }
}

/// Copy historical acquisition facts for exactly one explicitly named epoch.
/// # Safety
/// Follow include/members_v1.h. The synchronous receiver returns normally,
/// contains its foreign panics, copies before retaining, and cannot mutate,
/// retain native views or reenter the owner. Its token remains live until return.
#[no_mangle]
pub unsafe extern "C" fn mh_members_snapshot1(
    raw: *mut Owner,
    version: u32,
    generation: u64,
    receive: Option<SnapshotReceiver>,
    token: usize,
    report: *mut MembersReport,
    report_bytes: u32,
    out: *mut Outcome,
    out_bytes: u32,
) -> u32 {
    // SAFETY: same disjoint caller-owned report storage as all member exports.
    let report = unsafe { report_output(report, report_bytes) };
    // SAFETY: shared owner/output validation precedes callback projection.
    unsafe {
        call(raw, out, out_bytes, |owner, _out| {
            let report = match report {
                Ok(value) => value,
                Err(status) => return status,
            };
            if version != VERSION {
                return ABI;
            }
            if generation == 0 {
                return ARGUMENT;
            }
            let Some(receive) = receive else {
                return ARGUMENT;
            };
            let Some(snapshot) = owner
                .inner
                .job_member_snapshot()
                .filter(|s| s.generation == generation)
            else {
                record_io(report, SOURCE_OBSERVATION, &invalid_state());
                return STATE;
            };
            let creation_time_100ns = match owner.inner.original_creation_time_100ns() {
                Ok(value) => value,
                Err(error) => {
                    record_io(report, SOURCE_COPY, &error);
                    return STATE;
                }
            };
            let projection = match SnapshotProjection::new(
                snapshot,
                OriginalCreation {
                    pid: owner.inner.root_pid(),
                    reserved: 0,
                    creation_time_100ns,
                },
            ) {
                Ok(value) => value,
                Err(error) => {
                    record_io(report, SOURCE_COPY, &error);
                    return STATE;
                }
            };
            // SAFETY: native census and every projected allocation stay live,
            // immutable and owner-exclusive through this one synchronous call.
            receive(
                &projection.value,
                size_of::<MembersSnapshot>() as u32,
                token,
            );
            OK
        })
    }
}

/// Revalidate through the same native retained members and absolute deadline.
/// # Safety
/// Same live exclusive owner and mutually disjoint complete output contract as
/// mh_members_observe1; no returned pointer or new ownership is produced.
#[no_mangle]
pub unsafe extern "C" fn mh_members_revalidate1(
    raw: *mut Owner,
    version: u32,
    generation: u64,
    budget_ms: u32,
    required_pid: u32,
    report: *mut MembersReport,
    report_bytes: u32,
    out: *mut Outcome,
    out_bytes: u32,
) -> u32 {
    // SAFETY: initialized caller report storage, validated before native entry.
    let report = unsafe { report_output(report, report_bytes) };
    // SAFETY: same owner/output validation as the other member exports.
    unsafe {
        call(raw, out, out_bytes, |owner, _out| {
            let report = match report {
                Ok(value) => value,
                Err(status) => return status,
            };
            if version != VERSION {
                return ABI;
            }
            if generation == 0 {
                return ARGUMENT;
            }
            let Some(deadline) = deadline(budget_ms) else {
                return ARGUMENT;
            };
            match owner.inner.revalidate_job_members(
                generation,
                deadline,
                (required_pid != 0).then_some(required_pid),
            ) {
                Ok(()) => OK,
                Err(error) => {
                    record_query(report, error);
                    STATE
                }
            }
        })
    }
}

/// Finalize one member epoch and deliver its cached receipt independently.
/// # Safety
/// Follow include/members_v1.h: finalized is initialized zero and disjoint from
/// all other outputs. Receiver/token obey the same copy-only callback lifetime
/// as snapshot. Retain finalized even if foreign receipt validation fails.
#[no_mangle]
pub unsafe extern "C" fn mh_members_close1(
    raw: *mut Owner,
    version: u32,
    generation: u64,
    finalized: *mut u32,
    receive: Option<CloseReceiver>,
    token: usize,
    report: *mut MembersReport,
    report_bytes: u32,
    out: *mut Outcome,
    out_bytes: u32,
) -> u32 {
    // SAFETY: disjoint writable full report supplied by the foreign caller.
    let report = unsafe { report_output(report, report_bytes) };
    // SAFETY: shared owner/output validation; all preflight precedes native close.
    unsafe {
        call(raw, out, out_bytes, |owner, _out| {
            let report = match report {
                Ok(value) => value,
                Err(status) => return status,
            };
            if version != VERSION {
                return ABI;
            }
            if generation == 0 {
                return ARGUMENT;
            }
            let finalized = match zero_scalar(finalized) {
                Ok(value) => value,
                Err(status) => return status,
            };
            let Some(receive) = receive else {
                return ARGUMENT;
            };
            let Some(snapshot) = owner
                .inner
                .job_member_snapshot()
                .filter(|s| s.generation == generation)
            else {
                record_io(report, SOURCE_OBSERVATION, &invalid_state());
                return STATE;
            };
            let count = snapshot.resources.len();
            let original_pid = owner.inner.root_pid();
            let mut resources = Vec::new();
            // No fallible foreign-array allocation after native owners are
            // consumed. Projection failure still preserves finalized below.
            if let Err(error) = reserve(&mut resources, count) {
                record_io(report, SOURCE_COPY, &error);
                return STATE;
            }
            let receipt = match owner.inner.close_job_members(generation) {
                Ok(value) => value,
                Err(error) => {
                    record_io(report, SOURCE_OBSERVATION, &error);
                    return STATE;
                }
            };
            *finalized = 1;
            let projection =
                match close_projection(receipt, generation, count, original_pid, &mut resources) {
                    Ok(value) => value,
                    Err(error) => {
                        record_io(report, SOURCE_COPY, &error);
                        return STATE;
                    }
                };
            // SAFETY: the complete C receipt and projected resource array live
            // through this call. Native receipt stays cached in this owner.
            receive(&projection, size_of::<MembersClose>() as u32, token);
            OK
        })
    }
}

#[cfg(test)]
#[path = "members_tests.rs"]
mod tests;
