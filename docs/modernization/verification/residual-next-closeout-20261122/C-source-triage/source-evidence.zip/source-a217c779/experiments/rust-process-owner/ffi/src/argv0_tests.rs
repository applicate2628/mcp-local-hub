use super::*;
use std::{
    fs::{self, File},
    os::windows::io::AsRawHandle,
    sync::atomic::{AtomicU64, Ordering},
};

fn view(units: &[u16]) -> U16 {
    U16 {
        data: units.as_ptr(),
        len: units.len(),
    }
}

#[test]
fn create_io_v2_v3_rejects_invalid_shape_without_owner() {
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let root = PathBuf::from(
        std::env::var_os("MCPHUB_RX02_FIXTURES").expect("owned fixtures root"),
    )
    .join(format!(
        "ffi-argv0-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    fs::create_dir(&root).unwrap();
    let missing = root.join("never-created.exe");
    assert!(!missing.exists());
    let program = missing.as_os_str().encode_wide().collect::<Vec<_>>();
    let cwd = root.as_os_str().encode_wide().collect::<Vec<_>>();
    let stream = File::create(root.join("stdio")).unwrap();
    #[link(name = "kernel32")]
    unsafe extern "system" {
        #[link_name = "SetHandleInformation"]
        fn set_handle_information(handle: RawHandle, mask: u32, flags: u32) -> i32;
    }
    // SAFETY: exclusively owned real file, made inheritable before any call.
    assert_ne!(
        unsafe { set_handle_information(stream.as_raw_handle(), 1, 1) },
        0
    );
    let handle = stream.as_raw_handle() as usize;
    let context = IoContext {
        environment: Environment {
            entries: ptr::null(),
            count: 0,
        },
        streams: StandardStreams {
            stdin: handle,
            stdout: handle,
            stderr: handle,
        },
    };
    for version in [2, 3] {
        for name in [
            "missing-argv0",
            "65-user-arguments",
            "null-views",
            "nul-argv0",
            "individual-budget",
            "aggregate-budget",
            "encoded-budget",
            "reserved",
            "unknown-version",
            "zero-version",
            "max-version",
        ] {
            let mut strings = vec!["git".encode_utf16().collect::<Vec<_>>()];
            match name {
                "missing-argv0" => strings.clear(),
                "65-user-arguments" => strings = vec![vec![b'a' as u16]; 66],
                "nul-argv0" => strings[0].push(0),
                "individual-budget" => strings[0] = vec![b'a' as u16; 32767],
                "aggregate-budget" => {
                    strings[0] = vec![b'a' as u16; MAX_UNITS - program.len() - cwd.len()];
                    strings.push(vec![b'x' as u16]);
                }
                "encoded-budget" => strings.push(vec![b'"' as u16; 16400]),
                _ => {}
            }
            let views = strings.iter().map(|s| view(s)).collect::<Vec<_>>();
            let req = Create {
                version: match name {
                    "unknown-version" => 4,
                    "zero-version" => 0,
                    "max-version" => u32::MAX,
                    _ => version,
                },
                reserved: u32::from(name == "reserved"),
                program: view(&program),
                cwd: view(&cwd),
                args: if name == "null-views" {
                    ptr::null()
                } else {
                    views.as_ptr()
                },
                argc: views.len(),
            };
            let mut owner = ptr::null_mut();
            let mut out = Outcome::default();
            // SAFETY: valid immutable storage and live inheritable file; malformed
            // structural values are the documented rejections under examination.
            let status = unsafe { mh_create_io1(&req, 56, &context, 40, &mut owner, &mut out, 48) };
            let expected = if matches!(
                name,
                "reserved" | "unknown-version" | "zero-version" | "max-version"
            ) {
                ABI
            } else {
                ARGUMENT
            };
            assert_eq!(status, expected, "v{version}:{name}");
            assert!(owner.is_null(), "v{version}:{name}");
            assert_eq!(
                out,
                Outcome {
                    size: 48,
                    version: 1,
                    ..Outcome::default()
                },
                "v{version}:{name}"
            );
        }
    }

    // At the allowed boundary the same valid request reaches CreateProcessW,
    // whose missing-image failure is distinct from a count/argument refusal.
    for version in [1, 2, 3] {
        let strings = vec![vec![b'a' as u16]; if version != 1 { 65 } else { 64 }];
        let views = strings.iter().map(|s| view(s)).collect::<Vec<_>>();
        let req = Create {
            version,
            reserved: 0,
            program: view(&program),
            cwd: view(&cwd),
            args: views.as_ptr(),
            argc: views.len(),
        };
        let mut owner = ptr::null_mut();
        let mut out = Outcome::default();
        // SAFETY: all input/output storage and original source handles live.
        assert_eq!(
            unsafe { mh_create_io1(&req, 56, &context, 40, &mut owner, &mut out, 48) },
            NATIVE,
        );
        assert!(owner.is_null());
        assert_ne!(out.native_error, 0);
        assert_eq!(out.pid, 0);
    }
}

#[test]
fn io_v2_v3_is_rejected_by_legacy_exports() {
    let program = r"D:\owned\not-executed.exe"
        .encode_utf16()
        .collect::<Vec<_>>();
    let cwd = r"D:\owned".encode_utf16().collect::<Vec<_>>();
    let first = "git".encode_utf16().collect::<Vec<_>>();
    let args = [view(&first)];
    for version in [2, 3] {
        let req = Create {
            version,
            reserved: 0,
            program: view(&program),
            cwd: view(&cwd),
            args: args.as_ptr(),
            argc: 1,
        };
        let environment = Environment {
            entries: ptr::null(),
            count: 0,
        };
        let mut owner = ptr::null_mut();
        let mut out = Outcome::default();
        // SAFETY: complete separate views; non-v1 requests are refused before native work.
        assert_eq!(
            unsafe { mh_create1(&req, 56, &mut owner, &mut out, 48) },
            ABI
        );
        assert!(owner.is_null());
        assert_eq!(
            unsafe { mh_create_env1(&req, 56, &environment, 16, &mut owner, &mut out, 48) },
            ABI,
        );
        assert!(owner.is_null());
        assert_eq!(
            out,
            Outcome {
                size: 48,
                version: 1,
                ..Outcome::default()
            }
        );
    }
}
