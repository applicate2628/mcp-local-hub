//! Per-child native arguments, never a mutation of the parent's process state.
use std::{
    ffi::{OsStr, OsString},
    io,
    os::windows::ffi::OsStrExt,
    path::Path,
};
use windows_sys::Win32::Globalization::{CompareStringOrdinal, CSTR_LESS_THAN};

// Experimental input budget, not a claimed Windows environment size limit.
const MAX_ENVIRONMENT_UNITS: usize = 1 << 20;
const MAX_DIRECTORY_UNITS: usize = 32767;

/// Complete explicit environment and absolute working directory for one create.
/// Empty environment means empty, never implicit inheritance or parent merge.
/// Entries must be strictly sorted by Windows case-insensitive ordinal name;
/// duplicates, NULs and '=' in ordinary names are rejected, not normalized.
/// Drive-current-directory names are accepted only as '=[A-Za-z]:'.
/// Values and paths preserve Windows UTF-16 units, including non-Unicode values.
/// No sandbox, directory-identity lock or removal of loader-injected variables
/// is implied. The caller remains responsible for child-specific required keys.
pub struct LaunchContext<'a> {
    pub current_dir: &'a Path,
    pub environment: &'a [(OsString, OsString)],
}

pub(crate) struct PreparedContext {
    pub(crate) directory: Vec<u16>,
    pub(crate) environment: Vec<u16>,
}

impl LaunchContext<'_> {
    pub(crate) fn prepare(&self) -> io::Result<PreparedContext> {
        if !self.current_dir.is_absolute() {
            return Err(invalid("absolute child working directory required"));
        }
        let directory_length =
            bounded_wide_length(self.current_dir.as_os_str(), MAX_DIRECTORY_UNITS - 1)?;
        let mut directory = Vec::new();
        directory
            .try_reserve_exact(directory_length + 1)
            .map_err(|_| io::ErrorKind::OutOfMemory)?;
        directory.extend(self.current_dir.as_os_str().encode_wide());
        directory.push(0);

        // Validate and bound all UTF-16 input before reserving one final block.
        // Count each entry's '=' and NUL plus the block's final NUL; an empty
        // block requires two. No temporary name/value allocations are needed.
        let mut environment_length = 1usize;
        for (name, value) in self.environment {
            environment_length = environment_length
                .checked_add(2)
                .filter(|length| *length <= MAX_ENVIRONMENT_UNITS)
                .ok_or_else(|| {
                    invalid("explicit environment exceeds the experiment's input budget")
                })?;
            environment_length +=
                bounded_wide_length(name, MAX_ENVIRONMENT_UNITS - environment_length)?;
            environment_length +=
                bounded_wide_length(value, MAX_ENVIRONMENT_UNITS - environment_length)?;
        }
        let mut environment = Vec::new();
        environment
            .try_reserve_exact(environment_length.max(2))
            .map_err(|_| io::ErrorKind::OutOfMemory)?;
        let mut previous_name: Option<(usize, usize)> = None;
        for (name, value) in self.environment {
            let start = environment.len();
            environment.extend(name.encode_wide());
            let name = &environment[start..];
            let drive_name = name.len() == 3
                && name[0] == u16::from(b'=')
                && name[2] == u16::from(b':')
                && ((u16::from(b'A')..=u16::from(b'Z')).contains(&name[1])
                    || (u16::from(b'a')..=u16::from(b'z')).contains(&name[1]));
            if name.is_empty() || (name.contains(&(b'=' as u16)) && !drive_name) {
                return Err(invalid(
                    "environment name must be ordinary or a drive-directory name",
                ));
            }
            if let Some((start, length)) = previous_name {
                // SAFETY: nonempty live UTF-16 slices; both bounded well below
                // i32::MAX. Comparison uses the OS ordinal uppercase table,
                // not locale-dependent or Rust Unicode case conversion.
                let order = unsafe {
                    CompareStringOrdinal(
                        environment[start..start + length].as_ptr(),
                        length as i32,
                        name.as_ptr(),
                        name.len() as i32,
                        1,
                    )
                };
                if order == 0 {
                    return Err(io::Error::last_os_error());
                }
                if order != CSTR_LESS_THAN {
                    return Err(invalid(
                        "explicit environment names must be strictly ordinal sorted and unique",
                    ));
                }
            }
            previous_name = Some((start, name.len()));
            environment.push(b'=' as u16);
            environment.extend(value.encode_wide());
            environment.push(0);
        }
        // A non-null pointer to TWO zeros distinguishes explicit empty from
        // CreateProcessW's NULL (inherit) environment argument.
        if environment.is_empty() {
            environment.push(0);
        }
        environment.push(0);
        Ok(PreparedContext {
            directory,
            environment,
        })
    }
}

fn invalid(message: &'static str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidInput, message)
}

fn bounded_wide_length(value: &OsStr, cap: usize) -> io::Result<usize> {
    let mut length = 0;
    for unit in value.encode_wide() {
        if length == cap {
            return Err(invalid(
                "launch-context string exceeds the experiment's input budget",
            ));
        }
        if unit == 0 {
            return Err(invalid("launch-context string contains NUL"));
        }
        length += 1;
    }
    Ok(length)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn context(entries: &[(OsString, OsString)]) -> LaunchContext<'_> {
        LaunchContext {
            current_dir: Path::new(r"D:\owned"),
            environment: entries,
        }
    }

    #[test]
    fn block_has_exact_utf16_entries_and_double_terminator() {
        let entries = vec![("A".into(), "".into()), ("AA".into(), "λ=🦀".into())];
        let prepared = context(&entries).prepare().unwrap();
        assert_eq!(
            prepared.environment,
            OsStr::new("A=\0AA=λ=🦀\0\0")
                .encode_wide()
                .collect::<Vec<_>>()
        );
        assert_eq!(
            prepared.directory,
            OsStr::new("D:\\owned\0").encode_wide().collect::<Vec<_>>()
        );
        assert_eq!(context(&[]).prepare().unwrap().environment, vec![0, 0]);
    }

    #[test]
    fn drive_entries_preserve_exact_block_and_source() {
        let mut entries = vec![
            ("=C:".into(), "C:\\space λ=🦀".into()),
            ("=d:".into(), "d:\\last=part".into()),
            ("A".into(), "value".into()),
        ];
        let before = entries.clone();
        let prepared = context(&entries).prepare().unwrap();
        assert_eq!(entries, before);
        let expected = OsStr::new("=C:=C:\\space λ=🦀\0=d:=d:\\last=part\0A=value\0\0")
            .encode_wide()
            .collect::<Vec<_>>();
        assert_eq!(prepared.environment, expected);
        entries[0].1 = "changed after preparation".into();
        entries.clear();
        assert_eq!(prepared.environment, expected);
    }

    #[test]
    fn full_block_budget_counts_separators_and_terminators() {
        // One key unit + '=' + value + entry NUL + block NUL.
        let exact = vec![(
            "A".into(),
            OsString::from("v".repeat(MAX_ENVIRONMENT_UNITS - 4)),
        )];
        assert_eq!(
            context(&exact).prepare().unwrap().environment.len(),
            MAX_ENVIRONMENT_UNITS
        );
        let over = vec![(
            "A".into(),
            OsString::from("v".repeat(MAX_ENVIRONMENT_UNITS - 3)),
        )];
        assert_eq!(
            context(&over).prepare().err().unwrap().kind(),
            io::ErrorKind::InvalidInput
        );
        // A drive name contributes three units; keep the same total bound.
        for (value_len, valid) in [
            (MAX_ENVIRONMENT_UNITS - 6, true),
            (MAX_ENVIRONMENT_UNITS - 5, false),
        ] {
            let entries = vec![("=D:".into(), OsString::from("v".repeat(value_len)))];
            let result = context(&entries).prepare();
            if valid {
                assert_eq!(result.unwrap().environment.len(), MAX_ENVIRONMENT_UNITS);
            } else {
                assert_eq!(result.err().unwrap().kind(), io::ErrorKind::InvalidInput);
            }
        }
        let combined = vec![
            (
                "A".into(),
                OsString::from("v".repeat(MAX_ENVIRONMENT_UNITS / 2)),
            ),
            (
                "B".into(),
                OsString::from("v".repeat(MAX_ENVIRONMENT_UNITS / 2)),
            ),
        ];
        assert_eq!(
            context(&combined).prepare().err().unwrap().kind(),
            io::ErrorKind::InvalidInput
        );
    }

    #[test]
    fn directory_budget_and_errors_do_not_echo_values() {
        let too_long = std::path::PathBuf::from(format!("D:\\{}", "x".repeat(MAX_DIRECTORY_UNITS)));
        let result = LaunchContext {
            current_dir: &too_long,
            environment: &[],
        }
        .prepare();
        assert_eq!(result.err().unwrap().kind(), io::ErrorKind::InvalidInput);
        let private = "not-a-real-secret\0must-not-appear";
        let entries = vec![("A".into(), private.into())];
        let err = context(&entries).prepare().err().unwrap();
        assert!(!err.to_string().contains("not-a-real-secret"));
    }

    #[test]
    fn block_and_directory_preserve_unpaired_utf16_units() {
        use std::os::windows::ffi::OsStringExt;

        let directory = std::path::PathBuf::from(OsString::from_wide(&[68, 58, 92, 0xd800]));
        let entries = vec![
            ("=D:".into(), OsString::new()),
            (
                OsString::from_wide(&[65, 0xd800]),
                OsString::from_wide(&[0xdc00, 61, 0x03bb, 0xd83e, 0xdd80]),
            ),
        ];
        let prepared = LaunchContext {
            current_dir: &directory,
            environment: &entries,
        }
        .prepare()
        .unwrap();
        assert_eq!(prepared.directory, [68, 58, 92, 0xd800, 0]);
        assert_eq!(
            prepared.environment,
            [61, 68, 58, 61, 0, 65, 0xd800, 61, 0xdc00, 61, 0x03bb, 0xd83e, 0xdd80, 0, 0,]
        );
    }

    #[test]
    fn directory_budget_includes_exactly_one_terminator() {
        for (units, valid) in [
            (MAX_DIRECTORY_UNITS - 1, true),
            (MAX_DIRECTORY_UNITS, false),
        ] {
            let directory = std::path::PathBuf::from(format!("D:\\{}", "x".repeat(units - 3)));
            let result = LaunchContext {
                current_dir: &directory,
                environment: &[],
            }
            .prepare();
            if valid {
                let prepared = result.unwrap();
                assert_eq!(prepared.directory.len(), MAX_DIRECTORY_UNITS);
                assert_eq!(prepared.directory.last(), Some(&0));
            } else {
                assert_eq!(result.err().unwrap().kind(), io::ErrorKind::InvalidInput);
            }
        }
    }
}
