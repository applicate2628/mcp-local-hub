//go:build windows && amd64 && cgo

// Package caller is an isolated foreign-caller experiment, not a Hub backend.
package caller

/*
#cgo CFLAGS: -std=c11 -Wall -Wextra -Werror
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include "../include/identity_v1.h"
#include "../include/members_v1.h"
typedef struct {
    HMODULE module;
    mh_create_fn create;
    mh_create_env_fn create_env;
    mh_create_io_fn create_io;
    mh_admit_fn admit;
    mh_stop_fn stop;
    mh_finish_fn finish;
    mh_wait_fn wait;
    mh_close_fn close_exited;
    mh_release_fn release;
    mh_admit_checked_fn admit_checked;
    mh_admit_identity_fn admit_identity;
    mh_query_identity_fn query_identity;
    mh_members_observe_fn members_observe;
    mh_members_snapshot_fn members_snapshot;
    mh_members_revalidate_fn members_revalidate;
    mh_members_close_fn members_close;
} bridge;
static bridge *bridge_open(const uint16_t *path, uint32_t *error) {
    bridge *b = (bridge*)calloc(1, sizeof(*b));
    if (!b) { *error=ERROR_NOT_ENOUGH_MEMORY; return NULL; }
    b->module=LoadLibraryExW((LPCWSTR)path, NULL,
        LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!b->module) { *error=GetLastError(); free(b); return NULL; }
    // GetProcAddress returns a generic function pointer; copy its representation
    // into a declared function type without hiding a compiler cast warning.
    FARPROC p; mh_version_fn version;
#define RESOLVE(target, symbol) do { p=GetProcAddress(b->module,symbol); \
    if (!p) { *error=GetLastError(); goto fail; } \
    _Static_assert(sizeof(target)==sizeof(p), "function pointer size"); \
    memcpy(&(target), &p, sizeof(target)); } while (0)
    RESOLVE(version,"mh_version1");
    RESOLVE(b->create,"mh_create1"); RESOLVE(b->admit,"mh_admit1");
    RESOLVE(b->stop,"mh_stop1"); RESOLVE(b->finish,"mh_finish1");
    RESOLVE(b->release,"mh_release1");
    RESOLVE(b->admit_checked,"mh_admit_checked1");
    RESOLVE(b->create_env,"mh_create_env1");
    RESOLVE(b->create_io,"mh_create_io1");
#undef RESOLVE
    if (version()!=1) { *error=ERROR_REVISION_MISMATCH; goto fail; }
    // Optional identity protocol: old ABI1 DLLs still load. Its absence is
    // rejected at AdmitIdentity, never downgraded to PID/image admission.
    p=GetProcAddress(b->module,"mh_admit_identity1");
    if (p) {
        _Static_assert(sizeof(b->admit_identity)==sizeof(p), "identity function pointer size");
        memcpy(&b->admit_identity,&p,sizeof(b->admit_identity));
    }
    // Query support is independent of identity admission support.
    p=GetProcAddress(b->module,"mh_query_identity1");
    if (p) {
        _Static_assert(sizeof(b->query_identity)==sizeof(p), "query function pointer size");
        memcpy(&b->query_identity,&p,sizeof(b->query_identity));
    }
    // Treat the split lifecycle extension as a pair; old DLLs still load.
    p=GetProcAddress(b->module,"mh_wait1");
    if (p) {
        _Static_assert(sizeof(b->wait)==sizeof(p), "wait function pointer size");
        memcpy(&b->wait,&p,sizeof(b->wait));
    }
    p=GetProcAddress(b->module,"mh_close1");
    if (p) {
        _Static_assert(sizeof(b->close_exited)==sizeof(p), "close function pointer size");
        memcpy(&b->close_exited,&p,sizeof(b->close_exited));
    }
    // The member protocol is one optional group. A missing export disables
    // every member entry point, without affecting preexisting ABI1 methods.
#define OPTIONAL_MEMBER(target, symbol) do { p=GetProcAddress(b->module,symbol); \
    if (p) { _Static_assert(sizeof(target)==sizeof(p), "member function pointer size"); \
    memcpy(&(target), &p, sizeof(target)); } } while (0)
    OPTIONAL_MEMBER(b->members_observe,"mh_members_observe1");
    OPTIONAL_MEMBER(b->members_snapshot,"mh_members_snapshot1");
    OPTIONAL_MEMBER(b->members_revalidate,"mh_members_revalidate1");
    OPTIONAL_MEMBER(b->members_close,"mh_members_close1");
#undef OPTIONAL_MEMBER
    return b;
fail:
    FreeLibrary(b->module); free(b); return NULL;
}
static uint32_t bridge_close(bridge *b) {
    if (!FreeLibrary(b->module)) return GetLastError();
    free(b); return 0;
}
static uint32_t bridge_create(bridge *b, const mh_create *c, mh_owner **p, mh_out *o) {
    return b->create(c,sizeof(*c),p,o,sizeof(*o));
}
static uint32_t bridge_create_io(bridge *b,const mh_create *c,const mh_env_entry *entries,size_t count,
    uintptr_t in,uintptr_t out,uintptr_t err,mh_owner **p,mh_out *o) {
    mh_io_context context={{entries,count},{in,out,err}};
    return b->create_io(c,sizeof(*c),&context,sizeof(context),p,o,sizeof(*o));
}
static uint32_t bridge_create_env(bridge *b,const mh_create *c,const mh_env_entry *entries,size_t count,mh_owner **p,mh_out *o) {
    mh_environment env={entries,count};
    return b->create_env(c,sizeof(*c),&env,sizeof(env),p,o,sizeof(*o));
}static uint32_t bridge_admit(bridge *b,mh_owner *p,uint32_t a,mh_out *o){return b->admit(p,a,o,sizeof(*o));}
static uint32_t bridge_stop(bridge *b,mh_owner *p,uint32_t a,mh_out *o){return b->stop(p,a,o,sizeof(*o));}
static uint32_t bridge_finish(bridge *b,mh_owner *p,uint32_t a,mh_out *o){return b->finish(p,a,o,sizeof(*o));}
static uint32_t bridge_release(bridge *b,mh_owner **p,mh_out *o){return b->release(p,o,sizeof(*o));}
static int bridge_has_wait_close(bridge *b){return b->wait != NULL && b->close_exited != NULL;}
static uint32_t bridge_wait(bridge *b,mh_owner *p,uint32_t ms,mh_wait_out *o){return b->wait(p,ms,o,sizeof(*o));}
static uint32_t bridge_close_exited(bridge *b,mh_owner *p,mh_out *o){return b->close_exited(p,o,sizeof(*o));}
extern uint32_t mh_go_admission(uint32_t, uint16_t*, size_t, uintptr_t);
static uint32_t bridge_check(uint32_t pid, const uint16_t *image, size_t n, uintptr_t token) {
    // cgo exports mutable pointer types; the Go handler treats this as read-only
    // and immediately copies. No permission to mutate the Rust buffer is granted.
    return mh_go_admission(pid,(uint16_t*)image,n,token);
}
static uint32_t bridge_checked(bridge *b,mh_owner *p,uintptr_t token,mh_out *o) {
    return b->admit_checked(p,bridge_check,token,o,sizeof(*o));
}
extern uint32_t mh_go_identity(mh_identity*, uint32_t, uintptr_t);
static uint32_t bridge_identity_check(const mh_identity *v, uint32_t bytes, uintptr_t token) {
    // cgo's generated declaration is mutable; the handler only reads and copies.
    return mh_go_identity((mh_identity*)v,bytes,token);
}
static int bridge_has_identity(bridge *b) { return b->admit_identity != NULL; }
static uint32_t bridge_identity(bridge *b,mh_owner *p,uintptr_t token,mh_identity_report *r,mh_out *o) {
    return b->admit_identity(p,MH_ID_VERSION,bridge_identity_check,token,r,sizeof(*r),o,sizeof(*o));
}
extern void mh_go_identity_query(mh_identity*, uint32_t, uintptr_t);
static void bridge_identity_receive(const mh_identity *v, uint32_t bytes, uintptr_t token) {
    // This distinct callback only copies; its signature carries no decision.
    mh_go_identity_query((mh_identity*)v,bytes,token);
}
static int bridge_has_identity_query(bridge *b) { return b->query_identity != NULL; }
static uint32_t bridge_identity_query(bridge *b,mh_owner *p,uintptr_t token,mh_identity_report *r,mh_out *o) {
    return b->query_identity(p,MH_ID_VERSION,bridge_identity_receive,token,r,sizeof(*r),o,sizeof(*o));
}
static int bridge_has_members(bridge *b) {
    return b->members_observe != NULL && b->members_snapshot != NULL &&
        b->members_revalidate != NULL && b->members_close != NULL;
}
static uint32_t bridge_members_observe(bridge *b,mh_owner *p,uint32_t ms,
    uint64_t *generation,mh_members_report *r,mh_out *o) {
    return b->members_observe(p,MH_MEMBERS_VERSION,ms,generation,r,sizeof(*r),o,sizeof(*o));
}
extern void mh_go_members_snapshot(mh_members_snapshot*, uint32_t, uintptr_t);
static void bridge_members_receive(const mh_members_snapshot *v,uint32_t bytes,uintptr_t token) {
    // The generated declaration is mutable; the Go receiver only copies.
    mh_go_members_snapshot((mh_members_snapshot*)v,bytes,token);
}
static uint32_t bridge_members_snapshot(bridge *b,mh_owner *p,uint64_t generation,
    uintptr_t token,mh_members_report *r,mh_out *o) {
    return b->members_snapshot(p,MH_MEMBERS_VERSION,generation,bridge_members_receive,token,r,sizeof(*r),o,sizeof(*o));
}
static uint32_t bridge_members_revalidate(bridge *b,mh_owner *p,uint64_t generation,
    uint32_t ms,uint32_t required_pid,mh_members_report *r,mh_out *o) {
    return b->members_revalidate(p,MH_MEMBERS_VERSION,generation,ms,required_pid,r,sizeof(*r),o,sizeof(*o));
}
extern void mh_go_members_close(mh_members_close*, uint32_t, uintptr_t);
static void bridge_members_close_receive(const mh_members_close *v,uint32_t bytes,uintptr_t token) {
    mh_go_members_close((mh_members_close*)v,bytes,token);
}
static uint32_t bridge_members_close(bridge *b,mh_owner *p,uint64_t generation,
    uint32_t *finalized,uintptr_t token,mh_members_report *r,mh_out *o) {
    return b->members_close(p,MH_MEMBERS_VERSION,generation,finalized,
        bridge_members_close_receive,token,r,sizeof(*r),o,sizeof(*o));
}
*/
import "C"

import (
	"errors"
	"fmt"
	"path/filepath"
	"runtime/cgo"
	"sync"
	"syscall"
	"unicode/utf8"
	"unsafe"
)

const (
	ok            = 0
	argument      = 1
	abiMismatch   = 2
	nativeFailure = 3
	denied        = 4
	invalidState  = 5
	notSettled    = 6
	pending       = 1
	complete      = 2
	cleanupFailed = 3
)

type Outcome struct {
	State, Flags, PID, RootExit, Active uint32
	NativeError                         int32
	CleanupMask                         uint32
	CleanupCodes                        [3]int32
}
type CallError struct {
	Status uint32
	Native int32
}

func (e *CallError) Error() string {
	return fmt.Sprintf("owner ABI status=%d native=%d", e.Status, e.Native)
}
func result(status C.uint32_t, o C.mh_out) (Outcome, error) {
	v := Outcome{State: uint32(o.state), Flags: uint32(o.flags), PID: uint32(o.pid), RootExit: uint32(o.root_exit), Active: uint32(o.active), NativeError: int32(o.native_error), CleanupMask: uint32(o.cleanup_mask)}
	for i := range v.CleanupCodes {
		v.CleanupCodes[i] = int32(o.cleanup_codes[i])
	}
	layoutKnown := o.size == C.sizeof_mh_out && o.version == 1
	var callErr error
	if status != 0 {
		var native int32
		if layoutKnown && uint32(status) == nativeFailure {
			native = v.NativeError
		}
		callErr = &CallError{uint32(status), native}
	}
	if !layoutKnown {
		return Outcome{}, errors.Join(callErr, fmt.Errorf("%w: incompatible layout", ErrInvalidOutcome))
	}
	if reason := outcomeViolation(uint32(status), v); reason != "" {
		return Outcome{}, errors.Join(callErr, fmt.Errorf("%w: %s", ErrInvalidOutcome, reason))
	}
	return v, callErr
}

// Mutexes are intentionally owned at the calling boundary. Raw C callers must
// provide equivalent exclusive access themselves. These values must not be copied.
type Library struct {
	mu   sync.Mutex
	raw  *C.bridge
	live int
}
type Owner struct {
	mu  sync.Mutex
	lib *Library
	raw *C.mh_owner
	// Latest native finalization fact survives a malformed copy/report.
	membersFinalized uint64
	membersClose     *MemberClose
	membersObserved  *memberResourceBinding
}

func Open(path string) (*Library, error) {
	if !filepath.IsAbs(path) {
		return nil, errors.New("absolute trusted DLL path required")
	}
	p, free, err := wide(path)
	if err != nil {
		return nil, err
	}
	defer free()
	var code C.uint32_t
	b := C.bridge_open(p.data, &code)
	if b == nil {
		return nil, syscall.Errno(code)
	}
	return &Library{raw: b}, nil
}
func (l *Library) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.live != 0 {
		return errors.New("cannot unload library with live owners")
	}
	if l.raw == nil {
		return nil
	}
	if e := C.bridge_close(l.raw); e != 0 {
		return syscall.Errno(e)
	}
	l.raw = nil
	return nil
}

// wide allocates C-owned input, including a private terminator for DLL loading.
// The Rust API receives a length excluding that terminator and copies it. There
// are no Go pointers in any input; all C allocations die before New returns.
func wide(s string) (C.mh_u16, func(), error) {
	if !utf8.ValidString(s) {
		return C.mh_u16{}, func() {}, &CallError{argument, 0}
	}
	units, err := syscall.UTF16FromString(s)
	if err != nil {
		return C.mh_u16{}, func() {}, &CallError{argument, 0}
	}
	if len(units) > 32767 {
		return C.mh_u16{}, func() {}, &CallError{argument, 0}
	}
	p := C.malloc(C.size_t(len(units) * 2))
	if p == nil {
		return C.mh_u16{}, func() {}, errors.New("input allocation failed")
	}
	copy(unsafe.Slice((*uint16)(p), len(units)), units)
	return C.mh_u16{data: (*C.uint16_t)(p), len: C.size_t(len(units) - 1)}, func() { C.free(p) }, nil
}

// New may return both a non-nil owner and an error after native ownership has
// transferred. Retain and explicitly settle/release every non-nil returned owner.
func (l *Library) New(program, cwd string, args []string) (*Owner, Outcome, error) {
	return l.newVersion(program, cwd, args, 1)
}

// NewWithEnvironment supplies the complete explicit child environment. Like New,
// it may return both an owner and an error after native ownership transfers.
// Retain every non-nil owner, even on error; never retry an unknown outcome.
func (l *Library) NewWithEnvironment(program, cwd string, args []string, environment []EnvironmentEntry) (*Owner, Outcome, error) {
	return l.newRequest(program, cwd, args, 1, environment, true, nil)
}
func (l *Library) newVersion(program, cwd string, args []string, version uint32) (*Owner, Outcome, error) {
	return l.newRequest(program, cwd, args, version, nil, false, nil)
}
func (l *Library) newRequest(program, cwd string, args []string, version uint32, environment []EnvironmentEntry, explicitEnvironment bool, streams *Stdio) (owner *Owner, observed Outcome, err error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.raw == nil {
		return nil, Outcome{}, errors.New("library closed")
	}
	if len(args) > 64 || len(environment) > 256 {
		return nil, Outcome{}, &CallError{argument, 0}
	}
	p, fp, err := wide(program)
	if err != nil {
		return nil, Outcome{}, err
	}
	defer fp()
	d, fd, err := wide(cwd)
	if err != nil {
		return nil, Outcome{}, err
	}
	defer fd()
	var array unsafe.Pointer
	if len(args) > 0 {
		array = C.calloc(C.size_t(len(args)), C.sizeof_mh_u16)
		if array == nil {
			return nil, Outcome{}, errors.New("args allocation failed")
		}
		defer C.free(array)
	}
	views := unsafe.Slice((*C.mh_u16)(array), len(args))
	for i, s := range args {
		v, free, e := wide(s)
		if e != nil {
			return nil, Outcome{}, e
		}
		defer free()
		views[i] = v
	}
	var envArray unsafe.Pointer
	if len(environment) > 0 {
		envArray = C.calloc(C.size_t(len(environment)), C.sizeof_mh_env_entry)
		if envArray == nil {
			return nil, Outcome{}, errors.New("environment allocation failed")
		}
		defer C.free(envArray)
	}
	envViews := unsafe.Slice((*C.mh_env_entry)(envArray), len(environment))
	blockUnits := 1 // final NUL; each entry includes its own '=' and NUL
	for i, entry := range environment {
		name, freeName, e := wide(entry.Name)
		if e != nil {
			return nil, Outcome{}, e
		}
		defer freeName()
		value, freeValue, e := wide(entry.Value)
		if e != nil {
			return nil, Outcome{}, e
		}
		defer freeValue()
		blockUnits += int(name.len) + int(value.len) + 2
		if blockUnits > 32766 {
			return nil, Outcome{}, &CallError{argument, 0}
		}
		envViews[i] = C.mh_env_entry{name: name, value: value}
	}
	request := C.mh_create{version: C.uint32_t(version), program: p, cwd: d, args: (*C.mh_u16)(array), argc: C.size_t(len(args))}
	var ptr *C.mh_owner
	var output C.mh_out
	var status C.uint32_t
	if streams != nil {
		copies, copyErr := duplicateStdio(*streams)
		if copyErr != nil {
			return nil, Outcome{}, copyErr
		}
		// Keep copy-close errors separate from native effects: an already
		// returned owner survives even a late temporary-handle cleanup failure.
		defer func() { err = errors.Join(err, copies.close()) }()
		status = C.bridge_create_io(l.raw, &request, (*C.mh_env_entry)(envArray), C.size_t(len(environment)),
			C.uintptr_t(copies[0]), C.uintptr_t(copies[1]), C.uintptr_t(copies[2]), &ptr, &output)
	} else if explicitEnvironment {
		status = C.bridge_create_env(l.raw, &request, (*C.mh_env_entry)(envArray), C.size_t(len(environment)), &ptr, &output)
	} else {
		status = C.bridge_create(l.raw, &request, &ptr, &output)
	}
	out, e := result(status, output)
	// A transferred owner is an independent fact, even if result metadata is
	// invalid. The caller must retain any non-nil Owner returned with an error.
	if ptr != nil {
		l.live++
		return &Owner{lib: l, raw: ptr}, out, e
	}
	if e == nil {
		e = errors.New("ABI success without an owner")
	}
	return nil, out, e
}
func (o *Owner) Admit(allow bool) (Outcome, error) {
	v := uint32(0)
	if allow {
		v = 1
	}
	return o.call(0, v)
}
func (o *Owner) Stop(code uint32) (Outcome, error)           { return o.call(1, code) }
func (o *Owner) Finish(milliseconds uint32) (Outcome, error) { return o.call(2, milliseconds) }
func (o *Owner) call(operation int, value uint32) (Outcome, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	return o.callLocked(operation, value)
}

// callLocked requires this owner mutex. Both synchronous calls and the
// cancelable observer use the same native operation/result mapping.
func (o *Owner) callLocked(operation int, value uint32) (Outcome, error) {
	if o.raw == nil {
		return Outcome{}, errors.New("owner released")
	}
	var out C.mh_out
	var code C.uint32_t
	switch operation {
	case 0:
		code = C.bridge_admit(o.lib.raw, o.raw, C.uint32_t(value), &out)
	case 1:
		code = C.bridge_stop(o.lib.raw, o.raw, C.uint32_t(value), &out)
	case 2:
		code = C.bridge_finish(o.lib.raw, o.raw, C.uint32_t(value), &out)
	case 3:
		if C.bridge_has_wait_close(o.lib.raw) == 0 {
			return Outcome{}, ErrWaitCloseUnsupported
		}
		code = C.bridge_close_exited(o.lib.raw, o.raw, &out)
	default:
		return Outcome{}, errors.New("invalid local operation")
	}
	observed, err := result(code, out)
	if err == nil && operation == 2 && observed.State == 0 {
		return Outcome{}, fmt.Errorf("%w: successful finish omitted settlement", ErrInvalidOutcome)
	}
	if operation == 3 && ((err == nil && observed.State != complete && observed.State != cleanupFailed) || (err != nil && (observed.State != 0 || observed.Flags&2 != 0))) {
		return Outcome{}, errors.Join(err, fmt.Errorf("%w: close contradicted terminal settlement", ErrInvalidOutcome))
	}
	return observed, err
}

// WaitForExit observes original root/Job exit and retains every native resource.
// The finite budget is 0..60000ms. This synchronous call holds the owner mutex;
// it has no cancellation guarantee and never falls back to combined Finish.
func (o *Owner) WaitForExit(milliseconds uint32) (ExitObservation, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.raw == nil {
		return ExitObservation{}, errors.New("owner released")
	}
	if C.bridge_has_wait_close(o.lib.raw) == 0 {
		return ExitObservation{}, ErrWaitCloseUnsupported
	}
	var out C.mh_wait_out
	status := C.bridge_wait(o.lib.raw, o.raw, C.uint32_t(milliseconds), &out)
	observed := ExitObservation{State: uint32(out.state), Flags: uint32(out.flags), PID: uint32(out.pid), RootExit: uint32(out.root_exit), Active: uint32(out.active), NativeError: int32(out.native_error)}
	return exitResult(uint32(status), uint32(out.size), uint32(out.version), observed)
}

// CloseExited rechecks original root/Job exit and records terminal cleanup.
// It requires both optional exports, never stops the child, and does not release
// the Rust allocation. A product caller obtains terminal permission before entry.
func (o *Owner) CloseExited() (Outcome, error) { return o.call(3, 0) }

// Release never silently stops an active child. Finish or CloseExited must be terminal first.
// No finalizer: GC cannot truthfully report settlement or native cleanup errors.
func (o *Owner) Release() error {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.raw == nil {
		return nil
	}
	var out C.mh_out
	code := C.bridge_release(o.lib.raw, &o.raw, &out)
	_, err := result(code, out)
	// Pointer clearing records completed deallocation, not successful outcome
	// reporting. Keep the library count correct even if metadata validation fails.
	if o.raw == nil {
		o.lib.mu.Lock()
		o.lib.live--
		o.lib.mu.Unlock()
	} else if err == nil {
		err = errors.New("release did not clear owner")
	}
	return err
}

// AdmitChecked evaluates only copied evidence from the original process handle,
// inside the native single-use admission. Policy runs with this owner locked:
// it must return and must not call owner methods (or wait for others to do so).
// No Go pointer or callback is retained in the DLL. Nil policy has no effect.
func (o *Owner) AdmitChecked(check func(ProcessObservation) error) (Outcome, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.raw == nil {
		return Outcome{}, errors.New("owner released")
	}
	if check == nil {
		return Outcome{}, &CallError{argument, 0}
	}
	state := &admissionCall{check: check}
	token := cgo.NewHandle(state)
	defer token.Delete()
	var out C.mh_out
	status := C.bridge_checked(o.lib.raw, o.raw, C.uintptr_t(token), &out)
	observed, err := result(status, out)
	if err == nil && state.calls != 1 {
		err = errors.New("checked admission returned without one policy decision")
	}
	return observed, errors.Join(err, state.err)
}

// AdmitIdentity requires the optional identity protocol. Unsupported libraries,
// a nil policy and a released owner are rejected before native admission.
// Policy runs before resume under the same owner mutex and receives only Go-owned values.
// It must return normally and must not reenter this owner; panics become denial.
func (o *Owner) AdmitIdentity(check func(IdentityObservation) error) (Outcome, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.raw == nil {
		return Outcome{}, errors.New("owner released")
	}
	if check == nil {
		return Outcome{}, &CallError{argument, 0}
	}
	if C.bridge_has_identity(o.lib.raw) == 0 {
		return Outcome{}, ErrIdentityUnsupported
	}
	state := &identityCall{check: check}
	token := cgo.NewHandle(state)
	defer token.Delete()
	var report C.mh_identity_report
	var out C.mh_out
	status := C.bridge_identity(o.lib.raw, o.raw, C.uintptr_t(token), &report, &out)
	observed, err := result(status, out)
	stage, reportErr := identityReportResult(report)
	switch stage {
	case IdentityStageNone:
		if status == 0 || state.calls != 0 {
			reportErr = errors.Join(reportErr, invalidIdentity("missing identity observation"))
		}
	case IdentityStageComplete:
		if state.calls != 1 {
			reportErr = errors.Join(reportErr, invalidIdentity("completed report without one callback"))
		}
	default:
		if uint32(status) != invalidState || state.calls != 0 {
			reportErr = errors.Join(reportErr, invalidIdentity("query failure contradicts admission outcome"))
		}
	}
	return observed, errors.Join(err, reportErr, state.err)
}

// QueryIdentity copies facts from the same retained process and original Job.
// It never consumes admission or changes the owner lifecycle. Queries may be
// repeated until Stop is attempted or Finish closes the resources. Windows
// query/temporary-token-close failures are preserved; no partial value escapes.
// The call is synchronous under the owner mutex and has no cancellation deadline.
// These separate observations are not a product identity/custody capability.
func (o *Owner) QueryIdentity() (IdentityObservation, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.raw == nil {
		return IdentityObservation{}, errors.New("owner released")
	}
	if C.bridge_has_identity_query(o.lib.raw) == 0 {
		return IdentityObservation{}, ErrIdentityQueryUnsupported
	}
	state := &identityQueryCall{}
	token := cgo.NewHandle(state)
	defer token.Delete()
	var report C.mh_identity_report
	var out C.mh_out
	status := C.bridge_identity_query(o.lib.raw, o.raw, C.uintptr_t(token), &report, &out)
	observed, err := result(status, out)
	stage, reportErr := identityReportResult(report)
	switch stage {
	case IdentityStageNone:
		if (uint32(status) != argument && uint32(status) != abiMismatch && uint32(status) != invalidState) || state.calls != 0 {
			reportErr = errors.Join(reportErr, invalidIdentity("query preflight contradicts outcome"))
		}
	case IdentityStageComplete:
		if status != 0 || state.calls != 1 {
			reportErr = errors.Join(reportErr, invalidIdentity("completed query without one successful receiver"))
		}
		if observed.PID != state.value.PID {
			reportErr = errors.Join(reportErr, invalidIdentity("query owner PID contradicts identity"))
		}
		if observed.Flags&1 != 0 && state.value.WaitState != IdentitySignaled {
			reportErr = errors.Join(reportErr, invalidIdentity("query wait contradicts known root exit"))
		}
	default:
		if uint32(status) != invalidState || state.calls != 0 {
			reportErr = errors.Join(reportErr, invalidIdentity("query failure contradicts receiver outcome"))
		}
	}
	if observed.State != 0 || observed.Flags&2 != 0 {
		reportErr = errors.Join(reportErr, invalidIdentity("query reported a settlement observation"))
	}
	if err = errors.Join(err, reportErr, state.err); err != nil {
		return IdentityObservation{}, err
	}
	return state.value, nil
}

// memberReadyLocked requires o.mu. A live owner already pins its Library: Close
// cannot unload the module until Release clears this same owner under o.mu.
func (o *Owner) memberReadyLocked() error {
	if o.raw == nil {
		return errors.New("owner released")
	}
	if C.bridge_has_members(o.lib.raw) == 0 {
		return ErrMembersUnsupported
	}
	return nil
}

func memberCallResult(status C.uint32_t, report C.mh_members_report, raw C.mh_out) (Outcome, error) {
	observed, callErr := result(status, raw)
	reportErr := memberReportResult(status, report)
	var protocolErr error
	if errors.Is(callErr, ErrInvalidOutcome) {
		protocolErr = invalidMember("invalid common outcome")
	}
	if observed.State != 0 || observed.Flags & ^uint32(1) != 0 || observed.Active != 0 ||
		observed.NativeError != 0 || observed.CleanupMask != 0 || observed.CleanupCodes != [3]int32{} ||
		(status == 0 && observed.PID == 0) {
		protocolErr = errors.Join(protocolErr, invalidMember("member call reported terminal or unbound facts"))
	}
	return observed, errors.Join(callErr, reportErr, protocolErr)
}

func memberReceiverResult(status C.uint32_t, calls int) error {
	if (status == 0 && calls != 1) || (status != 0 && calls != 0) {
		return invalidMember("member status contradicts receiver count")
	}
	return nil
}

// ObserveJobMembers reserves an observation on the same original owner. The
// 0..60000ms native budget covers acquisition, not mutex admission or copyout.
// Retain every returned nonzero generation even with an error: a failed partial
// acquisition or failed copy still needs explicit CloseJobMembers. The initial
// snapshot copy shares this owner lock with acquisition and never adopts an
// older generation after a pre-reservation failure.
func (o *Owner) ObserveJobMembers(milliseconds uint32) (uint64, MemberSnapshot, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if err := o.memberReadyLocked(); err != nil {
		return 0, MemberSnapshot{}, err
	}
	if milliseconds > 60000 {
		return 0, MemberSnapshot{}, &CallError{argument, 0}
	}
	var fresh C.uint64_t
	var report C.mh_members_report
	var out C.mh_out
	status := C.bridge_members_observe(o.lib.raw, o.raw, C.uint32_t(milliseconds), &fresh, &report, &out)
	// Reservation is independent of metadata/copy validity. Never replace this
	// call's scalar with the owner's latest historical snapshot.
	generation := uint64(fresh)
	observed, callErr := memberCallResult(status, report, out)
	if generation == 0 {
		if callErr == nil {
			callErr = invalidMember("successful acquisition omitted its fresh generation")
		}
		return 0, MemberSnapshot{}, callErr
	}
	if observed.PID == 0 {
		callErr = errors.Join(callErr, invalidMember("reserved generation omitted original PID"))
	}
	snapshot, copyErr := o.memberSnapshotLocked(generation)
	if copyErr == nil && observed.PID != 0 && observed.PID != snapshot.Original.PID {
		copyErr = invalidMember("acquisition outcome contradicts original PID")
	}
	if callErr == nil && copyErr == nil && !snapshot.AcquisitionComplete {
		copyErr = invalidMember("successful acquisition returned an incomplete snapshot")
	}
	var acquisitionErr *MemberError
	if copyErr == nil && snapshot.AcquisitionComplete && errors.As(callErr, &acquisitionErr) &&
		acquisitionErr.Source != MemberSourceCopy {
		copyErr = invalidMember("failed native acquisition reported a complete snapshot")
	}
	if copyErr != nil || errors.Is(callErr, ErrMemberObservation) {
		return generation, MemberSnapshot{}, errors.Join(callErr, copyErr)
	}
	return generation, snapshot, callErr
}

// JobMemberSnapshot copies one explicitly selected historical generation. It
// performs no fresh image/token/liveness queries. Every returned array is owned
// by Go; later calls, closure and release cannot mutate those copies.
func (o *Owner) JobMemberSnapshot(generation uint64) (MemberSnapshot, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if err := o.memberReadyLocked(); err != nil {
		return MemberSnapshot{}, err
	}
	if generation == 0 {
		return MemberSnapshot{}, &CallError{argument, 0}
	}
	return o.memberSnapshotLocked(generation)
}

func (o *Owner) memberSnapshotLocked(generation uint64) (MemberSnapshot, error) {
	state := &memberSnapshotCall{generation: generation}
	token := cgo.NewHandle(state)
	defer token.Delete()
	var report C.mh_members_report
	var out C.mh_out
	status := C.bridge_members_snapshot(o.lib.raw, o.raw, C.uint64_t(generation), C.uintptr_t(token), &report, &out)
	observed, callErr := memberCallResult(status, report, out)
	err := errors.Join(callErr, memberReceiverResult(status, state.calls), state.err)
	if err == nil && observed.PID != state.value.Original.PID {
		err = invalidMember("snapshot original PID contradicts owner outcome")
	}
	// Current cached root exit does not invalidate a historical acquisition
	// row that described the original root while it was still alive.
	if err == nil {
		err = o.rememberMemberSnapshot(state.value)
	}
	if err != nil {
		return MemberSnapshot{}, err
	}
	return state.value, nil
}

// RevalidateJobMembers checks the original retained baseline. requiredPID=0
// selects the whole set; nonzero additionally requires that acquired PID.
// The finite native budget does not bound waiting to enter the owner mutex.
func (o *Owner) RevalidateJobMembers(generation uint64, milliseconds, requiredPID uint32) error {
	o.mu.Lock()
	defer o.mu.Unlock()
	if err := o.memberReadyLocked(); err != nil {
		return err
	}
	if generation == 0 || milliseconds > 60000 {
		return &CallError{argument, 0}
	}
	var report C.mh_members_report
	var out C.mh_out
	status := C.bridge_members_revalidate(o.lib.raw, o.raw, C.uint64_t(generation),
		C.uint32_t(milliseconds), C.uint32_t(requiredPID), &report, &out)
	_, err := memberCallResult(status, report, out)
	return err
}

// CloseJobMembers finalizes one generation without closing the original owner.
// The native operation attempts owned closes once and caches its receipt.
// A valid failed native close returns nil error and CleanupComplete=false;
// callers must inspect that flag and the per-resource CloseFailed/CloseError.
// Errors here report call or receipt-validation failures separately.
// A malformed copy can leave CloseFinalized=true with CleanupComplete=false;
// repeat this method explicitly to reread native evidence, never to retry a
// numeric handle. No deadline or automatic owner settlement is introduced.
func (o *Owner) CloseJobMembers(generation uint64) (MemberClose, error) {
	o.mu.Lock()
	defer o.mu.Unlock()
	result := MemberClose{Generation: generation,
		CloseFinalized: generation != 0 && o.membersFinalized == generation}
	if o.membersClose != nil && o.membersClose.Generation == generation {
		result = cloneMemberClose(*o.membersClose)
	}
	if err := o.memberReadyLocked(); err != nil {
		return result, err
	}
	if generation == 0 {
		return result, &CallError{argument, 0}
	}
	state := &memberCloseCall{generation: generation}
	token := cgo.NewHandle(state)
	defer token.Delete()
	var finalized C.uint32_t
	var report C.mh_members_report
	var out C.mh_out
	status := C.bridge_members_close(o.lib.raw, o.raw, C.uint64_t(generation), &finalized, C.uintptr_t(token), &report, &out)
	// Preserve the independent native fact before inspecting any other output.
	if finalized == 1 {
		o.membersFinalized = generation
		result.CloseFinalized = true
	}
	observed, callErr := memberCallResult(status, report, out)
	err := errors.Join(callErr, memberReceiverResult(status, state.calls), state.err)
	if finalized > 1 || (status == 0 && finalized != 1) {
		err = errors.Join(err, invalidMember("invalid or missing close finalization"))
	}
	if finalized == 1 && observed.PID == 0 {
		err = errors.Join(err, invalidMember("finalized close omitted original PID"))
	}
	if err == nil {
		for _, resource := range state.value.Resources {
			if resource.BorrowedOriginal != (resource.PID == observed.PID) {
				err = invalidMember("close receipt misidentified the borrowed original")
				break
			}
		}
	}
	if known := o.membersObserved; err == nil && known != nil && known.generation == generation {
		if known.original.PID != observed.PID || !sameMemberResourceSet(known.resources, state.value.Resources) {
			err = invalidMember("close receipt omitted or replaced a retained resource")
		}
	}
	if err != nil {
		return result, err
	}
	candidate := state.value
	candidate.CloseFinalized = true
	if o.membersClose != nil && o.membersClose.Generation == generation && !sameMemberClose(*o.membersClose, candidate) {
		return result, invalidMember("cached close receipt changed")
	}
	cached := cloneMemberClose(candidate)
	o.membersClose = &cached
	return candidate, nil
}
