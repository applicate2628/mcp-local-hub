use super::*;

fn wide_line(value: &str) -> Vec<u16> {
    value.encode_utf16().chain([0]).collect()
}

#[test]
fn command_line_v1_keeps_original_bytes() {
    let args = ["plain", "", r"tail\", r#"a"b"#].map(OsString::from);
    let result = command_line(OsStr::new(r"D:\owned\child.exe"), &args, None).unwrap();
    assert_eq!(
        result,
        wide_line(r#""D:\owned\child.exe" "plain" "" "tail\\" "a\"b""#)
    );
}

#[test]
fn command_line_v2_matches_go_first_argument_rules() {
    for (first, expected) in [
        ("git", "git"),
        ("", "\"\""),
        ("space name\\", "\"space name\\\""),
        ("a \"b\\", "\"a b\\\""),
        ("\"quoted", "\"quoted\""),
        ("a\"b\"", "a\"b\""),
        ("a\\\"b\"", "a\\\"b\""),
        ("\"", "\"\""),
        ("a\u{1}b", "\"a\u{1}b\""),
        ("λ 🦀\\", "\"λ 🦀\\\""),
    ] {
        let result = command_line(
            OsStr::new(r"D:\owned\child.exe"),
            &[],
            Some(OsStr::new(first)),
        )
        .unwrap();
        assert_eq!(result, wide_line(expected), "{first:?}");
    }
}

#[test]
fn command_line_v2_rejects_nul_and_encoded_overflow() {
    let program = OsStr::new(r"D:\owned\child.exe");
    assert_eq!(
        command_line(program, &[], Some(OsStr::new("git\0hidden")))
            .unwrap_err()
            .kind(),
        io::ErrorKind::InvalidInput,
    );
    assert_eq!(
        command_line(
            program,
            &[OsString::from("\"".repeat(16400))],
            Some(OsStr::new("git"))
        )
        .unwrap_err()
        .kind(),
        io::ErrorKind::InvalidInput,
    );
}
