#ifndef MCPHUB_MEMBERS_V1_H
#define MCPHUB_MEMBERS_V1_H
#include "owner_v1.h"

/* Additive Windows x64 member schema. ABI1, mh_out and mh_wait_out are unchanged.
 * The four exports below are one OPTIONAL group: callers require all four,
 * otherwise report unsupported before any member effect. No alternate owner,
 * PID reopen, original-handle close, hash or raw Win32 HANDLE is supplied.
 * owner_v1.h pointer validity, exclusivity and loaded-DLL obligations apply. */
enum { MH_MEMBERS_VERSION=1, MH_MEMBERS_MAX_COUNT=4096,
       MH_MEMBERS_MAX_IMAGE_UNITS=32768, MH_MEMBERS_SID_CAPACITY=68 };
enum { MH_MEMBERS_SOURCE_NONE=0, MH_MEMBERS_SOURCE_OBSERVATION=1,
       MH_MEMBERS_SOURCE_TOKEN_USER=2, MH_MEMBERS_SOURCE_COPY=3,
       MH_MEMBERS_SOURCE_TOKEN_CLEANUP=4 };
enum { MH_MEMBERS_ERROR_NONE=0, MH_MEMBERS_ERROR_NATIVE=1,
       MH_MEMBERS_ERROR_INVALID_DATA=2, MH_MEMBERS_ERROR_NO_MEMORY=3,
       MH_MEMBERS_ERROR_OTHER=4, MH_MEMBERS_ERROR_DEADLINE=5,
       MH_MEMBERS_ERROR_BUSY=6, MH_MEMBERS_ERROR_INVALID_STATE=7 };
enum { MH_MEMBERS_PRE_KNOWN=1, MH_MEMBERS_POST_KNOWN=2,
       MH_MEMBERS_ACQUISITION_COMPLETE=4 };
enum { MH_MEMBER_BORROWED_ORIGINAL=1, MH_MEMBER_CLOSE_ATTEMPTED=2,
       MH_MEMBER_CLOSED=4, MH_MEMBER_CLOSE_FAILED=8 };
enum { MH_MEMBERS_CLOSE_COMPLETE=1 };

typedef struct {
    uint32_t pid, reserved;
    uint64_t creation_time_100ns;
} mh_original_creation;
typedef struct {
    uint32_t total_processes, active_processes;
    const uint32_t *pids;
    size_t count;
} mh_members_census;
typedef struct {
    uint32_t size, version, pid, sid_len;
    uint64_t creation_time_100ns;
    mh_u16 image;
    uint8_t sid[MH_MEMBERS_SID_CAPACITY];
    uint32_t reserved;
} mh_member_identity;
typedef struct {
    uint32_t pid, flags;
    int32_t close_error;
    uint32_t reserved;
} mh_member_resource;
typedef struct {
    uint32_t size, version;
    uint64_t generation;
    uint32_t flags, reserved;
    mh_original_creation original;
    mh_members_census pre, post;
    const mh_member_identity *rows;
    size_t row_count;
    const mh_member_resource *resources;
    size_t resource_count;
} mh_members_snapshot;
typedef struct {
    uint32_t size, version;
    uint64_t generation;
    uint32_t flags, reserved;
    const mh_member_resource *resources;
    size_t resource_count;
} mh_members_close;
typedef struct {
    uint32_t size, version, error_source, error_kind;
    int32_t native_error, token_close_error;
} mh_members_report;

/* Reports are initialized with NONE and zero error codes before owner work.
 * MH_ARGUMENT/MH_ABI indicate preflight refusal. Native operation or copyout
 * failure returns MH_STATE with this report; mh_out.state stays UNKNOWN,
 * mh_out.native_error/cleanup fields stay zero, and its diagnostic PID/cached
 * root exit retain their existing meanings. No member action makes the owner
 * terminal or permits mh_release1.
 *
 * NONE requires kind NONE and both codes zero. OBSERVATION and COPY require
 * a non-NONE kind. TOKEN_USER is TokenUserError::Observation, with non-NONE
 * kind and token_close_error=0. TOKEN_CLEANUP explicitly records the Cleanup
 * variant even when its close code is zero; kind NONE means no nested query
 * error, otherwise kind/native_error preserve that nested error.
 * NATIVE means raw_os_error is PRESENT, including code zero; other kinds
 * require native_error=0. token_close_error=0 outside TOKEN_CLEANUP.
 * COPY includes failure to export the stored original creation binding.
 * No query stage is inferred from a native error. Keep acquisition and later
 * copy reports separately; a successful close never repairs acquisition.
 *
 * All scalar outputs, report, out and owner storage are mutually disjoint.
 * Exact version/byte sizes and non-null receivers are checked before effects.
 * new_generation/finalized point to initialized ZERO scalars on entry. A
 * nonzero input is rejected unchanged, never overwritten or adopted. */

/* budget_ms is 0..60000; one absolute Instant is used inside native acquisition.
 * Checks occur at query-helper boundaries and before final success; an entered
 * helper and its mandatory cleanup finish normally, with no syscall cancel.
 * new_generation is set ONLY for a reservation made by THIS call, including
 * a failed partial acquisition with zero resources. Pre-reservation failure
 * leaves it zero, even when this owner already has another active generation.
 * Retain a nonzero generation before interpreting any other returned data.
 * Every such generation requires explicit close, irrespective of acquisition,
 * deadline or later snapshot-copy failure. No callback runs during acquisition. */
typedef uint32_t (*mh_members_observe_fn)(mh_owner*, uint32_t version,
    uint32_t budget_ms, uint64_t *new_generation,
    mh_members_report*, uint32_t, mh_out*, uint32_t);

/* Callback data are immutable borrowed views valid ONLY until return. Copy
 * every retained array/image. No callback is stored; token is an opaque
 * call-scoped integer never dereferenced by the DLL. The receiver must return
 * normally, contain foreign panics/exceptions, and never reenter this owner,
 * retain a native pointer, unwind/longjmp/Goexit, or wait for owner reentry.
 * Receiver copy/validation failure is caller-side and cannot undo reservation
 * or finalized close. Native success calls the receiver exactly once.
 *
 * snapshot generation must equal the explicitly requested nonzero generation.
 * An absent/stale generation never falls back to the latest snapshot.
 * original is the immutable PID and successful nonzero FILETIME captured from
 * the original process at create, available after root exit and native close.
 * It is historical binding, not fresh liveness, membership or custody proof.
 * Its capture failure remains a failure; no PID reopen/image/token query occurs.
 *
 * Census PIDs are sorted, unique, nonzero, count=active_processes<=total_processes.
 * total_processes counts lifetime assignments, not just active processes.
 * Absent census is all-zero; present empty census is allowed in partial data.
 * All array counts are <=4096; zero count uses NULL, otherwise a valid pointer.
 * Rows are the acquired identity prefix of resources; resources are the held
 * prefix of pre.pids. Acquisition COMPLETE requires equal nonempty pre/post
 * census and full row/resource coverage. A present post requires full pre
 * row/resource coverage even when acquisition is incomplete; its census may
 * differ from pre. A missing post does not imply a complete acquisition.
 * Each row has nonzero PID/FILETIME, absolute image (1..32768 UTF16 units,
 * no NUL, preserve unpaired surrogates), and validated binary SID (8..68 bytes).
 * Unused SID bytes and every reserved field are zero.
 *
 * All resources represent actually held members, including the borrowed root.
 * Borrowed root has only BORROWED_ORIGINAL, never close fields. Before close an
 * owned resource has flags=0. Afterwards CLOSE_ATTEMPTED requires exactly one
 * of CLOSED/CLOSE_FAILED. CLOSE_FAILED indicates NativeFailure presence
 * independently of close_error (zero is allowed); absent failure requires zero.
 * Close finalizes all owned resources; mixed open/attempted owned slots are invalid.
 * Snapshot pre/post/rows/acquisition completeness remain historical after close;
 * only resource close fields update. Snapshot copy never queries native state. */
typedef void (*mh_members_snapshot_receive_fn)(
    const mh_members_snapshot*, uint32_t, uintptr_t);
typedef uint32_t (*mh_members_snapshot_fn)(mh_owner*, uint32_t version,
    uint64_t generation, mh_members_snapshot_receive_fn, uintptr_t,
    mh_members_report*, uint32_t, mh_out*, uint32_t);

/* Revalidate the same retained handles and immutable complete baseline.
 * required_pid=0 checks the whole set; nonzero additionally requires that PID.
 * Uses one absolute deadline from budget_ms (0..60000), never reopens by PID,
 * never refreshes acquisition facts, and refuses closed/stale/partial epochs. */
typedef uint32_t (*mh_members_revalidate_fn)(mh_owner*, uint32_t version,
    uint64_t generation, uint32_t budget_ms, uint32_t required_pid,
    mh_members_report*, uint32_t, mh_out*, uint32_t);

/* Close is not deadline-bound. Reserve foreign receipt-array capacity before
 * native close. finalized becomes 1 immediately after native returns a cached
 * or new close receipt, BEFORE projection or callback, even for failed handle
 * close and later copy failure. It means all member close attempts finalized
 * and the active-observation guard drained; it does NOT mean successful cleanup.
 * The receipt's COMPLETE flag means no owned close failure. Wrong/stale epoch
 * cannot affect another observation; failure before native completion leaves
 * finalized=0. Repeating with a fresh zero scalar reads the SAME cached receipt,
 * never retries a numeric HANDLE. Root-only/zero-resource close also finalizes.
 * Even if foreign receipt validation fails, retain finalized and allow explicit
 * receipt reread; do not invent successful cleanup or replay native attempts. */
typedef void (*mh_members_close_receive_fn)(
    const mh_members_close*, uint32_t, uintptr_t);
typedef uint32_t (*mh_members_close_fn)(mh_owner*, uint32_t version,
    uint64_t generation, uint32_t *finalized,
    mh_members_close_receive_fn, uintptr_t,
    mh_members_report*, uint32_t, mh_out*, uint32_t);

/* Export names: mh_members_observe1, mh_members_snapshot1,
 * mh_members_revalidate1, mh_members_close1. */
#if UINTPTR_MAX == UINT64_MAX
_Static_assert(sizeof(mh_original_creation)==16 &&
    offsetof(mh_original_creation,creation_time_100ns)==8, "original creation layout");
_Static_assert(sizeof(mh_members_census)==24 &&
    offsetof(mh_members_census,pids)==8 && offsetof(mh_members_census,count)==16,
    "member census layout");
_Static_assert(sizeof(mh_member_identity)==112 &&
    offsetof(mh_member_identity,creation_time_100ns)==16 &&
    offsetof(mh_member_identity,image)==24 && offsetof(mh_member_identity,sid)==40 &&
    offsetof(mh_member_identity,reserved)==108, "member identity layout");
_Static_assert(sizeof(mh_member_resource)==16 &&
    offsetof(mh_member_resource,close_error)==8, "member resource layout");
_Static_assert(sizeof(mh_members_snapshot)==120 &&
    offsetof(mh_members_snapshot,original)==24 && offsetof(mh_members_snapshot,pre)==40 &&
    offsetof(mh_members_snapshot,post)==64 && offsetof(mh_members_snapshot,rows)==88 &&
    offsetof(mh_members_snapshot,resources)==104, "member snapshot layout");
_Static_assert(sizeof(mh_members_close)==40 &&
    offsetof(mh_members_close,resources)==24, "member close layout");
_Static_assert(sizeof(mh_members_report)==24 &&
    offsetof(mh_members_report,native_error)==16 &&
    offsetof(mh_members_report,token_close_error)==20, "member report layout");
#endif
#endif
