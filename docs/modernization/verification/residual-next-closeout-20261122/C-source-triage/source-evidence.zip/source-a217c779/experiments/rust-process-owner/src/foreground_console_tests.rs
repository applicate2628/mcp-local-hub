use super::*;

#[test]
fn foreground_console_policy_preserves_background_and_refuses_unknown_attachment() {
    assert_eq!(
        creation_console_flags(false, || panic!("background queried parent console")).unwrap(),
        CREATE_NO_WINDOW
    );
    for (attached, want) in [(false, CREATE_NO_WINDOW), (true, 0)] {
        let mut calls = 0;
        let flags = creation_console_flags(true, || {
            calls += 1;
            Ok(attached)
        })
        .unwrap();
        assert_eq!(calls, 1);
        assert_eq!(flags, want);
    }
    let mut calls = 0;
    let error = creation_console_flags(true, || {
        calls += 1;
        Err(io::Error::from_raw_os_error(5))
    })
    .unwrap_err();
    assert_eq!(calls, 1);
    assert_eq!(error.raw_os_error(), Some(5));
}

#[test]
fn console_attachment_observation_distinguishes_absence_from_failure() {
    assert!(console_attachment_observation(1, 0).unwrap());
    // A count larger than the one-element buffer is still attached. A stale
    // last error must not turn a successful count into a false absence.
    assert!(console_attachment_observation(17, 5).unwrap());
    assert!(!console_attachment_observation(0, ERROR_INVALID_HANDLE).unwrap());
    assert_eq!(
        console_attachment_observation(0, 5)
            .unwrap_err()
            .raw_os_error(),
        Some(5)
    );
    assert!(console_attachment_observation(0, 0).is_err());
}
