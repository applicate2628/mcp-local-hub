//go:build windows && amd64 && cgo

package caller

import (
	"errors"
	"fmt"
)

const (
	waitPending = 1
	waitExited  = 2
)

// ErrWaitCloseUnsupported refuses the split protocol unless both exports exist.
var ErrWaitCloseUnsupported = errors.New("native wait/close extension unavailable")

// ExitObservation contains exit facts, never cleanup or release permission.
// State is 0=unknown, 1=pending, 2=exited. Flags bit0 validates RootExit; bit1
// validates Active. PID is diagnostic only. Exited retains the original owner.
type ExitObservation struct {
	State, Flags, PID, RootExit, Active uint32
	NativeError                         int32
}

func exitResult(status, size, version uint32, v ExitObservation) (ExitObservation, error) {
	layoutKnown := size == 32 && version == 1
	var callErr error
	if status != ok {
		var native int32
		if layoutKnown && status == nativeFailure {
			native = v.NativeError
		}
		callErr = &CallError{status, native}
	}
	var reason string
	switch {
	case !layoutKnown:
		reason = "incompatible layout"
	case status > notSettled:
		reason = "unknown call status"
	case v.State > waitExited:
		reason = "unknown exit state"
	case v.Flags & ^uint32(3) != 0:
		reason = "unknown observation flags"
	case status == ok && v.State == 0:
		reason = "success omitted exit observation"
	case status != ok && v.State != 0:
		reason = "failure supplied successful exit state"
	case status == nativeFailure && v.NativeError == 0:
		reason = "native failure without its code"
	case status != nativeFailure && v.NativeError != 0:
		reason = "native code without native failure"
	case v.Flags&1 == 0 && v.RootExit != 0:
		reason = "root code without a known root result"
	case v.Flags&2 == 0 && v.Active != 0:
		reason = "active count without a known observation"
	case (v.State != 0 || v.Flags != 0) && v.PID == 0:
		reason = "exit facts without a process identity"
	case v.State == 0 && v.Flags&2 != 0:
		reason = "failure supplied an active observation"
	case v.State == waitPending && v.Flags != 0 && (v.Flags != 3 || v.Active == 0):
		reason = "pending requires unknown facts or a known root with live members"
	case v.State == waitExited && (v.Flags != 3 || v.Active != 0):
		reason = "exited requires a known root and zero active members"
	}
	if reason != "" {
		return ExitObservation{}, errors.Join(callErr, fmt.Errorf("%w: exit observation: %s", ErrInvalidOutcome, reason))
	}
	return v, callErr
}
