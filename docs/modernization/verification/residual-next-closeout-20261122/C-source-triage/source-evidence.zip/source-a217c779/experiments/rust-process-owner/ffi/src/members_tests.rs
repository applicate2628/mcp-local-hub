use super::*;
use mcphub_process_owner_spike::{ExitObservation, NativeFailure, NativeOwner, Settlement};
use std::{
    mem::{align_of, offset_of},
    path::PathBuf,
    slice,
};

const REPORT_BYTES: u32 = size_of::<MembersReport>() as u32;
const OUT_BYTES: u32 = size_of::<Outcome>() as u32;

#[test]
fn layouts_and_offsets_leave_existing_abi_unchanged() {
    assert_eq!(
        (size_of::<Outcome>(), size_of::<crate::WaitOutcome>()),
        (48, 32)
    );
    assert_eq!(
        (
            size_of::<OriginalCreation>(),
            align_of::<OriginalCreation>()
        ),
        (16, 8)
    );
    assert_eq!(offset_of!(OriginalCreation, creation_time_100ns), 8);
    assert_eq!(size_of::<MemberCensus>(), 24);
    assert_eq!(
        (
            offset_of!(MemberCensus, pids),
            offset_of!(MemberCensus, count)
        ),
        (8, 16)
    );
    assert_eq!(size_of::<MemberIdentity>(), 112);
    assert_eq!(
        (
            offset_of!(MemberIdentity, creation_time_100ns),
            offset_of!(MemberIdentity, image),
            offset_of!(MemberIdentity, sid),
            offset_of!(MemberIdentity, reserved)
        ),
        (16, 24, 40, 108)
    );
    assert_eq!(size_of::<MemberResource>(), 16);
    assert_eq!(offset_of!(MemberResource, close_error), 8);
    assert_eq!(size_of::<MembersSnapshot>(), 120);
    assert_eq!(
        (
            offset_of!(MembersSnapshot, original),
            offset_of!(MembersSnapshot, pre),
            offset_of!(MembersSnapshot, post),
            offset_of!(MembersSnapshot, rows),
            offset_of!(MembersSnapshot, resources)
        ),
        (24, 40, 64, 88, 104)
    );
    assert_eq!(size_of::<MembersClose>(), 40);
    assert_eq!(offset_of!(MembersClose, resources), 24);
    assert_eq!(size_of::<MembersReport>(), 24);
    assert_eq!(
        (
            offset_of!(MembersReport, native_error),
            offset_of!(MembersReport, token_close_error)
        ),
        (16, 20)
    );
}

#[test]
fn reports_preserve_nested_token_errors_and_zero_native_codes() {
    let cases = [
        (
            JobMemberQueryError::Observation(io::ErrorKind::TimedOut.into()),
            SOURCE_OBSERVATION,
            ERROR_DEADLINE,
            0,
            0,
        ),
        (
            JobMemberQueryError::Observation(io::ErrorKind::WouldBlock.into()),
            SOURCE_OBSERVATION,
            ERROR_BUSY,
            0,
            0,
        ),
        (
            JobMemberQueryError::Observation(io::Error::from_raw_os_error(0)),
            SOURCE_OBSERVATION,
            ERROR_NATIVE,
            0,
            0,
        ),
        (
            JobMemberQueryError::TokenUser(TokenUserError::Observation(
                io::Error::from_raw_os_error(5),
            )),
            SOURCE_TOKEN_USER,
            ERROR_NATIVE,
            5,
            0,
        ),
        (
            JobMemberQueryError::TokenUser(TokenUserError::Cleanup {
                observation: None,
                failure: NativeFailure {
                    operation: "CloseToken",
                    code: 0,
                },
            }),
            SOURCE_TOKEN_CLEANUP,
            ERROR_NONE,
            0,
            0,
        ),
        (
            JobMemberQueryError::TokenUser(TokenUserError::Cleanup {
                observation: Some(io::Error::from_raw_os_error(5)),
                failure: NativeFailure {
                    operation: "CloseToken",
                    code: 0,
                },
            }),
            SOURCE_TOKEN_CLEANUP,
            ERROR_NATIVE,
            5,
            0,
        ),
        (
            JobMemberQueryError::TokenUser(TokenUserError::Cleanup {
                observation: Some(io::Error::from_raw_os_error(0)),
                failure: NativeFailure {
                    operation: "CloseToken",
                    code: 0,
                },
            }),
            SOURCE_TOKEN_CLEANUP,
            ERROR_NATIVE,
            0,
            0,
        ),
        (
            JobMemberQueryError::TokenUser(TokenUserError::Cleanup {
                observation: Some(io::ErrorKind::InvalidData.into()),
                failure: NativeFailure {
                    operation: "CloseToken",
                    code: 6,
                },
            }),
            SOURCE_TOKEN_CLEANUP,
            ERROR_INVALID_DATA,
            0,
            6,
        ),
    ];
    for (error, source, kind, native, close) in cases {
        let mut report = MembersReport::default();
        record_query(&mut report, error);
        assert_eq!(
            (
                report.error_source,
                report.error_kind,
                report.native_error,
                report.token_close_error
            ),
            (source, kind, native, close)
        );
    }
    for (kind, expected) in [
        (io::ErrorKind::InvalidData, ERROR_INVALID_DATA),
        (io::ErrorKind::OutOfMemory, ERROR_NO_MEMORY),
        (io::ErrorKind::InvalidInput, ERROR_INVALID_STATE),
        (io::ErrorKind::Other, ERROR_OTHER),
    ] {
        let mut report = MembersReport::default();
        record_io(&mut report, SOURCE_COPY, &kind.into());
        assert_eq!(
            (report.error_source, report.error_kind, report.native_error),
            (SOURCE_COPY, expected, 0)
        );
    }
}

// These records test projection validation only. They are not native resource,
// membership or identity evidence; the later tests acquire real NativeOwners.
fn projection_input() -> (JobMemberSnapshot, OriginalCreation) {
    let census = JobMemberCensus {
        total_processes: 1,
        active_processes: 1,
        pids: vec![42],
    };
    (
        JobMemberSnapshot {
            generation: 1,
            pre: Some(census.clone()),
            post: Some(census),
            rows: vec![JobMemberIdentity {
                pid: 42,
                creation_time_100ns: 123,
                image_path: PathBuf::from(r"C:\fixtures\child.exe"),
                token_user_sid: vec![1, 1, 0, 0, 0, 0, 0, 5, 18, 0, 0, 0],
            }],
            resources: vec![JobMemberResource {
                pid: 42,
                borrowed_original: true,
                close_attempted: false,
                closed: false,
                close_error: None,
            }],
            complete: true,
        },
        OriginalCreation {
            pid: 42,
            reserved: 0,
            creation_time_100ns: 123,
        },
    )
}

#[test]
fn projection_rejects_malformed_counts_identity_and_resource_facts() {
    type Change = fn(&mut JobMemberSnapshot);
    let cases: [(&str, Change); 13] = [
        ("generation", |v| v.generation = 0),
        ("missing pre", |v| v.pre = None),
        ("post with missing coverage", |v| {
            v.complete = false;
            v.rows.clear();
            v.resources.clear();
        }),
        ("active count", |v| {
            v.pre.as_mut().unwrap().active_processes = 2
        }),
        ("lifetime count", |v| {
            v.pre.as_mut().unwrap().total_processes = 0
        }),
        ("zero pid", |v| v.pre.as_mut().unwrap().pids[0] = 0),
        ("row pid", |v| v.rows[0].pid = 43),
        ("root birth", |v| v.rows[0].creation_time_100ns = 124),
        ("relative image", |v| {
            v.rows[0].image_path = PathBuf::from("relative.exe")
        }),
        ("SID revision", |v| v.rows[0].token_user_sid[0] = 0),
        ("SID size", |v| v.rows[0].token_user_sid.push(0)),
        ("root ownership", |v| {
            v.resources[0].borrowed_original = false
        }),
        ("borrowed close", |v| v.resources[0].close_attempted = true),
    ];
    for (name, mutate) in cases {
        let (mut value, original) = projection_input();
        mutate(&mut value);
        assert!(SnapshotProjection::new(&value, original).is_err(), "{name}");
    }
    let (mut value, original) = projection_input();
    value.pre.as_mut().unwrap().pids = vec![42; MAX_COUNT + 1];
    assert!(SnapshotProjection::new(&value, original).is_err());
    let (value, mut original) = projection_input();
    original.creation_time_100ns = 0;
    assert!(SnapshotProjection::new(&value, original).is_err());

    let (mut value, original) = projection_input();
    for pid in [43, 44] {
        let mut row = value.rows[0].clone();
        row.pid = pid;
        value.rows.push(row);
        value.resources.push(JobMemberResource {
            pid,
            borrowed_original: false,
            close_attempted: pid == 43,
            closed: pid == 43,
            close_error: None,
        });
    }
    let census = JobMemberCensus {
        total_processes: 3,
        active_processes: 3,
        pids: vec![42, 43, 44],
    };
    value.pre = Some(census.clone());
    value.post = Some(census);
    assert!(
        SnapshotProjection::new(&value, original).is_err(),
        "mixed open/attempted owned resources"
    );
}

#[test]
fn projection_preserves_partial_empty_and_initializes_reserved_storage() {
    let (value, original) = projection_input();
    let projected = SnapshotProjection::new(&value, original).unwrap();
    assert_eq!(
        projected.value.flags,
        PRE_KNOWN | POST_KNOWN | ACQUISITION_COMPLETE
    );
    assert_eq!(projected.value.reserved, 0);
    assert_eq!(projected._rows[0].reserved, 0);
    assert!(projected._rows[0].sid[12..].iter().all(|v| *v == 0));
    assert_eq!(projected._resources[0].reserved, 0);

    let mut changed = value.clone();
    changed.complete = false;
    changed.post = Some(JobMemberCensus {
        total_processes: 2,
        active_processes: 1,
        pids: vec![43],
    });
    let projected = SnapshotProjection::new(&changed, original).unwrap();
    assert_eq!(projected.value.flags, PRE_KNOWN | POST_KNOWN);
    assert_eq!(
        (
            projected.value.pre.total_processes,
            projected.value.post.total_processes,
            projected.value.post.active_processes
        ),
        (1, 2, 1)
    );
    // SAFETY: this successful projection borrows both complete census arrays
    // from the still-live synthetic input; their lengths were validated above.
    let (pre_pids, post_pids) = unsafe {
        (
            copy_view(projected.value.pre.pids, projected.value.pre.count),
            copy_view(projected.value.post.pids, projected.value.post.count),
        )
    };
    assert_eq!(pre_pids, vec![42]);
    assert_eq!(post_pids, vec![43]);
    assert_eq!(
        (projected.value.row_count, projected.value.resource_count),
        (1, 1)
    );
    assert_eq!(
        (projected._rows[0].pid, projected._resources[0].pid),
        (42, 42)
    );

    let partial = JobMemberSnapshot {
        generation: 2,
        pre: Some(JobMemberCensus {
            total_processes: 1,
            active_processes: 0,
            pids: vec![],
        }),
        post: None,
        rows: vec![],
        resources: vec![],
        complete: false,
    };
    let projected = SnapshotProjection::new(&partial, original).unwrap();
    assert_eq!(projected.value.flags, PRE_KNOWN);
    assert!(projected.value.pre.pids.is_null() && projected.value.post.pids.is_null());
    assert!(projected.value.rows.is_null() && projected.value.resources.is_null());
    assert_eq!(
        (projected.value.row_count, projected.value.resource_count),
        (0, 0)
    );
}

#[test]
fn close_projection_preserves_failure_presence_even_when_native_code_is_zero() {
    let failed = JobMemberResource {
        pid: 43,
        borrowed_original: false,
        close_attempted: true,
        closed: false,
        close_error: Some(NativeFailure {
            operation: "CloseJobMemberProcess",
            code: 0,
        }),
    };
    let receipt = JobMemberClose {
        generation: 9,
        resources: vec![failed.clone()],
        complete: false,
    };
    let mut resources = Vec::with_capacity(1);
    let projected = close_projection(&receipt, 9, 1, 42, &mut resources).unwrap();
    assert_eq!(projected.flags, 0);
    assert_eq!(
        (resources[0].flags, resources[0].close_error),
        (CLOSE_ATTEMPTED | CLOSE_FAILED, 0)
    );
    let mut invalid = failed.clone();
    invalid.close_error = None;
    assert!(
        resource(&invalid).is_err(),
        "attempted close without success or failure"
    );
    invalid = failed;
    invalid.closed = true;
    assert!(
        resource(&invalid).is_err(),
        "success and failure cannot coexist"
    );
    let wrong_complete = JobMemberClose {
        complete: true,
        ..receipt
    };
    let mut storage = Vec::with_capacity(1);
    assert!(close_projection(&wrong_complete, 9, 1, 42, &mut storage).is_err());
}

#[derive(Debug, PartialEq, Eq)]
struct RowCopy {
    pid: u32,
    birth: u64,
    image: Vec<u16>,
    sid: Vec<u8>,
}
#[derive(Debug, PartialEq, Eq)]
struct CensusCopy {
    total: u32,
    active: u32,
    pids: Vec<u32>,
}
#[derive(Debug, PartialEq, Eq)]
struct SnapshotCopy {
    generation: u64,
    flags: u32,
    original: OriginalCreation,
    pre: CensusCopy,
    post: CensusCopy,
    rows: Vec<RowCopy>,
    resources: Vec<MemberResource>,
}
#[derive(Default)]
struct SnapshotReceiverState {
    calls: usize,
    bytes: u32,
    value: Option<SnapshotCopy>,
}
#[derive(Debug, Clone, PartialEq, Eq)]
struct CloseCopy {
    generation: u64,
    flags: u32,
    resources: Vec<MemberResource>,
}
#[derive(Default)]
struct CloseReceiverState {
    calls: usize,
    bytes: u32,
    value: Option<CloseCopy>,
}

unsafe fn copy_view<T: Copy>(data: *const T, len: usize) -> Vec<T> {
    if len == 0 {
        return Vec::new();
    }
    // SAFETY: used only by these callbacks with the producer's complete valid
    // views. Zero-length NULL is handled without forming a Rust slice.
    unsafe { slice::from_raw_parts(data, len).to_vec() }
}
unsafe extern "C" fn receive_snapshot(raw: *const MembersSnapshot, bytes: u32, token: usize) {
    // SAFETY: producer supplies a complete immutable snapshot and views;
    // this test passes an exclusive live callback state for this synchronous call.
    unsafe {
        let state = &mut *(token as *mut SnapshotReceiverState);
        let value = &*raw;
        state.calls += 1;
        state.bytes = bytes;
        let rows = if value.row_count == 0 {
            Vec::new()
        } else {
            slice::from_raw_parts(value.rows, value.row_count)
                .iter()
                .map(|row| RowCopy {
                    pid: row.pid,
                    birth: row.creation_time_100ns,
                    image: copy_view(row.image.data, row.image.len),
                    sid: row.sid[..row.sid_len as usize].to_vec(),
                })
                .collect()
        };
        state.value = Some(SnapshotCopy {
            generation: value.generation,
            flags: value.flags,
            original: value.original,
            pre: CensusCopy {
                total: value.pre.total_processes,
                active: value.pre.active_processes,
                pids: copy_view(value.pre.pids, value.pre.count),
            },
            post: CensusCopy {
                total: value.post.total_processes,
                active: value.post.active_processes,
                pids: copy_view(value.post.pids, value.post.count),
            },
            rows,
            resources: copy_view(value.resources, value.resource_count),
        });
    }
}
unsafe extern "C" fn receive_close(raw: *const MembersClose, bytes: u32, token: usize) {
    // SAFETY: same complete immutable producer view and call-scoped test state.
    unsafe {
        let state = &mut *(token as *mut CloseReceiverState);
        let value = &*raw;
        state.calls += 1;
        state.bytes = bytes;
        state.value = Some(CloseCopy {
            generation: value.generation,
            flags: value.flags,
            resources: copy_view(value.resources, value.resource_count),
        });
    }
}
fn suspended_owner() -> Box<Owner> {
    let executable = std::env::current_exe().unwrap();
    Box::new(Owner {
        inner: NativeOwner::create_suspended(&executable, &["--list".into()]).unwrap(),
        terminal: false,
    })
}
fn settle(owner: &mut Owner, code: u32) {
    if let Some(generation) = owner
        .inner
        .job_member_snapshot()
        .map(|value| value.generation)
    {
        owner.inner.close_job_members(generation).unwrap();
    }
    owner.inner.terminate(code).unwrap();
    assert_eq!(
        owner.inner.finish(Duration::from_secs(3)).unwrap(),
        Settlement::Complete { root_exit: code }
    );
}
fn observe(owner: &mut Owner, budget: u32) -> (u32, u64, MembersReport, Outcome) {
    let mut generation = 0;
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    // SAFETY: real live owner, separate full outputs, initially zero scalar.
    let status = unsafe {
        mh_members_observe1(
            owner,
            VERSION,
            budget,
            &mut generation,
            &mut report,
            REPORT_BYTES,
            &mut out,
            OUT_BYTES,
        )
    };
    (status, generation, report, out)
}
fn snapshot(
    owner: &mut Owner,
    generation: u64,
) -> (u32, SnapshotReceiverState, MembersReport, Outcome) {
    let mut receive = SnapshotReceiverState::default();
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    // SAFETY: real owner and complete disjoint output/state; synchronous copying receiver.
    let status = unsafe {
        mh_members_snapshot1(
            owner,
            VERSION,
            generation,
            Some(receive_snapshot),
            &mut receive as *mut SnapshotReceiverState as usize,
            &mut report,
            REPORT_BYTES,
            &mut out,
            OUT_BYTES,
        )
    };
    (status, receive, report, out)
}
fn close(
    owner: &mut Owner,
    generation: u64,
) -> (u32, u32, CloseReceiverState, MembersReport, Outcome) {
    let mut finalized = 0;
    let mut receive = CloseReceiverState::default();
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    // SAFETY: live owner, initially zero scalar and complete disjoint copy-only outputs.
    let status = unsafe {
        mh_members_close1(
            owner,
            VERSION,
            generation,
            &mut finalized,
            Some(receive_close),
            &mut receive as *mut CloseReceiverState as usize,
            &mut report,
            REPORT_BYTES,
            &mut out,
            OUT_BYTES,
        )
    };
    (status, finalized, receive, report, out)
}

#[test]
fn observe_preflight_rejects_before_reservation_and_never_overwrites_a_nonzero_slot() {
    let mut owner = suspended_owner();
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    for (version, budget, report_bytes, out_bytes, expected) in [
        (2, 1000, REPORT_BYTES, OUT_BYTES, ABI),
        (1, 60001, REPORT_BYTES, OUT_BYTES, ARGUMENT),
        (1, 1000, REPORT_BYTES - 1, OUT_BYTES, ARGUMENT),
        (1, 1000, REPORT_BYTES, OUT_BYTES - 1, ARGUMENT),
    ] {
        let mut generation = 0;
        // SAFETY: complete valid allocations; only declared metadata is malformed.
        let status = unsafe {
            mh_members_observe1(
                &mut *owner,
                version,
                budget,
                &mut generation,
                &mut report,
                report_bytes,
                &mut out,
                out_bytes,
            )
        };
        assert_eq!(status, expected);
        assert_eq!(generation, 0);
        assert!(owner.inner.job_member_snapshot().is_none());
    }
    let mut occupied = 91;
    // SAFETY: valid scalar storage intentionally violates the zero-value preflight.
    assert_eq!(
        unsafe {
            mh_members_observe1(
                &mut *owner,
                VERSION,
                1000,
                &mut occupied,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        ARGUMENT
    );
    assert_eq!(occupied, 91);
    // SAFETY: null scalar is rejected before any dereference or native operation.
    assert_eq!(
        unsafe {
            mh_members_observe1(
                &mut *owner,
                VERSION,
                1000,
                ptr::null_mut(),
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        ARGUMENT
    );
    #[repr(align(8))]
    struct Aligned([u8; 16]);
    let mut storage = Aligned([0; 16]);
    let unaligned = storage.0.as_mut_ptr().wrapping_add(1).cast::<u64>();
    // SAFETY: malformed alignment is checked without reading this scalar.
    assert_eq!(
        unsafe {
            mh_members_observe1(
                &mut *owner,
                VERSION,
                1000,
                unaligned,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        ARGUMENT
    );
    assert!(owner.inner.job_member_snapshot().is_none());
    let (status, generation, report, _) = observe(&mut owner, 0);
    assert_eq!(
        (status, generation, report.error_source, report.error_kind),
        (STATE, 0, SOURCE_OBSERVATION, ERROR_DEADLINE)
    );
    assert!(owner.inner.job_member_snapshot().is_none());
    let (status, generation, report, _) = observe(&mut owner, 1000);
    assert_eq!(
        (status, generation, report.error_source),
        (OK, 1, SOURCE_NONE)
    );
    settle(&mut owner, 84);
}

#[test]
fn occupied_generation_is_not_acquired_and_stale_requests_cannot_touch_a_new_epoch() {
    let mut owner = suspended_owner();
    let (status, first, _, _) = observe(&mut owner, 1000);
    assert_eq!(status, OK);
    let (status, acquired, report, out) = observe(&mut owner, 1000);
    assert_eq!(
        (status, acquired, report.error_source, report.error_kind),
        (STATE, 0, SOURCE_OBSERVATION, ERROR_BUSY)
    );
    assert_eq!((out.state, out.native_error, out.cleanup_mask), (0, 0, 0));
    let (status, before, _, _) = snapshot(&mut owner, first);
    assert_eq!(status, OK);
    assert_eq!(before.calls, 1);
    assert_eq!(before.bytes as usize, size_of::<MembersSnapshot>());
    let before = before.value.unwrap();
    assert_eq!(before.original.pid, owner.inner.root_pid());
    assert_eq!(
        before.original.creation_time_100ns,
        owner.inner.original_creation_time_100ns().unwrap()
    );
    assert_eq!(before.flags, PRE_KNOWN | POST_KNOWN | ACQUISITION_COMPLETE);
    let (status, finalized, receipt, _, out) = close(&mut owner, first);
    assert_eq!((status, finalized, receipt.calls), (OK, 1, 1));
    assert_eq!(receipt.bytes as usize, size_of::<MembersClose>());
    assert_eq!(out.state, 0);
    assert!(
        !owner.terminal,
        "member close cannot release the original owner"
    );
    let (status, repeated, replay, _, _) = close(&mut owner, first);
    assert_eq!((status, repeated, replay.calls), (OK, 1, 1));
    assert_eq!(receipt.value, replay.value);
    let (status, after, _, _) = snapshot(&mut owner, first);
    assert_eq!(status, OK);
    assert_eq!(after.calls, 1);
    assert!(
        before == after.value.unwrap(),
        "borrowed root close changes no acquisition facts"
    );

    let (status, second, _, _) = observe(&mut owner, 1000);
    assert_eq!((status, second), (OK, first + 1));
    let (status, finalized, receiver, report, _) = close(&mut owner, first);
    assert_eq!(
        (status, finalized, receiver.calls, report.error_kind),
        (STATE, 0, 0, ERROR_INVALID_STATE)
    );
    let (status, receiver, report, _) = snapshot(&mut owner, first);
    assert_eq!(
        (status, receiver.calls, report.error_kind),
        (STATE, 0, ERROR_INVALID_STATE)
    );
    assert_eq!(
        owner.inner.job_member_snapshot().unwrap().generation,
        second
    );
    assert_eq!(
        owner.inner.finish(Duration::ZERO).unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    // SAFETY: real current generation; zero budget must not be renewed.
    assert_eq!(
        unsafe {
            mh_members_revalidate1(
                &mut *owner,
                VERSION,
                second,
                0,
                0,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        STATE
    );
    assert_eq!(report.error_kind, ERROR_DEADLINE);
    let root_pid = owner.inner.root_pid();
    // SAFETY: the same retained handles remain usable under a later caller deadline.
    assert_eq!(
        unsafe {
            mh_members_revalidate1(
                &mut *owner,
                VERSION,
                second,
                1000,
                root_pid,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        OK
    );
    settle(&mut owner, 85);
}

#[test]
fn invalid_read_and_close_preflight_preserves_the_active_native_observation() {
    let mut owner = suspended_owner();
    let (status, generation, _, _) = observe(&mut owner, 1000);
    assert_eq!(status, OK);
    let baseline = owner.inner.job_member_snapshot().unwrap().clone();
    let mut report = MembersReport::default();
    let mut out = Outcome::default();
    let mut receiver = CloseReceiverState::default();
    let token = &mut receiver as *mut CloseReceiverState as usize;
    let callback: Option<CloseReceiver> = Some(receive_close);
    for (version, epoch, receive, report_bytes, out_bytes, expected) in [
        (2, generation, callback, REPORT_BYTES, OUT_BYTES, ABI),
        (1, 0, callback, REPORT_BYTES, OUT_BYTES, ARGUMENT),
        (1, generation, None, REPORT_BYTES, OUT_BYTES, ARGUMENT),
        (
            1,
            generation,
            callback,
            REPORT_BYTES - 1,
            OUT_BYTES,
            ARGUMENT,
        ),
        (
            1,
            generation,
            callback,
            REPORT_BYTES,
            OUT_BYTES - 1,
            ARGUMENT,
        ),
    ] {
        let mut finalized = 0;
        // SAFETY: complete disjoint allocations; invalid metadata precedes close.
        assert_eq!(
            unsafe {
                mh_members_close1(
                    &mut *owner,
                    version,
                    epoch,
                    &mut finalized,
                    receive,
                    token,
                    &mut report,
                    report_bytes,
                    &mut out,
                    out_bytes,
                )
            },
            expected
        );
        assert_eq!((finalized, receiver.calls), (0, 0));
        assert!(
            owner.inner.job_member_snapshot().unwrap() == &baseline,
            "acquisition facts changed after preflight refusal"
        );
        assert_eq!(
            owner.inner.terminate(1).unwrap_err().kind(),
            io::ErrorKind::WouldBlock
        );
    }
    let mut occupied = 7;
    // SAFETY: a nonzero input is valid storage but invalid preflight.
    assert_eq!(
        unsafe {
            mh_members_close1(
                &mut *owner,
                VERSION,
                generation,
                &mut occupied,
                callback,
                token,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        ARGUMENT
    );
    assert_eq!(occupied, 7);
    // SAFETY: null scalar is rejected without dereference/native close.
    assert_eq!(
        unsafe {
            mh_members_close1(
                &mut *owner,
                VERSION,
                generation,
                ptr::null_mut(),
                callback,
                token,
                &mut report,
                REPORT_BYTES,
                &mut out,
                OUT_BYTES,
            )
        },
        ARGUMENT
    );

    let mut receiver = SnapshotReceiverState::default();
    let token = &mut receiver as *mut SnapshotReceiverState as usize;
    let callback: Option<SnapshotReceiver> = Some(receive_snapshot);
    for (version, epoch, receive, expected) in [
        (2, generation, callback, ABI),
        (1, 0, callback, ARGUMENT),
        (1, generation, None, ARGUMENT),
    ] {
        // SAFETY: complete owner/output/state, deliberately invalid request metadata.
        assert_eq!(
            unsafe {
                mh_members_snapshot1(
                    &mut *owner,
                    version,
                    epoch,
                    receive,
                    token,
                    &mut report,
                    REPORT_BYTES,
                    &mut out,
                    OUT_BYTES,
                )
            },
            expected
        );
        assert_eq!(receiver.calls, 0);
        assert!(
            owner.inner.job_member_snapshot().unwrap() == &baseline,
            "acquisition facts changed after preflight refusal"
        );
    }
    for (version, epoch, budget, expected) in [
        (2, generation, 1000, ABI),
        (1, 0, 1000, ARGUMENT),
        (1, generation, 60001, ARGUMENT),
    ] {
        // SAFETY: complete live owner/output; malformed version/epoch/budget.
        assert_eq!(
            unsafe {
                mh_members_revalidate1(
                    &mut *owner,
                    version,
                    epoch,
                    budget,
                    0,
                    &mut report,
                    REPORT_BYTES,
                    &mut out,
                    OUT_BYTES,
                )
            },
            expected
        );
        assert_eq!(report.error_source, SOURCE_NONE);
    }
    assert!(
        owner.inner.job_member_snapshot().unwrap() == &baseline,
        "acquisition facts changed after preflight refusal"
    );
    // Valid close proves none of the refused terminal attempts consumed state.
    let (status, finalized, receiver, _, _) = close(&mut owner, generation);
    assert_eq!((status, finalized, receiver.calls), (OK, 1, 1));
    settle(&mut owner, 86);
}

#[test]
fn empty_original_job_preserves_zero_resource_reservation_until_close_and_historical_copy() {
    let mut owner = suspended_owner();
    let birth = owner.inner.original_creation_time_100ns().unwrap();
    let pid = owner.inner.root_pid();
    owner.inner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.inner.wait_for_exit(Duration::from_secs(3)).unwrap(),
        ExitObservation::Exited { root_exit: 0 }
    );
    let (status, generation, report, out) = observe(&mut owner, 1000);
    assert_ne!(
        generation, 0,
        "a failed empty-census acquisition still reserved"
    );
    assert_eq!(
        (status, report.error_source, report.error_kind),
        (STATE, SOURCE_OBSERVATION, ERROR_INVALID_DATA)
    );
    assert_eq!((out.state, out.native_error, out.cleanup_mask), (0, 0, 0));
    let native = owner.inner.job_member_snapshot().unwrap();
    assert_eq!(native.generation, generation);
    assert!(!native.complete && native.rows.is_empty() && native.resources.is_empty());
    assert_eq!(
        owner.inner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    let (status, before, report, _) = snapshot(&mut owner, generation);
    assert_eq!(
        (status, before.calls, report.error_source),
        (OK, 1, SOURCE_NONE)
    );
    let before = before.value.unwrap();
    assert_eq!(
        before.original,
        OriginalCreation {
            pid,
            reserved: 0,
            creation_time_100ns: birth
        }
    );
    assert_eq!(before.flags, PRE_KNOWN);
    assert_eq!(before.pre.active, 0);
    assert!(before.pre.pids.is_empty() && before.rows.is_empty() && before.resources.is_empty());

    let (status, finalized, receipt, _, _) = close(&mut owner, generation);
    assert_eq!((status, finalized, receipt.calls), (OK, 1, 1));
    let receipt = receipt.value.unwrap();
    assert_eq!(receipt.flags, CLOSE_COMPLETE);
    assert!(receipt.resources.is_empty());
    assert!(!owner.terminal);
    let mut out = Outcome::default();
    // SAFETY: the real caller-owned Box is only borrowed; mh_close1 closes
    // original handles but does not free the allocation (no mh_release1 here).
    assert_eq!(
        unsafe { crate::mh_close1(&mut *owner, &mut out, OUT_BYTES) },
        OK
    );
    assert!(owner.terminal);
    assert_eq!(out.state, crate::COMPLETE);
    let (status, after, report, out) = snapshot(&mut owner, generation);
    assert_eq!(
        (status, after.calls, report.error_source),
        (OK, 1, SOURCE_NONE)
    );
    assert!(
        before == after.value.unwrap(),
        "historical copy must work with original handles closed"
    );
    assert_eq!((out.state, out.root_exit), (0, 0));
    let (status, finalized, replay, _, _) = close(&mut owner, generation);
    assert_eq!((status, finalized, replay.calls), (OK, 1, 1));
    assert_eq!(receipt, replay.value.unwrap());
}
