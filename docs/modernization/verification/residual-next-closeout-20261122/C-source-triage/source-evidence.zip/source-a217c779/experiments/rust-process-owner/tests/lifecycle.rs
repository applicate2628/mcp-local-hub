#![cfg(windows)]
use mcphub_process_owner_spike::{
    ExitObservation, JobMemberQueryError, NativeOwner, RootWait, Settlement,
};
use std::{
    ffi::OsString,
    fs, io,
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
    thread,
    time::{Duration, Instant},
};
const DEADLINE: Duration = Duration::from_secs(3);
static NEXT: AtomicU64 = AtomicU64::new(1);
struct Fixture {
    root: PathBuf,
}
impl Fixture {
    fn new() -> Self {
        let root =
            PathBuf::from(std::env::var_os("MCPHUB_RX02_FIXTURES").expect("owned fixture root"))
                .join(format!(
                    "mcphub-native-owner-{}-{}",
                    std::process::id(),
                    NEXT.fetch_add(1, Ordering::Relaxed)
                ));
        fs::create_dir(&root).unwrap();
        Self { root }
    }
    fn marker(&self) -> PathBuf {
        self.root.join("marker with spaces λ.txt")
    }
    fn launch(&self, mode: &str, code: u32, payload: &str) -> NativeOwner {
        NativeOwner::create_suspended(
            Path::new(env!("CARGO_BIN_EXE_owner_child")),
            &[
                mode.into(),
                self.marker().into_os_string(),
                code.to_string().into(),
                payload.into(),
            ],
        )
        .unwrap()
    }
}
// Fixtures are retained for evidence and later trash-first disposition; no deletion.
fn wait_marker(path: &Path) {
    let until = Instant::now() + DEADLINE;
    while !path.exists() {
        assert!(
            Instant::now() < until,
            "test child did not publish readiness"
        );
        thread::sleep(Duration::from_millis(5));
    }
}

#[test]
fn process_view_repeats_without_consuming_admission_and_reads_running_owner() {
    let f = Fixture::new();
    let mut owner = f.launch("block", 0, "");
    let pid = owner.root_pid();
    let birth = owner.process_view().unwrap().creation_time_100ns().unwrap();
    let sid = owner.process_view().unwrap().token_user_sid().unwrap();
    for _ in 0..3 {
        let view = owner.process_view().unwrap();
        assert_eq!(view.process_id().unwrap(), pid);
        assert_eq!(view.creation_time_100ns().unwrap(), birth);
        assert!(view.is_in_original_job().unwrap());
        assert_eq!(view.wait_state().unwrap(), RootWait::NotSignaled);
        assert!(
            !f.marker().exists(),
            "read-only observation resumed the child"
        );
    }
    assert_eq!(owner.root_exit(), None);
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker());
    {
        let view = owner.process_view().unwrap();
        assert_eq!(view.process_id().unwrap(), pid);
        assert_eq!(view.creation_time_100ns().unwrap(), birth);
        assert!(view.is_in_original_job().unwrap());
        assert_eq!(view.wait_state().unwrap(), RootWait::NotSignaled);
        assert!(
            view.token_user_sid().unwrap() == sid,
            "retained process SID changed"
        );
    }
    assert_eq!(owner.root_exit(), None);
    assert!(matches!(
        owner.finish(Duration::ZERO).unwrap(),
        Settlement::Pending {
            root_exit: None,
            ..
        }
    ));
    assert_eq!(owner.process_view().unwrap().process_id().unwrap(), pid);
    owner.terminate(81).unwrap();
    assert!(matches!(
        owner.process_view(),
        Err(error) if error.kind() == io::ErrorKind::InvalidInput
    ));
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 81 }
    );
    assert!(matches!(
        owner.process_view(),
        Err(error) if error.kind() == io::ErrorKind::InvalidInput
    ));
}

#[test]
fn process_view_after_denial_does_not_reopen_admission_or_resume() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 0, "must not appear");
    let pid = owner.root_pid();
    let birth = owner.process_view().unwrap().creation_time_100ns().unwrap();
    assert_eq!(
        owner
            .admit_and_resume(|_| Err(io::ErrorKind::PermissionDenied.into()))
            .unwrap_err()
            .kind(),
        io::ErrorKind::PermissionDenied
    );
    for _ in 0..3 {
        let view = owner.process_view().unwrap();
        assert_eq!(view.process_id().unwrap(), pid);
        assert_eq!(view.creation_time_100ns().unwrap(), birth);
        assert!(view.is_in_original_job().unwrap());
        assert_eq!(view.wait_state().unwrap(), RootWait::NotSignaled);
    }
    assert_eq!(
        owner.admit_and_resume(|_| Ok(())).unwrap_err().kind(),
        io::ErrorKind::InvalidInput
    );
    owner.terminate(82).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 82 }
    );
    assert!(
        !f.marker().exists(),
        "observation after denial resumed the child"
    );
}

#[test]
fn token_user_observation_matches_child_and_survives_settlement() {
    let f = Fixture::new();
    let mut owner = f.launch("token-user", 0, "");
    let mut observed = Vec::new();
    owner
        .admit_and_resume(|view| {
            observed = view.token_user_sid().map_err(io::Error::other)?;
            assert!(!observed.is_empty(), "token observation returned no SID");
            assert!(!f.marker().exists(), "token observation resumed the child");
            assert_eq!(view.wait_state()?, RootWait::NotSignaled);
            Ok(())
        })
        .unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
    drop(owner);
    let report = fs::read(f.marker()).unwrap();
    // Compare privately: never include the machine's actual SID in test logs.
    assert!(
        observed == report,
        "original-process SID differs from child observation"
    );
}

#[test]
fn identity_observation_matches_child_and_does_not_resume_it() {
    let f = Fixture::new();
    let mut owner = f.launch("identity", 0, "");
    let pid = owner.root_pid();
    let mut birth = 0;
    owner
        .admit_and_resume(|view| {
            assert_eq!(view.process_id()?, pid);
            birth = view.creation_time_100ns()?;
            assert_ne!(birth, 0);
            assert_eq!(view.creation_time_100ns()?, birth);
            assert!(view.is_in_original_job()?);
            assert_eq!(view.wait_state()?, RootWait::NotSignaled);
            assert!(!f.marker().exists(), "observation resumed the child");
            Ok(())
        })
        .unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
    let report = fs::read(f.marker()).unwrap();
    assert_eq!(report.len(), 12);
    assert_eq!(u32::from_le_bytes(report[..4].try_into().unwrap()), pid);
    assert_eq!(u64::from_le_bytes(report[4..].try_into().unwrap()), birth);
}

#[test]
fn original_process_is_suspended_and_job_member_before_admission() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 7, "hello");
    let pid = owner.root_pid();
    assert!(pid > 0);
    assert_eq!(owner.active_processes().unwrap(), 1);
    assert!(!f.marker().exists());
    assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), None);
    owner
        .admit_and_resume(|view| {
            assert_eq!(view.process_id()?, pid);
            assert_eq!(
                view.image_path()?.file_name(),
                Path::new(env!("CARGO_BIN_EXE_owner_child")).file_name()
            );
            assert!(!f.marker().exists());
            Ok(())
        })
        .unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
    assert_eq!(fs::read_to_string(f.marker()).unwrap(), "hello");
    assert_eq!(
        owner.finish(Duration::ZERO).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

#[test]
fn rejected_admission_retains_original_owner_without_execution() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 0, "must not appear");
    let pid = owner.root_pid();
    let err = owner
        .admit_and_resume(|_| {
            Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "fixture rejects",
            ))
        })
        .unwrap_err();
    assert_eq!(err.kind(), io::ErrorKind::PermissionDenied);
    assert_eq!(owner.root_pid(), pid);
    assert!(!f.marker().exists());
    assert!(matches!(
        owner.finish(Duration::ZERO).unwrap(),
        Settlement::Pending {
            root_exit: None,
            ..
        }
    ));
    owner.terminate(73).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 73 }
    );
    assert!(!f.marker().exists());
}

#[test]
fn running_timeout_keeps_owner_and_can_be_settled() {
    let f = Fixture::new();
    let mut owner = f.launch("block", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker());
    let pid = owner.root_pid();
    assert!(matches!(
        owner.finish(Duration::from_millis(5)).unwrap(),
        Settlement::Pending {
            root_exit: None,
            ..
        }
    ));
    assert_eq!(owner.root_pid(), pid);
    owner.terminate(74).unwrap();
    owner.terminate(74).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 74 }
    );
    assert_eq!(owner.root_exit(), Some(74));
}

#[test]
fn one_owner_settles_root_and_descendant() {
    let f = Fixture::new();
    let mut owner = f.launch("tree", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker());
    wait_marker(&f.marker().with_extension("grandchild"));
    assert!(owner.active_processes().unwrap() >= 2);
    owner.terminate(75).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 75 }
    );
}

#[test]
fn exit_code_still_active_is_not_mistaken_for_running() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 259, "finished");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 259 }
    );
}

#[test]
fn wide_argv_preserves_unicode_quotes_backslashes_and_empty() {
    for payload in [
        "",
        "a b λ",
        "quote\"inside",
        "trail\\",
        "slash\\\"quote\\\\",
    ] {
        let f = Fixture::new();
        let mut owner = f.launch("exit", 0, payload);
        owner.admit_and_resume(|_| Ok(())).unwrap();
        assert_eq!(
            owner.finish(DEADLINE).unwrap(),
            Settlement::Complete { root_exit: 0 }
        );
        assert_eq!(fs::read_to_string(f.marker()).unwrap(), payload);
    }
}

#[test]
fn repeated_resume_is_rejected() {
    let f = Fixture::new();
    let mut owner = f.launch("block", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.admit_and_resume(|_| Ok(())).unwrap_err().kind(),
        io::ErrorKind::InvalidInput
    );
    owner.terminate(76).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 76 }
    );
}

#[test]
fn invalid_argument_fails_before_creation() {
    let args = [OsString::from("bad\0argument")];
    let result = NativeOwner::create_suspended(Path::new(env!("CARGO_BIN_EXE_owner_child")), &args);
    assert!(matches!(result,Err(ref e) if e.kind()==io::ErrorKind::InvalidInput));
}

#[test]
fn missing_image_returns_error_without_started_owner() {
    let f = Fixture::new();
    assert!(NativeOwner::create_suspended(&f.root.join("missing.exe"), &[]).is_err());
}

#[test]
fn repeated_create_settle_does_not_grow_handle_count() {
    use windows_sys::Win32::System::Threading::{GetCurrentProcess, GetProcessHandleCount};
    fn handles() -> u32 {
        let mut n = 0; /* SAFETY: valid pseudo-handle and writable count. */
        assert_ne!(
            unsafe { GetProcessHandleCount(GetCurrentProcess(), &mut n) },
            0
        );
        n
    }
    let warm = Fixture::new();
    let mut owner = warm.launch("exit", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
    drop(owner);
    let before = handles();
    for _ in 0..24 {
        let f = Fixture::new();
        let mut owner = f.launch("exit", 0, "");
        owner.admit_and_resume(|_| Ok(())).unwrap();
        assert_eq!(
            owner.finish(DEADLINE).unwrap(),
            Settlement::Complete { root_exit: 0 }
        );
    }
    assert_eq!(
        handles(),
        before,
        "native handles leaked across complete owner lifetimes"
    );
}

#[test]
fn completed_root_does_not_mean_completed_tree() {
    let f = Fixture::new();
    let mut owner = f.launch("detach", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker().with_extension("grandchild"));
    assert_eq!(owner.wait_root(DEADLINE).unwrap(), Some(7));
    assert!(
        matches!(owner.finish(Duration::ZERO).unwrap(),Settlement::Pending{root_exit:Some(7),active_processes:Some(n)} if n>0)
    );
    owner.terminate(82).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

#[test]
fn denied_admission_cannot_be_retried_as_approval() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 0, "forbidden");
    assert!(owner
        .admit_and_resume(|_| Err(io::ErrorKind::PermissionDenied.into()))
        .is_err());
    assert_eq!(
        owner.admit_and_resume(|_| Ok(())).unwrap_err().kind(),
        io::ErrorKind::InvalidInput
    );
    owner.terminate(83).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 83 }
    );
    assert!(!f.marker().exists());
}

#[test]
fn root_result_survives_late_stop_request() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 7, "completed");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(owner.wait_root(DEADLINE).unwrap(), Some(7));
    owner.terminate(84).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

#[test]
fn split_wait_preserves_original_resources_until_explicit_close() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 259, "observed-not-closed");
    let pid = owner.root_pid();
    let birth = owner.process_view().unwrap().creation_time_100ns().unwrap();
    assert_eq!(
        owner.wait_for_exit(Duration::ZERO).unwrap(),
        ExitObservation::Pending {
            root_exit: None,
            active_processes: None
        }
    );
    assert!(
        !f.marker().exists(),
        "observation resumed the original root"
    );
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.wait_for_exit(DEADLINE).unwrap(),
        ExitObservation::Exited { root_exit: 259 }
    );
    for _ in 0..3 {
        assert_eq!(
            owner.active_processes().unwrap(),
            0,
            "wait closed the original Job"
        );
        let view = owner.process_view().unwrap();
        assert_eq!(view.process_id().unwrap(), pid);
        assert_eq!(view.creation_time_100ns().unwrap(), birth);
        assert_eq!(view.wait_state().unwrap(), RootWait::Signaled);
        assert_eq!(
            owner.wait_for_exit(Duration::ZERO).unwrap(),
            ExitObservation::Exited { root_exit: 259 }
        );
    }
    assert_eq!(
        owner.close_exited().unwrap(),
        Settlement::Complete { root_exit: 259 }
    );
    assert_eq!(
        owner.close_exited().unwrap(),
        Settlement::Complete { root_exit: 259 }
    );
    assert_eq!(
        owner.finish(Duration::ZERO).unwrap(),
        Settlement::Complete { root_exit: 259 }
    );
    assert_eq!(
        owner.wait_for_exit(Duration::ZERO).unwrap_err().kind(),
        io::ErrorKind::InvalidInput
    );
    assert!(owner.process_view().is_err());
}

#[test]
fn split_close_refuses_live_root_without_consuming_admission() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 7, "admission-still-owned");
    assert_eq!(
        owner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(
        owner.process_view().unwrap().wait_state().unwrap(),
        RootWait::NotSignaled
    );
    assert!(!f.marker().exists());
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.wait_for_exit(DEADLINE).unwrap(),
        ExitObservation::Exited { root_exit: 7 }
    );
    // Legacy callers keep the existing complete-and-close behavior.
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
    assert!(owner.active_processes().is_err());
}

#[test]
fn split_wait_distinguishes_exited_root_and_live_original_job_member() {
    let f = Fixture::new();
    let mut owner = f.launch("detach", 0, "");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker().with_extension("grandchild"));
    assert_eq!(owner.wait_root(DEADLINE).unwrap(), Some(7));
    assert!(matches!(owner.wait_for_exit(Duration::ZERO).unwrap(),
        ExitObservation::Pending { root_exit: Some(7), active_processes: Some(n) } if n > 0));
    assert_eq!(
        owner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert!(owner.active_processes().unwrap() > 0);
    owner.terminate(82).unwrap();
    assert_eq!(
        owner.wait_for_exit(DEADLINE).unwrap(),
        ExitObservation::Exited { root_exit: 7 }
    );
    assert_eq!(
        owner.active_processes().unwrap(),
        0,
        "exit observation destroyed its Job"
    );
    assert_eq!(
        owner.close_exited().unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

fn wait_member_count(owner: &NativeOwner, expected: u32) {
    let deadline = Instant::now() + DEADLINE;
    loop {
        if owner.active_processes().unwrap() == expected {
            return;
        }
        assert!(
            Instant::now() < deadline,
            "owned Job did not reach the expected active member count"
        );
        thread::sleep(Duration::from_millis(5));
    }
}

#[test]
fn job_members_suspended_root_preserves_identity_and_lifecycle_attempts() {
    let f = Fixture::new();
    let mut owner = f.launch("block", 0, "");
    let pid = owner.root_pid();
    let birth = owner.process_view().unwrap().creation_time_100ns().unwrap();
    let image = owner.process_view().unwrap().image_path().unwrap();
    let sid = owner.process_view().unwrap().token_user_sid().unwrap();
    assert!(owner.job_member_snapshot().is_none());

    let generation = owner
        .observe_job_members(Instant::now() + DEADLINE)
        .unwrap();
    let snapshot = owner.job_member_snapshot().unwrap().clone();
    assert_ne!(generation, 0);
    assert_eq!(snapshot.generation, generation);
    assert!(snapshot.complete);
    let census = snapshot.pre.as_ref().unwrap();
    assert_eq!(census.total_processes, 1);
    assert_eq!(census.active_processes, 1);
    assert_eq!(census.pids, vec![pid]);
    assert_eq!(snapshot.post.as_ref(), Some(census));
    assert_eq!(snapshot.rows.len(), 1);
    let row = &snapshot.rows[0];
    assert_eq!(row.pid, pid);
    assert_eq!(row.creation_time_100ns, birth);
    assert_eq!(row.image_path, image);
    // Never print the machine's actual security identifier on assertion failure.
    assert!(
        !sid.is_empty() && row.token_user_sid == sid,
        "member SID differs from the retained original process"
    );
    assert_eq!(snapshot.resources.len(), 1);
    let resource = &snapshot.resources[0];
    assert_eq!(resource.pid, pid);
    assert!(resource.borrowed_original);
    assert!(!resource.close_attempted && !resource.closed && resource.close_error.is_none());

    assert!(matches!(
        owner.observe_job_members(Instant::now() + DEADLINE),
        Err(JobMemberQueryError::Observation(error)) if error.kind() == io::ErrorKind::WouldBlock
    ));
    let mut admission_called = false;
    assert_eq!(
        owner
            .admit_and_resume(|_| {
                admission_called = true;
                Ok(())
            })
            .unwrap_err()
            .kind(),
        io::ErrorKind::WouldBlock
    );
    assert!(
        !admission_called,
        "an active member observation consumed admission"
    );
    assert_eq!(
        owner.terminate(91).unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(
        owner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(
        owner.finish(Duration::ZERO).unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), None);
    assert_eq!(
        owner.wait_for_exit(Duration::ZERO).unwrap(),
        ExitObservation::Pending {
            root_exit: None,
            active_processes: None,
        }
    );
    assert_eq!(owner.root_exit(), None);
    assert!(
        owner.job_member_snapshot().unwrap() == &snapshot,
        "refused lifecycle operations changed the acquisition baseline"
    );
    assert!(!f.marker().exists(), "member observation resumed the child");

    let closed = owner.close_job_members(generation).unwrap().clone();
    assert_eq!(closed.generation, generation);
    assert!(closed.complete);
    assert_eq!(closed.resources, snapshot.resources);
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    assert_eq!(owner.process_view().unwrap().process_id().unwrap(), pid);
    assert_eq!(
        owner.process_view().unwrap().creation_time_100ns().unwrap(),
        birth
    );
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker());
    // A different code proves the earlier refusal did not consume termination.
    owner.terminate(81).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 81 }
    );
}

#[test]
fn job_members_live_tree_revalidates_the_whole_set_and_closes_only_acquired_handles() {
    let f = Fixture::new();
    let mut owner = f.launch("tree", 0, "");
    let root_pid = owner.root_pid();
    let root_birth = owner.process_view().unwrap().creation_time_100ns().unwrap();
    let image = owner.process_view().unwrap().image_path().unwrap();
    let sid = owner.process_view().unwrap().token_user_sid().unwrap();
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker().with_extension("grandchild"));
    wait_member_count(&owner, 2);

    let generation = owner
        .observe_job_members(Instant::now() + DEADLINE)
        .unwrap();
    let snapshot = owner.job_member_snapshot().unwrap().clone();
    assert!(snapshot.complete);
    assert_eq!(snapshot.generation, generation);
    assert_eq!(snapshot.rows.len(), 2);
    assert_eq!(snapshot.resources.len(), 2);
    let root = snapshot
        .rows
        .iter()
        .find(|row| row.pid == root_pid)
        .unwrap();
    let descendant = snapshot
        .rows
        .iter()
        .find(|row| row.pid != root_pid)
        .unwrap();
    let descendant_pid = descendant.pid;
    assert_ne!(descendant_pid, 0);
    assert_eq!(root.creation_time_100ns, root_birth);
    assert_ne!(descendant.creation_time_100ns, 0);
    for row in &snapshot.rows {
        assert_eq!(row.image_path, image);
        assert!(
            !sid.is_empty() && row.token_user_sid == sid,
            "member SID differs from the fixture's inherited token user"
        );
    }
    // This fixture holds both members alive; equality is not an atomic-census claim.
    let census = snapshot.pre.as_ref().unwrap();
    assert_eq!(census.total_processes, 2);
    assert_eq!(census.active_processes, 2);
    assert_eq!(census.pids.len(), 2);
    assert!(census.pids.contains(&root_pid) && census.pids.contains(&descendant_pid));
    assert_eq!(snapshot.post.as_ref(), Some(census));
    for pid in [root_pid, descendant_pid] {
        let resource = snapshot
            .resources
            .iter()
            .find(|resource| resource.pid == pid)
            .unwrap();
        assert_eq!(resource.borrowed_original, pid == root_pid);
        assert!(!resource.close_attempted && !resource.closed && resource.close_error.is_none());
    }

    for required in [None, Some(root_pid), Some(descendant_pid)] {
        owner
            .revalidate_job_members(generation, Instant::now() + DEADLINE, required)
            .unwrap();
    }
    // The test host is outside this child's exact Job; no unrelated PID is probed.
    for required in [0, std::process::id()] {
        assert!(matches!(
            owner.revalidate_job_members(generation, Instant::now() + DEADLINE, Some(required)),
            Err(JobMemberQueryError::Observation(_))
        ));
    }
    assert!(
        owner.job_member_snapshot().unwrap() == &snapshot,
        "failed Match changed the acquisition baseline"
    );
    owner
        .revalidate_job_members(generation, Instant::now() + DEADLINE, None)
        .unwrap();
    let closed = owner.close_job_members(generation).unwrap().clone();
    assert!(closed.complete);
    assert_eq!(closed.generation, generation);
    assert_eq!(closed.resources.len(), 2);
    for pid in [root_pid, descendant_pid] {
        let resource = closed
            .resources
            .iter()
            .find(|resource| resource.pid == pid)
            .unwrap();
        assert_eq!(resource.borrowed_original, pid == root_pid);
        assert_eq!(resource.close_attempted, pid == descendant_pid);
        assert_eq!(resource.closed, pid == descendant_pid);
        assert!(resource.close_error.is_none());
    }
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    assert_eq!(
        owner.process_view().unwrap().process_id().unwrap(),
        root_pid
    );
    assert_eq!(owner.active_processes().unwrap(), 2);
    owner.terminate(82).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 82 }
    );
}

#[test]
fn job_members_exited_root_keeps_live_descendant_and_original_exit_separate() {
    let f = Fixture::new();
    let mut owner = f.launch("detach", 0, "");
    let root_pid = owner.root_pid();
    let image = owner.process_view().unwrap().image_path().unwrap();
    let sid = owner.process_view().unwrap().token_user_sid().unwrap();
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker().with_extension("grandchild"));
    assert_eq!(owner.wait_root(DEADLINE).unwrap(), Some(7));
    wait_member_count(&owner, 1);

    let generation = owner
        .observe_job_members(Instant::now() + DEADLINE)
        .unwrap();
    let snapshot = owner.job_member_snapshot().unwrap().clone();
    assert!(snapshot.complete);
    assert_eq!(snapshot.generation, generation);
    let census = snapshot.pre.as_ref().unwrap();
    assert_eq!(census.total_processes, 2);
    assert_eq!(census.active_processes, 1);
    assert_eq!(census.pids.len(), 1);
    assert!(!census.pids.contains(&root_pid));
    assert_eq!(snapshot.post.as_ref(), Some(census));
    assert_eq!(snapshot.rows.len(), 1);
    let row = &snapshot.rows[0];
    assert_eq!(census.pids, vec![row.pid]);
    assert_ne!(row.pid, root_pid);
    assert_ne!(row.pid, 0);
    assert_ne!(row.creation_time_100ns, 0);
    assert_eq!(row.image_path, image);
    assert!(
        !sid.is_empty() && row.token_user_sid == sid,
        "live descendant SID differs from the fixture token user"
    );
    assert_eq!(snapshot.resources.len(), 1);
    let resource = &snapshot.resources[0];
    assert_eq!(resource.pid, row.pid);
    assert!(!resource.borrowed_original);
    assert!(!resource.close_attempted && !resource.closed && resource.close_error.is_none());

    owner
        .revalidate_job_members(generation, Instant::now() + DEADLINE, None)
        .unwrap();
    owner
        .revalidate_job_members(generation, Instant::now() + DEADLINE, Some(row.pid))
        .unwrap();
    assert!(matches!(
        owner.revalidate_job_members(generation, Instant::now() + DEADLINE, Some(root_pid)),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), Some(7));
    assert_eq!(
        owner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    let closed = owner.close_job_members(generation).unwrap().clone();
    assert!(closed.complete);
    assert_eq!(closed.resources.len(), 1);
    let resource = &closed.resources[0];
    assert_eq!(resource.pid, row.pid);
    assert!(!resource.borrowed_original);
    assert!(resource.close_attempted && resource.closed && resource.close_error.is_none());
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    assert_eq!(owner.root_exit(), Some(7));
    assert_eq!(owner.active_processes().unwrap(), 1);
    owner.terminate(83).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

#[test]
fn job_members_empty_job_requires_partial_close_before_original_close() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 7, "empty-job");
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.wait_for_exit(DEADLINE).unwrap(),
        ExitObservation::Exited { root_exit: 7 }
    );
    assert!(owner.job_member_snapshot().is_none());
    assert!(matches!(
        owner.observe_job_members(Instant::now() + DEADLINE),
        Err(JobMemberQueryError::Observation(_))
    ));
    let snapshot = owner.job_member_snapshot().unwrap().clone();
    assert_ne!(snapshot.generation, 0);
    assert!(
        !snapshot.complete,
        "an empty Job was admitted as a complete member set"
    );
    let census = snapshot.pre.as_ref().unwrap();
    assert_eq!(census.total_processes, 1);
    assert_eq!(census.active_processes, 0);
    assert!(census.pids.is_empty());
    assert!(snapshot.rows.is_empty() && snapshot.resources.is_empty());

    // Root and Job have exited, so only the still-active partial observation
    // can explain WouldBlock; no original handle may close in this refusal.
    assert_eq!(
        owner.close_exited().unwrap_err().kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), Some(7));
    assert_eq!(owner.active_processes().unwrap(), 0);
    assert!(
        owner.job_member_snapshot().unwrap() == &snapshot,
        "original close refusal rewrote the failed acquisition"
    );
    let closed = owner
        .close_job_members(snapshot.generation)
        .unwrap()
        .clone();
    assert_eq!(closed.generation, snapshot.generation);
    assert!(closed.complete && closed.resources.is_empty());
    assert!(!owner.job_member_snapshot().unwrap().complete);
    assert_eq!(
        owner.close_job_members(snapshot.generation).unwrap(),
        &closed
    );
    assert_eq!(
        owner.close_exited().unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
}

#[test]
fn job_members_expiry_and_stale_generations_cannot_replace_current_observation() {
    let f = Fixture::new();
    let mut owner = f.launch("exit", 0, "after-member-generations");
    assert!(matches!(
        owner.observe_job_members(Instant::now()),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert!(owner.job_member_snapshot().is_none());
    assert!(!f.marker().exists());

    let first = owner
        .observe_job_members(Instant::now() + DEADLINE)
        .unwrap();
    let first_close = owner.close_job_members(first).unwrap().clone();
    assert!(first_close.complete);
    let prior = owner.job_member_snapshot().unwrap().clone();
    assert!(matches!(
        owner.observe_job_members(Instant::now()),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert!(
        owner.job_member_snapshot().unwrap() == &prior,
        "expired acquisition replaced the prior snapshot"
    );
    assert_eq!(owner.close_job_members(first).unwrap(), &first_close);

    let current = owner
        .observe_job_members(Instant::now() + DEADLINE)
        .unwrap();
    assert_eq!(current, first.checked_add(1).unwrap());
    let baseline = owner.job_member_snapshot().unwrap().clone();
    assert_eq!(baseline.generation, current);
    assert!(baseline.complete);
    assert!(matches!(
        owner.revalidate_job_members(first, Instant::now() + DEADLINE, None),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert!(owner.close_job_members(first).is_err());
    assert!(matches!(
        owner.revalidate_job_members(current, Instant::now(), None),
        Err(JobMemberQueryError::Observation(_))
    ));
    assert!(
        owner.job_member_snapshot().unwrap() == &baseline,
        "stale generation or expired validation changed the acquisition baseline"
    );
    owner
        .revalidate_job_members(current, Instant::now() + DEADLINE, Some(owner.root_pid()))
        .unwrap();
    let closed = owner.close_job_members(current).unwrap().clone();
    assert!(closed.complete);
    assert_eq!(closed.generation, current);
    assert_eq!(closed.resources, baseline.resources);
    assert_eq!(owner.close_job_members(current).unwrap(), &closed);
    assert!(
        !f.marker().exists(),
        "generation changes resumed the suspended root"
    );
    owner.admit_and_resume(|_| Ok(())).unwrap();
    assert_eq!(
        owner.finish(DEADLINE).unwrap(),
        Settlement::Complete { root_exit: 0 }
    );
    assert_eq!(
        fs::read_to_string(f.marker()).unwrap(),
        "after-member-generations"
    );
}

#[test]
fn job_members_revalidation_rejects_naturally_exited_retained_descendant() {
    // The existing block fixture exits naturally after ten seconds. Acquisition,
    // revalidation and exit polling share one absolute deadline; the existing
    // readiness helpers retain their separate finite waits.
    let deadline = Instant::now() + Duration::from_secs(13);
    let f = Fixture::new();
    let mut owner = f.launch("detach", 0, "");
    let root_pid = owner.root_pid();
    owner.admit_and_resume(|_| Ok(())).unwrap();
    wait_marker(&f.marker().with_extension("grandchild"));
    assert_eq!(owner.wait_root(DEADLINE).unwrap(), Some(7));
    wait_member_count(&owner, 1);

    let generation = owner.observe_job_members(deadline).unwrap();
    let baseline = owner.job_member_snapshot().unwrap().clone();
    assert!(baseline.complete);
    assert_eq!(baseline.generation, generation);
    assert_eq!(baseline.rows.len(), 1);
    assert_eq!(baseline.resources.len(), 1);
    let descendant_pid = baseline.rows[0].pid;
    assert_ne!(descendant_pid, root_pid);
    assert_ne!(descendant_pid, 0);
    let resource = &baseline.resources[0];
    assert_eq!(resource.pid, descendant_pid);
    assert!(!resource.borrowed_original);
    assert!(!resource.close_attempted && !resource.closed && resource.close_error.is_none());
    let census = baseline.pre.as_ref().unwrap();
    assert_eq!(census.total_processes, 2);
    assert_eq!(census.active_processes, 1);
    assert_eq!(census.pids, vec![descendant_pid]);
    owner
        .revalidate_job_members(generation, deadline, Some(descendant_pid))
        .unwrap();

    // No stop request: the original owner retains the acquired descendant
    // handle while the child reaches its own natural exit.
    loop {
        assert!(
            Instant::now() < deadline,
            "retained descendant did not exit within the shared budget"
        );
        if owner.active_processes().unwrap() == 0 {
            break;
        }
        thread::sleep(
            deadline
                .saturating_duration_since(Instant::now())
                .min(Duration::from_millis(5)),
        );
    }
    for required in [None, Some(descendant_pid)] {
        assert!(
            matches!(
                owner.revalidate_job_members(generation, deadline, required),
                Err(JobMemberQueryError::Observation(error))
                    if error.kind() != io::ErrorKind::TimedOut
            ),
            "exited member must be rejected by observation, not deadline expiry"
        );
    }
    assert!(
        owner.job_member_snapshot().unwrap() == &baseline,
        "failed revalidation replaced or consumed the acquisition baseline"
    );
    assert_eq!(owner.wait_root(Duration::ZERO).unwrap(), Some(7));

    let closed = owner.close_job_members(generation).unwrap().clone();
    assert_eq!(closed.generation, generation);
    assert!(closed.complete);
    assert_eq!(closed.resources.len(), 1);
    let resource = &closed.resources[0];
    assert_eq!(resource.pid, descendant_pid);
    assert!(!resource.borrowed_original);
    assert!(resource.close_attempted && resource.closed && resource.close_error.is_none());
    assert_eq!(owner.close_job_members(generation).unwrap(), &closed);
    assert_eq!(
        owner
            .finish(deadline.saturating_duration_since(Instant::now()))
            .unwrap(),
        Settlement::Complete { root_exit: 7 }
    );
    // On any earlier panic the same owner remains in scope for its existing
    // Job-close/owned-handle Drop fallback; no helper thread or second owner exists.
}
