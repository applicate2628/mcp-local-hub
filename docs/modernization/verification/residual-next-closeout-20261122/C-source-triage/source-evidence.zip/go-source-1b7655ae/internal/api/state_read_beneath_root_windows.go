//go:build windows

package api

import (
	"context"
	"path/filepath"
	"strings"
	"unsafe"

	"golang.org/x/sys/windows"
)

func stateReadOpenCauseIsNotExist(cause error) bool {
	status, direct := cause.(windows.NTStatus)
	return direct && windowsAnchoredReadErrIsNotExist(status)
}

// ReadStateFileBeneathRootNoFollow reads one bounded regular state file through
// a retained no-follow handle chain. The bytes returned are the bytes hashed
// from the final handle; no pathname is reopened after loading.
func ReadStateFileBeneathRootNoFollow(ctx context.Context, root string, relativeComponents []string, expectedSHA256 string) ([]byte, error) {
	return readStateFileBeneathRootNoFollow(ctx, root, relativeComponents, expectedSHA256, nil)
}

// ReadClientConfigBackupBeneathRootNoFollow reads one bounded client-config
// backup through the same retained no-follow handle chain as state files.
// expectedSHA256 is empty only while capturing a fresh forward backup; callers
// restoring a persisted pin must pass its persisted SHA-256.
func ReadClientConfigBackupBeneathRootNoFollow(ctx context.Context, root string, relativeComponents []string, expectedSHA256 string) ([]byte, error) {
	return readStateFileBeneathRootNoFollowWithPolicy(ctx, root, relativeComponents, stateReadBeneathRootPolicy{
		maxBytes: MaxClientConfigBackupBytes, expectedSHA256: expectedSHA256, allowEmptyExpectedSHA256: true,
	}, nil)
}

func readStateFileBeneathRootNoFollow(
	ctx context.Context,
	root string,
	relativeComponents []string,
	expectedSHA256 string,
	step stateReadBeneathRootStepFunc,
) (result []byte, retErr error) {
	return readStateFileBeneathRootNoFollowWithPolicy(ctx, root, relativeComponents, stateReadBeneathRootPolicy{
		maxBytes: maxStateFileBytes, expectedSHA256: expectedSHA256,
	}, step)
}

// Only final stat and close are injected per invocation. The public readers
// always supply the native operations; no process-global hook is retained.
type stateReadBeneathRootNative struct {
	statFinal func(windows.Handle, *windows.ByHandleFileInformation) error
	close     func(windows.Handle) error
}

func readStateFileBeneathRootNoFollowWithPolicy(
	ctx context.Context,
	root string,
	relativeComponents []string,
	policy stateReadBeneathRootPolicy,
	step stateReadBeneathRootStepFunc,
) (result []byte, retErr error) {
	return readStateFileBeneathRootNoFollowWithNative(ctx, root, relativeComponents, policy, step, stateReadBeneathRootNative{
		statFinal: windows.GetFileInformationByHandle, close: windows.CloseHandle,
	})
}

func readStateFileBeneathRootNoFollowWithNative(
	ctx context.Context,
	root string,
	relativeComponents []string,
	policy stateReadBeneathRootPolicy,
	step stateReadBeneathRootStepFunc,
	native stateReadBeneathRootNative,
) (result []byte, retErr error) {
	if err := validateStateReadBeneathRootInputWithPolicy(root, relativeComponents, policy); err != nil {
		return nil, err
	}
	if err := ctx.Err(); err != nil {
		return nil, newStateFileReadError(StateFileReadErrorCanceled, "before-root-open", "", err)
	}
	rootHandle, err := ntOpenStateReadRoot(root)
	if err != nil {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-root", "", err)
	}
	currentHandle := rootHandle
	defer func() {
		result, retErr = completeStateReadClose(result, retErr, "close-parent", "", native.close(currentHandle))
	}()
	if err := refuseReparsePointHandle(rootHandle); err != nil {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-root", "", err)
	}

	for i, component := range relativeComponents[:len(relativeComponents)-1] {
		if err := ctx.Err(); err != nil {
			return nil, newStateFileReadError(StateFileReadErrorCanceled, "before-component-open", component, err)
		}
		if err := invokeStateReadBeneathRootStep(step, stateReadBeneathRootStep{
			Event: stateReadBeneathRootBeforeComponentOpen, ComponentIndex: i, Component: component,
		}); err != nil {
			return nil, err
		}
		nextHandle, openErr := ntOpenStateReadRelative(currentHandle, component, windows.FILE_TRAVERSE|windows.FILE_READ_ATTRIBUTES, true)
		if openErr != nil {
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-component", component, openErr)
		}
		if infoErr := refuseReparsePointHandle(nextHandle); infoErr != nil {
			primary := newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-component", component, infoErr)
			return completeStateReadClose(nil, primary, "close-parent", component, native.close(nextHandle))
		}
		previousHandle := currentHandle
		currentHandle = nextHandle
		if closeErr := native.close(previousHandle); closeErr != nil {
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "close-parent", component, closeErr)
		}
	}
	finalComponent := relativeComponents[len(relativeComponents)-1]
	if err := ctx.Err(); err != nil {
		return nil, newStateFileReadError(StateFileReadErrorCanceled, "before-final-open", finalComponent, err)
	}
	if err := invokeStateReadBeneathRootStep(step, stateReadBeneathRootStep{
		Event: stateReadBeneathRootBeforeComponentOpen, ComponentIndex: len(relativeComponents) - 1, Component: finalComponent,
	}); err != nil {
		return nil, err
	}
	finalHandle, err := ntOpenStateReadRelative(currentHandle, finalComponent, windows.FILE_READ_DATA|windows.FILE_READ_ATTRIBUTES, false)
	if err != nil {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "open-final", finalComponent, err)
	}
	defer func() {
		result, retErr = completeStateReadClose(result, retErr, "close-final", finalComponent, native.close(finalHandle))
	}()
	var info windows.ByHandleFileInformation
	if err := native.statFinal(finalHandle, &info); err != nil {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "stat-final", finalComponent, err)
	}
	if info.FileAttributes&windows.FILE_ATTRIBUTE_REPARSE_POINT != 0 || info.FileAttributes&windows.FILE_ATTRIBUTE_DIRECTORY != 0 {
		return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "stat-final", finalComponent, nil)
	}
	size := int64(info.FileSizeHigh)<<32 | int64(info.FileSizeLow)
	if size > int64(policy.maxBytes) {
		return nil, newStateFileReadError(StateFileReadErrorTooLarge, "stat-final", finalComponent, nil)
	}
	buf := make([]byte, 0, minStateReadCapacity(size, policy.maxBytes))
	chunk := make([]byte, stateReadChunkSize)
	defer zeroStateSecretBytes(chunk)
	for {
		if err := ctx.Err(); err != nil {
			zeroStateSecretBytes(buf)
			return nil, newStateFileReadError(StateFileReadErrorCanceled, "before-read", finalComponent, err)
		}
		requested := stateReadRequestLimitWithCap(len(buf), len(chunk), policy.maxBytes)
		if requested == 0 {
			zeroStateSecretBytes(buf)
			return nil, newStateFileReadError(StateFileReadErrorTooLarge, "before-read", finalComponent, nil)
		}
		if err := invokeStateReadBeneathRootStep(step, stateReadBeneathRootStep{
			Event: stateReadBeneathRootBeforeRead, ComponentIndex: len(relativeComponents) - 1,
			Component: finalComponent, Requested: requested,
		}); err != nil {
			zeroStateSecretBytes(buf)
			return nil, err
		}
		var n uint32
		readErr := windows.ReadFile(finalHandle, chunk[:requested], &n, nil)
		remaining := policy.maxBytes - len(buf)
		if int(n) > remaining {
			zeroStateSecretBytes(buf)
			return nil, newStateFileReadError(StateFileReadErrorTooLarge, "read-final", finalComponent, nil)
		}
		if n > 0 {
			buf = append(buf, chunk[:n]...)
		}
		if readErr != nil {
			if readErr == windows.ERROR_HANDLE_EOF {
				break
			}
			zeroStateSecretBytes(buf)
			return nil, newStateFileReadError(StateFileReadErrorUnsafeObjectOrIO, "read-final", finalComponent, readErr)
		}
		if n == 0 {
			break
		}
	}
	if buf == nil {
		buf = []byte{}
	}
	if policy.expectedSHA256 != "" && !stateReadChecksumMatches(buf, policy.expectedSHA256) {
		zeroStateSecretBytes(buf)
		return nil, newStateFileReadError(StateFileReadErrorChecksumMismatch, "verify-checksum", finalComponent, nil)
	}
	return buf, nil
}

func ntOpenStateReadRelative(parent windows.Handle, name string, desiredAccess uint32, directory bool) (windows.Handle, error) {
	return ntOpenStateReadRelativeMode(parent, name, desiredAccess, &directory, windows.FILE_OPEN, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE, nil)
}

// The owned-tree mode keeps the same anchored NT open and adds explicit
// create/share/type policy; legacy readers retain their original policy.
func ntOpenStateReadRelativeMode(parent windows.Handle, name string, desiredAccess uint32, directory *bool, disposition, share uint32, sd *windows.SECURITY_DESCRIPTOR) (windows.Handle, error) {
	objectName, err := windows.NewNTUnicodeString(name)
	if err != nil {
		return windows.InvalidHandle, err
	}
	oa := &windows.OBJECT_ATTRIBUTES{
		ObjectName: objectName, RootDirectory: parent,
		Attributes: windows.OBJ_CASE_INSENSITIVE | windows.OBJ_DONT_REPARSE,
	}
	if sd != nil {
		oa.SecurityDescriptor = sd
	}
	oa.Length = uint32(unsafe.Sizeof(*oa))
	options := uint32(windows.FILE_SYNCHRONOUS_IO_NONALERT | windows.FILE_OPEN_REPARSE_POINT)
	if directory != nil {
		if *directory {
			options |= windows.FILE_DIRECTORY_FILE
		} else {
			options |= windows.FILE_NON_DIRECTORY_FILE
		}
	}
	var iosb windows.IO_STATUS_BLOCK
	var allocSize int64
	var handle windows.Handle
	if err := windows.NtCreateFile(
		&handle, desiredAccess|windows.SYNCHRONIZE, oa, &iosb, &allocSize,
		windows.FILE_ATTRIBUTE_NORMAL,
		share,
		disposition, options, 0, 0,
	); err != nil {
		return windows.InvalidHandle, err
	}
	return handle, nil
}

func ntOpenStateReadRoot(root string) (windows.Handle, error) {
	return ntOpenStateReadRootMode(root, windows.FILE_TRAVERSE|windows.FILE_READ_ATTRIBUTES, windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE)
}

func ntOpenStateReadRootMode(root string, access, share uint32) (windows.Handle, error) {
	cleanRoot := filepath.Clean(root)
	nativeRoot := `\??\` + cleanRoot
	if strings.HasPrefix(cleanRoot, `\\`) {
		nativeRoot = `\??\UNC\` + strings.TrimPrefix(cleanRoot, `\\`)
	}
	objectName, err := windows.NewNTUnicodeString(nativeRoot)
	if err != nil {
		return windows.InvalidHandle, err
	}
	oa := &windows.OBJECT_ATTRIBUTES{
		ObjectName: objectName,
		Attributes: windows.OBJ_CASE_INSENSITIVE | windows.OBJ_DONT_REPARSE,
	}
	oa.Length = uint32(unsafe.Sizeof(*oa))
	var iosb windows.IO_STATUS_BLOCK
	var allocSize int64
	var handle windows.Handle
	if err := windows.NtCreateFile(
		&handle, access|windows.SYNCHRONIZE, oa, &iosb, &allocSize,
		windows.FILE_ATTRIBUTE_NORMAL,
		share,
		windows.FILE_OPEN,
		windows.FILE_DIRECTORY_FILE|windows.FILE_SYNCHRONOUS_IO_NONALERT|windows.FILE_OPEN_REPARSE_POINT,
		0, 0,
	); err != nil {
		return windows.InvalidHandle, err
	}
	return handle, nil
}
