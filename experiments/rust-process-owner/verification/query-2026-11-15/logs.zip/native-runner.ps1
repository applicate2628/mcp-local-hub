param(
    [Parameter(Mandatory=$true)][string]$Name,
    [Parameter(Mandatory=$true)][string[]]$CargoArguments
)
$ErrorActionPreference = 'Stop'
if ($Name -notmatch '^[a-zA-Z0-9_-]+$') { throw 'Run name must be one path component' }
$taskRoot = 'D:\dev\ChatGPT\mcphub-readonly-identity-20261115'
$crateRoot = 'D:\dev\ChatGPT\mcphub-rust-identity-20261114\source\experiments\rust-process-owner'
$results = Join-Path $taskRoot ('native-evidence\' + $Name)
if (Test-Path -LiteralPath $results) { throw 'Do not overwrite an existing run' }
New-Item -ItemType Directory -Path $results | Out-Null
$env:CARGO_HOME = 'D:\dev\ChatGPT\mcphub-rx02-stdio-20261113\cargo-home'
$env:CARGO_NET_OFFLINE = 'true'
$env:RUSTUP_OFFLINE = '1'
$env:CARGO_TARGET_DIR = Join-Path $taskRoot 'native-target'
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '2'
$env:TEMP = Join-Path $taskRoot 'temp\native'
$env:TMP = $env:TEMP
$env:MCPHUB_RX02_FIXTURES = Join-Path $results 'fixtures'
$env:MCPHUB_RX02_PARENT_SENTINEL = 'owned-test-parent-only-20261113'
New-Item -ItemType Directory -Path $env:TEMP,$env:MCPHUB_RX02_FIXTURES -Force | Out-Null
Set-Location -LiteralPath $crateRoot
$started = [DateTime]::UtcNow.ToString('o')
$sourcePaths = @('src\windows.rs','src\native_failure_tests.rs','tests\lifecycle.rs','Cargo.toml','Cargo.lock')
function Hash-Source([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $hash.Dispose() }
}
$sourceHashes = @($sourcePaths | ForEach-Object {
    [ordered]@{path=$_; sha256=(Hash-Source (Join-Path $crateRoot $_))}
})
$head = (& git rev-parse HEAD) -join ''
$rustVersion = (& rustc --version) -join ''
$cargoVersion = (& cargo --version) -join ''
$ErrorActionPreference = 'Continue'
$output = & cargo @CargoArguments 2>&1
$exitCode = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
$utf8 = New-Object Text.UTF8Encoding($false)
$text = ($output | ForEach-Object { $_.ToString() }) -join "`n"
[IO.File]::WriteAllText((Join-Path $results 'run.log'), $text + "`n", $utf8)
$record = [ordered]@{
    name=$Name; command=@('cargo')+$CargoArguments; exitCode=$exitCode
    startedUtc=$started; finishedUtc=[DateTime]::UtcNow.ToString('o')
    sourceHead=$head; sourceHashes=$sourceHashes
    rustc=$rustVersion; cargo=$cargoVersion
    sourceRoot=$crateRoot; targetRoot=$env:CARGO_TARGET_DIR; tempRoot=$env:TEMP
    cargoHome=$env:CARGO_HOME; offline=$true
}
[IO.File]::WriteAllText((Join-Path $results 'result.json'), (ConvertTo-Json -InputObject $record -Depth 5) + "`n", $utf8)
Write-Output $text
Write-Output ("native step " + $Name + " exit=" + $exitCode)
exit $exitCode
