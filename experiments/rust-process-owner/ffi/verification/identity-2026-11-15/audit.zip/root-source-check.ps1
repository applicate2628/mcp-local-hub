$ErrorActionPreference='Stop'
$repo='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\source'
Set-Location $repo
function Digest([string]$path) {
 $h=[Security.Cryptography.SHA256]::Create()
 try { ([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($path)))).Replace('-','').ToLowerInvariant() } finally { $h.Dispose() }
}
$entries=Get-Content -LiteralPath 'experiments\rust-process-owner\ffi\verification\identity-2026-11-15\source-hashes.json' -Raw | ConvertFrom-Json
$checked=0
foreach($entry in $entries) {
 $path=Join-Path $repo $entry.path
 if((Digest $path) -ne $entry.sha256 -or ([IO.FileInfo]$path).Length -ne $entry.bytes){throw "Source mismatch: $($entry.path)"}
 $qualified=git rev-parse "32812fa5c3793d9af9f3d5770b614f0a96d4d8da:$($entry.path)"
 $current=git rev-parse "HEAD:$($entry.path)"
 if($LASTEXITCODE -ne 0 -or $qualified -ne $current){throw "Commit mismatch: $($entry.path)"}
 $checked++
}
"Qualified runtime inputs verified: $checked"
git diff --exit-code 84119b51e089cce9ca42da2fce35a012eb86cb7c HEAD -- experiments/rust-process-owner/src experiments/rust-process-owner/tests experiments/rust-process-owner/Cargo.toml experiments/rust-process-owner/Cargo.lock
if($LASTEXITCODE -ne 0){throw 'Native parent source changed'}
'Native parent inputs unchanged'
git diff --exit-code 17bc78fc602efa204a74596409c939a3bf1ddc42 HEAD -- internal cmd go.mod go.sum
if($LASTEXITCODE -ne 0){throw 'Product baseline source changed'}
'Product source matches historical accepted master17bc78fc'
git diff --check 84119b51e089cce9ca42da2fce35a012eb86cb7c HEAD
if($LASTEXITCODE -ne 0){throw 'Whitespace errors'}
git ls-remote --heads origin refs/heads/master refs/heads/spike/rx02-native-process-owner-20261112 refs/heads/spike/rx02-native-identity-20261114 refs/heads/spike/rx02-go-rust-boundary-20261113 refs/heads/docs/rust-cross-platform-no-com-20261112
if($LASTEXITCODE -ne 0){throw 'Remote inspection failed'}
