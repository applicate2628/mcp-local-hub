$ErrorActionPreference='Stop'
$audit=$PSScriptRoot
$task='D:\dev\ChatGPT\mcphub-ffi-identity-20261115'
$repo=Join-Path $task 'source'
$published=Join-Path $repo 'experiments\rust-process-owner\ffi\verification\identity-2026-11-15'
function Digest([string]$path) {
 $h=[Security.Cryptography.SHA256]::Create()
 try { ([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($path)))).Replace('-','').ToLowerInvariant() } finally {$h.Dispose()}
}
function Write-JSON([string]$path,$value) {
 [IO.File]::WriteAllText($path,((ConvertTo-Json -InputObject $value -Depth 10)+[char]10),(New-Object Text.UTF8Encoding($false)))
}
$receipt=Get-Content -LiteralPath (Join-Path $audit 'runner-guard.json') -Raw | ConvertFrom-Json
if(@($receipt.cases | Where-Object {$_.oracle -ne 'matched'}).Count -ne 0 -or $receipt.cases.Count -ne 6){throw 'Guard oracles incomplete'}
if((Digest (Join-Path $published 'run.ps1')) -ne $receipt.protectedRunnerSHA256){throw 'Corrected runner changed after checks'}
$oldLine=[IO.File]::ReadAllLines((Join-Path $published 'SHA256SUMS')) | Where-Object {$_ -match '\s+run\.ps1$'}
if(-not $oldLine -or $oldLine.Split(' ')[0] -ne (Digest (Join-Path $audit 'baseline-run.ps1'))){throw 'Baseline runner does not match original published checksum'}
$legacy=Join-Path $repo 'experiments\rust-process-owner\ffi\verification\legacy\history.zip'
if((Digest $legacy) -ne '1df805b8d50ef8e10eaa9404efbee341ba85daeea3c94e3c4a6dd7a572ee342e'){throw 'Legacy archive changed'}
if((Digest (Join-Path $published 'logs.zip')) -ne '191731f1deb99ee39ba1b54b3736b51dcdd02d074d74df480eb6f6bd202d027a'){throw 'Original execution archive changed'}
$active=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith(($task+'\'),[StringComparison]::OrdinalIgnoreCase)})
if($active.Count -ne 0){throw 'Owned executable still active; preserve fixtures'}
$trash='D:\dev\ChatGPT\trash\mcphub-ffi-identity-20261115\runner-guard-2026-11-15'
if(Test-Path -LiteralPath $trash){throw 'Disposition destination already exists'}
[IO.Directory]::CreateDirectory($trash) | Out-Null
$moves=New-Object Collections.Generic.List[object]
foreach($name in @('guard-fixtures','guard-fixtures-run-02')){
 $from=Join-Path $audit $name
 $to=Join-Path $trash $name
 $files=@(Get-ChildItem -LiteralPath $from -Recurse -File | Sort-Object FullName | ForEach-Object {
  [ordered]@{path=$_.FullName.Substring($from.Length+1);bytes=$_.Length;sha256=(Digest $_.FullName)}
 })
 Move-Item -LiteralPath $from -Destination $to
 foreach($file in $files){
  $moved=Join-Path $to $file.path
  if((Digest $moved) -ne $file.sha256 -or (Get-Item -LiteralPath $moved).Length -ne $file.bytes){throw 'Moved guard fixture mismatch'}
 }
 if(Test-Path -LiteralPath $from){throw 'Fixture source remained after move'}
 $moves.Add([ordered]@{source=$from;destination=$to;fileCount=$files.Count;verifiedAfterMove=$true;files=$files})
}
Write-JSON (Join-Path $audit 'guard-disposition.json') ([ordered]@{recordedUtc=[DateTime]::UtcNow.ToString('o');ownedExecutableCount=0;method='direct move to owned trash, no deletion or purge';reason='Only inert completed guard fixtures; scripts/logs/receipts retained outside trash';moves=@($moves.ToArray())})
$records=@(Get-ChildItem -LiteralPath $audit -File | Where-Object {$_.Name -ne 'audit-manifest.json'} | Sort-Object Name | ForEach-Object {
 [ordered]@{path=$_.Name;bytes=$_.Length;sha256=(Digest $_.FullName)}
})
$manifest=[ordered]@{format='exact original bytes, no normalization';manifestSelfExcluded=$true;records=$records}
$manifestPath=Join-Path $audit 'audit-manifest.json'
Write-JSON $manifestPath $manifest
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath=Join-Path $published 'audit.zip'
$stream=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
 $zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try {
  foreach($name in @($records.path)+@('audit-manifest.json')){
   [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $audit $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
  }
 } finally {$zip.Dispose()}
} finally {$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try {
 if($archive.Entries.Count -ne $records.Count+1){throw 'Audit archive entry count mismatch'}
 foreach($record in $records){
  $entry=$archive.GetEntry($record.path)
  if($null -eq $entry -or $entry.Length -ne $record.bytes){throw 'Audit archive length mismatch'}
  $s=$entry.Open();$h=[Security.Cryptography.SHA256]::Create()
  try {$hash=([BitConverter]::ToString($h.ComputeHash($s))).Replace('-','').ToLowerInvariant()} finally {$h.Dispose();$s.Dispose()}
  if($hash -ne $record.sha256){throw 'Audit archive hash mismatch'}
 }
} finally {$archive.Dispose()}
$sums=@(Get-ChildItem -LiteralPath $published -File | Where-Object {$_.Name -ne 'SHA256SUMS'} | Sort-Object Name | ForEach-Object {(Digest $_.FullName)+'  '+$_.Name})
[IO.File]::WriteAllText((Join-Path $published 'SHA256SUMS'),(($sums -join [char]10)+[char]10),(New-Object Text.UTF8Encoding($false)))
Write-Output ('Audit archive entries: '+($records.Count+1))
Write-Output ('Audit archive SHA256: '+(Digest $zipPath))
Write-Output ('Current checksum entries: '+$sums.Count)
Write-Output ('Guard fixture files moved and verified: '+(($moves | ForEach-Object {$_.fileCount} | Measure-Object -Sum).Sum))
'Original archives unchanged; AUDIT_PACKAGE_COMPLETE'
