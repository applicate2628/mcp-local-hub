$ErrorActionPreference='Stop'
$audit=$PSScriptRoot
$fixed='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\source\experiments\rust-process-owner\ffi\verification\identity-2026-11-15\run.ps1'
$baseline=Join-Path $audit 'baseline-run.ps1'
$fixtures=Join-Path $audit 'guard-fixtures'
if(Test-Path -LiteralPath $fixtures){throw 'Guard fixtures already exist; preserve the previous run'}
[IO.Directory]::CreateDirectory($fixtures) | Out-Null
function Write-UTF8([string]$path,[string]$content) {
 [IO.File]::WriteAllText($path,$content,(New-Object Text.UTF8Encoding($false)))
}
function Digest([string]$path) {
 $h=[Security.Cryptography.SHA256]::Create()
 try { ([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($path)))).Replace('-','').ToLowerInvariant() } finally {$h.Dispose()}
}
function Inventory([string]$root) {
 @(Get-ChildItem -LiteralPath $root -Recurse -Force | Sort-Object FullName | ForEach-Object {
  $relative=$_.FullName.Substring($root.Length+1)
  if($_.PSIsContainer){'directory '+$relative}else{'file '+$relative+' '+(Digest $_.FullName)}
 }) -join [char]10
}
function Prepare([string]$name,[string]$occupied) {
 $root=Join-Path $fixtures $name
 foreach($part in @('source\experiments\rust-process-owner\src','source\experiments\rust-process-owner\ffi\src','source\experiments\rust-process-owner\ffi\include','source\experiments\rust-process-owner\ffi\go','target\debug')){
  [IO.Directory]::CreateDirectory((Join-Path $root $part)) | Out-Null
 }
 foreach($part in @('source\experiments\rust-process-owner\Cargo.toml','source\experiments\rust-process-owner\Cargo.lock','source\experiments\rust-process-owner\ffi\Cargo.toml','source\experiments\rust-process-owner\ffi\Cargo.lock','target\debug\owner_child.exe')){
  Write-UTF8 (Join-Path $root $part) 'INERT OWNED GUARD FIXTURE; NEVER EXECUTE'
 }
 if($occupied -eq 'qualification'){
  $output=Join-Path $root 'evidence\qualification'
  [IO.Directory]::CreateDirectory($output) | Out-Null
  Write-UTF8 (Join-Path $output 'source-hashes.json') 'PRESERVE ORIGINAL EVIDENCE'
 }
 if($occupied -eq 'compatibility-source'){
  [IO.Directory]::CreateDirectory((Join-Path $root 'compatibility\source')) | Out-Null
 }
 if($occupied -eq 'compatibility-archive'){
  [IO.Directory]::CreateDirectory((Join-Path $root 'compatibility')) | Out-Null
  Write-UTF8 (Join-Path $root 'compatibility\native.zip') 'PRESERVE ORIGINAL ARCHIVE'
 }
 return $root
}
# Stubs are deliberately confined to this guard harness. No compiler, test suite,
# Git mutation, child fixture or existing execution directory can be invoked.
$script:gitCalls=0;$script:cargoCalls=0
function git {
 $script:gitCalls++
 if($args[0] -ne 'rev-parse'){throw 'Unexpected Git command in guard harness'}
 $global:LASTEXITCODE=0
 'guard-fixture-tree-id'
}
function cargo {
 $script:cargoCalls++
 $global:LASTEXITCODE=97
 'OWNED_GUARD_HARNESS_TOOL_BOUNDARY'
}
$cases=New-Object Collections.Generic.List[object]
foreach($case in @(
 @{name='old-runner-overwrites-evidence';runner=$baseline;occupied='qualification';refuse=$false},
 @{name='fixed-preserves-qualification';runner=$fixed;occupied='qualification';refuse=$true},
 @{name='fixed-preserves-compatibility-source';runner=$fixed;occupied='compatibility-source';refuse=$true},
 @{name='fixed-preserves-compatibility-archive';runner=$fixed;occupied='compatibility-archive';refuse=$true},
 @{name='fixed-accepts-new-output';runner=$fixed;occupied='';refuse=$false}
)){
 $root=Prepare $case.name $case.occupied
 $before=Inventory $root
 $script:gitCalls=0;$script:cargoCalls=0
 $failure=''
 try { & $case.runner -TaskRoot $root *> (Join-Path $audit ($case.name+'.log')) } catch {$failure=$_.Exception.Message}
 Set-Location $audit
 $after=Inventory $root
 $unchanged=$before -ceq $after
 if($case.refuse){
  if($failure -notlike 'Qualification output already exists;*' -or -not $unchanged -or $script:gitCalls -ne 0 -or $script:cargoCalls -ne 0){throw "Occupied-root refusal failed: $($case.name): $failure"}
 } else {
  if($failure -notlike 'rust-fmt failed: 97*' -or $script:cargoCalls -ne 1){throw "Guard did not reach isolated tool boundary: $($case.name): $failure"}
  if($case.occupied -eq 'qualification' -and $unchanged){throw 'Old-runner negative control did not expose overwrite'}
 }
 $cases.Add([ordered]@{name=$case.name;oracle='matched';existingFilesAndDirectoriesUnchanged=$unchanged;gitStubCalls=$script:gitCalls;cargoStubCalls=$script:cargoCalls;observedFailure=$failure})
 Write-Output ($case.name+': intended oracle matched')
}
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($fixed,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count -ne 0){throw 'Fixed runner has syntax errors'}
$parameter=$ast.ParamBlock.Parameters | Where-Object {$_.Name.VariablePath.UserPath -eq 'TaskRoot'}
if($parameter.Extent.Text -notmatch 'Mandatory\s*=\s*\$true'){throw 'TaskRoot is not mandatory'}
# Noninteractive parameter binding must refuse before executing the script body.
$bindingRoot=Join-Path $fixtures 'missing-parameter'
[IO.Directory]::CreateDirectory($bindingRoot) | Out-Null
Set-Location $bindingRoot
$oldPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
& powershell.exe -NoProfile -NonInteractive -File $fixed *> (Join-Path $audit 'missing-parameter.log')
$bindingCode=$LASTEXITCODE;$ErrorActionPreference=$oldPreference
Set-Location $audit
if($bindingCode -eq 0 -or @(Get-ChildItem -LiteralPath $bindingRoot -Force).Count -ne 0 -or [IO.File]::ReadAllText((Join-Path $audit 'missing-parameter.log')) -notmatch 'TaskRoot'){throw 'Missing mandatory TaskRoot did not refuse safely'}
$cases.Add([ordered]@{name='fixed-requires-explicit-task-root';oracle='matched';exitCode=$bindingCode;createdFiles=0})
$receipt=[ordered]@{
 recordedUtc=[DateTime]::UtcNow.ToString('o')
 baselineCommit='10f011453239b26076d60609b2c9a68621185fdb'
 baselineRunnerSHA256=(Digest $baseline)
 protectedRunnerSHA256=(Digest $fixed)
 harnessSHA256=(Digest $PSCommandPath)
 syntaxErrors=0
 realCompilerOrSuiteExecuted=$false
 cases=@($cases.ToArray())
}
Write-UTF8 (Join-Path $audit 'runner-guard.json') ((ConvertTo-Json -InputObject $receipt -Depth 6)+[char]10)
'GUARD_REVIEW_COMPLETE'
