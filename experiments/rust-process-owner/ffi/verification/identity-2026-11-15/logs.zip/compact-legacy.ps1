$ErrorActionPreference='Stop'
$taskRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115'
$sourceRoot=Join-Path $taskRoot 'source'
$package=Join-Path $taskRoot 'evidence\legacy-ffi-history'
$prefix='experiments/rust-process-owner/ffi/verification/'
$original=Join-Path $sourceRoot $prefix
$staged=Join-Path $taskRoot 'evidence\verification-staged'
$trash='D:\dev\ChatGPT\trash\mcphub-ffi-identity-20261115\legacy-verification'
function Digest([string]$Path){
 $h=[Security.Cryptography.SHA256]::Create()
 try{([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($Path)))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}
}
$zipPath=Join-Path $package 'history.zip'
if((Digest $zipPath) -ne '1df805b8d50ef8e10eaa9404efbee341ba85daeea3c94e3c4a6dd7a572ee342e'){throw 'Archive SHA256 mismatch'}
if((Digest (Join-Path $package 'manifest.tsv')) -ne '8d2d16d99c43e33590cadb9c387c5e9f95c1dd354efedd9299243edd46eb8bda'){throw 'Manifest SHA256 mismatch'}
Set-Location $sourceRoot
$dirty=@(& git status --porcelain -- $prefix)
if($LASTEXITCODE -ne 0 -or $dirty.Count -ne 0){throw 'Historical working files are not clean'}
$tree=@(& git ls-tree -r --full-tree 'eb4ca1d40244ba1915638b76c3e30b2a684d9b07' -- $prefix)
if($LASTEXITCODE -ne 0){throw 'Git tree unavailable'}
$expected=@{}
foreach($line in $tree){if($line -notmatch '^(\d+) blob ([0-9a-f]{40})\t(.+)$'){throw 'Unexpected Git tree entry'};$expected[$Matches[3]]=$Matches[2]}
$manifest=@{}
foreach($entry in (Import-Csv (Join-Path $package 'manifest.tsv') -Delimiter ([char]9))){$manifest[$entry.path]=$entry}
if($expected.Count -ne 624 -or $manifest.Count -ne 624){throw 'Unexpected historical file count'}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
$sha1=[Security.Cryptography.SHA1]::Create();$sha256=[Security.Cryptography.SHA256]::Create()
$seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$count=0;$bytes=0
try{
 foreach($entry in $zip.Entries){
  if($entry.FullName.EndsWith('/')){continue}
  $name=$entry.FullName
  if(!$name.StartsWith($prefix) -or $name -match '(^/|\\|:|(^|/)\.\.(/|$))' -or !$seen.Add($name)){throw 'Unsafe or duplicate archive name'}
  if(!$expected.ContainsKey($name) -or !$manifest.ContainsKey($name)){throw 'Extra archive member'}
  $stream=$entry.Open();$buffer=New-Object IO.MemoryStream
  try{$stream.CopyTo($buffer);$raw=$buffer.ToArray()}finally{$stream.Dispose();$buffer.Dispose()}
  $header=[Text.Encoding]::UTF8.GetBytes(('blob '+$raw.Length+[char]0))
  $combined=New-Object byte[] ($header.Length+$raw.Length)
  [Array]::Copy($header,0,$combined,0,$header.Length);[Array]::Copy($raw,0,$combined,$header.Length,$raw.Length)
  $blob=([BitConverter]::ToString($sha1.ComputeHash($combined))).Replace('-','').ToLowerInvariant()
  $hash=([BitConverter]::ToString($sha256.ComputeHash($raw))).Replace('-','').ToLowerInvariant()
  $m=$manifest[$name]
  if($blob -ne $expected[$name] -or $blob -ne $m.git_blob_sha1 -or $hash -ne $m.sha256 -or $raw.Length -ne [long]$m.bytes){throw "Historical byte mismatch: $name"}
  $count++;$bytes+=$raw.Length
 }
}finally{$zip.Dispose();$sha1.Dispose();$sha256.Dispose()}
if($count -ne 624 -or $bytes -ne 2364014){throw 'Incomplete historical archive'}
if((Test-Path $staged) -or (Test-Path $trash)){throw 'Staging/trash destination must be new'}
[IO.Directory]::CreateDirectory((Join-Path $staged 'legacy'))|Out-Null
foreach($name in @('history.zip','manifest.tsv','receipt.json','SHA256SUMS')){
 $destination=Join-Path $staged ('legacy\'+$name)
 Copy-Item -LiteralPath (Join-Path $package $name) -Destination $destination
 if((Digest $destination) -ne (Digest (Join-Path $package $name))){throw 'Package copy mismatch'}
}
Copy-Item -LiteralPath (Join-Path $taskRoot 'evidence\verification-index.md') -Destination (Join-Path $staged 'README.md')
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($trash))|Out-Null
Move-Item -LiteralPath $original.TrimEnd('\','/') -Destination $trash
Move-Item -LiteralPath $staged -Destination $original.TrimEnd('\','/')
$receipt=[ordered]@{
 schema=1;recordedUtc=[DateTime]::UtcNow.ToString('o');sourceCommit='eb4ca1d40244ba1915638b76c3e30b2a684d9b07'
 independentlyRecheckedFiles=$count;uncompressedBytes=$bytes
 validation='Every ZIP file compared with immutable Git blob SHA1 plus independent SHA256/length manifest; no extraction'
 packageCopiesVerified=$true;historicalWorkingTreeWasClean=$true
 disposableOriginalCheckoutMovedTo=$trash;archivePreservedAt=(Join-Path $original 'legacy\history.zip')
 permanentDeletionPerformed=$false
}
$json=ConvertTo-Json -InputObject $receipt -Depth 5
[IO.File]::WriteAllText((Join-Path $original 'legacy\compaction.json'),($json -replace '\r\n',[string][char]10)+[char]10,(New-Object Text.UTF8Encoding($false)))
Write-Output "Verified $count files / $bytes bytes; archive preserved; old clean evidence moved directly to trash"
