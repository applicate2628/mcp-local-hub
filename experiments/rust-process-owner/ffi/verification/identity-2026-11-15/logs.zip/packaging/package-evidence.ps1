[CmdletBinding()]
param([string]$TaskRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Utf8=New-Object Text.UTF8Encoding($false,$true)
$Lf=[string][char]10
$TaskRoot=[IO.Path]::GetFullPath($TaskRoot).TrimEnd('\')
if(!$TaskRoot.StartsWith('D:\dev\ChatGPT\',[StringComparison]::OrdinalIgnoreCase)){throw 'Outside authorized work area'}
$Evidence=Join-Path $TaskRoot 'evidence'
$Source=Join-Path $TaskRoot 'source'
$Public=Join-Path $Source 'experiments\rust-process-owner\ffi\verification\identity-2026-11-15'
$Private=Join-Path $Evidence ('packaging\'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))
[void][IO.Directory]::CreateDirectory($Private)
if(!(Test-Path -LiteralPath $Public -PathType Container)){throw 'Publication directory must already exist'}
$SourceCommit='32812fa5c3793d9af9f3d5770b614f0a96d4d8da'
$OverlayBase='aa7f4ea41631cbb29bd86b9e3c8c149e4a9f7675'
$Master='17bc78fc602efa204a74596409c939a3bf1ddc42'
$Controls=Join-Path $Evidence 'controls\runs\20261114T2146053593724Z'

function Hash-Bytes([byte[]]$Bytes){
 $h=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($h.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}
}
function Hash-File([string]$Path){return Hash-Bytes ([IO.File]::ReadAllBytes($Path))}
function Write-Json([string]$Path,$Value){
 $text=(ConvertTo-Json -InputObject $Value -Depth 20).Replace([string][char]13,'')+$Lf
 [IO.File]::WriteAllText($Path,$text,$Utf8)
}
function Git-Read([string[]]$Arguments){
 Push-Location -LiteralPath $Source
 try{
  $prior=$ErrorActionPreference;$ErrorActionPreference='Continue'
  $lines=@(& git @Arguments 2>&1);$code=$LASTEXITCODE
  $ErrorActionPreference=$prior
  if($code -ne 0){throw ('Read-only git command failed: '+($Arguments -join ' '))}
  return (($lines|ForEach-Object{$_.ToString()}) -join $Lf).Trim()
 }finally{Pop-Location}
}
function Test-Log-Summary([string]$Path){
 $counts=[ordered]@{jsonEvents=0;nonJsonLines=0;nonGoJsonLines=0;testRun=0;testPass=0;testFail=0;testSkip=0;topLevelRun=0;topLevelPass=0;topLevelFail=0;topLevelSkip=0;nestedRun=0;nestedPass=0;nestedFail=0;nestedSkip=0;packageStart=0;packagePass=0;packageFail=0;packageSkip=0}
 $started=@{};$ended=@{};$failedTests=@{};$failedPackages=@{}
 $timeouts=New-Object 'System.Collections.Generic.List[object]'
 $timeoutNames=New-Object 'System.Collections.Generic.HashSet[string]'
 $capture=0;$lineNumber=0;$timeoutCount=0
 $reader=New-Object IO.StreamReader($Path,$Utf8,$true)
 try{
  while(($line=$reader.ReadLine()) -ne $null){
   $lineNumber++
   if(!$line.TrimStart().StartsWith('{')){$counts.nonJsonLines++;continue}
   try{$event=ConvertFrom-Json -InputObject $line -ErrorAction Stop}catch{$counts.nonJsonLines++;continue}
   if($null -eq $event.PSObject.Properties['Action']){$counts.nonGoJsonLines++;continue}
   $counts.jsonEvents++
   $action=[string]$event.Action
   $package=if($null -ne $event.PSObject.Properties['Package']){[string]$event.Package}else{''}
   $test=if($null -ne $event.PSObject.Properties['Test']){[string]$event.Test}else{''}
   if($test -ne ''){
    $key=$package+[char]9+$test
    $item=[ordered]@{package=$package;test=$test}
    if($action -eq 'run'){$started[$key]=$item}
    if($action -in @('pass','fail','skip')){$ended[$key]=$true}
    if($action -eq 'fail'){$failedTests[$key]=$item}
    if($action -in @('run','pass','fail','skip')){
     $suffix=(Get-Culture).TextInfo.ToTitleCase($action)
     $counts['test'+$suffix]++
     $level=if($test.Contains('/')){'nested'}else{'topLevel'}
     $counts[$level+$suffix]++
    }
   }elseif($action -in @('start','pass','fail','skip')){
    $suffix=(Get-Culture).TextInfo.ToTitleCase($action)
    $counts['package'+$suffix]++
    if($action -eq 'fail'){$failedPackages[$package]=$true}
   }
   if($null -ne $event.PSObject.Properties['Output']){
    $output=[string]$event.Output
    foreach($marker in [regex]::Matches($output,'(?m)^\s*--- FAIL:\s+([^\r\n]+?)\s+\([0-9.]+s\)')){
     $name=$marker.Groups[1].Value
     $failedTests[$package+[char]9+$name]=[ordered]@{package=$package;test=$name}
    }
    if($output -match 'panic: test timed out'){$timeoutCount++;$capture=10}
    if($capture -gt 0){
     foreach($part in ($output -split '\r?\n')){
      if($part -eq ''){continue}
      if($part -match '^\s*goroutine\s+\d+'){$capture=0;break}
      if($timeouts.Count -lt 40){[void]$timeouts.Add([ordered]@{line=$lineNumber;package=$package;text=$part})}
      if($part -match '^\s*(Test\S+)\s+\([^)]*\)\s*$'){[void]$timeoutNames.Add($Matches[1])}
     }
     $capture--
    }
   }
  }
 }finally{$reader.Dispose()}
 $incomplete=@($started.Keys|Where-Object{!$ended.ContainsKey($_)}|Sort-Object|ForEach-Object{$started[$_]})
 return [ordered]@{
  counts=$counts;failedTests=@($failedTests.Keys|Sort-Object|ForEach-Object{$failedTests[$_]})
  failedPackages=@($failedPackages.Keys|Sort-Object)
  startedTestsWithoutTerminalEvent=$incomplete
  timeoutCount=$timeoutCount;namedRunningTestsAtTimeout=@($timeoutNames|Sort-Object)
  timeoutExcerpts=@($timeouts.ToArray());timeoutExcerptMaximumLines=40
  interpretation='Counts are emitted Go JSON events; nested test counts are separate. A timeout can leave started tests without terminal events; these are listed separately, not silently counted as passing or as individual fail events.'
 }
}
$stepsPath=Join-Path $Evidence 'repository-gates\steps.json'
$steps=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($stepsPath))
if($steps.Count -ne 4){throw 'Expected exactly four finished repository gates'}
$expected=@{build=0;vet=0;test=1;'state-tag'=1}
$gateResults=New-Object 'System.Collections.Generic.List[object]'
foreach($step in $steps){
 if(!$expected.ContainsKey($step.name) -or $step.exitCode -ne $expected[$step.name]){throw 'Repository gate observation differs from reviewed outcome'}
 $log=Join-Path (Join-Path $Evidence 'repository-gates') $step.log
 $summary=if($step.name -in @('test','state-tag')){Test-Log-Summary $log}else{$null}
 [void]$gateResults.Add([ordered]@{
  name=$step.name;program=$step.program;arguments=$step.arguments;exitCode=$step.exitCode
  startedUtc=$step.startedUtc;finishedUtc=$step.finishedUtc;log=('repository-gates/'+$step.log)
  originalLogSHA256=(Hash-File $log);originalLogBytes=(Get-Item -LiteralPath $log).Length
  passed=($step.exitCode -eq 0);jsonSummary=$summary
 })
 Write-Output ('Summarized repository gate '+$step.name)
}
$treeProof=New-Object 'System.Collections.Generic.List[object]'
foreach($path in @('internal','cmd','go.mod','go.sum')){
 $masterObject=Git-Read @('rev-parse',($Master+':'+$path))
 $overlayObject=Git-Read @('rev-parse',($OverlayBase+':'+$path))
 $sourceObject=Git-Read @('rev-parse',($SourceCommit+':'+$path))
 if($masterObject -ne $overlayObject -or $masterObject -ne $sourceObject){throw ('Core tree differs: '+$path)}
 [void]$treeProof.Add([ordered]@{path=$path;masterObject=$masterObject;qualifiedOverlayBaseObject=$overlayObject;sourceCommitObject=$sourceObject;identical=$true})
}
$workingChanges=Git-Read @('status','--porcelain','--','internal','cmd','go.mod','go.sum')
if($workingChanges -ne ''){throw 'Core working tree changed while packaging'}
$runtimeHashes=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $Evidence 'qualification\source-hashes.json')))
if($runtimeHashes.Count -ne 38){throw 'Expected exact 38-file runtime overlay manifest'}
foreach($entry in $runtimeHashes){
 if((Hash-File (Join-Path $Source $entry.path)) -ne $entry.sha256){throw ('Qualified runtime overlay changed: '+$entry.path)}
}
$repoSummary=[ordered]@{
 schema=1;recordedUtc=[DateTime]::UtcNow.ToString('o')
 gateStatus='BLOCKED';allMandatoryGatesPassed=$false
 collectorExitCode=0;collectorExitMeaning='The collector recorded all outcomes. Its exit code 0 is not passing repository gates.'
 publicationStatus='BLOCKED by CLAUDE.md pre-push hard gate unless the user grants an explicit draft-only exception.'
 sourceCommit=$SourceCommit;executedQualifiedOverlayBase=$OverlayBase
 sourceIdentity='Execution used the dirty 38-file runtime overlay over aa7f4ea. The current source commit contains the same 38 bytes-hashed inputs; no clean future head execution is claimed.'
 qualifiedRuntimeFiles=38;qualifiedRuntimeFilesUnchanged=$true
 masterCommit=$Master;coreTreeEquality=@($treeProof.ToArray());coreWorkingTreeChanges=$workingChanges
 equalityLimit='Object equality localizes the broad failing tests to unchanged core sources. It does not prove those failures are harmless, diagnose their causes, or waive the mandatory gate.'
 stepsOriginalSHA256=(Hash-File $stepsPath);gates=@($gateResults.ToArray())
}
$summaryPath=Join-Path $Private 'repository-gates-original.json'
Write-Json $summaryPath $repoSummary

$Inputs=New-Object 'System.Collections.Generic.List[object]'
function Add-Input([string]$Path,[string]$Entry,[string]$Loose=''){
 if(!(Test-Path -LiteralPath $Path -PathType Leaf)){throw ('Missing package input: '+$Path)}
 [void]$Inputs.Add([pscustomobject]@{Source=$Path;Entry=$Entry;Loose=$Loose})
}
function Add-Directory([string]$Name,[string]$Prefix){
 foreach($item in @(Get-ChildItem -LiteralPath (Join-Path $Evidence $Name) -File|Sort-Object Name)){
  if($item.Extension -notin @('.log','.json','.jsonl','.ps1','.md','.txt')){throw ('Unexpected artifact type: '+$item.FullName)}
  Add-Input $item.FullName ($Prefix+'/'+$item.Name)
 }
}
Add-Directory 'focused' 'focused'
Add-Input (Join-Path $Evidence 'focused.ps1') 'focused/runner.ps1'
Add-Directory 'qualification' 'qualification'
Add-Input (Join-Path $Evidence 'qualify.ps1') 'qualification/runner.ps1' 'run.ps1'
Add-Directory 'qualification-attempt-01' 'qualification-attempt-01'
foreach($item in @(Get-ChildItem -LiteralPath $Controls -File|Sort-Object Name)){
 if($item.Extension -notin @('.log','.json','.jsonl')){throw ('Unexpected control artifact: '+$item.FullName)}
 Add-Input $item.FullName ('controls/'+$item.Name)
}
Add-Input (Join-Path $Evidence 'controls\run-controls.ps1') 'controls/runner.ps1' 'controls.ps1'
Add-Directory 'repository-gates' 'repository-gates'
Add-Input (Join-Path $Evidence 'repository-gates.ps1') 'repository-gates/runner.ps1' 'repository-gates.ps1'
Add-Directory 'repository-gates-attempt-01' 'repository-gates-attempt-01'
Add-Input (Join-Path $Evidence 'pr-audit.json') 'pr-audit.json' 'pr-audit.json'
Add-Input (Join-Path $Evidence 'previous-pr-metadata.json') 'previous-pr-metadata.json'
Add-Input (Join-Path $Evidence 'compact-legacy.ps1') 'compact-legacy.ps1'
Add-Input $summaryPath 'repository-gates/summary.json' 'repository-gates.json'
Add-Input $PSCommandPath 'packaging/package-evidence.ps1'
$looseMappings=@{
 'qualification/steps.json'='qualification.json'
 'qualification/source-identity.json'='source-identity.json'
 'qualification/source-hashes.json'='source-hashes.json'
 'qualification/artifacts.json'='artifacts.json'
 'controls/cases.json'='controls.json'
}
foreach($sourceItem in $Inputs){if($looseMappings.ContainsKey($sourceItem.Entry)){$sourceItem.Loose=$looseMappings[$sourceItem.Entry]}}

# Apply one privacy/encoding transformation to every archive and loose copy.
# Original logs/scripts stay untouched; their hashes remain explicit.
$sidPattern=New-Object Text.RegularExpressions.Regex('\bS-1-\d+(?:-\d+)+\b')
$profilePattern=New-Object Text.RegularExpressions.Regex('(?i)(?<prefix>\bC:(?:\\+|/)Users(?:\\+|/))[^\\/\s"''<>]+')
$Manifest=New-Object 'System.Collections.Generic.List[object]'
$Contents=@{}
$Names=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$LooseNames=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach($sourceItem in $Inputs){
 $entry=$sourceItem.Entry
 if($entry.StartsWith('/') -or $entry.Contains('\') -or $entry.Contains(':') -or $entry.IndexOf([char]0) -ge 0){throw ('Unsafe entry: '+$entry)}
 foreach($part in $entry.Split('/')){
  if($part -in @('','.','..') -or $part.TrimEnd(' ','.') -ne $part -or $part -match '(?i)^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$'){throw ('Unsafe entry component: '+$entry)}
 }
 if(!$Names.Add($entry)){throw ('Duplicate entry: '+$entry)}
 $original=[IO.File]::ReadAllBytes($sourceItem.Source)
 $text=[IO.File]::ReadAllText($sourceItem.Source,$Utf8)
 $sidCount=$sidPattern.Matches($text).Count
 $profileCount=$profilePattern.Matches($text).Count
 $published=$sidPattern.Replace($text,'<SID-REDACTED>')
 $published=$profilePattern.Replace($published,('$'+'{prefix}<USER-REDACTED>'))
 $published=$published.Replace(([string][char]13+[char]10),$Lf).Replace([string][char]13,$Lf)
 if($sidPattern.IsMatch($published) -or $profilePattern.IsMatch($published)){throw ('Residual private identifier in '+$entry)}
 $bytes=$Utf8.GetBytes($published)
 $Contents[$entry]=$bytes
 if($sourceItem.Loose -ne ''){
  if(!$LooseNames.Add($sourceItem.Loose)){throw ('Duplicate loose artifact: '+$sourceItem.Loose)}
  [IO.File]::WriteAllBytes((Join-Path $Private $sourceItem.Loose),$bytes)
 }
 $originalHash=Hash-Bytes $original
 $publishedHash=Hash-Bytes $bytes
 [void]$Manifest.Add([ordered]@{
  entry=$entry;source=$sourceItem.Source;looseFile=$sourceItem.Loose
  originalBytes=$original.Length;originalSHA256=$originalHash
  publishedBytes=$bytes.Length;publishedSHA256=$publishedHash
  sidRedactions=$sidCount;userProfileRedactions=$profileCount
  byteIdentical=($original.Length -eq $bytes.Length -and $originalHash -eq $publishedHash)
 })
}
$zipPath=Join-Path $Private 'logs.zip'
$zip=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($entry in @($Contents.Keys|Sort-Object)){
  $item=$zip.CreateEntry($entry,[IO.Compression.CompressionLevel]::Optimal)
  $stream=$item.Open()
  try{$bytes=[byte[]]$Contents[$entry];$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
 }
}finally{$zip.Dispose()}
$read=[IO.Compression.ZipFile]::OpenRead($zipPath)
$verified=0
try{
 if($read.Entries.Count -ne $Manifest.Count){throw 'ZIP entry count mismatch'}
 $readNames=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($entry in $read.Entries){
  if(!$readNames.Add($entry.FullName) -or !$Contents.ContainsKey($entry.FullName)){throw 'Unexpected/duplicate ZIP readback entry'}
  $stream=$entry.Open();$memory=New-Object IO.MemoryStream
  try{$stream.CopyTo($memory);$bytes=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}
  $expected=[byte[]]$Contents[$entry.FullName]
  if($bytes.Length -ne $expected.Length -or (Hash-Bytes $bytes) -ne (Hash-Bytes $expected)){throw ('ZIP readback mismatch: '+$entry.FullName)}
  $verified++
 }
}finally{$read.Dispose()}
$manifestPath=Join-Path $Private 'log-manifest.json'
$totalSid=0;$totalProfile=0
foreach($record in $Manifest){$totalSid += [int]$record['sidRedactions'];$totalProfile += [int]$record['userProfileRedactions']}
$manifestData=[ordered]@{
 schema=1;createdUtc=[DateTime]::UtcNow.ToString('o')
 normalization='UTF-8 without BOM; CRLF and CR normalized to LF; no original evidence modified.'
 redaction='All textual S-1 numeric SID patterns and C:\Users\<name> prefixes, including slash and JSON-escaped variants, are replaced in publication copies.'
 embeddedHashMeaning='Hashes inside captured runner JSON records remain original execution hashes. Per-entry original/published hashes below explicitly map normalization/redaction changes.'
 entries=@($Manifest.ToArray());entryCount=$Manifest.Count
 zip=@{file='logs.zip';bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Hash-File $zipPath);readBackEntries=$verified;safeUniqueNames=$true;allReadBackHashesMatched=$true}
 sidRedactions=$totalSid
 userProfileRedactions=$totalProfile
 excluded='DLLs, executables, targets, copied source trees, caches and private binary SID fixtures.'
 sourceCommit=$SourceCommit;executedQualifiedOverlayBase=$OverlayBase
}
Write-Json $manifestPath $manifestData
$deliverables=@($LooseNames)+@('logs.zip','log-manifest.json')
foreach($file in $deliverables){
 if(Test-Path -LiteralPath (Join-Path $Public $file)){throw ('Refusing to overwrite existing public artifact: '+$file)}
}
foreach($file in $deliverables){[IO.File]::Copy((Join-Path $Private $file),(Join-Path $Public $file),$false)}
$receipt=[ordered]@{
 publicationDirectory=$Public;privatePackage=$Private;files=$deliverables.Count;zipEntries=$Manifest.Count
 zipBytes=(Get-Item -LiteralPath $zipPath).Length;zipSHA256=(Hash-File $zipPath)
 manifestSHA256=(Hash-File $manifestPath);sidRedactions=$manifestData.sidRedactions;userProfileRedactions=$manifestData.userProfileRedactions
 repositoryGates='BLOCKED';qualifiedRuntimeFilesVerified=38
}
Write-Json (Join-Path $Private 'package-receipt.json') $receipt
Write-Output (ConvertTo-Json -InputObject $receipt -Depth 5)
