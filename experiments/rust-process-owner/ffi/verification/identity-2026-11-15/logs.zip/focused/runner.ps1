$ErrorActionPreference='Stop'
$taskRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115'
$sourceRoot=Join-Path $taskRoot 'source'
$native=Join-Path $sourceRoot 'experiments\rust-process-owner'
$ffi=Join-Path $native 'ffi'
$logRoot=Join-Path $taskRoot 'evidence\focused'
@('tmp','target','go-cache','go-mod-cache','go-path','tmp\identity-focused','evidence\focused') | ForEach-Object { [IO.Directory]::CreateDirectory((Join-Path $taskRoot $_)) | Out-Null }
$env:TEMP=Join-Path $taskRoot 'tmp'; $env:TMP=$env:TEMP; $env:GOTMPDIR=$env:TEMP
$env:CARGO_HOME='D:\dev\ChatGPT\mcphub-rx02-stdio-20261113\cargo-home'
$env:CARGO_TARGET_DIR=Join-Path $taskRoot 'target'; $env:CARGO_NET_OFFLINE='true'; $env:RUSTUP_OFFLINE='1'
$env:GOCACHE=Join-Path $taskRoot 'go-cache'; $env:GOMODCACHE=Join-Path $taskRoot 'go-mod-cache'; $env:GOPATH=Join-Path $taskRoot 'go-path'
$env:GOTOOLCHAIN='local'; $env:GOPROXY='off'; $env:GOSUMDB='off'; $env:GOTELEMETRY='off'; $env:CGO_ENABLED='1'; $env:CC='c:\msys64\ucrt64\bin\gcc.exe'
$env:MCPHUB_RX02_FFI_DLL=Join-Path $env:CARGO_TARGET_DIR 'debug\mcphub_owner_ffi_spike.dll'
$env:MCPHUB_RX02_FFI_CHILD=Join-Path $env:CARGO_TARGET_DIR 'debug\owner_child.exe'
$env:MCPHUB_RX02_IDENTITY_FIXTURES=Join-Path $taskRoot 'tmp\identity-focused'
function Step([string]$Name,[string]$Program,[string[]]$Arguments){
 $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
 & $Program @Arguments 2>&1 | Out-File -Encoding utf8 (Join-Path $logRoot ($Name+'.log'))
 $code=$LASTEXITCODE; $ErrorActionPreference=$old
 Write-Output "$Name exit=$code"
 if($code -ne 0){Get-Content (Join-Path $logRoot ($Name+'.log')) -Tail 90; throw "$Name failed: $code"}
}
Set-Location $ffi
Step 'format-rust' 'cargo' @('fmt','--manifest-path',(Join-Path $ffi 'Cargo.toml'))
Set-Location (Join-Path $ffi 'go')
Step 'format-go' 'gofmt' @('-w','bridge_windows.go','identity_windows.go','identity_windows_test.go','identity_legacy_windows_test.go','identity_faults_windows_test.go')
Set-Location $native
Step 'build-child' 'cargo' @('build','--offline','--locked','--bin','owner_child')
Set-Location $ffi
Step 'test-ffi' 'cargo' @('test','--offline','--locked','--','--test-threads=1')
Step 'build-ffi' 'cargo' @('build','--offline','--locked')
Set-Location (Join-Path $ffi 'go')
Step 'test-identity-race' 'go' @('test','-v','-race','-count=1','-timeout=90s','-run','^TestIdentity','.')
Write-Output 'FOCUSED_COMPLETE'
