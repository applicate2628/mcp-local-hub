$ErrorActionPreference='Stop'
$taskRoot='D:\dev\ChatGPT\mcphub-readonly-identity-20261115'
$sourceRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\source'
$cacheRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115'
$logRoot=Join-Path $taskRoot 'evidence\repository-gates'
if(Test-Path -LiteralPath $logRoot){throw 'Preserve existing repository gate evidence; choose a fresh path'}
@($logRoot,(Join-Path $taskRoot 'tmp\repository'),(Join-Path $taskRoot 'appdata'),(Join-Path $taskRoot 'localappdata')) | ForEach-Object {[IO.Directory]::CreateDirectory($_)|Out-Null}
$env:TEMP=Join-Path $taskRoot 'tmp\repository';$env:TMP=$env:TEMP;$env:GOTMPDIR=$env:TEMP
$env:APPDATA=Join-Path $taskRoot 'appdata';$env:LOCALAPPDATA=Join-Path $taskRoot 'localappdata'
$env:GOCACHE=Join-Path $cacheRoot 'go-cache';$env:GOMODCACHE=Join-Path $cacheRoot 'go-mod-cache';$env:GOPATH=Join-Path $cacheRoot 'go-path'
$env:GOTOOLCHAIN='local';$env:GOPROXY='file:///C:/Users/<USER-REDACTED>/go/pkg/mod/cache/download';$env:GOSUMDB='off';$env:GOTELEMETRY='off';$env:CGO_ENABLED='1';$env:CC='c:\msys64\ucrt64\bin\gcc.exe'
$env:MCPHUB_GUI_SPAWN_TESTS=''
Set-Location $sourceRoot
$utf8=New-Object Text.UTF8Encoding($false)
$goTrees=[ordered]@{sourceRoot=$sourceRoot;head=(& git rev-parse HEAD).Trim();internal=(& git rev-parse HEAD:internal).Trim();cmd=(& git rev-parse HEAD:cmd).Trim();goMod=(& git rev-parse HEAD:go.mod).Trim();goSum=(& git rev-parse HEAD:go.sum).Trim();note='Parallel edits are confined to the nested Rust/FFI experiment; product Go inputs stay unchanged.'}
[IO.File]::WriteAllText((Join-Path $logRoot 'source-identity.json'),(ConvertTo-Json $goTrees)+[char]10,$utf8)
$records=New-Object Collections.Generic.List[object]
foreach($step in @(
 @{name='build';arguments=@('build','./...')},
 @{name='vet';arguments=@('vet','./...')},
 @{name='test';arguments=@('test','-json','-count=1','-timeout','5m','./...')},
 @{name='state-tag';arguments=@('test','-json','-tags=test_state_path_env','-count=1','-timeout','5m','./internal/api/','./internal/cli/')}
)){
 $started=[DateTime]::UtcNow.ToString('o');$arguments=$step.arguments
 $oldPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
 & go @arguments 2>&1 | Out-File -Encoding utf8 (Join-Path $logRoot ($step.name+'.log'))
 $code=$LASTEXITCODE;$ErrorActionPreference=$oldPreference
 $records.Add([ordered]@{name=$step.name;program='go';arguments=$arguments;exitCode=$code;startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');log=$step.name+'.log'})
 $json=ConvertTo-Json -InputObject @($records.ToArray()) -Depth 5
 [IO.File]::WriteAllText((Join-Path $logRoot 'steps.json'),($json -replace '\r\n',[string][char]10)+[char]10,$utf8)
 Write-Output ($step.name+' exit='+$code)
}
foreach($record in @('internal','cmd','go.mod','go.sum')){
 $expected = switch($record){'go.mod'{$goTrees.goMod};'go.sum'{$goTrees.goSum};default{$goTrees[$record]}}
 if((& git rev-parse ('HEAD:'+$record)).Trim() -ne $expected){throw ('Product Go tree changed during gates: '+$record)}
}
Write-Output 'REPOSITORY_GATES_RECORDED'
