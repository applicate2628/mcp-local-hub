$ErrorActionPreference='Stop'
$taskRoot='D:\dev\ChatGPT\mcphub-readonly-identity-20261115'
$controlRoot=Join-Path $taskRoot 'query-controls\evidence\qualified'
$outputRoot=Join-Path $taskRoot 'evidence\root-controls'
if(Test-Path -LiteralPath $outputRoot){throw 'Preserve existing root controls'}
[IO.Directory]::CreateDirectory($outputRoot)|Out-Null
$env:TEMP=Join-Path $outputRoot 'tmp';$env:TMP=$env:TEMP;$env:GOTMPDIR=$env:TEMP
[IO.Directory]::CreateDirectory($env:TEMP)|Out-Null
$env:GOTELEMETRY='off';$env:GOENV='off';$env:GOTOOLCHAIN='local';$env:GOPROXY='off';$env:GOSUMDB='off'
$env:GOCACHE='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-cache';$env:GOMODCACHE='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-mod-cache';$env:GOPATH='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-path'
$env:MCPHUB_RX02_FFI_CHILD=Join-Path $taskRoot 'native-target\debug\owner_child.exe'
$env:MCPHUB_RX02_FFI_DLL=Join-Path $controlRoot 'known-root-not-signaled\mcphub_owner_ffi_spike.dll'
$env:MCPHUB_IDENTITY_QUERY_FAULT='known-root-not-signaled'
$env:MCPHUB_RX02_IDENTITY_FIXTURES=$env:TEMP
function Digest([string]$Path){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($Path)))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
$records=New-Object Collections.Generic.List[object]
foreach($case in @(
 @{name='good-consumer';binary=(Join-Path $controlRoot 'consumer-query-faults.test.exe');expected=0},
 @{name='weakened-consumer';binary=(Join-Path $controlRoot 'weakened-consumer\consumer-query-faults.test.exe');expected=1}
)){
 $started=[DateTime]::UtcNow.ToString('o');$dllHash=Digest $env:MCPHUB_RX02_FFI_DLL;$binaryHash=Digest $case.binary
 $arguments=@('tool','test2json','-t','-p','mcphub-owner-ffi-caller',$case.binary,'-test.v=test2json','-test.run=^TestIdentityQueryForeignFaultPreservesAdmission$','-test.count=1','-test.timeout=45s')
 $oldPreference=$ErrorActionPreference;$ErrorActionPreference='Continue'
 & go @arguments 2>&1|Out-File -Encoding utf8 (Join-Path $outputRoot ($case.name+'.log'))
 $code=$LASTEXITCODE;$ErrorActionPreference=$oldPreference
 $events=@(Get-Content (Join-Path $outputRoot ($case.name+'.log'))|Where-Object{$_ -match '^\{'}|ForEach-Object{$_|ConvertFrom-Json})
 $pass=@($events|Where-Object{$_.Action -eq 'pass' -and $_.Test}).Count;$fail=@($events|Where-Object{$_.Action -eq 'fail' -and $_.Test}).Count;$skip=@($events|Where-Object{$_.Action -eq 'skip'}).Count
 $oracle=($code -eq $case.expected -and $skip -eq 0)
 if($case.expected -eq 0){$oracle=$oracle -and $pass -eq 1 -and $fail -eq 0}else{$oracle=$oracle -and $pass -eq 0 -and $fail -eq 1 -and (($events|Where-Object{$_.Output -match 'failed query exposed an observation'}).Count -eq 1)}
 if((Digest $env:MCPHUB_RX02_FFI_DLL) -ne $dllHash -or (Digest $case.binary) -ne $binaryHash){throw 'Artifact changed during root control'}
 $records.Add([ordered]@{name=$case.name;arguments=$arguments;startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');expectedExit=$case.expected;exitCode=$code;testPass=$pass;testFail=$fail;testSkip=$skip;semanticOracle=$oracle;dllSHA256=$dllHash;consumerSHA256=$binaryHash})
 [IO.File]::WriteAllText((Join-Path $outputRoot 'results.json'),(ConvertTo-Json -InputObject @($records.ToArray()) -Depth 6)+[char]10,(New-Object Text.UTF8Encoding($false)))
 Write-Output ($case.name+' exit='+$code+' expected='+$case.expected+' oracle='+$oracle)
 if(-not $oracle){throw 'Root control oracle failed'}
}
Write-Output 'ROOT_CONTROLS_VERIFIED'
