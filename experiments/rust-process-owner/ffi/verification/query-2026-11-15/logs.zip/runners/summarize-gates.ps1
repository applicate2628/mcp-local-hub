$ErrorActionPreference='Stop'
$taskRoot='D:\dev\ChatGPT\mcphub-readonly-identity-20261115'
$oldRoot='D:\dev\ChatGPT\mcphub-ffi-identity-20261115\evidence\repository-gates'
$gateRoot=Join-Path $taskRoot 'evidence\repository-gates'
function Census([string]$Path){
 $passedTop=0;$passedNested=0;$failedTop=0;$failedNested=0;$skippedTop=0;$skippedNested=0
 $open=@{};$failed=New-Object Collections.Generic.List[string];$packages=New-Object Collections.Generic.List[string];$timeouts=New-Object Collections.Generic.List[string]
 foreach($line in [IO.File]::ReadLines($Path)){
  if($line -notmatch '"Action":"(?:run|pass|fail|skip)"' -and $line -notmatch 'test timed out'){continue}
  $event=$line|ConvertFrom-Json
  if($event.Output -match 'test timed out'){$timeouts.Add($event.Package)}
  if(-not $event.Test){if($event.Action -eq 'fail'){$packages.Add($event.Package)};continue}
  $key=$event.Package+'::'+$event.Test
  if($event.Action -eq 'run'){$open[$key]=$true;continue}
  [void]$open.Remove($key)
  switch($event.Action){
   'pass'{if($event.Test -match '/'){$passedNested++}else{$passedTop++}}
   'fail'{$failed.Add($key);if($event.Test -match '/'){$failedNested++}else{$failedTop++}}
   'skip'{if($event.Test -match '/'){$skippedNested++}else{$skippedTop++}}
  }
 }
 return [ordered]@{topPass=$passedTop;topFail=$failedTop;topSkip=$skippedTop;nestedPass=$passedNested;nestedFail=$failedNested;nestedSkip=$skippedNested;incomplete=@($open.Keys|Sort-Object);failedTests=@($failed.ToArray()|Sort-Object);failedPackages=@($packages.ToArray()|Sort-Object -Unique);timeoutPackages=@($timeouts.ToArray()|Sort-Object -Unique)}
}
$all=[ordered]@{}
foreach($name in @('test','state-tag')){
 $current=Census (Join-Path $gateRoot ($name+'.log'))
 $old=Census (Join-Path $oldRoot ($name+'.log'))
 $differences=@(Compare-Object $old.failedTests $current.failedTests)
 $current['newFailureNames']=@($differences|Where-Object{$_.SideIndicator -eq '=>'}|Select-Object -ExpandProperty InputObject)
 $current['missingPreviousFailureNames']=@($differences|Where-Object{$_.SideIndicator -eq '<='}|Select-Object -ExpandProperty InputObject)
 $all[$name]=$current
 Write-Output ($name+': top='+$current.topPass+'/'+$current.topFail+'/'+$current.topSkip+' nested='+$current.nestedPass+'/'+$current.nestedFail+'/'+$current.nestedSkip+' incomplete='+$current.incomplete.Count+' newNames='+$current.newFailureNames.Count+' missingNames='+$current.missingPreviousFailureNames.Count)
}
[IO.File]::WriteAllText((Join-Path $gateRoot 'census.json'),(ConvertTo-Json -InputObject $all -Depth 8)+[char]10,(New-Object Text.UTF8Encoding($false)))
$observed=@(Get-CimInstance Win32_Process|Where-Object{$_.ProcessId -ne $PID -and (($_.ExecutablePath -and $_.ExecutablePath.StartsWith($taskRoot,[StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and $_.CommandLine.Contains($taskRoot)))}|Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
$receipt=[ordered]@{observedUtc=[DateTime]::UtcNow.ToString('o');scope=$taskRoot;records=$observed;terminated=@();note='Read-only snapshot. No image-name sweep or termination.'}
[IO.File]::WriteAllText((Join-Path $gateRoot 'owned-process-snapshot.json'),(ConvertTo-Json -InputObject $receipt -Depth 6)+[char]10,(New-Object Text.UTF8Encoding($false)))
Write-Output ('OWNED_PREFIX_PROCESSES='+$observed.Count)
