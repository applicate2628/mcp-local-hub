$ErrorActionPreference='Stop'
$root='D:\dev\ChatGPT\mcphub-readonly-identity-20261115\evidence\root-controls'
$records=Get-Content (Join-Path $root 'results.json') -Raw|ConvertFrom-Json
$review=New-Object Collections.Generic.List[object]
foreach($record in $records){
 $log=Join-Path $root ($record.name+'.log')
 $events=@(Get-Content $log|Where-Object{$_ -match '^\{'}|ForEach-Object{$_|ConvertFrom-Json})
 $pass=@($events|Where-Object{$_.Action -eq 'pass' -and $_.Test}).Count
 $fail=@($events|Where-Object{$_.Action -eq 'fail' -and $_.Test}).Count
 $skip=@($events|Where-Object{$_.Action -eq 'skip'}).Count
 $runs=@($events|Where-Object{$_.Action -eq 'run' -and $_.Test}).Count
 $marker=@($events|Where-Object{$_.Output -match 'failed query exposed an observation'}).Count
 $accepted=($record.exitCode -eq $record.expectedExit -and $skip -eq 0 -and $runs -eq 1)
 if($record.expectedExit -eq 0){$accepted=$accepted -and $pass -eq 1 -and $fail -eq 0}else{$accepted=$accepted -and $pass -eq 0 -and $fail -eq 1 -and $marker -eq 1}
 $review.Add([ordered]@{name=$record.name;actualExit=$record.exitCode;expectedExit=$record.expectedExit;testRuns=$runs;testPass=$pass;testFail=$fail;skips=$skip;failureMarkerCount=$marker;accepted=$accepted;dllSHA256=$record.dllSHA256;consumerSHA256=$record.consumerSHA256})
 if(-not $accepted){throw 'Corrected semantic interpretation failed'}
}
$data=[ordered]@{reviewedUtc=[DateTime]::UtcNow.ToString('o');executionRepeated=$false;originalRunnerReceipt='results.json';correction='PowerShell scalar property Count replaced by explicit array wrapping @(...).Count; original execution logs and receipt preserved.';runs=@($review.ToArray());actualExecutionCount=2;allSemanticOraclesMatched=$true}
$json=(ConvertTo-Json -InputObject $data -Depth 6) -replace '\r\n',[string][char]10
[IO.File]::WriteAllText((Join-Path $root 'reviewed-results.json'),$json+[char]10,(New-Object Text.UTF8Encoding($false)))
Write-Output 'ROOT_ACTUAL_EXECUTIONS_VERIFIED: good=0; weakened=1; exact failure marker=1'
