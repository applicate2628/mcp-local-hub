[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$TaskRoot,
 [Parameter(Mandatory=$true)][string]$SourceRoot,
 [Parameter(Mandatory=$true)][string]$CacheRoot,
 [Parameter(Mandatory=$true)][string]$Child,
 [Parameter(Mandatory=$true)][string]$LegacyAbiDll,
 [Parameter(Mandatory=$true)][string]$LegacyIdentityDll
)
$ErrorActionPreference='Stop'
function Owned-Path([string]$Path) {
 if($Path -notmatch '^[A-Za-z]:[\\/]'){throw 'Explicit absolute D:\dev\ChatGPT path required'}
 $full=[IO.Path]::GetFullPath($Path).TrimEnd([char]92)
 if(-not $full.StartsWith('D:\dev\ChatGPT\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path outside owned D:\dev\ChatGPT tree'}
 return $full
}
$TaskRoot=Owned-Path $TaskRoot; $SourceRoot=Owned-Path $SourceRoot; $CacheRoot=Owned-Path $CacheRoot
$Child=Owned-Path $Child; $LegacyAbiDll=Owned-Path $LegacyAbiDll; $LegacyIdentityDll=Owned-Path $LegacyIdentityDll
$native=Join-Path $SourceRoot 'experiments\rust-process-owner'; $ffi=Join-Path $native 'ffi'
$logRoot=Join-Path $TaskRoot 'evidence\qualification'; $compat=Join-Path $TaskRoot 'compatibility-query'
foreach($path in @($logRoot,$compat)){if(Test-Path -LiteralPath $path){throw "Preserve existing qualification evidence: $path"}}
foreach($path in @($Child,$LegacyAbiDll,$LegacyIdentityDll,(Join-Path $ffi 'go\go.mod'))){if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw "Missing pinned input: $path"}}
@($logRoot,$compat,(Join-Path $TaskRoot 'tmp\ffi'),(Join-Path $TaskRoot 'tmp\query-identity-qualified'))|ForEach-Object{[IO.Directory]::CreateDirectory($_)|Out-Null}
$env:TEMP=Join-Path $TaskRoot 'tmp\ffi'; $env:TMP=$env:TEMP; $env:GOTMPDIR=$env:TEMP
$env:CARGO_HOME='D:\dev\ChatGPT\mcphub-rx02-stdio-20261113\cargo-home'
$env:CARGO_TARGET_DIR=Join-Path $TaskRoot 'ffi-target'; $env:CARGO_NET_OFFLINE='true'; $env:RUSTUP_OFFLINE='1'
$env:CARGO_INCREMENTAL='0'; $env:CARGO_BUILD_JOBS='2'
$env:GOCACHE=Join-Path $CacheRoot 'go-cache'; $env:GOMODCACHE=Join-Path $CacheRoot 'go-mod-cache'; $env:GOPATH=Join-Path $CacheRoot 'go-path'
$env:GOTOOLCHAIN='local'; $env:GOPROXY='off'; $env:GOSUMDB='off'; $env:GOTELEMETRY='off'; $env:CGO_ENABLED='1'; $env:CC='c:\msys64\ucrt64\bin\gcc.exe'
$env:MCPHUB_RX02_FFI_CHILD=$Child
$env:MCPHUB_RX02_IDENTITY_FIXTURES=Join-Path $TaskRoot 'tmp\query-identity-qualified'
$steps=New-Object Collections.Generic.List[object]
function Write-Text([string]$Path,[string]$Content){[IO.File]::WriteAllText($Path,($Content -replace '\r\n',[string][char]10).TrimEnd()+[char]10,(New-Object Text.UTF8Encoding($false)))}
function Digest([string]$Path){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash([IO.File]::ReadAllBytes($Path)))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Save-Steps {Write-Text (Join-Path $logRoot 'steps.json') (ConvertTo-Json -InputObject @($steps.ToArray()) -Depth 6)}
function Step([string]$Name,[string]$Program,[string[]]$Arguments){
 $started=[DateTime]::UtcNow.ToString('o'); $oldPreference=$ErrorActionPreference; $ErrorActionPreference='Continue'
 & $Program @Arguments 2>&1 | Out-File -Encoding utf8 (Join-Path $logRoot ($Name+'.log'))
 $code=$LASTEXITCODE; $ErrorActionPreference=$oldPreference
 $steps.Add([ordered]@{name=$Name;program=$Program;arguments=$Arguments;cwd=(Get-Location).Path;startedUtc=$started;finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$code;log=$Name+'.log'})
 Save-Steps; Write-Output "$Name exit=$code"
 if($code -ne 0){Get-Content (Join-Path $logRoot ($Name+'.log')) -Tail 70;throw "$Name failed"}
}
function Check-Go([string]$Name,[int]$ExpectedTop,[int]$ExpectedNested){
 $events=@(Get-Content (Join-Path $logRoot ($Name+'.log'))|Where-Object{$_ -match '^\{'}|ForEach-Object{$_|ConvertFrom-Json})
 $top=@($events|Where-Object{$_.Action -eq 'pass' -and $_.Test -and $_.Test -notmatch '/'}).Count
 $nested=@($events|Where-Object{$_.Action -eq 'pass' -and $_.Test -match '/'}).Count
 $skip=@($events|Where-Object{$_.Action -eq 'skip'}).Count; $fail=@($events|Where-Object{$_.Action -eq 'fail'}).Count
 $record=$steps[$steps.Count-1];$record['topLevelPass']=$top;$record['nestedPass']=$nested;$record['skips']=$skip;$record['failures']=$fail;Save-Steps
 Write-Output "$Name top=$top nested=$nested skips=$skip failures=$fail"
 if($top -ne $ExpectedTop -or $nested -ne $ExpectedNested -or $skip -ne 0 -or $fail -ne 0){throw "$Name unexpected test census"}
}
$nativeParent='7f99d4001c43c77c0fab478566e42b8bfb4d12e1'; $foreignParent='2e4bf6f983fbf1747ca286016a6eb485a834b852'
Set-Location $SourceRoot
& git diff --exit-code $nativeParent -- experiments/rust-process-owner/Cargo.toml experiments/rust-process-owner/Cargo.lock experiments/rust-process-owner/src experiments/rust-process-owner/tests
if($LASTEXITCODE -ne 0){throw 'Native runtime differs from the qualified parent'}
if((Digest $LegacyAbiDll) -ne '32276f47f356cb7473f06a6bb5bba1a89d1545f3986ce9f640013c72b41047f1'){throw 'Legacy ABI1 DLL identity differs'}
if((Digest $LegacyIdentityDll) -ne 'f87027915e60020457495d9c5a67548152e69559ca9b9a8fdf53305815417b1b'){throw 'Admission-only identity DLL differs'}
$sourceFiles=@(Get-Item (Join-Path $native 'Cargo.toml'),(Join-Path $native 'Cargo.lock'),(Join-Path $ffi 'Cargo.toml'),(Join-Path $ffi 'Cargo.lock');Get-ChildItem (Join-Path $native 'src'),(Join-Path $native 'tests'),(Join-Path $ffi 'src'),(Join-Path $ffi 'include'),(Join-Path $ffi 'go') -File -Recurse)
$hashes=@($sourceFiles|Sort-Object FullName -Unique|ForEach-Object{[ordered]@{path=$_.FullName.Substring($SourceRoot.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Digest $_.FullName)}})
Write-Text (Join-Path $logRoot 'source-hashes.json') (ConvertTo-Json -InputObject $hashes -Depth 4)
Write-Text (Join-Path $logRoot 'source-identity.json') (ConvertTo-Json -InputObject ([ordered]@{sourceHead=(& git rev-parse HEAD).Trim();nativeParent=$nativeParent;foreignParent=$foreignParent;dirtyRuntimeOverlay=$true;runtimeFiles=$hashes.Count;recordedUtc=[DateTime]::UtcNow.ToString('o');go=(& go version);rustc=(& rustc --version);cargo=(& cargo --version)}) -Depth 4)
Set-Location $ffi
Step 'rust-fmt' 'cargo' @('fmt','--check')
Step 'rust-clippy' 'cargo' @('clippy','--offline','--locked','--all-targets','--','-D','warnings')
Step 'rust-tests-debug' 'cargo' @('test','--offline','--locked','--','--test-threads=1')
Step 'rust-tests-release' 'cargo' @('test','--offline','--locked','--release','--','--test-threads=1')
Step 'dll-debug' 'cargo' @('build','--offline','--locked')
Step 'dll-release' 'cargo' @('build','--offline','--locked','--release')
Set-Location (Join-Path $ffi 'go')
Step 'go-format' 'gofmt' @('-l','bridge_windows.go','identity_windows.go','identity_query_windows_test.go','identity_query_legacy_windows_test.go','identity_query_faults_windows_test.go')
if((Get-Content (Join-Path $logRoot 'go-format.log')|Out-String).Trim()){throw 'Go formatting differs'}
foreach($profile in @('debug','release')){
 $env:MCPHUB_RX02_FFI_DLL=Join-Path $TaskRoot ("ffi-target\"+$profile+'\mcphub_owner_ffi_spike.dll')
 Step ("go-race-"+$profile) 'go' @('test','-json','-race','-count=1','-timeout=120s','.')
 Check-Go ("go-race-"+$profile) 57 72
 $env:GOEXPERIMENT='cgocheck2'
 Step ("go-cgocheck2-"+$profile) 'go' @('test','-json','-count=1','-timeout=120s','.')
 Check-Go ("go-cgocheck2-"+$profile) 57 72
 $env:GOEXPERIMENT=''
}
Step 'go-vet' 'go' @('vet','.')
$env:MCPHUB_RX02_FFI_DLL=$LegacyAbiDll; $env:MCPHUB_QUERY_LEGACY_MODE='abi1'
Step 'new-go-abi1-dll' 'go' @('test','-json','-race','-tags=identity_query_legacy','-run','^TestIdentityQueryUnsupportedPreservesExplicitAdmission$','-count=1','-timeout=60s','.')
Check-Go 'new-go-abi1-dll' 1 0
$env:MCPHUB_RX02_FFI_DLL=$LegacyIdentityDll; $env:MCPHUB_QUERY_LEGACY_MODE='admission-identity'
Step 'new-go-admission-dll' 'go' @('test','-json','-race','-tags=identity_query_legacy','-run','^TestIdentityQueryUnsupportedPreservesExplicitAdmission$','-count=1','-timeout=60s','.')
Check-Go 'new-go-admission-dll' 1 0
Set-Location $SourceRoot
Step 'archive-old-go' 'git' @('archive','--format=zip',('--output='+(Join-Path $compat 'old-go.zip')),$foreignParent,'--','experiments/rust-process-owner/ffi/go','experiments/rust-process-owner/ffi/include')
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $compat 'old-go.zip'),(Join-Path $compat 'source'))
Set-Location (Join-Path $compat 'source\experiments\rust-process-owner\ffi\go')
$env:MCPHUB_RX02_FFI_DLL=Join-Path $TaskRoot 'ffi-target\debug\mcphub_owner_ffi_spike.dll'
Step 'old-go-new-dll' 'go' @('test','-json','-race','-count=1','-timeout=120s','.')
Check-Go 'old-go-new-dll' 54 68
$artifacts=@((Join-Path $TaskRoot 'ffi-target\debug\mcphub_owner_ffi_spike.dll'),(Join-Path $TaskRoot 'ffi-target\release\mcphub_owner_ffi_spike.dll'),$Child,$LegacyAbiDll,$LegacyIdentityDll,(Join-Path $compat 'old-go.zip'))|ForEach-Object{[ordered]@{path=$_;bytes=(Get-Item $_).Length;sha256=(Digest $_)}}
Write-Text (Join-Path $logRoot 'artifacts.json') (ConvertTo-Json -InputObject @($artifacts) -Depth 4)
foreach($record in $hashes){if((Digest (Join-Path $SourceRoot $record.path)) -ne $record.sha256){throw "Qualified source changed: $($record.path)"}}
Write-Output 'READ_ONLY_IDENTITY_QUALIFICATION_COMPLETE'

