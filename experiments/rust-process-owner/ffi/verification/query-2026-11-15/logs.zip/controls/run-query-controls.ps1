param([string]$Run = 'qualified')
$ErrorActionPreference = 'Stop'
if ($Run -notmatch '^[a-zA-Z0-9_-]+$') { throw 'Run must be one directory name' }
$controlRoot = 'D:\dev\ChatGPT\mcphub-readonly-identity-20261115\query-controls'
$production = 'D:\dev\ChatGPT\mcphub-ffi-identity-20261115\source\experiments\rust-process-owner'
$evidence = Join-Path $controlRoot ('evidence\' + $Run)
$baseline = Join-Path $evidence 'baseline-source'
$working = Join-Path $controlRoot ('working-' + $Run)
$target = Join-Path $controlRoot 'target'
$tempRoot = Join-Path $controlRoot ('temp-' + $Run)
$child = 'D:\dev\ChatGPT\mcphub-readonly-identity-20261115\native-target\debug\owner_child.exe'
if ((Test-Path -LiteralPath $evidence) -or (Test-Path -LiteralPath $working)) { throw 'Do not overwrite an existing run' }
$utf8 = New-Object Text.UTF8Encoding($false)
$lf = [string][char]10
$crlf = [string][char]13 + [char]10
$commands = New-Object 'Collections.Generic.List[object]'
$testRuns = New-Object 'Collections.Generic.List[object]'
$go = (Get-Command go -ErrorAction Stop).Source
$cargo = (Get-Command cargo -ErrorAction Stop).Source
$git = (Get-Command git -ErrorAction Stop).Source
$env:CARGO_HOME = 'D:\dev\ChatGPT\mcphub-rx02-stdio-20261113\cargo-home'
$env:CARGO_TARGET_DIR = $target
$env:CARGO_NET_OFFLINE = 'true'
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '2'
$env:RUSTUP_OFFLINE = '1'
$env:GOCACHE = 'D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-cache'
$env:GOMODCACHE = 'D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-mod-cache'
$env:GOPATH = 'D:\dev\ChatGPT\mcphub-ffi-identity-20261115\go-path'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
$env:GOTOOLCHAIN = 'local'
$env:GOENV = 'off'
$env:CGO_ENABLED = '1'
$env:CC = (Get-Command gcc -ErrorAction Stop).Source
$env:TEMP = $tempRoot
$env:TMP = $tempRoot
$env:GOTMPDIR = Join-Path $tempRoot 'go'
New-Item -ItemType Directory -Path $evidence,$target,$env:GOTMPDIR -Force | Out-Null
foreach ($path in @($env:CARGO_HOME,$env:GOCACHE,$env:GOMODCACHE,$env:GOPATH,$child)) {
    if (-not (Test-Path -LiteralPath $path)) { throw ('Missing existing prerequisite: ' + $path) }
}
function Write-Text([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, $utf8)
}
function Save-Json([string]$Path, $Value) {
    Write-Text $Path ((ConvertTo-Json -InputObject $Value -Depth 12) + $lf)
}
function Hash-File([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $hash.Dispose() }
}
function Assert-Budget {
    $bytes = (Get-ChildItem -LiteralPath $controlRoot -Recurse -File | Measure-Object Length -Sum).Sum
    if ($bytes -gt 500MB) { throw 'Query-control directory exceeded 500 MiB budget' }
    if ((Get-PSDrive -Name D).Free -lt 600MB) { throw 'Drive D has less than 600 MiB free' }
}
function Copy-Subset([string]$From, [string]$To) {
    New-Item -ItemType Directory -Path $To | Out-Null
    foreach ($part in @('Cargo.toml','Cargo.lock','src','tests')) {
        Copy-Item -LiteralPath (Join-Path $From $part) -Destination $To -Recurse
    }
    $ffiTo = Join-Path $To 'ffi'
    New-Item -ItemType Directory -Path $ffiTo | Out-Null
    foreach ($part in @('Cargo.toml','Cargo.lock','src','include','go')) {
        Copy-Item -LiteralPath (Join-Path $From ('ffi\' + $part)) -Destination $ffiTo -Recurse
    }
}
function Source-Manifest([string]$Root) {
    $files = @(Get-Item -LiteralPath (Join-Path $Root 'Cargo.toml'),(Join-Path $Root 'Cargo.lock'),(Join-Path $Root 'ffi\Cargo.toml'),(Join-Path $Root 'ffi\Cargo.lock'))
    foreach ($part in @('src','tests','ffi\src','ffi\include','ffi\go')) {
        $files += @(Get-ChildItem -LiteralPath (Join-Path $Root $part) -Recurse -File)
    }
    return @($files | Sort-Object FullName | ForEach-Object {
        [ordered]@{path=$_.FullName.Substring($Root.Length + 1).Replace('\','/'); bytes=$_.Length; sha256=(Hash-File $_.FullName)}
    })
}
function Replace-One([string]$Text, [string]$Before, [string]$After) {
    $eol = if ($Text.Contains($crlf)) { $crlf } else { $lf }
    $beforeExact = $Before.Replace($crlf,$lf).Replace($lf,$eol)
    $afterExact = $After.Replace($crlf,$lf).Replace($lf,$eol)
    $at = $Text.IndexOf($beforeExact,[StringComparison]::Ordinal)
    if ($at -lt 0 -or $Text.IndexOf($beforeExact,$at + $beforeExact.Length,[StringComparison]::Ordinal) -ge 0) {
        throw 'Mutation requires exactly one known preimage'
    }
    return $Text.Substring(0,$at) + $afterExact + $Text.Substring($at + $beforeExact.Length)
}
function Invoke-CommandRecorded([string]$Name, [string]$Directory, [string]$Tool, [string[]]$Arguments, [int]$Expected=0, [bool]$Check=$true) {
    Assert-Budget
    $started = [DateTime]::UtcNow.ToString('o')
    Push-Location $Directory
    try {
        $ErrorActionPreference = 'Continue'
        $output = & $Tool @Arguments 2>&1
        $code = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
    } finally { $ErrorActionPreference = 'Stop'; Pop-Location }
    $text = ($output | ForEach-Object { $_.ToString() }) -join $lf
    Write-Text (Join-Path $evidence ($Name + '.log')) ($text + $lf)
    $record = [ordered]@{name=$Name; executable=$Tool; arguments=$Arguments; directory=$Directory; expectedExit=$Expected; exitCode=$code; startedUtc=$started; finishedUtc=[DateTime]::UtcNow.ToString('o')}
    Save-Json (Join-Path $evidence ($Name + '.json')) $record
    $commands.Add($record)
    Save-Json (Join-Path $evidence 'commands.json') @($commands.ToArray())
    Write-Host ($Name + ' exit=' + $code + ' expected=' + $Expected)
    if ($Check -and $code -ne $Expected) { throw ('Unexpected command exit: ' + $Name) }
    return [pscustomobject]@{code=$code; text=$text}
}
function Mutate-Query([string]$Mode) {
    $query = $queryBase
    $receive = '            receive(&observation.value, size_of::<Identity>() as u32, token);'
    switch ($Mode) {
        'baseline' {}
        'late-report' { $query = Replace-One $query $receive ($receive + $lf + '            report.version = VERSION + 1;') }
        'missing-receiver' { $query = Replace-One $query $receive '            let _ = (&observation, receive, token);' }
        'repeated-receiver' { $query = Replace-One $query $receive ($receive + $lf + $receive) }
        'invalid-observation' {
            $query = Replace-One $query '            let observation = match observe(view, report) {' '            let mut observation = match observe(view, report) {'
            $query = Replace-One $query $receive ('            observation.value.version = VERSION + 1;' + $lf + $receive)
        }
        'query-close' {
            $query = Replace-One $query ($receive + $lf + '            OK') @'
            let _ = (&observation, receive, token);
            report.stage = STAGE_TOKEN;
            report.query_error_kind = ERROR_NATIVE;
            report.query_native_error = 5;
            report.token_close_error = 6;
            STATE
'@
        }
        'close-only' {
            $query = Replace-One $query ($receive + $lf + '            OK') @'
            let _ = (&observation, receive, token);
            report.stage = STAGE_TOKEN;
            report.query_error_kind = ERROR_NONE;
            report.query_native_error = 0;
            report.token_close_error = 6;
            STATE
'@
        }
        'known-root-not-signaled' {
            $query = Replace-One $query $receive ($receive + $lf + '            out.flags |= super::ROOT_KNOWN;' + $lf + '            out.root_exit = 0;')
        }
        'pid-mismatch' {
            $query = Replace-One $query '            let observation = match observe(view, report) {' '            let mut observation = match observe(view, report) {'
            $query = Replace-One $query $receive ('            observation.value.pid = observation.value.pid.wrapping_add(1).max(1);' + $lf + $receive)
        }
        'settlement' { $query = Replace-One $query $receive ($receive + $lf + '            out.state = super::PENDING;') }
        'active-observation' { $query = Replace-One $query $receive ($receive + $lf + '            out.flags |= super::ACTIVE_KNOWN;') }
        'routing-admission' {
            $query = Replace-One $query '            let view = match owner.inner.process_view() {' @'
            if let Err(error) = owner.inner.admit_and_resume(|_| Ok(())) {
                return failure(out, error);
            }
            let view = match owner.inner.process_view() {
'@
        }
        default { throw 'Unknown query mutation' }
    }
    # The complete prefix, signature and suffix remain the baseline text.
    if (-not $query.StartsWith($querySignature,[StringComparison]::Ordinal)) { throw 'Query signature changed' }
    Write-Text $identityPath ($identityBase.Substring(0,$queryStart) + $query + $identityBase.Substring($queryEnd))
}
function Build-Producer([string]$Mode) {
    Mutate-Query $Mode
    $caseDir = Join-Path $evidence $Mode
    New-Item -ItemType Directory -Path $caseDir | Out-Null
    Copy-Item -LiteralPath $identityPath -Destination (Join-Path $caseDir 'identity.rs')
    Save-Json (Join-Path $caseDir 'mutation.json') ([ordered]@{
        mode=$Mode; scope='mh_query_identity1 body only'; baselineFile='baseline-source/ffi/src/identity.rs'
        baselineSHA256=(Hash-File (Join-Path $baseline 'ffi\src\identity.rs'))
        mutatedSHA256=(Hash-File $identityPath)
        syntheticTokenReceipt=($Mode -in @('query-close','close-only'))
        unchangedSharedObservationAndAdmission=$true
    })
    $null = Invoke-CommandRecorded ('build-' + $Mode) (Join-Path $working 'ffi') $cargo @('build','--offline','--locked')
    $dll = Join-Path $caseDir 'mcphub_owner_ffi_spike.dll'
    Copy-Item -LiteralPath (Join-Path $target 'debug\mcphub_owner_ffi_spike.dll') -Destination $dll
    Write-Text (Join-Path $caseDir 'dll.sha256') ((Hash-File $dll) + $lf)
    return $dll
}
function Run-Test([string]$Name, [string]$Dll, [string]$Binary, [string]$Test, [string]$Fault, [int]$Expected, [int]$Subtests, [string]$Oracle='') {
    $caseDir = Join-Path $evidence $Name
    if (-not (Test-Path -LiteralPath $caseDir)) { New-Item -ItemType Directory -Path $caseDir | Out-Null }
    $env:MCPHUB_RX02_FFI_DLL = $Dll
    $env:MCPHUB_RX02_FFI_CHILD = $child
    $env:MCPHUB_IDENTITY_QUERY_FAULT = $Fault
    $env:MCPHUB_RX02_IDENTITY_FIXTURES = Join-Path $caseDir 'fixtures'
    New-Item -ItemType Directory -Path $env:MCPHUB_RX02_IDENTITY_FIXTURES | Out-Null
    $dllHash = Hash-File $Dll
    $binaryHash = Hash-File $Binary
    $testArgs = @('tool','test2json','-t','-p','mcphub-owner-ffi-caller',$Binary,'-test.v=test2json',('-test.run=^' + $Test + '$'),'-test.count=1','-test.timeout=45s')
    $run = Invoke-CommandRecorded ('test-' + $Name) (Join-Path $working 'ffi\go') $go $testArgs $Expected $false
    Write-Text (Join-Path $caseDir 'test-events.jsonl') ($run.text + $lf)
    $events = @($run.text.Split([char]10) | Where-Object { $_.Trim() } | ForEach-Object { ConvertFrom-Json $_ })
    $topRun = @($events | Where-Object { $_.Action -eq 'run' -and $_.Test -eq $Test })
    $subs = @($events | Where-Object { $_.Action -eq 'run' -and $_.Test -and $_.Test.StartsWith($Test + '/') })
    $skips = @($events | Where-Object { $_.Action -eq 'skip' })
    $allRuns = @($events | Where-Object { $_.Action -eq 'run' })
    $wantAction = if ($Expected -eq 0) { 'pass' } else { 'fail' }
    $topOutcome = @($events | Where-Object { $_.Action -eq $wantAction -and $_.Test -eq $Test })
    $matched = $run.code -eq $Expected -and $topRun.Count -eq 1 -and $subs.Count -eq $Subtests -and $skips.Count -eq 0 -and $allRuns.Count -eq (1 + $Subtests) -and $topOutcome.Count -eq 1
    if ($Oracle) { $matched = $matched -and ($run.text -match $Oracle) }
    if ((Hash-File $Dll) -ne $dllHash -or (Hash-File $Binary) -ne $binaryHash) { throw 'Test artifact changed during execution' }
    $record = [ordered]@{
        name=$Name; exactTest=$Test; fault=$Fault; expectedExit=$Expected; exitCode=$run.code; oracle=$Oracle; accepted=$matched
        topTestsRun=$topRun.Count; subtestsRun=$subs.Count; skips=$skips.Count
        passingTests=@($events | Where-Object { $_.Action -eq 'pass' -and $_.Test } | ForEach-Object { $_.Test })
        failingTests=@($events | Where-Object { $_.Action -eq 'fail' -and $_.Test } | ForEach-Object { $_.Test })
        dllPath=$Dll; dllSHA256=$dllHash; consumerPath=$Binary; consumerSHA256=$binaryHash; childSHA256=(Hash-File $child)
    }
    $testRuns.Add($record)
    Save-Json (Join-Path $caseDir 'test-result.json') $record
    Save-Json (Join-Path $evidence 'test-runs.json') @($testRuns.ToArray())
    if (-not $matched) { throw ('Semantic test oracle did not match: ' + $Name) }
}
Assert-Budget
$inputManifest = Source-Manifest $production
Copy-Subset $production $baseline
Copy-Subset $baseline $working
if ((ConvertTo-Json -InputObject (Source-Manifest $baseline) -Depth 5 -Compress) -ne (ConvertTo-Json -InputObject $inputManifest -Depth 5 -Compress)) { throw 'Baseline copy does not match production input bytes' }
Save-Json (Join-Path $evidence 'input-source-manifest.json') $inputManifest
Save-Json (Join-Path $evidence 'environment.json') ([ordered]@{
    productionHead=((& $git -C $production rev-parse HEAD) -join '')
    rustc=((& rustc --version) -join ''); cargo=((& $cargo --version) -join ''); go=((& $go version) -join '')
    productionInput=$production; baselineSource=$baseline; workingSource=$working; target=$target; temporary=$tempRoot
    runnerSHA256=(Hash-File $PSCommandPath)
    cargoHome=$env:CARGO_HOME; goCache=$env:GOCACHE; goModuleCache=$env:GOMODCACHE; goPath=$env:GOPATH
    offline=$true; cgoEnabled=$true; budgetBytes=500MB; child=$child; childSHA256=(Hash-File $child)
})
$identityPath = Join-Path $working 'ffi\src\identity.rs'
$bridgePath = Join-Path $working 'ffi\go\bridge_windows.go'
$identityBase = [IO.File]::ReadAllText((Join-Path $baseline 'ffi\src\identity.rs'))
$bridgeBase = [IO.File]::ReadAllText((Join-Path $baseline 'ffi\go\bridge_windows.go'))
$queryStart = $identityBase.IndexOf('pub unsafe extern "C" fn mh_query_identity1(',[StringComparison]::Ordinal)
$queryEnd = $identityBase.IndexOf('#[cfg(test)]',$queryStart,[StringComparison]::Ordinal)
if ($queryStart -lt 0 -or $queryEnd -le $queryStart) { throw 'Exact query function boundary unavailable' }
$queryBase = $identityBase.Substring($queryStart,$queryEnd-$queryStart)
$bodyStart = $queryBase.IndexOf(') -> u32 {',[StringComparison]::Ordinal) + ') -> u32 {'.Length
if ($bodyStart -lt ') -> u32 {'.Length) { throw 'Query signature boundary unavailable' }
$querySignature = $queryBase.Substring(0,$bodyStart)
$normalBinary = Join-Path $evidence 'consumer-normal.test.exe'
$faultBinary = Join-Path $evidence 'consumer-query-faults.test.exe'
$null = Invoke-CommandRecorded 'build-consumer-normal' (Join-Path $working 'ffi\go') $go @('test','-c','-o',$normalBinary,'.')
$null = Invoke-CommandRecorded 'build-consumer-faults' (Join-Path $working 'ffi\go') $go @('test','-c','-tags=identity_query_faults','-o',$faultBinary,'.')
$normalTest = 'TestIdentityQueryPreservesAdmissionAndOwnsCopies'
$faultTest = 'TestIdentityQueryForeignFaultPreservesAdmission'
$baselineDll = Build-Producer 'baseline'
Run-Test 'baseline' $baselineDll $normalBinary $normalTest '' 0 2
$faults = @('late-report','missing-receiver','repeated-receiver','invalid-observation','query-close','close-only','known-root-not-signaled','pid-mismatch','settlement','active-observation')
$knownRootDll = ''
foreach ($mode in $faults) {
    $dll = Build-Producer $mode
    Run-Test $mode $dll $faultBinary $faultTest $mode 0 0
    if ($mode -eq 'known-root-not-signaled') { $knownRootDll = $dll }
}
$routingDll = Build-Producer 'routing-admission'
Run-Test 'routing-admission' $routingDll $normalBinary $normalTest '' 1 2 'query did not describe original suspended process|repeated query changed original facts|owner ABI status=[1-9]|missing or inconsistent process facts|child effect before admission'
$guard = @'
		if observed.Flags&1 != 0 && state.value.WaitState != IdentitySignaled {
			reportErr = errors.Join(reportErr, invalidIdentity("query wait contradicts known root exit"))
		}
'@
$weakened = Replace-One $bridgeBase ($guard + $lf) ''
Write-Text $bridgePath $weakened
$weakDir = Join-Path $evidence 'weakened-consumer'
New-Item -ItemType Directory -Path $weakDir | Out-Null
Copy-Item -LiteralPath $bridgePath -Destination (Join-Path $weakDir 'bridge_windows.go')
Save-Json (Join-Path $weakDir 'mutation.json') ([ordered]@{
    scope='Only ROOT_KNOWN implies IdentitySignaled check removed'; removed=$guard
    baselineSHA256=(Hash-File (Join-Path $baseline 'ffi\go\bridge_windows.go')); mutatedSHA256=(Hash-File $bridgePath)
    producerDLL=$knownRootDll; producerSHA256=(Hash-File $knownRootDll)
})
$weakBinary = Join-Path $weakDir 'consumer-query-faults.test.exe'
$null = Invoke-CommandRecorded 'build-consumer-weakened' (Join-Path $working 'ffi\go') $go @('test','-c','-tags=identity_query_faults','-o',$weakBinary,'.')
Run-Test 'weakened-consumer' $knownRootDll $weakBinary $faultTest 'known-root-not-signaled' 1 0 'failed query exposed an observation'
Write-Text $identityPath $identityBase
Write-Text $bridgePath $bridgeBase
$productionUnchanged = (ConvertTo-Json -InputObject (Source-Manifest $production) -Depth 5 -Compress) -eq (ConvertTo-Json -InputObject $inputManifest -Depth 5 -Compress)
$baselineUnchanged = (ConvertTo-Json -InputObject (Source-Manifest $baseline) -Depth 5 -Compress) -eq (ConvertTo-Json -InputObject $inputManifest -Depth 5 -Compress)
if (-not $productionUnchanged -or -not $baselineUnchanged) { throw 'Production input or immutable baseline changed during controls' }
Assert-Budget
$trash = Join-Path $controlRoot 'trash'
New-Item -ItemType Directory -Path $trash -Force | Out-Null
$trashWorking = Join-Path $trash ('working-' + $Run)
$trashTemp = Join-Path $trash ('temp-' + $Run)
Move-Item -LiteralPath $working -Destination $trashWorking
Move-Item -LiteralPath $tempRoot -Destination $trashTemp
$summary = [ordered]@{
    run=$Run; completedUtc=[DateTime]::UtcNow.ToString('o'); actualTestInvocations=$testRuns.Count; actualCommandInvocations=$commands.Count
    allExpectedOutcomesMatched=(@($testRuns | Where-Object { -not $_.accepted }).Count -eq 0)
    baselinePasses=1; syntheticProducerCases=$faults.Count; expectedSemanticFailures=2
    productionUnchanged=$productionUnchanged; immutableBaselineUnchanged=$baselineUnchanged
    queryCloseReceipts='Synthetic report corruption after real successful observe/token close; not real Windows close failures'
    targetsRetained=$target; workingCopyMovedToTrash=$trashWorking; temporaryMovedToTrash=$trashTemp
    immutableBaseline=$baseline; exactMutatedSourcesAndDLLsRetained=$true
    bytesUnderControlRoot=(Get-ChildItem -LiteralPath $controlRoot -Recurse -File | Measure-Object Length -Sum).Sum
}
Save-Json (Join-Path $evidence 'SUMMARY.json') $summary
Write-Text (Join-Path $evidence 'COMPLETED') ('All 13 test invocations matched their exact semantic oracles.' + $lf)
Write-Host ('Completed controls: ' + $evidence)
