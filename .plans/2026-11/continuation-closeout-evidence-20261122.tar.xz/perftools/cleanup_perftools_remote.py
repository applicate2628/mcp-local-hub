"""One authorized perftools root, direct rename to trash; no deletion or old-root writes."""
import datetime, hashlib, json, os, stat, subprocess
from pathlib import Path

SRC = Path(r'D:\dev\ChatGPT\mcp-perftools-probe-20261122-e21a1792')
DST = Path(r'D:\dev\ChatGPT\trash\mcp-perftools-probe-20261122-e21a1792')
RECEIPT = Path(r'D:\dev\ChatGPT\mcp-perftools-closeout-20261122-e21a1792.json')
PUBLISHED = '1eb934595d3c21954d0bddb934be57a3fe3138cf'
record = {'schema': 'perftools-trash-closeout-v1', 'source': str(SRC), 'destination': str(DST),
          'published_commit': PUBLISHED, 'state': 'checking', 'queries': [],
          'limits': ['Available command lines and executable paths only; inaccessible commands and process working directories are not proven idle.',
                     'No general process-tree settlement guarantee; settled command receipts and path observations are recorded.'],
          'deletion_attempted': False, 'trash_emptied': False,
          'inventory_definition': 'SHA256 of UTF-8 json.dumps({files: sorted([relative_POSIX_path, byte_size, SHA256_file_bytes]), directories: sorted(relative_POSIX_paths_including_dot)}, ensure_ascii=False, sort_keys=True, separators=(comma,colon)); strict os.walk(onerror=raise); no reparse points'}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Reparse path: ' + str(item))


def save():
    record['updated_utc'] = now()
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')


def query(env):
    ps = str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/powershell.exe')
    script = "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath | ConvertTo-Json -Compress"
    result = subprocess.run([ps, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
                            cwd=SRC.parent, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode or result.stderr:
        raise RuntimeError('Process query failed: ' + result.stderr.decode('utf-8', errors='replace'))
    rows = json.loads(result.stdout.decode('utf-8-sig'))
    if isinstance(rows, dict):
        rows = [rows]
    needle = str(SRC).casefold()
    hits = []
    for row in rows:
        for field in ('CommandLine', 'ExecutablePath'):
            text = (row.get(field) or '').replace('/', '\\').casefold()
            tails = text.split(needle)[1:]
            if any(not tail or tail[0] in ('\\', chr(34), chr(39), ' ', '\t', '\r', '\n') for tail in tails):
                hits.append(row)
                break
    observation = {'utc': now(), 'rows': len(rows), 'available_command_lines': sum(bool(r.get('CommandLine')) for r in rows),
                   'unavailable_command_lines': sum(not r.get('CommandLine') for r in rows), 'exact_path_matches': hits}
    record['queries'].append(observation)
    if hits:
        raise RuntimeError('An available process references the exact source path')


def inventory(root):
    safe(root)
    files, directories, stamps = [], ['.'], {}
    def fail(error):
        raise error
    for parent, names, leaves in os.walk(root, followlinks=False, onerror=fail):
        for name in names:
            path = Path(parent) / name
            safe(path)
            directories.append(path.relative_to(root).as_posix())
        for name in leaves:
            path = Path(parent) / name
            safe(path)
            before = path.stat()
            if not stat.S_ISREG(before.st_mode):
                raise RuntimeError('Nonregular file: ' + str(path))
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1048576), b''):
                    digest.update(block)
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise RuntimeError('File changed while hashing: ' + str(path))
            relative = path.relative_to(root).as_posix()
            files.append([relative, after.st_size, digest.hexdigest()])
            stamps[relative] = [after.st_size, after.st_mtime_ns]
    files.sort()
    directories.sort()
    payload = json.dumps({'files': files, 'directories': directories}, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'files': len(files), 'directories_including_root': len(directories), 'bytes': sum(x[1] for x in files),
            'inventory_sha256': hashlib.sha256(payload).hexdigest()}, stamps


assert os.name == 'nt' and SRC.parent == RECEIPT.parent and DST.parent.parent == SRC.parent
os.chdir(SRC.parent)
assert SRC.is_dir() and DST.parent.is_dir() and not DST.exists() and not RECEIPT.exists()
safe(SRC)
safe(DST.parent)
assert SRC.stat().st_dev == DST.parent.stat().st_dev
try:
    settled = []
    for phase in ('prepare', 'format', 'control', 'candidate', 'build', 'vet'):
        row = json.loads((SRC / 'evidence' / phase / 'receipt.json').read_text(encoding='utf-8'))
        assert row['completed'] and not row.get('retain_workspace_descendants_unresolved')
        assert row['head_before'] == row['head_after'] == '99dd76ccd453ccd56d9adbcd6f4d4d06ce5cb57c'
        for command in row['commands']:
            assert not command.get('timed_out') and command['exit_code'] == command['expected_exit']
            settled.append({'phase': phase, 'label': command['label'], 'exit_code': command['exit_code'], 'expected_exit': command['expected_exit'], 'pid': command['pid']})
    assert hashlib.sha256((SRC / 'exports/probe-evidence.tar.xz').read_bytes()).hexdigest() == '4e4ac9ed77107ca156405e09238a3b2b48ced4f6af1359719488e09430b8c3a8'
    record['settled_commands'] = settled
    runtime = SRC / 'runtime/vet'
    env = dict(os.environ)
    env.update(USERPROFILE=str(runtime / 'profile'), APPDATA=str(runtime / 'appdata'), LOCALAPPDATA=str(runtime / 'localappdata'), TEMP=str(runtime / 'tmp'), TMP=str(runtime / 'tmp'), TMPDIR=str(runtime / 'tmp'),
               PSModuleAnalysisCachePath='NUL', POWERSHELL_TELEMETRY_OPTOUT='1', POWERSHELL_UPDATECHECK='Off', PSModulePath=str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/Modules'))
    query(env)
    print('Receipts settled; first exact-path query clear', flush=True)
    before, stamps = inventory(SRC)
    record['before'] = before
    print(json.dumps({'before': before}), flush=True)
    query(env)
    current_inventory, current = inventory(SRC)
    if current != stamps or current_inventory != before:
        raise RuntimeError('File inventory changed after the process query')
    record['state'] = 'prepared_to_move'
    save()
    os.rename(SRC, DST)
    record['state'] = 'moved_verifying'
    save()
    after, _ = inventory(DST)
    record['after'] = after
    record['inventory_equal'] = before == after
    record['source_absent'] = not os.path.lexists(SRC)
    assert record['inventory_equal'] and record['source_absent']
    record['state'] = 'complete'
    save()
    print(json.dumps(record), flush=True)
except BaseException as error:
    record['state'] = 'stopped'
    record['error'] = repr(error)
    record['source_exists'] = SRC.exists()
    record['destination_exists'] = DST.exists()
    save()
    raise
