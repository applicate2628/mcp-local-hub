"""Decode the pinned source-only packet into this task's new directory."""
from pathlib import Path, PurePosixPath
import base64
import hashlib
import io
import json
import zipfile

root = Path(r'D:\dev\ChatGPT\mcp-scheduler-20261122-e21a1792')
if Path(__file__).resolve().parent != root or root.is_symlink() or root.lstat().st_file_attributes & 0x400:
    raise SystemExit('Unexpected staging directory')
raw = base64.b64decode(''.join((root / 'inputs.zip.b64').read_text('ascii').split()), validate=True)
if len(raw) != 388710 or hashlib.sha256(raw).hexdigest() != '64ad591f0b75ac374b015216f2a6647fdcfed5003372ce23d5bcc1f952a35f3f':
    raise SystemExit('Archive transfer differs')
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    names = {'manifest.json', 'master-tree.json', 'control/' + manifest['control']['path']}
    names.update('overlays/' + row['path'] for row in manifest['files'])
    if len(archive.namelist()) != len(names) or set(archive.namelist()) != names:
        raise SystemExit('Archive membership differs')
    for name in sorted(names):
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or str(path) != name:
            raise SystemExit('Nonlocal member refused')
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        for directory in target.parents:
            if directory == root or root in directory.parents:
                if directory.is_symlink() or directory.lstat().st_file_attributes & 0x400:
                    raise SystemExit('Reparse destination refused')
        with target.open('xb') as stream:
            stream.write(archive.read(name))
with (root / 'inputs.zip').open('xb') as stream:
    stream.write(raw)
print(json.dumps({'staged_members': len(names), 'archive_bytes': len(raw), 'manifest_sha256': hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()}))
