"""Prepare exact repository overlays locally; no compilation or execution."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/ef942c6ee5ce/mcphub-audit-20261121/repo')
MASTER = '75dbc6406123e22468f168b861d5e0622c9d5769'
BASE = 'a7d92d2852c4f6eb8afb0569ef76a545e38aacf7'
PR660 = '1cffaab021686a7ae27a5ffc038f280160f96a60'
PR665 = 'b5cd530969b7089e7d7cbaf5308543be8c443f8c'
CHECKPOINT = '858812988833a84368c60fba1540ae601155fa71'
TEST = 'internal/api/install_backend_hold_composition_windows_test.go'
COMPOSED = 'internal/api/install_parsed_manifest.go'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

changed = git('diff', '--name-only', BASE, PR660, '--', '*.go').decode().splitlines()
helper = git('diff', '--name-only', CHECKPOINT, PR665, '--', '*.go').decode().splitlines()
assert len(changed) == 27 and len(helper) == 5
assert not set(changed) & set(helper)
overlaps = set(changed) & set(git('diff', '--name-only', BASE, MASTER).decode().splitlines())
assert overlaps == {COMPOSED}
files = []
for path in changed + helper:
    owner = PR660 if path in changed else PR665
    raw = git('show', owner + ':' + path)
    try:
        original = git('show', MASTER + ':' + path)
    except subprocess.CalledProcessError:
        original = None
    origin = {'commit': owner, **digest(raw)}
    if path == COMPOSED:
        assert original is not None
        anchor = b'\t\t\t\t\t\t!errors.As(err, &incomplete) && !errors.As(err, &forward) &&\n'
        addition = b'\t\t\t\t\t\tlen(installSchedulerRecoveryTasks(err)) == 0 &&\n'
        assert original.count(anchor) == 1 and addition not in original
        raw = original.replace(anchor, anchor + addition)
        # The only #660 change to the original base is this same insertion.
        base_raw = git('show', BASE + ':' + path)
        assert git('show', PR660 + ':' + path) == base_raw.replace(anchor, anchor + addition)
        origin['composition'] = 'master plus the sole PR660 recovery-classification guard'
    target = ROOT / 'overlays' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    files.append({'path': path, 'source': digest(original) if original is not None else None,
                  'candidate': digest(raw), 'origin': origin})
raw = (ROOT / 'overlays' / TEST).read_bytes()
files.append({'path': TEST, 'source': None, 'candidate': digest(raw), 'origin': {'kind': 'new composition regression test'}})

# The control models incorrect whole-file composition losing the two master invariants.
candidate = (ROOT / 'overlays' / COMPOSED).read_bytes()
control = candidate.replace(b'\t\tBackendRunHold:          prior.BackendRunHold.clone(),\n', b'')
probe = (b'\tprobe := desired\n\tif desired != nil && !desired.BackendRunHold.IsZero() {\n'
         b'\t\t// The temporary write probe has no authority to carry a real hold.\n'
         b'\t\tprobe = cloneSupervisorIntentFile(desired)\n'
         b'\t\tprobe.BackendRunHold = SupervisorBackendRunHold{}\n\t}\n'
         b'\tif err := WriteSupervisorIntent(tmp, probe); err != nil {\n')
assert control.count(probe) == 1
control = control.replace(probe, b'\tif err := WriteSupervisorIntent(tmp, desired); err != nil {\n')
assert control != candidate
target = ROOT / 'control' / COMPOSED
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(control)

tracked = []
for entry in git('ls-tree', '-r', '-z', MASTER).split(b'\0'):
    if not entry:
        continue
    header, path = entry.split(b'\t', 1)
    mode, kind, blob = header.decode().split()
    assert kind == 'blob', (path, kind)
    tracked.append({'path': path.decode(), 'mode': mode, 'git_blob': blob})
(ROOT / 'master-tree.json').write_text(json.dumps(tracked, indent=2) + '\n', encoding='utf-8')
roots = [
    'TestInstallMergePreservesBackendRunHold',
    'TestInstallPreflightPreservesBackendRunHold',
    'TestExecuteInstallToPruneSnapshotBeforeDelete',
    'TestExecuteInstallToPruneRequiresRecoveryBeforeDelete',
    'TestExecuteInstallToPruneDeleteUnconfirmedStopsAndRollsBack',
    'TestExecuteInstallToPruneRollbackObservation',
    'TestExecuteInstallToPruneRollbackPreservesExternalOccupant',
    'TestExecuteAdoptPruneRecoveryPreservesProvenance',
    'TestExecuteInstallToCurrentAndEarlierRecoveryNames',
    'TestInstallSchedulerRecoveryTasksClassifiesCurrentAndLater',
]
manifest = {'schema': 1, 'source_head': MASTER, 'source_tree': git('rev-parse', MASTER+'^{tree}').decode().strip(),
            'source_pr660': PR660, 'source_api_testmain': PR665, 'files': files,
            'control': {'path': COMPOSED, **digest(control)}, 'required_roots': roots,
            'master_tree_manifest': digest((ROOT / 'master-tree.json').read_bytes()),
            'native_scheduler_operations': False, 'installed_product_execution': False,
            'test_owned_loopback_port_probe': 'TestExecuteAdoptPruneRecoveryPreservesProvenance; listener.Close before returning port',
            'source_overlaps': sorted(overlaps)}
(ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(ROOT / 'inputs.zip', 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for file in sorted([ROOT / 'manifest.json', ROOT / 'master-tree.json', *list((ROOT / 'overlays').rglob('*.go')), *list((ROOT / 'control').rglob('*.go'))]):
        z.write(file, file.relative_to(ROOT).as_posix())
print(json.dumps({'overlays': len(files), 'source_files': len(tracked), 'manifest': digest((ROOT/'manifest.json').read_bytes()), 'archive': digest((ROOT/'inputs.zip').read_bytes())}))
