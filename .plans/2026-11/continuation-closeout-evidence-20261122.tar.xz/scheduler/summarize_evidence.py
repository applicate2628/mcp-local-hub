"""Verify downloaded raw evidence and derive a compact, explicitly scoped summary."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw-evidence'
manifest = json.loads((RAW / 'manifest.json').read_bytes())
export = json.loads((ROOT / 'export-receipt.json').read_bytes())
assert hashlib.sha256((ROOT / export['archive']).read_bytes()).hexdigest() == export['sha256']
rows = []
for phase in ('format', 'control', 'candidate', 'build', 'vet'):
    directory = RAW / 'evidence' / phase
    receipt = json.loads((directory / 'receipt.json').read_bytes())
    assert receipt['completed'] and receipt['qualification_status'] == 'PASS'
    assert receipt['source_before'] == receipt['source_after']
    assert receipt['temporary_residue'] == []
    assert receipt['manifest_sha256'] == hashlib.sha256((RAW / 'manifest.json').read_bytes()).hexdigest()
    assert receipt['runner_sha256'] == hashlib.sha256((RAW / 'qualify_scheduler.py').read_bytes()).hexdigest()
    counts = {}
    if phase in ('control', 'candidate'):
        events = [json.loads(line) for line in (directory / 'test.stdout.log').read_text().splitlines()]
        for kind in ('pass', 'fail', 'skip'):
            names = [event.get('Test') for event in events if event.get('Action') == kind]
            counts[kind] = {'roots': sum(bool(name) and '/' not in name for name in names),
                            'subtests': sum(bool(name) and '/' in name for name in names),
                            'packages': names.count(None)}
        expected_kind = 'pass' if phase == 'candidate' else 'fail'
        expected_roots = manifest['required_roots'] if phase == 'candidate' else manifest['required_roots'][:2]
        actual_roots = [event['Test'] for event in events if event.get('Action') == expected_kind and event.get('Test') and '/' not in event['Test']]
        assert Counter(actual_roots) == Counter(expected_roots)
        assert counts['skip'] == {'roots': 0, 'subtests': 0, 'packages': 0}
    rows.append({'phase': phase, 'command_outcome': receipt['command_outcome'],
                 'commands': [{'label': r['label'], 'exit_code': r['exit_code'],
                               'seconds': r['seconds'], 'timed_out': r['timed_out']} for r in receipt['commands']],
                 'terminal_counts': counts, 'source_before_after_equal': True,
                 'own_tmp_empty_after_exit': True, 'raw_receipt': 'evidence/' + phase + '/receipt.json'})
file = next(item for item in manifest['files'] if item['path'] == 'internal/api/install_parsed_manifest.go')
assert file['origin']['git_blob'] == manifest['control']['git_blob']
summary = {
    'schema': 1,
    'scope': 'Exact master + PR660 + five PR665 API TestMain isolation files + two new Windows composition test roots; not standalone PR660',
    'source_head': manifest['source_head'], 'source_tree': manifest['source_tree'],
    'source_pr660': manifest['source_pr660'], 'source_api_testmain': manifest['source_api_testmain'],
    'overlay_files': len(manifest['files']), 'master_tracked_files': 3270,
    'source_overlaps': manifest['source_overlaps'],
    'control_equals_historical_pr660_install_file': True,
    'control_meaning': 'Incorrect whole-file overlay on newer master drops two master hold invariants; no claim that normal Git merge drops them or standalone PR660 fails these tests',
    'required_roots': manifest['required_roots'],
    'phases': rows,
    'source_inventory_before_build': json.loads((RAW / 'evidence/source-inventory-before-build.json').read_bytes()),
    'source_inventory_after_vet': json.loads((RAW / 'evidence/source-inventory-after-vet.json').read_bytes()),
    'raw_archive': {key: export[key] for key in ('archive', 'bytes', 'sha256')},
    'raw_archive_members': len(export['members']),
    'native_scheduler_operations': 'NOT_RUN',
    'installed_hub_product_or_serena': 'NOT_RUN',
    'full_default_or_tagged_go_tests': 'NOT_RUN',
    'standalone_pr660_runtime_qualification': 'NOT_RUN',
    'whole_process_tree_deadline_and_settlement': 'NOT_PROVEN',
    'external_exact_published_commit_review': 'NOT_RUN',
    'approval_review_rejections_observed': False,
    'execution_observation_limit': 'RDC session lookup was lost for test launchers; immutable on-disk receipts and logs were retrieved. No uncertain launch was repeated. Direct retained Popen handles settled without timeout.',
    'residual': 'Windows ListContext ownership compares short usernames. Domain/SID identity, native Run/RunOwned/Stop/Delete, cancellation/process tree lifetime, external replacement and snapshot retention remain open.',
}
with (ROOT / 'qualification.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps({'phases': rows, 'summary': 'qualification.json'}, indent=2))
