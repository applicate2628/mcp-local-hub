"""Close only the published Scheduler qualification root by direct trash rename."""
import datetime, hashlib, json, os, stat, subprocess
from pathlib import Path, PurePosixPath

SRC = Path(r'D:\dev\ChatGPT\mcp-scheduler-20261122-e21a1792')
DST = Path(r'D:\dev\ChatGPT\trash\mcp-scheduler-20261122-e21a1792')
RECEIPT = Path(r'D:\dev\ChatGPT\mcp-scheduler-closeout-20261122-e21a1792.json')
PUBLISHED = '0bdb725ed261c532eba07d645c2a14880d12b9fd'
ARCHIVE_SHA = '52c1c863b1438c380d0c8c808a18a0f136c37765127bd48de6cc43f84a240728'
record = {'schema': 'scheduler-trash-closeout-v1', 'source': str(SRC), 'destination': str(DST),
          'published_commit': PUBLISHED, 'publication_readback_confirmed_by': 'parent agent',
          'helper_sha256': _closeout_source_sha256, 'state': 'checking', 'queries': [],
          'limits': ['Available command lines and executable paths only; inaccessible commands and process working directories are not proven idle.',
                     'No general process-tree settlement guarantee; settled command receipts and path observations are recorded.'],
          'inventory_algorithm': 'SHA256 of UTF-8 compact JSON, sort_keys=True, ensure_ascii=False; sorted files [relative POSIX path,bytes,SHA256] and sorted directories including dot root.',
          'deletion_attempted': False, 'trash_emptied': False}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def safe(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Reparse path: ' + str(item))

def fail(error):
    raise error

def save():
    record['updated_utc'] = now()
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')

def query(env):
    ps = str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/powershell.exe')
    script = "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath | ConvertTo-Json -Compress"
    result = subprocess.run([ps, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
                            cwd=SRC.parent, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode or result.stderr:
        raise RuntimeError('Process query failed: ' + result.stderr.decode('utf-8', errors='replace'))
    rows = json.loads(result.stdout.decode('utf-8-sig'))
    if isinstance(rows, dict):
        rows = [rows]
    needle = str(SRC).casefold()
    hits = []
    for row in rows:
        for field in ('CommandLine', 'ExecutablePath'):
            text = (row.get(field) or '').replace('/', '\\').casefold()
            tails = text.split(needle)[1:]
            if any(not tail or tail[0] in ('\\', chr(34), chr(39), ' ', '\t', '\r', '\n') for tail in tails):
                hits.append(row)
                break
    record['queries'].append({'utc': now(), 'rows': len(rows),
                             'available_command_lines': sum(bool(r.get('CommandLine')) for r in rows),
                             'unavailable_command_lines': sum(not r.get('CommandLine') for r in rows),
                             'exact_path_matches': hits})
    if hits:
        raise RuntimeError('An available process references the exact source path')

def inventory(root, hash_content):
    safe(root)
    files, directories, stamps = [], ['.'], {}
    for parent, names, leaves in os.walk(root, followlinks=False, onerror=fail):
        for name in names:
            path = Path(parent) / name
            safe(path)
            info = path.lstat()
            if not stat.S_ISDIR(info.st_mode):
                raise RuntimeError('Nonordinary directory: ' + str(path))
            relative = path.relative_to(root).as_posix()
            directories.append(relative)
            stamps[relative + '/'] = [info.st_mtime_ns]
        for name in leaves:
            path = Path(parent) / name
            safe(path)
            before = path.lstat()
            if not stat.S_ISREG(before.st_mode):
                raise RuntimeError('Nonregular file: ' + str(path))
            digest = hashlib.sha256()
            if hash_content:
                with path.open('rb') as stream:
                    for block in iter(lambda: stream.read(1048576), b''):
                        digest.update(block)
            after = path.lstat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise RuntimeError('File changed while hashing: ' + str(path))
            relative = path.relative_to(root).as_posix()
            files.append([relative, after.st_size, digest.hexdigest()])
            stamps[relative] = [after.st_size, after.st_mtime_ns]
    files.sort()
    directories.sort()
    payload = json.dumps({'files': files, 'directories': directories}, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'files': len(files), 'directories_including_root': len(directories), 'bytes': sum(x[1] for x in files),
            'inventory_sha256': hashlib.sha256(payload).hexdigest()}, stamps


OUT = Path(r'D:\dev\ChatGPT\mcp-scheduler-closeout-diagnostic-20261122-e21a1792.json')
assert os.name == 'nt' and not os.path.lexists(OUT)

def detailed():
    summary, _ = inventory(SRC, True)
    metadata = {}
    for parent, names, leaves in os.walk(SRC, followlinks=False, onerror=fail):
        for name in ['.', *names, *leaves]:
            path = Path(parent) if name == '.' else Path(parent) / name
            safe(path)
            info = path.lstat()
            key = path.relative_to(SRC).as_posix()
            metadata[key] = {'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file', 'size': info.st_size,
                             'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns, 'atime_ns': info.st_atime_ns}
    return {'summary': summary, 'metadata': metadata}

def differences(before, after):
    return [{'path': key, 'before': before.get(key), 'after': after.get(key)}
            for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]

vet = json.loads((SRC / 'evidence/vet/receipt.json').read_bytes())
env = dict(os.environ)
env.update(vet['environment'])
env.update(PSModuleAnalysisCachePath='NUL', POWERSHELL_TELEMETRY_OPTOUT='1', POWERSHELL_UPDATECHECK='Off')
first = detailed()
query(env)
second = detailed()
third = detailed()
result = {'schema': 1, 'observed_utc': now(), 'source': str(SRC), 'helper_sha256': _closeout_source_sha256,
          'query': record['queries'], 'before_query': first['summary'], 'after_query': second['summary'],
          'subsequent_without_query': third['summary'],
          'query_metadata_delta': differences(first['metadata'], second['metadata']),
          'subsequent_metadata_delta': differences(second['metadata'], third['metadata']),
          'source_exists': SRC.is_dir(), 'destination_exists': os.path.lexists(DST),
          'move_attempted': False, 'deletion_attempted': False}
with OUT.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result), flush=True)
