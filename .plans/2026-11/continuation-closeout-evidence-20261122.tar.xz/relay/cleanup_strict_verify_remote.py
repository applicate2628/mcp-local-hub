"""Read the moved Relay tree with fail-closed traversal; never move or delete."""
import datetime, hashlib, json, os, stat
from pathlib import Path

SOURCE = Path(r'D:\dev\ChatGPT\mcp-relay-20261122-e21a1792')
ROOT = Path(r'D:\dev\ChatGPT\trash\mcp-relay-20261122-e21a1792')
RECEIPT = Path(r'D:\dev\ChatGPT\mcp-relay-closeout-20261122-e21a1792.json')
record = json.loads(RECEIPT.read_text(encoding='utf-8'))
assert record['state'] == 'complete' and record['inventory_equal']
assert record['source'] == str(SOURCE) and record['destination'] == str(ROOT)
assert not os.path.lexists(SOURCE)


def checked(path, directory):
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
        raise RuntimeError('Reparse path: ' + str(path))
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise RuntimeError('Unexpected file kind: ' + str(path))
    return info


def failed(error):
    raise error


verification = {'method': 'os.walk(followlinks=False,onerror=raise), lstat every file/directory, SHA-256 every byte',
                'move_repeated': False, 'deletion_attempted': False,
                'cleanup_source_sha256': '7c3e364f08ad261157ebb3e74f719154f4cda7ad489f19b995efbed993a08e9d',
                'verification_source_sha256': CHECKER_SHA}
try:
    for parent in (ROOT, *ROOT.parents):
        checked(parent, True)
    files, directories = [], ['.']
    for parent, names, leaves in os.walk(ROOT, followlinks=False, onerror=failed):
        checked(Path(parent), True)
        for name in names:
            path = Path(parent) / name
            checked(path, True)
            directories.append(path.relative_to(ROOT).as_posix())
        for name in leaves:
            path = Path(parent) / name
            before = checked(path, False)
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1048576), b''):
                    digest.update(block)
            after = checked(path, False)
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            files.append([path.relative_to(ROOT).as_posix(), after.st_size, digest.hexdigest()])
    files.sort()
    directories.sort()
    raw = json.dumps({'files': files, 'directories': directories}, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    summary = {'files': len(files), 'directories_including_root': len(directories),
               'bytes': sum(x[1] for x in files), 'inventory_sha256': hashlib.sha256(raw).hexdigest()}
    assert summary == record['before'] == record['after']
    verification.update(state='complete', inventory=summary, equal_to_before_and_after=True, traversal_errors=0, reparse_paths=0)
except BaseException as error:
    verification.update(state='failed', error=repr(error))
    raise
finally:
    verification['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['strict_walk_verification'] = verification
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record), flush=True)
