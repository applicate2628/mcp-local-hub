"""One authorized Relay root, direct rename to trash; no deletion or old-root writes."""
import datetime, hashlib, json, os, stat, subprocess
from pathlib import Path

SRC = Path(r'D:\dev\ChatGPT\mcp-relay-20261122-e21a1792')
DST = Path(r'D:\dev\ChatGPT\trash\mcp-relay-20261122-e21a1792')
RECEIPT = Path(r'D:\dev\ChatGPT\mcp-relay-closeout-20261122-e21a1792.json')
PUBLISHED = 'f11cd6cf1f4031f3a2d7db60fb5d4edf19d0a4da'
record = {'schema': 'relay-trash-closeout-v1', 'source': str(SRC), 'destination': str(DST),
          'published_commit': PUBLISHED, 'state': 'checking', 'queries': [],
          'limits': ['Available command lines and executable paths only; inaccessible commands and process working directories are not proven idle.',
                     'No general process-tree settlement guarantee; settled command receipts and path observations are recorded.'],
          'deletion_attempted': False, 'trash_emptied': False}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe(path):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Reparse path: ' + str(item))


def save():
    record['updated_utc'] = now()
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')


def query(env):
    ps = str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/powershell.exe')
    script = "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath | ConvertTo-Json -Compress"
    result = subprocess.run([ps, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
                            cwd=SRC.parent, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode or result.stderr:
        raise RuntimeError('Process query failed: ' + result.stderr.decode('utf-8', errors='replace'))
    rows = json.loads(result.stdout.decode('utf-8-sig'))
    if isinstance(rows, dict):
        rows = [rows]
    needle = str(SRC).casefold()
    hits = []
    for row in rows:
        for field in ('CommandLine', 'ExecutablePath'):
            text = (row.get(field) or '').replace('/', '\\').casefold()
            tails = text.split(needle)[1:]
            if any(not tail or tail[0] in ('\\', chr(34), chr(39), ' ', '\t', '\r', '\n') for tail in tails):
                hits.append(row)
                break
    observation = {'utc': now(), 'rows': len(rows), 'available_command_lines': sum(bool(r.get('CommandLine')) for r in rows),
                   'unavailable_command_lines': sum(not r.get('CommandLine') for r in rows), 'exact_path_matches': hits}
    record['queries'].append(observation)
    if hits:
        raise RuntimeError('An available process references the exact source path')


def inventory(root):
    safe(root)
    files, directories, stamps = [], ['.'], {}
    for parent, names, leaves in os.walk(root, followlinks=False):
        for name in names:
            path = Path(parent) / name
            safe(path)
            directories.append(path.relative_to(root).as_posix())
        for name in leaves:
            path = Path(parent) / name
            safe(path)
            before = path.stat()
            if not stat.S_ISREG(before.st_mode):
                raise RuntimeError('Nonregular file: ' + str(path))
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1048576), b''):
                    digest.update(block)
            after = path.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise RuntimeError('File changed while hashing: ' + str(path))
            relative = path.relative_to(root).as_posix()
            files.append([relative, after.st_size, digest.hexdigest()])
            stamps[relative] = [after.st_size, after.st_mtime_ns]
    files.sort()
    directories.sort()
    payload = json.dumps({'files': files, 'directories': directories}, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'files': len(files), 'directories_including_root': len(directories), 'bytes': sum(x[1] for x in files),
            'inventory_sha256': hashlib.sha256(payload).hexdigest()}, stamps


assert os.name == 'nt' and SRC.parent == RECEIPT.parent and DST.parent.parent == SRC.parent
assert SRC.is_dir() and DST.parent.is_dir() and not DST.exists() and not RECEIPT.exists()
safe(SRC)
safe(DST.parent)
assert SRC.stat().st_dev == DST.parent.stat().st_dev
try:
    settled = []
    for started in sorted((SRC / 'evidence').rglob('*.started.json')):
        path = started.with_name(started.name.replace('.started.json', '.receipt.json'))
        row = json.loads(path.read_text(encoding='utf-8'))
        assert row['settled'] and not row['timed_out'] and row['exit_code'] == 0
        assert not row.get('process_tree_unresolved') and not row.get('termination_unresolved')
        settled.append({'path': path.relative_to(SRC).as_posix(), 'exit_code': row['exit_code'], 'pid': row['pid']})
    assert len(settled) == 8
    for phase in ('neighbors', 'build', 'vet'):
        row = json.loads((SRC / 'evidence' / phase / 'summary.json').read_text())
        assert row['source_unchanged'] and row['composition_sha256'] == 'c3f0be2cd6fe0310cc7b951ebeacfc17e16629a32e98eed6af32f7fcc152fb28'
    record['settled_commands'] = settled
    env = json.loads((SRC / 'evidence/vet/input.json').read_text())['environment']
    env.update(PSModuleAnalysisCachePath='NUL', POWERSHELL_TELEMETRY_OPTOUT='1', POWERSHELL_UPDATECHECK='Off')
    query(env)
    print('Receipts settled; first exact-path query clear', flush=True)
    before, stamps = inventory(SRC)
    record['before'] = before
    print(json.dumps({'before': before}), flush=True)
    query(env)
    current = {p.relative_to(SRC).as_posix(): [p.stat().st_size, p.stat().st_mtime_ns] for p in SRC.rglob('*') if p.is_file()}
    if current != stamps:
        raise RuntimeError('File inventory changed after the process query')
    record['state'] = 'prepared_to_move'
    save()
    os.rename(SRC, DST)
    record['state'] = 'moved_verifying'
    save()
    after, _ = inventory(DST)
    record['after'] = after
    record['inventory_equal'] = before == after
    record['source_absent'] = not os.path.lexists(SRC)
    assert record['inventory_equal'] and record['source_absent']
    record['state'] = 'complete'
    save()
    print(json.dumps(record), flush=True)
except BaseException as error:
    record['state'] = 'stopped'
    record['error'] = repr(error)
    record['source_exists'] = SRC.exists()
    record['destination_exists'] = DST.exists()
    save()
    raise
