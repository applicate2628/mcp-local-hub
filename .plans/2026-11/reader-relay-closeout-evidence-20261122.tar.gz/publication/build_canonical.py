from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'publication/canonical/.plans/2026-11'
plan = OUT / 'open-pr-integration-20261117.md'
original = plan.read_bytes()
assert hashlib.sha256(original).hexdigest() == '04c08383c6c174571e9b3268db63dbb0aabdd174d2fd4094199d76976a88b9a6'
(ROOT / 'publication/canonical-plan-before-cleanup.md').write_bytes(original)
text = original.decode()
old = 'Уборка собственных копий — **PENDING**; факты переноса будут закреплены в [квитанции Reader/Relay](reader-relay-closeout-20261122.json).'
new = 'Собственная Windows-копия перенесена в trash после публикации и сверки: 7 042 файла, 483 каталога, 136 416 620 байт и полный инвентарь совпали; исходный путь отсутствует. Локальная рабочая копия пока нужна для обратного чтения этого документа. [Квитанция Reader/Relay](reader-relay-closeout-20261122.json).'
assert text.count(old) == 1
text = text.replace(old, new)
old = '**Уборка собственных копий — PENDING.** Фактические наблюдения и результат trash-first переноса будут внесены в [квитанцию Reader/Relay](reader-relay-closeout-20261122.json). До этого перенос, инвентари и отсутствие исходного пути не заявляются.'
new = '**Windows-копия перенесена непосредственно в trash.** До и после совпали **7 042 файла, 483 каталога с корнем и 136 416 620 байт**; SHA-256 полного инвентаря — `b1aa86d07921e9589f2c9815c95702f54b2da05bee88392babe62154e914ee17`. Исходный путь отсутствует. Две проверки доступных командных строк не нашли точного пути; 180 строк были недоступны, поэтому общей гарантии покоя системы нет. Проверены 20 итоговых квитанций и 706 записей завершённых дочерних команд. Helper и публикационный input закреплены; до исполнения исправлены два замечания ревью об учёте formatter-журналов и shell-разделителей. Обязательные квитанции и восстановление сохранены вне trash; общие кэши и старые рабочие области не перемещались, trash не очищался. Точные данные — [квитанция Reader/Relay](reader-relay-closeout-20261122.json). Локальная исходная копия сохраняется до обратного чтения публикации этого плана.'
assert text.count(old) == 1
text = text.replace(old, new)
text = text.replace('Новая read-only [привязка источников]', 'Новая [привязка источников без исполнения]')
text = text.replace('POST-origin resumption не реализовано, GET→405 из #626 его не квалифицирует.', 'Возобновление SSE-ответа, начатого POST, не реализовано; прежний GET→405 из #626 не проверял возобновление потока.')
plan.write_text(text)
(OUT / 'archguard-source-binding-20261122.json').write_bytes((ROOT / 'p0/archguard-source-binding.json').read_bytes())

receipt = json.loads((ROOT / 'cleanup/observed/cleanup-receipt.json').read_bytes())
assert receipt['state'] == 'complete' and receipt['source_absent'] and receipt['inventory_equal']
assert receipt['before'] == receipt['after'] and len(receipt['settled_commands']) == 706
before = (ROOT / 'cleanup/observed/inventory-before.json').read_bytes()
assert before == (ROOT / 'cleanup/observed/inventory-after.json').read_bytes()
assert hashlib.sha256(before).hexdigest() == receipt['before']['inventory_sha256']

paths = set()
for directory in ('cleanup', 'publication/recovery', 'qualification/preparation', 'qualification/staging-raw', 'p0'):
    for path in (ROOT / directory).rglob('*'):
        if path.is_file() and not path.name.endswith('.b64'):
            paths.add(path)
for path in (ROOT / 'publication').iterdir():
    if path.is_file() and path.suffix in ('.json', '.diff'):
        paths.add(path)
for name in ('root-own-review.json', 'build_publication.py', 'import_raw_phase.py'):
    paths.add(ROOT / 'qualification' / name)
paths.add(Path(__file__).resolve())
entries, contents = [], {}
for path in sorted(paths):
    assert not path.is_symlink()
    name = str(path.relative_to(ROOT))
    raw = path.read_bytes()
    contents[name] = raw
    entries.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
contents['INVENTORY.json'] = (json.dumps({'schema': 1, 'indexed_files': len(entries), 'total_regular_members': len(entries) + 1, 'files': entries}, ensure_ascii=False, indent=2) + '\n').encode()
archive_path = OUT / 'reader-relay-closeout-evidence-20261122.tar.gz'
with archive_path.open('xb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(contents.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(contents) and all(x.isfile() for x in members)
    assert {x.name for x in members} == set(contents)
    for member in members:
        assert archive.extractfile(member).read() == contents[member.name]
raw = archive_path.read_bytes()
archive = {'path': archive_path.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
           'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
           'indexed_files': len(entries), 'total_regular_members': len(contents)}
closeout = {
    'schema': 1, 'scope': 'Second reader/relay increment on 2026-11-22; exact code publication and owned Windows cleanup',
    'canonical_parent': 'b4bb85c2a099916974c55a69490c6644702b6fe0',
    'code_publication_readback': json.loads((ROOT / 'publication/publication-readback.json').read_bytes()),
    'raw_archive': archive,
    'windows_cleanup': {k: receipt[k] for k in ('schema', 'source', 'destination', 'retained_directory', 'state', 'queries', 'move_attempted', 'deletion_attempted', 'trash_emptied', 'limits', 'inventory_definition', 'input_sha256', 'helper_sha256', 'before', 'after', 'inventory_equal', 'source_absent')},
    'windows_cleanup_raw_receipt': {'path_in_archive': 'cleanup/observed/cleanup-receipt.json', 'sha256': hashlib.sha256((ROOT / 'cleanup/observed/cleanup-receipt.json').read_bytes()).hexdigest(), 'settled_children': 706},
    'local_cleanup': {'state': 'PENDING_AFTER_CANONICAL_READBACK', 'reason': 'Source checkout is still required for byte readback of the canonical publication.'},
    'recovery': 'publication/recovery/source858-delta.json and all 28 exact delta files preserve source858 content on master75 outside trash; Git commit bytes are retained.',
    'p0': json.loads((ROOT / 'p0/archguard-source-binding.json').read_bytes()),
    'own_review': 'Requirements, correctness, safety, compatibility, complexity, qualification scope, archive members and published byte/ref binding reviewed by root.',
    'independent_review': 'Separate source, formatter, runner, runtime, packaging, canonical-plan and cleanup-source reviews retained. Cleanup input hash substitution and final observations checked by root.',
    'full_default_tests': 'NOT_RUN', 'full_tagged_tests': 'NOT_RUN', 'external_exact_head_review': 'PENDING',
    'merge_performed': False, 'force_push': False, 'donor_closed': False, 'branch_deleted': False,
    'previous_R24_R25_scope': 'Unchanged; this increment does not enlarge earlier acceptance claims.'
}
(OUT / 'reader-relay-closeout-20261122.json').write_text(json.dumps(closeout, ensure_ascii=False, indent=2) + '\n')
rows = []
for path in sorted((ROOT / 'publication/canonical').rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        rows.append({'path': str(path.relative_to(ROOT / 'publication/canonical')), 'local': str(path), 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest(), 'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()})
(ROOT / 'publication/canonical-files.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'archive': archive, 'windows_cleanup': receipt['after'], 'local_cleanup': closeout['local_cleanup']['state']}, indent=2))
