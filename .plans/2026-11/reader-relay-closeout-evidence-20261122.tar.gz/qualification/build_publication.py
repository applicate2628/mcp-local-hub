"""Create deterministic, fully indexed evidence and reviewable Git publication inputs."""
from pathlib import Path
from collections import Counter
import base64
import gzip
import hashlib
import io
import json
import re
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parent.parent
Q = ROOT / 'qualification'
component = sys.argv[1]
assert component in ('reader', 'relay')
folder = {'reader': 'go-reader-close-errors-20261122', 'relay': 'relay-session-retry-20261122'}[component]
out = ROOT / 'publication' / component
out.mkdir(parents=True, exist_ok=False)
target_prefix = 'docs/modernization/verification/' + folder
docs = out / target_prefix
docs.mkdir(parents=True)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def write_json(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)

scope = read_json(Q / (component + '-runner-scope.json'))
phase_names = sorted(set().union(*map(set, scope['phases'].values())))
assert len(phase_names) == (6 if component == 'reader' else 12)
manifest_pins = {}
for variant in ('control', 'candidate'):
    path = Q / (component + '-qualification') / variant / 'manifest.json'
    raw = path.read_bytes()
    manifest = json.loads(raw)
    assert manifest['runner_sha256'] == scope['runner_sha256']
    for row in manifest['files']:
        source = path.parent / 'candidate' / row['path']
        content = source.read_bytes()
        assert sha(content) == row['candidate_sha256'] and blob(content) == row['candidate_git_blob']
    manifest_pins[variant] = sha(raw)

phases = []
for phase in phase_names:
    path = Q / 'raw' / phase / 'receipt.json'
    raw = path.read_bytes()
    receipt = json.loads(raw)
    assert receipt['completed'] and receipt['state'] == 'complete'
    assert receipt['source_before'] == receipt['source_after'] == receipt['source_final']
    assert receipt['tracked_source_before'] == receipt['tracked_source_after']
    assert receipt['tracked_source_before']['matched_files'] == 3281
    assert receipt['tracked_source_before']['inventory_sha256'] == '2086845d9b610a74da049e4524af48df4b0d07458f31b3ad82a42739015c8345'
    assert receipt['runner_sha256'] == receipt['runner_sha256_after'] == scope['runner_sha256']
    assert receipt['manifest_sha256'] == receipt['manifest_sha256_after'] in manifest_pins.values()
    assert receipt['tools_sha256'] == receipt['tools_sha256_after']
    for command in receipt['commands'] + receipt['observations']:
        assert command['settled'] and not command['timed_out']
        for stream in ('stdout', 'stderr'):
            content = (path.parent / (command['label'] + '.' + stream + '.log')).read_bytes()
            assert len(content) == command[stream]['bytes'] and sha(content) == command[stream]['sha256']
    commands = []
    for command in receipt['commands']:
        assert command['oracle']['matched']
        result = {k: command[k] for k in ('label', 'executable', 'args', 'exit_code', 'seconds', 'settled', 'timed_out')}
        if '-json' in command['args']:
            events = [json.loads(line) for line in (path.parent / (command['label'] + '.stdout.log')).read_text().splitlines()]
            result['terminal_counts'] = {a: sum(e['Action'] == a for e in events) for a in ('pass', 'fail', 'skip')}
            result['test_counts'] = {a: sum(e['Action'] == a and bool(e.get('Test')) for e in events) for a in ('pass', 'fail', 'skip')}
            result['package_counts'] = {a: sum(e['Action'] == a and not e.get('Test') for e in events) for a in ('pass', 'fail', 'skip')}
            result['root_passes'] = [e['Test'] for e in events if e['Action'] == 'pass' and e.get('Test') and '/' not in e['Test']]
            frozen = next(c for c in scope['commands'][phase] if c['label'] == command['label'])
            actual = {a: Counter(e.get('Test') or ('PACKAGE:' + e['Package']) for e in events if e['Action'] == a) for a in ('pass', 'fail', 'skip')}
            if 'expected_tests' in frozen:
                assert actual == {a: Counter(frozen['expected_tests'][a]) for a in ('pass', 'fail', 'skip')}
            if command['exit_code'] == 0:
                assert not actual['fail'] and not actual['skip']
            for name, count in frozen.get('required_root_pass_counts', {}).items():
                assert actual['pass'][name] == count
            output = ''.join(e.get('Output', '') for e in events)
            for marker in frozen.get('required_output', []):
                assert marker in output
            if phase.endswith('-consumer'):
                result['consumer_observation'] = next(e['Output'].strip() for e in events if 'real SDK GET-SSE consumer:' in e.get('Output', ''))
        if 'binary' in command['oracle']:
            result['compile_output_observed_by_runner'] = command['oracle']['binary']
            result['compile_output_exported_or_executed'] = False
        commands.append(result)
    phases.append({'phase': phase, 'receipt_path': str(path.relative_to(ROOT)), 'receipt_sha256': sha(raw),
                   'started_moscow': receipt['started_moscow'], 'finished_moscow': receipt['finished_moscow'],
                   'source_admission': receipt['tracked_source_before'], 'commands': commands})

own_all = read_json(Q / 'root-own-review.json')
own = {'reviewer': own_all['reviewer'], 'kind': own_all['kind'], 'component': component,
       'review': own_all[component], 'global_limits': own_all['global_limits']}
own_path = Q / (component + '-own-review.json')
write_json(own_path, own)
source_review = {'own_review': own, 'independent_source_review': read_json(ROOT / 'reader/independent-review.json' if component == 'reader' else Q / 'relay-source-independent-review-preformat.json')}
if component == 'relay':
    source_review['independent_formatted_binding'] = read_json(Q / 'relay-formatted-independent-review.json')
write_json(docs / 'source-review.json', source_review)
shutil.copyfile(Q / (component + '-runtime-independent-review.json'), docs / 'runtime-review.json')
shutil.copyfile(ROOT / component / 'publication-README.md', docs / 'README.md')

code_root = ROOT / component / ('overlays' if component == 'reader' else 'formatted')
code_paths = sorted(p for p in code_root.rglob('*.go') if p.is_file())
assert len(code_paths) == (8 if component == 'reader' else 6)
candidate_manifest = read_json(Q / (component + '-qualification/candidate/manifest.json'))
candidate_map = {x['path']: x for x in candidate_manifest['files']}
for path in code_paths:
    relative = path.relative_to(code_root)
    raw = path.read_bytes()
    assert sha(raw) == candidate_map[str(relative)]['candidate_sha256']
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)

selected = set()
def add(path):
    assert path.is_file() and not path.is_symlink(), path
    selected.add(path)

for path in (ROOT / component).rglob('*'):
    if not path.is_file() or path.name.startswith('publication-'):
        continue
    if component == 'reader' and ('relay' in path.name or 'relay' in str(path.relative_to(ROOT / component)).split('/')[0]):
        continue
    add(path)
for path in Q.iterdir():
    if path.is_file() and (path.name.startswith(component) or path.name in ('generate_' + component + '_runner.py', 'make_' + component + '_manifests.py', 'prepare_source_remote.py', 'parent_relay_runner.py', 'import_raw_phase.py')):
        add(path)
for directory in [Q / (component + '-qualification'), Q / 'preparation'] + [Q / 'raw' / x for x in phase_names]:
    for path in directory.rglob('*'):
        if path.is_file():
            add(path)
for path in (Q / 'fixtures/internal' / ('api' if component == 'reader' else 'daemon')).rglob('*'):
    if path.is_file():
        add(path)
for phase in phase_names:
    add(Q / 'remote-transfers' / (phase + '-import.json'))
if component == 'relay':
    for name in ('reader_runner.py', 'reader-runner-scope.json', 'reader-runner-independent-review.json', 'reader_runner.delta.patch'):
        add(Q / name)
    for path in (ROOT / 'reader').iterdir():
        if path.is_file() and ('relay' in path.name or path.name == 'format_stage_remote.py'):
            add(path)

entries = []
contents = {}
for path in sorted(selected):
    relative = str(path.relative_to(ROOT))
    raw = path.read_bytes()
    contents[relative] = raw
    entries.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw)})
inventory = {'schema': 1, 'component': component, 'indexed_files': len(entries),
             'total_regular_members': len(entries) + 1, 'files': entries,
             'binary_exclusion': 'Compiled Linux test output is reproducible and omitted; its identity remains in the reader receipt.' if component == 'reader' else None}
contents['INVENTORY.json'] = (json.dumps(inventory, ensure_ascii=False, indent=2) + '\n').encode()
archive_path = docs / 'raw-evidence.tar.gz'
with archive_path.open('xb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(contents.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(contents) and all(m.isfile() for m in members)
    assert {m.name for m in members} == set(contents)
    for member in members:
        assert archive.extractfile(member).read() == contents[member.name]
archive_raw = archive_path.read_bytes()
summary = {'schema': 1, 'component': component, 'physical_source_commit': '858812988833a84368c60fba1540ae601155fa71',
           'physical_source_tree': 'dba685c090952a93a80a1e82403c4646ad8aaed1', 'overlay_paths': len(scope['paths']),
           'runner_sha256': scope['runner_sha256'], 'manifest_sha256': manifest_pins, 'phases': phases,
           'raw_archive': {'path': 'raw-evidence.tar.gz', 'bytes': len(archive_raw), 'sha256': sha(archive_raw), 'git_blob': blob(archive_raw),
                           'indexed_files': len(entries), 'total_regular_members': len(contents)},
           'full_default_tests': 'NOT_RUN', 'full_tagged_tests': 'NOT_RUN', 'external_exact_published_head_review': 'PENDING',
           'standalone_published_tree_tested': False, 'whole_process_tree_deadline_or_settlement_proven': False}
write_json(docs / 'runtime-summary.json', summary)
publication = []
for path in sorted(out.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        publication.append({'path': str(path.relative_to(out)), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw), 'local': str(path)})
write_json(ROOT / 'publication' / (component + '-files.json'), publication)
print(json.dumps({'component': component, 'publication_files': len(publication), 'archive': summary['raw_archive'],
                  'phase_counts': [{p['phase']: [c.get('test_counts') for c in p['commands'] if 'test_counts' in c]} for p in phases]}, indent=2))
