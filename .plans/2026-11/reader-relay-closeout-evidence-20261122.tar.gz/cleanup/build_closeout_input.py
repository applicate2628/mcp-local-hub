from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'cleanup' / 'retained'
OUT.mkdir(exist_ok=False)
readback = json.loads((ROOT / 'publication/publication-readback.json').read_bytes())
commits = ['1b7655ae9a0dec7d6821d8419087fd92ccadbb62', '4b6ec39930cb5a0498dba068b99dbf29ba7129b7']
assert readback['all_published_bytes_equal'] and readback['published_commits'] == commits
assert readback['queue']['count'] == 30 and readback['queue']['all_draft']
assert all(len(x['parents']) == 1 and x['all_published_bytes_equal'] for x in readback['publications'])

def pin(name, raw):
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

retained = []
for name, source in {
    'publication-readback.json': ROOT / 'publication/publication-readback.json',
    'reader-runtime-review.json': ROOT / 'qualification/reader-runtime-independent-review.json',
    'relay-runtime-review.json': ROOT / 'qualification/relay-runtime-independent-review.json',
    'source-copy-receipt.json': ROOT / 'qualification/preparation/source-copy-receipt.json',
}.items():
    raw = source.read_bytes()
    (OUT / name).write_bytes(raw)
    retained.append(pin(name, raw))

source_files = {}
inventory = json.loads((ROOT / 'qualification/preparation/source-copy-inventory.json').read_bytes())
assert len(inventory['files']) == 3290
for row in inventory['files']:
    name = 'source/' + row['path']
    source_files[name] = {**row, 'path': name}
for component in ('reader', 'relay'):
    for row in json.loads((ROOT / ('qualification/' + component + '-transfer.json')).read_bytes()):
        source_files[row['relative']] = {'path': row['relative'], 'bytes': row['bytes'], 'sha256': row['sha256']}

receipts = []
for path in sorted((ROOT / 'qualification/raw').glob('*/receipt.json')):
    assert path.parent.name.startswith(('reader-', 'relay-'))
    name = 'evidence/' + path.parent.name + '/receipt.json'
    row = json.loads(path.read_bytes())
    assert row['completed'] and row['state'] == 'complete'
    source_files[name] = pin(name, path.read_bytes())
    receipts.append(name)
for stage in ('reader-stage', 'relay-stage'):
    name = stage + '/receipt.json'
    path = ROOT / 'qualification/staging-raw' / name
    row = json.loads(path.read_bytes())
    assert row['completed'] and row['state'] == 'complete'
    source_files[name] = pin(name, path.read_bytes())
    receipts.append(name)
assert len(receipts) == 20

for remote, local in {
    'reader_runner.py': 'qualification/reader_runner.py',
    'relay_runner.py': 'qualification/relay_runner.py',
    'source-copy-receipt.json': 'qualification/preparation/source-copy-receipt.json',
    'source-copy-inventory.json': 'qualification/preparation/source-copy-inventory.json',
    'prepare_source_remote.py': 'qualification/prepare_source_remote.py',
}.items():
    source_files[remote] = pin(remote, (ROOT / local).read_bytes())
for row in source_files.values():
    p = PurePosixPath(row['path'])
    assert not p.is_absolute() and '..' not in p.parts

plan = {
    'schema': 'iteration-trash-closeout-input-v1', 'ready': True,
    'source': r'D:\dev\ChatGPT\mcp-next-20261122-e21a1792',
    'destination': r'D:\dev\ChatGPT\trash\mcp-next-20261122-e21a1792',
    'retained_directory': r'D:\dev\ChatGPT\mcp-next-closeout-20261122-e21a1792',
    'published_commits': commits, 'retained_files': retained,
    'source_files': [source_files[x] for x in sorted(source_files)],
    'runtime_receipts': receipts,
}
raw = (json.dumps(plan, ensure_ascii=False, indent=2) + '\n').encode()
input_sha = hashlib.sha256(raw).hexdigest()
(OUT / 'closeout-input.json').write_bytes(raw)
source = ROOT / 'cleanup/cleanup_next_remote.py'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == '40ec291eb7bafaaed39759d989eef506e9f396c991bbd8e74b1d35f6c7df4baf'
old = b"INPUT_SHA256 = ''  # Root fills this only after publication and exact readback."
assert original.count(old) == 1
final = original.replace(old, ("INPUT_SHA256 = '" + input_sha + "'  # Exact published/readback input approved by root.").encode())
(OUT / 'cleanup_next_remote.py').write_bytes(final)
record = {
    'schema': 1, 'reviewer': '/root', 'status': 'FINAL_INPUT_BOUND_NOT_EXECUTED',
    'unbound_helper_sha256': hashlib.sha256(original).hexdigest(),
    'bound_helper_sha256': hashlib.sha256(final).hexdigest(),
    'input': pin('closeout-input.json', raw),
    'only_helper_change': 'One INPUT_SHA256 assignment and its comment; complete review and both narrow corrections read by root.',
    'published_readback': retained[0], 'source_files_pinned': len(source_files),
    'original_source_copy_files_pinned': 3290, 'runtime_receipts': 20,
    'expected_settled_children': 706,
    'limits': 'Only the exact own root may move; no deletion, no trash emptying, no shared/older-root movement. Available command lines are bounded observations.'
}
(ROOT / 'cleanup/final-input-binding.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record, ensure_ascii=False, indent=2))
