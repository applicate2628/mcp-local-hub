"""Close one published iteration root by one direct trash rename; never delete."""
import sys

if not sys.flags.dont_write_bytecode or sys.flags.optimize:
    raise SystemExit('Use python -B without optimization; no helper actions performed')

import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
from pathlib import Path, PurePosixPath

BASE = Path(r'D:\dev\ChatGPT')
SRC = BASE / 'mcp-next-20261122-e21a1792'
DST = BASE / 'trash/mcp-next-20261122-e21a1792'
HOLD = BASE / 'mcp-next-closeout-20261122-e21a1792'
INPUT = HOLD / 'closeout-input.json'
RECEIPT = HOLD / 'cleanup-receipt.json'
INPUT_SHA256 = '3c44b21925a1cce46102ddfc71232ad46dbb644c5cc74933f562aa3672c3b7ad'  # Exact published/readback input approved by root.
record = {'schema': 'iteration-trash-closeout-v1', 'source': str(SRC),
          'destination': str(DST), 'retained_directory': str(HOLD),
          'state': 'checking', 'queries': [], 'move_attempted': False,
          'deletion_attempted': False, 'trash_emptied': False,
          'limits': ['Available command lines and executable paths only; inaccessible commands and process working directories are not proven idle.',
                     'No general process-tree settlement or atomic namespace-lock guarantee.',
                     'Explicit output/profile/temp/cache paths use D; this is not system-wide filesystem-write tracing.'],
          'inventory_definition': 'SHA256 of UTF-8 compact JSON, ensure_ascii=False, sort_keys=True; sorted files [relative POSIX path,bytes,SHA256] and sorted directories including dot root.'}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe(path, directory):
    leaf = None
    for item in (path, *path.parents):
        info = item.lstat()
        if item == path:
            leaf = info
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 0x400,
                'Reparse/link path: ' + str(item))
        if item != path or directory:
            require(stat.S_ISDIR(info.st_mode), 'Nonordinary directory: ' + str(item))
        else:
            require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1,
                    'Nonregular or multiply linked file: ' + str(item))
    return leaf


def stamp(info):
    return [info.st_dev, info.st_ino, info.st_nlink, info.st_size, info.st_mtime_ns]


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def save(stream):
    record['updated_utc'] = now()
    require(stamp(safe(RECEIPT, False))[:2] == stamp(os.fstat(stream.fileno()))[:2],
            'Receipt path identity changed')
    stream.seek(0)
    stream.write(json_bytes(record))
    stream.truncate()
    stream.flush()
    os.fsync(stream.fileno())


def write_new(path, raw):
    safe(path.parent, True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    safe(path, False)
    require(path.read_bytes() == raw, 'Retained output readback differs')


def relative(value):
    require(isinstance(value, str), 'Relative path must be text')
    path = PurePosixPath(value)
    require(value and not path.is_absolute() and str(path) == value
            and not any(p in {'.', '..'} for p in path.parts)
            and all(p == p.rstrip(' .') for p in path.parts)
            and '\\' not in value and ':' not in value, 'Unsafe relative path')
    return path


def pinned_files(root, entries):
    require(isinstance(entries, list) and entries, 'Missing pinned files')
    seen = {}
    for entry in entries:
        name = str(relative(entry['path']))
        require(name not in seen and isinstance(entry['bytes'], int) and entry['bytes'] >= 0
                and re.fullmatch(r'[0-9a-f]{64}', entry['sha256']), 'Invalid or duplicate file pin')
        path = root / name
        before = safe(path, False)
        raw = path.read_bytes()
        require(stamp(before) == stamp(safe(path, False)), 'Pinned file changed while reading')
        require(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'],
                'Pinned bytes differ: ' + name)
        seen[name] = raw
    return seen


def query(env):
    ps = str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/powershell.exe')
    script = "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath | ConvertTo-Json -Compress"
    result = subprocess.run([ps, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
                            cwd=HOLD, env=env, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    require(result.returncode == 0 and not result.stderr, 'Process query failed')
    rows = json.loads(result.stdout.decode('utf-8-sig'))
    if isinstance(rows, dict):
        rows = [rows]
    require(isinstance(rows, list) and rows and all(isinstance(r, dict) for r in rows),
            'Process query did not return process rows')
    needle = str(SRC).casefold()
    hits = []
    for row in rows:
        for field in ('CommandLine', 'ExecutablePath'):
            text = (row.get(field) or '').replace('/', '\\').casefold()
            tails = text.split(needle)[1:]
            if any(not tail or tail[0] in ('\\', chr(34), chr(39), ' ', '\t', '\r', '\n',
                                          ';', '&', '|', '(', ')', '<', '>', '}', ']', ',') for tail in tails):
                hits.append(row)
                break
    record['queries'].append({'utc': now(), 'rows': len(rows),
                             'available_command_lines': sum(bool(r.get('CommandLine')) for r in rows),
                             'unavailable_command_lines': sum(not r.get('CommandLine') for r in rows),
                             'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                             'exact_path_matches': hits})
    require(not hits, 'An available process references the exact source path')


def fail(error):
    raise error


def inventory(root):
    first = safe(root, True)
    files, directories, stamps = [], ['.'], {'./': stamp(first)}
    for parent, names, leaves in os.walk(root, followlinks=False, onerror=fail):
        safe(Path(parent), True)
        for name in names:
            path = Path(parent) / name
            info = safe(path, True)
            name = path.relative_to(root).as_posix()
            directories.append(name)
            stamps[name + '/'] = stamp(info)
        for name in leaves:
            path = Path(parent) / name
            before = safe(path, False)
            digest, size = hashlib.sha256(), 0
            with path.open('rb') as stream:
                require(stamp(os.fstat(stream.fileno())) == stamp(before), 'Opened file identity differs')
                for block in iter(lambda: stream.read(1048576), b''):
                    digest.update(block)
                    size += len(block)
                require(stamp(os.fstat(stream.fileno())) == stamp(before), 'Open file changed while hashing')
            after = safe(path, False)
            require(stamp(before) == stamp(after) and size == after.st_size,
                    'File changed while hashing: ' + str(path))
            name = path.relative_to(root).as_posix()
            files.append([name, size, digest.hexdigest()])
            stamps[name] = stamp(after)
    files.sort()
    directories.sort()
    payload = json.dumps({'files': files, 'directories': directories}, ensure_ascii=False,
                         sort_keys=True, separators=(',', ':')).encode('utf-8')
    summary = {'files': len(files), 'directories_including_root': len(directories),
               'bytes': sum(x[1] for x in files), 'inventory_sha256': hashlib.sha256(payload).hexdigest()}
    require(stamp(first) == stamp(safe(root, True)), 'Root changed during inventory')
    return summary, payload, stamps


def main():
    require(os.name == 'nt' and not sys.flags.optimize and sys.flags.dont_write_bytecode
            and len(sys.argv) == 1, 'Use the pinned helper with python -B on Windows, without arguments')
    require(Path(__file__).absolute() == HOLD / 'cleanup_next_remote.py', 'Unexpected helper path')
    require(re.fullmatch(r'[0-9a-f]{64}', INPUT_SHA256) is not None,
            'Publication pins are not finalized; no cleanup actions performed')
    safe(HOLD, True)
    safe(Path(__file__), False)
    safe(INPUT, False)
    raw = INPUT.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == INPUT_SHA256, 'Closeout input bytes differ')
    plan = json.loads(raw)
    require(plan['schema'] == 'iteration-trash-closeout-input-v1' and plan['ready'] is True
            and plan['source'] == str(SRC) and plan['destination'] == str(DST)
            and plan['retained_directory'] == str(HOLD), 'Closeout input is not ready for this exact root')
    require(isinstance(plan['published_commits'], list) and plan['published_commits']
            and all(re.fullmatch(r'[0-9a-f]{40}', c) for c in plan['published_commits']), 'Missing published commit pins')
    os.chdir(HOLD)
    with RECEIPT.open('xb') as receipt:
        try:
            record.update(input_sha256=INPUT_SHA256, published_commits=plan['published_commits'],
                          publication_gate='Exact pinned readback supplied after parent own review',
                          helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
            save(receipt)
            safe(SRC, True)
            safe(DST.parent, True)
            require(not os.path.lexists(DST) and SRC.stat().st_dev == DST.parent.stat().st_dev,
                    'Destination exists or is on another filesystem')
            retained = pinned_files(HOLD, plan['retained_files'])
            require('publication-readback.json' in retained, 'Publication readback is not retained outside trash')
            source_files = pinned_files(SRC, plan['source_files'])
            names = plan['runtime_receipts']
            require(isinstance(names, list) and names and len(set(names)) == len(names), 'Missing or duplicate runtime receipts')
            settled, expected_started = [], set()
            for name in names:
                require(name in source_files, 'Runtime receipt is not byte-pinned')
                row = json.loads(source_files[name])
                require(not row.get('process_tree_unresolved') and row.get('commands'), 'Unsettled or empty runtime receipt')
                started_parent = PurePosixPath(name).parent
                if name in {'reader-stage/receipt.json', 'relay-stage/receipt.json'}:
                    started_parent /= 'evidence'
                for child in row['commands'] + row.get('observations', []):
                    require(child.get('settled') is True and not child.get('timed_out')
                            and not child.get('process_tree_unresolved') and not child.get('error_type')
                            and isinstance(child.get('exit_code'), int), 'Unsettled recorded child')
                    label = child['label']
                    require(re.fullmatch(r'[A-Za-z0-9_-]+', label), 'Unsafe child label')
                    expected_started.add(str(started_parent / (label + '.started.json')))
                    settled.append({'receipt': name, 'label': label, 'pid': child.get('pid'), 'exit_code': child['exit_code']})
            record['settled_commands'] = settled
            record['retained_files'] = plan['retained_files']
            runtime = HOLD / 'query-runtime'
            runtime.mkdir()
            for name in ('profile', 'appdata', 'localappdata', 'tmp'):
                (runtime / name).mkdir()
            env = dict(os.environ)
            env.update(USERPROFILE=str(runtime / 'profile'), APPDATA=str(runtime / 'appdata'),
                       LOCALAPPDATA=str(runtime / 'localappdata'), TEMP=str(runtime / 'tmp'),
                       TMP=str(runtime / 'tmp'), TMPDIR=str(runtime / 'tmp'),
                       PSModuleAnalysisCachePath='NUL', POWERSHELL_TELEMETRY_OPTOUT='1', POWERSHELL_UPDATECHECK='Off',
                       PSModulePath=str(Path(env['SYSTEMROOT']) / 'System32/WindowsPowerShell/v1.0/Modules'))
            query(env)
            before_query, _, _ = inventory(SRC)
            query(env)
            before, payload, stamps = inventory(SRC)
            confirmed, _, current = inventory(SRC)
            require(before_query == before == confirmed and stamps == current,
                    'Content or metadata changed around the final process query')
            actual_started = {name for name, _, _ in json.loads(payload)['files'] if name.endswith('.started.json')}
            require(actual_started <= expected_started, 'An unaccounted started-command record remains')
            pinned_files(HOLD, plan['retained_files'])
            pinned_files(SRC, plan['source_files'])
            record.update(before_last_query=before_query, before=before, confirmed_before_move=confirmed,
                          two_strict_post_query_inventories_and_stamps_equal=True)
            write_new(HOLD / 'inventory-before.json', payload)
            require(stamp(safe(SRC, True)) == stamps['./'] and not os.path.lexists(DST), 'Root or destination changed')
            safe(DST.parent, True)
            safe(INPUT, False)
            safe(Path(__file__), False)
            require(hashlib.sha256(INPUT.read_bytes()).hexdigest() == INPUT_SHA256
                    and hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == record['helper_sha256'],
                    'Helper or closeout input changed before move')
            record['state'] = 'prepared_to_move'
            save(receipt)
            record['move_attempted'] = True
            save(receipt)
            os.rename(SRC, DST)
            record['state'] = 'moved_verifying'
            save(receipt)
            after, payload, _ = inventory(DST)
            write_new(HOLD / 'inventory-after.json', payload)
            record.update(after=after, inventory_equal=before == after,
                          source_absent=not os.path.lexists(SRC))
            require(record['inventory_equal'] and record['source_absent'], 'Post-move inventory differs')
            pinned_files(HOLD, plan['retained_files'])
            record['state'] = 'complete'
            save(receipt)
            print(json.dumps(record), flush=True)
        except BaseException as error:
            record.update(state='stopped', error=repr(error), source_exists=os.path.lexists(SRC),
                          destination_exists=os.path.lexists(DST))
            save(receipt)
            raise


if __name__ == '__main__':
    main()
