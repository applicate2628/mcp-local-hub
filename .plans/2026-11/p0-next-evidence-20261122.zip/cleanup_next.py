"""Preserve closed qualification inputs, then rename the owned workspace to trash."""
import sys
sys.dont_write_bytecode = True
import base64
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import zipfile

BASE = Path(r"D:\dev\ChatGPT")
ROOT = BASE / "mcp-p0-next-20261122-e51f"
CONTROL = BASE / "mcp-p0-next-closeout-20261122-e51f"
TARGET = BASE / "trash" / ROOT.name
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
TOP = {"architecture", "source", "inputs", "evidence", "exports", "plans", "runtime",
       "qualify_go.py", "prepare.py", "make_plans.py", "export_evidence.py", "stage_serena.py",
       "stage-inputs.json.zlib.b64", "serena-stage-inputs-v1.b64", "serena-stage-plans-v2.b64"}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def guard(path):
    path.relative_to(BASE)
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse point: " + str(current))

def read(path):
    guard(path)
    return path.read_bytes()

def write(path, raw):
    guard(path)
    with path.open("xb") as stream:
        stream.write(raw)

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()

def inventory(root):
    guard(root)
    rows = []
    def fail(error):
        raise error
    for directory, directories, files in os.walk(root, followlinks=False, onerror=fail):
        parent = Path(directory)
        guard(parent)
        rows.append({"path": parent.relative_to(root).as_posix(), "type": "directory"})
        for name in directories:
            guard(parent / name)
        for name in files:
            path = parent / name
            guard(path)
            if not stat.S_ISREG(path.lstat().st_mode):
                raise RuntimeError("Special file: " + str(path))
            raw = read(path)
            rows.append({"path": path.relative_to(root).as_posix(), "type": "file", "bytes": len(raw), "sha256": sha(raw)})
    return sorted(rows, key=lambda row: (row["path"], row["type"]))

def process_observation(label):
    runtime = CONTROL / ("runtime-" + label)
    runtime.mkdir(exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata"):
        (runtime / name).mkdir()
    env = {k.upper(): v for k, v in os.environ.items() if not k.upper().startswith(("MCPHUB_", "GIT_"))}
    env.update({"PSMODULEPATH": str(PS.parent / "Modules"), "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"),
                "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata"),
                "PSMODULEANALYSISCACHEPATH": str(runtime / "localappdata/module-cache"), "PYTHONDONTWRITEBYTECODE": "1"})
    command = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false); @(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,CommandLine | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Compress"
    argv = [str(PS), "-NoProfile", "-NonInteractive", "-Command", command]
    row = {"label": label, "started_utc": now(), "argv": argv, "powershell_sha256": sha(PS.read_bytes()), "direct_child_waited": False,
           "timed_out": False, "termination_requested": False}
    child = subprocess.Popen(argv, cwd=CONTROL, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    row["pid"] = child.pid
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        row.update(timed_out=True, finished_utc=now(), retain_workspaces=True)
        write(CONTROL / (label + ".json"), encoded(row))
        raise
    row.update(exit_code=child.returncode, direct_child_waited=True, finished_utc=now(),
               stdout_sha256=sha(stdout), stderr_sha256=sha(stderr), stderr_bytes=len(stderr))
    if child.returncode or stderr:
        row["error"] = "Process query failed; workspace retained"
        write(CONTROL / (label + ".json"), encoded(row))
        raise RuntimeError(row["error"])
    processes = json.loads(stdout.decode("utf-8-sig"))
    if not isinstance(processes, list) or not processes:
        raise RuntimeError("Invalid visible-process result")
    aliases = (str(ROOT).casefold(), ROOT.as_posix().casefold(), str(TARGET).casefold(), TARGET.as_posix().casefold())
    matches = [p for p in processes if any(a in (p.get("CommandLine") or "").casefold() for a in aliases)]
    row.update(process_rows=len(processes), missing_commandline=sum(not p.get("CommandLine") for p in processes), matches=matches,
               scope="Visible command lines only; no whole-machine, hidden-process or open-handle settlement claim")
    write(CONTROL / (label + ".json"), encoded(row))
    if matches:
        raise RuntimeError("Own workspace referenced by an observed process")
    return row

def export(path):
    raw = read(path)
    text = base64.b64encode(raw)
    chunks = []
    for index, start in enumerate(range(0, len(text), 180000)):
        part = text[start:start + 180000]
        name = path.stem + "-part-%03d.b64" % index
        write(CONTROL / name, part)
        chunks.append({"path": name, "bytes": len(part), "sha256": sha(part)})
    result = {"path": path.name, "bytes": len(raw), "sha256": sha(raw), "chunks": chunks}
    write(CONTROL / (path.stem + "-transport.json"), encoded(result))
    print(json.dumps(result), flush=True)

def prepare(config):
    if not ROOT.is_dir() or TARGET.exists() or {p.name for p in ROOT.iterdir()} != TOP:
        raise RuntimeError("Unexpected workspace state; retain it")
    seen_receipts = {}
    archive_rows = []
    for group, pub in config["publications"].items():
        proof = pub["readback"]
        if proof["parents"] != [pub["parent"]] or proof["head"] != pub["head"] or not proof["all_published_bytes_match"] or not proof["exact_changed_path_set"]:
            raise RuntimeError("Incomplete publication readback")
        archive_path = ROOT / "exports" / group / "raw-evidence.zip"
        if sha(read(archive_path)) != pub["archive_sha256"]:
            raise RuntimeError("Published archive changed: " + group)
        with zipfile.ZipFile(archive_path) as archive:
            manifest = json.loads(archive.read("manifest.json"))
            if len(manifest["files"]) != pub["payload_count"] or set(archive.namelist()) != {r["path"] for r in manifest["files"]} | {"manifest.json"}:
                raise RuntimeError("Published payload set differs")
            for row in manifest["files"]:
                raw = archive.read(row["path"])
                if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
                    raise RuntimeError("Archive payload mismatch")
                if row["path"].endswith("/receipt.json"):
                    receipt = json.loads(raw)
                    if not receipt.get("completed") or any(not c.get("settled") or c.get("timed_out") for c in receipt.get("commands", [])):
                        raise RuntimeError("Unsettled qualification")
                    if read(ROOT / row["path"]) != raw:
                        raise RuntimeError("Qualification receipt changed")
                    seen_receipts[row["path"]] = {"sha256": sha(raw), "waited_direct_children": len(receipt.get("commands", []))}
        archive_rows.append({"group": group, "sha256": pub["archive_sha256"], "published_head": pub["head"], "verified_payloads": pub["payload_count"]})
    observed = process_observation("before-inventory")
    before = inventory(ROOT)
    for directory, plan_pin in config["physical_sources"].items():
        raw = read(ROOT / plan_pin["path"])
        if sha(raw) != plan_pin["sha256"]:
            raise RuntimeError("Source plan changed")
        plan = json.loads(raw)
        actual = [{"path": r["path"][len(directory) + 1:], "bytes": r["bytes"], "sha256": r["sha256"]}
                  for r in before if r["type"] == "file" and r["path"].startswith(directory + "/")
                  and not r["path"].startswith(directory + "/.git/")]
        if sorted(actual, key=lambda r: r["path"]) != sorted(plan["source_files"], key=lambda r: r["path"]):
            raise RuntimeError("Unpreserved physical source change: " + directory)
    before_raw = encoded(before)
    write(CONTROL / "workspace-inventory-before.json.gz", gzip.compress(before_raw, mtime=0))
    payload = {"workspace-inventory-before.json.gz": read(CONTROL / "workspace-inventory-before.json.gz"),
               "cleanup-config.json": read(CONTROL / "cleanup-config.json"), "cleanup_next.py": read(Path(__file__)),
               "before-inventory.json": read(CONTROL / "before-inventory.json")}
    for row in before:
        if row["type"] != "file":
            continue
        top = row["path"].split("/", 1)[0]
        if top in ("source", "architecture"):
            continue
        if top == "exports" and not row["path"].endswith("/transport.json"):
            continue
        raw = read(ROOT / row["path"])
        if sha(raw) != row["sha256"]:
            raise RuntimeError("Workspace changed during preservation")
        payload["preserved/" + row["path"]] = raw
    report = {"schema": 1, "completed": True, "finished_utc": now(), "source": str(ROOT), "target": str(TARGET),
              "publication_archives": archive_rows, "qualification_receipts": seen_receipts,
              "physical_sources_match": True, "inventory_sha256": sha(before_raw),
              "files": sum(r["type"] == "file" for r in before), "directories": sum(r["type"] == "directory" for r in before),
              "bytes": sum(r.get("bytes", 0) for r in before), "preserved_payload_files": len(payload),
              "excluded": {"source": "Exact qualified Git source inventory; published physical source checkpoint",
                           "architecture": "Exact qualified Git parent plus four published changes; disposable clone metadata",
                           "exports": "Three independently read-back published archives; encoded chunks are reproducible transports"},
              "whole_process_tree_settlement_claimed": False, "process_observation": observed,
              "delete_attempted": False, "trash_emptied": False, "moved": False}
    write(CONTROL / "prepare-cleanup.json", encoded(report))
    payload["prepare-cleanup.json"] = encoded(report)
    payload["manifest.json"] = encoded({name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(payload.items())})
    path = CONTROL / "preserved-workspace.zip"
    with zipfile.ZipFile(path, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(payload.items()):
            archive.writestr(name, raw)
    export(path)

def move(config):
    ack = json.loads(read(CONTROL / "preservation-ack.json"))
    transport = json.loads(read(CONTROL / "preserved-workspace-transport.json"))
    if ack["archive_sha256"] != transport["sha256"] or not ack["all_payloads_verified"] or not ack["retained_outside_trash"]:
        raise RuntimeError("No verified external preservation")
    if sha(read(CONTROL / "preserved-workspace.zip")) != transport["sha256"]:
        raise RuntimeError("Preservation archive changed")
    before_compressed = read(CONTROL / "workspace-inventory-before.json.gz")
    with zipfile.ZipFile(CONTROL / "preserved-workspace.zip") as archive:
        if before_compressed != archive.read("workspace-inventory-before.json.gz"):
            raise RuntimeError("Live inventory differs from acknowledged preservation")
    before_raw = gzip.decompress(before_compressed)
    before = json.loads(before_raw)
    if encoded(inventory(ROOT)) != before_raw:
        raise RuntimeError("Workspace changed after preservation")
    observed = process_observation("before-move")
    for path in (ROOT, TARGET, TARGET.parent):
        guard(path)
    TARGET.parent.mkdir(exist_ok=True)
    if TARGET.exists() or ROOT.stat().st_dev != TARGET.parent.stat().st_dev:
        raise RuntimeError("Unsafe destination")
    receipt = {"schema": 1, "started_utc": now(), "source": str(ROOT), "target": str(TARGET), "moved": False,
               "preserved_archive_sha256": transport["sha256"], "local_preservation": ack, "completed": False,
               "delete_attempted": False, "trash_emptied": False, "termination_requested": False,
               "history_or_shared_cache_modified": False, "whole_process_tree_settlement_claimed": False,
               "process_observation": observed}
    receipt_path = CONTROL / "workspace-cleanup.json"
    write(receipt_path, encoded(receipt))
    try:
        ROOT.rename(TARGET)
        receipt["moved"] = True
        receipt_path.write_bytes(encoded(receipt))
        after = inventory(TARGET)
        after_raw = encoded(after)
        write(CONTROL / "workspace-inventory-after.json.gz", gzip.compress(after_raw, mtime=0))
        receipt.update(source_absent=not ROOT.exists(), target_exists=TARGET.is_dir(), inventory_equal=before == after,
                       inventory_before_sha256=sha(before_raw), inventory_after_sha256=sha(after_raw),
                       files=sum(r["type"] == "file" for r in after), directories=sum(r["type"] == "directory" for r in after),
                       bytes=sum(r.get("bytes", 0) for r in after))
        receipt["completed"] = receipt["source_absent"] and receipt["target_exists"] and receipt["inventory_equal"]
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = now()
        receipt_path.write_bytes(encoded(receipt))
        print(json.dumps(receipt), flush=True)
    if not receipt["completed"]:
        raise RuntimeError("Moved workspace requires inspection")

if __name__ == "__main__":
    if os.name != "nt" or Path(__file__).resolve().parent != CONTROL or len(sys.argv) != 3 or sys.flags.optimize:
        raise RuntimeError("Unexpected cleanup entry")
    for path in (BASE, ROOT, CONTROL, TARGET):
        guard(path)
    raw = read(CONTROL / "cleanup-config.json")
    if sha(raw) != sys.argv[2]:
        raise RuntimeError("Cleanup configuration changed")
    config = json.loads(raw)
    if sys.argv[1] == "prepare":
        prepare(config)
    elif sys.argv[1] == "move":
        move(config)
    else:
        raise RuntimeError("Unknown cleanup phase")
