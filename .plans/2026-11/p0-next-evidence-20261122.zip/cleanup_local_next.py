"""Preserve every owned local byte, then move the released workspace to trash."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import hashlib
import json
from pathlib import Path
import gzip
import zipfile

BASE = Path("/workspace/scratch/e51f442c712e")
OUT = BASE / "p0-next-closeout-20261122"
SOURCE = BASE / "p0-next-20261122"
TARGET = BASE / "trash" / "local-p0-next-20261122"
PRIOR = BASE / "continuation-closeout" / "cleanup_local.py"
if hashlib.sha256(PRIOR.read_bytes()).hexdigest() != "f5da55e6e91b9c062cb4d2cc953e1d18247eff29f424d109ed2eaf64b4b045a8":
    raise RuntimeError("Prior inventory helper changed")
spec = importlib.util.spec_from_file_location("local_inventory", PRIOR)
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
q.NAMES = (SOURCE.name,)

def main():
    q.require(Path(__file__).resolve().parent == OUT and q.os.name == "posix" and sys.argv[1:] == ["agents-released-by-root"], "Unexpected entry")
    for p in (OUT, SOURCE, TARGET):
        q.guard(p)
    q.require(SOURCE.is_dir() and not TARGET.exists() and not TARGET.is_symlink(), "Unexpected source or trash state")
    for pr in (655, 660, 663):
        record = json.loads((OUT / "publication" / ("readback-%s.json" % pr)).read_bytes())
        q.require(record["all_published_bytes_match"] and record["exact_changed_path_set"] and len(record["parents"]) == 1, "Incomplete publication")
        for row in record["files"]:
            raw = Path(row["local_path"]).read_bytes()
            q.require(len(raw) == row["bytes"] and q.sha(raw) == row["sha256"], "Publication candidate changed")
    observations = [q.processes("before-preservation")]
    q.require(not observations[-1]["matches"], "Visible process still references the workspace")
    before = q.inventory([(SOURCE.name, SOURCE)])
    q.require(all(r["type"] in ("file", "directory") for r in before), "Special entries require explicit preservation")
    inventory_raw = q.encoded(before)
    inventory_path = OUT / "local-inventory-before.json.gz"
    with inventory_path.open("xb") as stream:
        stream.write(gzip.compress(inventory_raw, mtime=0))
    archive_path = OUT / "local-workspace-recovery.zip"
    with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for row in before:
            if row["type"] == "file":
                raw = (BASE / row["path"]).read_bytes()
                q.require(len(raw) == row["bytes"] and q.sha(raw) == row["sha256"], "Source changed during preservation")
                archive.writestr(row["path"], raw)
        archive.writestr("inventory.json", inventory_raw)
    with zipfile.ZipFile(archive_path) as archive:
        q.require(archive.read("inventory.json") == inventory_raw, "Archive inventory differs")
        expected = {r["path"] for r in before if r["type"] == "file"} | {"inventory.json"}
        q.require(len(archive.namelist()) == len(expected) and set(archive.namelist()) == expected, "Archive file set differs")
        for row in before:
            if row["type"] == "file":
                raw = archive.read(row["path"])
                q.require(len(raw) == row["bytes"] and q.sha(raw) == row["sha256"], "Archive payload differs")
    q.require(q.inventory([(SOURCE.name, SOURCE)]) == before, "Workspace changed before move")
    observations.append(q.processes("before-move"))
    q.require(not observations[-1]["matches"], "Visible process still references the workspace")
    q.require(SOURCE.stat().st_dev == TARGET.parent.stat().st_dev, "Cross-volume move refused")
    receipt = {"schema": 1, "started_utc": q.now(), "source": str(SOURCE), "target": str(TARGET), "completed": False, "moved": False,
               "agents_released_by_root": True, "process_observations": observations,
               "recovery": {"path": str(archive_path), "bytes": archive_path.stat().st_size, "sha256": q.sha(archive_path.read_bytes()),
                            "all_file_payloads_verified": True}, "inventory_before_sha256": q.sha(inventory_raw),
               "retained_checkout": str(BASE / "mcphub-base"), "retained_prior_closeout": str(BASE / "continuation-closeout"),
               "delete_attempted": False, "termination_requested": False, "trash_emptied": False,
               "history_or_shared_cache_modified": False, "whole_process_tree_settlement_claimed": False}
    receipt_path = OUT / "local-cleanup.json"
    with receipt_path.open("x") as stream:
        json.dump(receipt, stream, indent=2)
    try:
        SOURCE.rename(TARGET)
        receipt["moved"] = True
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
        after = q.inventory([(SOURCE.name, TARGET)])
        after_raw = q.encoded(after)
        with (OUT / "local-inventory-after.json.gz").open("xb") as stream:
            stream.write(gzip.compress(after_raw, mtime=0))
        receipt.update(inventory_after_sha256=q.sha(after_raw), inventory_equal=before == after,
                       source_absent=not SOURCE.exists(), target_exists=TARGET.is_dir(),
                       files=sum(r["type"] == "file" for r in after), directories=sum(r["type"] == "directory" for r in after),
                       bytes=sum(r.get("bytes", 0) for r in after), retained_checkout_exists=(BASE / "mcphub-base").is_dir())
        receipt["completed"] = receipt["inventory_equal"] and receipt["source_absent"] and receipt["target_exists"] and receipt["retained_checkout_exists"]
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = q.now()
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps({k: receipt.get(k) for k in ("completed", "error", "files", "directories", "bytes", "inventory_equal", "source_absent", "recovery")}), flush=True)
    q.require(receipt["completed"], "Post-move verification differs")

if __name__ == "__main__":
    main()
