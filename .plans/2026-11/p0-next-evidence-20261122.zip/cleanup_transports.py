"""Trash only acknowledged transfer chunks and settled process-query runtimes."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import hashlib
import json
from pathlib import Path

CONTROL = Path(r"D:\dev\ChatGPT\mcp-p0-next-closeout-20261122-e51f")
helper = CONTROL / "cleanup_next.py"
if hashlib.sha256(helper.read_bytes()).hexdigest() != "080ba3eb36d8af9278a62552484c65edf548c9d4d6179346c364fde36c962d4f":
    raise RuntimeError("Reviewed helper changed")
spec = importlib.util.spec_from_file_location("closed_cleanup", helper)
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def main():
    if Path(__file__).resolve().parent != CONTROL or q.os.name != "nt":
        raise RuntimeError("Unexpected cleanup entry")
    target = q.BASE / "trash" / "mcp-p0-next-transports-20261122-e51f"
    q.guard(target)
    if target.exists():
        raise RuntimeError("Inspect existing trash destination")
    completed = json.loads(q.read(CONTROL / "workspace-cleanup.json"))
    ack = json.loads(q.read(CONTROL / "preservation-ack.json"))
    transport = json.loads(q.read(CONTROL / "preserved-workspace-transport.json"))
    if not completed["completed"] or not ack["all_payloads_verified"] or not ack["retained_outside_trash"]:
        raise RuntimeError("Results are not retained")
    if ack["archive_sha256"] != transport["sha256"] or q.sha(q.read(CONTROL / "preserved-workspace.zip")) != ack["archive_sha256"]:
        raise RuntimeError("Retained archive changed")
    names = []
    for row in transport["chunks"]:
        raw = q.read(CONTROL / row["path"])
        if len(raw) != row["bytes"] or q.sha(raw) != row["sha256"]:
            raise RuntimeError("Transfer chunk changed")
        names.append(row["path"])
    for label in ("before-inventory", "before-move"):
        probe = json.loads(q.read(CONTROL / (label + ".json")))
        if not probe["direct_child_waited"] or probe["timed_out"] or probe["exit_code"] != 0:
            raise RuntimeError("Process query not settled")
        names.append("runtime-" + label)
    def selected(base):
        result = []
        for name in names:
            path = base / name
            q.guard(path)
            if path.is_dir():
                for row in q.inventory(path):
                    row = dict(row)
                    row["path"] = name if row["path"] == "." else name + "/" + row["path"]
                    result.append(row)
            else:
                raw = q.read(path)
                result.append({"path": name, "type": "file", "bytes": len(raw), "sha256": q.sha(raw)})
        return sorted(result, key=lambda r: (r["path"], r["type"]))
    before = selected(CONTROL)
    receipt = {"schema": 1, "started_utc": q.now(), "source": str(CONTROL), "target": str(target), "completed": False,
               "retained_evidence_directory": str(CONTROL), "retained_preservation_sha256": ack["archive_sha256"],
               "selection": names, "moves": [], "inventory_before": before, "delete_attempted": False,
               "termination_requested": False, "trash_emptied": False, "whole_process_tree_settlement_claimed": False}
    receipt_path = CONTROL / "transport-cleanup.json"
    q.write(receipt_path, q.encoded(receipt))
    try:
        target.mkdir()
        if target.stat().st_dev != CONTROL.stat().st_dev:
            raise RuntimeError("Cross-volume move refused")
        for name in names:
            (CONTROL / name).rename(target / name)
            receipt["moves"].append(name)
            receipt_path.write_bytes(q.encoded(receipt))
        after = selected(target)
        receipt.update(inventory_after=after, inventory_equal=before == after,
                       sources_absent=all(not (CONTROL / name).exists() for name in names),
                       files=sum(r["type"] == "file" for r in after), directories=sum(r["type"] == "directory" for r in after),
                       bytes=sum(r.get("bytes", 0) for r in after))
        receipt["completed"] = receipt["inventory_equal"] and receipt["sources_absent"]
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = q.now()
        receipt_path.write_bytes(q.encoded(receipt))
        print(json.dumps({k: receipt.get(k) for k in ("completed", "error", "files", "directories", "bytes", "inventory_equal", "sources_absent")}), flush=True)
    if not receipt["completed"]:
        raise RuntimeError("Post-move verification differs")

if __name__ == "__main__":
    main()
