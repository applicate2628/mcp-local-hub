"""Move the completed, published Product check workspace directly to trash."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

BASE = Path(r"D:\dev\ChatGPT")
CONTROL = BASE / "mcp-closeout-20261122-e51f"
SOURCE = BASE / "mcp-continuation-product-20261122-e51f"
TARGET = BASE / "trash" / "mcp-continuation-product-20261122-e51f"
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def guard(path):
    current = Path("D:\\")
    for part in path.parts[1:]:
        current /= part
        if current.exists():
            info = current.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("Unexpected reparse point: " + str(current))

def inventory(root):
    guard(root)
    rows = []
    def fail(error):
        raise error
    for directory, directories, files in os.walk(root, followlinks=False, onerror=fail):
        p = Path(directory)
        guard(p)
        rows.append({"path": p.relative_to(root).as_posix(), "type": "directory"})
        for name in files:
            path = p / name
            guard(path)
            if not stat.S_ISREG(path.lstat().st_mode):
                raise RuntimeError("Unexpected special file")
            data = path.read_bytes()
            rows.append({"path": path.relative_to(root).as_posix(), "type": "file",
                         "bytes": len(data), "sha256": digest(data)})
        for name in directories:
            guard(p / name)
    return sorted(rows, key=lambda row: (row["path"], row["type"]))

def main():
    if os.name != "nt" or Path(__file__).resolve().parent != CONTROL:
        raise RuntimeError("Unexpected cleanup root")
    for path in (BASE, CONTROL, SOURCE, TARGET.parent):
        guard(path)
    if not SOURCE.is_dir() or TARGET.exists():
        raise RuntimeError("Unexpected cleanup state")
    qualification = json.loads((SOURCE / "evidence-utf8/receipt.json").read_bytes())
    if not qualification.get("completed") or any(not x.get("direct_child_waited") for x in qualification["commands"]):
        raise RuntimeError("Qualification unsettled")
    if digest((SOURCE / "raw-evidence.zip").read_bytes()) != "1e874e5bc0914394848850ddec10afb6cf4ac585265a77a890f0f26a6d232174":
        raise RuntimeError("Published evidence mismatch")
    if digest(PS.read_bytes()) != qualification["powershell_sha256_after"]:
        raise RuntimeError("PowerShell identity drift")
    runtime = CONTROL / "runtime-product"
    runtime.mkdir(exist_ok=False)
    for name in ("tmp", "profile", "appdata", "localappdata"):
        (runtime / name).mkdir()
    env = dict(os.environ)
    env.update({"PSModulePath": str(PS.parent / "Modules"), "TEMP": str(runtime / "tmp"),
                "TMP": str(runtime / "tmp"), "USERPROFILE": str(runtime / "profile"),
                "APPDATA": str(runtime / "appdata"), "LOCALAPPDATA": str(runtime / "localappdata")})
    receipt = {"schema": 1, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "source": str(SOURCE), "target": str(TARGET), "completed": False,
               "published_head": "477f6e3f66eca482e2267351af3535c62db8ebb2",
               "published_files_read_back": 4, "trash_emptied": False, "delete_attempted": False,
               "process_observations": [], "runner_sha256": digest(Path(__file__).read_bytes())}
    def save():
        (CONTROL / "product-cleanup.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    def observe():
        command = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false); @(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,CommandLine | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Compress"
        result = subprocess.run([str(PS), "-NoProfile", "-NonInteractive", "-Command", command],
                                cwd=CONTROL, env=env, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False)
        if result.returncode or result.stderr:
            raise RuntimeError("Process observation failed; no move permitted")
        processes = json.loads(result.stdout.decode("utf-8-sig"))
        matches = [row for row in processes if str(SOURCE).casefold() in (row.get("CommandLine") or "").casefold()]
        receipt["process_observations"].append({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "process_rows": len(processes), "missing_commandline": sum(not row.get("CommandLine") for row in processes),
            "matches": matches, "scope": "Visible command lines only; no whole-machine settlement claim"})
        save()
        if matches:
            raise RuntimeError("Own source still referenced by an observed process")
    try:
        observe()
        before = inventory(SOURCE)
        receipt["inventory_before"] = before
        save()
        observe()
        TARGET.parent.mkdir(exist_ok=True)
        guard(TARGET.parent)
        if SOURCE.stat().st_dev != TARGET.parent.stat().st_dev:
            raise RuntimeError("Refuse cross-volume move")
        SOURCE.rename(TARGET)
        receipt["moved"] = True
        after = inventory(TARGET)
        receipt["source_absent"] = not SOURCE.exists()
        receipt["inventory_equal"] = before == after
        receipt["files"] = sum(row["type"] == "file" for row in after)
        receipt["directories"] = sum(row["type"] == "directory" for row in after)
        receipt["bytes"] = sum(row.get("bytes", 0) for row in after)
        if not receipt["source_absent"] or not receipt["inventory_equal"]:
            raise RuntimeError("Post-move verification mismatch; retain target for recovery")
        receipt["completed"] = True
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        print(json.dumps({key: receipt.get(key) for key in ("completed", "error", "files", "directories", "bytes", "inventory_equal", "source_absent")}), flush=True)

if __name__ == "__main__":
    main()
