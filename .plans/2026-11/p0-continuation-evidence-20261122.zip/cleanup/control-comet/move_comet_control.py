"""Reviewed inline-only final move of Comet's fully preserved control directory."""
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zlib

BASE = Path(r"D:\dev\ChatGPT")
SOURCE = BASE / "mcp-closeout-20261122-e51f"
TARGET = BASE / "trash" / SOURCE.name
EXPECTED_INVENTORY = "b9d93bd556f4b14dd24523fa8c76ef54ec3a146d3c102dc775466bbe310c73a2"
PRESERVATION_SHA = "92c589c88c03ea3c6128d441ca3eb7af2e829b7ac1441198217d1002ddaa65b2"
SUPPORT_SHA = "8379f770febe012a54b72e86c03ce0717511ce82f9ef8f9c9bc5ae558d83beb2"
PS_SHA = "3247bcfd60f6dd25f34cb74b5889ab10ef1b3ec72b4d4b3d95b5b25b534560b8"
RECEIPTS = {
    "architecture-cleanup.json": ("a9adb03d340fc5ce5e823ed78609659af63c6768759cb58e76d9901e52551a39", False, 3),
    "architecture-cleanup-recovery.json": ("f91d9b9fe41e766f0ff6a40b14fa8b150427ead19faf288aded75c0a23604394", True, 5),
    "scheduler-cleanup.json": ("8d079690eb814588d5c135c231cf6f7d8039fe32c6b5eaa1c7aba81882842229", True, 2),
}


def now():
    return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inventory_hash(rows):
    return sha(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())


result = {
    "schema": 1, "device": "Comet", "device_id": "9cf41183-4a92-4bca-a51b-528ca8ea98d7",
    "source": str(SOURCE), "target": str(TARGET), "started_msk": now(),
    "completed": False, "moved": False, "runner_sha256": globals().get("__reviewed_source_sha256__"),
    "local_preservation_manifest_sha256": PRESERVATION_SHA, "expected_inventory_sha256": EXPECTED_INVENTORY,
    "support_sha256": SUPPORT_SHA, "powershell_sha256": PS_SHA,
    "delete_attempted": False, "termination_requested": False, "trash_emptied": False,
    "new_remote_helper_or_receipt_files": False, "whole_machine_settlement_claimed": False,
    "prior_receipts": [], "process_observations": [], "commands": [],
}

try:
    if os.name != "nt" or sys.flags.optimize or not sys.flags.isolated or not sys.dont_write_bytecode:
        raise RuntimeError("Unexpected execution environment")
    os.chdir(BASE)
    # Reuse only the immutable, previously reviewed inventory and path-guard code.
    support_path = SOURCE / "cleanup_architecture.py"
    support_bytes = support_path.read_bytes()
    if sha(support_bytes) != SUPPORT_SHA:
        raise RuntimeError("Reviewed inventory support changed")
    support = {"__name__": "control_move_support", "__file__": str(support_path)}
    exec(compile(support_bytes, str(support_path), "exec"), support)
    guard, inventory, ps = support["guard"], support["inventory"], support["PS"]
    for path in (BASE, SOURCE, TARGET):
        guard(path)
    if not SOURCE.is_dir() or TARGET.exists():
        raise RuntimeError("Unexpected source or destination state")
    if any((BASE / name).exists() for name in ("mcp-continuation-20261122-e51f", "mcp-continuation-scheduler-20261122-e51f")):
        raise RuntimeError("An original task root is still present")
    if sha(ps.read_bytes()) != PS_SHA:
        raise RuntimeError("Comet PowerShell identity differs")
    for name, (expected, completed, count) in RECEIPTS.items():
        raw = (SOURCE / name).read_bytes()
        receipt = json.loads(raw)
        if sha(raw) != expected or receipt.get("completed") is not completed or len(receipt.get("commands", [])) != count:
            raise RuntimeError("Prior cleanup identity differs: " + name)
        if not (receipt.get("finished_msk") or receipt.get("finished_utc")) or any(not c.get("direct_child_waited") or c.get("timed_out") for c in receipt["commands"]):
            raise RuntimeError("Prior children remain unsettled: " + name)
        result["prior_receipts"].append({"path": name, "sha256": expected, "completed": completed, "waited_direct_children": count})
    runtime = SOURCE / "runtime-scheduler-cleanup"
    env = {key.upper(): value for key, value in os.environ.items()}
    env.update({"PSMODULEPATH": str(ps.parent / "Modules"), "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"),
                "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
                "LOCALAPPDATA": str(runtime / "localappdata"),
                "PSMODULEANALYSISCACHEPATH": str(runtime / "localappdata/module-cache"),
                "PYTHONDONTWRITEBYTECODE": "1"})

    def observe(label):
        command = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false); @(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,CommandLine | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Compress"
        entry = {"label": label, "started_msk": now(), "direct_child_waited": False}
        result["commands"].append(entry)
        child = subprocess.Popen([str(ps), "-NoProfile", "-NonInteractive", "-Command", command], cwd=BASE,
                                 env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        entry["pid"] = child.pid
        try:
            stdout, stderr = child.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            entry.update(timed_out=True, settlement="unsettled; no termination requested; source retained")
            raise
        entry.update(exit_code=child.returncode, direct_child_waited=True, finished_msk=now(),
                     stdout={"bytes": len(stdout), "sha256": sha(stdout)}, stderr={"bytes": len(stderr), "sha256": sha(stderr)})
        if child.returncode or stderr:
            raise RuntimeError("Native process observation failed")
        processes = json.loads(stdout.decode("utf-8-sig"))
        if not isinstance(processes, list) or not processes:
            raise RuntimeError("Unexpected process snapshot")
        aliases = (str(SOURCE).casefold(), SOURCE.as_posix().casefold(), str(TARGET).casefold(), TARGET.as_posix().casefold())
        matches = [p for p in processes if any(s in (p.get("CommandLine") or "").casefold() for s in aliases)]
        result["process_observations"].append({"msk": now(), "process_rows": len(processes),
            "missing_commandline": sum(not p.get("CommandLine") for p in processes), "matches": matches,
            "scope": "Visible command lines only; no hidden-process or open-handle settlement claim"})
        if matches:
            raise RuntimeError("Control path is referenced by an observed process")

    observe("before-inventory")
    before = inventory(SOURCE)
    result["inventory_before"] = before
    result["inventory_before_sha256"] = inventory_hash(before)
    if result["inventory_before_sha256"] != EXPECTED_INVENTORY:
        raise RuntimeError("Control inventory changed after local preservation verification")
    observe("before-move")
    guard(TARGET.parent)
    if TARGET.exists() or not TARGET.parent.is_dir() or SOURCE.stat().st_dev != TARGET.parent.stat().st_dev:
        raise RuntimeError("Refuse destination collision or cross-volume move")
    SOURCE.rename(TARGET)
    result["moved"] = True
    after = inventory(TARGET)
    result["inventory_after"] = after
    result["inventory_after_sha256"] = inventory_hash(after)
    result["source_absent"] = not SOURCE.exists()
    result["target_exists"] = TARGET.is_dir()
    result["inventory_equal"] = before == after
    result["files"] = sum(r["type"] == "file" for r in after)
    result["directories"] = sum(r["type"] == "directory" for r in after)
    result["bytes"] = sum(r.get("bytes", 0) for r in after)
    if not result["source_absent"] or not result["target_exists"] or not result["inventory_equal"]:
        raise RuntimeError("Post-move mismatch; retain target for recovery")
    result["completed"] = True
except BaseException as error:
    result["error"] = type(error).__name__ + ": " + str(error)
finally:
    result["finished_msk"] = now()
    data = json.dumps(result, ensure_ascii=False, separators=(",", ":")).encode()
    print("CONTROL_CLOSEOUT_ZLIB_BASE64=" + base64.b64encode(zlib.compress(data, 9)).decode(), flush=True)
sys.exit(0 if result["completed"] else 1)
