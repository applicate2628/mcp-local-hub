"""Read-only inline probes around the separately reviewed CONTROL directory move."""
import sys
sys.dont_write_bytecode = True
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

PHASE = __PHASE__
MANIFEST_B64 = __MANIFEST_B64__
MANIFEST_SHA = "d1ab5a5fe1e230a2caf7248e139bea8a54195a36728263f82dfb983ef6b2b9f5"
BASE = Path(r"D:\dev\ChatGPT")
SOURCE = BASE / "mcp-closeout-20261122-e51f"
TARGET = BASE / "trash" / SOURCE.name
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
PS_SHA = "95ce2acbc6cd9d7f4a22759d39a8d40fc2a53ceeecf068ef856849f0d2076961"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def guard(path):
    path.relative_to(BASE)
    current = Path("D:\\")
    for part in path.parts[1:]:
        current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("Reparse point refused: " + str(current))


def inventory(root, expected):
    guard(root)
    if not root.is_dir():
        raise RuntimeError("Expected directory is absent")
    directories, files = [], {}
    def fail(error):
        raise error
    for directory, children, names in os.walk(root, followlinks=False, onerror=fail):
        parent = Path(directory)
        guard(parent)
        relative = parent.relative_to(root).as_posix()
        if relative not in expected["directories"]:
            raise RuntimeError("Unexpected directory: " + relative)
        directories.append(relative)
        for name in children:
            guard(parent / name)
        for name in names:
            path = parent / name
            guard(path)
            relative = path.relative_to(root).as_posix()
            if relative not in expected["files"]:
                raise RuntimeError("Unexpected file: " + relative)
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise RuntimeError("Non-regular or multiply-linked file")
            raw = path.read_bytes()
            row = {"bytes": len(raw), "sha256": sha(raw)}
            if row != expected["files"][relative]:
                raise RuntimeError("Changed file: " + relative)
            files[relative] = row
    actual = {"directories": sorted(directories), "files": {key: files[key] for key in sorted(files)}}
    if actual != {"directories": expected["directories"], "files": expected["files"]}:
        raise RuntimeError("Missing inventory entry")
    return actual


def main():
    receipt = {"schema": 1, "phase": PHASE, "started_utc": now(), "completed": False,
               "source": str(SOURCE), "target": str(TARGET), "process_observations": [],
               "filesystem_write_requested": False, "move_requested_by_probe": False,
               "delete_attempted": False, "kill_attempted": False, "policy_changed": False,
               "scope": "Exact CONTROL files and visible process references only; no whole-machine settlement claim"}
    exit_code = 1
    try:
        if os.name != "nt" or sys.flags.optimize or len(sys.argv) != 1 or PHASE not in ("before", "after"):
            raise RuntimeError("Unexpected probe invocation")
        for path in (BASE, SOURCE, TARGET, TARGET.parent):
            guard(path)
        os.chdir(BASE)
        manifest_bytes = base64.b64decode(MANIFEST_B64, validate=True)
        if sha(manifest_bytes) != MANIFEST_SHA:
            raise RuntimeError("Frozen local-copy inventory differs")
        expected = json.loads(manifest_bytes)
        if Path(expected["source"]) != SOURCE or Path(expected["target"]) != TARGET:
            raise RuntimeError("Manifest changes source or target")
        receipt["manifest_sha256"] = MANIFEST_SHA
        if PHASE == "before":
            if TARGET.exists() or not SOURCE.is_dir() or SOURCE.stat().st_dev != TARGET.parent.stat().st_dev:
                raise RuntimeError("Refuse existing target, absent source, or cross-volume move")
            receipt["inventory_before_observers"] = inventory(SOURCE, expected)
            for name in ("product-cleanup.json", "encoding-cleanup-receipt.json"):
                prior = json.loads((SOURCE / name).read_bytes())
                if any(prior.get(key) is not True for key in ("completed", "moved", "source_absent", "inventory_equal")):
                    raise RuntimeError("Prior cleanup is incomplete: " + name)
            prior = json.loads((SOURCE / "encoding-cleanup-receipt.json").read_bytes())
            if len(prior.get("process_observations", [])) != 2 or any(row.get("direct_child_waited") is not True or row.get("timed_out") is not False for row in prior["process_observations"]):
                raise RuntimeError("An encoding cleanup observer is unsettled")
            if sha(PS.read_bytes()) != PS_SHA:
                raise RuntimeError("Native observer image differs")
            runtime = SOURCE / "encoding-cleanup-runtime"
            env = {key.upper(): value for key, value in os.environ.items() if not key.upper().startswith("MCPHUB_")}
            env.update({"PSMODULEPATH": str(PS.parent / "Modules"),
                        "PSMODULEANALYSISCACHEPATH": str(runtime / "localappdata/module-analysis.cache"),
                        "TEMP": str(runtime / "tmp"), "TMP": str(runtime / "tmp"), "TMPDIR": str(runtime / "tmp"),
                        "USERPROFILE": str(runtime / "profile"), "APPDATA": str(runtime / "appdata"),
                        "LOCALAPPDATA": str(runtime / "localappdata"), "PYTHONDONTWRITEBYTECODE": "1",
                        "MCPHUB_CONTROL_CLOSEOUT_SOURCE": str(SOURCE)})
            receipt["observer_runtime"] = str(runtime)
            command = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false); $root=$env:MCPHUB_CONTROL_CLOSEOUT_SOURCE; $all=@(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,CommandLine,ExecutablePath); $matches=@($all | Where-Object { ($_.CommandLine -and $_.CommandLine.IndexOf($root,[StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root+'\\',[StringComparison]::OrdinalIgnoreCase)) } | Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath); [pscustomobject]@{observed_utc=[DateTime]::UtcNow.ToString('o'); process_rows=$all.Count; missing_commandline=@($all | Where-Object {-not $_.CommandLine}).Count; missing_executable=@($all | Where-Object {-not $_.ExecutablePath}).Count; matches=$matches} | ConvertTo-Json -Compress -Depth 5"
            for number in (1, 2):
                row = {"number": number, "started_utc": now(), "direct_child_waited": False, "timed_out": False,
                       "argv": [str(PS), "-NoProfile", "-NonInteractive", "-Command", command]}
                receipt["process_observations"].append(row)
                child = subprocess.Popen(row["argv"], cwd=BASE, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                row["pid"] = child.pid
                try:
                    stdout, stderr = child.communicate(timeout=30)
                except subprocess.TimeoutExpired as error:
                    row.update(timed_out=True, retain_source=True, kill_attempted=False)
                    raise RuntimeError("Observer timed out; do not move CONTROL") from error
                row.update(direct_child_waited=True, exit_code=child.returncode, finished_utc=now())
                for stream, raw in (("stdout", stdout), ("stderr", stderr)):
                    row[stream] = {"bytes": len(raw), "sha256": sha(raw), "base64": base64.b64encode(raw).decode()}
                if child.returncode != 0 or stderr:
                    raise RuntimeError("Process observation failed")
                observation = json.loads(stdout.decode("utf-8-sig"))
                row["observation"] = observation
                if observation.get("matches") != [] or not isinstance(observation.get("process_rows"), int):
                    raise RuntimeError("CONTROL is referenced or process observation is malformed")
            actual = inventory(SOURCE, expected)
            if actual != receipt["inventory_before_observers"] or sha(PS.read_bytes()) != PS_SHA or TARGET.exists():
                raise RuntimeError("CONTROL or observer changed before move")
            receipt["same_volume"] = SOURCE.stat().st_dev == TARGET.parent.stat().st_dev
            if not receipt["same_volume"]:
                raise RuntimeError("Volume changed")
            receipt["target_absent"] = True
        else:
            if SOURCE.exists():
                raise RuntimeError("Original CONTROL still exists")
            actual = inventory(TARGET, expected)
            receipt["source_absent"] = True
        receipt["inventory"] = actual
        receipt["files"] = len(actual["files"])
        receipt["directories"] = len(actual["directories"])
        receipt["bytes"] = sum(row["bytes"] for row in actual["files"].values())
        receipt["completed"] = True
        exit_code = 0
    except BaseException as error:
        receipt["error"] = type(error).__name__ + ": " + str(error)
    finally:
        receipt["finished_utc"] = now()
        raw = (json.dumps(receipt, indent=2) + "\n").encode("utf-8")
        print(json.dumps({"receipt_bytes": len(raw), "receipt_sha256": sha(raw), "receipt_base64": base64.b64encode(raw).decode()}), flush=True)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
