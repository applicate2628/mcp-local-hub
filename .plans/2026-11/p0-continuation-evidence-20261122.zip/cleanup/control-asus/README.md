# Asus CONTROL closeout candidate

Status: completed after parent review. Both probes succeeded, the exact CONTROL directory was moved to trash, and all file bytes and directory entries matched before and after. The original CONTROL path is absent. All 11 payloads remain preserved outside trash in the verified local backup. No new remote control directory, helper, output file, or runtime was created.

`final.json` binds the exact before/after receipts, move tool result, probe sources, local backup, and raw process-snapshot streams by SHA-256. Both observers exited zero and were waited. Each snapshot saw 410 processes, with 27 unavailable command lines and executable paths; no visible reference to CONTROL was found. No whole-machine settlement is asserted.

## Scope and preserved contents

Source: `D:\dev\ChatGPT\mcp-closeout-20261122-e51f`.

Destination: `D:\dev\ChatGPT\trash\mcp-closeout-20261122-e51f`.

The complete expected directory contains 11 files, 15 directories including its root, and 107,661 file bytes. The two runtime directory trees have no files. `control-payload-backup.zip` already preserves all 11 locally available payloads and the exact full inventory. The before probe must prove that every remote byte matches this preserved copy before any move is allowed.

| Contents | Classification | Preserved copy |
| --- | --- | --- |
| `cleanup_product.py`, `product-cleanup.json` | Completed original Product cleanup helper and receipt | Exact local context files and backup ZIP |
| `encoding-cleanup.py`, `encoding-cleanup-inventory.json`, `encoding-publication-readback.json` | Completed parser cleanup helper, strict source inventory, and publication readback | Exact local cleanup files and backup ZIP |
| `encoding-published-raw.zip.b64` | Exact transport copy of the published parser evidence ZIP | Local carrier, published ZIP, and backup ZIP |
| `encoding-cleanup-receipt.json`, four `encoding-process-snapshot-*` streams | Completed parser cleanup evidence | Verified raw retrieval, local files, and backup ZIP |
| `runtime-product`, `encoding-cleanup-runtime` | Empty temporary profile trees | All 14 directory entries retained in the full inventory |

The original Product workspace is already in trash; neither probe reads or modifies it. The parser workspace has now been moved and its complete contents verified. The final move operates only on the named CONTROL directory.

## Reviewed execution sequence

1. Run the `before` command from `control-probe-commands.json`. It decompresses only the locally reviewed script in memory, changes its working directory to `D:\dev\ChatGPT`, and creates no remote files. It rejects reparse points, multiply linked or nonregular files, unexpected or changed entries, a preexisting destination, and a cross-volume destination. It verifies both completed cleanup receipts. Two native PowerShell Common Information Model (CIM) process snapshots run sequentially with literal arguments and the existing isolated CONTROL runtime; both must finish with exit zero and no visible references to CONTROL. No timeout causes a kill. Full inventory and observer-image hashes are checked again after the snapshots. Any extra runtime file also causes refusal. The receipt and raw snapshot streams are returned through standard output as a length- and SHA-256-bound Base64 envelope.
2. Save and verify the exact before receipt locally. Require success, two waited observers, no timeout, no matches, an absent destination, and a complete inventory identical to the local backup. Only then use Remote Desktop Commander `move_file` with the exact source and destination above. No deletion or purge is requested.
3. Run the `after` command. It performs no PowerShell invocation and writes no remote files. It requires the original CONTROL to be absent and verifies every file and directory under the trash destination against the same pinned inventory. Save the exact stdout receipt locally and require successful before/after inventory equality.

Process snapshots report missing command-line/executable fields explicitly; they do not establish whole-machine process settlement. The five original parser children and two parser-cleanup observers were already waited in their original receipts. Historical process identifiers are not reused as ownership claims.

## Pins

- Frozen inventory SHA-256: `d1ab5a5fe1e230a2caf7248e139bea8a54195a36728263f82dfb983ef6b2b9f5`.
- Local backup ZIP: 59,590 bytes, SHA-256 `45850a83c60fac8019093e93c4d8f000ec815d099be30e33304794a8f96ff85c`; 11 payloads plus inventory.
- Before probe: 12,903 bytes, SHA-256 `5082c502cbdcf8ac10c00a1b35b12c31553549c371104b9b8dce370348d63b37`.
- After probe: 12,902 bytes, SHA-256 `2b729b4c94dfbcb73d9020545fed700f6187142aa8a38845e2c0b1e302ba1917`.
- Commands are 6,567 and 6,563 characters, respectively, below the Windows CMD command-length limit. They use the existing Python 3.15 executable with `-I -B`, a plain executable path, and one quoted ASCII Python expression containing only Base64-compressed reviewed code.

No native Product, builder, Go, Node, Task Scheduler, dependency installation, policy override, deletion, trash purge, or process termination is requested.
